
label ep5_08_universitydylan:

    stop music fadeout 5

    if choice_made('ep4_livingsituation_dylan'):

        play music from_luna_to_mars fadein 5 volume 0.35
        show ep5 universitydylan_001 with wipeleft
        simon "Wow..." id ep5_08_universitydylan_063ea2e3
        show ep5 universitydylan_002 with d
        simon "No flashy ride today?" id ep5_08_universitydylan_e0f1ea96
        show ep5 universitydylan_003 with d
        dylan "Of course not." id ep5_08_universitydylan_f9e6747e
        dylan "I can't exactly drive back today." id ep5_08_universitydylan_31951e86
        show ep5 universitydylan_004 with d
        simon "And why's that?" id ep5_08_universitydylan_ba62b2ba
        show ep5 universitydylan_005 with d
        dylan "Dude... Today is the first real day of college." id ep5_08_universitydylan_659770e0
        show ep5 universitydylan_006 with d
        dylan "In other words, this is the day we get wasted!" id ep5_08_universitydylan_45454ce8
        show ep5 universitydylan_007 with d
        simon "What was all that talk about seeking an education and worrying about the future then?" id ep5_08_universitydylan_d530cc99
        show ep5 universitydylan_008 with d
        dylan "Who said there's no knowledge to be gained in the arms of a beautiful woman?" id ep5_08_universitydylan_3cf38405
        show ep5 universitydylan_009 with d
        dylan "Especially if the two of you are under the influence." id ep5_08_universitydylan_a8fbab8c
        show ep5 universitydylan_010 with d
        dylan "I've seen what you're like when you drink." id ep5_08_universitydylan_5e94fa2e
        dylan "You unleash the inner [name]." id ep5_08_universitydylan_8093da42
        show ep5 universitydylan_011 with d
        simon "And you..." id ep5_08_universitydylan_1eb2e28e
        simon "... Well, you get arrested." id ep5_08_universitydylan_1c2af165

        if choice_made('ep3_04_challenge_won'):
            show ep5 universitydylan_012 with d
            dylan "Good thing I have you to bail me out." id ep5_08_universitydylan_122435fe
            show ep5 universitydylan_013 with d
            dylan "The King of The Station!" id ep5_08_universitydylan_404970ed
            show ep5 universitydylan_014 with d
            dylan "Conqueror of The Test!" id ep5_08_universitydylan_4832def1
            show ep5 universitydylan_015 with d
            dylan "And most importantly..." id ep5_08_universitydylan_aa0bbd73
            show ep5 universitydylan_016 with d
            dylan "My bro!" id ep5_08_universitydylan_7c6237d2
            show ep5 universitydylan_017 with d
            simon "Bro..." id ep5_08_universitydylan_c78a43e4
            play sound bus_stop_arrival_short volume 0.4
            show ep5 universitydylan_018 with d
            dylan "Bro!"
            show ep5 universitydylan_019 with d
            simon "Come on, bro." id ep5_08_universitydylan_66ccecfe
            simon "Time to make history." id ep5_08_universitydylan_2a8c7e4a
            stop sound fadeout 1
            show ep5 universitydylan_038 with fade
            dylan "So..."
        else:

            show ep5 universitydylan_020 with d
            dylan "I had to pay Devilla and Angela money out of my own pocket to post bail for that." id ep5_08_universitydylan_34e9ce96
            dylan "They didn't let me try \"The Test\" either."
            dylan "I hope they let me take it someday though." id ep5_08_universitydylan_f50fc769
            show ep5 universitydylan_021 with d
            dylan "Unlike some people, I won't fail!" id ep5_08_universitydylan_8f88c2c5
            show ep5 universitydylan_022 with d
            simon "If you saw what I saw, you'd fail pretty damn quick." id ep5_08_universitydylan_ebf7730d
            show ep5 universitydylan_023 with d
            dylan "Hah! I doubt that!" id ep5_08_universitydylan_35dd7508
            show ep5 universitydylan_024 with d
            dylan "..." id ep5_08_universitydylan_d6b2ef43
            show ep5 universitydylan_025 with d
            dylan "Was it really that difficult?" id ep5_08_universitydylan_c5401b9e
            show ep5 universitydylan_026 with d
            simon "I can't tell you that." id ep5_08_universitydylan_675208c4
            simon "Only the chosen few know." id ep5_08_universitydylan_b6d0532f
            show ep5 universitydylan_027 with d
            dylan "Bro..." id ep5_08_universitydylan_8324bf67
            show ep5 universitydylan_019_1 with d
            simon "Come on. It's time." id ep5_08_universitydylan_0f9af131
            show ep5 universitydylan_038 with fade
            dylan "So..."

        $ debug_other_path()
    else:
        show ep5 universitydylan_028 with long_fade
        simon "(Wow, there sure are a lot of people on here today.)" id ep5_08_universitydylan_b8b4b9d0
        show ep5 universitydylan_029 with d
        simon "(Must be because it's the start of the semester...)" id ep5_08_universitydylan_622bafa4
        show ep5 universitydylan_030 with d
        simon "(Hold on...)" id ep5_08_universitydylan_0d7c893b
        simon "(Is that...?)" id ep5_08_universitydylan_ac9dc040
        play music from_luna_to_mars volume 0.2
        show ep5 universitydylan_031 with d
        simon "Dylan?" id ep5_08_universitydylan_45ba0e88
        show ep5 universitydylan_032 with d
        dylan "Bro!"
        show ep5 universitydylan_033 with d
        simon "You're riding the bus?" id ep5_08_universitydylan_31c166e5
        simon "What happened?" id ep5_08_universitydylan_9aa9ef74
        show ep5 universitydylan_034 with d
        dylan "It's our first real day of college." id ep5_08_universitydylan_5ef8ca0e
        dylan "There's no way I'm going home sober!" id ep5_08_universitydylan_0277afd2
        show ep5 universitydylan_035 with d
        simon "Right..." id ep5_08_universitydylan_41326fcf
        show ep5 universitydylan_036 with d
        dylan "And you're coming with me." id ep5_08_universitydylan_482afce0
        show ep5 universitydylan_037 with d
        simon "I am?" id ep5_08_universitydylan_8c1537af
        show ep5 universitydylan_043 with d
        dylan "Yup." id ep5_08_universitydylan_cac0358e
        dylan "After class of course." id ep5_08_universitydylan_4bfe8acc
        dylan "You've got to focus on your studies too." id ep5_08_universitydylan_782bed0a

    $ debug_other_path()

    show ep5 universitydylan_038 with d
    dylan "What classes do you have today?" id ep5_08_universitydylan_0b62a457
    show ep5 universitydylan_039 with d
    simon "Hmm... I think the first one is..." id ep5_08_universitydylan_d679a03a
    show ep5 universitydylan_040 with d
    simon "Introduction to Economics." id ep5_08_universitydylan_3f1eb7c8
    show ep5 universitydylan_041 with d
    dylan "Oh, cool. We're taking the same class!" id ep5_08_universitydylan_16dca289
    show ep5 universitydylan_042 with d
    simon "You're taking ECON 101 too?" id ep5_08_universitydylan_525fc59e
    play sound bus_brakes volume 0.4
    show ep5 universitydylan_043 with d
    dylan "Yeah." id ep5_08_universitydylan_5fd556a0
    dylan "I failed it last year." id ep5_08_universitydylan_2de02039
    show ep5 universitydylan_044 with d
    simon "How'd you fail an introductory course?" id ep5_08_universitydylan_b49c706b
    jump ep5_09_universityclass
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
