
label ep5_13_universityend:

    play music one_chance volume 0.45

    if choice_made("ep5_gabbyclass_ready"):
        show ep5 universityend_001 with d
        simon "AAAAAAGGGGHHHH!!!" id ep5_13_universityend_295ead28
        show ep5 universityend_002 with d
        simon "Aaaaaggghhhh..." id ep5_13_universityend_48aaa59e
        play sound door_open_hard 
        show ep5 universityend_003 with d
        simon "(That was a horrible idea.)" id ep5_13_universityend_88ff26fb
        play sound dress_shirt_unroll volume 0.7 
        simon "(But let's hope it worked.)" id ep5_13_universityend_8cea0c26
        show ep5 universityend_004 with d
        simon "(I hope no one saw me.)" id ep5_13_universityend_b293c00a
        simon "(The coast should be clear now.)" id ep5_13_universityend_74f5083e
        show ep5 universityend_005 with d
        simon "(Just act natural.)" id ep5_13_universityend_e0ea3996
        show ep5 universityend_006 with d
        student_uni_male "I think he went that way!" id ep5_13_universityend_172e9a6d
        show ep5 universityend_007 with d
        student_uni_male "Hey, buddy!" id ep5_13_universityend_4f748c90
        student_uni_male "Have you seen a naked guy run through here?" id ep5_13_universityend_72cd1236
        show ep5 universityend_008 with d
        simon "Um, what?" id ep5_13_universityend_c433015f
        show ep5 universityend_009 with d
        student_uni_male "He must have gone that way!" id ep5_13_universityend_951fd999

    $ debug_other_paths()

    play sound highschool_crowd1 volume 0.2

    show ep5 universityend_010 with d
    simon "(Everything's fine.)" id ep5_13_universityend_3eb3e4d8
    simon "(Just a normal conversation with a normal college friend.)" id ep5_13_universityend_738b3e1e
    simon "(Another ordinary day in the life of [name].)" id ep5_13_universityend_c216c59a
    show ep5 universityend_011 with d
    simon "(I'm pretty sure I'm done with classes for today.)" id ep5_13_universityend_2b45575a
    simon "(So, all that's left to do is go home and —)" id ep5_13_universityend_5ee23bf6
    stop sound fadeout 5
    show ep5 universityend_012 with d
    simon "(Oh, right...)" id ep5_13_universityend_95bf7d33
    simon "(Besides, the charity ball is tomorrow, so I'll be busy from the moment I wake up.)" id ep5_13_universityend_69e7f6d4
    show ep5 universityend_013 with d
    simon "(Maybe I should spend today with friends.)" id ep5_13_universityend_3ba9cfcd
    show ep5 universityend_014 with d
    simon "Hmmmm..." id ep5_13_universityend_36e616eb
    simon "(Dylan and Chloe are still in class.)" id ep5_13_universityend_ae6c6b4a
    show ep5 universityend_015 with d
    simon "(Maybe I should check in with Julia.)" id ep5_13_universityend_627bbe71

    if choice_made("ep5_juliaday_hide_under_the_bed"):
        show ep5 universityend_016 with d
        simon "Hey, Ju —" id ep5_13_universityend_281c8ca0
        show ep5 universityend_017 with d
        julia "TWINKLE TOES!" (what_italic=True)
        julia "You're alive!" (what_italic=True)
        show ep5 universityend_018 with d
        simon "Of course I am." id ep5_13_universityend_e3b60468
        show ep5 universityend_019 with d
        simon "If it were up to your mom though, I would no longer be among the living." id ep5_13_universityend_52dae30a
        show ep5 universityend_020 with d
        julia "Yup." (what_italic=True)
        julia "Sorry about that." (what_italic=True)
        show ep5 universityend_018 with d
        simon "It wasn't your fault. Relax." id ep5_13_universityend_0a34915a
    else:

        show ep5 universityend_016 with d
        simon "Hi, Julia!" id ep5_13_universityend_ab549b9e
        julia "Hey, you!" (what_italic=True)

    $ debug_other_paths()

    show ep5 universityend_021 with d
    simon "What's up?" id ep5_13_universityend_280a8994
    simon "I'm finished with class for today, so I thought we could hang out or something." id ep5_13_universityend_5480e6cd
    show ep5 universityend_022 with d
    julia "Oh..." (what_italic=True)
    show ep5 universityend_023 with d
    julia "The problem is, I'm still in class." id ep5_13_universityend_a5059db6
    julia "I think it'll be a while before I can leave." id ep5_13_universityend_3519eacb
    show ep5 universityend_024 with d
    julia "But we can meet up at the party later. How's that sound?" id ep5_13_universityend_13af0f81
    show ep5 universityend_025 with d
    simon "Party? What party?" id ep5_13_universityend_9307389b
    show ep5 universityend_026 with d
    julia "The party your friend invited me to." id ep5_13_universityend_63a5d648
    show ep5 universityend_025 with d
    simon "My friend invited you?" id ep5_13_universityend_869e8099
    show ep5 universityend_026 with d
    julia "Yeah, that Russian friend of yours from the book club." id ep5_13_universityend_182f7656
    show ep5 universityend_025 with d
    simon "Oooh. You mean Dylan." id ep5_13_universityend_5658067d
    show ep5 universityend_027 with d
    julia "That's him!" id ep5_13_universityend_fae36702
    show ep5 universityend_028 with d
    julia "Between us..." id ep5_13_universityend_99501729
    julia "Something seems off about him." id ep5_13_universityend_a155c7f1
    show ep5 universityend_029 with d
    simon "Oh, there's a lot off about Dylan." id ep5_13_universityend_ec1b47ba
    simon "But he's all right, I guess." id ep5_13_universityend_80b72ffc
    show ep5 universityend_028 with d
    julia "He seems nice. It's just that..." id ep5_13_universityend_40197d4e
    julia "I don't know. It doesn't seem like he's really Russian." id ep5_13_universityend_80de15a7
    show ep5 universityend_030 with d
    simon "(She wasn't kidding about being a genius.)" id ep5_13_universityend_b61a4f2d
    show ep5 universityend_031 with d
    simon "I don't know what you're talking about." id ep5_13_universityend_20b87264
    show ep5 universityend_032 with d
    julia "Right. It's not that important anyway." id ep5_13_universityend_aa986bd0
    julia "See you at the party later?" id ep5_13_universityend_10cc5ab4
    show ep5 universityend_033 with d
    simon "For sure." (what_italic=True)
    julia "Great! Back to class." id ep5_13_universityend_c74cf817

    jump ep5_14_angels
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
