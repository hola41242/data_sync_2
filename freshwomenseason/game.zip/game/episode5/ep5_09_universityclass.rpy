label ep5_09_universityclass:
    play sound highschool_crowd1 volume 0.2
    stop music fadeout 10 
    play music radio_graffiti volume 0.4 fadein 5
    show ep5 universityclass_001 with wipeleft
    dylan "Well, first of all..." id ep5_09_universityclass_10a995fe
    show ep5 universityclass_002 with d
    dylan "... The subject matter is crazy difficult." id ep5_09_universityclass_d930601b
    stop sound fadeout 5
    play sound door_open_hard
    show ep5 universityclass_003 with d
    dylan "And second..." id ep5_09_universityclass_dc06cde0
    show ep5 universityclass_004 with d
    dylan "... The professor's scorching hot." id ep5_09_universityclass_87e5eb43
    show ep5 universityclass_005 with d
    simon "Is she really allowed to dress like that for work?" id ep5_09_universityclass_4d031b64
    show ep5 universityclass_006 with d
    dylan "Dude... She's a fully grown, well-adjusted woman." id ep5_09_universityclass_c766f3ce
    dylan "She can wear whatever she wants." id ep5_09_universityclass_2e65c5b6
    show ep5 universityclass_007 with d
    dylan "And I'm so glad those are the clothes she likes to wear." id ep5_09_universityclass_22e7a7bb
    show ep5 universityclass_008 with d
    professor "Hello, students!" id ep5_09_universityclass_4d98dc52
    professor "Welcome, everyone." id ep5_09_universityclass_3fdc53df
    show ep5 universityclass_009 with d
    professor "That goes for the new faces..." id ep5_09_universityclass_aaa7fe57
    show ep5 universityclass_010 with d
    professor "... and the old ones as well." id ep5_09_universityclass_4af39ccd
    show ep5 universityclass_011 with d
    dylan "Hello, professor." (what_bold=True)
    show ep5 universityclass_012 with d
    simon "(There's that sudden change of accents again!)" id ep5_09_universityclass_5e758a7c
    show ep5 universityclass_013 with d
    professor "Please, find your seats." id ep5_09_universityclass_dafb9fe3

    show ep5 universityclass_014 with wipeleft
    professor "For our first class, we're going to be giving an overview of world economics..." id ep5_09_universityclass_f81341f2
    show ep5 universityclass_015 with d
    dylan "*Whispers.* Dude..." id ep5_09_universityclass_0c0cdb2b
    show ep5 universityclass_016 with d
    dylan "*Whispers.* Hey. Dude..." id ep5_09_universityclass_e6fcaa07
    show ep5 universityclass_017 with d
    simon "What is it?" id ep5_09_universityclass_da31dd9d
    show ep5 universityclass_018 with d
    dylan "Check that girl out." id ep5_09_universityclass_b1aad9ab
    show ep5 universityclass_019 with d
    simon "I think I saw her yesterday." id ep5_09_universityclass_a93bac49

    if choice_made('ep4_dylanphone_i_want_style'):
        show ep5 universityclass_020 with d
        simon "Yeah, I'm sure I did!" id ep5_09_universityclass_2076a5ba
        show ep5 universityclass_021 with d
        simon "That's the girl who said hi to me!" id ep5_09_universityclass_4b8e0253
        show ep5 universityclass_022 with d
        dylan "You're right!" id ep5_09_universityclass_60f550ad

    show ep5 universityclass_023 with d
    dylan "Dude... Don't look now... but I think she's checking us out." id ep5_09_universityclass_ff675dc8
    show ep5 universityclass_024 with d
    simon "Is she?" id ep5_09_universityclass_64588337
    show ep5 universityclass_025 with d
    dylan "Dude!" id ep5_09_universityclass_f31d1567
    dylan "I told you not to look!" id ep5_09_universityclass_ec8eb120
    show ep5 universityclass_026 with d
    simon "Check that out!" id ep5_09_universityclass_1c020fd5
    simon "She has a friend!" id ep5_09_universityclass_4b9d0d39
    show ep5 universityclass_027 with d
    dylan "I bet her friend is hot too." id ep5_09_universityclass_b55c9381
    stop music fadeout 5
    show ep5 universityclass_028 with d
    simon "I think we're about to find out." id ep5_09_universityclass_bdab5cb8
    simon "I think she's about to look this way." id ep5_09_universityclass_31baee32
    show ep5 universityclass_029 with d
    dylan "Oh, I can't wait to —" id ep5_09_universityclass_7cea858b
    play music easy volume 0.4
    show ep5 universityclass_030 with d
    professor "To pass this class, I hope." id ep5_09_universityclass_5ce43308
    show ep5 universityclass_031 with d
    dylan "Oh. Hello, ma'am." (what_bold=True)
    show ep5 universityclass_032 with d
    professor "Dylan, right?" id ep5_09_universityclass_96116758
    show ep5 universityclass_033 with d
    professor "I see you've made a new friend." id ep5_09_universityclass_51e4479e
    show ep5 universityclass_034 with d
    professor "And what's your name?" id ep5_09_universityclass_4ca3f536
    show ep5 universityclass_035 with d
    simon "It's [name]." id ep5_09_universityclass_533988a1
    show ep5 universityclass_036 with d
    professor "[name], were you paying attention to my lecture..." id ep5_09_universityclass_4c7107ed
    show ep5 universityclass_037 with d
    professor "... or to something else?" id ep5_09_universityclass_481ad3bd
    show ep5 universityclass_038 with d
    simon "Class of course!" id ep5_09_universityclass_c9cae2da
    show ep5 universityclass_039 with d
    professor "Oh really?" id ep5_09_universityclass_e0a74faa
    professor "Then what is the subject of today's class?" id ep5_09_universityclass_347a524e


    menu:
        "The stock market":
            $ ep5_universityclass_stock_market = True
            $ player_choice("ep5_universityclass_stock_market:true")
            show ep5 universityclass_040 with d
            simon "It's about... the stock market...?" id ep5_09_universityclass_b466b3fa
            show ep5 universityclass_041 with d
            professor "The stock market?" id ep5_09_universityclass_41bfe473
            professor "On the first day of ECON 101?" id ep5_09_universityclass_da8b03b6
            show ep5 universityclass_042 with d
            professor "You must be smart, wishing to discuss such advanced topics." id ep5_09_universityclass_fa093416
            show ep5 universityclass_043 with d
            professor "Maybe you should be doing the teaching." id ep5_09_universityclass_1035dbda
            show ep5 universityclass_044 with d
            simon "Sorry, professor." id ep5_09_universityclass_c2357ecc
            simon "I'll pay more attention." id ep5_09_universityclass_b6ca65fe
            show ep5 universityclass_045 with d
            professor "Good to know." id ep5_09_universityclass_ce06b32d
        "International politics":

            $ ep5_universityclass_international_politics = True
            $ player_choice("ep5_universityclass_international_politics:true")
            show ep5 universityclass_046 with d
            simon "Hmm..."
            show ep5 universityclass_047 with d
            simon "International politics of course." id ep5_09_universityclass_914c7f9e
            show ep5 universityclass_048 with d
            professor "International... politics?" id ep5_09_universityclass_0562c7d4
            show ep5 universityclass_049 with d
            professor "Are you sure you're in the right place?" id ep5_09_universityclass_fed27c86
            show ep5 universityclass_050 with d
            professor "The political science course is right next door." id ep5_09_universityclass_2ff069b4
            show ep5 universityclass_045 with d
            professor "You should pay more attention." id ep5_09_universityclass_de3b78ec
        "World economics"(True):

            $ ep5_universityclass_world_economy = True
            $ player_choice("ep5_universityclass_world_economy:true")
            show ep5 universityclass_051 with d
            simon "It was something about world economics." id ep5_09_universityclass_e8841c23
            show ep5 universityclass_052 with d
            professor "World economics, huh...?" id ep5_09_universityclass_96b2fa04
            show ep5 universityclass_053 with d
            professor "Hmm..." id ep5_09_universityclass_d909c829
            show ep5 universityclass_054 with d
            professor "Then you really were paying attention!" id ep5_09_universityclass_12a90fc2
            show ep5 universityclass_055 with d
            simon "(Holy shit. I got it!)" id ep5_09_universityclass_361577f0
            show ep5 universityclass_045 with d
            professor "Good to know you can multitask." id ep5_09_universityclass_f36b8918
        "Ask Dylan":

            $ ep5_universityclass_ask_dylan = True
            $ player_choice("ep5_universityclass_ask_dylan:true")
            show ep5 universityclass_046 with d
            simon "Umm..."
            show ep5 universityclass_056 with d
            simon "Dylan?" id ep5_09_universityclass_45ba0e88
            show ep5 universityclass_057 with d
            dylan "World economics." (what_bold=True)
            show ep5 universityclass_058 with d
            dylan "You were explaining how the events happening on the other side of the world can affect us here." (what_bold=True)
            show ep5 universityclass_059 with d
            simon "(Wow...)" id ep5_09_universityclass_943b1370
            show ep5 universityclass_060 with d
            professor "Very we —" id ep5_09_universityclass_9ab0d375
            show ep5 universityclass_061 with d
            dylan "As with the motherland, for example, when something happe —" (what_bold=True)
            show ep5 universityclass_062 with d
            professor "That's..." id ep5_09_universityclass_0e469a41
            professor "... quite enough, Dylan. Thank you." id ep5_09_universityclass_9ad2b011


    $ debug_other_path()

    show ep5 universityclass_063 with d
    professor "Moving on..." id ep5_09_universityclass_4180b957
    play sound school_bell volume 0.7 
    show ep5 universityclass_064 with long_fade
    stop sound
    professor "Well, I'm afraid that's all for today, folks." id ep5_09_universityclass_b128860e
    play sound highschool_crowd1 volume 0.2 
    show ep5 universityclass_065 with d
    dylan "*Whispers.* Bro, let's get out of here and find those girls." id ep5_09_universityclass_97fdb8a7
    stop sound fadeout 5
    show ep5 universityclass_066 with d
    simon "Good idea." id ep5_09_universityclass_9a3ac949
    show ep5 universityclass_067 with d
    professor "Not so fast, you." id ep5_09_universityclass_dbf75847
    show ep5 universityclass_068 with d
    simon "Huh?" id ep5_09_universityclass_708b4972
    show ep5 universityclass_069 with d
    professor "Go ahead, Dylan." id ep5_09_universityclass_f66118fc
    professor "Your friend will join you in a moment." id ep5_09_universityclass_80e6c891
    show ep5 universityclass_070 with d
    dylan "Sorry, bro..." (what_bold=True)
    play sound door_open_hard
    show ep5 universityclass_071 with d
    professor "May I have a word with you, [name]?" id ep5_09_universityclass_bfa3b627
    show ep5 universityclass_072 with d
    simon "(It's not like she's giving me much of a choice.)" id ep5_09_universityclass_2a375790
    show ep5 universityclass_073 with d
    simon "Um... Of course." id ep5_09_universityclass_fb0733b3
    play sound dress_shirt_fold volume 0.5
    show ep5 universityclass_074 with d
    professor "I'll get straight to the point." id ep5_09_universityclass_97f5008d
    show ep5 universityclass_075 with d
    professor "Don't be like him." id ep5_09_universityclass_dcaa54bf
    show ep5 universityclass_076 with d
    simon "Him?" id ep5_09_universityclass_7ab5bf0d
    show ep5 universityclass_077 with d
    professor "Dylan." id ep5_09_universityclass_6eff9b33
    show ep5 universityclass_078 with d
    professor "We tolerate his behavior because he comes from a different culture." id ep5_09_universityclass_08939f34
    professor "You, on the other hand, do not share that privilege." id ep5_09_universityclass_70beef19
    show ep5 universityclass_079 with d
    simon "(A different culture?)" id ep5_09_universityclass_d66555f2
    simon "(Does that mean the professors here also think he's Russian?)" id ep5_09_universityclass_bb740c67
    show ep5 universityclass_080 with d
    simon "(I'm starting to think no one around here has a brain.)" id ep5_09_universityclass_c62efbaf
    show ep5 universityclass_081 with d
    professor "You know... I understand what's going on." id ep5_09_universityclass_0965ed86
    professor "You're young, and there are plenty of pretty girls hanging around." id ep5_09_universityclass_1ddd3480
    show ep5 universityclass_082 with d
    professor "You're just horny and looking to have some fun." id ep5_09_universityclass_68e2a0e9
    show ep5 universityclass_083 with d
    professor "And there's nothing wrong with that." id ep5_09_universityclass_dab4c4fc
    show ep5 universityclass_084 with d
    simon "(She sure is straightforward!)" id ep5_09_universityclass_3b69442f
    show ep5 universityclass_085 with d
    professor "You were even checking me out." id ep5_09_universityclass_b348ca1f
    professor "And that's okay as well." id ep5_09_universityclass_fba1dcc5
    show ep5 universityclass_086 with d
    professor "But you can't keep talking and interrupting my class." id ep5_09_universityclass_aa1e89b5
    professor "You get a pass for today, but I want you to remember one thing." id ep5_09_universityclass_ab70e156
    show ep5 universityclass_087 with d
    professor "I can fail you in this subject — in more ways than one." id ep5_09_universityclass_a11e3e10
    show ep5 universityclass_088 with d
    professor "And if that happens, you'll end up a friendless loser." id ep5_09_universityclass_bae92173
    professor "Just like Dylan." id ep5_09_universityclass_72df77fb
    show ep5 universityclass_089 with d
    simon "Wow..." id ep5_09_universityclass_063ea2e3
    show ep5 universityclass_090 with d
    professor "Hmm... From the look on your face, I can tell you got the message." id ep5_09_universityclass_0d3c2e56
    professor "You seem to have more than one functioning neuron, unlike your friend." id ep5_09_universityclass_39077fce

    if choice_made('ep5_universityclass_world_economy'):
        show ep5 universityclass_091 with d
        professor "You were even paying attention in class and managed to squeak out the right answer." id ep5_09_universityclass_f29d7b11
        professor "You might be able to go places." id ep5_09_universityclass_77d9061e
    $ debug_other_path()
    show ep5 universityclass_092 with d
    professor "So the next logical step would be to apologize." id ep5_09_universityclass_a9cbd174
    show ep5 universityclass_091 with d
    professor "Or you might end up in trouble." id ep5_09_universityclass_47a92cef
    professor "So, what do you say?" id ep5_09_universityclass_165ba846

    menu:
        "Defend Dylan"(True):
            $ ep5_universityclass_defend_dylan = True
            $ player_choice("ep5_universityclass_defend_dylan:true")

            show ep5 universityclass_093 with d
            simon "He told me he failed your class before. Is that true?" id ep5_09_universityclass_e9397ed0
            show ep5 universityclass_094 with d
            professor "Yes. That one is useless." id ep5_09_universityclass_56eb7fa6
            show ep5 universityclass_095 with d
            simon "Did you threaten him like you're threatening me now?" id ep5_09_universityclass_bee3bf71
            show ep5 universityclass_096 with d
            professor "What?" id ep5_09_universityclass_bd2ad1dd
            show ep5 universityclass_097 with d
            simon "You heard me. Did you talk to him like you're talking to me?" id ep5_09_universityclass_19987b9d
            simon "Did you tell him you'd make his life a living hell if he didn't bow before you?" id ep5_09_universityclass_b82ef0c5
            show ep5 universityclass_098 with d
            professor "That's a big leap from what I was getting at." id ep5_09_universityclass_4e78f92f
            professor "I was just giving you some advice." id ep5_09_universityclass_0e3ba6dc
            professor "He, though, refused to listen." id ep5_09_universityclass_c8172d42
            show ep5 universityclass_099 with d
            simon "You have no idea who he is." id ep5_09_universityclass_18a51560
            simon "Or how he thinks." id ep5_09_universityclass_31313000
            show ep5 universityclass_100 with d
            professor "Thinks? That Neanderthal couldn't solve a simple math problem." id ep5_09_universityclass_667b3324
            show ep5 universityclass_099 with d
            simon "He might not be your brightest student, but he's one hell of a friend." id ep5_09_universityclass_995881ef
            show ep5 universityclass_101 with d
            professor "You know, I saw potential in you." id ep5_09_universityclass_451aa1f0
            show ep5 universityclass_102 with d
            professor "Now, I'm not so sure..." id ep5_09_universityclass_fdcb9a9a
            play sound dress_shirt_fold volume 0.4 
            show ep5 universityclass_103 with d
            professor "Don't say I didn't warn you." id ep5_09_universityclass_b3b66a45
            show ep5 universityclass_104 with d
            simon "This is far from over, isn't it?" id ep5_09_universityclass_f9639ee7
            show ep5 universityclass_105 with d
            professor "We'll see." id ep5_09_universityclass_cee2e49d
        "Apologize":

            $ ep5_universityclass_apologize = True
            $ player_choice("ep5_universityclass_apologize:true")

            show ep5 universityclass_106 with d
            simon "You're right." id ep5_09_universityclass_31425f31
            simon "I'm sorry I disturbed your class." id ep5_09_universityclass_5c93a20b
            show ep5 universityclass_107 with d
            professor "Ah, that's so great to hear!" id ep5_09_universityclass_60ecf0c3
            professor "What an excellent start." id ep5_09_universityclass_2a712dc5
            show ep5 universityclass_108 with d
            professor "I knew I saw potential in you." id ep5_09_universityclass_fdd24a68
            show ep5 universityclass_109 with d
            professor "Now, do you have anything else to apologize for?" id ep5_09_universityclass_a2247e94
            show ep5 universityclass_110 with d
            simon "I... don't think so?" id ep5_09_universityclass_8b737324
            show ep5 universityclass_111 with d
            simon "(What is she talking about?)" id ep5_09_universityclass_007852ba
            show ep5 universityclass_112 with d
            simon "(What else did I do wrong?)" id ep5_09_universityclass_b5f7b314
            show ep5 universityclass_113 with d
            simon "(Oh...)" id ep5_09_universityclass_adc41a60
            show ep5 universityclass_114 with d
            simon "I'm doing that thing right now, aren't I?" id ep5_09_universityclass_7434adc0
            show ep5 universityclass_115 with d
            professor "Yes, you are." id ep5_09_universityclass_8b163173
            show ep5 universityclass_116 with d
            simon "Sorry." id ep5_09_universityclass_dbe8eca4
            show ep5 universityclass_117 with d
            professor "What for?" id ep5_09_universityclass_c5580190
            show ep5 universityclass_118 with d
            simon "For staring." id ep5_09_universityclass_88268588
            show ep5 universityclass_119 with d
            professor "Staring at what?" id ep5_09_universityclass_5eb68ede
            show ep5 universityclass_120 with d
            simon "Your..." id ep5_09_universityclass_c2f80690
            show ep5 universityclass_121 with d
            professor "My...?" id ep5_09_universityclass_210b11d6
            show ep5 universityclass_122 with d
            simon "Do you really want me to say it?" id ep5_09_universityclass_e576d4e0
            show ep5 universityclass_123 with d
            professor "Of course." id ep5_09_universityclass_b124c856
            professor "Otherwise, it would just be an empty apology." id ep5_09_universityclass_6d0fb865
            show ep5 universityclass_124 with d
            simon "Fine." id ep5_09_universityclass_2eac89ff
            simon "Sorry for staring..." id ep5_09_universityclass_fdbe94bf
            show ep5 universityclass_125 with d
            simon "... at your massive tits!" id ep5_09_universityclass_6344e2f9
            show ep5 universityclass_126 with d
            professor "Ugh... A true lack of class." id ep5_09_universityclass_e116e7f5
            show ep5 universityclass_127 with d
            simon "What? You're the one who asked me to say it!" id ep5_09_universityclass_41c14343
            show ep5 universityclass_128 with d
            professor "Yeah, but there were better ways of wording it." id ep5_09_universityclass_8ad43bc0
            play sound dress_shirt_fold volume 0.4 
            show ep5 universityclass_129 with d
            professor "Anyway, you may still have potential." id ep5_09_universityclass_666cb70a
            show ep5 universityclass_130 with d
            professor "I'll be in touch." id ep5_09_universityclass_e4ee4f8f
            show ep5 universityclass_131 with d
            simon "Potential?" id ep5_09_universityclass_250152e0


    $ debug_other_path()
    show ep5 universityclass_132 with d
    simon "What in the hell kind of talk was that?" id ep5_09_universityclass_39d26e37

    jump ep5_10_afterclass
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
