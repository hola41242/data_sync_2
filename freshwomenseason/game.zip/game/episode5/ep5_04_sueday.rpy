
label ep5_04_sueday:

    show black as ep5 with Dissolve(1)
    pause 1
    show ep5 sueday_001 with Dissolve(2)
    simon "Hmm?" id ep5_04_sueday_0c4419c0
    play music in_bloom fadein 5 volume 0.3
    show ep5 sueday_002 with d
    simon "Oh. Hey, Sue." id ep5_04_sueday_f800a417
    show ep5 sueday_003 with d
    sue "Finally, you're awake." id ep5_04_sueday_3dfde3f9
    show ep5 sueday_004 with d
    sue "So, what do we know about this Emily character?" id ep5_04_sueday_444111e6
    sue "And what exactly does she have to do with my aunt?" id ep5_04_sueday_ff835139
    show ep5 sueday_005 with d
    simon "Huh?" id ep5_04_sueday_708b4972
    show ep5 sueday_006 with d
    sue "The girl with you in the picture." id ep5_04_sueday_fc1365a2
    show ep5 sueday_007 with d
    simon "Oh, that's what we're talking about." id ep5_04_sueday_ca1f23a1
    simon "Good morning to you too, Sue." id ep5_04_sueday_b1bc3874
    show ep5 sueday_008 with d
    simon "Wait. I thought you gave up investigating your aunt." id ep5_04_sueday_f88f26af
    show ep5 sueday_009 with d
    sue "Fuck that." id ep5_04_sueday_11045045
    sue "Things have changed." id ep5_04_sueday_2da75b2b
    sue "There are new players in the game." id ep5_04_sueday_32b4aaf1
    show ep5 sueday_010 with d
    simon "Unbelievable." id ep5_04_sueday_1d466f5b
    show ep5 sueday_011 with d
    sue "Relax. It'll help you find your father as well." id ep5_04_sueday_ae8b9b95
    show ep5 sueday_012 with d
    simon "How so?" id ep5_04_sueday_58bb722e
    show ep5 sueday_013 with d
    sue "The charity ball." id ep5_04_sueday_b73cbdf8
    sue "You've been to one before." id ep5_04_sueday_a4e86895
    sue "Probably to look for clues about your father." id ep5_04_sueday_90e437c3
    show ep5 sueday_014 with d
    simon "Oh... I didn't think about that possibility." id ep5_04_sueday_35bd2911
    show ep5 sueday_015 with d
    sue "You and your little girlfriend Emily." id ep5_04_sueday_65acc678
    show ep5 sueday_016 with d
    simon "She's not my..." id ep5_04_sueday_213146ff
    show ep5 sueday_017 with d
    simon "She was..." id ep5_04_sueday_4893cf1f
    show ep5 sueday_018 with Dissolve(0.5)
    simon "Actually, I don't know what she was to me." id ep5_04_sueday_4ec05ed7
    show ep5 sueday_019 with d
    sue "Whatever. From what you told me last night, she's clearly insane." id ep5_04_sueday_549c94d5
    show ep5 sueday_020 with d
    sue "If you want my honest opinion, I'd say you dodged a bullet with her." id ep5_04_sueday_dd8b1c0a
    show ep5 sueday_021 with d
    simon "Oh, you have no idea." id ep5_04_sueday_07de1ed7
    show ep5 sueday_022 with d
    simon "Do you think she knew my father?" id ep5_04_sueday_9dd1fc34
    show ep5 sueday_023 with d
    sue "Hmm... Maybe." id ep5_04_sueday_92c6669c
    show ep5 sueday_024 with d
    sue "You could always confront her about it." id ep5_04_sueday_745a254f
    show ep5 sueday_025 with d
    simon "I've got about a million reasons I need to confront her." id ep5_04_sueday_905acfd7
    show ep5 sueday_026 with d
    sue "I bet... But you should probably keep your cards close to your chest for now." id ep5_04_sueday_4f742764
    show ep5 sueday_027 with d
    sue "We don't know what Emily's up to." id ep5_04_sueday_db686bab
    show ep5 sueday_028 with d
    simon "You're right." id ep5_04_sueday_4a478b52
    show ep5 sueday_029 with d
    sue "We have to get more information before doing anything." id ep5_04_sueday_ecf2fd0e
    show ep5 sueday_030 with d
    simon "We?" id ep5_04_sueday_63c2ec93
    show ep5 sueday_031 with d
    sue "Yeah." id ep5_04_sueday_dd3f4c35
    sue "I won't let you face crazy alone." id ep5_04_sueday_364dc360
    show ep5 sueday_032 with d
    simon "Wow... That's really nice of you, Sue." id ep5_04_sueday_be44883f
    show ep5 sueday_033 with d
    sue "Shut up and lie back down." id ep5_04_sueday_0c2be4a1
    play sound bed
    show ep5 sueday_034 with vpunch
    simon "Ouch..." id ep5_04_sueday_9b8dc3ec
    play sound bed
    show ep5 sueday_035 with d
    sue "You're surprisingly soft." id ep5_04_sueday_f30177fe
    show ep5 sueday_036 with d
    simon "(Did she cuddle up next to me last night while we were sleeping?)" id ep5_04_sueday_f82941cd
    show ep5 sueday_037 with Dissolve(0.6)
    simon "(Yes, she must have.)" id ep5_04_sueday_7d2f66de
    show ep5 sueday_038 with d
    simon "(Well, if that's the case...)" id ep5_04_sueday_2ff3bc5a
    show ep5 sueday_039 with d
    simon "(Shit. I can't.)" id ep5_04_sueday_496daeed
    show ep5 sueday_040 with d

    simon "I have to get to class." id ep5_04_sueday_600a3624
    show ep5 sueday_041 with d
    sue "Oh. Right." id ep5_04_sueday_4e1a1c02
    show ep5 sueday_042 with d
    sue "Let me know when you'll be coming back." id ep5_04_sueday_f2241146
    sue "I'll try to keep my parents away." id ep5_04_sueday_b434bdeb
    show ep5 sueday_043 with d
    simon "When I'm coming back, huh? Sounds like we're getting serious." id ep5_04_sueday_c9f08e05
    show ep5 sueday_044 with d
    sue "Fuck you." id ep5_04_sueday_c40c9ea8
    show ep5 sueday_045 with d
    simon "Thanks, Sue." id ep5_04_sueday_1b5715b2
    simon "See you later." id ep5_04_sueday_ba91d610

    jump ep5_08_universitydylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
