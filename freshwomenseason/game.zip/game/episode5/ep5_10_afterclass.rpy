
label ep5_10_afterclass:
    play sound door_heavy volume 0.4
    play music fireside_chat fadein 3 volume 0.3
    show ep5 afterclass_001 with wipeleft
    dylan "What's up, bro?" id ep5_10_afterclass_9b742c18
    show ep5 afterclass_002 with d
    simon "Oh. Hey, Dylan. You're still here." id ep5_10_afterclass_de3d1ef1
    show ep5 afterclass_003 with d
    simon "I thought you'd have run off after those girls." id ep5_10_afterclass_e8459e28
    show ep5 afterclass_004 with d
    dylan "I was going to, but I didn't want to leave you all alone with her." id ep5_10_afterclass_6a6b383b
    show ep5 afterclass_005 with d
    simon "Thanks for waiting." id ep5_10_afterclass_93f86448
    show ep5 afterclass_006 with d
    dylan "You know... Last semester she told me she was going to make things hard for me." id ep5_10_afterclass_d0f4add0
    show ep5 afterclass_007 with d
    dylan "I thought she was talking about my dick." id ep5_10_afterclass_6890d232
    show ep5 afterclass_008 with d
    simon "What the...?" id ep5_10_afterclass_2f7e4b1f
    show ep5 afterclass_009 with d
    dylan "But now I know what she really meant." id ep5_10_afterclass_5f2f8994
    dylan "I didn't know she thought of me like that." id ep5_10_afterclass_a9c00414

    if choice_made('ep5_universityclass_defend_dylan'):
        show ep5 afterclass_010 with d
        dylan "Good thing I have you, bro." id ep5_10_afterclass_45e2b699
        dylan "You stood up to her for me." id ep5_10_afterclass_1b72f79a
        show ep5 afterclass_011 with d
        simon "I couldn't let her talk like that about my bro." id ep5_10_afterclass_7019a1df
        show ep5 afterclass_012 with d
        dylan "Bro..." id ep5_10_afterclass_8324bf67
        show ep5 afterclass_013 with d
        dylan "Well... at least we can fail together this time!" id ep5_10_afterclass_3c5ff0e9
        show ep5 afterclass_014 with d
        simon "What was that?" id ep5_10_afterclass_6d6196fe
        show ep5 afterclass_015 with d
        dylan "Come on, bro! We have to find those girls!" id ep5_10_afterclass_e827c7cb
    else:

        show ep5 afterclass_016 with d
        dylan "You did the right thing." id ep5_10_afterclass_0f22998d
        dylan "Otherwise, she'd be looking over your shoulder like she did with me." id ep5_10_afterclass_cb02b9a0
        show ep5 afterclass_017 with d
        dylan "Still... I was expecting a little more from you." id ep5_10_afterclass_87ad4214
        show ep5 afterclass_018 with d
        simon "Well, I just —" id ep5_10_afterclass_463cb124
        show ep5 afterclass_019 with d
        dylan "You covered your own ass." id ep5_10_afterclass_ad3df56f
        dylan "That's fine." id ep5_10_afterclass_0764ceb9
        show ep5 afterclass_020 with d
        dylan "Come on. We've got to find those girls." id ep5_10_afterclass_24d547ee
        show ep5 afterclass_021 with d
        dylan "You can actually help a bro out with this one."
        show ep5 afterclass_022 with d
        simon "Dylan..." id ep5_10_afterclass_6a94ab6d
        show ep5 afterclass_023 with d
        dylan "Come on!" id ep5_10_afterclass_2432a0c3

    $ debug_other_paths()

    show ep5 afterclass_024 with wipedown
    simon "Okay. Which way did they go?" id ep5_10_afterclass_d7872c1f
    show ep5 afterclass_025 with d
    dylan "I think they were..." id ep5_10_afterclass_9516f4b2
    show ep5 afterclass_026 with d
    dylan "Oh, they're right over there!" id ep5_10_afterclass_5a69b9a0
    stop music fadeout 5
    show ep5 afterclass_027 with d
    simon "Ah. Now we can get a good look at them!" id ep5_10_afterclass_8b5e4c86
    show ep5 afterclass_028 with d
    dylan "That's right!" id ep5_10_afterclass_9cb7eb4f
    dylan "I couldn't see blondie's face before." id ep5_10_afterclass_dea2d3a2
    play music sunny_days volume 0.4
    show ep5 afterclass_029 with d
    simon "She seems pretty." id ep5_10_afterclass_4dbc58d2
    simon "Reminds me of..." id ep5_10_afterclass_96d93a55
    show ep5 afterclass_030 with d
    simon "... Angela?!" id ep5_10_afterclass_472f6d97
    show ep5 afterclass_031 with d
    angela "Hmm?" id ep5_10_afterclass_94085e04
    show ep5 afterclass_032 with d
    angela "[name], is that you?" id ep5_10_afterclass_2e275f0f
    show ep5 afterclass_033 with d
    angela "Hey! Dylan's here too." id ep5_10_afterclass_a25bd693
    show ep5 afterclass_034 with d
    simon "Hey, Angela. I didn't know you went to school here too." id ep5_10_afterclass_b25bc13c
    show ep5 afterclass_035 with d
    angela "Strippers can study too!" id ep5_10_afterclass_9a70cd00
    show ep5 afterclass_036 with d
    simon "Umm..." id ep5_10_afterclass_92c095c3
    show ep5 afterclass_037 with d
    angela "Oh, relax! It's no secret!" id ep5_10_afterclass_dd90bf15
    show ep5 afterclass_038 with d
    angela "*Whispers.* What is a secret is that I come here to recruit girls for our night club." id ep5_10_afterclass_994733f4
    show ep5 afterclass_039 with d
    simon "You do what?!" id ep5_10_afterclass_5d93827b
    show ep5 afterclass_040 with d
    angela "I'm a job provider!" id ep5_10_afterclass_5b7ff20b
    show ep5 afterclass_041 with d
    dylan "Nice." (what_bold=True)
    show ep5 afterclass_042 with d
    angela "We're thinking about expanding our club, so we're going to need more girls." id ep5_10_afterclass_2ebced3e
    show ep5 afterclass_043 with d
    angela "Let me introduce you to our first candidate." id ep5_10_afterclass_b86f3d50
    show ep5 afterclass_044 with d
    angela "Gabby!" id ep5_10_afterclass_6b3a3457
    show ep5 afterclass_045 with d
    gabby "Hey. What's up, boys?" id ep5_10_afterclass_cda8a77b
    show ep5 afterclass_046 with d
    angela "She has many qualifications, some of which I hope you will discover soon enough." id ep5_10_afterclass_5891f4b2
    show ep5 afterclass_047 with d
    simon "I thought you and Devilla did the whole good cop/bad cop routine." id ep5_10_afterclass_e9863a60
    simon "What kind of cop will Gabby be at The Station?" id ep5_10_afterclass_642a4444
    show ep5 afterclass_048 with d
    angela "Ah. Well, we're actually thinking about doing a rebrand!" id ep5_10_afterclass_c61e486e
    angela "With our plans for expansion, the club will no longer be known as The Station. We're now going to be..." id ep5_10_afterclass_3a140b7d
    show ep5 afterclass_049 with d
    angela "The Hell Angels!" id ep5_10_afterclass_b1c32368
    show ep5 afterclass_050 with d
    dylan "Good, good, very good!" (what_bold=True)
    show ep5 afterclass_051 with d
    simon "So... what sort of work are you going to be doing there?" id ep5_10_afterclass_169d9347
    show ep5 afterclass_052 with d
    gabby "All kinds of jobs... I guess?" id ep5_10_afterclass_96def76f
    show ep5 afterclass_053 with d
    gabby "Actually, Angela told me I've got to start here." id ep5_10_afterclass_1794ec94
    gabby "The fact of the matter is: I don't have any clients yet." id ep5_10_afterclass_eba4e651
    show ep5 afterclass_054 with d
    angela "Why don't you help her out, [name]?" id ep5_10_afterclass_0f990479
    show ep5 afterclass_055 with d
    simon "Help her? How?" id ep5_10_afterclass_59f4387c
    show ep5 afterclass_056 with d
    angela "Well, you two have freshmen classes together, don't you?"
    angela "Just have a talk with her..." id ep5_10_afterclass_6ddcc372
    show ep5 afterclass_057 with hpunch
    simon "Here on campus. Really?!" id ep5_10_afterclass_03fdbb0d
    show ep5 afterclass_058 with d
    angela "Oh, [name]. You're silly." id ep5_10_afterclass_b188d610
    show ep5 afterclass_059 with d
    angela "We provide a wide variety of services!" id ep5_10_afterclass_544dca74
    angela "Not everything has to be what you saw during The Test." id ep5_10_afterclass_3c9051b8
    angela "She really is just going to have a chat with you." id ep5_10_afterclass_73ba32f3
    show ep5 afterclass_060 with d
    gabby "We have ethics class next." id ep5_10_afterclass_2d0c9b5a
    gabby "From what I hear, it's a great place for a conversation." id ep5_10_afterclass_60f9debe
    show ep5 afterclass_061 with d
    simon "Well, I don't see any harm in that." id ep5_10_afterclass_18e8d20f
    show ep5 afterclass_062 with d
    simon "Dylan?" id ep5_10_afterclass_45ba0e88
    show ep5 afterclass_063 with d
    dylan "I actually have a different class now." (what_bold=True)
    dylan "But good luck to you." (what_bold=True)
    show ep5 afterclass_064 with d
    simon "See you later then, Dylan." id ep5_10_afterclass_da4eca6d
    show ep5 afterclass_065 with d
    simon "You too, Angela!" id ep5_10_afterclass_00b02e00
    show ep5 afterclass_066 with d
    angela "Bye-bye!" id ep5_10_afterclass_2f97fa83
    show ep5 afterclass_067 with d
    gabby "So..." id ep5_10_afterclass_f8cd0c47
    show ep5 afterclass_068 with d
    gabby "You're [name], right?" id ep5_10_afterclass_2a898467
    show ep5 afterclass_069 with d
    simon "Yes. And you're Gabby?"
    show ep5 afterclass_070 with d
    gabby "Gabriela actually. But you can just call me Gabby." id ep5_10_afterclass_371e0c7d

    if choice_made('ep4_dylanphone_i_want_style'):
        show ep5 afterclass_071 with d
        simon "I remember you from yesterday." id ep5_10_afterclass_11a73c3c
        show ep5 afterclass_072 with d
        gabby "You were wearing an interesting hat. It caught my eye." id ep5_10_afterclass_4e9e337a
        show ep5 afterclass_073 with d
        gabby "I would have thought it strange, but you were so confident in wearing it..." id ep5_10_afterclass_bd102bfc
        show ep5 afterclass_074 with d
        gabby "It was sort of sexy even." id ep5_10_afterclass_1d79e293
        show ep5 afterclass_075 with d
        simon "Wow..." id ep5_10_afterclass_063ea2e3
        show ep5 afterclass_076 with d
        simon "Thanks." id ep5_10_afterclass_71286ac3

    $ debug_other_path()

    jump ep5_11_gabbyclass
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
