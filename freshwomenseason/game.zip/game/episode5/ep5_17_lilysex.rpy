

label ep5_17_lilysex:







show ep5 lilysex_001 with d
simon "You know what I want." id ep5_17_lilysex_69a2493a
show ep5 lilysex_002 with d
lily "Then we can both get..." id ep5_17_lilysex_00ca8d1a
show ep5 lilysex_003 with d
lily "... everything we want." id ep5_17_lilysex_49ce00f6
show ep5 lilysex_003_1 with d
simon "Now, it's a party." id ep5_17_lilysex_89090308
play sound cloth_whoosh volume 0.7
pause 2
show ep5 lilysex_004 with d
queue sound button_clicking
play music [keeping_score_st_evan, belong_to_you, neverend] volume 0.30
lily "Oh..." id ep5_17_lilysex_b9ce07a9
show ep5 lilysex_005 with d
lily "Hmm." id ep5_17_lilysex_335b7dce

show ep5 lilysex_005_1 with d
lily "Getting better." id ep5_17_lilysex_7af4e352
show ep5 lilysex_006 with d
simon "Is this the kind of party you wanted?" id ep5_17_lilysex_478502ec
show ep5 lilysex_007 with d
lily "Well, it's about to go better than I expected." id ep5_17_lilysex_004f5309
show ep5 lilysex_007_1 with d
lily "Waaaay better." id ep5_17_lilysex_f12005ab
show ep5 lilysex_008 with d
simon "Then you won't mind if I get a little more comfortable." id ep5_17_lilysex_a103be2f
show ep5 lilysex_009 with d
lily "I was thinking of doing the exact same thing." id ep5_17_lilysex_7c81b2df
show ep5 lilysex_010 with d
lily "I hope you don't mind..." id ep5_17_lilysex_d881ef5c
show ep5 lilysex_010_1 with d
play sound bed_movement_6 volume 0.3
simon "(Fuck.)" id ep5_17_lilysex_ecce5167
show ep5 lilysex_011 with d
lily "I wanted to feel sexy..." id ep5_17_lilysex_1cacc72b
show ep5 lilysex_011_1 with d
lily "I hope you like it." id ep5_17_lilysex_49923b42
show ep5 lilysex_012 with d
simon "I do." id ep5_17_lilysex_0723dbdf
simon "I like it a lot." id ep5_17_lilysex_00fa9f8c
show ep5 lilysex_013 with d
simon "I mean, I'm no lingerie expert, but the fabric looks high quality." id ep5_17_lilysex_412c96f2
show ep5 lilysex_014 with d
lily "It feels nice to the touch as well." id ep5_17_lilysex_b2f38e89


show ep5 lilysex_015 with d
simon "Hmm..." id ep5_17_lilysex_92c095c3
simon "I think I'm starting to understand what you were getting at." id ep5_17_lilysex_544dea3d
show ep5 lilysex_016 with d
lily "Is that so?" id ep5_17_lilysex_8420e971
lily "Then describe it to me." id ep5_17_lilysex_38bf8869
simon "Feels so soft and..." id ep5_17_lilysex_95df2f6a
lily "And...?" id ep5_17_lilysex_720dc3b1
show ep5 lilysex_017 with d
simon "(My god...)" id ep5_17_lilysex_fd1d367b
lily "Hmm. I'm feeling something hard down here..." id ep5_17_lilysex_050a8d0e
lily "Glad to see they still get you like this." id ep5_17_lilysex_8b64e61d
show ep5 lilysex_018 with d
simon "How could they not?" id ep5_17_lilysex_56280fad
simon "They're fantastic!" id ep5_17_lilysex_c349f718
show ep5 lilysex_019 with d
lily "That's good." id ep5_17_lilysex_9626d848
lily "So you wouldn't mind a closer look at them." id ep5_17_lilysex_b31e8993
show ep5 lilysex_020 with d
simon "Up close is even bet —" id ep5_17_lilysex_c6406ad6
show ep5 lilysex_021 with hpunch
play sound body_thud_2 volume 0.7
simon "Mmmmph..." id ep5_17_lilysex_c22ee880
lily "Be careful what you wish for..." id ep5_17_lilysex_74184e71
lily "Although I don't think you'll hate me for doing this." id ep5_17_lilysex_fb655604
show ep5 lilysex_022 with d
lily "I can tell by the bulge I'm feeling." id ep5_17_lilysex_2b7c5894
show ep5 lilysex_023 with d
lily "Oh yes..." id ep5_17_lilysex_54c3d860
show ep5 lilysex_024 with hpunch
play sound body_fall_mat8 volume 0.7
simon "*Gasp...* I can breathe." id ep5_17_lilysex_3ab4c921
show ep5 lilysex_025 with d
lily "Yep, and now it's my turn..." id ep5_17_lilysex_a07e430a
show ep5 lilysex_026 with d
lily "... to hold my breath." id ep5_17_lilysex_f33a7a78
show ep5 lilysex_026_1 with d
lily "I love worshiping this big cock of yours, [name]." id ep5_17_lilysex_8c2ac30b
simon "Wow. Things got really serious all of a sudden." id ep5_17_lilysex_1421dd46
show ep5 lilysex_027 with d
lily "There's no reason for me to hold back anymore." id ep5_17_lilysex_96070690



$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_030_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_030_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_030 with d
lily "I always saw myself as a free woman — as someone who could do whatever she wanted..." id ep5_17_lilysex_c10aea6b
lily "... Someone who didn't have to worry about the consequences." id ep5_17_lilysex_5a9336bc
lily "But now, I see that I was just ignoring them." id ep5_17_lilysex_9840ae18
pause



$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_029_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_029_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_029 with d
lily "Now, I understand my actions."
lily "I accept the consequences."
lily "And I want to shove your cock so deep down my throat I gag on it."
simon "I think I like this new Lily." id ep5_17_lilysex_8e0d00ea
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_028_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_028_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_028 with d
lily "Good." id ep5_17_lilysex_799a4356
lily "Because I wasn't planning on taking no for an answer." id ep5_17_lilysex_3a003b3d
simon "So this is the real Lily." id ep5_17_lilysex_e8195c94
simon "Hungry for cock." id ep5_17_lilysex_bbb520d8
lily "Only hungry for the best cock I've ever tasted." id ep5_17_lilysex_76118f3c
pause

stop foley
stop voicefx
show ep5 lilysex_031 with d
lily "This time, you're going to fuck me until I forget my name." id ep5_17_lilysex_64136d8b
show ep5 lilysex_032 with d
lily "No excuses." id ep5_17_lilysex_9d1b301d
show ep5 lilysex_033_1 with d
lily "No holding back." id ep5_17_lilysex_1ea79f30
show ep5 lilysex_033_2 with d
lily "No bra." id ep5_17_lilysex_996eb5ba
show ep5 lilysex_033_3 with d
play sound dress2 volume 0.1
lily "No panties." id ep5_17_lilysex_ed9b0267
show ep5 lilysex_034 with d
lily "Fuck me good, [name]." id ep5_17_lilysex_51da2abc
show ep5 lilysex_035 with d
simon "(Holy shit...)" id ep5_17_lilysex_bc4412d5
simon "You're really going all out." id ep5_17_lilysex_28adfabb
show ep5 lilysex_036 with d
lily "Is it too much for you?" id ep5_17_lilysex_b014794a
simon "Not a chance." id ep5_17_lilysex_3fa45ee5
show ep5 lilysex_037 with d
simon "Don't worry." id ep5_17_lilysex_d07c2225
simon "I can handle whatever you throw at me." id ep5_17_lilysex_a16d1927
show ep5 lilysex_037_2 with hpunch
play sound body_fall_mat8 volume 0.7
lily "Aaaaah..." id ep5_17_lilysex_725af55c
lily "Is that so? Then give me everything you've got!" id ep5_17_lilysex_c4fbd067


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_038_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_038_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_038 with d
lily "I've been dying to feel that fat dick of yours again." nointeract
pause 80/20


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_039_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_039_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_039 with d
simon "And I've missed your pussy ever since that day, Lily." id ep5_17_lilysex_f805d26d
simon "It's been too long." id ep5_17_lilysex_ea69fcca
lily "Show me how much you missed me." id ep5_17_lilysex_26b4bb63
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_039_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_039_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_039_var1 with d
lily "Tell me how much you missed me!" id ep5_17_lilysex_c8e8bac8
simon "I've missed you so much, Lily." id ep5_17_lilysex_2660de96
simon "Ever since the day you showed up at my doorstep, you've always been on my mind." id ep5_17_lilysex_e7e8c66c
pause
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_040_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_040_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_040 with d
simon "I wish I could have fucked you so much more." id ep5_17_lilysex_5522be85
simon "Like how I'm fucking you right now." id ep5_17_lilysex_30d615ea
lily "Then fuck me!" id ep5_17_lilysex_c1825f3b
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_041_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_041_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_041 with d
lily "Let's fuck like never before!" id ep5_17_lilysex_977fab1c
lily "Today you're doing so much for me." id ep5_17_lilysex_175d6275
simon "But it's only because I want to." id ep5_17_lilysex_73bc1521
simon "I'm also free to make my own choices." id ep5_17_lilysex_c0468d77
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_040_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_040_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_040_var1 with d
lily "I know." id ep5_17_lilysex_d83d00de
lily "Thanks for cheering me up today, [name]." id ep5_17_lilysex_6ab2b112
lily "As a reward, I'll give you the best ride of your life." id ep5_17_lilysex_bf4e97d7
pause

label ep5_17_lilysex_loop1:
    menu:
        "Blowjob":
            image ep5 anim_lilysex_blowjob_combo:
                "ep5 anim_lilysex_030" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_029" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_028" with Dissolve(0.5)
                pause 4
                repeat

            $ allow_voicefx = True
            if is_voice_installed:
                play voicefx ep5_anim_lilysex_blowjob_combo_voicefx fadein 0.5 fadeout 0.5
                play foley ep5_anim_lilysex_blowjob_combo_foley fadein 0.5 fadeout 0.5
            show ep5 anim_lilysex_blowjob_combo with d
            pause
            jump ep5_17_lilysex_loop1
        "Missionary":
            image ep5 anim_lilysex_missionary_combo:
                "ep5 anim_lilysex_039" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_039_var1" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_040" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_040_var1" with Dissolve(0.5)
                pause 4
                "ep5 anim_lilysex_041" with Dissolve(0.5)
                pause 4
                repeat

            $ allow_voicefx = True
            if is_voice_installed:
                play voicefx ep5_anim_lilysex_missionary_combo_voicefx fadein 0.5 fadeout 0.5
                play foley ep5_anim_lilysex_missionary_combo_foley fadein 0.5 fadeout 0.5
            show ep5 anim_lilysex_missionary_combo with d
            pause
            jump ep5_17_lilysex_loop1
        "Continue" if True:
            lily "Now, it's my turn to climb on top of you, [name]." nointeract
            $ renpy.pause()


play sound placeholder volume 0.4 

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_043_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_043_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_043 with d

simon "Now we're starting to have some fun." id ep5_17_lilysex_loop1_4f6fb684
lily "There's so much more to come." id ep5_17_lilysex_loop1_340b7ca6
simon "You're going wild, Lily." id ep5_17_lilysex_loop1_d3e6f99e
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_042_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_042_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_042 with d
lily "You should be happy about that, [name]!" id ep5_17_lilysex_loop1_45b99007
lily "I'm showing you the real me." id ep5_17_lilysex_loop1_0672b8ca
lily "You're getting to know the real Lily." id ep5_17_lilysex_loop1_f892821d
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_044_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_044_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_044 with d
lily "Will you show me who the real [name] is too?" id ep5_17_lilysex_loop1_b94a4c78
simon "The real [name], huh?" id ep5_17_lilysex_loop1_d4a957a3
simon "I wonder what that guy's like." id ep5_17_lilysex_loop1_efe0bf23
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_045_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_045_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_045 with d
simon "I would certainly like to know as well." id ep5_17_lilysex_loop1_9e0aae0e
simon "But right now, this [name] is just thinking about fucking you, Lily." id ep5_17_lilysex_loop1_1e733cfc
lily "Excellent. I'm very much enjoying this version of you." id ep5_17_lilysex_loop1_1d0b26a5
lily "Now..." id ep5_17_lilysex_loop1_0b09b169
pause

play sound placeholder volume 0.4 
stop foley
stop voicefx
show ep5 lilysex_046 with d
lily "Let me look at you." id ep5_17_lilysex_loop1_0af6ded9


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_047_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_047_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_047 with d
simon "(Wow, this is big.)" id ep5_17_lilysex_loop1_9cf8bdec
simon "(Last time, she barely wanted to look me in the eye.)" id ep5_17_lilysex_loop1_e9d86aad
simon "(The fact that we're face-to-face like this is a huge deal!)" id ep5_17_lilysex_loop1_9dbb2a5a
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_048_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_048_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_048 with d
lily "Oh... [name]..." id ep5_17_lilysex_loop1_5c4a348f
lily "It's so big..." id ep5_17_lilysex_loop1_d7946e0c
lily "It fills me up inside." id ep5_17_lilysex_loop1_e5645243
lily "Don't stop until I cum, [name]!" id ep5_17_lilysex_loop1_62e3caa7
simon "I won't, Lily!" id ep5_17_lilysex_loop1_125858f8
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_049_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_049_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_049 with d
simon "I know you love the feeling of my cock deep inside you." id ep5_17_lilysex_loop1_57affbcb
lily "Yes! I love it!" id ep5_17_lilysex_loop1_1b137339
simon "So, cum while I'm inside you, Lily!" id ep5_17_lilysex_loop1_81cdc17a
simon "Cum for me!" id ep5_17_lilysex_loop1_2cbfdedc
lily "I'm going to cum!" id ep5_17_lilysex_loop1_7d8f7967
pause

stop foley
stop voicefx
show ep5 lilysex_050 with d
lily "[name], I'm going to..." id ep5_17_lilysex_loop1_550fd204
show ep5 lilysex_050_1 with hpunch
pause 0.2
show ep5 lilysex_050_1 with hpunch
pause 0.2
show ep5 lilysex_050_1 with hpunch
pause 0.2
lily "Aaaaahhh..." id ep5_17_lilysex_loop1_7bf31d17
show ep5 lilysex_051 with d
lily "That was great..." id ep5_17_lilysex_loop1_3fc89e20
lily "I feel like I've been reborn." id ep5_17_lilysex_loop1_1cbc9686
show ep5 lilysex_052 with d
simon "Great doesn't even begin to describe it." id ep5_17_lilysex_loop1_e6e07845
show ep5 lilysex_053 with d
lily "Yes, but now I'm thinking..." id ep5_17_lilysex_loop1_f94b822e
lily "You didn't cum." id ep5_17_lilysex_loop1_c4f03275
lily "And I still know my name." id ep5_17_lilysex_loop1_7638f40a
show ep5 lilysex_054 with d
simon "So we have to keep going." id ep5_17_lilysex_loop1_84c7484c
show ep5 lilysex_052 with d
lily "So we have to keep going." id ep5_17_lilysex_loop1_16a64c20
show ep5 lilysex_055 with d
lily "Maybe you haven't played with them enough yet." id ep5_17_lilysex_loop1_14a9b18e
lily "I know they always make you happy." id ep5_17_lilysex_loop1_c289d89f
show ep5 lilysex_056 with d
lily "Do you want to fuck my tits again, [name]?" id ep5_17_lilysex_loop1_de236e8a
show ep5 lilysex_057 with d
lily "Come here." id ep5_17_lilysex_loop1_7250bafb
show ep5 lilysex_058 with d
simon "Lily..." id ep5_17_lilysex_loop1_af3774f1
show ep5 lilysex_059 with d
simon "I'll never say no to something like that." id ep5_17_lilysex_loop1_d14d0d88
show ep5 lilysex_060 with d
lily "That's what I like to hear." id ep5_17_lilysex_loop1_47d7fe7f


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_061_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_061_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_061 with d
lily "I know you dream of fucking these tits every night." id ep5_17_lilysex_loop1_f1fb03dd
simon "I can't say the thought hasn't crossed my mind." id ep5_17_lilysex_loop1_1a8093cf
simon "I haven't forgotten the last time." id ep5_17_lilysex_loop1_f3ffd9e7
simon "But you seemed quite timid that time." id ep5_17_lilysex_loop1_5ecc420c
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_062_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_062_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_062 with d
simon "(Oh, right... We did do something similar last time...)" id ep5_17_lilysex_loop1_cf5ac55e
simon "(Now that I'm thinking about it...)" id ep5_17_lilysex_loop1_5cdf42e0
simon "(The biggest problem I had was her not looking me in the eye.)" id ep5_17_lilysex_loop1_019bba47
simon "(She got weird after the kiss!)" id ep5_17_lilysex_loop1_bc4889c8
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_063_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_063_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_063 with d
simon "(But this time, she's the one kissing me.)" id ep5_17_lilysex_loop1_af84919b
lily "What is it, [name]?" id ep5_17_lilysex_loop1_ed270923
simon "Nothing." id ep5_17_lilysex_loop1_0cf14254
simon "In fact, everything's good." id ep5_17_lilysex_loop1_98b1fea7
simon "I'm so glad to see you like this." id ep5_17_lilysex_loop1_6499067c
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_064_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_064_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_064 with d
lily "And speaking of feeling good..." id ep5_17_lilysex_loop1_a3f18ed9
lily "Don't you have something you'd like to give me?" id ep5_17_lilysex_loop1_f69ed998
simon "(Getting distracted helps me last longer, but oh god...)" id ep5_17_lilysex_loop1_56121f93
simon "(Who can resist those tits?!)" id ep5_17_lilysex_loop1_1b5fe22f
simon "I'm almost there, Lily..." id ep5_17_lilysex_loop1_6b2a4c64
pause

stop foley
stop voicefx
show ep5 lilysex_065 with d
lily "Yeah?" id ep5_17_lilysex_loop1_f1e3575a
lily "You can cum if you want, [name]!" id ep5_17_lilysex_loop1_644cacbe
show ep5 lilysex_066 with d
lily "Or..." id ep5_17_lilysex_loop1_798bf4ff
show ep5 lilysex_067_1 with d
lily "You can keep fucking me to your heart's desire..." id ep5_17_lilysex_loop1_29deed86
show ep5 lilysex_066_1 with d
lily "My holes..." id ep5_17_lilysex_loop1_34efc845
show ep5 lilysex_067 with d
lily "... Or my tits." id ep5_17_lilysex_loop1_0fb7ffd9
lily "I know the thing that's going to drive me crazy is seeing your semen all over me." id ep5_17_lilysex_loop1_6ce4c116
show ep5 lilysex_068 with d
simon "This is already driving me crazy, Lily." id ep5_17_lilysex_loop1_c5e0a1b1
show ep5 lilysex_069 with d
lily "And there's more..." id ep5_17_lilysex_loop1_2eded4ef
lily "I don't care if you do have all those girlfriends at college." id ep5_17_lilysex_loop1_884ef415
show ep5 lilysex_069_1 with d
lily "They wouldn't do this for you." id ep5_17_lilysex_loop1_2bea4bab
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_070_var3_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_070_var3_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_070_var3 with d
lily "Mmmmm." id ep5_17_lilysex_loop1_3e599d74
lily "I'm sure they wouldn't be up for it." id ep5_17_lilysex_loop1_df8faf22
pause
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_070_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_070_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_070 with d
lily "But I love it." id ep5_17_lilysex_loop1_f2972277
lily "I can't wait to fit your whole cock..." id ep5_17_lilysex_loop1_5c373bd4
lily "In my tight..." id ep5_17_lilysex_loop1_87786c21
lily "Little..." id ep5_17_lilysex_loop1_517c3c06

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_070_var2_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_070_var2_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_070_var2 with d
lily "Asshole." id ep5_17_lilysex_loop1_184ff19a
simon "Wow... Are you sure?" id ep5_17_lilysex_loop1_09a3e719
lily "I said I'd be the best fuck of your life." id ep5_17_lilysex_loop1_79f3a7f8
pause
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_070_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_070_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_070_var1 with d
lily "It has to be complete." id ep5_17_lilysex_loop1_75100d9f
lily "From that look of surprise, I guess it's true your girlfriends don't give this to you." id ep5_17_lilysex_loop1_9ab8c49d
lily "In the end, experience will always speak loudest." id ep5_17_lilysex_loop1_65ce22f4
lily "Go ahead." id ep5_17_lilysex_loop1_1f5c9f20
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_074_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_074_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_074 with d
lily "Mmmm..." nointeract
pause 80/20


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_075_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_075_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_075 with d
lily "Ah, just like that..." id ep5_17_lilysex_loop1_f730aa00
simon "Should I keep going?" id ep5_17_lilysex_loop1_41eedb6b
lily "Yes..." id ep5_17_lilysex_loop1_857ad0a1
simon "College girls don't even come close." id ep5_17_lilysex_loop1_a50d1702
simon "In fact, I think they could learn a thing or two from you." id ep5_17_lilysex_loop1_42d632fb
lily "Oh, you want me to teach them? Is that it?" id ep5_17_lilysex_loop1_9b048af5
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_076_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_076_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_076 with d
lily "Can't your girlfriends keep up with you, [name]?" id ep5_17_lilysex_loop1_224592db
lily "Can't they tame that big cock of yours?" id ep5_17_lilysex_loop1_a6474a29
simon "Well... sometimes they voice a few complaints..." id ep5_17_lilysex_loop1_084ee139
lily "I could understand a few of them..." id ep5_17_lilysex_loop1_bdf21283
lily "But that's a good problem to have." id ep5_17_lilysex_loop1_152f392a
lily "No one should complain about your dick being too big." id ep5_17_lilysex_loop1_de239db9
pause


$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_lilysex_077_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_lilysex_077_foley fadein 0.5 fadeout 0.5
show ep5 anim_lilysex_077 with d
simon "I certainly don't have any complaints." id ep5_17_lilysex_loop1_abcd3506
lily "Good. Because it's just the way I like it." id ep5_17_lilysex_loop1_7234c77f
lily "I think you're actually going to fuck me until I forget my name..." id ep5_17_lilysex_loop1_d72a62fe
simon "What makes you say that? Can't you tame my cock?" id ep5_17_lilysex_loop1_c4a8e7fe
lily "I could do this all day." id ep5_17_lilysex_loop1_e885d9b0
lily "But you've got to climax, [name]." id ep5_17_lilysex_loop1_a28f94f6
pause

menu:
    "Tits":
        $ save("ep5_lilysex_enjoy_in_the_breasts")
        stop foley
        stop voicefx
        show ep5 lilysex_060 with d
        simon "I want to cum on your tits, Lily." id ep5_17_lilysex_loop1_8d15dddb


        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_061_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_061_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_061 with d
        lily "I knew you'd pick them." id ep5_17_lilysex_loop1_401f28b1
        lily "I know how you feel about my girls." id ep5_17_lilysex_loop1_cc702b02
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_063_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_063_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_063 with d
        lily "Cum on my tits for me, [name]." id ep5_17_lilysex_loop1_37976c0a
        lily "Cum for me!" id ep5_17_lilysex_loop1_eb359e94
        stop foley
        stop voicefx
        show ep5 lilysex_079 with hpunch
        pause 0.2
        show ep5 lilysex_079 with hpunch
        pause 0.2
        show ep5 lilysex_079 with hpunch
        simon "Aaaaahhh..." id ep5_17_lilysex_loop1_2831e6a9
        lily "Mmmmm... I love it!" id ep5_17_lilysex_loop1_b569f20b
    "Ass":

        $ save("ep5_lilysex_cum_in_the_ass")
        simon "Since you insist..." id ep5_17_lilysex_loop1_3096e92f
        simon "I want to cum..." id ep5_17_lilysex_loop1_ab5bfd06
        simon "... inside your ass." id ep5_17_lilysex_loop1_bd2335ef

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_075_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_075_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_075 with d



        lily "Mmm... What a great idea." id ep5_17_lilysex_loop1_73794191
        simon "You said you could handle it..." id ep5_17_lilysex_loop1_b52425e2
        simon "Now it's time to prove it." id ep5_17_lilysex_loop1_50745953
        lily "Yes! YES!" id ep5_17_lilysex_loop1_866e70b8
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_076_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_076_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_076 with d
        lily "Fuck my asshole, [name]!" id ep5_17_lilysex_loop1_ad2c5040
        lily "Cum in my ass!" id ep5_17_lilysex_loop1_e7fbc593
        stop foley
        stop voicefx
        show ep5 lilysex_080 with d
        simon "Aaaaahhh!" id ep5_17_lilysex_loop1_3ac127a4
        show ep5 lilysex_081 with hpunch
        pause 0.2
        show ep5 lilysex_081 with hpunch
        pause 0.2
        show ep5 lilysex_081 with hpunch
        pause 0.2
        lily "Ahhh...yes..." id ep5_17_lilysex_loop1_f7cfcd6f
    "Pussy":

        $ save("ep5_lilysex_come_in_the_pussy")
        simon "Come here." id ep5_17_lilysex_loop1_08ebc8ff
        simon "Let me give you a creampie." id ep5_17_lilysex_loop1_e791a60c
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_047_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_047_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_047 with d
        play sound placeholder volume 0.4



        lily "Always a good choice." id ep5_17_lilysex_loop1_62e1b763
        lily "Another chance to fuck me more, [name]!" id ep5_17_lilysex_loop1_6d72f491
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_048_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_048_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_048 with d
        lily "Fuck me!" id ep5_17_lilysex_loop1_14d51ae0
        lily "Fill me with your cum!" id ep5_17_lilysex_loop1_d0016031
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_lilysex_049_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_lilysex_049_foley fadein 0.5 fadeout 0.5
        show ep5 anim_lilysex_049 with d
        lily "Give me everything!" id ep5_17_lilysex_loop1_1d4e9ec9
        simon "Lily, I'm gonna..." id ep5_17_lilysex_loop1_1947b91c
        stop foley
        stop voicefx
        show ep5 lilysex_082 with hpunch
        pause 0.2
        show ep5 lilysex_082 with hpunch
        pause 0.2
        show ep5 lilysex_082 with hpunch
        pause 0.2
        simon "Aaaaahhhh..." id ep5_17_lilysex_loop1_7f9f5fcf
        show ep5 lilysex_083 with d
        lily "Aaahhh... there you go..." id ep5_17_lilysex_loop1_1d216a23

$ debug_other_path()

play sound body_fall_mat8 volume 0.7 
show ep5 lilysex_084 with d
simon "Wow..." id ep5_17_lilysex_loop1_063ea2e3
$ renpy.end_replay()
lily "Wow indeed..." id ep5_17_lilysex_loop1_35696a10
show ep5 lilysex_085 with d
simon "Is this when I should look out the window and think your husband has arrived?" id ep5_17_lilysex_loop1_9e29383a
stop music fadeout 3
show ep5 lilysex_086 with d
lily "Former husband." id ep5_17_lilysex_loop1_59abf437
show ep5 lilysex_087 with d
simon "I wonder what he'd do if he saw us here." id ep5_17_lilysex_loop1_503ccf6f
simon "Honestly, the thought scares me." id ep5_17_lilysex_loop1_fd5c573d

play sound bed_movement_6 volume 0.4 
show ep5 lilysex_088 with d
lily "Don't worry, [name]." id ep5_17_lilysex_loop1_61227482
lily "Sam likes to threaten, but he can't do anything about it." id ep5_17_lilysex_loop1_c64fbaec
show ep5 lilysex_089 with d
simon "I wouldn't be so sure." id ep5_17_lilysex_loop1_77937197
simon "He did something to my father. I know that." id ep5_17_lilysex_loop1_0f935058
show ep5 lilysex_090 with d
lily "I don't know, [name]..." id ep5_17_lilysex_loop1_84bdeb88
lily "Sam is many things, but I don't think he'd do something like that." id ep5_17_lilysex_loop1_68328e27
show ep5 lilysex_091 with d
simon "What do you mean by \"something like that\" exactly?" id ep5_17_lilysex_loop1_47b35b21
simon "What is that supposed to mean, Lily?" id ep5_17_lilysex_loop1_4c9f6043
show ep5 lilysex_092 with d
lily "Well, your father disappeared a long time ago." id ep5_17_lilysex_loop1_77424d96
lily "I'm sorry to say this, but I don't think he's around anymore." id ep5_17_lilysex_loop1_131df90d
lily "That's what I meant... I don't think Sam would do something like that to anyone." id ep5_17_lilysex_loop1_d5700772
show ep5 lilysex_093 with d
simon "You don't think he'd do it?!" id ep5_17_lilysex_loop1_12fad3e6
show ep5 lilysex_093_1 with d
simon "He threatened me!" id ep5_17_lilysex_loop1_a504d961
show ep5 lilysex_094 with d
lily "Yes. Because of the things you said to him." id ep5_17_lilysex_loop1_f8e44d27
show ep5 lilysex_095 with d
simon "Why are you taking his side in this?" id ep5_17_lilysex_loop1_46666a8a
show ep5 lilysex_096 with d
lily "I'm not." id ep5_17_lilysex_loop1_ad1328ff
show ep5 lilysex_097 with hpunch
play sound body_fall_mat8 volume 0.7
lily "Where are you going?" id ep5_17_lilysex_loop1_69f0ca9d
show ep5 lilysex_098 with d
simon "I'm leaving." id ep5_17_lilysex_loop1_761731d4
show ep5 lilysex_099 with d
simon "Coming here was a bad idea." id ep5_17_lilysex_loop1_facb502c
show ep5 lilysex_099_1 with hpunch
play sound door_thud volume 0.7
lily "[name]..." id ep5_17_lilysex_loop1_7b847b4c

jump ep5_18_afterlily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
