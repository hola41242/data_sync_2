
label ep5_05_chloeday:

    show black as ep5 with Dissolve(1)
    pause 1
    play music hard_wired fadein 2 volume 0.3
    show ep5 chloeday_001 with Dissolve(2)
    chloe "[name]?" id ep5_05_chloeday_18c24156
    show black as ep5 with fast_fade
    pause 0
    show ep5 chloeday_002 with Dissolve(1)
    simon "What...?" id ep5_05_chloeday_e3927361
    show ep5 chloeday_003 with d
    simon "Oh. Good morning, Chloe." id ep5_05_chloeday_b761f115
    simon "You're up early." id ep5_05_chloeday_c2604847
    show ep5 chloeday_004 with d
    chloe "Yep, and I'm still surprised you just conked out right after you arrived." id ep5_05_chloeday_d03e5cfa
    show ep5 chloeday_005 with d
    chloe "It must have been a lot for you to process all at once." id ep5_05_chloeday_83f8b360
    show ep5 chloeday_006 with d
    chloe "Your mind must have short-circuited." id ep5_05_chloeday_6156b77e
    show ep5 chloeday_007 with d
    simon "It must have." id ep5_05_chloeday_12c39309
    simon "We barely had a chance to talk things through." id ep5_05_chloeday_0e7036f5
    show ep5 chloeday_008 with d
    simon "Sorry about that." id ep5_05_chloeday_7c4267e5
    show ep5 chloeday_009 with d
    chloe "It's okay. You looked exhausted." id ep5_05_chloeday_888eb86e
    show ep5 chloeday_010 with d
    chloe "So, uh, breakfast?" id ep5_05_chloeday_f2b20259
    show ep5 chloeday_011 with d
    simon "Oooh. That sounds nice."
    show ep5 chloeday_012 with d
    chloe "I did my best for my special guest." id ep5_05_chloeday_d81136dd
    show ep5 chloeday_013 with d
    simon "Thanks, Chloe." id ep5_05_chloeday_325aff69
    simon "I hope I'm not causing you too much trouble." id ep5_05_chloeday_e4709c8e


    show ep5 chloeday_013_2 with d
    chloe "Not at all!" id ep5_05_chloeday_330cf1a5
    show ep5 chloeday_014 with d
    chloe "Here." id ep5_05_chloeday_67d342eb
    chloe "You should eat something." id ep5_05_chloeday_fac09a5d
    show ep5 chloeday_015 with d
    chloe "Since I got up early, I decided to make breakfast." id ep5_05_chloeday_cf20f5cc
    chloe "Then I did some digging." id ep5_05_chloeday_a08d63b8
    show ep5 chloeday_016 with d
    simon "Wow, you didn't have to do all that." id ep5_05_chloeday_4b15e7b6
    simon "Thanks though." id ep5_05_chloeday_e55875bf
    show ep5 chloeday_017 with d
    chloe "It's the least I could do." id ep5_05_chloeday_805a6b78
    show ep5 chloeday_018 with d
    chloe "Ever since the bear attack, I've had this weird feeling." id ep5_05_chloeday_9a7c87be
    show ep5 chloeday_019 with d
    chloe "It was scary, and then funny, and then... well..." id ep5_05_chloeday_2ea8b196

    if choice_made('ep4_university_its_fine'):
        show ep5 chloeday_020 with d
        simon "We've been through this." id ep5_05_chloeday_46e94707
        simon "Everything's fine." id ep5_05_chloeday_bab395a1
        show ep5 chloeday_021 with d
        chloe "I know, but..." id ep5_05_chloeday_828c2ad3

    show ep5 chloeday_022 with d
    simon "(It doesn't seem like she slept a wink.)" id ep5_05_chloeday_da5784ca
    simon "(She must've been up all night thinking about this.)" id ep5_05_chloeday_85453fef
    show ep5 chloeday_023 with d
    chloe "After all that, I needed to find something to focus on." id ep5_05_chloeday_667dfbc5
    chloe "So I returned to my investigation." id ep5_05_chloeday_3d8560d8
    play sound keyboard
    show ep5 chloeday_024 with d
    chloe "But it was unsuccessful." id ep5_05_chloeday_c142c2ce
    chloe "This Emily girl has almost no online presence." id ep5_05_chloeday_0486ad95
    show ep5 chloeday_025 with d
    chloe "But take a look at this." id ep5_05_chloeday_3ce44bd1
    show ep5 chloeday_026 with d
    simon "What is it?" id ep5_05_chloeday_da31dd9d
    show ep5 chloeday_027 with d
    chloe "It's the guest list for the charity ball." id ep5_05_chloeday_9ad5051c
    show ep5 chloeday_028 with d
    chloe "And look who's on it." id ep5_05_chloeday_e80df3d0
    show ep5 chloeday_029 with d
    simon "Emily." id ep5_05_chloeday_afc4a704
    show ep5 chloeday_030 with d
    simon "Wait, how'd you get your hands on that?" id ep5_05_chloeday_068ce121
    show ep5 chloeday_031 with d
    chloe "I'm a good detective, remember?" id ep5_05_chloeday_ab99fdf8
    show ep5 chloeday_032 with d


    simon "You really are." id ep5_05_chloeday_8d7abc66

    if choice_made('ep3_07_cafe2_agree_to_help'):
        show ep5 chloeday_033 with d
        simon "Alyssa's dance group is also on the list." id ep5_05_chloeday_2a2649b0
        show ep5 chloeday_034 with d
        simon "I'm going to go there with them and find out what I can about my father." id ep5_05_chloeday_09228930
        show ep5 chloeday_035 with d
        chloe "Wow, then you're our inside man now!" id ep5_05_chloeday_6532695e
        chloe "How exciting!" id ep5_05_chloeday_2fb1c4e9
        show ep5 chloeday_036 with d
        simon "I hope it works." id ep5_05_chloeday_dbc3b2f9
    else:

        show ep5 chloeday_037 with d
        simon "Is there any way you can put me on that list?" id ep5_05_chloeday_81dfccf6
        show ep5 chloeday_038 with d
        chloe "Um... I can try." id ep5_05_chloeday_95389262
        chloe "But it won't be easy." id ep5_05_chloeday_6e2960ba
        chloe "Susan's probably got a list printed out, and that would be the official one." id ep5_05_chloeday_daf3baa5
        show ep5 chloeday_039 with d
        chloe "If you can get your hands on that list, I might be able to help you out." id ep5_05_chloeday_9ec03311

        if not (not choice_made('ep2_sue_stop') and not choice_made_skip_debug('ep4_susanhome_suespy1') and not choice_made_skip_debug('ep4_susanhome_suespy2')):
            show ep5 chloeday_040 with d
            simon "I can check with Sue." id ep5_05_chloeday_4f97db4f
            simon "Maybe she can help." id ep5_05_chloeday_11255091
            show ep5 chloeday_041 with d
            chloe "That would work!" id ep5_05_chloeday_baccdfc0
        else:

            if choice_made ('ep4_susanhome_accept_the_job'):
                show ep5 chloeday_040 with d
                simon "Susan asked me to make a delivery on the day of the ball, so I'll have to drop by there anyway. Maybe I can find something while I'm there?" id ep5_05_chloeday_d344edca
                show ep5 chloeday_041 with d
                chloe "Sounds like a plan!" id ep5_05_chloeday_012b5c7c
            else:

                show ep5 chloeday_042 with d
                simon "I don't know... Sue and I aren't exactly on good terms right now." id ep5_05_chloeday_62a06b4a
                simon "And I don't think Susan wants to see my face." id ep5_05_chloeday_6a190fe0
                show ep5 chloeday_043 with d
                chloe "I understand." id ep5_05_chloeday_c79d8c71
                chloe "In that case, I'll see what I can do." id ep5_05_chloeday_0737a2a5


            $ debug_other_path()


        $ debug_other_path()


    $ debug_other_path()

    show ep5 chloeday_044 with d
    simon "Anyway, I think it's time we headed to class, no?" id ep5_05_chloeday_d078d74d
    show ep5 chloeday_045 with d
    chloe "Oh, that's right!" id ep5_05_chloeday_e31d319f
    show ep5 chloeday_046 with d
    chloe "Do you know how to get there from here?" id ep5_05_chloeday_0b4351a8
    chloe "I'll meet up with you later." id ep5_05_chloeday_b2b03c76
    show ep5 chloeday_047 with d
    simon "Yeah. That's cool." id ep5_05_chloeday_70986d93
    simon "See you later, Chloe." id ep5_05_chloeday_8a7f176d

    jump ep5_08_universitydylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
