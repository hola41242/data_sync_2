label ep5_23_juliasex:






simon "Are you sure you're ready?" id ep5_23_juliasex_7567a521
show ep5 juliasex_002 with d
julia "Yup. I've been waiting for this moment for a long time." id ep5_23_juliasex_67389704
julia "And besides... I trust you." id ep5_23_juliasex_6ca7954c
play sound lock volume 0.7
show ep5 juliasex_003 with d
julia "Let's just make sure no one interrupts us this time." id ep5_23_juliasex_0792b585
simon "Good idea." id ep5_23_juliasex_9a3ac949
show ep5 juliasex_004 with d
julia "So..." id ep5_23_juliasex_83c31150
show ep5 juliasex_005 with d
simon "Come here." id ep5_23_juliasex_08ebc8ff
show ep5 juliasex_006 with d
simon "No need to be nervous." id ep5_23_juliasex_48b40d72
simon "I promise you, this night will be special." id ep5_23_juliasex_01c852b9
show ep5 juliasex_007 with d
julia "I know it will be." id ep5_23_juliasex_2063092b
play music [new_old_fashioned, heart_made_of_pixels] volume 0.4
play sound dress_shirt volume 0.7
show ep5 juliasex_008 with d
simon "And since we want to continue where we left off..." id ep5_23_juliasex_59448ec5
show ep5 juliasex_009 with d
julia "[name]...!" id ep5_23_juliasex_e6f2f513
show ep5 juliasex_010 with d
simon "You're beautiful." id ep5_23_juliasex_3e0ee19a
show ep5 juliasex_011 with d
simon "No need to be shy." id ep5_23_juliasex_ab27a917
play sound bed volume 0.5
show ep5 juliasex_012 with d
simon "Over here." id ep5_23_juliasex_0ba1c277
play sound bed volume 0.2
show ep5 juliasex_013 with d
julia "Here?" id ep5_23_juliasex_28970378
show ep5 juliasex_014 with d
simon "(I'd better get her turned on first.)" id ep5_23_juliasex_e7066e57
show ep5 juliasex_015 with d
simon "(And I know one thing she likes.)" id ep5_23_juliasex_0a3d21e3
show ep5 juliasex_016 with d
julia "[name]..."
show ep5 juliasex_017 with d
simon "Do you like that?" id ep5_23_juliasex_ce26935a
show ep5 juliasex_018 with d
julia "Yes." id ep5_23_juliasex_d1e1e790
julia "Keep going." id ep5_23_juliasex_cd564ac6
show ep5 juliasex_019 with d
julia "Ah!" id ep5_23_juliasex_6584bc6c
simon "Do you want me to go further?" id ep5_23_juliasex_2eaccaa0
julia "Yes..." id ep5_23_juliasex_4e619f92
show ep5 juliasex_020 with d
simon "Then I'll go all the way down." id ep5_23_juliasex_33cbd76a
show ep5 juliasex_021 with d
julia "Wait..."
show ep5 juliasex_022 with d
simon "Did I do something wrong?" id ep5_23_juliasex_f789bd75
show ep5 juliasex_023 with d
julia "No... it's just... I want you to take off your shorts before I take off my bottoms." id ep5_23_juliasex_6545a50f
show ep5 juliasex_022 with d
simon "Oh, of course!" id ep5_23_juliasex_a81e241b
simon "I should have thought of that myself." id ep5_23_juliasex_2b81b1c0
play sound taking_pants_off volume 0.7
show ep5 juliasex_024 with d
simon "So?" id ep5_23_juliasex_98c878ca
show ep5 juliasex_025 with d
julia "It's so big..." id ep5_23_juliasex_7dce007b
show ep5 juliasex_026 with d
julia "This is the first good look I'm getting of it."
show ep5 juliasex_027 with d
simon "What do you want to do?" id ep5_23_juliasex_e343c555
show ep5 juliasex_028 with d
julia "I want to do this." id ep5_23_juliasex_8222b4fe

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_029_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_029_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_029 with d
julia "How does this feel?" id ep5_23_juliasex_4df14f87
simon "It's... It's really good." id ep5_23_juliasex_6555e84e
julia "It's so big. I don't know if it'll fit." id ep5_23_juliasex_c6a54e7d
simon "Fit?" id ep5_23_juliasex_24a2ea0e
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_029_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_029_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_029_var1 with d
julia "Yeah, you know..." id ep5_23_juliasex_51587086
simon "It's okay. We'll take it slow..." id ep5_23_juliasex_0dd9b3f0
julia "Good to know." id ep5_23_juliasex_dd6d0581
pause

stop foley
stop voicefx
show ep5 juliasex_030 with d
simon "Just relax and leave it all to me." id ep5_23_juliasex_473e32f1
show ep5 juliasex_031 with d
julia "No..." id ep5_23_juliasex_9aab642e
play sound bed_movement_1 volume 0.5
show ep5 juliasex_032 with d
julia "I want to stay on top." id ep5_23_juliasex_ff07035a

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_033_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_033_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_033 with d
simon "I don't see any problem with that..." id ep5_23_juliasex_58533e08
julia "This way, I feel like I'll have more control." id ep5_23_juliasex_88d4fdeb
julia "And it'll feel better." id ep5_23_juliasex_64388e57
pause
$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_033_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_033_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_033_var1 with d
julia "Ahhhh." id ep5_23_juliasex_70950ea7
julia "It's so good." id ep5_23_juliasex_c7e920b5
simon "Don't you want to take off your bottoms?" id ep5_23_juliasex_0f346e3f
julia "Are you in a rush, Twinkle Toes?" id ep5_23_juliasex_8c632bcb
pause

stop foley
stop voicefx
show ep5 juliasex_034 with d
julia "But you're right. I said I would." id ep5_23_juliasex_90128434
show ep5 juliasex_035 with d
julia "Done." id ep5_23_juliasex_14a141d1

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_038_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_038_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_038 with d
julia "I can feel you." id ep5_23_juliasex_5f218f46
simon "I feel you too..." id ep5_23_juliasex_0572bda9
simon "You're so wet." id ep5_23_juliasex_f0795e00
julia "(I can't believe we've finally made it this far!)" id ep5_23_juliasex_2ce44179
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_037_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_037_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_037 with d
julia "This feels so good." id ep5_23_juliasex_c2caddd5
julia "Do you like it too?" id ep5_23_juliasex_c32c894b
simon "It feels amazing, Julia." id ep5_23_juliasex_36199826
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_036_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_036_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_036 with d
julia "I feel like I'm almost ready." id ep5_23_juliasex_88370882
simon "Take as much time as you need."
julia "But I don't want you inside me just yet." id ep5_23_juliasex_f3252c31
simon "Oh, you don't?" id ep5_23_juliasex_52df93d3
julia "There are a few things I want to do first." id ep5_23_juliasex_4c991c61
pause

stop foley
stop voicefx
show ep5 juliasex_039 with d
simon "I like the sound of that." id ep5_23_juliasex_69c27ab4
simon "Do what you've got to do." id ep5_23_juliasex_e6237e5b

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_040_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_040_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_040 with d
julia "Am I doing this right?" id ep5_23_juliasex_6016c4c7
simon "Oh yeah. Definitely." id ep5_23_juliasex_9b2937c8
julia "Great..." id ep5_23_juliasex_eb2fbd70
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_041_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_041_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_041 with d
julia "I've been dreaming of this moment." id ep5_23_juliasex_8f4cf1af
simon "Me too." id ep5_23_juliasex_12381f24
simon "Is it managing to live up to those dreams?" id ep5_23_juliasex_6e2539a3
julia "It's even better." id ep5_23_juliasex_24bcbdae
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_042_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_042_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_042 with d
simon "Julia..." id ep5_23_juliasex_f1758854
julia "Am I doing this right?" id ep5_23_juliasex_a39b75fe
simon "Yeah... Maybe a bit less teeth." id ep5_23_juliasex_901adc93
julia "Sorry... I'm still kind of new to this." id ep5_23_juliasex_9d86ff16
julia "I always wanted to know what it tasted like." id ep5_23_juliasex_c94f8a83
simon "You're doing a great job..." id ep5_23_juliasex_c89f4446
pause

stop foley
stop voicefx
show ep5 juliasex_043 with d
simon "Please don't stop..." id ep5_23_juliasex_f6592b5a
show ep5 juliasex_044 with d
julia "[name]..."
play sound bed_movement_6 volume 0.3
show ep5 juliasex_045 with d
simon "What is it?"
show ep5 juliasex_046 with d
julia "I don't know what else I should do." id ep5_23_juliasex_9d4c9d5d
show ep5 juliasex_047 with d
simon "Don't worry..." id ep5_23_juliasex_1418825b
simon "Like I said before, leave it to me." id ep5_23_juliasex_3a45a6af
show ep5 juliasex_046 with d
julia "I'm a little nervous..." id ep5_23_juliasex_f04308d0
show ep5 juliasex_048 with d
simon "Here's what we can do." id ep5_23_juliasex_88bfaa7c
simon "I'll take the lead, and we can use a few code words." id ep5_23_juliasex_7ab561f7
simon "You say green if it's good and say red if you want me to stop." id ep5_23_juliasex_9699b069
show ep5 juliasex_049 with d
julia "I like that!" id ep5_23_juliasex_6f0a2f8f
julia "Just like a traffic light." id ep5_23_juliasex_19fb87a1
show ep5 juliasex_048 with d
simon "Exactly." id ep5_23_juliasex_cc2b519d
show ep5 juliasex_050 with d
simon "Let's start with this..." id ep5_23_juliasex_5e530605

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_051_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_051_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_051 with d
julia "[name]..."
simon "What?" id ep5_23_juliasex_708b4972
julia "Nothing... Green. Go, go, go." id ep5_23_juliasex_f3a21d09
simon "Got you." id ep5_23_juliasex_855960f6
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_052_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_052_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_052 with d
simon "I hope I don't run into any red lights." id ep5_23_juliasex_ffde165c
julia "Everything's peachy so far..." id ep5_23_juliasex_12007fe0
simon "Then you're telling me to go further?" id ep5_23_juliasex_10ee08ea
julia "Yes! Green, green!" id ep5_23_juliasex_cd4ed725
pause

show ep5 juliasex_053 with d
julia "I feel like I'm ready." id ep5_23_juliasex_2e7603c2
show ep5 juliasex_054 with d
simon "Then let's start like this..." id ep5_23_juliasex_ecdad718

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_055_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_055_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_055 with d
julia "You haven't put it in yet." id ep5_23_juliasex_cb025513
simon "Relax. I'm playing with you a little more." id ep5_23_juliasex_827ff00c
julia "But I want it so bad..." id ep5_23_juliasex_86970b8f
pause

stop foley
stop voicefx
show ep5 juliasex_056 with d
simon "Then give me a color." id ep5_23_juliasex_8264f156
julia "Green." id ep5_23_juliasex_e032ac7c
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_057_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_057_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_057 with d
simon "I'm going to start real slow." id ep5_23_juliasex_923f4382
julia "I'm ready." id ep5_23_juliasex_becec871
simon "I'll start with just the tip." id ep5_23_juliasex_313e603c
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_058_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_058_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_058 with d
julia "Wait... Yellow." id ep5_23_juliasex_242c760e
simon "Yellow? What does that mean?" id ep5_23_juliasex_7b9f9ce0
julia "It's like a traffic light, remember?" id ep5_23_juliasex_ba66a0eb
simon "Do you want me to pull it out then?" id ep5_23_juliasex_a851f408
julia "No, just leave it like that for a second." id ep5_23_juliasex_25738e21
simon "Gotcha." id ep5_23_juliasex_35d28843
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_058_var1_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_058_var1_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_058_var1 with d
simon "Tell me when you're used to it." id ep5_23_juliasex_a4e84bff
julia "It's so big... but I'll manage..." id ep5_23_juliasex_c9b24d53
julia "Just hold on a little longer..." id ep5_23_juliasex_13fb30e6
simon "Take as much time as you need."
julia "Now!" id ep5_23_juliasex_7792cc77
julia "Green!" id ep5_23_juliasex_6f665adb
pause

stop foley
stop voicefx
show ep5 juliasex_059 with d
julia "Aaaah!" id ep5_23_juliasex_130a9ab9
show ep5 juliasex_060 with d
simon "Still green?" id ep5_23_juliasex_a2100de9
show ep5 juliasex_059 with d
julia "Green. Green!" id ep5_23_juliasex_64c3027b

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_062_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_062_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_062 with d
julia "Holy shit! I can't believe it's all the way inside of me!" id ep5_23_juliasex_5a100a13
simon "(It's only halfway in...)" id ep5_23_juliasex_7931f44f
simon "You're so tight." id ep5_23_juliasex_9c4616f9
julia "And you're sooo big..." id ep5_23_juliasex_d81f6955
julia "It feels good."
julia "I'm so happy." id ep5_23_juliasex_92fad12f
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_061_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_061_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_061 with d
simon "Can I go further in?" id ep5_23_juliasex_beeb76f0
julia "There's more?!" id ep5_23_juliasex_89dc9eec
simon "Just give me a color." id ep5_23_juliasex_8796dd1a
julia "Green, green... green!" id ep5_23_juliasex_dfa2a611
pause

stop foley
stop voicefx
show ep5 juliasex_063 with d
julia "Ooohhh!" id ep5_23_juliasex_96114531
show ep5 juliasex_064 with d
julia "I think I want to be on top now." id ep5_23_juliasex_3df396dd
show ep5 juliasex_065 with d
simon "Is everything okay?" id ep5_23_juliasex_b3474d79
show ep5 juliasex_066 with d
julia "Yeah, I just think it'll be easier that way." id ep5_23_juliasex_8df7a17f
julia "You can trust me." id ep5_23_juliasex_87d7d2fb
play sound bed_movement_6 volume 0.1
show ep5 juliasex_067 with d
simon "Are you sure?"
show ep5 juliasex_068 with d
julia "Yup." id ep5_23_juliasex_4468039b
show ep5 juliasex_069 with d
simon "Ohh..." id ep5_23_juliasex_c5c9bd2d

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_070_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_070_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_070 with d
julia "What was that for?" id ep5_23_juliasex_8b44d889
simon "Nothing... That just felt really good." id ep5_23_juliasex_4be54967
simon "Keep going." id ep5_23_juliasex_0b2eddb4
julia "Color?" id ep5_23_juliasex_7517b97c
simon "Oh, looks like the tables have turned..." id ep5_23_juliasex_fa8889cf
simon "Green!" id ep5_23_juliasex_0333325d
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_071_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_071_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_071 with d
julia "Now I'm the one in control." id ep5_23_juliasex_9c55c633
simon "How's that make you feel?" id ep5_23_juliasex_ec317a80
julia "So nice."
simon "Good to hear. I'll let you have a bit of control." id ep5_23_juliasex_631970fb
julia "Or we can always play co-op." id ep5_23_juliasex_8578a272

if config.developer:
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_juliasex_072_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_juliasex_072_foley fadein 0.5 fadeout 0.5
    show ep5 anim_juliasex_072 with d
simon "I like that idea!" id ep5_23_juliasex_9ded9be2
julia "[name]..."
simon "Yes?" id ep5_23_juliasex_34bf1b87
julia "I want to take it all the way in." id ep5_23_juliasex_798b329b
simon "Are you sure?"
pause

stop foley
stop voicefx
show ep5 juliasex_073 with d
julia "Yeah." id ep5_23_juliasex_a05bb39d
show ep5 juliasex_074 with d
julia "Mph!" id ep5_23_juliasex_82391efd
show ep5 juliasex_075 with d
simon "Are you okay?" id ep5_23_juliasex_30ddab2a
show ep5 juliasex_076 with d
julia "Yellow, but yes." id ep5_23_juliasex_cd686b89
julia "I'm fine." id ep5_23_juliasex_fd9b99f0

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_077_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_077_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_077 with d
julia "Oooooohhh, my god!" id ep5_23_juliasex_7c0675f0
simon "Oh yeah!" id ep5_23_juliasex_a067ea22
simon "Are you sure you can keep going?" id ep5_23_juliasex_6b433b93
julia "Purple!" id ep5_23_juliasex_52d99655
simon "What was that?" id ep5_23_juliasex_78cb84f6
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_078_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_078_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_078 with d
julia "Pink, white, blue..." id ep5_23_juliasex_5af19aae
julia "Squeeze my tits, [name]!" id ep5_23_juliasex_ef4400a6
simon "Is that what those colors mean?" id ep5_23_juliasex_f124f6f2
julia "None of that matters anymore!" id ep5_23_juliasex_58295dff
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_079_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_079_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_079 with d
simon "Your pussy feels like an oven." id ep5_23_juliasex_e6e21825
simon "Oh my god. This is so fucking great." id ep5_23_juliasex_ee4e8ea0
julia "Do you mean that?" id ep5_23_juliasex_4171c813
julia "Is it that good?" id ep5_23_juliasex_f87cc739
pause

$ allow_voicefx = False
if is_voice_installed:
    play voicefx ep5_anim_juliasex_080_voicefx fadein 0.5 fadeout 0.5
    play foley ep5_anim_juliasex_080_foley fadein 0.5 fadeout 0.5
show ep5 anim_juliasex_080 with d
simon "It's so good, I think I'm going to cum any second..." id ep5_23_juliasex_3cca32e8
julia "Really?" id ep5_23_juliasex_769ec150
julia "I'm gonna make you cum?" id ep5_23_juliasex_0cdf60c2
julia "This feels so good... I think I'm about to too..." id ep5_23_juliasex_423ff104
pause

stop foley
stop voicefx
show ep5 juliasex_081 with d
julia "Ahhhhhhh!" id ep5_23_juliasex_765f00bd
show ep5 juliasex_082 with d
julia "Ahh, ahh..." id ep5_23_juliasex_9d329ad4
julia "So... good..." id ep5_23_juliasex_b64716a0
show ep5 juliasex_083 with d
julia "Wait..."
julia "You... still... haven't cum..." id ep5_23_juliasex_811605d6
show ep5 juliasex_084 with d
julia "You want to cum on me, don't you?" id ep5_23_juliasex_3a4801c6
simon "(Of course I do!)" id ep5_23_juliasex_6f8e5faf
show ep5 juliasex_085 with d
julia "I know that in some videos, the guy likes to cum on the girl's face..." id ep5_23_juliasex_6e7ac2d1
show ep5 juliasex_086 with d
julia "Or breasts..." id ep5_23_juliasex_bd696db8
show ep5 juliasex_087 with d
julia "... Or other places." id ep5_23_juliasex_b8cc08e0
show ep5 juliasex_085 with d
julia "Do you want to do that with me, [name]?" id ep5_23_juliasex_766bd561
julia "Where do you want to cum?" id ep5_23_juliasex_ad26f4d1

menu:
    "Face":
        $ save("ep5_juliasex_face")
        show ep5 juliasex_088 with d
        simon "I want to cum on your face, Julia." id ep5_23_juliasex_ed811de0
        show ep5 juliasex_089 with d
        julia "I thought you might say that!" id ep5_23_juliasex_1299f778

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_juliasex_090_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_juliasex_090_foley fadein 0.5 fadeout 0.5
        show ep5 anim_juliasex_090 with d
        julia "Is it okay if I help you out a little?" id ep5_23_juliasex_55b5b2d5
        simon "Trust me. I won't need much." id ep5_23_juliasex_3ff88d12
        simon "I'm almost there..." id ep5_23_juliasex_b43408d1
        julia "Great!"
        julia "Then I'll stick out my tongue to catch a taste!" id ep5_23_juliasex_b05b4136
        pause

        stop foley
        stop voicefx
        show ep5 juliasex_091 with d
        julia "Let me know when you're there." id ep5_23_juliasex_e2de9c11
        julia "Aaahh..." id ep5_23_juliasex_17b9a54a
        simon "(My god!)" id ep5_23_juliasex_8549c9cc
        pause 0.2
        show ep5 juliasex_091 with vpunch
        pause 0.2
        show ep5 juliasex_091 with vpunch
        pause 0.2
        show ep5 juliasex_092 with vpunch
        simon "Aaaaaahhh!" id ep5_23_juliasex_69e4de4b
        julia "Aaah! So warm!" id ep5_23_juliasex_b697321a
        show ep5 juliasex_093 with d
        julia "You didn't warn me!" id ep5_23_juliasex_050add39
        simon "Sorry..." id ep5_23_juliasex_8cece15e
        julia "Relax. It tasted good." id ep5_23_juliasex_5ac93f5c
    "Breasts":

        $ save("ep5_juliasex_breasts")
        show ep5 juliasex_088 with d
        simon "I want to cum on your breasts." id ep5_23_juliasex_4c30834e
        show ep5 juliasex_089 with d
        julia "I figured that would be your choice." id ep5_23_juliasex_5f19ea71

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep5_anim_juliasex_094_voicefx fadein 0.5 fadeout 0.5
            play foley ep5_anim_juliasex_094_foley fadein 0.5 fadeout 0.5
        show ep5 anim_juliasex_094 with d
        julia "I know they aren't big..." id ep5_23_juliasex_ebed6670
        julia "... But I'll do my best." id ep5_23_juliasex_955c6b93
        simon "They're just right for me, Julia." id ep5_23_juliasex_b110d7db
        simon "The perfect size." id ep5_23_juliasex_618a14d1
        julia "Great!"
        simon "And they look even better when you play with them." id ep5_23_juliasex_81d7dc2c
        simon "My god. I think I'm gonna..." id ep5_23_juliasex_a4245caa
        pause

        stop foley
        stop voicefx
        show ep5 juliasex_095 with vpunch
        pause 0.2
        show ep5 juliasex_095 with vpunch
        pause 0.2
        show ep5 juliasex_095 with vpunch
        simon "Aaahhhh!" id ep5_23_juliasex_2df00bf8
        julia "Wow... That's a lot!"
    "Belly":

        $ save("ep5_juliasex_stomach")
        show ep5 juliasex_096 with d
        julia "Hmm? Are you sure?" id ep5_23_juliasex_80ab23f7
        simon "Relax. I won't cum inside." id ep5_23_juliasex_9392bd54
        if config.developer:
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep5_anim_juliasex_097_voicefx fadein 0.5 fadeout 0.5
                play foley ep5_anim_juliasex_097_foley fadein 0.5 fadeout 0.5
            show ep5 anim_juliasex_097 with d

        simon "I just want a little more of this before I cum." id ep5_23_juliasex_4930f67f
        julia "I don't mind doing more..." id ep5_23_juliasex_d96943e0
        julia "Especially now that I'm so wet..." id ep5_23_juliasex_62d99338
        simon "Still so tight though!" id ep5_23_juliasex_bbfcece2
        simon "So good, I have to..." id ep5_23_juliasex_1932b756
        pause

        stop foley
        stop voicefx
        show ep5 juliasex_098 with d
        simon "I think I'm gonna..." id ep5_23_juliasex_6eaf7e9d
        pause 0.2
        show ep5 juliasex_098 with vpunch
        pause 0.2
        show ep5 juliasex_098 with vpunch
        pause 0.2
        show ep5 juliasex_099 with vpunch
        simon "Aaaaahhh!" id ep5_23_juliasex_3ac127a4
        julia "Wow... That's a lot!"

$ debug_other_path()

stop music fadeout 5
play music_2 deep_sky_blue fadein 10 volume 0.2

show ep5 juliasex_100 with long_fade
julia "That was so good." id ep5_23_juliasex_6ae7a23b
show ep5 juliasex_101 with d
simon "It was amazing." id ep5_23_juliasex_2814f23b
simon "(That did not feel like her first time.)" id ep5_23_juliasex_7ac958bd
play sound alarm_clock volume 0.5
show ep5 juliasex_102 with d
julia "Oh no..." id ep5_23_juliasex_968080b2
stop sound fadeout 1
play sound_2 wearing_clothes_1 volume 0.7
show ep5 juliasex_103 with d
julia "I have to go." id ep5_23_juliasex_84c8c2af
show ep5 juliasex_104 with d
simon "What is it?"
show ep5 juliasex_105 with d
julia "I didn't know it was so late!" id ep5_23_juliasex_1f9c9d90
julia "My mother will get home soon and see that I'm gone!" id ep5_23_juliasex_ad5c438b
show ep5 juliasex_106 with d
simon "She doesn't know you're here?" id ep5_23_juliasex_6b866da8
show ep5 juliasex_107 with d
julia "Of course not." id ep5_23_juliasex_52865633
show ep5 juliasex_108 with d
julia "Sorry, I have to go." id ep5_23_juliasex_dead927e
show ep5 juliasex_109 with d
julia "You know what?" id ep5_23_juliasex_ad321559
julia "Screw her." id ep5_23_juliasex_a0e207dc
play sound bed_movement_1 volume 0.4
show ep5 juliasex_110 with d
julia "I want to stay a few more minutes with you." id ep5_23_juliasex_a99525bb
show ep5 juliasex_111 with d
simon "Are you sure?"
show ep5 juliasex_112 with d
julia "I'm already late." id ep5_23_juliasex_484f168d
julia "I'll be in trouble regardless." id ep5_23_juliasex_a05d6c08
show ep5 juliasex_111 with d
simon "I like the idea of us staying like this a little longer." id ep5_23_juliasex_2d48d770
simon "It's a good sign. You must have enjoyed yourself." id ep5_23_juliasex_117092ee
show ep5 juliasex_112 with d
julia "I loved it." id ep5_23_juliasex_4b3eb3e5
julia "We should do it again real soon." id ep5_23_juliasex_37ef9048
show ep5 juliasex_113 with d
simon "Definitely." id ep5_23_juliasex_20de0c08
$ renpy.end_replay()
show ep5 juliasex_114 with d
pause
stop music_2 fadeout 3
show ep5 juliasex_115 with longer_fade
simon "(Huh? I fell asleep? Where's Julia?)" id ep5_23_juliasex_5d9b2f05
play sound wearing_clothes_1 volume 0.5
show ep5 juliasex_116 with wipeup
simon "(She must have had to go but didn't want to wake me.)" id ep5_23_juliasex_17998841
simon "(Today was a good day.)" id ep5_23_juliasex_bd087a51
show ep5 juliasex_117 with d
simon "(I should celebrate.)" id ep5_23_juliasex_c6f1d7b5
show ep5 juliasex_118 with d
simon "(But everyone I know is probably gone by now.)" id ep5_23_juliasex_6ec13bd8
simon "(I should just go down, have a few more drinks, and meet some people.)" id ep5_23_juliasex_802bbc8f
play sound highschool_crowd1 volume 0.1
show ep5 juliasex_119 with d
simon "(After all, this is a college party!)" id ep5_23_juliasex_cbe9099d

stop sound fadeout 5

jump ep5_24_nextday
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
