label ep5_99_credits:

    scene black
    play music alter_ego
    with d

    show game_gui_logo with d

    pause 2

    hide game_gui_logo with d

    show cred at Move((0.5, credits_y_position), (0.5, 0.0), credits_stringpeed, repeat=False, bounce=False, xanchor="center", yanchor="bottom")
    with d

    show gui_credits_julia as girl at right with credits_dissolve
    show gui_credits_lily as girl at left with credits_dissolve
    show gui_credits_chloe2 as girl at right with credits_dissolve
    show gui_credits_emily as girl at left with credits_dissolve
    show gui_credits_alyssa as girl at right with credits_dissolve
    show gui_credits_sue as girl at left with credits_dissolve
    show gui_credits_susan as girl at right with credits_dissolve
    hide girl with long_dissolve

    hide cred with d
    stop music fadeout 30


    call thanks_cta from _call_thanks_cta_2
    call julia_cta from _call_julia_cta_2
    call newsletter_subscribe_cta from _call_newsletter_subscribe_cta_2
    call logo_cta from _call_logo_cta_3

    if check_if_next_rpy_is_built('ep6_01_goodfather.rpy'):
        jump ep6_01_goodfather
    else:
        $ end_game_correctly()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
