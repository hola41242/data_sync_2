
label ep5_06_emilyday:
    pass
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
