label ep5_18_afterlily:



play music sprawling fadein 5 volume 0.45

show ep5 afterlily_001 with wipeleft
simon "(What a huge waste of time.)" id ep5_18_afterlily_2c48ab86
simon "(At least I returned the apartment key.)" id ep5_18_afterlily_fb350bf6
simon "(I'm free of it now.)" id ep5_18_afterlily_c598eac7
show ep5 afterlily_002 with d
simon "(But I still have Emily's key.)" id ep5_18_afterlily_736fef9c
simon "(She's crazy... but if she really knew me from before...)" id ep5_18_afterlily_f7d50437
simon "(There might still be clues about my past at her apartment.)" id ep5_18_afterlily_aa091718



show ep5 afterlily_003 with wipeup
simon "(It might not be my best idea, but it's worth a shot.)" id ep5_18_afterlily_29caf350




show ep5 afterlily_004 with wipedown
play sound lock2 volume 0.7
simon "(I just hope she's not here.)" id ep5_18_afterlily_bf07fc95
simon "(Although this time, I'd be surprising her.)" id ep5_18_afterlily_1fa010fe
simon "(That would be nice for a change.)" id ep5_18_afterlily_c885d749


play sound opening_door_1 volume 0.7
show ep5 afterlily_005 with d
simon "(Not today, I guess.)" id ep5_18_afterlily_8fcbfdce
simon "(So, what else are you hiding here, Emily?)" id ep5_18_afterlily_568c34f6
play sound door volume 0.7
show ep5 afterlily_006 with d
simon "(Hmmmm...)" id ep5_18_afterlily_a3b02c8e
simon "(Another gift for me, is that it?)" id ep5_18_afterlily_32e43aa6
show ep5 afterlily_007 with d
simon "(A towel, some clothes... and a note.)" id ep5_18_afterlily_3699adfd
show ep5 afterlily_008 with d
simon "(Have fun at the party.)" id ep5_18_afterlily_4170fa9f
simon "(Which party? Is she talking about tonight's party?)" id ep5_18_afterlily_84293665
simon "(Or about the charity ball?)" id ep5_18_afterlily_acb9a515
show ep5 afterlily_009 with d
simon "(Um... That's a masquerade ball. She wouldn't be giving me these clothes for that.)" id ep5_18_afterlily_8584a564
simon "(I think...)" id ep5_18_afterlily_85731982
show ep5 afterlily_010 with d
simon "(But how would she know about the party tonight?)" id ep5_18_afterlily_b07a269e
simon "(Aaahh... How enigmatic you are, Emily.)" id ep5_18_afterlily_5eea4e42
stop music fadeout 10
show ep5 afterlily_011 with d
simon "(But at the same time...)" id ep5_18_afterlily_a48ed412
simon "(I could always take a shower and change here without having to bother anyone.)" id ep5_18_afterlily_e9fb80d2
simon "(Speaking of...)" id ep5_18_afterlily_b14217ce


if chose("ep4_livingsituation_julia"):
    show ep5 afterlily_012 with d
    simon "Hey, Julia!" id ep5_18_afterlily_a03cb08d
    show ep5 afterlily_013 with d
    julia "Hello, you!" (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I wanted to ask if I could leave my stuff at your place just a tiny bit longer."
    show ep5 afterlily_013 with d
    julia "Of course! I hid everything really well so my mom wouldn't find it." (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I'll need my bag for the ball tomorrow though."
    show ep5 afterlily_014 with d
    julia "I can bring it to you tomorrow if you want, Twinkle Toes!" (what_italic=True)
    show ep5 afterlily_015 with d
    simon "Thanks."
    simon "See you at the party later on." id ep5_18_afterlily_94879fde

elif chose("ep4_livingsituation_chloe"):
    show ep5 afterlily_012 with d
    simon "Hey, Chloe!" id ep5_18_afterlily_6d2e5e3c
    show ep5 afterlily_013 with d
    chloe "Hey!" (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I wanted to ask if I could leave my stuff at your place just a tiny bit longer."
    show ep5 afterlily_014 with d
    chloe "Of course! Not a problem." (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I'll need my bag for the ball tomorrow though."
    show ep5 afterlily_014 with d
    chloe "I'll bring it to you tomorrow then!" (what_italic=True)
    show ep5 afterlily_015 with d
    simon "Thanks."
    show ep5 afterlily_013 with d
    chloe "By the way, did Dylan tell you about the party?" (what_italic=True)
    show ep5 afterlily_012 with d
    simon "Yeah, I heard about it." id ep5_18_afterlily_d7bca91b
    show ep5 afterlily_014 with d
    chloe "Excellent! See you there!" (what_italic=True)

elif chose("ep4_livingsituation_sue"):
    show ep5 afterlily_012 with d
    simon "Hey, Sue." id ep5_18_afterlily_76c3817e
    show ep5 afterlily_016 with d
    sue "Hey, dipshit. Where are you?" (what_italic=True)
    show ep5 afterlily_015 with d
    simon "You were worrying about me, weren't you?" id ep5_18_afterlily_fe1ba973
    show ep5 afterlily_014 with d
    sue "I was just worried because it's getting late, and someone has to clean my room soon." (what_italic=True)
    show ep5 afterlily_015 with d
    simon "I'll have to get back to you on that." id ep5_18_afterlily_a3a5182f
    simon "I called to let you know I'm going to a party later on, so I won't be back early." id ep5_18_afterlily_a89c6f7f
    show ep5 afterlily_013 with d
    sue "Oh... A party, huh?" (what_italic=True)
    show ep5 afterlily_012 with d
    simon "It's Dylan's thing. I shouldn't be too long." id ep5_18_afterlily_1b5b7f99
    show ep5 afterlily_013 with d
    sue "That's cool." (what_italic=True)
    show ep5 afterlily_012 with d
    simon "Please don't throw away my stuff." id ep5_18_afterlily_657450fd
    show ep5 afterlily_012 with d
    simon "I need my bag for the ball tomorrow."
    show ep5 afterlily_013 with d
    sue "I'll think about it." (what_italic=True)
    sue "If I don't toss it, I guess I could bring you your bag tomorrow." (what_italic=True)
    show ep5 afterlily_017 with d
    simon "Thanks."
    sue "See you soon, [name]." (what_italic=True)

elif chose("ep4_livingsituation_here"):
    show ep5 afterlily_017 with d
    simon "Hi, Alyssa!" id ep5_18_afterlily_9bf6bb2d
    show ep5 afterlily_014 with d
    alyssa "Hi, [name]!" (what_italic=True)
    alyssa "How are things going with college?" (what_italic=True)
    show ep5 afterlily_015 with d
    simon "They're going well." id ep5_18_afterlily_ed10c9c3
    simon "I actually called to let you know I'm going to a party later." id ep5_18_afterlily_3069b927
    show ep5 afterlily_012 with d
    simon "It's Dylan's thing, so I don't know if I'll make it back too early." id ep5_18_afterlily_9715a088
    show ep5 afterlily_013 with d
    alyssa "Oh, thanks for letting me know!" (what_italic=True)
    alyssa "Don't worry, I'll take care of your things." (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I'll need my bag for the ball tomorrow."
    show ep5 afterlily_014 with d
    alyssa "I can bring it by tomorrow if you want." (what_italic=True)
    show ep5 afterlily_018 with d
    simon "Thanks."
    show ep5 afterlily_014 with d
    alyssa "Just don't go getting into trouble, okay?" (what_italic=True)
    show ep5 afterlily_019 with d
    simon "Haha. I'll try not to." id ep5_18_afterlily_9abcb672
    show ep5 afterlily_014 with d
    alyssa "See you later then!" (what_italic=True)
    show ep5 afterlily_020 with d
    simon "See ya." id ep5_18_afterlily_2606c561
else:
    show ep5 afterlily_012 with d
    simon "Hey, dude." id ep5_18_afterlily_5d6b555a
    show ep5 afterlily_013 with d
    dylan "My bro! Where you at?" (what_italic=True)
    show ep5 afterlily_012 with d
    simon "Just sorting some things out." id ep5_18_afterlily_9d08627b
    simon "I wanted to ask if I could leave my stuff at your place just a tiny bit longer."
    show ep5 afterlily_014 with d
    dylan "Of course, bro! You and your stuff are always welcome at my place." (what_italic=True)
    show ep5 afterlily_012 with d
    simon "I'll need my bag for the ball tomorrow though."
    show ep5 afterlily_014 with d
    dylan "I'll bring it to you tomorrow, bro!" (what_italic=True)
    show ep5 afterlily_018 with d
    simon "Thanks."
    simon "See you at the party later." id ep5_18_afterlily_b5d424c3

$ debug_other_path()

show ep5 afterlily_021 with d
simon "(That's that.)" id ep5_18_afterlily_04639ec0
show ep5 afterlily_022 with d
simon "(Now for you...)" id ep5_18_afterlily_ff0fe186
simon "(Emily really knows my tastes.)" id ep5_18_afterlily_35f731e6
simon "(Next time we meet, she's got a lot of explaining to do.)" id ep5_18_afterlily_bc72c729


show ep5 afterlily_023 with wipedown
simon "(Time to go to the party.)" id ep5_18_afterlily_2b7b4fd6

jump ep5_19_fratparty
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
