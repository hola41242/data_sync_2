






label ep5_19_fratparty:

play music gameday volume 0.35


show ep5 fratparty_001 with wiperight
simon "(This is my first college party. I've got to make sure I don't screw up tonight.)" id ep5_19_fratparty_b8dd85ae
show ep5 fratparty_002 with d
simon "(I should look for Dylan.)" id ep5_19_fratparty_53949fb6
show ep5 fratparty_003 with d
simon "(He should be here by now, and it won't be hard to find him with that dyed hair of his.)" id ep5_19_fratparty_fca70ebb


play sound door_thud volume 0.7
show ep5 fratparty_004 with wiperight
simon "(Why are all these people wearing bathing suits?)" id ep5_19_fratparty_f8817d01
simon "(No one said anything about a pool party.)" id ep5_19_fratparty_94294377
show ep5 fratparty_005 with d
simon "(There's no way I can go into a pool wearing this.)" id ep5_19_fratparty_a21534ea
show ep5 fratparty_006 with d
chloe "You forgot your bathing suit, didn't you?" id ep5_19_fratparty_797cadab
show ep5 fratparty_007 with d
simon "No one said anything about bathing suits." id ep5_19_fratparty_63394513
stop music fadeout 5
show ep5 fratparty_008 with d
chloe "Of course they didn't. They never tell the freshmen. Then they all have to jump in the pool in their underwear... or nothing." id ep5_19_fratparty_22ffbbda
simon "There's no way I'm jumping into any pool wearing this." id ep5_19_fratparty_b63a73de
play music phuket volume 0.35 fadein 5
show ep5 fratparty_009 with d
chloe "You're lucky to have a friend who knows things." id ep5_19_fratparty_31208f97


play sound door_thud volume 0.5
show ep5 fratparty_010 with wiperight
simon "Are you just going to stand there and watch me change?" id ep5_19_fratparty_44feaa19

if chose("ep3_sat_chloesex_continue"):
    show ep5 fratparty_010 with d
    chloe "Nothing I haven't seen before." id ep5_19_fratparty_b2ca3b7d
    chloe "And you know I like watching." id ep5_19_fratparty_ce9ea3c0
else:

    show ep5 fratparty_011 with d
    chloe "I'll give you some space." id ep5_19_fratparty_26b939ee

$ debug_other_path()

if chose("ep4_livingsituation_chloe"):
    show ep5 fratparty_012 with d
    chloe "So, have you found a way to get into the ball tomorrow?" id ep5_19_fratparty_0c6dc11e
    show ep5 fratparty_013 with d
    chloe "I tried everything, but I couldn't get your name on the list." id ep5_19_fratparty_f2073903
else:

    show ep5 fratparty_014 with d
    chloe "So, the ball is tomorrow. Do you know how you're going to get in?" id ep5_19_fratparty_7287b22d
    show ep5 fratparty_015 with d
    simon "Not quite yet... Do you have any ideas?" id ep5_19_fratparty_c259b696
    show ep5 fratparty_013 with d
    chloe "I tried to get your name on the list, but it didn't work." id ep5_19_fratparty_47a50908
    show ep5 fratparty_016 with d
    simon "Wow, you actually tried?" id ep5_19_fratparty_5965708f
    show ep5 fratparty_013 with d
    chloe "Oh, I tried everything." id ep5_19_fratparty_05b51631

$ debug_other_path()

show ep5 fratparty_017 with d
simon "(What does she mean by \"tried everything\"?)"
show ep5 fratparty_018 with fade
chloe "Hello, Susan." id ep5_19_fratparty_1a5762f1
chloe "You'll do exactly as I say and put his name on that list..." id ep5_19_fratparty_bef6391e
show ep5 fratparty_018_1 with d
chloe "If you don't, I'll have to release a certain video of you to the public." id ep5_19_fratparty_fc289fac
susan "You don't scare me." id ep5_19_fratparty_fcc16934
susan "And you're delusional if you think that video of me and Lily would ruin my reputation." id ep5_19_fratparty_ac343a51
show ep5 fratparty_018_2 with d
chloe "I'm not talking about that." id ep5_19_fratparty_b2bfc675
chloe "I'm talking about the video of you groping a college student." id ep5_19_fratparty_a77db745
show ep5 fratparty_013 with fade
chloe "[name]? Are you going to change soon, or are you just going to stand there?" id ep5_19_fratparty_1718abd3
show ep5 fratparty_019 with wiperight
simon "Are you sure about this, Chloe? Aren't they too short?" id ep5_19_fratparty_559d8377
chloe "Trust me. Women love a man in swim briefs." id ep5_19_fratparty_d275f3f1
if chose("ep3_sat_chloesex_continue"):
    show ep5 fratparty_020 with d
chloe "(Especially when they have a package like yours.)" id ep5_19_fratparty_5357fd1b
play sound door_open_hard volume 0.7
show ep5 fratparty_021 with d
julia "Oh, sorry. I thought there was no one in here." id ep5_19_fratparty_f2a41c2a
show ep5 fratparty_022 with d
simon "Julia? You're here already?" id ep5_19_fratparty_6de7b557
show ep5 fratparty_023 with d
julia "[name]? What's going on in here?" id ep5_19_fratparty_93627c49
show ep5 fratparty_024 with d
simon "Chloe was just helping me. I didn't bring a bathing suit." id ep5_19_fratparty_61203990
show ep5 fratparty_025 with d
chloe "Oh, the two of you came together?" id ep5_19_fratparty_52314d1f
chloe "I should get going then..." id ep5_19_fratparty_6be07583
chloe "We can talk another time." id ep5_19_fratparty_4ecd0459
show ep5 fratparty_026 with d
chloe "See you at the pool!" id ep5_19_fratparty_643b5f4d
show ep5 fratparty_027 with d
julia "That swimsuit looks good on you, Twinkle Toes." id ep5_19_fratparty_ae42803f
show ep5 fratparty_028 with d
simon "You think so?" id ep5_19_fratparty_f08ac222
simon "I feel weird leaving the bathroom wearing only this." id ep5_19_fratparty_7d86edaf
show ep5 fratparty_029 with d
julia "If you go out like that..." id ep5_19_fratparty_873b0d40
show ep5 fratparty_030 with d
julia "I can go out like this." id ep5_19_fratparty_5370d1e8
show ep5 fratparty_031 with d
julia "... Just so you feel better." id ep5_19_fratparty_6765c2d1
show ep5 fratparty_032 with d
simon "I guess we're going then." id ep5_19_fratparty_4cb0145d


play sound_3 school_crowd volume 0.1 loop
show ep5 fratparty_033 with wiperight
simon "We need to do something to fit in more." id ep5_19_fratparty_22311aca
show ep5 fratparty_034 with d
simon "And I need a way to get my mind off of everything." id ep5_19_fratparty_82664f15
simon "The ball is tomorrow after all." id ep5_19_fratparty_95a73c5e
show ep5 fratparty_035 with d
julia "I think your swimsuit is doing a good enough job calling attention to us." id ep5_19_fratparty_29c83ab7

play sound girls_laughing volume 0.5 
play sound_2 photo volume 0.7
show ep5 fratparty_036 with d
pause
show ep5 fratparty_037 with d
simon "Um, I'm not sure if this is the best way of fitting in." id ep5_19_fratparty_eb24ee7b
show ep5 fratparty_038 with d
julia "[name], check that out!" id ep5_19_fratparty_d0d3ee30
show ep5 fratparty_039 with d
simon "Dance Dance Supreme!" id ep5_19_fratparty_3ba2b964
show ep5 fratparty_040 with d
julia "We have to play!" id ep5_19_fratparty_804386db

if chose("ep1_win_arcade"):
    show ep5 fratparty_041 with d
    simon "I don't want to humiliate you in front of the whole frat party though." id ep5_19_fratparty_e841aae3
else:

    show ep5 fratparty_042 with d
    simon "That's all I need, to be humiliated by a girl at a frat party." id ep5_19_fratparty_a91657ae

$ debug_other_path()

stop music fadeout 5

show ep5 fratparty_043 with d
julia "Who said we need to compete against each other, dummy?" id ep5_19_fratparty_f8fa4840
show ep5 fratparty_044 with d
julia "We can play in co-op mode." id ep5_19_fratparty_885a5904

play music purple_tangerine_no_vocals volume 0.2
$ musicvar1 = renpy.music.get_playing()
play music purple_tangerine_vocals volume 0.2
$ musicvar2 = renpy.music.get_playing()

$ renpy.music.set_volume(0.2, 0.0)
$ renpy.music.set_volume(0.0, 0.0, channel="music_2")
$ renpy.music.play(musicvar1, channel="music", loop=True, synchro_start=True)
$ renpy.music.play(musicvar2, channel="music_2", loop=True, synchro_start=True)


$ renpy.music.set_volume(0.2, 0.0)
show ep5 fratparty_045 with d
julia "Attention, everyone!" id ep5_19_fratparty_cceff19e
julia "You're about to see the greatest Dance Dance Supreme duo the world has ever seen!" id ep5_19_fratparty_c0a8e8b7
simon "(What's she doing?)" id ep5_19_fratparty_7dff4053
julia "Come on, [name]!" id ep5_19_fratparty_0dcd4f95
show ep5 fratparty_046 with d
bruce "Who's this girl?" id ep5_19_fratparty_e7266870
show ep5 fratparty_047 with d
heather "She sure is cocky!" id ep5_19_fratparty_8581e3cc
heather "I won't allow it." id ep5_19_fratparty_9303d6de
show ep5 fratparty_048 with d
heather "What she's saying is ridiculous. Nobody beats us at DDS." id ep5_19_fratparty_e1668e9d
show ep5 fratparty_049 with d
julia "That's what you think!" id ep5_19_fratparty_1899aea9
julia "Whoever loses has to jump naked into the pool!" id ep5_19_fratparty_91a26841
show ep5 fratparty_050 with d
heather "Deal!" id ep5_19_fratparty_2c01c83d




show ep5 fratparty_051 with d
julia "Are you ready to rock?" id ep5_19_fratparty_c6253bb5
show ep5 fratparty_052 with d
heather "The competition will now begin!" id ep5_19_fratparty_e83ff453
heather "Bruce and Heather against Julia and [name]." id ep5_19_fratparty_639d3907
heather "The couple that scores the most points in a single match wins!" id ep5_19_fratparty_0f183174
heather "The couple that loses will have to jump into the pool naked — in front of the whole party!" id ep5_19_fratparty_68fe1271
show ep5 fratparty_053 with d
heather "But to make things a little more interesting..." id ep5_19_fratparty_5c6a7665
show ep5 fratparty_054 with d
heather "We'll have to dance tied together." (what_italic=True)
show ep5 fratparty_055 with d
simon "(How are we supposed to dance like this?)" id ep5_19_fratparty_99437cac
show ep5 fratparty_056 with d
julia "Hold onto my waist." id ep5_19_fratparty_c41ab9c0
simon "Have you done this before?" id ep5_19_fratparty_59bb720c


$ renpy.music.set_volume(0.0, 0.2)
$ renpy.music.set_volume(0.2, 0.2, channel="music_2")
show ep5 fratparty_057 with d
julia "Nope. But we just need to make good use of our hands." id ep5_19_fratparty_099f9f0c

play sound game_sfx_1 volume 0.5
show ep5 fratparty_058 with d
pause
play sound game_sfx_2 volume 0.5
show ep5 fratparty_059 with d
pause
play sound game_sfx_6 volume 0.5
show ep5 fratparty_060 with d
pause
show ep5 fratparty_061 with d
pause

stop music fadeout 5 
$ renpy.music.stop(channel="music_2", fadeout=5)
$ renpy.music.set_volume(0.2, 0.0)
queue music toy_shed_blues volume 0.35
play sound applause_cheer_small volume 0.3 
show ep5 fratparty_062 with d
julia "Someone sure got excited." id ep5_19_fratparty_14dcede7
stop sound fadeout 3
show ep5 fratparty_063 with d
simon "I'd say two people did." id ep5_19_fratparty_18a8c606
show ep5 fratparty_064 with d
simon "(It's a pretty good score... for a rookie.)" id ep5_19_fratparty_65c1b482
simon "(But if they've played like this before, we're definitely going to lose.)" id ep5_19_fratparty_d7798ab9
show ep5 fratparty_065 with d
julia "Now it's your turn!" id ep5_19_fratparty_a6f2f9b2
show ep5 fratparty_066 with d
julia "Let's help each other hide our... excitement." id ep5_19_fratparty_03842fec
show ep5 fratparty_067 with d
julia "I can still feel you, [name]." id ep5_19_fratparty_29ca4c3e
show ep5 fratparty_068 with d
simon "Sorry." id ep5_19_fratparty_dbe8eca4
show ep5 fratparty_069 with d
bruce "Damn, this is going to be hard." id ep5_19_fratparty_9543a13a
heather "I figured they'd just fall over." id ep5_19_fratparty_3b2679b8

play sound bit_ui_warning_buzz volume 0.5 
show ep5 fratparty_070 with d
heather "My foot, Bruce!" id ep5_19_fratparty_c1ff38d8
bruce "Sorry, baby." id ep5_19_fratparty_6a02076d
show ep5 fratparty_071 with d
bruce "Ouch, Heather!" id ep5_19_fratparty_5b43e51f

play sound body_fall_mat8 volume 0.7
play sound_2 small_crowd_laughing volume 0.8 
show ep5 fratparty_072 with vpunch
heather "Nooooo!!!" id ep5_19_fratparty_6b2d86df
show ep5 fratparty_073 with d
julia "We won!" id ep5_19_fratparty_bf998b7e
show ep5 fratparty_074 with d
heather "Look at what you did!" id ep5_19_fratparty_8aa5dd21
bruce "Sorry!" id ep5_19_fratparty_e8f783ac
heather "You're making me look ridiculous!" id ep5_19_fratparty_aa28c3e6
show ep5 fratparty_075 with d
julia "A bet is a bet." id ep5_19_fratparty_d0471051
julia "Undress, you two!" id ep5_19_fratparty_c46d4b54
show ep5 fratparty_076 with d
heather "This is all your fault." id ep5_19_fratparty_f2afcb67
bruce "It's not my fault. You stepped on my toes." id ep5_19_fratparty_323e4f69
show ep5 fratparty_077 with wiperight
pause

play sound crowd_medium_sized_crowd_laughing_out_loud volume 0.5 
show ep5 fratparty_078 with d
pause
play sound swimming_1 volume 0.7
show ep5 fratparty_078_1 with d
pause
show ep5 fratparty_079 with d
pause
show ep5 fratparty_080 with d
simon "Wait, Julia. Hold up." id ep5_19_fratparty_3cbbe4d6
show ep5 fratparty_081 with d
julia "Why?" id ep5_19_fratparty_56449802
show ep5 fratparty_082 with d
julia "[name]!" id ep5_19_fratparty_f67fdb4c
show ep5 fratparty_083 with d
simon "I can't let anyone see me like this!" id ep5_19_fratparty_e746075a
show ep5 fratparty_084 with d
julia "Don't worry about it." id ep5_19_fratparty_d64ecbbf
show ep5 fratparty_085 with d
julia "I'd prefer if no one else saw it anyway." id ep5_19_fratparty_e1ec28a2
julia "So to celebrate, we're going to..." id ep5_19_fratparty_37eba12f
play sound swimming_1 volume 0.7
show ep5 fratparty_086 with hpunch
julia "Go for a swim in the pool!" id ep5_19_fratparty_f0444910
show ep5 fratparty_087 with d
simon "What was that for, Julia?" id ep5_19_fratparty_75ded0ab
show ep5 fratparty_088 with d
julia "You needed to cool off a little." id ep5_19_fratparty_5852db1f
show ep5 fratparty_089 with d
simon "How about you?" id ep5_19_fratparty_90b41dd0
simon "Are you coming or what?" id ep5_19_fratparty_7b4c0ada
show ep5 fratparty_090 with d
julia "No, thank you." id ep5_19_fratparty_3be95202
julia "Chlorine is bad for my hair." id ep5_19_fratparty_b4afec42
show ep5 fratparty_091 with d
dylan "Hey, [name]! I was looking for you!" (what_bold=True)
show ep5 fratparty_092 with d
simon "Hey, Dylan!" id ep5_19_fratparty_903ecd8c
play sound swimming_getting_out_of_pool volume 0.5
show ep5 fratparty_093 with d
dylan "Swimming is for losers, man! Get out." (what_bold=True)
show ep5 fratparty_094 with d
dylan "*Whispers.* What are you wearing, dude?" id ep5_19_fratparty_fc335f21
show ep5 fratparty_095 with d
simon "Ask Chloe." id ep5_19_fratparty_fba384a6
simon "She's the one who gave them to me." id ep5_19_fratparty_0d211098
show ep5 fratparty_096 with d
dylan "*Whispers.* I have a pair of swim trunks in the car. I'll go get them for you." id ep5_19_fratparty_a2686a9c
dylan "*Whispers.* Then we can play beer pong. I want to challenge you to a match." id ep5_19_fratparty_e2eaccb7
show ep5 fratparty_097 with d
simon "Give me a second..." id ep5_19_fratparty_7a25842d

stop sound_3

call ask_for_review from _call_ask_for_review

jump ep5_20_beerpong
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
