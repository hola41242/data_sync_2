define episode_5_name = _("Episode 5 - Fresh Parties")
label ep5_01_intro:




    play sound school_crowd loop volume 0.3 


    $ validate_mods()
    scene ep5 intro_001 with long_fade
    mother "Oh, you know how boys are." id ep5_01_intro_88174cac
    stop sound fadeout 10
    mother "He only cares about hanging around with his girlfriend." id ep5_01_intro_1a606ed4
    play music want_to_dance fadein 2 volume 0.3
    show ep5 intro_002 with d
    susan "I don't think I've exchanged a single word with him yet!" id ep5_01_intro_b2f82482
    show ep5 intro_003 with d
    susan "And it's almost time for us to put on our costumes." id ep5_01_intro_49c274df
    susan "After that, I don't know if I'll be able to recognize him!" id ep5_01_intro_31881d70
    show ep5 intro_004 with d
    mother "Son, at least come take a picture with mommy's friend." id ep5_01_intro_97005ea8
    show ep5 intro_005 with d
    simon "Why? I'm not even in my costume yet." id ep5_01_intro_f77c8d83
    show ep5 intro_006 with d
    mother "He's just excited about his costume." id ep5_01_intro_a7eff4c4
    mother "So much so that he won't stop talking about it." id ep5_01_intro_4a717123
    show ep5 intro_007 with d
    mother "He's even got me curious about it!" id ep5_01_intro_24baed17
    show ep5 intro_008 with d
    susan "Oh really?" id ep5_01_intro_9c45c932
    susan "What did you pick out?" id ep5_01_intro_e438cadc
    show ep5 intro_009 with d
    simon "I'm going to wear the mask I found in my dad's things." id ep5_01_intro_747f9f30
    show ep5 intro_010 with d
    susan "Oh..." id ep5_01_intro_9840a7b4
    show ep5 intro_011 with d
    mother "[name]..." id ep5_01_intro_b428e479
    show ep5 intro_012 with d
    simon "It's a masquerade ball." id ep5_01_intro_c46da034
    simon "I just wanted to be in character." id ep5_01_intro_dafce01f
    show ep5 intro_013 with d
    susan "Well..." id ep5_01_intro_955579d2
    show ep5 intro_014 with d
    emily "[name]! Come on. We've got to get ready." id ep5_01_intro_2bde563b
    show ep5 intro_015 with d
    mother "Not before we take a picture together!" id ep5_01_intro_a0dcf089
    show ep5 intro_016 with d
    emily "No time, [name]'s mom!"
    show ep5 intro_017 with d
    play sound photo 
    show ep5 intro_017 with flash
    mother "These children..." id ep5_01_intro_b34c5cde
    show ep5 intro_018 with d
    susan "Did you take it already?" id ep5_01_intro_2184464f
    show ep5 intro_019 with d
    mother "Yep." id ep5_01_intro_565c7a2c
    show ep5 intro_020 with d
    mother "Aww, you look so pretty!" id ep5_01_intro_03966bda
    show ep5 intro_021 with d
    susan "You're a terrible photographer, Deb." id ep5_01_intro_ab2f1b1e
    show ep5 intro_022 with d
    mother "Does that mean you don't want a copy?" id ep5_01_intro_184a150a
    show ep5 intro_023 with d
    susan "No, I do. Send me one." id ep5_01_intro_522716f6
    show ep5 intro_024 with d
    mother "Will do." id ep5_01_intro_eb84b34a
    show ep5 intro_025 with d
    stop music fadeout 5
    susan "Who's the girl?" id ep5_01_intro_0ccd6e5b
    susan "She looks familiar." id ep5_01_intro_c5e5a91c
    show ep5 intro_026 with d
    mother "I don't know where he gets these girls from." id ep5_01_intro_dcf265ce
    show black with long_fade

    play music you_cant_stop_me fadein 4
    show black as ep5 with None

    scene oppaiman_presents with medium_fade
    pause 2

    scene black as ep5 with medium_fade
    show black_screen as ep5 with d

    show ep5 titlecard as ep5 with None
    $ on_screen_translation(episode_5_name, interact=False)
    pause 4
    $ on_screen_translation(episode_5_name, interact=False)
    stop music fadeout 4
    $ on_screen_translation(episode_5_name, interact=False)
    pause 4

    if choice_made_skip_debug('ep4_livingsituation_here'):
        jump ep5_07_alyssaday
    elif choice_made_skip_debug('ep4_livingsituation_julia'):
        jump ep5_03_juliaday
    elif choice_made_skip_debug('ep4_livingsituation_sue'):
        jump ep5_04_sueday
    elif choice_made_skip_debug('ep4_livingsituation_chloe'):
        jump ep5_05_chloeday
    else:
        $ ep4_livingsituation_dylan = True
        $ player_choice("ep4_livingsituation_dylan:true")
        jump ep5_02_dylanday
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
