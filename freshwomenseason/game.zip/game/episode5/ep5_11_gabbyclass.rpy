
label ep5_11_gabbyclass:


    play music passionate_choices fadein 5 volume 0.4
    play sound door volume 0.7
    show ep5 gabbyclass_001 with wipeleft
    simon "Here." id ep5_11_gabbyclass_35e55f7c
    simon "Let me get that for you." id ep5_11_gabbyclass_f450b4a1
    show ep5 gabbyclass_002 with d
    gabby "Thanks." id ep5_11_gabbyclass_2c2be029
    show ep5 gabbyclass_003 with d
    simon "You're welcome." id ep5_11_gabbyclass_937beae2
    show ep5 gabbyclass_004 with d
    simon "So..." id ep5_11_gabbyclass_71d93eb4
    show ep5 gabbyclass_005 with d
    simon "This job with Angela, what is it really?" id ep5_11_gabbyclass_a5aaca72
    play sound office_chair volume 0.7
    show ep5 gabbyclass_006 with d
    gabby "Well, it's just like she said..." id ep5_11_gabbyclass_8155a53c
    show ep5 gabbyclass_007 with d
    gabby "We talk." id ep5_11_gabbyclass_6c7af2c5
    gabby "You can vent to me." id ep5_11_gabbyclass_b7d15fba
    gabby "Talk about what's bothering you." id ep5_11_gabbyclass_02921ee3
    gabby "Or anything else you'd like to talk about." id ep5_11_gabbyclass_bc7bf30d
    show ep5 gabbyclass_008 with d
    gabby "Then when you're done talking, I'll see what I can do to help relieve some of that built-up tension." id ep5_11_gabbyclass_fdb6ba91
    show ep5 gabbyclass_009 with d
    simon "What's bothering me..." id ep5_11_gabbyclass_cfa185a4
    show ep5 gabbyclass_010 with d
    simon "(Sam... The photo... The charity ball... My father...)" id ep5_11_gabbyclass_055895f4
    show ep5 gabbyclass_011 with d
    simon "I..." id ep5_11_gabbyclass_9bf3b23a
    show ep5 gabbyclass_012 with d
    male_professor "Ethics." id ep5_11_gabbyclass_7d0e78af
    show ep5 gabbyclass_013 with d
    simon "Hmm?" id ep5_11_gabbyclass_0c4419c0
    show ep5 gabbyclass_014 with d
    male_professor "Or the art of overthinking whether or not we should carry out an action." id ep5_11_gabbyclass_09084b79
    show ep5 gabbyclass_015 with d
    male_professor "Please open your books to page thirty-four." id ep5_11_gabbyclass_a32b5984
    show ep5 gabbyclass_016 with d
    simon "We can talk later." id ep5_11_gabbyclass_5c8dc423
    show ep5 gabbyclass_017 with d
    gabby "Uh, check this out." id ep5_11_gabbyclass_2f2dbf8a
    show ep5 gabbyclass_018 with d
    simon "What? Is he just going to sit there?" id ep5_11_gabbyclass_608e443b
    show ep5 gabbyclass_019 with d
    gabby "As far as I've heard, yes." id ep5_11_gabbyclass_c0e7a777
    show ep5 gabbyclass_020 with d
    gabby "That's why this class is perfect for having a chat." id ep5_11_gabbyclass_cd84b036
    show ep5 gabbyclass_021 with d
    gabby "Have a look around..."
    show ep5 gabbyclass_022 with d
    simon "There's almost no one here." id ep5_11_gabbyclass_fb28a9e8
    gabby "And those who are here are sleeping." id ep5_11_gabbyclass_00225fd9
    show ep5 gabbyclass_023 with d
    gabby "So, what's going on in your life?" id ep5_11_gabbyclass_cbfb47b3


    menu:
        "Talk to Gabby"(True):
            $ ep5_gabbyclass_talk_to_gabby = True
            $ player_choice("ep5_gabbyclass_talk_to_gabby:true")
            show ep5 gabbyclass_024 with d
            simon "Well, I'm glad we're sitting because I've got a lot going on." id ep5_11_gabbyclass_e00c4eac
            show ep5 gabbyclass_025 with d
            gabby "I'm all ears." id ep5_11_gabbyclass_245d0008
            show ep5 gabbyclass_026 with d
            simon "Let's start from the beginning..." id ep5_11_gabbyclass_3f0bedc9

            show ep5 gabbyclass_027 with long_fade
            gabby "Wow... You really do have a lot going on." id ep5_11_gabbyclass_fa0492bd
            show ep5 gabbyclass_028 with d
            gabby "So you have to go to that ball and look for your father." id ep5_11_gabbyclass_eb92f024
            show ep5 gabbyclass_029 with d
            simon "Yep." id ep5_11_gabbyclass_30996514
            show ep5 gabbyclass_030 with d
            gabby "That's a lot of pressure you've put on yourself." id ep5_11_gabbyclass_9d2850a4
            show ep5 gabbyclass_031 with d
            gabby "Well, now that we've relieved you of some of that mental weight, maybe you'd like to release a bit more..." id ep5_11_gabbyclass_3c17ae94
            show ep5 gabbyclass_032 with d
            gabby "... physically." id ep5_11_gabbyclass_44c57f48
            show ep5 gabbyclass_033 with d
            gabby "Are you ready for part two of our conversation?" id ep5_11_gabbyclass_baf4be59
            show ep5 gabbyclass_034 with d
            simon "What are you planning on doing?" id ep5_11_gabbyclass_f0c3419f
            show ep5 gabbyclass_035 with d
            gabby "Look around." id ep5_11_gabbyclass_1a6290d4
            gabby "They're all leaving." id ep5_11_gabbyclass_8471b36c
            show ep5 gabbyclass_036 with d
            gabby "Soon the professor will be out of here too." id ep5_11_gabbyclass_2aef2fe9
            show ep5 gabbyclass_037 with d
            gabby "Then the room will be ours." id ep5_11_gabbyclass_3af1f0d5
            gabby "You ready?" id ep5_11_gabbyclass_44deb2f7

            menu:
                "I'm ready"(True):
                    $ ep5_gabbyclass_ready = True
                    $ player_choice("ep5_gabbyclass_ready:true")
                    show ep5 gabbyclass_038 with d
                    simon "Ready." id ep5_11_gabbyclass_d079c5f3
                    stop music fadeout 3
                    show ep5 gabbyclass_039 with d
                    gabby "Good answer." id ep5_11_gabbyclass_e93e2f73


                    jump ep5_12_gabbysex
                "Not now":

                    $ ep5_gabbyclass_not_now = True
                    $ player_choice("ep5_gabbyclass_not_now:true")
                    show ep5 gabbyclass_040 with d
                    simon "We'd better not." id ep5_11_gabbyclass_f39a505f
                    simon "It seems too risky to me." id ep5_11_gabbyclass_94cff8d2
                    show ep5 gabbyclass_041 with d
                    gabby "I understand." id ep5_11_gabbyclass_69a04c86
                    play sound office_chair_1 volume 0.7
                    show ep5 gabbyclass_042 with d
                    gabby "I'll tell Angela that I'm at least a skilled enough listener." id ep5_11_gabbyclass_64fd60f9
                    show ep5 gabbyclass_043 with d
                    gabby "She'll be happy to hear that." id ep5_11_gabbyclass_85279491
                    show ep5 gabbyclass_044 with d
                    gabby "See you around, [name]." id ep5_11_gabbyclass_a93a4290


                    jump ep5_13_universityend
        "Don't talk to her":


            $ ep5_gabbyclass_dont_vent = True
            $ player_choice("ep5_gabbyclass_dont_vent:true")
            show ep5 gabbyclass_045 with d
            simon "I'm not in the mood to talk right now." id ep5_11_gabbyclass_90c202b2
            show ep5 gabbyclass_046 with d
            gabby "Well..." id ep5_11_gabbyclass_8dbcb982
            gabby "Saying so is also a form of venting." id ep5_11_gabbyclass_b5492182
            show ep5 gabbyclass_047 with d
            gabby "But I respect your choice." id ep5_11_gabbyclass_d0a71e10
            play sound office_chair_1 volume 0.7
            show ep5 gabbyclass_042 with d
            gabby "Let's talk another time." id ep5_11_gabbyclass_b735a9bc
            show ep5 gabbyclass_048 with d
            simon "Are you just leaving like that?" id ep5_11_gabbyclass_3331b97f
            show ep5 gabbyclass_049 with d
            gabby "Class is over." id ep5_11_gabbyclass_34f8d2b3
            show ep5 gabbyclass_050 with d
            simon "Oh..." id ep5_11_gabbyclass_d3eabd74

            jump ep5_13_universityend
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
