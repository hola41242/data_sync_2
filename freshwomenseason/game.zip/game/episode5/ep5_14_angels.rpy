
label ep5_14_angels:


    play music why_you_do_this fadein 3 volume 0.4
    show ep5 angels_001 with wiperight
    simon "(Since I had some extra time, I decided to ask around about university housing.)" id ep5_14_angels_c684b426
    show ep5 angels_002 with d
    simon "(But they didn't have any good news for me.)" id ep5_14_angels_5cee2a91
    simon "(I can't apply for housing until next semester.)" id ep5_14_angels_9b2ce670
    show ep5 angels_003 with d
    simon "(I thought I could do something to change her mind...)" id ep5_14_angels_28f6a543
    show ep5 angels_004 with d
    simon "(I even tried to lay on the charm...)" id ep5_14_angels_30ba6350
    show ep5 angels_005 with d
    simon "(But I think that only made things worse.)" id ep5_14_angels_e6bb74ce
    show ep5 angels_006 with d
    simon "(Maybe I should have brought Dylan along to help...)" id ep5_14_angels_8fc37b87
    show ep5 angels_007 with wipeleft
    simon "(No.)" id ep5_14_angels_d128bc93
    simon "(That's exactly what's wrong with me.)" id ep5_14_angels_4560eb82
    show ep5 angels_008 with d
    simon "(I don't want to always depend on my friends.)" id ep5_14_angels_6bae7d90

    if choice_made("ep3_04_challenge_won"):
        show ep5 angels_009 with d
        devilla "Hey, champion." id ep5_14_angels_06d777fe
    else:

        show ep5 angels_009 with d
        devilla "Hi, [name]." id ep5_14_angels_b4ac2a77

    $ debug_other_paths()

    show ep5 angels_010 with d
    simon "Devilla?" id ep5_14_angels_bdb05480
    simon "(Oh. She must have come with Angela!)" id ep5_14_angels_68be3963
    show ep5 angels_011 with d
    simon "Are you also here recruiting girls for the night club?" id ep5_14_angels_fcdb318d
    show ep5 angels_012 with d
    devilla "Nah. That's Angela's thing." id ep5_14_angels_29218aae
    show ep5 angels_013 with d
    devilla "But in a way, I'm also here looking for help." id ep5_14_angels_7bd01697
    devilla "I overheard your conversation." id ep5_14_angels_19c47cb0
    show ep5 angels_014 with d
    devilla "Do you need a place to stay?" id ep5_14_angels_ff55d7ce
    show ep5 angels_013 with d
    devilla "I thought you lived in a big, expensive apartment building." id ep5_14_angels_57dd3625
    show ep5 angels_015 with d
    simon "Oh, you knew about that?" id ep5_14_angels_a9dc3ce2
    simon "Well, I used to live in an apartment building, but... shit happened." id ep5_14_angels_f6694745
    show ep5 angels_014 with d
    devilla "What shit might that be?" id ep5_14_angels_4e9aa671
    show ep5 angels_016 with d
    devilla "Did you fuck your landlord's wife, then he had to kick you to the curb or something?" id ep5_14_angels_f2067ff9
    show ep5 angels_017 with d
    simon "Huh?!" id ep5_14_angels_6c871165
    show ep5 angels_018 with d
    devilla "Haha. Just kidding." id ep5_14_angels_48aecbd5
    devilla "You look too kind for that." id ep5_14_angels_29c2be72
    show ep5 angels_019 with d
    simon "Haha... Right..." id ep5_14_angels_a3362b31
    show ep5 angels_020 with d
    simon "Well, what matters is that I'm staying at a friend's house for now." id ep5_14_angels_9c562fad
    simon "But, well... I can't exactly stay there forever." id ep5_14_angels_d82b88c8
    show ep5 angels_013 with d
    devilla "That's what friends are for though, right?" id ep5_14_angels_d37d4479
    show ep5 angels_021 with d
    simon "I guess." id ep5_14_angels_b3df6f88
    show ep5 angels_022 with d
    simon "But I've got to think about my future, you know?" id ep5_14_angels_093b611a
    simon "I need to stand on my own two feet." id ep5_14_angels_546771f2

    if choice_made("ep4_susanhome_accept_the_job"):
        show ep5 angels_023 with d
        simon "I have a job, but my boss is sketchy." id ep5_14_angels_b59e4268
    else:

        show ep5 angels_023 with d
        simon "I used to work for this woman, but I don't really trust her." id ep5_14_angels_e95dba38

    $ debug_other_paths()

    show ep5 angels_024 with d
    simon "I wish I had a nice place to live and a steady paycheck." id ep5_14_angels_ccc836c0
    simon "Doing something I like." id ep5_14_angels_65ed340f
    show ep5 angels_013 with d
    devilla "And what do you like?" id ep5_14_angels_3cbfec9f
    show ep5 angels_025 with d
    simon "Well, I like..." id ep5_14_angels_57fd452c
    show ep5 angels_026 with d
    simon "Hmmm." id ep5_14_angels_6171f5f6
    show ep5 angels_027 with d
    simon "I..." id ep5_14_angels_9bf3b23a
    show ep5 angels_028 with d
    devilla "Pfffft..." id ep5_14_angels_fe31aaed
    show ep5 angels_029 with d
    devilla "If that's what you like so much, maybe you should come work for us." id ep5_14_angels_16aa082d
    show ep5 angels_030 with d
    simon "Hahaha. Could you imagine?" id ep5_14_angels_fb0dff4b
    show ep5 angels_031 with d
    devilla "Haha..." id ep5_14_angels_09acbd35
    show ep5 angels_032 with d
    devilla "I mean, we are expanding..." id ep5_14_angels_e3e1d811
    devilla "And we'll probably need all the help we can get..." id ep5_14_angels_54f34788
    devilla "Plus, you get along so well with Alfredo." id ep5_14_angels_f36bd6a0
    show ep5 angels_034 with d
    simon "(Who?)" id ep5_14_angels_979987b9
    show ep5 angels_035 with d
    simon "(Oh, their security guy!)" id ep5_14_angels_e8313ca2
    show ep5 angels_032 with d
    devilla "And you're already well-acquainted with our bear." id ep5_14_angels_dc2872c3


    show ep5 angels_036 with d
    simon "Working alongside a bear... That's got to be interesting." id ep5_14_angels_838c2221
    show ep5 angels_032 with d
    devilla "But don't think of this as a favor from a friend." id ep5_14_angels_47542f29
    show ep5 angels_037 with d
    devilla "I remember what you did to my bear." id ep5_14_angels_1be78a71
    devilla "Angela may have forgiven you, but I haven't." id ep5_14_angels_c01233ac
    show ep5 angels_038 with d
    simon "All right, all right... I get it." id ep5_14_angels_b3820eb5
    show ep5 angels_039 with d
    devilla "We've also got a few empty rooms there." id ep5_14_angels_3f0af4e5
    show ep5 angels_040 with d
    simon "At the night club?" id ep5_14_angels_bffc230c
    show ep5 angels_041 with d
    devilla "Yep, we have... many rooms." id ep5_14_angels_49110ba7
    show ep5 angels_042 with d
    simon "I don't know, Devilla..." id ep5_14_angels_5926011a
    show ep5 angels_013 with d
    devilla "You don't need to answer me now." id ep5_14_angels_73883e92
    devilla "Just call me when you've made up your mind." id ep5_14_angels_ac102033
    show ep5 angels_043 with d
    simon "Thank you, Devilla."
    simon "Don't take this the wrong way, but I didn't expect this level of kindness from you." id ep5_14_angels_2a0ba461
    show ep5 angels_044 with d
    devilla "Kindness? We work hard at the club." id ep5_14_angels_59b9faa6
    devilla "We aren't running a charity." id ep5_14_angels_1d9808c9
    show ep5 angels_045 with d
    simon "Of course you aren't." id ep5_14_angels_0c1da136
    show ep5 angels_046 with d
    simon "Charity..." id ep5_14_angels_1455809b
    show ep5 angels_047 with d
    simon "Wait... That club has been around for quite some time, hasn't it?" id ep5_14_angels_73908e46
    show ep5 angels_048 with d
    devilla "I think so. The place is quite old." id ep5_14_angels_32f52e2b
    show ep5 angels_047 with d
    simon "Why are you expanding now of all times?" id ep5_14_angels_15f15674
    simon "Do you buy sex toys from a certain woman who owns a beach house?" id ep5_14_angels_04ee15e1
    simon "Do you have an event to attend soon?" id ep5_14_angels_de38f0fc
    show ep5 angels_049 with d
    devilla "Whoa, whoa. Calm down, tiger!" id ep5_14_angels_0251bedd
    devilla "So many questions!" id ep5_14_angels_95c3eee7
    devilla "Still..." id ep5_14_angels_11f79be9
    show ep5 angels_048 with d
    devilla "How do you know all that?" id ep5_14_angels_12144d95
    show ep5 angels_050 with d
    devilla "We have an agreement to send escorts to a charity ball." id ep5_14_angels_03feee92
    devilla "They always ask for our girls." id ep5_14_angels_8f847d08
    show ep5 angels_047 with d
    simon "So, the Hell Angels are going to be there?" id ep5_14_angels_b8bda355
    show ep5 angels_048 with d
    devilla "Perhaps..." id ep5_14_angels_ba7f61e2
    devilla "Where are you going with this?" id ep5_14_angels_984bc697


    menu:
        "Ask Devilla for help"(True):
            $ ep5_angels_ask_devilla_for_help = True
            $ player_choice("ep5_angels_ask_devilla_for_help:true")

            if choice_made("ep3_07_cafe2_agree_to_help") or choice_made("ep4_susanhome_accept_the_job"):
                show ep5 angels_051 with d
                simon "(I've already got my ticket to the ball.)" id ep5_14_angels_227cbffd
                simon "(But it would be nice to have some help on the inside.)" id ep5_14_angels_eaa73452
            else:

                show ep5 angels_052 with d
                simon "Could you help me get into the ball?" id ep5_14_angels_480c192e
                show ep5 angels_053 with d
                devilla "Get you in?" id ep5_14_angels_c22c7e8a
                devilla "What would you want to do at a charity ball?" id ep5_14_angels_7d707ef5

            $ debug_other_paths()

            show ep5 angels_054 with d
            simon "I'm looking for someone... Maybe you could help." id ep5_14_angels_9f303469
            show ep5 angels_055 with wiperight
            devilla "Who are you looking for? Do I know them?" id ep5_14_angels_520bdcb8
            show ep5 angels_056 with d
            simon "It's my father." id ep5_14_angels_c0b84418
            simon "He disappeared a few years back, and this ball is in his honor." id ep5_14_angels_da500831
            show ep5 angels_057 with d
            devilla "I see..." id ep5_14_angels_6145f241

            if choice_made("ep3_04_challenge_won"):
                show ep5 angels_058 with d
                devilla "Well normally... I'm not one to grant favors." id ep5_14_angels_dd61705f
                devilla "But you passed our test, so you are entitled to a prize." id ep5_14_angels_3d9326cc
                show ep5 angels_059 with d
                devilla "Which you used to free your friend..." id ep5_14_angels_45cdb5a3
                show ep5 angels_060 with d
                devilla "But Angela kept insisting it was a noble request and that you deserved better." id ep5_14_angels_8632118b
                devilla "Honestly, I don't know what she sees in you..." id ep5_14_angels_a3eb5f84
                devilla "But for her sake, I'll help." id ep5_14_angels_81b30806
                show ep5 angels_061 with d
                simon "I have to admit I'm a bit offended, but I accept the help." id ep5_14_angels_3a89d8f3
                show ep5 angels_062 with d
                devilla "I guess you're not so bad." id ep5_14_angels_709bab3a

                if choice_made("ep3_07_cafe2_agree_to_help") or choice_made("ep4_susanhome_accept_the_job"):
                    show ep5 angels_063 with d
                    simon "I'll be at the ball, so let me give you some details about my father." id ep5_14_angels_d54560c1
                    simon "Anything you can learn will help me out." id ep5_14_angels_bc098ca2
                    show ep5 angels_064 with d
                    devilla "We've got a deal." id ep5_14_angels_575658a7
                    show ep5 angels_086 with d
                    devilla "Anyway..."
                else:

                    show ep5 angels_065 with d
                    devilla "Anyway, let's meet up tomorrow at 8 pm in front of the club." id ep5_14_angels_9b9012de
                    devilla "From there, we can head to the ball." id ep5_14_angels_4b1d5175
                    show ep5 angels_066 with d
                    simon "Thank you, Devilla."
                    show ep5 angels_086 with d
                    devilla "Anyway..."

                $ debug_other_paths()
            else:


                show ep5 angels_067 with d
                devilla "I can't do that though." id ep5_14_angels_043930e7
                devilla "If they found out we were smuggling someone into the dance, that would destroy our reputation." id ep5_14_angels_b40a00a3
                show ep5 angels_068 with d
                devilla "Unless..." id ep5_14_angels_2ff56dea
                show ep5 angels_069 with d
                simon "Unless...?" id ep5_14_angels_a3f21b6f
                show ep5 angels_070 with d
                devilla "Unless you were an employee of ours." id ep5_14_angels_6a835739
                show ep5 angels_071 with d
                simon "I feel like you're tricking me into working for you." id ep5_14_angels_d2717f2e
                show ep5 angels_070 with d
                devilla "Oh, no. No tricks." id ep5_14_angels_0e82569c
                devilla "It's straight up blackmail." id ep5_14_angels_cd290aab
                devilla "So, what do you say?" id ep5_14_angels_c3d9d1aa


                menu:
                    "Accept Devilla's job"(True):
                        $ ep5_angels_accept_devillas_job = True
                        $ player_choice("ep5_angels_accept_devillas_job:true")
                        show ep5 angels_063 with d
                        simon "Fine." id ep5_14_angels_2eac89ff
                        simon "I don't think I have much of a choice at this point." id ep5_14_angels_f787052c
                        show ep5 angels_064 with d
                        devilla "Excellent!" id ep5_14_angels_4eedcb82
                        show ep5 angels_072 with d
                        devilla "You just made a deal with Devilla!" id ep5_14_angels_aea754d1
                        show ep5 angels_073 with d
                        simon "Huh...?" id ep5_14_angels_e3927361
                        show ep5 angels_086 with d
                        devilla "Anyway..."
                    "Don't accept the job":

                        $ ep5_angels_not_accept_the_job = True
                        $ player_choice("ep5_angels_not_accept_the_job:true")
                        simon "I don't know..." id ep5_14_angels_295854cb
                        simon "I think I'll try another way." id ep5_14_angels_bd52c50d
                        devilla "Your loss." id ep5_14_angels_ece4a929
                        show ep5 angels_086 with d
                        devilla "Anyway..."



                $ debug_other_path()

            $ debug_other_paths()


            show ep5 angels_087 with d
            devilla "There's still a lot of work to be done."
            show ep5 angels_088 with d
            devilla "By the way, I heard you met our new girl."
            show ep5 angels_089 with d
            simon "Are you talking about Gabby?"
            show ep5 angels_090 with d
            devilla "That's right."
            devilla "What did you think of her?"
            show ep5 angels_091 with d
            simon "She's cool." id ep5_14_angels_300cd731
            simon "I hope she makes a good addition to the team."
            show ep5 angels_090 with d
            devilla "Good to hear."
            devilla "If you meet any other girls with potential, let me know."
            show ep5 angels_092 with d
            devilla "I imagine you must have some pretty friends."
            show ep5 angels_093 with d
            simon "Well, I do, but..."
            show ep5 angels_094 with d
            simon "Wait, potential for what?"
            show ep5 angels_095 with d
            devilla "Hmm..."
            show ep5 angels_096 with d
            devilla "That's a discussion for another time."
            devilla "Bye, [name]..."
            show ep5 angels_097 with d
            simon "(I'd better be getting out of here too.)"
        "Don't ask Devilla for help":



            $ ep5_angels_dont_ask_devilla_for_help = True
            $ player_choice("ep5_angels_dont_ask_devilla_for_help:true")
            show ep5 angels_074 with d
            simon "Never mind." id ep5_14_angels_6e333e63
            simon "I just had this crazy idea, but it's really nothing." id ep5_14_angels_25374e1e
            show ep5 angels_075 with d
            devilla "Well, there's still a lot of work to be done."
            show ep5 angels_076 with d
            devilla "By the way, I heard you met our new girl."
            show ep5 angels_077 with d
            simon "Are you talking about Gabby?"
            show ep5 angels_078 with d
            devilla "That's right."
            devilla "What did you think of her?"
            show ep5 angels_079 with d
            simon "She's cool." id ep5_14_angels_ca032a38
            simon "I hope she makes a good addition to the team."
            show ep5 angels_078 with d
            devilla "Good to hear."
            devilla "If you meet any other girls with potential, let me know."
            show ep5 angels_080 with d
            devilla "I imagine you must have some pretty friends."
            show ep5 angels_081 with d
            simon "Well, I do, but..."
            show ep5 angels_082 with d
            simon "Wait, potential for what?"
            show ep5 angels_083 with d
            devilla "Hmm..."
            show ep5 angels_084 with d
            devilla "That's a discussion for another time."
            devilla "Bye, [name]..."
            show ep5 angels_085 with d
            simon "(I'd better be getting out of here too.)"



    $ debug_other_path()

    stop music fadeout 5

    jump ep5_15_lilycall
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
