
label ep5_02_dylanday:


    show ep5 dylanday_001 with long_fade
    simon "Umm..." id ep5_02_dylanday_92c095c3
    simon "(Who's hugging me?)" id ep5_02_dylanday_f99c2747
    show ep5 dylanday_002 with d
    simon "Hmm?!" id ep5_02_dylanday_7fe7c894
    play music porch_fun volume 0.25
    show ep5 dylanday_003 with hpunch
    simon "AAAAAAAAHHHH!" id ep5_02_dylanday_263c9650
    show ep5 dylanday_004 with hpunch
    dylan "AAAAAAAAAAAAAAH!" id ep5_02_dylanday_9e828f11
    show ep5 dylanday_005 with d
    dylan "Dude, what happened?" id ep5_02_dylanday_f5004049
    show ep5 dylanday_006 with d
    simon "What are you doing??" id ep5_02_dylanday_431ed527
    show ep5 dylanday_007 with d
    dylan "I usually cuddle up with my pillow when I sleep..." id ep5_02_dylanday_15b4e12b
    show ep5 dylanday_008 with d
    dylan "I probably didn't notice the difference." id ep5_02_dylanday_160cc0da
    show ep5 dylanday_009 with d
    simon "Do I look like a pillow to you?" id ep5_02_dylanday_0a4027ba
    show ep5 dylanday_010 with d
    dylan "No... but you're about the same size..." id ep5_02_dylanday_261903d2
    show ep5 dylanday_011 with d
    simon "The same size?" id ep5_02_dylanday_a8cae240
    simon "Do you happen to have one of those anime girl pillows?" id ep5_02_dylanday_29456b40
    show ep5 dylanday_012 with d
    dylan "No!"
    show ep5 dylanday_013 with d
    simon "Wait..." id ep5_02_dylanday_320b9734
    simon "When we first met, you said you weren't good at talking to girls." id ep5_02_dylanday_c06b21b7
    simon "I'm sure you have one of those pillows now." id ep5_02_dylanday_9f10fbdd
    show ep5 dylanday_014 with d
    simon "You've definitely got one!" id ep5_02_dylanday_e9748f93
    show ep5 dylanday_015 with d
    simon "Where is it?" id ep5_02_dylanday_527cb9b5
    show ep5 dylanday_016 with d
    simon "Is it over here?" id ep5_02_dylanday_b4ae82bd
    show ep5 dylanday_017 with d
    dylan "No!"
    dylan "Dude!" id ep5_02_dylanday_f31d1567

    $ renpy.music.set_volume(0, delay=2)

    play sound door_opening 
    queue sound magical_twinkle1

    show ep5 dylanday_018 with d
    simon "Wow..." id ep5_02_dylanday_063ea2e3
    show ep5 dylanday_019 with d
    simon "What's this all about?" id ep5_02_dylanday_6b1567ed
    show ep5 dylanday_020 with d
    dylan "Um... It's just stuff from the book club." id ep5_02_dylanday_01a562ae
    show ep5 dylanday_021 with d
    simon "Doesn't look like it." id ep5_02_dylanday_4544b904
    show ep5 dylanday_022 with d
    simon "Are these yours?" id ep5_02_dylanday_a2f9adb5
    simon "Have you read all of these?" id ep5_02_dylanday_2eda3df4
    play music_2 green_sleeves_a_minor volume 0.3
    show ep5 dylanday_023 with d
    dylan "Yeah..." id ep5_02_dylanday_88a9c0c7
    show ep5 dylanday_024 with d
    dylan "When I was younger, reading was my only hobby." id ep5_02_dylanday_759faf16
    show ep5 dylanday_025 with d
    dylan "I told you, I wasn't known for my social skills..." id ep5_02_dylanday_0a6fb7eb
    show ep5 dylanday_026 with d
    simon "Wow, I had a very different idea of who you were." id ep5_02_dylanday_28c4cc9b
    simon "I didn't know you had an actual interest in books." id ep5_02_dylanday_59e86519
    show ep5 dylanday_027 with d
    dylan "I really like to read." id ep5_02_dylanday_6546ad73
    show ep5 dylanday_028 with d
    simon "That's awesome, man." id ep5_02_dylanday_56c8fb65
    show ep5 dylanday_029 with d
    simon "Let me see what you've got here..." id ep5_02_dylanday_0935d492
    show ep5 dylanday_030 with d
    simon "Dylan." id ep5_02_dylanday_1f724e9f
    show ep5 dylanday_031 with d
    dylan "Yes?" id ep5_02_dylanday_d9c17b34
    show ep5 dylanday_032 with d
    stop music_2 fadeout 0.5
    play sound record_player_needle_scratch volume 0.5
    simon "This is hentai." id ep5_02_dylanday_b5d5bfe5

    $ renpy.music.set_volume(0.35, delay=0.5)

    show ep5 dylanday_033 with d
    dylan "Oh yeah. This is from one of the best series I own." id ep5_02_dylanday_d543ddc7
    show ep5 dylanday_034 with d
    dylan "Good choice, bro." id ep5_02_dylanday_34d580e1
    show ep5 dylanday_035 with d
    simon "My god, Dylan." id ep5_02_dylanday_abf1d4cf
    show ep5 dylanday_036 with d
    simon "Suddenly, pretending to be Russian isn't your worst sin." id ep5_02_dylanday_0088dd64
    show ep5 dylanday_037 with d
    dylan "It's good to see you having fun, bro." id ep5_02_dylanday_fe85a4e8
    show ep5 dylanday_038 with d
    dylan "You were kind of in shock when you got here yesterday." id ep5_02_dylanday_b04c984c
    show ep5 dylanday_039 with d
    simon "Yeah... I have to find a way of attending that ball." id ep5_02_dylanday_8e1a4cba
    show ep5 dylanday_040 with d
    dylan "Bro... I know this ball thing is really important to you." id ep5_02_dylanday_3f36fcd0
    dylan "I totally get it." id ep5_02_dylanday_9c978743
    dylan "And I know you'll find a way to get there." id ep5_02_dylanday_62b71b6f
    show ep5 dylanday_041 with d
    dylan "But you also have your education to think about." id ep5_02_dylanday_9084cb23
    dylan "You have to think about what comes next." id ep5_02_dylanday_6e88aa1f
    show ep5 dylanday_042 with d
    simon "Like parties and girls?" id ep5_02_dylanday_82549671
    show ep5 dylanday_043 with d
    dylan "You have to think about the future." id ep5_02_dylanday_8f1e59ec
    dylan "About what's to come after you find out what happened to your father." id ep5_02_dylanday_860a8c8d
    dylan "You have to think about your studies." id ep5_02_dylanday_d36417b9
    show ep5 dylanday_044 with d
    simon "Oh..." id ep5_02_dylanday_d3eabd74
    show ep5 dylanday_045 with d
    simon "I don't think I've ever really stopped to think about what comes next." id ep5_02_dylanday_11d7f4fb
    show ep5 dylanday_046 with d
    dylan "It might be good to start thinking about that now." id ep5_02_dylanday_10f123f4
    show ep5 dylanday_047 with d
    dylan "And girls too." id ep5_02_dylanday_b05189d2
    show ep5 dylanday_048 with d
    dylan "Do you know where we'll find both?" id ep5_02_dylanday_ffa73629
    dylan "At college!" id ep5_02_dylanday_1cf6c492
    show ep5 dylanday_049 with d
    dylan "Come on. Let's ride." id ep5_02_dylanday_5138582d
    stop music fadeout 5

    jump ep5_08_universitydylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
