label ep5_20_beerpong:





play music the_comeback fadein 3 volume 0.4
show ep5 beerpong_001 with wipeleft
dylan "Now you don't look like a little lost freshman anymore." id ep5_20_beerpong_3fbcc0a4
show ep5 beerpong_002 with d
dylan "Come on. Beer pong's probably already started, and I'm ready to kick your ass!" id ep5_20_beerpong_c13f1b7b
simon "We'll see about that!" id ep5_20_beerpong_b724bb79
show ep5 beerpong_003 with d
simon "But, hold on. Who are our partners going to be?" id ep5_20_beerpong_c70727bc
show ep5 beerpong_004 with d
dylan "Huh?" id ep5_20_beerpong_8511f247
show ep5 beerpong_005 with d
simon "Partners. Don't you play in teams of two?" id ep5_20_beerpong_ef42dd45
show ep5 beerpong_006 with d
dylan "I met up with Chloe before. She can play with me." id ep5_20_beerpong_da711004
dylan "Now it's up to you to find a partner." id ep5_20_beerpong_a98c839c
dylan "How about Julia?" id ep5_20_beerpong_caa54b85
show ep5 beerpong_007 with vpunch
simon "Julia?!" id ep5_20_beerpong_2fb65d71
simon "Right! I left her alone at the pool!" id ep5_20_beerpong_157e0dfa
show ep5 beerpong_008 with d
simon "Hey! Where are you?" id ep5_20_beerpong_e8154dd7
simon "I need a professional beer pong partner." id ep5_20_beerpong_20c1d53c
show ep5 beerpong_009 with d
julia "I'm by the pool." id ep5_20_beerpong_044c8ddb
simon "Want to come play with me?" (what_italic=True)
julia "Are you trying to get me drunk, Twinkle Toes? I'm only nineteen." id ep5_20_beerpong_96aa8630
show ep5 beerpong_003 with d
simon "(True. Better not risk it...)" id ep5_20_beerpong_610b9260
simon "Julia's out." id ep5_20_beerpong_e79f6769
show ep5 beerpong_002 with d
dylan "I'll tell Chloe to bring a friend then." id ep5_20_beerpong_05786bbc


show ep5 beerpong_010 with d
dylan "The beer pong challenge is about to begin! We need a referee!" (what_bold=True)
show ep5 beerpong_011 with d
sue "I'll be the ref." id ep5_20_beerpong_4404fa6e
show ep5 beerpong_012 with d
simon "Sue, what are you doing here?" id ep5_20_beerpong_782fbb62

if chose("ep4_susanhome_suespy1") or chose("ep4_susanhome_suespy2"):
    show ep5 beerpong_013 with d
    sue "I'm not talking to you, fuckface." id ep5_20_beerpong_f0b73018
    show ep5 beerpong_014 with d
    simon "Sue, are you still mad at me?" id ep5_20_beerpong_e7a63bf3
    simon "Can't we move past this?" id ep5_20_beerpong_1b9a5215
    show ep5 beerpong_013 with d
    sue "Well, I am stuck at this university with you." id ep5_20_beerpong_3388cadb
    sue "So we'll see." id ep5_20_beerpong_322f826f
    sue "Who knows? Maybe your situation will improve if you win." id ep5_20_beerpong_332362e3
else:

    show ep5 beerpong_015 with d
    sue "Remember when I said I was still deciding which college to attend?" id ep5_20_beerpong_32c751ef
    sue "In the end, I decided to stay in Minerva Bay." id ep5_20_beerpong_9e6ccc35

$ debug_other_path()

show ep5 beerpong_016 with d
simon "Glad you're staying." id ep5_20_beerpong_1d1874ce
simon "We'll end up seeing a whole lot more of each other." id ep5_20_beerpong_527a202b
show ep5 beerpong_017 with d
sue "Believe me, I hope that's not the case." id ep5_20_beerpong_a656e8ea
sue "In fact, if you see me in the hallways, you'd better pretend you don't even know me." id ep5_20_beerpong_bbd49747
sue "The last thing I need is to have a sad little puppy dog following me around." id ep5_20_beerpong_f55c9a00
if chose("ep2_sue_stop"):
    show ep5 beerpong_018 with d
    simon "All right. We can keep meeting in secret if you want." id ep5_20_beerpong_e90b61a0
show ep5 beerpong_015 with d
sue "Just get over yourself." id ep5_20_beerpong_e2621926
show ep5 beerpong_018_1 with d
simon "So, why are you here anyway?" id ep5_20_beerpong_d17f76df
show ep5 beerpong_019 with d
sue "It's a party. Everyone's here." id ep5_20_beerpong_228f6d33
sue "Including your stupid friends." id ep5_20_beerpong_c216624e
show ep5 beerpong_020 with d
chloe "We're here!" id ep5_20_beerpong_46580d9d
show ep5 beerpong_021 with d
alyssa "Hey, [name]!" id ep5_20_beerpong_620ff672
alyssa "I can't believe the three of us are finally able to do something together!" id ep5_20_beerpong_94a9d6c3
show ep5 beerpong_022 with d
sue "The match will now begin!" id ep5_20_beerpong_3e54cee0
sue "I'll pour the beer." id ep5_20_beerpong_cff6f4e3

if not chose("ep2_sue_stop") and chose("ep3_sat_chloesex_remove_clothes") and chose("ep4_alyssasex_take_the_step"):
    show ep5 beerpong_023 with d
    simon "(What the fuck...)" id ep5_20_beerpong_4287598d
    simon "(They're all here... at the same time!)"
    show ep5 beerpong_024 with d
    dylan "Dude, what's going on?"
    dylan "Did you just see a ghost?"
    show ep5 beerpong_025 with d
    simon "How do they all know each other?"
    show ep5 beerpong_024 with d
    dylan "I don't know, man. It's a party. The whole city's here."
    show ep5 beerpong_026 with d
    dylan "Relax. It's not like you've fucked them all or something." id ep5_20_beerpong_77132c09
    simon "About that..." id ep5_20_beerpong_71d93eb4
    show ep5 beerpong_027 with d
    dylan "Have you fucked every one of them?!" id ep5_20_beerpong_b28e2519
    simon "Keep your voice down, Dylan!" id ep5_20_beerpong_53f6cdaa
    dylan "Dude, teach me your secrets." id ep5_20_beerpong_0165b2be
else:

    show ep5 beerpong_028 with d
    simon "(They're all here... at the same time!)"
    show ep5 beerpong_029 with d
    dylan "Dude, what's going on?"
    dylan "Did you just see a ghost?"
    show ep5 beerpong_025 with d
    simon "How do they all know each other?"
    show ep5 beerpong_029 with d
    dylan "I don't know, man. It's a party. The whole city's here."

$ debug_other_path()

show ep5 beerpong_030 with d
sue "Are we going to play? Or are we going to stand around and gossip all night?" id ep5_20_beerpong_29bb9528
show ep5 beerpong_031 with d
dylan "Hmm..." id ep5_20_beerpong_3b57c19d
show ep5 beerpong_032 with d
alyssa "Partners then?" id ep5_20_beerpong_5aaebc9c
simon "Let's bring it to them!" id ep5_20_beerpong_fb467837
show ep5 beerpong_033 with d
sue "Let the game begin!" id ep5_20_beerpong_5caa23da


play music anything_you_want fadein 2 volume 0.37
show ep5 beerpong_034 with vpunch
pause 1.0
show ep5 beerpong_035 with d
chloe "What's going on, Dylan?" id ep5_20_beerpong_1bce38fc
chloe "Are you okay?" id ep5_20_beerpong_ae3c7a93
dylan "[name] thinks he's the king." (what_bold=True)
dylan "Let's kick his ass." (what_bold=True)
show ep5 beerpong_036 with d
chloe "You've got the right person on your team." id ep5_20_beerpong_ce338e30
chloe "Beer pong is all about math." id ep5_20_beerpong_f2b2962a
chloe "No one beats me at that." id ep5_20_beerpong_1c1f1ca9

show ep5 beerpong_037 with d
pause 1.0
show ep5 beerpong_038 with d
pause 1.0

show ep5 beerpong_039 with d
pause 1.0
show ep5 beerpong_040 with d
pause 1.0

show ep5 beerpong_041 with d
pause 1.0
show ep5 beerpong_042 with d
simon "I figured you didn't drink." id ep5_20_beerpong_e196fc45
alyssa "I do a little, just because it's a party." id ep5_20_beerpong_b84d16af
play sound ball_bouncing_1
show ep5 beerpong_043 with d
alyssa "Oh no!" id ep5_20_beerpong_d1c107ed
show ep5 beerpong_044 with d
simon "Don't worry, we'll bounce right back." id ep5_20_beerpong_3aa23e2f
show ep5 beerpong_045 with d
dylan "That's what they say, right?" (what_bold=True)
dylan "Bad luck in the game, good luck in love." (what_bold=True)
show ep5 beerpong_046 with d
chloe "I think you've got that backward." id ep5_20_beerpong_6ff15188
dylan "Which side are you on?" (what_bold=True)

show ep5 beerpong_047 with d
chloe "On the winning side!" id ep5_20_beerpong_72d7ba6e
show ep5 beerpong_038 with d
pause
show ep5 beerpong_048 with d
pause 0.75
show ep5 beerpong_048_1 with d
pause 0.75
show ep5 beerpong_048_2 with d
pause 0.75
show ep5 beerpong_048_3 with d
pause 1.0
show ep5 beerpong_049 with d
simon "And here I am, thinking you didn't know how to play, Dylan!" id ep5_20_beerpong_896e0c56
simon "You sure are good at faking stuff!" id ep5_20_beerpong_ee5f8792
show ep5 beerpong_050 with d
dylan "I'm not the only one faking things at this table." (what_bold=True)
show ep5 beerpong_051 with d
simon "Dude, what are you talking about?" id ep5_20_beerpong_73d70a59
show ep5 beerpong_052 with d
dylan "I had no idea you were Mr. Popular." (what_bold=True)
dylan "From the looks of things, it seems like you never needed my help fitting in." (what_bold=True)
play sound ball_bouncing_2 volume 0.7
show ep5 beerpong_053 with d
chloe "Dylan! They're going to catch up with us if you keep that up!" id ep5_20_beerpong_87f027ee
stop sound fadeout 2
show ep5 beerpong_054 with d
chloe "What's going on between the two of you?" id ep5_20_beerpong_41847e0d
show ep5 beerpong_055 with d
dylan "Nothing, Chloe..." (what_bold=True)
show ep5 beerpong_056 with d
alyssa "What's going on between you and Dylan?" id ep5_20_beerpong_ab8411b9
show ep5 beerpong_057 with d
simon "I don't know." id ep5_20_beerpong_4ec05ed7
simon "Let's just focus on the game. We're losing." id ep5_20_beerpong_0b0954df

show ep5 beerpong_058 with d
pause 1.0
show ep5 beerpong_059 with d
pause 1.0
show ep5 beerpong_060 with d
dylan "How are things between you and [name]?" (what_bold=True)
play sound ball_bouncing_3 volume 0.7
show ep5 beerpong_061 with d
chloe "Look at what you made me do, Dylan!" id ep5_20_beerpong_0de12dc2
dylan "How is that my fault?" (what_bold=True)
stop sound fadeout 2
show ep5 beerpong_062 with d
pause 1.0
show ep5 beerpong_040_1 with d
pause 1.0
show ep5 beerpong_063 with d
alyssa "We're all tied up." id ep5_20_beerpong_ed2ee4dc
simon "Dylan needs to miss this one." id ep5_20_beerpong_40d8820c
show ep5 beerpong_064 with d
dylan "I won't miss. I can't." (what_bold=True)
chloe "Calm your nerves, Dylan. You can do this!" id ep5_20_beerpong_8b63a588
play sound ball_bouncing_4 volume 0.7
show ep5 beerpong_065 with d
dylan "Shit! Now we're going to lose!" (what_bold=True)
stop sound fadeout 2
show ep5 beerpong_066 with d
chloe "But [name] could still miss." id ep5_20_beerpong_e260175d
show ep5 beerpong_067 with d
simon "(I should let Dylan win this one...)" id ep5_20_beerpong_9325bea4
simon "(He would be happy to get all that attention.)" id ep5_20_beerpong_49e1fd8a
simon "(But I would also like to win.)" id ep5_20_beerpong_268b93ea

menu:
    "Miss on purpose"(True):
        $ save("ep5_beerpong_miss_the_ball_on_purpose")
        $ points_dylan += 1
        play sound ball_bouncing_1 volume 0.7
        show ep5 beerpong_068 with d
        alyssa "Oh no!" id ep5_20_beerpong_37d76742
        show ep5 beerpong_069 with d
        dylan "Please don't miss." (what_bold=True)
        show ep5 beerpong_070 with d
        chloe "Just let me concentrate." id ep5_20_beerpong_64e3c0ce

        show ep5 beerpong_071 with vpunch
        pause 1.0
        show ep5 beerpong_072 with d
        sue "The winners are: Dylan and Chloe!" id ep5_20_beerpong_25275890
        sue "What's the punishment for the losers?"
        dylan "Body shots for the both of them!" (what_bold=True)
        show ep5 beerpong_073 with d
        simon "Is that okay with you?" id ep5_20_beerpong_0591043f
        alyssa "I... umm..." id ep5_20_beerpong_8bcef915
        alyssa "Is there another punishment we can do?" id ep5_20_beerpong_09e83a98
        show ep5 beerpong_074 with vpunch
        dylan "A punishment is a punishment!" (what_bold=True)
        chloe "Dylan, leave her alone!" id ep5_20_beerpong_d201f686
        show ep5 beerpong_075 with d
        alyssa "Sorry, guys. I think I should go..." id ep5_20_beerpong_bdfb793d
        show ep5 beerpong_076 with d
        sue "If she doesn't want to, [name] has to drink both shots." id ep5_20_beerpong_c29943ef
        show ep5 beerpong_077 with d
        pause 0.75
        show ep5 beerpong_078 with d
        dylan "Just don't drink too much, yeah?" (what_bold=True)
        dylan "It didn't go too well last time." (what_bold=True)
        show ep5 beerpong_079 with d
        simon "Look who's talking." id ep5_20_beerpong_45b3bc22
        show ep5 beerpong_080 with d
        pause 1.0
    "Try to win":

        $ save("ep5_beerpong_hit_the_ball")

        show ep5 beerpong_081 with vpunch
        alyssa "We won! Great job, [name]!" id ep5_20_beerpong_67775fb0
        show ep5 beerpong_082 with d
        pause 1.0
        show ep5 beerpong_083 with d
        sue "The winners are: [name] and Alyssa." id ep5_20_beerpong_b0c60001
        sue "What's the punishment for the losers?"
        show ep5 beerpong_084 with d
        simon "They have to... umm..." id ep5_20_beerpong_fbbafa93
        simon "They, uh..." id ep5_20_beerpong_3dc0280f
        show ep5 beerpong_083 with d
        sue "Since you can't choose, I'll pick the punishment!" id ep5_20_beerpong_66f82c21
        show ep5 beerpong_085 with vpunch
        sue "They have to kiss!" id ep5_20_beerpong_92cbf2b7
        sue "... Or they'll have to take two shots." id ep5_20_beerpong_3180feea
        show ep5 beerpong_086 with d
        dylan "What do you want to do, Chloe?" (what_bold=True)
        chloe "Sorry, Dylan." id ep5_20_beerpong_5d9518aa
        show ep5 beerpong_087 with d
        pause 1.0
        show ep5 beerpong_082 with d
        pause 1.0
        show ep5 beerpong_088 with d
        pause 1.0

$ debug_other_path()
stop music fadeout 3
jump ep5_21_maddylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
