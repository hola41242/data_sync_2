
label ep5_03_juliaday:

    play sound suburb_morning volume 0.5 fadein 5
    show ep5 juliaday_001_1 with long_fade
    pause
    stop sound fadeout 5
    show ep5 juliaday_001 with medium_fade
    play music dusty_morning volume 0.25
    julia "Good morning, Twinkle Toes!" id ep5_03_juliaday_df2ac01b
    show ep5 juliaday_002 with d
    simon "(Huh? Am I still dreaming?)" id ep5_03_juliaday_0e80445c
    show ep5 juliaday_003 with d
    julia "You sure take your sweet time getting up, don't you?" id ep5_03_juliaday_bf602da4
    show ep5 juliaday_004 with d
    simon "(Oh, that's right. I snuck into Julia's last night.)" id ep5_03_juliaday_b4eada30
    show ep5 juliaday_005 with d
    simon "Good morning, Julia." id ep5_03_juliaday_0b259874
    show ep5 juliaday_006 with d
    julia "Finally!" id ep5_03_juliaday_1dfa8c0d
    show ep5 juliaday_007 with d
    simon "Were you waiting for me to wake up?" id ep5_03_juliaday_bffe65ed
    show ep5 juliaday_008 with d
    julia "Yup. You look so cute when you sleep." id ep5_03_juliaday_7938202c
    show ep5 juliaday_009 with d
    julia "Apart from the fact that you were, like, drooling all over the place." id ep5_03_juliaday_adf1a83b
    show ep5 juliaday_010 with d
    julia "Aside from that, you sleep like a baby." id ep5_03_juliaday_2ea3ebb3
    show ep5 juliaday_011 with d
    simon "What? I don't drool!" id ep5_03_juliaday_008dd4e7
    show ep5 juliaday_012 with d
    simon "*Whispers.* Oh shit. Was I too loud?" id ep5_03_juliaday_acb214a6
    show ep5 juliaday_013 with d
    julia "Don't worry. My mom's not home." id ep5_03_juliaday_764f4ee6
    play sound bed_movement_1 volume 3.0

    show ep5 juliaday_014 with d
    simon "Oh. Then I'd better leave before she gets back, right?" id ep5_03_juliaday_1e01f410

    if choice_made('ep2_julia_kiss'):
        show ep5 juliaday_015 with d
        julia "Or..." id ep5_03_juliaday_fcea6707
        show ep5 juliaday_016 with d
        julia "We can finish what we started the other day." id ep5_03_juliaday_4e6ffe48
        show ep5 juliaday_017 with d
        julia "Are you sure you want to leave?" id ep5_03_juliaday_fdaa22a9
        show ep5 juliaday_018 with d
        simon "I guess I could hang around a little longer." id ep5_03_juliaday_d7c3b6a1
        show ep5 juliaday_019 with d
        julia "So... where were we?" id ep5_03_juliaday_cf379e7a
        stop music fadeout 5
        show ep5 juliaday_020 with d
        simon "I think it was something more or less..." id ep5_03_juliaday_af58eb35
        play music heart_made_of_pixels volume 0.25 fadein 3
        play sound dress_shirt volume 0.7
        show ep5 juliaday_021 with d
        simon "... like this!" id ep5_03_juliaday_9bc90f31
        show ep5 juliaday_022 with d
        julia "Ah..." id ep5_03_juliaday_5e76aabf
        show ep5 juliaday_023 with d
        simon "Too much?" id ep5_03_juliaday_e62eaec1
        show ep5 juliaday_024 with d
        julia "No, no." id ep5_03_juliaday_957d9a9b
        julia "Please keep going... It's just that..." id ep5_03_juliaday_3399c4b7
        play sound bed volume 1.5 
        show ep5 juliaday_025 with d
        pause
        show ep5 juliaday_026 with d
        julia "I can't believe we're finally doing this." id ep5_03_juliaday_634a89a7
        julia "I've been waiting so long." id ep5_03_juliaday_e3d91820
        show ep5 juliaday_027 with d
        simon "We don't have to rush it." id ep5_03_juliaday_9510e1df
        show ep5 juliaday_028 with d
        julia "I know." id ep5_03_juliaday_ae691c05
        show ep5 juliaday_029 with d
        julia "But I think that's what I want." id ep5_03_juliaday_59cff512
        julia "I can barely contain myself." id ep5_03_juliaday_cc6be2e7
        show ep5 juliaday_030 with d
        simon "I'm glad you feel that way." id ep5_03_juliaday_66a3960a
        show ep5 juliaday_031 with d
        julia "I want to..." id ep5_03_juliaday_0ed1c33b
        show ep5 juliaday_032 with d
        julia "I want to do things with you." id ep5_03_juliaday_2d930771
        show ep5 juliaday_033 with d
        julia "Things I've never done before." id ep5_03_juliaday_e1981df6
        show ep5 juliaday_034 with d
        simon "(She really is excited.)" id ep5_03_juliaday_69d35636
        show ep5 juliaday_035 with d
        simon "(And there's no one here.)" id ep5_03_juliaday_d41602dc
        simon "(Even better!)" id ep5_03_juliaday_628ab076
        show ep5 juliaday_036 with d
        julia "Huh?" id ep5_03_juliaday_101332d7
        show ep5 juliaday_037 with d
        julia "I feel something down here!" id ep5_03_juliaday_3a8e1258
        show ep5 juliaday_038 with d
        julia "I..." id ep5_03_juliaday_5698db07
        show ep5 juliaday_039 with d
        julia "I want you to feel me too!" id ep5_03_juliaday_ef92127f
        show ep5 juliaday_040 with d
        julia "Umm..." id ep5_03_juliaday_3eb0dc8c
        show ep5 juliaday_041 with d
        simon "You have an amazing body." id ep5_03_juliaday_63884f41
        simon "No need to feel ashamed of it." id ep5_03_juliaday_dce8006f
        show ep5 juliaday_042 with d
        julia "Do you really think so?" id ep5_03_juliaday_2de72afa
        show ep5 juliaday_043 with d
        simon "I do." id ep5_03_juliaday_30996514
        show ep5 juliaday_044 with d
        simon "But let me go first." id ep5_03_juliaday_eee47acf
        play sound dress_shirt volume 0.8
        show ep5 juliaday_045 with d
        simon "Remember these?" id ep5_03_juliaday_019bd237
        show ep5 juliaday_046 with d
        julia "Whoa. I almost forgot about those..." id ep5_03_juliaday_b7c69b45
        show ep5 juliaday_047 with d
        simon "Right? And yet I'm not ashamed of showing them off." id ep5_03_juliaday_3937d389
        simon "There's no reason for you to be shy either." id ep5_03_juliaday_d2d8b78e
        show ep5 juliaday_048 with d
        julia "You're right!" id ep5_03_juliaday_97749a8a
        show ep5 juliaday_049 with d
        julia "Well then..." id ep5_03_juliaday_fce4cd2b
        show ep5 juliaday_050 with d
        simon "Wow..." id ep5_03_juliaday_063ea2e3
        show ep5 juliaday_051 with d
        julia "Ack!" id ep5_03_juliaday_6584bc6c
        show ep5 juliaday_052 with d
        simon "You okay?" id ep5_03_juliaday_30ddab2a
        show ep5 juliaday_053 with d
        julia "Yeah... This is all just new territory for me..." id ep5_03_juliaday_1328d077
        show ep5 juliaday_054 with d
        simon "All right. I'll take things slow." id ep5_03_juliaday_9f4dc27b
        show ep5 juliaday_055 with d
        julia "(Oh my god... I'm burning up.)" id ep5_03_juliaday_da1f2cf2
        show ep5 juliaday_056 with d
        julia "Ah." id ep5_03_juliaday_79dba224
        julia "So warm." id ep5_03_juliaday_32307853
        show ep5 juliaday_057 with d
        julia "And so, so good..." id ep5_03_juliaday_ab33c406
        show ep5 juliaday_058 with d
        simon "(Since she's not that experienced, I think I should explore every part of her body first.)" id ep5_03_juliaday_e318c739
        show ep5 juliaday_059 with d
        simon "(That way, we can figure out what she likes best.)" id ep5_03_juliaday_632327ce
        show ep5 juliaday_060 with d
        julia "Ahh..." id ep5_03_juliaday_dbae195f
        show ep5 juliaday_061 with d
        julia "Are you really going to...?" id ep5_03_juliaday_2cc29b1b
        show ep5 juliaday_062 with d
        julia "With your tongue...?" id ep5_03_juliaday_afc6dfc8
        show ep5 juliaday_063 with d
        simon "(I think I found one of her spots!)" id ep5_03_juliaday_6b0709b4
        show ep5 juliaday_064 with d
        julia "Aaaahhh!" id ep5_03_juliaday_a9ac456a
        show ep5 juliaday_065 with d
        stop music
        play sound knock_knock
        juliamom "Honey? Are you okay in there?" id ep5_03_juliaday_3e215b41
        play music my_new_disease volume 0.2
        show ep5 juliaday_066 with d
        simon "(Fuck!)" id ep5_03_juliaday_dfbc171f
        show ep5 juliaday_067 with d
        julia "Yeah, mom. Just getting changed!" id ep5_03_juliaday_0deaffaf
        show ep5 juliaday_068 with d
        juliamom "All right." id ep5_03_juliaday_9adebfae
        show ep5 juliaday_069 with d
        simon "*Whispers.* Your mom's here?!" id ep5_03_juliaday_5800daf9
        show ep5 juliaday_070 with d
        julia "She probably just got back..." id ep5_03_juliaday_3b8a9d1f
        show ep5 juliaday_071 with d
        simon "Fuck..." id ep5_03_juliaday_10eba243
        show ep5 juliaday_072 with d
        julia "I guess I didn't think this through." id ep5_03_juliaday_9e1ed5eb
        julia "She was supposed to be out for a while!" id ep5_03_juliaday_4d08ee05
        show ep5 juliaday_073 with d
        julia "Hmm..." id ep5_03_juliaday_ebeb14c7
        show ep5 juliaday_074 with d
        simon "Oh, no. No fucking way!" id ep5_03_juliaday_43647da8
        show ep5 juliaday_075 with d
        julia "*Whispers.* It's either that or the classic hide-under-the-bed trick!" id ep5_03_juliaday_5f44c09c
        show ep5 juliaday_076 with d
        play sound knock_door_4_times
        juliamom "Julia? What's going on?" id ep5_03_juliaday_df514e8e
        show ep5 juliaday_077 with d
        simon "*Whispers.* Goddammit!" id ep5_03_juliaday_0f232e94

        menu:
            "Use the window":
                $ ep5_juliaday_go_out_the_window = True
                $ player_choice("ep5_juliaday_go_out_the_window:true")
                show ep5 juliaday_078 with d
                simon "(I'm going to regret this.)" id ep5_03_juliaday_20684b6f
                play sound door_open volume 1.5
                show ep5 juliaday_079 with d
                juliamom "Julia, are you okay?"
                show ep5 juliaday_080 with d
                julia "Aaagghhh! Mom! I said I'm changing!"
                show ep5 juliaday_081 with d
                juliamom "I heard you."
                juliamom "But I thought I heard a man's voice too." id ep5_03_juliaday_d624c658
                show ep5 juliaday_082 with d
                juliamom "At least close the windows if you're going to change." id ep5_03_juliaday_852abf4c
                show ep5 juliaday_083 with d
                juliamom "There are all sorts of sleazebags out there just waiting to catch a glimpse." id ep5_03_juliaday_3419f162
                show ep5 juliaday_084 with d
                simon "*Whistles.*"
            "Hide under the bed"(True):

                $ ep5_juliaday_hide_under_the_bed = True
                $ player_choice("ep5_juliaday_hide_under_the_bed:true")
                show ep5 juliaday_085 with d
                simon "*Whispers.* There's no room for me to fit down here!" id ep5_03_juliaday_fb0d7640
                show ep5 juliaday_086 with d
                julia "*Whispers.* I know!" id ep5_03_juliaday_e615d0b1
                julia "That's why I said to go out the window!" id ep5_03_juliaday_809a9e85
                julia "This was a terrible idea!" id ep5_03_juliaday_3a8c8a23
                show ep5 juliaday_087 with d
                juliamom "Julia?" id ep5_03_juliaday_6e5e3b91
                show ep5 juliaday_088 with d
                julia "*Whispers.* Hide!" id ep5_03_juliaday_9b1aa2d0
                play sound door_open volume 1.5
                show ep5 juliaday_079 with d
                juliamom "Julia, are you okay?"
                show ep5 juliaday_089_1 with d
                julia "Aaagghhh! Mom! I said I'm changing!"
                show ep5 juliaday_081 with d
                juliamom "I know."
                juliamom "But I thought I heard you talking to someone, and it sounded like..." id ep5_03_juliaday_b1648592
                show ep5 juliaday_089 with d:
                    yalign 1.0
                    ease 8 yalign 0.0
                pause
                show ep5 juliaday_089_2 with d:
                    yalign 0.0
                juliamom "... A man!" id ep5_03_juliaday_4ffb5739
                show ep5 juliaday_089_3 with d
                pause
                show ep5 juliaday_090 with d
                juliamom "Aaaaggghhh!" id ep5_03_juliaday_f6b69a89
                show ep5 juliaday_091 with d
                julia "Aaaaggghhh!" id ep5_03_juliaday_093c9ee8
                show ep5 juliaday_092 with d
                simon "AAAAAAAGGGGHHHHH!" id ep5_03_juliaday_dbb6f7aa
                show ep5 juliaday_093 with d
                juliamom "GET OVER HERE YOU LITTLE SHIT!" id ep5_03_juliaday_9754dd33
                play sound weapon_throw8
                show ep5 juliaday_093_1 with d
                pause
                show ep5 juliaday_093_3 with d
                simon "(My [name] senses are tingling!)" id ep5_03_juliaday_38675812
                show ep5 juliaday_093_2 with d
                pause
                show ep5 juliaday_094 with d
                simon "OH MY GOD! OH MY GOD!! OH MY GOD!!!" id ep5_03_juliaday_91ac17ba
                show ep5 juliaday_095 with d
                pause
                play sound match_blowing_whoosh volume 2 
                show ep5 juliaday_096 with d
                pause
                show ep5 juliaday_097 with d
                simon "Owwwiiee..." id ep5_03_juliaday_ef925772
                show ep5 juliaday_098 with d
                simon "Huh?" id ep5_03_juliaday_196da51b
                show ep5 juliaday_099 with d
                juliamom "GET BACK HERE, YOU GODDAMN HOOLIGAN!" id ep5_03_juliaday_4054fc99


        $ debug_other_paths()
    else:

        show ep5 juliaday_100 with d
        julia "Well, if you insist..." id ep5_03_juliaday_5535a1ca
        show ep5 juliaday_101 with d
        julia "It's probably for the best." id ep5_03_juliaday_79835dc9
        show ep5 juliaday_102 with d
        simon "Good. See you around campus?" id ep5_03_juliaday_0e13129f
        show ep5 juliaday_103 with d
        julia "Of course!" id ep5_03_juliaday_6d43129f
        show ep5 juliaday_104 with d
        julia "Let me walk you to the door." id ep5_03_juliaday_ddbb1ce2
        show ep5 juliaday_105 with d
        simon "Thanks, Julia!" id ep5_03_juliaday_2540f212
        show ep5 juliaday_106 with d
        julia "See you around, [name]!" id ep5_03_juliaday_510dd5fe
        show ep5 juliaday_107 with d
        simon "*Whistles.*"
        show ep5 juliaday_108 with d
        simon "*Whistles.*"
        show ep5 juliaday_109 with d
        simon "*Whistles.*"
        show ep5 juliaday_110 with d
        juliamom "Hmm." id ep5_03_juliaday_736c7a51


    jump ep5_08_universitydylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
