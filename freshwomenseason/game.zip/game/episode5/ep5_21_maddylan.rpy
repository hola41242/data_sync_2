label ep5_21_maddylan:






if chose("ep5_beerpong_hit_the_ball"):
    play music muddy_up_the_dirt fadein 5 volume 0.37
    show ep5 maddylan_001 with d
    simon "Dylan! Hold up, man. What's going on?" id ep5_21_maddylan_be9d599a
    dylan "You could've gone easy on me." id ep5_21_maddylan_198c7fda
    dylan "Could've acted like a real bro." id ep5_21_maddylan_17e0c65b
    show ep5 maddylan_002 with d
    simon "But I am your bro." id ep5_21_maddylan_e2100c72
else:

    show ep5 maddylan_003 with d
    play music muddy_up_the_dirt fadein 5 volume 0.37
    dylan "[name]! Wait a minute, man. What's going on?" id ep5_21_maddylan_b06973a0
    simon "You crossed the line, Dylan." id ep5_21_maddylan_42bdfee9
    show ep5 maddylan_004 with d
    dylan "What'd I do?" id ep5_21_maddylan_0f99f8cf
    show ep5 maddylan_005 with d
    simon "You embarrassed Alyssa in front of the whole party." id ep5_21_maddylan_918fcdae
    simon "I just hope she doesn't get mad at me too." id ep5_21_maddylan_062dfe2b
    show ep5 maddylan_004 with d
    dylan "Sorry, dude. I just wanted to help a bro out, like I always do." id ep5_21_maddylan_5f015f5a
    show ep5 maddylan_005 with d
    simon "Do you think that was you being my bro back there?" id ep5_21_maddylan_8346f2b2
    show ep5 maddylan_004 with d
    dylan "But I am your bro." id ep5_21_maddylan_d4e38245

$ debug_other_path()

if chose("let_dylan_help"):
    show ep5 maddylan_006 with d
    dylan "I helped you with Chloe when you asked me to." id ep5_21_maddylan_0d3a59b0
    dylan "And I'm still waiting for you to return the favor." id ep5_21_maddylan_6a710531
    simon "Return the favor? I joined the book club for you." id ep5_21_maddylan_723ebc1a
    dylan "I mean helping out with girls in general." id ep5_21_maddylan_51b25c51
    show ep5 maddylan_007 with d
    simon "Then pick one! Do it now! Right here at this party." id ep5_21_maddylan_999cb797
    simon "Pick a girl. I'll be your wingman." id ep5_21_maddylan_40595a3d
    dylan "I'm not going to just pick someone." id ep5_21_maddylan_2a9f7c96
    dylan "You think this is all about having sex?" id ep5_21_maddylan_9e7679f4

$ debug_other_path()

show ep5 maddylan_007_1 with d
simon "I don't understand why you're so angry." id ep5_21_maddylan_ae66bfba
show ep5 maddylan_006 with d
dylan "Of course you don't. Because you only think about yourself." id ep5_21_maddylan_a8eae5e1
simon "Damn it, Dylan. Can you just cut this out and tell me what I did wrong?" id ep5_21_maddylan_930aeb21
dylan "I asked you to help me fit in with these girls, but you're only helping yourself." id ep5_21_maddylan_3842270a
dylan "I met you at that café, and you rushed me straight out of there." id ep5_21_maddylan_cfc8bc08
show ep5 maddylan_007_1 with d
simon "Dylan, this is the drinks talking." id ep5_21_maddylan_3970e6bb
simon "Plus, you're the one who started talking about the bear!" id ep5_21_maddylan_ff7a0997
show ep5 maddylan_006 with d
dylan "Maybe I wanted to tell your friend a cool story!" id ep5_21_maddylan_5a9fa53e
show ep5 maddylan_008 with d
dylan "Speaking of which, how did you even meet all of those girls?" id ep5_21_maddylan_0836fd2a
dylan "I was supposed to be your wingman." id ep5_21_maddylan_334cba37

if chose("ep5_universityclass_apologize"):
    show ep5 maddylan_016 with d
    dylan "And you even agreed with the professor when she said those things about me!" id ep5_21_maddylan_b75fb3f9
    show ep5 maddylan_009 with d
    simon "She wasn't exactly lying." id ep5_21_maddylan_e75377de
    show ep5 maddylan_016 with d
    dylan "Is that what you really think?" id ep5_21_maddylan_4ac12501
else:

    show ep5 maddylan_007_1 with d
    simon "You're my wingman, dude. But sometimes you take things too far." id ep5_21_maddylan_93158820
    simon "That's what the professor said about you." id ep5_21_maddylan_f57cd02a
    simon "Even then, I stood up for you." id ep5_21_maddylan_a454301f
    show ep5 maddylan_008 with d
    dylan "It's the least you could have done." id ep5_21_maddylan_68cd9355

$ debug_other_path()

show ep5 maddylan_010 with d
simon "It's not like I planned all of this. Things just sort of happened..." id ep5_21_maddylan_241c297c
show ep5 maddylan_011 with d
dylan "Come on, man. You know what I'm talking about." id ep5_21_maddylan_79027ce1
show ep5 maddylan_007 with d
simon "Dude, when I was meeting those girls, I wasn't going to be thinking about you." id ep5_21_maddylan_61dc948e
simon "That would have been weird, to say the least." id ep5_21_maddylan_4599b9a2

if chose("ep3_04_challenge_won"):
    show ep5 maddylan_012 with d
    simon "I had to make a huge effort to win all three challenges and get you out of that jail cell." id ep5_21_maddylan_3130f67b
    simon "Doesn't that count for something?" id ep5_21_maddylan_64f94904
    show ep5 maddylan_008_1 with d
    dylan "You've got me there." id ep5_21_maddylan_ed7eca43
else:

    show ep5 maddylan_008 with d
    dylan "I should have realized who you really were after all that happened at The Station." id ep5_21_maddylan_6cbce9e0
    show ep5 maddylan_013 with d
    simon "Man, that challenge is insane. It's impossible to win." id ep5_21_maddylan_f2a4f441
    simon "You would know if you'd have been in there." id ep5_21_maddylan_9b4a931a
    show ep5 maddylan_008 with d
    dylan "Fuck you, [name]." id ep5_21_maddylan_60f4ed03
    show ep5 maddylan_015 with d
    simon "Fuck you too." id ep5_21_maddylan_8c2ba650

$ debug_other_path()

show ep5 maddylan_007_1 with d
simon "I don't get what you want." id ep5_21_maddylan_3d836abb
dylan "I already told you." id ep5_21_maddylan_49f39f60
show ep5 maddylan_014 with d
simon "What? You want me to grab a girl, strip you both naked, and lock the two of you in a room?" id ep5_21_maddylan_794800a0
dylan "That wouldn't be a horrible idea." id ep5_21_maddylan_33d2fba7
simon "The thing is, you're not even trying!" id ep5_21_maddylan_16c1a75c
show ep5 maddylan_007_1 with d
dylan "What do you mean?" id ep5_21_maddylan_8511f247
simon "You're running around behind that stupid mask of a foreign accent you wear to make yourself seem cool." id ep5_21_maddylan_6a1fe374
show ep5 maddylan_008 with d
dylan "My accent isn't stupid." id ep5_21_maddylan_7b3da019
show ep5 maddylan_015 with d
simon "I've never even seen you approach a girl." id ep5_21_maddylan_b82cd565
show ep5 maddylan_016 with d
dylan "I talk to girls." id ep5_21_maddylan_01a34762
show ep5 maddylan_015 with d
simon "You and Chloe have been friends for a while. I bet she would have given you a chance." id ep5_21_maddylan_8457b29e
show ep5 maddylan_017 with d
dylan "I don't want your sloppy seconds, [name]." id ep5_21_maddylan_169e2717
dylan "You know what? Never mind." id ep5_21_maddylan_d9b44061
show ep5 maddylan_018 with d
simon "(Where in the hell is all this coming from?)" id ep5_21_maddylan_7e5dfa2a
simon "(Maybe he's right. I could have helped him out a little more.)" id ep5_21_maddylan_b66c188e
show ep5 maddylan_019 with d
simon "(I hope he calms down by tomorrow.)" id ep5_21_maddylan_2d6913ba
simon "(Then we can talk this through.)" id ep5_21_maddylan_f4496f18
simon "(I should look for Julia. I shouldn't have left her alone.)" id ep5_21_maddylan_d8c84160
stop music fadeout 8
show ep5 maddylan_020 with d
simon "(Where could she be?)" id ep5_21_maddylan_7ace6d22
show ep5 maddylan_021 with d
simon "(I hope she isn't mad at me too.)" id ep5_21_maddylan_52f8c84b
show ep5 maddylan_022 with d
simon "Where are you?" id ep5_21_maddylan_8cf92ff3
julia "On the balcony." id ep5_21_maddylan_0e9de34e
show ep5 maddylan_023 with d
simon "The balcony?" id ep5_21_maddylan_bbc88898


show ep5 maddylan_024 with d
julia "The view from up here is incredible. Come have a look!" id ep5_21_maddylan_1219fb4d


show ep5 maddylan_025 with wipeup
pause

jump ep5_22_juliaroof
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
