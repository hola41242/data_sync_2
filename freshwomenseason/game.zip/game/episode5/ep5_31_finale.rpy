label ep5_31_finale:

    $ add_frame_to_finale = True
    show screen save_your_game(5, 1, 5, 0) with ending_fade
    show ep5 finale_lily
    pause

    $ award_manager.enable_notify()

    $ set_finale_chars("Lily")
    $ finale_color = "CF4730"
    $ finale_txt1 = _("Lily called you, asking you to come to her house.")
    if chose_finale('ep5_lilyhome_to_stay'):
        $ finale_txt2 = _("You had a conversation, then you decided to stay and have a party.")
        if chose_finale("ep5_lilyhome_i_want_to"):
            $ finale_txt3 = _("After your party, you had sex.")
    else:
        $ finale_txt2 = _("You talked.")
        $ finale_txt3 = _("Then you left.")
        $ finale_txt4 = ""
    $ finale_txt5 = _("You returned your apartment key.")

    hide screen save_your_game with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Julia")
    $ finale_color = "C161D4"
    if chose_finale('ep4_livingsituation_julia'):
        $ finale_txt1 = _("You stayed at Julia's.")
        $ finale_txt2 = ""
        if chose_finale("ep2_julia_kiss"):
            if chose_finale("ep5_juliaday_go_out_the_window"):
                $ finale_txt3 = _("You jumped out of Julia's window, completely unnoticed.")
            else:
                $ finale_txt3 = _("You tried to hide under the bed, but her mother saw you.")
    else:
        $ finale_txt1 = _("You didn't stay at Julia's.")
        $ finale_txt2 = ""
        $ finale_txt3 = ""
    if chose_finale("ep5_juliaroof_we_will"):
        $ finale_txt4 = _("You had sex with Julia.")
    else:
        $ finale_txt4 = ""
    $ finale_txt5 = _("You and Julia talked on the balcony during the party.")

    show ep5 finale_julia with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    $ set_finale_chars ("Sue")
    $ finale_color = "D6D6D6"
    if chose_finale('ep4_livingsituation_sue'):
        $ finale_txt1 = _("You stayed at Sue's.")
    else:
        $ finale_txt1 = _("You didn't stay at Sue's.")
    $ finale_txt2 = _("Sue was at the frat party.")
    $ finale_txt3 = _("She refereed the beer pong game.")
    $ finale_txt4 = ""
    if chose_finale('ep4_susanhome_suespy1') or chose_finale('ep4_susanhome_suespy2'):
        $ finale_txt4 = _("She was still mad at you.")
    $ finale_txt5 = _("She made sure the game was fair.")


    show ep5 finale_sue with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Chloe")
    $ finale_color = "4FDB85"
    if chose_finale('ep4_livingsituation_chloe'):
        $ finale_txt1 = _("You stayed at Chloe's.")
        $ finale_txt2 = _("Chloe helped you do some more research before the ball.")
    else:
        $ finale_txt1 = _("You didn't stay at Chloe's.")
        $ finale_txt2 = ""
    $ finale_txt3 = _("Chloe helped you find a bathing suit.")
    $ finale_txt4 = ""
    if chose_finale('ep5_beerpong_hit_the_ball'):
        $ finale_txt5 = _("You won at beer pong, but she refused to kiss Dylan.")
    else:
        $ finale_txt5 = _("You lost the beer pong game on purpose, and Chloe stood up for Alyssa.")

    $ finale_txt5 = ""

    show ep5 finale_chloe with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Alyssa")
    $ finale_color = "A6F2F5"
    if chose_finale('ep4_livingsituation_here'):
        $ finale_txt1 = _("You stayed at Alyssa's.")
    else:
        $ finale_txt1 = _("You didn't stay at Alyssa's.")
    $ finale_txt2 = _("Alyssa was your partner for beer pong.")
    if chose_finale('ep5_beerpong_hit_the_ball'):
        $ finale_txt3 = _("You won at beer pong.")
    else:
        $ finale_txt3 = _("You lost the beer pong game on purpose, and Alyssa was very uncomfortable with the punishment.")
    $ finale_txt4 = ""
    if chose_finale("ep3_07_cafe2_agree_to_help"):
        $ finale_txt5 = _("You danced with Alyssa's group, and the dance went well.")
    else:
        $ finale_txt5 = _("You didn't dance with Alyssa's group.")

    show ep5 finale_alyssa with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars ("Dylan")
    $ finale_color = "FCFF4B"
    if chose_finale('ep4_livingsituation_dylan'):
        $ finale_txt1 = _("You stayed at Dylan's.")
    else:
        $ finale_txt1 = _("You didn't stay at Dylan's.")
    if chose_finale("ep5_universityclass_defend_dylan"):
        $ finale_txt2 = _("You stood up for Dylan when the professor held you back for a word after class.")
    else:
        $ finale_txt2 = _("You agreed with what the professor had to say about Dylan.")
    if chose_finale('ep5_beerpong_hit_the_ball'):
        $ finale_txt3 = _("You won at beer pong, fueling Dylan's rage even further.")
    else:
        $ finale_txt3 = _("You lost the beer pong game on purpose, feeling like Dylan needed the win more than you.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You and Dylan had a misunderstanding and are not talking to one another.")

    show ep5 finale_dylan with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Gabby")
    $ finale_color = "ff96d3"
    $ finale_txt1 = _("You met Gabby.")
    if chose_finale("ep4_dylanphone_i_want_style"):
        $ finale_txt2 = _("She noticed you before because of the hats you and Dylan were wearing.")
    else:
        $ finale_txt2 = ""
    if chose_finale("ep5_gabbyclass_talk_to_gabby"):
        $ finale_txt3 = _("You decided to talk to Gabby about what was on your mind.")
        if chose_finale("ep5_gabbyclass_ready"):
            $ finale_txt4 = _("That led to the two of you having sex.")
            $ finale_txt5 = _("Which then led to you running naked through campus.")
        else:
            $ finale_txt4 = ""
            $ finale_txt5 = _("But you decided that doing anything more in that room would be too much of a risk.")
    else:
        $ finale_txt3 = ""
        $ finale_txt4 = ""
        $ finale_txt5 = _("You decided not to talk to Gabby about what was bothering you.")

    show ep5 finale_gabby with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars ("Devilla")
    $ finale_color = "C90404"
    if chose_finale('ep5_angels_ask_devilla_for_help'):
        $ finale_txt1 = _("You asked Devilla for help.")
        $ finale_txt2 = ""
        $ finale_txt3 = ""
        $ finale_txt4 = ""
        if chose_finale("ep5_angels_accept_devillas_job"):
            $ finale_txt5 = _("You accepted Devilla's job offer.")
        else:
            $ finale_txt5 = _("You didn't accept Devilla's job offer.")
    else:
        $ finale_txt1 = _("You didn't ask Devilla for help.")
        $ finale_txt2 = ""
        $ finale_txt3 = ""
        $ finale_txt4 = ""
        $ finale_txt5 = ""


    show ep5 finale_devilla with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    call end_game_if_rpy_is_not_installed ('ep6_01_goodfather.rpy') from _call_end_game_if_rpy_is_not_installed_2

    jump ep6_01_goodfather
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
