label ep5_27_chase:







    play music mystical_tension volume 0.35 if_changed


    show ep5 chase_001 with wiperight
    simon "(I think Susan is on to me.)" id ep5_27_chase_354b173f
    simon "(Got to be smart about this.)" id ep5_27_chase_063d5151
    show ep5 chase_002 with d
    simon "(The mask helps a little, but if she gets too close, she'll recognize me.)" id ep5_27_chase_3c1286d8
    simon "(I have to be careful not to —)" id ep5_27_chase_016486fd
    play sound hitting_leather volume 0.7
    show ep5 chase_003 with hpunch
    simon "Ouch!" id ep5_27_chase_2e4f777a
    simon "Sorry!" id ep5_27_chase_af3cd353
    show ep5 chase_004 with d
    woman_customer "No, I'm the one who should apologize. Don't worry about it." id ep5_27_chase_06f2227b
    woman_customer "Wow, you're so tense!" id ep5_27_chase_5afa30d3
    woman_customer "Relax. It's really no big deal!" id ep5_27_chase_1346685b
    show ep5 chase_005 with d
    simon "(Tense...? Oh no.)" id ep5_27_chase_07f89cd1

    show ep5 chase_006 with d
    customer "What's wrong? You look like you just saw a ghost." id ep5_27_chase_c5664a69
    show ep5 chase_007 with d
    simon "(Shit, is that Mae? She's that client of Susan's I made a delivery to way back when, huh?)" id ep5_27_chase_d53168db
    show ep5 chase_006 with d
    customer "[name], is that you?" id ep5_27_chase_bffbb12a
    show ep5 chase_007 with d
    simon "(She remembers my name!)" id ep5_27_chase_ef9fda87
    show ep5 chase_008 with d
    customer "I thought I recognized those strong arms from somewhere!" id ep5_27_chase_33d63d9a
    customer "I didn't think I'd see you here." id ep5_27_chase_ab3dc965
    customer "What a pleasant surprise." id ep5_27_chase_52790e62
    show ep5 chase_009 with d
    simon "Look, Mae. It's nice running into you, but I have some errands to —" id ep5_27_chase_a611f71c
    show ep5 chase_010 with d
    customer "Errands? Those don't look like work clothes to me." id ep5_27_chase_b7186a38
    customer "Speaking of work, after our last run-in, I asked Susan about you." id ep5_27_chase_d1cf3d2c
    customer "She didn't mention anything about you being here." id ep5_27_chase_ce55d748
    show ep5 chase_011 with d
    customer "You wouldn't, by chance, have snuck in without her knowing, would you?" id ep5_27_chase_c5167d87
    show ep5 chase_012 with d
    simon "Of course not." id ep5_27_chase_ed0cdf1e
    show ep5 chase_011 with d
    customer "That's what I thought." id ep5_27_chase_56a8602e
    show ep5 chase_013 with d
    customer "So you wouldn't mind joining me for a drink over there in front of god and everyone." id ep5_27_chase_dd5762fc
    show ep5 chase_014 with d
    customer "Or, of course, we could go somewhere more private." id ep5_27_chase_c9449d72
    show ep5 chase_015 with d
    simon "(Manipulative bitch!)" id ep5_27_chase_ce568c1b
    show ep5 chase_014 with d
    customer "It's up to you." id ep5_27_chase_e2777469

    menu:
        "Go with Mae":
            $ save("ep5_chase_go_with_mom")
            show ep5 chase_016 with d
            simon "Fine. Let's go somewhere more private." id ep5_27_chase_d47844fb
            show ep5 chase_017 with d
            customer "Ah, this party just keeps getting better and better!" id ep5_27_chase_48090d93
            customer "Let's go." id ep5_27_chase_f4c267a7
            show ep5 chase_018 with d
            sam "Excuse me, Mae?" id ep5_27_chase_f4f27f10
            simon "(Holy shit.)" id ep5_27_chase_933f09cb
            simon "(Not him.)" id ep5_27_chase_8f1c59fc
            show ep5 chase_019 with d
            customer "Oh, Sam! I didn't see you over there." id ep5_27_chase_2967f096
            show ep5 chase_020 with d
            sam "Susan was looking for you. It seems urgent." id ep5_27_chase_0c0563c9
            customer "I see..." id ep5_27_chase_a0b61c92
            show ep5 chase_021 with d
            customer "I think our conversation will have to wait, [name]." id ep5_27_chase_a22c6f55
            customer "I'll find you later on." id ep5_27_chase_a1585f9a
            play sound high_heels_walk_on_wooden_floor volume 0.7
        "Don't go with her":

            $ save("ep5_chase_dont_go_with_mae")
            show ep5 chase_022 with d
            simon "I won't do either." id ep5_27_chase_e6d57635
            simon "Do what you want with that. I don't really care." id ep5_27_chase_30aa8f96
            show ep5 chase_023 with d
            customer "Wow. So feisty." id ep5_27_chase_c30246ad
            customer "I like it." id ep5_27_chase_c639332f
            show ep5 chase_024 with d
            customer "Let's see how long you can keep that up." id ep5_27_chase_5e112623
            show ep5 chase_025 with d
            sam "I don't think your pick-up line worked very well." id ep5_27_chase_6bc0b0e4
            show ep5 chase_026 with d
            simon "Fuck! Sam?!" id ep5_27_chase_d0c8b086
            simon "How long have you been there?" id ep5_27_chase_e97a1930
            show ep5 chase_027 with d
            sam "Just got here." id ep5_27_chase_c53c7b38

    $ debug_other_path()

    stop sound fadeout 5
    show ep5 chase_028 with d
    sam "It seems you have a type." id ep5_27_chase_23114fc0
    sam "Married women." id ep5_27_chase_4651e200
    show ep5 chase_029 with d
    simon "Is Mae married?" id ep5_27_chase_5f9ed971
    show ep5 chase_030 with d
    sam "No." id ep5_27_chase_539f20c4
    sam "But from your answer I can tell you didn't know that." id ep5_27_chase_973c84fc
    sam "And you didn't even care." id ep5_27_chase_49c4bb4b
    show ep5 chase_031 with d
    sam "Scum." id ep5_27_chase_0a478e06
    show ep5 chase_032 with d
    simon "Sam, what are you doing here?" id ep5_27_chase_1ef5f3dc
    show ep5 chase_033 with d
    sam "What am I doing here? I organized this event with Susan." id ep5_27_chase_dfbef74e
    sam "And right now, I'm supervising a delivery." id ep5_27_chase_76c398e2
    sam "So I'm not going to fuck you up right here, but only because we're in public." id ep5_27_chase_c14e0ca7
    show ep5 chase_034 with d
    sam "But I'd suggest you scram because my patience is running thin." id ep5_27_chase_5c2d1a3d
    show ep5 chase_035 with d
    simon "(A delivery? Why is Sam overseeing a delivery?)" id ep5_27_chase_846630e7
    simon "(It must be something extremely important. I should check it out.)" id ep5_27_chase_9f5d9b7c
    show ep5 chase_032 with d
    simon "Sam, I don't want any trouble." id ep5_27_chase_007c67a7
    show ep5 chase_036 with d
    sam "Oh, but I do. Just not right this second in front of everyone." id ep5_27_chase_93a37305
    show ep5 chase_037 with d
    emily "Boys!" id ep5_27_chase_f5ce1248
    emily "No fighting!" id ep5_27_chase_df4deebc
    show ep5 chase_038 with d
    simon "What? Emily?!" id ep5_27_chase_58df3d0a
    emily "Hello, [name]!" id ep5_27_chase_a42bda0c
    show ep5 chase_039 with d
    emily "Sam." id ep5_27_chase_a5911647
    show ep5 chase_040 with d
    simon "Emily, what are you doing here?" id ep5_27_chase_15709223
    show ep5 chase_041 with d
    sam "Are you that dumb? She works for Susan, you little shit." id ep5_27_chase_503aadad
    show ep5 chase_042 with d
    emily "Sam! Don't talk to him like that." id ep5_27_chase_545196a2
    show ep5 chase_043 with d
    emily "Wow, there's so much negative energy between the two of you." id ep5_27_chase_50445c44
    emily "What happened, huh?" id ep5_27_chase_dfec4aab
    show ep5 chase_044 with d
    sam "This is neither the time nor the place to talk about it, Emily." id ep5_27_chase_5eb79a67
    show ep5 chase_045 with d
    simon "Yeah, Emily, don't even get me started..." id ep5_27_chase_81caea7f
    show ep5 chase_043 with d
    emily "I thought you two would be such good friends!" id ep5_27_chase_b70821bc
    show ep5 chase_046 with d
    emily "After all, wasn't it your wife, Lily, who gave [name] a room?" id ep5_27_chase_232c8854
    show ep5 chase_047 with d
    sam "My wife..." id ep5_27_chase_7421b41c
    show ep5 chase_048 with d
    simon "(Their marriage is in shambles!)" id ep5_27_chase_96fda4f1
    show ep5 chase_049 with d
    emily "And you, [name]? Wasn't your father a good friend of Sam's?" id ep5_27_chase_8b1e00c9
    show ep5 chase_050 with d
    simon "Friend?" id ep5_27_chase_73c73446
    show ep5 chase_051 with d
    emily "You think Emily here doesn't know a thing about this." id ep5_27_chase_80ba6f15
    emily "But she knows a whole lot." id ep5_27_chase_c399c5f0
    show ep5 chase_052 with d
    sam "What are you talking about?"
    play sound glasses_clink_toasting_thick volume 0.7
    show ep5 chase_053 with d
    emily "Wow, you two are so tense." id ep5_27_chase_c4be9987
    emily "You could both use a drink." id ep5_27_chase_14ef4d4a
    show ep5 chase_054 with d
    emily "Ta-da." id ep5_27_chase_d581a117



    emily "Here you go." id ep5_27_chase_b2033f88
    show ep5 chase_055 with d
    simon "Oh, what the hell..." id ep5_27_chase_9fd44a5f
    show ep5 chase_056 with d
    sam "Mmm..." id ep5_27_chase_26a9b3e9
    show ep5 chase_057 with d
    sam "I really needed that." id ep5_27_chase_b987329b
    show ep5 chase_058 with d
    emily "Wow, you both slammed those!" id ep5_27_chase_5177b744
    show ep5 chase_057 with d
    sam "It's the only way I can put up with looking at that dumb face of his." id ep5_27_chase_48eb110f
    play sound door_heavy volume 0.5
    show ep5 chase_059 with d

    sam "Now, I need to get back to work. The delivery man should be here by now." id ep5_27_chase_96e1a051
    show ep5 chase_060 with d
    simon "I'm coming with you!" id ep5_27_chase_fa7e40e7
    sam "What are you talking about?"

    stop music
    play sound tinnitus loop volume 0.05
    show ep5 chase_061 with vpunch
    sam "Ugh... My head." id ep5_27_chase_0a13eb21
    play sound_2 heartbeat_distant volume 0.7 loop
    show ep5 chase_063 with d


    simon "Something feels... off..." id ep5_27_chase_d123dbfa
    show ep5 chase_062 with d
    emily "You two don't look so hot." id ep5_27_chase_3a82590e
    emily "Why don't you come with me and take a load off?" id ep5_27_chase_f0a5518d



    stop music fadeout 5
    scene black with long_dissolve
    play sound_2 body_fall_mat8 volume 0.7
    pause 0.5
    play sound_2 body_fall volume 0.7
    pause 1

    stop sound fadeout 2



jump ep5_28_blackout
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
