
label ep5_07_alyssaday:

    play music within_these_walls fadein 5 volume 0.3
    show ep5 alyssaday_001 with d
    alyssa "Good morning, sleepyhead!" id ep5_07_alyssaday_e57c3791
    show ep5 alyssaday_002 with d
    simon "Oh. Good morning, Alyssa." id ep5_07_alyssaday_9eda21d3
    show ep5 alyssaday_003 with d
    alyssa "You scared me a little last night." id ep5_07_alyssaday_e46db821
    alyssa "Did you sleep all right?" id ep5_07_alyssaday_45b23fe7
    show ep5 alyssaday_004 with d
    simon "I had this weird dream." id ep5_07_alyssaday_79459335
    show ep5 alyssaday_005 with d
    alyssa "So that's why you tossed and turned last night while you were sleeping." id ep5_07_alyssaday_41898ff2
    show ep5 alyssaday_006 with d
    simon "Sorry if I woke you." id ep5_07_alyssaday_6baf613c
    show ep5 alyssaday_007 with d
    alyssa "No worries!" id ep5_07_alyssaday_186b9237
    show ep5 alyssaday_008 with d
    alyssa "Sorry to make you sleep on a mat." id ep5_07_alyssaday_3f7401f6
    alyssa "It's not so bad once you get used to it though." id ep5_07_alyssaday_66e02a78
    show ep5 alyssaday_009 with d
    simon "You're used to it then?" id ep5_07_alyssaday_b28b717b
    show ep5 alyssaday_010 with d
    alyssa "I am." id ep5_07_alyssaday_e455da7a
    show ep5 alyssaday_011 with d
    simon "Then this isn't the first time you've slept here?" id ep5_07_alyssaday_82885b16
    show ep5 alyssaday_012 with d
    alyssa "Nope." id ep5_07_alyssaday_5677f662

    show ep5 alyssaday_013 with d
    alyssa "Imagine how awful it is to sleep in a house with multiple teenage boys." id ep5_07_alyssaday_bb7c110a
    show ep5 alyssaday_014 with d
    alyssa "That's why I sleep here from time to time." id ep5_07_alyssaday_eb559542
    alyssa "Well, that and to get some practice time for myself." id ep5_07_alyssaday_49f06c67
    show ep5 alyssaday_015 with d
    simon "Right. Like for the dance performance at the charity ball." id ep5_07_alyssaday_44f4adfa
    show ep5 alyssaday_016 with d
    alyssa "Yup..." id ep5_07_alyssaday_bf5e478a
    show ep5 alyssaday_017 with d
    alyssa "Looking down in the dumps when you showed up here yesterday has something to do with that, doesn't it?" id ep5_07_alyssaday_30982ad8
    show ep5 alyssaday_018 with d
    simon "Yeah." id ep5_07_alyssaday_d44ae3cd
    simon "I found out that the charity ball is held to honor my father — in a way." id ep5_07_alyssaday_22c84cd2
    show ep5 alyssaday_019 with d
    alyssa "Oh really?" id ep5_07_alyssaday_25e8db9c
    alyssa "How did I not know that?" id ep5_07_alyssaday_35cba70e
    show ep5 alyssaday_020 with d
    simon "It's complicated." id ep5_07_alyssaday_a20baf0b
    simon "There's nothing official with his name on it." id ep5_07_alyssaday_b26c689f
    show ep5 alyssaday_021 with d
    simon "I also found out that I've been to the ball before." id ep5_07_alyssaday_d27bc88e
    simon "Probably looking for my father." id ep5_07_alyssaday_47406356
    show ep5 alyssaday_022 with d
    alyssa "Really? When was that?" id ep5_07_alyssaday_34750a15
    show ep5 alyssaday_023 with d
    simon "A few years back." id ep5_07_alyssaday_e46c12e7
    play sound bag_zips_open
    show ep5 alyssaday_024 with d
    simon "I don't remember exactly when, but I found this photo." id ep5_07_alyssaday_c2bfa9ac
    show ep5 alyssaday_025 with d
    simon "Have a look." id ep5_07_alyssaday_35e55f7c
    show ep5 alyssaday_026 with d
    alyssa "Oh, this is that crazy girl!" id ep5_07_alyssaday_5d728a6f
    show ep5 alyssaday_027 with d
    alyssa "So it was you with her back then." id ep5_07_alyssaday_25865cf4
    show ep5 alyssaday_028 with d
    simon "Wait. You know Emily?" id ep5_07_alyssaday_1dfbd8a5
    show ep5 alyssaday_029 with d
    alyssa "I wouldn't say I know her." id ep5_07_alyssaday_167cc3cc
    alyssa "But I was at the ball one time, trying to get them to let my group dance there." id ep5_07_alyssaday_2e2af5d9
    show ep5 alyssaday_030 with d
    alyssa "They ended up picking another group that year, but I stayed there long enough to see this girl running around." id ep5_07_alyssaday_bfc0a625
    show ep5 alyssaday_031 with d
    alyssa "She sure had a lot of energy." id ep5_07_alyssaday_41ea4e3d
    show ep5 alyssaday_032 with d
    simon "(What did you do, Emily?)" id ep5_07_alyssaday_bac51834
    show ep5 alyssaday_033 with d
    alyssa "And you're thinking about looking for your father at the ball?" id ep5_07_alyssaday_a5c51166
    show ep5 alyssaday_034 with d
    simon "Either him or someone close to him." id ep5_07_alyssaday_5a396e71

    if choice_made('ep3_07_cafe2_agree_to_help'):
        show ep5 alyssaday_035 with d
        alyssa "It's great that you already have your entry guaranteed with us!" id ep5_07_alyssaday_bf6665a8
        show ep5 alyssaday_036 with d
        alyssa "After the performance, I can help you look for him if you want." id ep5_07_alyssaday_594cc712
        show ep5 alyssaday_037 with d
        simon "Thank you, Alyssa." id ep5_07_alyssaday_81435a97
        show ep5 alyssaday_038 with d
        simon "Do you think he'll be there?" id ep5_07_alyssaday_0671033f
        show ep5 alyssaday_039 with d
        alyssa "I don't know..." id ep5_07_alyssaday_d74cc5a0
        show ep5 alyssaday_040 with d
        alyssa "But I'm sure something in that place will bring back a memory or two!" id ep5_07_alyssaday_62b3c006
    else:

        show ep5 alyssaday_041 with d
        alyssa "And you already know how you're going to get in?" id ep5_07_alyssaday_52695ea7
        alyssa "They must have a pretty exclusive list." id ep5_07_alyssaday_db4f3fb9
        show ep5 alyssaday_042 with d
        alyssa "Your father must be a very important person..." id ep5_07_alyssaday_fe438020
        show ep5 alyssaday_043 with d
        simon "I don't know how I'll get in yet... But I'll find a way." id ep5_07_alyssaday_b90bbfc4
        show ep5 alyssaday_044 with d
        alyssa "I'm sure you will!" id ep5_07_alyssaday_967b3b22

    $ debug_other_path()

    show ep5 alyssaday_045 with d
    simon "And speaking of going places, I have to get to class." id ep5_07_alyssaday_df48425f
    show ep5 alyssaday_045_1 with d
    simon "Do you mind if I change real quick?" id ep5_07_alyssaday_ab77fd09
    show ep5 alyssaday_045_1 with d
    pause
    show ep5 alyssaday_046 with d
    alyssa "Oh, you're going already?" id ep5_07_alyssaday_9471c8ad
    show ep5 alyssaday_047 with d
    simon "Yeah... I kind of overslept." id ep5_07_alyssaday_18d32e21
    show ep5 alyssaday_048 with d
    alyssa "Maybe just a tad... Haha." id ep5_07_alyssaday_0346b3fe
    show ep5 alyssaday_049 with d
    stop music fadeout 5
    alyssa "See you later then, [name]!" id ep5_07_alyssaday_64710cbe
    show ep5 alyssaday_050 with d
    simon "See you!" id ep5_07_alyssaday_504fdea7
    jump ep5_08_universitydylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
