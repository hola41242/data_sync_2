
label ep5_12_gabbysex:

    play music i_want_you fadein 4 volume 0.42
    play sound unzip_2 volume 0.6 
    show ep5 gabbysex_001 with d
    gabby "Let's start your relaxation." id ep5_12_gabbysex_a7ccbf32
    show ep5 gabbysex_002 with d
    simon "Are you sure it's safe to do this here?" id ep5_12_gabbysex_86e90e08
    gabby "No one will see us if we keep it quiet." id ep5_12_gabbysex_490e438b

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_003_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_003_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_003 with d
    gabby "Don't worry." id ep5_12_gabbysex_2a256f8e
    gabby "In fact, I want you to do the opposite of that." id ep5_12_gabbysex_339cc69e
    gabby "I want you to relax." id ep5_12_gabbysex_b5262d8a
    simon "If you keep that up, I'll forget we're doing this in a classroom even." id ep5_12_gabbysex_f3d9c456
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_003_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_003_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_003_var1 with d
    gabby "Excellent!" id ep5_12_gabbysex_d5bfb980
    gabby "That means I'm doing my job right." id ep5_12_gabbysex_da7960b1
    gabby "Angela will be happy." id ep5_12_gabbysex_223c33c2
    simon "Oh, I'll be happy too." id ep5_12_gabbysex_42874e44
    gabby "Yeah?" id ep5_12_gabbysex_1cac7cc7
    pause
    stop foley
    stop voicefx
    show ep5 gabbysex_005 with d
    gabby "So if I make you happy enough, maybe you'll want to do some other things." id ep5_12_gabbysex_387d98bf
    show ep5 gabbysex_006 with d
    simon "You think so?" id ep5_12_gabbysex_bf39b1cb
    simon "What kind of things?" id ep5_12_gabbysex_9fd1ef39
    show ep5 gabbysex_007 with d
    gabby "Like coming with me." id ep5_12_gabbysex_2f8ab6b9
    show ep5 gabbysex_008 with d
    simon "Ooh, where are we going?" id ep5_12_gabbysex_115ff513
    show ep5 gabbysex_009 with d
    gabby "Here." id ep5_12_gabbysex_7fa555b7
    show ep5 gabbysex_010 with d
    gabby "Don't tell me you've never thought about fucking a professor before." id ep5_12_gabbysex_6ec6a810
    show ep5 gabbysex_011 with d
    gabby "A sexy professor?" id ep5_12_gabbysex_5783ded2
    show ep5 gabbysex_012 with d
    simon "Um... A sexy professor...?" id ep5_12_gabbysex_4b8449d4
    show ep5 gabbysex_013 with d
    gabby "Oh, is there one who comes to mind?" id ep5_12_gabbysex_602e605e
    show ep5 gabbysex_014 with d
    simon "Not exactly." id ep5_12_gabbysex_52d3a88a
    show ep5 gabbysex_015 with d
    simon "Anyway, you're just a student." id ep5_12_gabbysex_4c658e83
    show ep5 gabbysex_016 with d
    gabby "I can be whoever you want me to be." id ep5_12_gabbysex_baebd552
    gabby "For example..." id ep5_12_gabbysex_f16e10cc
    play sound dress_shirt
    show ep5 gabbysex_017 with d
    simon "Wow..."
    show ep5 gabbysex_018 with d
    simon "Isn't it better for us to keep our clothes on in case someone comes in?" id ep5_12_gabbysex_460386d3
    show ep5 gabbysex_019 with d
    gabby "Maybe..." id ep5_12_gabbysex_e7b3c370
    play sound dress_shirt_fold volume 0.7
    show ep5 gabbysex_020 with d
    gabby "But that would be..." id ep5_12_gabbysex_e7523a65
    show ep5 gabbysex_021 with d
    gabby "... much less fun..." id ep5_12_gabbysex_da5fbf78
    simon "This is insane." id ep5_12_gabbysex_03d40cee
    play sound cloth_toss_heavy
    show ep5 gabbysex_022 with d
    simon "Fuck it." id ep5_12_gabbysex_f4de4dbd
    play sound dress volume 0.7
    show ep5 gabbysex_023 with d
    gabby "That's the spirit." id ep5_12_gabbysex_72660804
    show ep5 gabbysex_024 with d
    gabby "Now come closer..." id ep5_12_gabbysex_d3f269ae
    show ep5 gabbysex_025 with d
    gabby "... and let me show you..." id ep5_12_gabbysex_fe315ddf
    gabby "... a world of relaxation." id ep5_12_gabbysex_b2e3541e

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_025_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_025_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_025 with d
    gabby "How do you feel now?" id ep5_12_gabbysex_6e4773b6
    simon "I feel..." id ep5_12_gabbysex_1263b0a4
    simon "... free." id ep5_12_gabbysex_02f1d041
    gabby "Yes! That's it!" id ep5_12_gabbysex_a7d23e37

    gabby "You're out of those clothes." id ep5_12_gabbysex_d0eb1bf5
    gabby "And out of your fears." id ep5_12_gabbysex_c777492b
    gabby "Free!" id ep5_12_gabbysex_89128842
    simon "There's no reason to resist, huh?" id ep5_12_gabbysex_9d196b72
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_027_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_027_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_027 with d
    gabby "None that I can think of." id ep5_12_gabbysex_65c4d955

    gabby "Mmm... So good." id ep5_12_gabbysex_57ca7bb1
    simon "Looks like you're enjoying this as much as I am." id ep5_12_gabbysex_f5487cca
    gabby "I can't help it..." id ep5_12_gabbysex_cfba2d16
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_026_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_026_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_026 with d
    gabby "That big cock rubbing against my ass gives me... ideas..." id ep5_12_gabbysex_15fb09f6
    simon "Yeah? What kind of ideas?" id ep5_12_gabbysex_c104e0a7

    gabby "Makes me want to open up all of my senses..." id ep5_12_gabbysex_e3e12306
    gabby "Can you hear the sound of flesh on flesh?"
    simon "I can hear and feel my cock rubbing between your cheeks." id ep5_12_gabbysex_cef020fb
    gabby "Yes! That's what I'm talking about!" id ep5_12_gabbysex_b8569ba1
    simon "I'm not worried about who's going to see us here anymore." id ep5_12_gabbysex_9dd6c64c
    pause
    stop foley
    stop voicefx
    show ep5 gabbysex_028 with d
    gabby "Exactly!" id ep5_12_gabbysex_44891425
    show ep5 gabbysex_029 with d
    gabby "Come here!"
    show ep5 gabbysex_030 with d
    gabby "In this moment..." id ep5_12_gabbysex_9e085f65
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_030_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_030_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_030 with d
    gabby "... all I can do is smell..." id ep5_12_gabbysex_e75cbc1a
    gabby "... and touch..." id ep5_12_gabbysex_eec0ba58
    gabby "... and feel you getting hard for me..." id ep5_12_gabbysex_3df79ba1
    gabby "... Then soon..." id ep5_12_gabbysex_ce416756
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_032_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_032_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_032 with d
    gabby "... I can taste the flavors." id ep5_12_gabbysex_e50a4b97
    simon "(Fuck, that's hot!)" id ep5_12_gabbysex_f9657b12
    gabby "Mmmm..."
    simon "So, what do you think?" id ep5_12_gabbysex_9f63f9fb
    gabby "It's so tasty!" id ep5_12_gabbysex_e192dcd5
    gabby "I can't wait to extract everything stored up in inside." id ep5_12_gabbysex_fee5c8cc
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_030_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_030_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_030_var1 with d
    gabby "And sample the flavors." id ep5_12_gabbysex_2a2e4b0f
    simon "Ahhh..."
    simon "You like everything in your mouth, don't you?" id ep5_12_gabbysex_ebcced17
    gabby "Of course!" id ep5_12_gabbysex_54c31da4
    gabby "But I want more..." id ep5_12_gabbysex_04b4415d
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_033_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_033_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_033 with d
    gabby "I want to stroke your balls." id ep5_12_gabbysex_99df6cdc
    gabby "And milk you." id ep5_12_gabbysex_10aa1905


    if choice_made("ep3_04_challenge_won"):
        simon "Well, you should know that it won't be that easy." id ep5_12_gabbysex_4ea6f9d6
        simon "I even resisted the Hell Angels' sex trial." id ep5_12_gabbysex_c3a71d40
        simon "(But I have to admit...)" id ep5_12_gabbysex_90d57605

    $ debug_other_paths()

    simon "(There's something very exciting about a college girl sucking my dick in a classroom.)" id ep5_12_gabbysex_97ab50e6
    simon "(I think she'll be able to make me cum pretty fast.)" id ep5_12_gabbysex_527d3d72
    simon "(... Just not yet.)" id ep5_12_gabbysex_cb20e26c
    pause

    label ep5_12_gabbysex_loop1:
        menu:
            "Assjob":
                image ep5 anim_gabbysex_assjob_combo:
                    "ep5 anim_gabbysex_025" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_026" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_027" with Dissolve(0.5)
                    pause 4
                    repeat
                $ allow_voicefx = True
                if is_voice_installed:
                    play voicefx ep5_anim_gabbysex_assjob_combo_voicefx fadein 0.5 fadeout 0.5
                    play foley ep5_anim_gabbysex_assjob_combo_foley fadein 0.5 fadeout 0.5
                show ep5 anim_gabbysex_assjob_combo with d
                pause
                jump ep5_12_gabbysex_loop1
            "Blowjob":
                image ep5 anim_gabbysex_blowjob_combo:
                    "ep5 anim_gabbysex_030" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_030_var1" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_032" with Dissolve(0.5)
                    pause 4
                    repeat
                $ allow_voicefx = True
                if is_voice_installed:
                    play voicefx ep5_anim_gabbysex_blowjob_combo_voicefx fadein 0.5 fadeout 0.5
                    play foley ep5_anim_gabbysex_blowjob_combo_foley fadein 0.5 fadeout 0.5
                show ep5 anim_gabbysex_blowjob_combo with d
                pause
                jump ep5_12_gabbysex_loop1
            "Continue" if True:
                $ renpy.pause()

    stop foley
    stop voicefx
    show ep5 gabbysex_034 with d
    simon "Gabby..."
    simon "This isn't fair." id ep5_12_gabbysex_loop1_164c6ce0
    show ep5 gabbysex_035 with d
    gabby "What isn't?" id ep5_12_gabbysex_loop1_629feebb
    show ep5 gabbysex_036 with d
    simon "I want a taste too." id ep5_12_gabbysex_loop1_effcb438
    show ep5 gabbysex_037 with d
    gabby "Oh... What a pleasant surprise!" id ep5_12_gabbysex_loop1_b2d8eac5
    show ep5 gabbysex_038 with d
    gabby "Here. Let me help." id ep5_12_gabbysex_loop1_95654ee6
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_039_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_039_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_039 with d
    gabby "Like this?" id ep5_12_gabbysex_loop1_dc46e60b
    gabby "(God, I'm so wet already.)" id ep5_12_gabbysex_loop1_109accb7
    simon "Yeah, just like that." id ep5_12_gabbysex_loop1_fb7c55f5
    gabby "Dinner is served." id ep5_12_gabbysex_loop1_fda2576b
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_039_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_039_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_039_var1 with d
    simon "Let me see you up close..." id ep5_12_gabbysex_loop1_a2596bfe
    gabby "Ahhh..." id ep5_12_gabbysex_loop1_9009832d
    simon "I want to taste you." id ep5_12_gabbysex_loop1_56128057
    pause


    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_040_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_040_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_040 with d
    simon "(Gently at first...)" id ep5_12_gabbysex_loop1_fe0f98e1
    simon "(Appreciating each part, as you should with such a delicate dish.)" id ep5_12_gabbysex_loop1_e88a552b
    simon "(A fine example...)" id ep5_12_gabbysex_loop1_ba2d3c1f
    simon "(... of a freshwoman pussy.)" id ep5_12_gabbysex_loop1_28400a46
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_041_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_041_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_041 with d
    gabby "Wow... Maybe Angela should hire you on too..." id ep5_12_gabbysex_loop1_9b9af835
    gabby "I'm so sensitive down there..." id ep5_12_gabbysex_loop1_d5ffce4b
    gabby "What an amazing tongue you have!" id ep5_12_gabbysex_loop1_9624525a
    gabby "Aaaahhh... Mmmm..." id ep5_12_gabbysex_loop1_335c5efb

    gabby "That's so good..." id ep5_12_gabbysex_loop1_efd959e6
    gabby "I'm so wet that your dick would slide right into me." id ep5_12_gabbysex_loop1_0935365e
    pause
    stop foley
    stop voicefx
    show ep5 gabbysex_042 with d
    simon "Wanna try?" id ep5_12_gabbysex_loop1_1e6bca51
    show ep5 gabbysex_043 with d
    gabby "Well..." id ep5_12_gabbysex_loop1_8dbcb982
    gabby "Maybe it might be better to go in easy..." id ep5_12_gabbysex_loop1_cfe8d4d4
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_044_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_044_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_044 with d
    gabby "Though I can't stand by what I said now that I'm seeing your huge cock so close to my pussy." id ep5_12_gabbysex_loop1_9cba43b9
    simon "We don't have to hurry, do we?" id ep5_12_gabbysex_loop1_6ec1da34
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_045_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_045_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_045 with d
    simon "Let's take it slow..." id ep5_12_gabbysex_loop1_f7a9533d
    simon "Nice and slow..." id ep5_12_gabbysex_loop1_ec89074f
    gabby "Ohhh, [name]..." id ep5_12_gabbysex_loop1_6c3cca77
    gabby "That feels so good..." id ep5_12_gabbysex_loop1_c129ea4b
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_044_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_044_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_044_var1 with d
    simon "See?" id ep5_12_gabbysex_loop1_0d45f2f6
    simon "The most important thing is to relax." id ep5_12_gabbysex_loop1_794fe05a
    gabby "You're right, [name]." id ep5_12_gabbysex_loop1_44918b81
    gabby "The most important thing is to relax." id ep5_12_gabbysex_loop1_364aaba1
    gabby "And take in every feeling..." id ep5_12_gabbysex_loop1_eaf4130a

    simon "So relax..." id ep5_12_gabbysex_loop1_713422b6
    simon "... And leave the rest to me." id ep5_12_gabbysex_loop1_7347ef2a
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_046_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_046_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_046 with d
    gabby "Ahhhh..." nointeract
    pause 85/20

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_047_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_047_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_047 with d
    gabby "This is a totally different way of taking everything in." id ep5_12_gabbysex_loop1_988442f9
    gabby "Every sense is alive and tingling." id ep5_12_gabbysex_loop1_2c9868b5
    gabby "I'm so wet!" id ep5_12_gabbysex_loop1_5a86f1d0
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_047_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_047_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_047_var1 with d
    gabby "Can you feel it too, [name]?" id ep5_12_gabbysex_loop1_7ed0fda8
    simon "(All I can feel is how tight and wet you are around my cock.)" id ep5_12_gabbysex_loop1_1f0c03ca

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_047_var2_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_047_var2_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_047_var2 with d
    simon "Yes, I'm feeling it." id ep5_12_gabbysex_loop1_45c5253d
    simon "I'm feeling all of it." id ep5_12_gabbysex_loop1_f36c9679
    simon "I'm also feeling that this table could give way at any moment." id ep5_12_gabbysex_loop1_2315f423
    gabby "Yeah... I don't think it was made for this..." id ep5_12_gabbysex_loop1_9a9489b8
    simon "A college professor's desk?" id ep5_12_gabbysex_loop1_abe7e33d

    simon "Of course it was made for fucking students." id ep5_12_gabbysex_loop1_43fe6c75
    simon "My concern is that it could be worn out for that very reason!" id ep5_12_gabbysex_loop1_d13889c8
    gabby "Haha! He's got a sense of humor!" id ep5_12_gabbysex_loop1_97ae55f1
    gabby "Or maybe you're just thinking about that hot professor again?" id ep5_12_gabbysex_loop1_b9b91a4e

    pause
    stop foley
    stop voicefx
    show ep5 gabbysex_049 with d
    gabby "Come here. Pretend I'm her." id ep5_12_gabbysex_loop1_0e56205c
    gabby "It'll be easier if you're not looking me in the face." id ep5_12_gabbysex_loop1_fee5fafb
    gabby "Slide your whole cock inside of me." id ep5_12_gabbysex_loop1_a3fbdde5
    gabby "Nice and slow." id ep5_12_gabbysex_loop1_5a670c13
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_049_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_049_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_049 with d
    gabby "Ahhhh..." nointeract
    pause 170/30
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_050_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_050_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_050 with d
    simon "You're right. That professor is hot." id ep5_12_gabbysex_loop1_1a916332
    simon "But I'm fucking you, not her." id ep5_12_gabbysex_loop1_e6aa3565
    gabby "That's so touching! A gentleman to the very end!" id ep5_12_gabbysex_loop1_77f5319c
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_050_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_050_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_050_var1 with d
    gabby "But it's fun pretending to be her." id ep5_12_gabbysex_loop1_59864a49

    gabby "Fuck me like you wish you could fuck that professor, [name]." id ep5_12_gabbysex_loop1_5a32b0c3
    simon "Honestly, she was kind of a bitch..." id ep5_12_gabbysex_loop1_b93b7cfe
    gabby "So, does she deserve to be taught a lesson?" id ep5_12_gabbysex_loop1_7c116f3a
    simon "Oh yeah... I'd love to do it with a spanking." id ep5_12_gabbysex_loop1_176d38d4
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_051_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_051_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_051 with d
    simon "But I don't think it'd be wise to do that now." id ep5_12_gabbysex_loop1_a29114dc

    gabby "We'll have to schedule another session then..." id ep5_12_gabbysex_loop1_c3f4a8eb
    gabby "Or you can spank her yourself in the future." id ep5_12_gabbysex_loop1_01c8bdc2
    simon "Both seem like good options to me." id ep5_12_gabbysex_loop1_e1f6b4cb
    gabby "Mmmm. Do you like it when I do this?" id ep5_12_gabbysex_loop1_37aedc3d

    gabby "Do you like fucking a freshwoman on your professor's desk?" id ep5_12_gabbysex_loop1_19778e4c
    simon "Oh yeah..." id ep5_12_gabbysex_loop1_8ec09e34

    label ep5_12_gabbysex_loop2:
        menu:
            "Over the table":
                image ep5 anim_gabbysex_table_combo:
                    "ep5 anim_gabbysex_047_var2" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_047" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_047_var1" with Dissolve(0.5)
                    pause 4
                    repeat
                $ allow_voicefx = True
                if is_voice_installed:
                    play voicefx ep5_anim_gabbysex_table_combo_voicefx fadein 0.5 fadeout 0.5
                    play foley ep5_anim_gabbysex_table_combo_foley fadein 0.5 fadeout 0.5
                show ep5 anim_gabbysex_table_combo with d
                pause
                jump ep5_12_gabbysex_loop2
            "Doggy Style":
                image ep5 anim_gabbysex_doggystyle_combo:
                    "ep5 anim_gabbysex_050" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_051" with Dissolve(0.5)
                    pause 4
                    "ep5 anim_gabbysex_050_var1" with Dissolve(0.5)
                    pause 4
                    repeat
                $ allow_voicefx = True
                if is_voice_installed:
                    play voicefx ep5_anim_gabbysex_doggystyle_combo_voicefx fadein 0.5 fadeout 0.5
                    play foley ep5_anim_gabbysex_doggystyle_combo_foley fadein 0.5 fadeout 0.5
                show ep5 anim_gabbysex_doggystyle_combo with d
                pause
                jump ep5_12_gabbysex_loop2
            "Continue" if True:
                $ renpy.pause()


    simon "If you keep this up, Gabby, I'm going to —" id ep5_12_gabbysex_loop2_fb527f9d
    gabby "Remember what I said!" id ep5_12_gabbysex_loop2_b23c7deb
    pause


    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep5_anim_gabbysex_053_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep5_anim_gabbysex_053_var1_foley fadein 0.5 fadeout 0.5
    show ep5 anim_gabbysex_053_var1 with d
    gabby "I want to feel your cum on me." id ep5_12_gabbysex_loop2_5de7789d
    gabby "I want to sample your true flavors." id ep5_12_gabbysex_loop2_105ccd8c
    gabby "I want to milk you." id ep5_12_gabbysex_loop2_ce5fc74e
    gabby "Give me everything you've got, [name]." id ep5_12_gabbysex_loop2_a03bb957
    simon "Gabby..."
    gabby "Where are you going to cum on me, [name]?" id ep5_12_gabbysex_loop2_77ff5e7f

    menu:
        "Mouth":
            $ ep5_gabbysex_mouth = True
            $ player_choice("ep5_gabbysex_mouth:true")

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep5_anim_gabbysex_052_voicefx fadein 0.5 fadeout 0.5
                play foley ep5_anim_gabbysex_052_foley fadein 0.5 fadeout 0.5
            show ep5 anim_gabbysex_052 with d
            gabby "Mmmmmph..." nointeract
            pause 255/30
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep5_anim_gabbysex_052_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep5_anim_gabbysex_052_var1_foley fadein 0.5 fadeout 0.5
            show ep5 anim_gabbysex_052_var1 with d
            simon "Ahhh..."
            stop foley
            stop voicefx
            show ep5 gabbysex_052 with hpunch
            pause 0.5
            show ep5 gabbysex_052 with hpunch
            pause 0.5
            show ep5 gabbysex_052 with hpunch
            pause 0.5
            gabby "Aaaahh..."


            show ep5 gabbysex_053 with d
            gabby "Delicious." id ep5_12_gabbysex_loop2_adc1a327
        "Breasts":

            $ ep5_gabbysex_breasts = True
            $ player_choice("ep5_gabbysex_breasts:true")

            stop foley
            stop voicefx
            show ep5 gabbysex_054 with d
            simon "I want to cum on those breasts!" id ep5_12_gabbysex_loop2_eb7f383b
            show ep5 gabbysex_054_1 with d
            gabby "Yeah??" id ep5_12_gabbysex_loop2_ed6622e2
            show ep5 gabbysex_054_2 with d
            gabby "On my breasts?" id ep5_12_gabbysex_loop2_6f70d5de
            simon "Yeah!"
            show ep5 gabbysex_054_3 with d
            gabby "I love the feeling of cum on my breasts..." id ep5_12_gabbysex_loop2_a67581d8
            gabby "Sooo wet and..." id ep5_12_gabbysex_loop2_f9d7fe3c
            show ep5 gabbysex_054_4 with d
            gabby "Warm." id ep5_12_gabbysex_loop2_7a170e7a
            gabby "Mmmm..."
            gabby "Cum on my tits, [name]!" id ep5_12_gabbysex_loop2_d063673c
            gabby "Give me everything!" id ep5_12_gabbysex_loop2_85de3f38
            gabby "CUM ON MY..." id ep5_12_gabbysex_loop2_d3b0a78d
            show ep5 gabbysex_054_5 with hpunch
            pause 0.5
            show ep5 gabbysex_054_5 with hpunch
            pause 0.5
            show ep5 gabbysex_054_5 with hpunch
            pause 0.5
            gabby "Aaaahh..."
            show ep5 gabbysex_054_6 with d
            gabby "That was..." id ep5_12_gabbysex_loop2_47c465c7
        "Butt":



            $ ep5_gabbysex_butt = True
            $ player_choice("ep5_gabbysex_butt:true")

            simon "I want to cum on that ass." id ep5_12_gabbysex_loop2_7b50ec7e

            stop foley
            stop voicefx
            show ep5 gabbysex_055_1 with d
            gabby "Quite bold, aren't you?" id ep5_12_gabbysex_loop2_b7215876
            show ep5 gabbysex_055_2 with d
            gabby "I like it!" id ep5_12_gabbysex_loop2_e202ee3a
            simon "Yeah?" id ep5_12_gabbysex_loop2_ee837b79
            show ep5 gabbysex_055_3 with d
            gabby "Come here!"
            gabby "I want you to see me spread wide for you!" id ep5_12_gabbysex_loop2_55d141e6
            show ep5 gabbysex_055_5 with d
            gabby "Do you like that?" id ep5_12_gabbysex_loop2_884147d2
            simon "Yeah!"
            gabby "Then cum for me, [name]!" id ep5_12_gabbysex_loop2_d60583a3
            show ep5 gabbysex_055_4 with d
            gabby "Cum on my ass!" id ep5_12_gabbysex_loop2_7a0d022e
            show ep5 gabbysex_055 with hpunch
            pause 0.5
            show ep5 gabbysex_055 with hpunch
            pause 0.5
            show ep5 gabbysex_055 with hpunch
            pause 0.5
            gabby "Mmmmm..." id ep5_12_gabbysex_loop2_32703351
            simon "Ahhh..."





    $ debug_other_path()
    show ep5 gabbysex_057 with d
    simon "Wow..."
    simon "I can't believe we just did that." id ep5_12_gabbysex_loop2_73559f4c
    show ep5 gabbysex_058 with d
    gabby "So, are you more relaxed now?" id ep5_12_gabbysex_loop2_99511a92
    gabby "I bet you are." id ep5_12_gabbysex_loop2_b455b1d2
    show ep5 gabbysex_059 with d
    simon "I really am..." id ep5_12_gabbysex_loop2_6fa1b261
    play sound dress_shirt_unroll volume 0.7
    show ep5 gabbysex_061 with d
    gabby "But now might not be the best time to relax..." id ep5_12_gabbysex_loop2_f9731b68
    gabby "Since there seems to be someone coming." id ep5_12_gabbysex_loop2_be00bcd8
    play sound get_pants volume 0.7
    show ep5 gabbysex_062 with d
    simon "What?!" id ep5_12_gabbysex_loop2_6c871165
    play sound door_open_hard
    show ep5 gabbysex_063 with vpunch
    janitor "Who's there?!" id ep5_12_gabbysex_loop2_c1d46b12
    show ep5 gabbysex_064 with d
    simon "*Whispers.* Fuck!" id ep5_12_gabbysex_loop2_532a29cd
    simon "*Whispers.* What do we do now?" id ep5_12_gabbysex_loop2_6f7b32ef
    show ep5 gabbysex_065 with d
    gabby "If he finds us, I'll lose my scholarship." id ep5_12_gabbysex_loop2_060a38d3
    gabby "On my first day of college." id ep5_12_gabbysex_loop2_e4dd6ccb
    show ep5 gabbysex_066 with d
    simon "Gabby..."
    simon "Well then..." id ep5_12_gabbysex_loop2_bf4a2a91
    show ep5 gabbysex_067 with d
    simon "(Screw it.)" id ep5_12_gabbysex_loop2_539eceb7
    play music one_chance volume 0.45
    show ep5 gabbysex_068 with d
    janitor "Hey! What are you doing here?!" id ep5_12_gabbysex_loop2_8c338eb0
    show ep5 gabbysex_069 with d
    simon "Me?" id ep5_12_gabbysex_loop2_e6cd7916
    simon "I'm just a relaxed student." id ep5_12_gabbysex_loop2_573d496f
    simon "Remember that." id ep5_12_gabbysex_loop2_a8d44a6e
    show ep5 gabbysex_070 with d
    simon "Gabby..."
    show ep5 gabbysex_071 with vpunch
    simon "RUN!" id ep5_12_gabbysex_loop2_9223670d
    janitor "GET BACK HERE!" id ep5_12_gabbysex_loop2_aa679545
    show ep5 gabbysex_072 with d
    gabby "(Thank you, [name].)" id ep5_12_gabbysex_loop2_91f1de27
    stop music fadeout 5
    $ renpy.end_replay()


    jump ep5_13_universityend
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
