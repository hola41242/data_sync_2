label ep5_24_nextday:





play music morning_birds volume 0.3
scene black with longer_fade
""
show ep5 nextday_001 with longer_fade
simon "Ugh..." id ep5_24_nextday_d646a3db
show ep5 nextday_002 with d
simon "What the fuck...?" id ep5_24_nextday_29c58389
show ep5 nextday_003 with d
simon "(My head is killing me...)" id ep5_24_nextday_29f7d26b
play music kingston_blues fadein 10 volume 0.4
show ep5 nextday_004 with d
simon "(Wait, am I still at the frat house?)" id ep5_24_nextday_464ad82f
simon "(Where is everyone?)" id ep5_24_nextday_65968aef
show ep5 nextday_005 with d
simon "(Ugh...)" id ep5_24_nextday_d3961878
simon "(I'm such a mess.)" id ep5_24_nextday_3395ce47
simon "(I have to clean up and start getting ready for the ball.)" id ep5_24_nextday_476a3697
show ep5 nextday_006 with d
simon "(My phone's dead.)" id ep5_24_nextday_a1edd798
simon "(There should still be plenty of time to figure everything out.)" id ep5_24_nextday_a0c51706
show ep5 nextday_007 with d
simon "(Oh, there's someone over there.)" id ep5_24_nextday_3675135d
show ep5 nextday_008 with d
simon "Hey, um... Bruce, right?" id ep5_24_nextday_cb3e400a
show ep5 nextday_009 with d
bruce "Dance Dance Supreme guy." id ep5_24_nextday_58d2e6f0
bruce "What are you doing here? Did you leave something here last night?" id ep5_24_nextday_636f5460
show ep5 nextday_010 with d
simon "No. I just woke up a second ago, and I'm looking for a place to charge my phone." id ep5_24_nextday_fe0e7ae3
show ep5 nextday_011 with d
bruce "You just woke up?" id ep5_24_nextday_153d8eda
simon "Yeah. I must have blacked out..." id ep5_24_nextday_1312ef21
show ep5 nextday_012 with d
bruce "Are you kidding? Everyone else left hours ago." id ep5_24_nextday_48e5a423
bruce "You can charge your phone here if you want." id ep5_24_nextday_8bcbb8e6
show ep5 nextday_013 with d
simon "Thanks, Bruce."
simon "(I was not supposed to sleep here.)" id ep5_24_nextday_a2ef64d5
show ep5 nextday_014 with wiperight
simon "(I should check my texts. Better make sure I didn't worry anyone.)" id ep5_24_nextday_cc5f0ea1
show ep5 nextday_015 with d
simon "Ninety-seven unread messages?!" id ep5_24_nextday_25ce3aca
show ep5 nextday_016 with d
simon "Goddamn. It's already three in the afternoon!" id ep5_24_nextday_efe32c6b
show ep5 nextday_017 with d
bruce "Hey, could you quiet down over there?"
bruce "But... Holy shit, dude. Ninety-seven messages." id ep5_24_nextday_94b4b57c
bruce "Jealous girlfriend?" id ep5_24_nextday_3007612e
show ep5 nextday_018 with d
simon "No... Most are just random texts from Dylan." id ep5_24_nextday_53eebd40

if chose("ep4_susanhome_accept_the_job"):
    simon "There are texts from my boss though." id ep5_24_nextday_0d4aa0c3
    simon "I'm late meeting up with her..." id ep5_24_nextday_1a9d3aaa
    show ep5 nextday_019 with d
    bruce "Someone's about to get fired..." id ep5_24_nextday_0312dffb

$ debug_other_path()

if chose("ep3_07_cafe2_agree_to_help"):
    show ep5 nextday_021 with d
    simon "There are also texts from my dance group." id ep5_24_nextday_eb79a8a3
    simon "I have to meet up with them before the ball." id ep5_24_nextday_7bd3ad3e
    show ep5 nextday_020 with d
    bruce "You must be really serious about dance." id ep5_24_nextday_29dc0fd2

$ debug_other_path()

if chose("ep5_angels_accept_devillas_job"):
    show ep5 nextday_021 with d
    simon "(Shit. There's even a text from Devilla reminding me of our deal.)" id ep5_24_nextday_0a38023a

$ debug_other_path()

show ep5 nextday_021 with d
simon "There are a few people asking where I am." id ep5_24_nextday_ff8d02c5
simon "Maybe Dylan's right. I have a whole group of people surrounding me right now." id ep5_24_nextday_d6c99bf2
show ep5 nextday_022 with d
bruce "Honestly, dude, yesterday I saw you with a whole bunch of people having fun and enjoying the party." id ep5_24_nextday_627574e9
bruce "It's been a while since I saw a freshman pull out all the stops." id ep5_24_nextday_69698de9
bruce "Yet you seem a bit frazzled. What's going down?" id ep5_24_nextday_492ddba5
show ep5 nextday_023 with d
simon "I have a charity ball to go to tonight." id ep5_24_nextday_be799a0d
simon "It's really important." id ep5_24_nextday_a268ea51
show ep5 nextday_024 with d
simon "(What am I doing, telling all this to a complete stranger?)" id ep5_24_nextday_779b920c
simon "You know, never mind." id ep5_24_nextday_675085d1
show ep5 nextday_025 with d
bruce "No, wait. What's your deal?" id ep5_24_nextday_1e02ae28
show ep5 nextday_023 with d
simon "It's just going to be hard getting in. And I don't know if I'm ready." id ep5_24_nextday_402e93dc
show ep5 nextday_026 with d
bruce "I don't know about any balls but mine. However..."
simon "However...?"
bruce "I can tell you one thing: It sounds like this is real important to you." id ep5_24_nextday_26f16bd5
show ep5 nextday_027 with d
bruce "And if it's important to you, it's like how my balls are to me." id ep5_24_nextday_cf5c7d1c
bruce "They're real important." id ep5_24_nextday_9fbbd928
bruce "I once found a smudge on them and just about went crazy. Didn't know what to do." id ep5_24_nextday_8f78d68a
show ep5 nextday_028 with d
simon "What?!" id ep5_24_nextday_6c871165
show ep5 nextday_027 with d
bruce "The doctor I usually go to had no time to see me that day." id ep5_24_nextday_62e685f4
bruce "But I was going there one way or another." id ep5_24_nextday_9e9c16d2
bruce "So that's just what I did." id ep5_24_nextday_df6c9aa5
show ep5 nextday_029 with d
bruce "I went straight in the front door and demanded he see me." id ep5_24_nextday_906c1a78
show ep5 nextday_030 with d
simon "But wasn't that kind of... wrong?" id ep5_24_nextday_a8485d74
simon "You took someone else's spot." id ep5_24_nextday_22bdcaf6
show ep5 nextday_031 with d
bruce "Dude, that's what I'm telling you." id ep5_24_nextday_e0513d3d
bruce "It wasn't wrong because, in the end, he did see me, and then he saw everyone else right after." id ep5_24_nextday_70b7f60e
bruce "What I'm trying to say is, there's always a way." id ep5_24_nextday_9e497b61
show ep5 nextday_032 with d
bruce "Even if you have to kick down the front door and roar like a lion or something."
bruce "Yesterday, I saw your determination." id ep5_24_nextday_6b302a30
bruce "Today, I see your soul." id ep5_24_nextday_f0df4243
bruce "There isn't a thing you can't do, man!" id ep5_24_nextday_f0dc70c8
show ep5 nextday_033 with d
simon "Wow... That was... kind of inspirational at the end there." id ep5_24_nextday_f96b0b34
simon "Thank you, Bruce." id ep5_24_nextday_9d1911a8
show ep5 nextday_034 with d
simon "What was wrong with your balls in the end?" id ep5_24_nextday_40119c36
show ep5 nextday_035 with d
bruce "Oh, it was nothing. Just a smudge after all." id ep5_24_nextday_5c63cb45
show ep5 nextday_036 with d
simon "Hmm." id ep5_24_nextday_e4d7d873
bruce "Now go kick some ass, tiger." id ep5_24_nextday_188bc717
stop music fadeout 5


show ep5 nextday_037 with wiperight
simon "Thanks, Bruce."

jump ep5_25_preball
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
