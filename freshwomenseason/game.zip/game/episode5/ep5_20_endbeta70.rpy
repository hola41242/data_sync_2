label ep5_20_endbeta70:
    $ percentage_completed = 70
    call end_of_beta (5) from _call_end_of_beta_2



    jump ep5_20_beerpong
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
