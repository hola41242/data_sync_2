
label ep5_15_lilycall:
    show ep5 lilycall_001 with d
    simon "(I think taking a walk might help me clear my head.)" id ep5_15_lilycall_07b48cc8
    simon "(I just want to relax today. Leave the drama for tomorrow.)" id ep5_15_lilycall_fcbc5d67
    play music eternity fadein 6 volume 0.5
    play sound phone_vibrate2 volume 0.1 
    show ep5 lilycall_002 with d
    simon "(Or perhaps drama has its way of finding me.)" id ep5_15_lilycall_c9a4a1e6
    stop sound
    show ep5 lilycall_003 with d
    simon "Hi, Lily." id ep5_15_lilycall_9d4fe2a2
    show ep5 lilycall_004 with d
    lily "Can we talk?" (what_italic=True)
    show ep5 lilycall_003 with d
    simon "I guess we have to." id ep5_15_lilycall_1589e919
    simon "But, don't worry, I already moved out of the apartment." id ep5_15_lilycall_b595259c
    show ep5 lilycall_004 with d
    simon "(She doesn't need to know I have nowhere to go.)" id ep5_15_lilycall_a8e6a508
    lily "Could you come over?" (what_italic=True)
    show ep5 lilycall_005 with d
    simon "Wouldn't that be a bad idea?" id ep5_15_lilycall_ce49e52a
    show ep5 lilycall_006 with d
    lily "Don't worry." (what_italic=True)
    lily "He's not here." (what_italic=True)
    show ep5 lilycall_007 with d
    lily "Sam's a bully." (what_italic=True)
    lily "He's all bark and no bite." (what_italic=True)

    if choice_made("ep4_lunch2_i_fucked_your_wife"):
        show ep5 lilycall_008 with d
        simon "But what about you?" id ep5_15_lilycall_f02e0843
        simon "Are you sure you want to see me?" id ep5_15_lilycall_6aa7368f
        show ep5 lilycall_007 with d
        lily "I don't know." (what_italic=True)
        lily "But we need to talk." (what_italic=True)
        lily "I'll be waiting for you here." (what_italic=True)
        play sound phone_call_end volume 0.4 
        show ep5 lilycall_009 with d
        simon "(Shit.)" id ep5_15_lilycall_7f8d675e
    else:

        show ep5 lilycall_007 with d
        lily "I'll be waiting for you here." (what_italic=True)
        play sound phone_call_end 
        show ep5 lilycall_010 with d
        simon "(I've seen a whole lot of bite in him, Lily.)" id ep5_15_lilycall_b3e760e9

    $ debug_other_paths()
    jump ep5_16_lilyhome
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
