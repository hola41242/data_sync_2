label ep5_28_blackout:


    show ep5 blackout_001 with longer_fade
    deliveryman "Why is he taking so long?" id ep5_28_blackout_0c7e4284

    play music ritual_mole_sacrifice volume 0.3

    scene black with longer_fade
    pause 1


    show ep5 blackout_002 with longer_fade
    emily "Wakey-wakey!" id ep5_28_blackout_be4e62b7
    simon "What the ...?" id ep5_28_blackout_e3927361
    show ep5 blackout_003 with long_dissolve
    simon "Emily!" id ep5_28_blackout_37cf406d
    show ep5 blackout_004 with d
    emily "It's me, all right!" id ep5_28_blackout_c47b0acd
    show ep5 blackout_003 with d
    simon "What happened? I felt so dizzy and..." id ep5_28_blackout_3cc90f6d
    show ep5 blackout_005 with d
    simon "Sam?!" id ep5_28_blackout_f7bb95eb
    simon "Is he — ?" id ep5_28_blackout_b7974991
    show ep5 blackout_004 with d
    emily "Yeah, he's alive." id ep5_28_blackout_58eedf84
    emily "For now at least..." id ep5_28_blackout_c307d01c
    simon "At least? What do you mean by that?" id ep5_28_blackout_4b844e6b
    show ep5 blackout_006 with d
    simon "And why am I tied up?" id ep5_28_blackout_df265d0d
    simon "What's going on, Emily?" id ep5_28_blackout_c190464c
    show ep5 blackout_007 with d
    emily "That? It's for your own safety." id ep5_28_blackout_c237a7eb
    emily "I didn't want you to hurt yourself when you came to." id ep5_28_blackout_1d2cb1a3
    show ep5 blackout_008 with d
    simon "So... what's this all about?" id ep5_28_blackout_460b4798
    show ep5 blackout_009 with d
    emily "You really don't remember me, do you?" id ep5_28_blackout_9bfa791d
    show ep5 blackout_010 with d
    simon "I... I remember a few things." id ep5_28_blackout_7f4bb112
    emily "Like what?"
    show ep5 blackout_011 with d
    simon "I remember us at the ball a few years back." id ep5_28_blackout_f0524da8
    show ep5 blackout_012 with d
    emily "Glad the photo kick-started your memory." id ep5_28_blackout_1ad2a4bd
    show ep5 blackout_013 with d
    simon "What do you want, Emily?" id ep5_28_blackout_cf291742

    emily "What I've always wanted!" id ep5_28_blackout_c0cde163
    emily "To help you!" id ep5_28_blackout_3ae747e7
    show ep5 blackout_014 with d
    simon "And tying me up helps how?!" id ep5_28_blackout_72f6b75c
    play sound rope_untie_knot volume 0.5
    show ep5 blackout_015 with d
    emily "You're right. Here. Let me help." id ep5_28_blackout_e29487a9
    simon "Good. Thanks." id ep5_28_blackout_313fb8e4
    show ep5 blackout_016 with d
    simon "Now untie him." id ep5_28_blackout_1ef2b439
    emily "What?"
    show ep5 blackout_017 with d
    emily "But now's your chance!" id ep5_28_blackout_fa7df4d4
    show ep5 blackout_018 with d
    simon "I'm not going to kill him, Emily!" id ep5_28_blackout_dba1d94a
    show ep5 blackout_019 with d
    emily "But isn't that what you wanted?!" id ep5_28_blackout_f4c7b401
    emily "For what he did to your father!" id ep5_28_blackout_a625247e
    show ep5 blackout_020 with d
    simon "Do you know what he did to my father?" id ep5_28_blackout_f98a3133
    show ep5 blackout_021 with d
    emily "Of course!" id ep5_28_blackout_a15e1153
    emily "It was you who told me. Before your accident." id ep5_28_blackout_9fc5d43f
    emily "Him, Charlie, Susan... They're all to blame." id ep5_28_blackout_da67bbaf
    emily "And I'm going to help you end them all." id ep5_28_blackout_0d7e5e5f
    show ep5 blackout_018 with d
    simon "No, Emily! That's not what I want!" id ep5_28_blackout_6ad010a7
    simon "I want answers." id ep5_28_blackout_cb2afb75
    show ep5 blackout_022 with d
    simon "The person I was before..." id ep5_28_blackout_31c62c7a
    simon "... He was impulsive and destructive." id ep5_28_blackout_a45b1547
    simon "I don't want to be like that anymore." id ep5_28_blackout_204ac7c2
    simon "Also, these people are dangerous. We're risking our lives if we do this." id ep5_28_blackout_545d2cb2
    show ep5 blackout_023 with d
    emily "Okay. But I won't be the one to let him go." id ep5_28_blackout_85b5b9e0
    emily "If you want answers, they're right here in front of you." id ep5_28_blackout_47480779
    emily "Are you really going to let him go?" id ep5_28_blackout_6f059938

    menu:
        "Interrogate Sam":
            $ save("ep5_blackout_interrogate_sam")
            show ep5 blackout_024 with d
            simon "Fine. I won't hurt him, but I think I can get some information out of him." id ep5_28_blackout_90d8b40c
            simon "Are you sure no one will come back here while I do?" id ep5_28_blackout_22c53f4e
            show ep5 blackout_025 with d
            emily "I can keep watch." id ep5_28_blackout_88b226d8
            play sound jail_door_cell4 volume 0.7
            show ep5 blackout_026 with vpunch
            emily "Oh." id ep5_28_blackout_888e0ac6
            emily "Looks like someone's already here." id ep5_28_blackout_c48bb4e7
            emily "Sooner than I expected." id ep5_28_blackout_ce767310
            show ep5 blackout_027 with d
            deliveryman "What's going on?" id ep5_28_blackout_9ad1ee97
            show ep5 blackout_028 with d
            simon "Oh! This isn't what it looks like!" id ep5_28_blackout_f2526da5
            show ep5 blackout_029 with d
            deliveryman "What is it then?" id ep5_28_blackout_751bc144
            deliveryman "I-Is he..." id ep5_28_blackout_c14c1e13
            simon "He's alive." id ep5_28_blackout_13ff307a
            simon "He's fine." id ep5_28_blackout_4f444e16
            show ep5 blackout_030 with d
            deliveryman "Good. Sam plays a very important role in this." id ep5_28_blackout_72e2736e
            show ep5 blackout_031 with d
            deliveryman "And you, girl." id ep5_28_blackout_eaef9ccc
            deliveryman "You're the one who arranged for the delivery, aren't you?" id ep5_28_blackout_33e74825
        "Release Sam":

            $ save("ep5_blackout_release_sam")
            show ep5 blackout_032 with d
            simon "Let him go, Emily." id ep5_28_blackout_28284856
            simon "This is all wrong." id ep5_28_blackout_f9a2c0aa
            show ep5 blackout_033 with d
            emily "I'm the one who should be saying that to you!" id ep5_28_blackout_a3bba738
            show ep5 blackout_034 with d
            emily "It's really a shame you can't see things for what they are, [name]." id ep5_28_blackout_2d3b4ca1
            emily "Our delivery man has arrived." id ep5_28_blackout_3d1a523e
            play sound jail_door_cell4 volume 0.7
            show ep5 blackout_035 with vpunch
            simon "Who?!" id ep5_28_blackout_9dd3e07f
            show ep5 blackout_036 with d
            emily "Hello, Mr. Delivery Man. Your package is right here." id ep5_28_blackout_8b69b7d8
            show ep5 blackout_037 with d
            deliveryman "What? What's going on?" id ep5_28_blackout_ecc4c3c7
            show ep5 blackout_038 with d
            simon "She's insane. Please, help me." id ep5_28_blackout_c32f2275
            show ep5 blackout_039 with d
            deliveryman "Is that Sam?" id ep5_28_blackout_b99027ce
            show ep5 blackout_040 with d
            simon "Yeah, you were about to get a delivery from him, weren't you?" id ep5_28_blackout_f310f642
            show ep5 blackout_030 with d
            deliveryman "Yes." id ep5_28_blackout_a5fa2346
            show ep5 blackout_031 with d
            deliveryman "So you're the girl who organized all this?" id ep5_28_blackout_8593ab5e

    $ debug_other_path()

    show ep5 blackout_041 with d
    emily "Yep, it was all me." id ep5_28_blackout_36244b16
    show ep5 blackout_042 with d
    deliveryman "Then you should leave." id ep5_28_blackout_1e78ed5c
    deliveryman "And you, boy. You're coming with me." id ep5_28_blackout_621a37cb
    show ep5 blackout_043 with d
    deliveryman "I'm sorry to drag you into this, but this goes way deeper than you could ever imagine." id ep5_28_blackout_68271726
    simon "What are you talking about?!" id ep5_28_blackout_cd71b2bb
    play sound body_thud volume 0.7
    show ep5 blackout_044 with hpunch
    simon "Wait, I —" id ep5_28_blackout_5a8eca0d
    simon "Mmmph..." id ep5_28_blackout_7410c844
    play sound hit_reverb_dark volume 0.7
    show ep5 blackout_045 with medium_fade
    pause
    play sound hit_reverb_dark volume 0.7
    show ep5 blackout_046 with medium_fade
    pause


    play sound hit_reverb_dark volume 0.7
    show ep5 blackout_047 with medium_fade
    pause




    play sound jeep_start_idle volume 0.3
    show ep5 blackout_049 with medium_fade
    deliveryman "Look, girl. I don't know who you are or who you're working for..." id ep5_28_blackout_42c1354d
    deliveryman "But thanks for bringing me to Sam." id ep5_28_blackout_0b5b8808
    deliveryman "And more importantly..." id ep5_28_blackout_0f388e0d
    stop music fadeout 3
    show ep5 blackout_050 with medium_fade
    play sound_2 horror_ghostly volume 0.5
    deliveryman "... to my son." id ep5_28_blackout_55d2a907


    stop sound fadeout 3

jump ep5_31_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
