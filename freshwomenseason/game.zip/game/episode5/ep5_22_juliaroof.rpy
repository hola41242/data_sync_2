label ep5_22_juliaroof:






play music tired volume 0.37
show ep5 juliaroof_001 with wiperight
simon "Hey... I finally found you!" id ep5_22_juliaroof_f17fae61
show ep5 juliaroof_002 with d
julia "[name]! Take a look at this view." id ep5_22_juliaroof_16674884
show ep5 juliaroof_003 with d
simon "Wow... not bad." id ep5_22_juliaroof_9ceff92b
simon "(This must be the balcony of Bruce's bedroom.)" id ep5_22_juliaroof_5d689cd3
simon "How'd you end up here?" id ep5_22_juliaroof_cc75ba55
show ep5 juliaroof_004 with d
julia "Oh, the door was open, so I just let myself in." id ep5_22_juliaroof_1dc131fc
julia "If I wasn't supposed to come in, they would've locked it, right?" id ep5_22_juliaroof_892ab4e1
show ep5 juliaroof_005 with d
simon "I guess so." id ep5_22_juliaroof_bc552e05
show ep5 juliaroof_004_1 with d
julia "Did you give up on the short shorts?" id ep5_22_juliaroof_30389e80
julia "I liked them." id ep5_22_juliaroof_6fa4542e
show ep5 juliaroof_005 with d
simon "Dylan lent me a change of clothes." id ep5_22_juliaroof_c00973a1
show ep5 juliaroof_007 with d
julia "This way it'll be easier to hide it if you get turned on because of a certain competition." id ep5_22_juliaroof_dacd89c2
show ep5 juliaroof_006 with d
simon "I think I've had enough competition for today." id ep5_22_juliaroof_b36c7dc2

if not chose("ep2_julia_glitch_2"):
    show ep5 juliaroof_008 with d
    julia "Yup. Losing all the time must be really tiring." id ep5_22_juliaroof_09dece9a
else:

    show ep5 juliaroof_008 with d
    julia "Playing a game without taking advantage of a controller glitch isn't so fun, is it?" id ep5_22_juliaroof_cac9da6e

$ debug_other_path()

show ep5 juliaroof_006 with d
simon "No, that's not it... I think Dylan's really pissed at me." id ep5_22_juliaroof_45536bf2
simon "He asked me to help him make friends, and I didn't take him serious enough." id ep5_22_juliaroof_54d01dbb
simon "I've been too worried about my own problems." id ep5_22_juliaroof_5628c85b
show ep5 juliaroof_007 with d
julia "I don't think you should blame yourself too much." id ep5_22_juliaroof_78c6b2b4
julia "Dylan is a bit of a goof, for real." id ep5_22_juliaroof_c474ecb2
julia "And you're a nice guy, [name]." id ep5_22_juliaroof_5360e096

if chose("ep2_julia_kiss"):

    if chose("ep4_livingsituation_julia"):
        show ep5 juliaroof_006 with d
        simon "Your mom doesn't seem to agree." id ep5_22_juliaroof_e6e7cf34
        show ep5 juliaroof_008 with d
        julia "Hahaha." id ep5_22_juliaroof_c514c728
        show ep5 juliaroof_009 with d
        julia "She's not here to disturb us right now." id ep5_22_juliaroof_91988700
        simon "Are you thinking about..." id ep5_22_juliaroof_66e41144
        julia "... Continuing where we left off?" id ep5_22_juliaroof_70879874
        julia "Again." id ep5_22_juliaroof_092d474d
    else:

        show ep5 juliaroof_006 with d
        simon "You think so?" id ep5_22_juliaroof_f08ac222
        show ep5 juliaroof_008 with d
        julia "Yup. Only a cool kid would own a Super System 64." id ep5_22_juliaroof_5e61a2c2
        show ep5 juliaroof_009 with d
        julia "In fact... I have really fond memories of our day together." id ep5_22_juliaroof_88c81705
        simon "If you want, we could..." id ep5_22_juliaroof_0d31d623
        julia "... Continue where we left off?" id ep5_22_juliaroof_adbb8f48

    $ debug_other_path()

    show ep5 juliaroof_010 with d
    pause
    show ep5 juliaroof_011 with d
    boy "Hey, get a room!"
    play sound wood_hit volume 0.2
    show ep5 juliaroof_012 with vpunch
    simon "Do you think many people saw us?"
    show ep5 juliaroof_013 with d
    julia "I don't think so. There weren't that many people down there."
    julia "But, is there a problem if someone does see us together?" id ep5_22_juliaroof_33b6b27e
    show ep5 juliaroof_014 with d
    simon "No, of course not."
    simon "I just don't want to draw attention."
    show ep5 juliaroof_015 with d
    julia "We can head inside." id ep5_22_juliaroof_b4aaff86
    show ep5 juliaroof_016 with d
    simon "What if someone walks in on us?" id ep5_22_juliaroof_594abac6
    show ep5 juliaroof_015 with d
    julia "The key's in the door. I already checked." id ep5_22_juliaroof_bab17da8
    julia "Shall we?" id ep5_22_juliaroof_b0d8ecd9

    menu:
        "Let's"(True):
            $ save("ep5_juliaroof_we_will")
            show ep5 juliaroof_017 with d
            simon "Let's." id ep5_22_juliaroof_9090ccf0
            jump ep5_23_juliasex
        "Better not":

            $ save("ep5_juliaroof_best_not")
            show ep5 juliaroof_014 with d
            simon "Better not." id ep5_22_juliaroof_09f6195d
            simon "Your first time needs to be special, not some drunken night at a frat party." id ep5_22_juliaroof_1f0d5e0d
            show ep5 juliaroof_013 with d
            julia "I'm not drunk, but... I guess you're right." id ep5_22_juliaroof_7bba1674
            julia "I think I'd better go. My mom doesn't even know I'm here." id ep5_22_juliaroof_dbe472ed
            julia "Will we see each other around campus?" id ep5_22_juliaroof_4b3e0360
            show ep5 juliaroof_018 with d
            simon "Definitely."
            show ep5 juliaroof_019 with wipeup
            simon "(I think I blew it today.)"
            show ep5 juliaroof_020 with d
            simon "(Everyone I know already left.)"
            simon "(I guess I could head back to the party, drink some more, and meet other people.)"
            show ep5 juliaroof_021 with d
            simon "(After all, this is a college party!)"
            jump ep5_24_nextday

    $ debug_other_path()
else:

    show ep5 juliaroof_006 with d
    simon "I think you're the only one who thinks that." id ep5_22_juliaroof_53ac76d5
    show ep5 juliaroof_007 with d
    julia "Why would you say that?" id ep5_22_juliaroof_abba5d28
    show ep5 juliaroof_006 with d
    simon "I don't know. Everyone got a little weird after beer pong." id ep5_22_juliaroof_886b1d7d
    show ep5 juliaroof_007 with d
    julia "Do you think that's something you can fix right now?" id ep5_22_juliaroof_58003cf4
    show ep5 juliaroof_006 with d
    simon "They've already left." id ep5_22_juliaroof_bd37e24d
    show ep5 juliaroof_008 with d
    julia "Then relax." id ep5_22_juliaroof_f58658bf
    show ep5 juliaroof_022 with d
    simon "Thanks, Julia." id ep5_22_juliaroof_27c07ecd
    show ep5 juliaroof_023 with d
    pause
    show ep5 juliaroof_011 with d
    boy "Hey, get a room!"
    play sound wood_hit volume 0.2
    show ep5 juliaroof_012 with vpunch
    simon "Do you think a lot of people saw us?"
    show ep5 juliaroof_013 with d
    julia "I don't think so. There weren't that many people down there."
    julia "But, is there a problem if someone were to see us kissing?" id ep5_22_juliaroof_29184b54
    show ep5 juliaroof_014 with d
    simon "No, of course not."
    simon "I just don't want to draw attention."
    show ep5 juliaroof_013 with d
    julia "Gotcha. Maybe we'd better just head downstairs." id ep5_22_juliaroof_98758998
    julia "In fact, it's getting late. I think I'd better go." id ep5_22_juliaroof_1515b8b7
    julia "My mom doesn't even know I'm here." id ep5_22_juliaroof_b829aa78
    julia "See you around campus?" id ep5_22_juliaroof_1b51974b
    show ep5 juliaroof_018 with d
    simon "Definitely."
    show ep5 juliaroof_019 with wipeup
    simon "(I think I blew it today.)"
    show ep5 juliaroof_020 with d
    simon "(Everyone I know already left.)"
    simon "(I should just head back to the party, drink some more, and meet other people.)"
    show ep5 juliaroof_021 with d
    simon "(After all, this is a college party!)"

    jump ep5_24_nextday

$ debug_other_path()

jump ep5_23_juliasex
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
