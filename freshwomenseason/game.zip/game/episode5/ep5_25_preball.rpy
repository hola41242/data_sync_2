label ep5_25_preball:


play music taking_my_time fadein 10 volume 0.4
show ep5 preball_001 with fast_fade
simon "(I should at least change before going to the ball.)" id ep5_25_preball_1b9c8872

if chose("ep3_07_cafe2_agree_to_help"):
    simon "(Alyssa will probably have my dance uniform ready.)" id ep5_25_preball_a80f27fe

$ debug_other_path()


show ep5 preball_002 with fast_fade
simon "(Let's see if Emily has any more surprises for me.)" id ep5_25_preball_254602d0


show ep5 preball_003 with wipeup
simon "(A place to rest and a warm shower. Even some clean clothes.)" id ep5_25_preball_a2edaab5


play sound shower volume 0.4
show ep5 preball_004 with d
simon "(If she weren't batshit crazy, Emily would make a good wife.)" id ep5_25_preball_e6ef9cef
show ep5 preball_005 with d
simon "(What the fuck am I thinking?)" id ep5_25_preball_5c3e9001
simon "(I must be insane just for coming back here.)" id ep5_25_preball_1ed24b3e
stop sound
show ep5 preball_006 with d
simon "(I've got to get out of here as quick as I can.)" id ep5_25_preball_0616c1fb

if chose("ep5_angels_accept_devillas_job"):


    show ep5 preball_007 with wiperight
    simon "(I should talk to my new boss.)" id ep5_25_preball_549d3cda
    show ep5 preball_008 with d
    simon "Hey, Dev." id ep5_25_preball_22c9b923


    show ep5 preball_009 with d
    devilla "What? Who the hell is this?" id ep5_25_preball_1b545af8
    show ep5 preball_010 with d
    simon "It's me, [name]." (what_italic=True)
    show ep5 preball_011 with d
    devilla "Oh, my handsome boy." id ep5_25_preball_b48efcfc
    devilla "I didn't think you'd actually call." id ep5_25_preball_adf8e591
    devilla "Are you ready to start work?" id ep5_25_preball_b1982f55
    show ep5 preball_012 with d
    simon "I'm ready." (what_italic=True)
    show ep5 preball_013 with d
    devilla "Are you sure? It's a hard job." id ep5_25_preball_ad49ea4e
    show ep5 preball_014 with d
    simon "I'm sure. This is very important to me." id ep5_25_preball_e3c824af
    show ep5 preball_011 with d
    devilla "Excellent! Then you pass my test." id ep5_25_preball_3e6352a9
    devilla "I'll give you your ticket to the ball." id ep5_25_preball_d456106f
    show ep5 preball_012 with d
    simon "Seriously? This was all just a test?" id ep5_25_preball_f4bbc52e
    show ep5 preball_011 with d
    devilla "Of course not. You're really going to be working for me." id ep5_25_preball_943a7243
    devilla "Just consider this a down payment." id ep5_25_preball_adc0d2c6
    devilla "Come to the entrance and say the password." id ep5_25_preball_09af5933
    show ep5 preball_012 with d
    simon "What's the password?" (what_italic=True)
    show ep5 preball_015 with d
    devilla "Hell Angels rule!" id ep5_25_preball_0a44d47f


    show ep5 preball_016 with d
    simon "You really do." id ep5_25_preball_77b9a48d
    devilla "We know." (what_italic=True)

$ debug_other_path()

stop music fadeout 7

jump ep5_26_theball
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
