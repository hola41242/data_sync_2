label ep5_13_endbeta40:

    $ percentage_completed = 40
    call end_of_beta (5) from _call_end_of_beta


    jump ep5_20_beerpong
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
