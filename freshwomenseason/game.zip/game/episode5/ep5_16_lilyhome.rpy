label ep5_16_lilyhome:

show ep5 lilyhome_001 with long_fade
simon "(Hmm...)" id ep5_16_lilyhome_b9c55da2
show ep5 lilyhome_002 with d
play sound intercom_ring volume 0.3
simon "(This time I'll buzz her intercom, just to be sure.)" id ep5_16_lilyhome_88f6a4a5
show ep5 lilyhome_003 with d
lily "Come in." (what_italic=True)
show ep5 lilyhome_004 with d
simon "(What a strange feeling, being back here again.)" id ep5_16_lilyhome_62a35764
play sound door volume 0.6
play music winter_rain fadein 8 volume 0.35
show ep5 lilyhome_005 with d
lily "Hi, [name]." id ep5_16_lilyhome_f9042763
simon "Hi, Lily." id ep5_16_lilyhome_d99489d2
show ep5 lilyhome_006 with d
lily "Come on in." id ep5_16_lilyhome_158322c5
play sound door_closing2 volume 0.6
show ep5 lilyhome_007 with d
simon "Like I said..."
simon "I already packed up and vacated the apartment." id ep5_16_lilyhome_92a3f0f0
show ep5 lilyhome_008 with d
simon "I didn't have many things anyway." id ep5_16_lilyhome_3b521c6c
show ep5 lilyhome_009 with d
simon "Here's the key." id ep5_16_lilyhome_b75e162d
show ep5 lilyhome_010 with d
lily "Thanks..."
lily "And sorry about that." id ep5_16_lilyhome_63e3b693

if choice_made("ep4_lunch2_i_fucked_your_wife"):
    show ep5 lilyhome_011 with d
    simon "You're sorry?" id ep5_16_lilyhome_fc260e29
    simon "You were the one who kicked me out of the apartment." id ep5_16_lilyhome_c02758a8
    show ep5 lilyhome_012 with d
    lily "And you're the one who chose to say what you did." id ep5_16_lilyhome_90adceab
    show ep5 lilyhome_013 with d
    lily "Why did you tell Sam the truth?" id ep5_16_lilyhome_26fb7dc3
    lily "Was it just to feel superior?" id ep5_16_lilyhome_f7a78905
    show ep5 lilyhome_014 with d
    simon "I... I just wanted to hurt him." id ep5_16_lilyhome_77ab6905
    show ep5 lilyhome_015 with d
    simon "The things he said..." id ep5_16_lilyhome_fa3854ed
    show ep5 lilyhome_016 with d
    lily "I know." id ep5_16_lilyhome_d83d00de
    show ep5 lilyhome_017 with d
    lily "That's why I'm sorry." id ep5_16_lilyhome_994644cd
    lily "But..." id ep5_16_lilyhome_5e1e62ec
    show ep5 lilyhome_018 with d
    lily "This is what we need to talk about." id ep5_16_lilyhome_ac948a36
    simon "(Chloe's flash drive!)"
    simon "(She must have seen the videos we took of Susan and her.)" id ep5_16_lilyhome_356e81af
    show ep5 lilyhome_019 with d
    lily "This was... Well, there are no words to describe how I feel." id ep5_16_lilyhome_1ba958c8
    show ep5 lilyhome_020 with d
    lily "However, as creepy as it was, I understand the reason behind doing something like this." id ep5_16_lilyhome_e828651e
    show ep5 lilyhome_021 with d
    simon "I needed to know more." id ep5_16_lilyhome_229cb27c
    show ep5 lilyhome_022 with d
    lily "I'll tell you what I know." id ep5_16_lilyhome_1480f0ff
    show ep5 lilyhome_023 with d
    simon "No thanks." id ep5_16_lilyhome_cbbf3194
    show ep5 lilyhome_024 with d
    lily "What? What do you mean?" id ep5_16_lilyhome_d63b4beb
    show ep5 lilyhome_025 with d
    simon "Susan already told me about Sam's dealings with my father." id ep5_16_lilyhome_f26ccc42
    simon "And she also told me about the ball tomorrow." id ep5_16_lilyhome_ae3665cd
    show ep5 lilyhome_026 with d
    lily "I see." id ep5_16_lilyhome_b5671827
    lily "So you're going to the ball too?" id ep5_16_lilyhome_75b279ce
    show ep5 lilyhome_025 with d
    simon "I am."
    show ep5 lilyhome_027 with d
    lily "Sam won't like that." id ep5_16_lilyhome_4899e872
    lily "He'll be there. You should be on your guard." id ep5_16_lilyhome_5083c64d
    show ep5 lilyhome_028 with d
    simon "I'll come up with a plan." id ep5_16_lilyhome_04b3d1be
    show ep5 lilyhome_027 with d
    lily "Just..." id ep5_16_lilyhome_c979561c
    lily "Don't make any more trouble for yourself, okay?" id ep5_16_lilyhome_35e1e802
    show ep5 lilyhome_029 with d
    simon "I'll do whatever it takes." id ep5_16_lilyhome_47727310
    simon "Will you be there as well?" id ep5_16_lilyhome_2bcb8c15
    show ep5 lilyhome_030 with d
    lily "No." id ep5_16_lilyhome_97d62de8
else:

    show ep5 lilyhome_031 with d
    simon "You tried your best." id ep5_16_lilyhome_5f38e41a
    simon "You don't need to worry about me." id ep5_16_lilyhome_98ff62f8
    show ep5 lilyhome_032 with d
    lily "I think I should worry a little." id ep5_16_lilyhome_716f3185
    show ep5 lilyhome_018 with d
    lily "We haven't talked about this yet." id ep5_16_lilyhome_a3ca1289
    simon "(Chloe's flash drive!)"
    simon "(She must have seen the videos we took of Susan and her.)" id ep5_16_lilyhome_aef4a10c
    show ep5 lilyhome_033 with d
    lily "As much as I don't approve..." id ep5_16_lilyhome_6876ef3d
    lily "I understand why you did this." id ep5_16_lilyhome_23cf3ade
    show ep5 lilyhome_034 with d
    lily "If you want, I can tell you what I know about your father." id ep5_16_lilyhome_110625a9
    show ep5 lilyhome_035 with d
    simon "Susan told me about his dealings with Sam and about the charity ball." id ep5_16_lilyhome_bdf0d52f
    show ep5 lilyhome_036 with d
    lily "Oh..."
    lily "Then you already know everything I know." id ep5_16_lilyhome_4a9d54fe
    show ep5 lilyhome_035 with d
    simon "I think so." id ep5_16_lilyhome_bc552e05
    show ep5 lilyhome_037 with d
    lily "Will you try to attend the ball?" id ep5_16_lilyhome_32f57653
    show ep5 lilyhome_038 with d
    simon "Yes."
    simon "Will you be there too?" id ep5_16_lilyhome_1483f179
    show ep5 lilyhome_039 with d
    lily "Oh, no. Not a chance." id ep5_16_lilyhome_4edd5f55
    simon "Why not?" id ep5_16_lilyhome_dcea2581

$ debug_other_paths()

show ep5 lilyhome_040 with d
simon "You don't look very well." id ep5_16_lilyhome_513172f2
show ep5 lilyhome_041 with d
lily "I don't want to be anywhere near a place serving alcohol." id ep5_16_lilyhome_c195aef4
show ep5 lilyhome_042 with d
simon "(Right... The night we had sex, she'd already had a few drinks.)" id ep5_16_lilyhome_17a9e68c
simon "(And that time she offered me tea, I caught a whiff of booze coming from her cup.)" id ep5_16_lilyhome_bf40c644

simon "(That explains a lot.)" id ep5_16_lilyhome_75b84d2d
show ep5 lilyhome_043 with d
simon "I think I should go." id ep5_16_lilyhome_69d3e612
show ep5 lilyhome_044 with d
lily "Of course." id ep5_16_lilyhome_c0aa354c
lily "I won't try to make you stay." id ep5_16_lilyhome_4fb7a495
show ep5 lilyhome_045 with d
lily "You should take this." id ep5_16_lilyhome_4d41ccb6
show ep5 lilyhome_046 with d
simon "Thanks." id ep5_16_lilyhome_71286ac3
show ep5 lilyhome_047 with d
lily "I deleted the videos of Susan, but I left your girlfriend's videos." id ep5_16_lilyhome_8428899e
lily "She's pretty by the way." id ep5_16_lilyhome_45e28b92
show ep5 lilyhome_048 with d
simon "My girlfriend?" id ep5_16_lilyhome_9318671d
simon "Are you talking about Chloe?" id ep5_16_lilyhome_71184b24
show ep5 lilyhome_049 with d
lily "Yeah, the girl with the glasses." id ep5_16_lilyhome_4ed7aea7
show ep5 lilyhome_050 with d
simon "She's not my girlfriend." id ep5_16_lilyhome_3badf7b5
show ep5 lilyhome_051 with d
lily "I see. Then she must be another sort of friend." id ep5_16_lilyhome_bbe78e04
lily "She is very pretty though." id ep5_16_lilyhome_2c477f35
lily "Honestly, I wouldn't be surprised if you've already got a girlfriend." id ep5_16_lilyhome_eab33e92
show ep5 lilyhome_052 with d
lily "Anyway, I've already taken up too much of your time." id ep5_16_lilyhome_1a53e0a6
show ep5 lilyhome_053 with d
simon "Okay, I'll be off then..." id ep5_16_lilyhome_317411fa
simon "Or..." id ep5_16_lilyhome_c716bc75
show ep5 lilyhome_054 with d
simon "Is it that you want me to stay?" id ep5_16_lilyhome_abe8d875
show ep5 lilyhome_055 with d
lily "No, you don't have to do that..." id ep5_16_lilyhome_6da276e2
lily "Unless you want to..." id ep5_16_lilyhome_7ced159c

menu:
    "Stay"(True):
        $ ep5_lilyhome_to_stay = True
        $ player_choice("ep5_lilyhome_to_stay:true")
        $ points_lily += 1
        show ep5 lilyhome_056 with d
        simon "I could stay for a while." id ep5_16_lilyhome_92de5847
        show ep5 lilyhome_057 with d
        lily "Thank you." id ep5_16_lilyhome_8a12a146
        show ep5 lilyhome_058 with d
        simon "(Well, this is awkward.)" id ep5_16_lilyhome_d57763d3
        simon "(Come to think of it... we haven't said more than a few words to each other since that time we had sex.)" id ep5_16_lilyhome_113cb521
        show ep5 lilyhome_059 with d
        lily "So..." id ep5_16_lilyhome_86446176
        simon "(Great! She's going to be the one to break the silence!)" id ep5_16_lilyhome_b231e573
        show ep5 lilyhome_060 with d
        lily "... She's not your girlfriend?" id ep5_16_lilyhome_360ff88d
        lily "Do you have any other girls in your life?" id ep5_16_lilyhome_7161ac6a
        show ep5 lilyhome_061 with d
        simon "Umm..."
        show ep5 lilyhome_062 with d
        lily "I'm sorry. That's not a subject to broach lightly." id ep5_16_lilyhome_17a919ac
        show ep5 lilyhome_063 with d
        lily "But you know..." id ep5_16_lilyhome_1f3cbb0f
        lily "I've been thinking a lot about you and your college adventures." id ep5_16_lilyhome_c3f6c2e5
        show ep5 lilyhome_064 with d
        lily "Reminded me of old times..." id ep5_16_lilyhome_1cf64274
        show ep5 lilyhome_065 with d
        simon "I bet there were a lot of guys chasing after you when you were a freshwoman." id ep5_16_lilyhome_70e044a2
        show ep5 lilyhome_066 with d
        lily "Not as many as you might think." id ep5_16_lilyhome_308f6b94
        lily "You could say, it took me a while to bloom." id ep5_16_lilyhome_39ce78b1
        show ep5 lilyhome_067 with d
        lily "Boys didn't really notice me." id ep5_16_lilyhome_97df1384
        lily "Except for Sam, that is." id ep5_16_lilyhome_606cb883
        show ep5 lilyhome_068 with d
        lily "He treated me well and showered me with praises." id ep5_16_lilyhome_2846b334
        lily "We started dating, and I found myself enjoying his company." id ep5_16_lilyhome_b9419c40
        lily "I even started taking better care of myself." id ep5_16_lilyhome_6ae2f55a
        show ep5 lilyhome_069 with d
        lily "So we ended up getting married at a very young age..." id ep5_16_lilyhome_04671182
        lily "... And these days, I feel like I never really enjoyed life all that much." id ep5_16_lilyhome_e3eb60f1
        show ep5 lilyhome_070 with d
        simon "Do you find yourself wishing you had enjoyed single life more?" id ep5_16_lilyhome_20361f4a
        show ep5 lilyhome_069 with d
        lily "Exactly."
        lily "Especially during my college days." id ep5_16_lilyhome_c7aeca63
        show ep5 lilyhome_071 with d
        lily "Now I'm happy enough just being in the presence of college kids." id ep5_16_lilyhome_42d342a1
        show ep5 lilyhome_072 with d
        simon "Come now. You could always go back to college." id ep5_16_lilyhome_94ef1f05
        show ep5 lilyhome_073 with d
        lily "I've already graduated, [name]." id ep5_16_lilyhome_d9115412
        lily "I just wish I could relive those years." id ep5_16_lilyhome_676fcb0d
        show ep5 lilyhome_074 with d
        lily "I wish I had studied a little less." id ep5_16_lilyhome_161844c3
        lily "Gone to more parties." id ep5_16_lilyhome_fdde722f
        stop music fadeout 8
        show ep5 lilyhome_075 with d
        simon "You didn't miss out on much." id ep5_16_lilyhome_2c936584
        show ep5 lilyhome_076 with d
        lily "Even so, I think I would've liked it." id ep5_16_lilyhome_8b2933a1
        show ep5 lilyhome_077 with d
        simon "Hmm..."
        show ep5 lilyhome_078 with d
        simon "I could throw you a college party." id ep5_16_lilyhome_a67ccae5
        simon "All we need is lots of cheap beer and bad music." id ep5_16_lilyhome_50ab05fe
        show ep5 lilyhome_079 with d
        lily "I would say yes, but I don't drink beer." id ep5_16_lilyhome_fec96399
        show ep5 lilyhome_077 with d
        simon "Right..." id ep5_16_lilyhome_41326fcf
        show ep5 lilyhome_080 with d
        lily "But I wouldn't mind a bit of music." id ep5_16_lilyhome_ab4fdd5d
        show ep5 lilyhome_081_1 with d
        pause 1
        show ep5 lilyhome_081 with d
        simon "Then let's have a party." id ep5_16_lilyhome_3ee55dcb

        menu:
            "Put on some upbeat music"(True):
                $ ep5_lilyhome_put_on_some_upbeat_music = True
                $ player_choice("ep5_lilyhome_put_on_some_upbeat_music:true")
                play music love_will_save_the_day volume 0.3
                show ep5 lilyhome_082 with d
                lily "Oh..."
                show ep5 lilyhome_083 with d
                lily "I like this song!" id ep5_16_lilyhome_5c31367c
                show ep5 lilyhome_084 with d
                simon "You're not supposed to like it." id ep5_16_lilyhome_8ecfbbe9
                simon "It's just loud music you try to block out and shout over."
                show ep5 lilyhome_085 with d
                lily "Then you suck at parties because I'm enjoying it!" id ep5_16_lilyhome_fcce26f8
                show ep5 lilyhome_086 with d
                simon "I never said I was good at throwing parties!" id ep5_16_lilyhome_a1a57d1b
            "Put on some calm music"(True):

                $ ep5_lilyhome_put_on_some_calm_music = True
                $ player_choice("ep5_lilyhome_put_on_some_calm_music:true")
                play music celestial_walkers volume 0.3
                show ep5 lilyhome_087 with d
                lily "So this is what young people listen to these days?" id ep5_16_lilyhome_da88f5cc
                show ep5 lilyhome_088 with d
                simon "I warned you the music would be bad." id ep5_16_lilyhome_4a387635
                show ep5 lilyhome_089 with d
                lily "That you did." id ep5_16_lilyhome_def0ea58
                lily "Matches the cheap beer." id ep5_16_lilyhome_59d4cd5c
                show ep5 lilyhome_090 with d
                simon "The true spirit of any college party." id ep5_16_lilyhome_dc0581bd



        $ debug_other_path()
        stop music fadeout 3
        show ep5 lilyhome_091 with d
        lily "So, what do we do now?" id ep5_16_lilyhome_3f5e1b0c
        show ep5 lilyhome_092 with d
        simon "I don't know." id ep5_16_lilyhome_4ec05ed7
        simon "I haven't gotten to that part yet." id ep5_16_lilyhome_bac237ea
        play music what_about_trust fadein 3 volume 0.2
        show ep5 lilyhome_093 with d
        lily "I think we should dance." id ep5_16_lilyhome_48b46e8a
        show ep5 lilyhome_094 with d
        simon "Are you sure? Usually people get drunk before they dance at parties." id ep5_16_lilyhome_189a7d33
        show ep5 lilyhome_095 with d
        lily "I don't need drinks to loosen up!" id ep5_16_lilyhome_cc3e3ec3
        show ep5 lilyhome_094 with d
        simon "Loosen up? That's your idea for the next part?" id ep5_16_lilyhome_7c71b417
        show ep5 lilyhome_095 with d
        lily "Don't you enjoy dancing, [name]?" id ep5_16_lilyhome_25179a29
        show ep5 lilyhome_096 with d
        simon "Umm..." id ep5_16_lilyhome_3e5c02d1
        simon "Well, actually..." id ep5_16_lilyhome_a17c778b
        show ep5 lilyhome_097 with d
        simon "...I love dancing." id ep5_16_lilyhome_bcbd3adc
        lily "Wow..." id ep5_16_lilyhome_77afcc97
        simon "I do what I can." id ep5_16_lilyhome_a85aecba
        show ep5 lilyhome_098 with d
        lily "Hmm..." id ep5_16_lilyhome_4bd06a29
        show ep5 lilyhome_099 with d
        lily "(Those moves...)" id ep5_16_lilyhome_41ba7839
        show ep5 lilyhome_100 with d
        lily "(He's so delicate...)" id ep5_16_lilyhome_89a7572f
        show ep5 lilyhome_101 with d
        lily "(... Yet he knows how to take the lead.)"
        show ep5 lilyhome_102 with hpunch
        lily "(And being held like this...)" id ep5_16_lilyhome_dd25b20e
        show ep5 lilyhome_103 with d
        lily "(It makes me feel young again.)" id ep5_16_lilyhome_b9e3c627
        show ep5 lilyhome_104 with d
        pause
        show ep5 lilyhome_105 with d
        simon "Umm..."
        show ep5 lilyhome_106 with d
        lily "Don't worry. I'm not drunk this time." id ep5_16_lilyhome_e3b4c4be
        lily "And I already served Sam with the divorce papers." id ep5_16_lilyhome_c54d2392
        lily "We're not doing anything wrong." id ep5_16_lilyhome_0d652c37
        show ep5 lilyhome_107 with d
        simon "Are you sure?" id ep5_16_lilyhome_4b1d3f09
        show ep5 lilyhome_108 with d
        lily "Yes."
        lily "I don't want you to be my collegiate boy toy or anything." id ep5_16_lilyhome_164a908f
        lily "I just want to feel you again." id ep5_16_lilyhome_6350ae49
        lily "Without the burden of guilt." id ep5_16_lilyhome_5a8b18fb
        show ep5 lilyhome_109 with d
        lily "And I think..." id ep5_16_lilyhome_c5bd995a
        show ep5 lilyhome_106 with d
        lily "... No, I hope... you want me too." id ep5_16_lilyhome_2d07d402

        menu:
            "I want you"(True):
                $ ep5_lilyhome_i_want_to = True
                $ player_choice("ep5_lilyhome_i_want_to:true")
                jump ep5_17_lilysex
            "Not now":

                $ ep5_lilyhome_not_now = True
                $ player_choice("ep5_lilyhome_not_now:true")
                stop music
                show ep5 lilyhome_110 with d
                simon "Sorry, Lily. I think I should go." id ep5_16_lilyhome_cc1f76b9
                show ep5 lilyhome_111 with d
                lily "I get it."
                show ep5 lilyhome_112 with d
                lily "Take care, [name]."
                show ep5 lilyhome_113 with d
                simon "You too, Lily."
                jump ep5_18_afterlily



        $ debug_other_path()
    "Leave":

        $ ep5_lilyhome_go_away = True
        $ player_choice("ep5_lilyhome_go_away:true")
        stop music
        show ep5 lilyhome_111 with d
        simon "I think... I should go." id ep5_16_lilyhome_e0224bf9
        lily "I get it."
        show ep5 lilyhome_112 with d
        lily "Take care, [name]."
        show ep5 lilyhome_113 with d
        simon "You too, Lily."
        jump ep5_18_afterlily



$ debug_other_path()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
