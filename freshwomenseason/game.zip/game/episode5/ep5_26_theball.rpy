label ep5_26_theball:



show ep5 theball_001 with longer_fade
simon "(Time to go.)" id ep5_26_theball_3586ece5

if chose("ep3_07_cafe2_agree_to_help"):
    play music the_world_is_mine fadein 3 volume 0.35
    show ep5 theball_002 with d
    simon "(The plan is to infiltrate the ball with Alyssa's dance crew.)" id ep5_26_theball_e8f71aed
    simon "(From the stage, I'll be able to see everyone in attendance.)" id ep5_26_theball_3d43d5d3
    simon "(Maybe even someone I recognize.)" id ep5_26_theball_ffaf1f8d
    play sound phone_vibrate volume 0.15
    show ep5 theball_003 with d
    simon "(I'd better call Alyssa.)" id ep5_26_theball_b2c7d1ee
    stop sound fadeout 1
    show ep5 theball_004 with d
    simon "Hey, Al —" id ep5_26_theball_c3e127db
    show ep5 theball_005 with d
    alyssa "[name]!" (what_italic=True)
    alyssa "Where are you?!" (what_italic=True)
    show ep5 theball_004_1 with d
    simon "I'm on my way."


    show ep5 theball_006 with d
    alyssa "Thank god." id ep5_26_theball_b3a6f2f1
    alyssa "We're all waiting for you." id ep5_26_theball_0ba7cfa3
    show ep5 theball_007 with d
    alyssa "You need to change into your outfit before we leave." id ep5_26_theball_fba90096
    alyssa "Come to the dance studio." id ep5_26_theball_00e8b4dc


    show ep5 theball_008 with d
    simon "I'm on my way."


    show ep5 theball_009 with wiperight
    simon "So... I'm here..." id ep5_26_theball_c628bd9f
    simon "And I'm seeing the outfits." id ep5_26_theball_2af461fb
    show ep5 theball_010 with d
    simon "Is that what I'll be wearing too?" id ep5_26_theball_d85d4a93
    alyssa "I think you'd look great in one of these!" id ep5_26_theball_fcf8e178
    simon "Seriously?" id ep5_26_theball_5ed5024e
    show ep5 theball_011 with d
    alyssa "No." id ep5_26_theball_5677f662
    alyssa "Hahaha. But you should have seen your face." id ep5_26_theball_2c8f6f34
    show ep5 theball_012 with d
    alyssa "You'll wear this." id ep5_26_theball_7fb46528
    play sound dress_shirt_fold volume 0.5
    scene black with wiperight
    ""
    show ep5 theball_013 with fade
    simon "This looks much better." id ep5_26_theball_1e0b1f12
    show ep5 theball_014 with d
    alyssa "So, you ready?" id ep5_26_theball_b8c1824d
    show ep5 theball_015 with d
    simon "Yep." id ep5_26_theball_30996514
    show ep5 theball_014 with d
    alyssa "Nervous?" id ep5_26_theball_8e91841a
    show ep5 theball_015 with d
    simon "Nope." id ep5_26_theball_3f86a073
    show ep5 theball_016 with d
    simon "(Yep.)" id ep5_26_theball_c1bc8bb2
    show ep5 theball_015 with d
    simon "Come on." id ep5_26_theball_fb65f9f9
    show ep5 theball_017 with d
    simon "So, I agreed to help." id ep5_26_theball_daf385e4
    simon "But I have my own reasons for being at the ball." id ep5_26_theball_f2878e75
    show ep5 theball_018 with d
    alyssa "I know. We'll do our dance, and then you're free to roam." id ep5_26_theball_cee04f14
    alyssa "Let me know if I can help you with anything." id ep5_26_theball_550513aa
    show ep5 theball_017 with d
    simon "You've already helped me out a lot." id ep5_26_theball_ff261328

    stop music fadeout 5
    play music_2 quiet_street_light_traffic_pedestrians volume 0.8


    show ep5 theball_019_1 with longer_fade
    simon "(So this is it.)"
    show ep5 theball_019 with d
    simon "(The charity ball.)"
    show ep5 theball_020 with d
    alyssa "Let's go!" id ep5_26_theball_129c60c5

    stop music_2 fadeout 2


    play music_2 concert_hall_lobby_crowd_people_talking_and_toasting volume 0.75 fadein 2
    show ep5 theball_021 with medium_fade
    simon "(The show is about to begin.)" id ep5_26_theball_74bace10
    show ep5 theball_022 with d
    simon "There are so many people out there." id ep5_26_theball_cf95993b
    simon "And not a single familiar face." id ep5_26_theball_bd000317
    show ep5 theball_023 with d
    alyssa "All right, [name]." id ep5_26_theball_a4471303
    alyssa "Every eye will be on us while we dance." id ep5_26_theball_7deb011d
    alyssa "If there's anyone here you know, you'll see them in the crowd." id ep5_26_theball_22b44485
    alyssa "And speaking of dancing..." id ep5_26_theball_866043f2
    show ep5 theball_024 with d
    alyssa "It's time." id ep5_26_theball_e4abad61
    stop music fadeout 5
    show ep5 theball_025 with d
    susan "Attention, everyone!" id ep5_26_theball_4f55ee98

    stop music_2 fadeout 3

    susan "The dance performance is about to begin!" id ep5_26_theball_c9d4df62
    play music the_four_seasons_summer3 volume 0.8
    show ep5 theball_026 with d
    simon "(I have to focus on my moves...)" id ep5_26_theball_e9138300
    pause 2
    show ep5 theball_026_1 with d
    pause 2
    show ep5 theball_026_2 with d
    pause 2
    show ep5 theball_026_3 with d
    pause 2
    show ep5 theball_027 with d
    simon "(But I also need to be on the lookout for a few people...)" id ep5_26_theball_888de564
    show ep5 theball_028 with d
    simon "(... For instance...)" id ep5_26_theball_09e443eb
    show ep5 theball_029 with vpunch
    simon "(...Emily!)" id ep5_26_theball_4005b51d
    simon "(What's she doing here?)" id ep5_26_theball_7dff4053
    stop music fadeout 5
    show ep5 theball_030 with d
    simon "(And she's with... Sam?!)" id ep5_26_theball_9975eefe
    play sound medium_applause_concert_hall_crowd_clapping volume 0.5 fadein 2
    show ep5 theball_031 with d
    susan "And that's the show, everyone!" id ep5_26_theball_884f7e17
    show ep5 theball_032 with d
    susan "I hope you enjoyed their musical number." id ep5_26_theball_bd6feb18
    susan "Soon, we will continue with more music and dance." id ep5_26_theball_ef2bf731
    show ep5 theball_033 with d
    simon "(Where are you off to, Emily?)" id ep5_26_theball_9844a427
    stop sound fadeout 2
    show ep5 theball_034 with d
    alyssa "[name]?" id ep5_26_theball_54f26c95
    show ep5 theball_035_1 with d
    simon "Huh?!" id ep5_26_theball_a7348e03
    show ep5 theball_035 with d
    alyssa "We were amazing, weren't we?!" id ep5_26_theball_00fb2617

    play music mystical_tension fadein 2 volume 0.35




    show ep5 theball2_001 with d
    susan "Yeah, you were great!" id ep5_26_theball_14644cc2
    show ep5 theball2_002 with d
    simon "(Oh shit. It's Susan!)" id ep5_26_theball_c7eb17d1
    show ep5 theball2_003 with d
    susan "Excuse me?"
    alyssa "Erm... Yes, Mrs. Myers." id ep5_26_theball_964f010a
    show ep5 theball2_004 with d
    susan "No need for such formalities." id ep5_26_theball_feb6ca4e
    susan "Just call me Susan." id ep5_26_theball_6d9f002c
    show ep5 theball2_005 with d
    susan "So, you're Alyssa, and these fine dancers are...?" id ep5_26_theball_97928945
    show ep5 theball2_006 with d
    alyssa "Umm..." id ep5_26_theball_10c1a38a
    show ep5 theball2_007 with d
    claire "I'm Claire!" id ep5_26_theball_53f305b2
    show ep5 theball2_008 with d
    claire "Nice to meet you!" id ep5_26_theball_362551ab
    show ep5 theball2_009 with d
    jason "The name's Jason!" id ep5_26_theball_6175c189
    show ep5 theball2_010 with d
    susan "Oh, um... nice to meet you all." id ep5_26_theball_020cdc02
    susan "But there was one more of you..." id ep5_26_theball_23b4a361
    show ep5 theball2_011 with d
    alyssa "Oh, don't worry about him! He was just so tired that he left early." id ep5_26_theball_ecb9c086
    show ep5 theball2_012 with d
    susan "Oh, right. He looked somewhat familiar..." id ep5_26_theball_7eb2a590
    show ep5 theball2_011 with d
    alyssa "He's just got one of those faces. You know." id ep5_26_theball_6bd4b365
    susan "Right..." id ep5_26_theball_31f98f57
    play sound dress_shirt_fold volume 0.3
    show ep5 theball2_013 with wiperight
    simon "(I'd better ditch these clothes.)" id ep5_26_theball_3bf29bf9

elif chose("ep4_susanhome_accept_the_job"):

    play music mystical_tension fadein 2 volume 0.35

    show ep5 theball_002 with d
    simon "(The plan is to do that job for Susan.)" id ep5_26_theball_b8db1fc4
    simon "(I have to make a delivery to another city.)" id ep5_26_theball_912b94fb
    simon "(But I can try to buy some time to sneak into the ball and investigate.)" id ep5_26_theball_99fcb5f5
    show ep5 theball_002 with d
    simon "(Let's see...)" id ep5_26_theball_58e9919e
    show ep5 theball_004 with d
    simon "Hey, Susan." id ep5_26_theball_95710872
    show ep5 theball_075 with d
    susan "Hi, [name]. Are you ready to work?" (what_italic=True)
    show ep5 theball_004 with d
    simon "I'm ready." id ep5_26_theball_fd5c20a7
    show ep5 theball_075 with d
    susan "Then come to the ball. There'll be a truck waiting for you." (what_italic=True)
    show ep5 theball_004 with d
    simon "Got it." id ep5_26_theball_d4c01a79

    play music_2 quiet_street_light_traffic_pedestrians volume 0.6

    show ep5 theball_019_1 with longer_fade
    simon "(So this is it.)"
    simon "(The charity ball.)"
    show ep5 theball_019 with d
    simon "(But this isn't exactly where I'm heading.)" id ep5_26_theball_717bcdab


    show ep5 theball_076 with d
    simon "(My job is to help with the delivery.)" id ep5_26_theball_26bda32f
    simon "(But that doesn't mean I can't take a quick peek inside.)" id ep5_26_theball_4cf41c6e
    show ep5 theball_077 with d
    simon "(There's the delivery guy.)" id ep5_26_theball_066e969b
    simon "(He looks distracted. I'd better come up with an excuse to get into that ball.)" id ep5_26_theball_80b643e3
    show ep5 theball_078 with d
    simon "Hello. I'm the help Susan sent." id ep5_26_theball_258251ae
    show ep5 theball_079 with d
    man "*Cough.* I told her I didn't need any help." id ep5_26_theball_a06dc193
    man "I just need to talk with Sam before we go." id ep5_26_theball_7893ddeb
    show ep5 theball_079_1 with d
    simon "Really?" id ep5_26_theball_6e229894
    man "..." id ep5_26_theball_8cb6f128
    show ep5 theball_080 with d
    simon "So you wouldn't mind if I snuck into the party for a bit." id ep5_26_theball_3bbabcbd
    play sound dress_shirt_fold volume 0.4
    show ep5 theball_081 with fade
    man "Do what you want, man." id ep5_26_theball_b4381ffc
    show ep5 theball_082 with d
    simon "(Weird dude.)" id ep5_26_theball_1d2d223f



    stop music_2 fadeout 2

    show ep5 theball2_014 with wiperight
    simon "(Now I just have to...)"
    show ep5 theball2_015 with d
    simon "(Oh shit!)"
    show ep5 theball2_016 with d
    susan "Jacob, keep both eyes open tonight." id ep5_26_theball_7a884db3
    susan "Nothing can go wrong." id ep5_26_theball_e7437bc2
    security "Leave it to me, boss." id ep5_26_theball_bc459319
    show ep5 theball2_017 with d
    susan "I have a bad feeling about this."

elif chose("ep5_angels_accept_devillas_job"):

    play music mystical_tension fadein 2 volume 0.35

    show ep5 theball_002 with d
    simon "(The plan is to get into the ball with the Hell Angels.)" id ep5_26_theball_38daa7e0
    simon "(From what Devilla told me, I can walk right through the front door.)" id ep5_26_theball_86961c99

    play music_2 quiet_street_light_traffic_pedestrians volume 0.6

    show ep5 theball_019_1 with longer_fade
    simon "(So this is it.)"
    show ep5 theball_019 with d
    simon "(The ball.)"


    show ep5 theball_098 with d
    simon "(Should be smooth sailing from here on out.)" id ep5_26_theball_b2dbf73a
    show ep5 theball_099 with d
    simon "Hi, I'm [name]. My name's on the list." id ep5_26_theball_fd4072df
    show ep5 theball_100 with d
    security "Let's see..." id ep5_26_theball_bb80a105
    show ep5 theball_101 with d
    security "Here you are. Have fun at the ball." id ep5_26_theball_7909bdcc



    show ep5 theball2_014 with d
    simon "(Now I just have to...)"
    show ep5 theball2_015 with d
    simon "(Oh shit!)"
    show ep5 theball2_016 with d
    susan "Jacob, keep both eyes open tonight. Nothing can go wrong." id ep5_26_theball_3dfed344
    security "You can go on ahead, boss." id ep5_26_theball_aecb8ad2
    show ep5 theball2_017 with d
    susan "I have a bad feeling about this."
else:


    play music mystical_tension fadein 2 volume 0.35

    $ save("ep5_theball_front_door")
    show ep5 theball_002 with d
    simon "(The plan is to get into the ball by kicking the front door in.)" id ep5_26_theball_703b715c
    simon "(Not really much of a plan.)" id ep5_26_theball_6680a4be


    play music_2 quiet_street_light_traffic_pedestrians volume 0.6

    show ep5 theball_019_1 with longer_fade
    simon "(So this is it.)"
    show ep5 theball_019 with d
    simon "(The ball.)"
    show ep5 theball_098 with d
    simon "(I'll do as Bruce said...)" id ep5_26_theball_107e3113
    simon "(And go right through the front door.)" id ep5_26_theball_8e6b0b2e


    show ep5 theball_120 with d
    simon "(What could go wrong?)" id ep5_26_theball_081f9627
    show ep5 theball_121 with d
    security "Hey." id ep5_26_theball_23364803
    show ep5 theball_122 with d
    simon "Hey, who? Me?" id ep5_26_theball_87fac459
    show ep5 theball_123 with d
    security "You aren't on the list." id ep5_26_theball_e6eb3239
    show ep5 theball_122 with d
    simon "How would you know that? I'm wearing a mask." id ep5_26_theball_54041d6a
    show ep5 theball_124 with d
    security "You. Aren't. On. The list." id ep5_26_theball_3dda5af6
    show ep5 theball_125 with d
    simon "(Screw this.)" id ep5_26_theball_539eceb7
    play sound door_thud volume 0.7
    show ep5 theball_126 with hpunch
    simon "Aagghhh..." id ep5_26_theball_643c7c6f
    security "Hey!" id ep5_26_theball_6fbcc8e4

    play music_2 concert_hall_lobby_crowd_people_talking_and_toasting volume 0.75 fadein 2


    show ep5 theball_127 with wipeleft
    simon "(He won't find me in the middle of a party with everyone wearing masks.)" id ep5_26_theball_85e43010
    simon "(I just have to blend in.)" id ep5_26_theball_2f94892a
    play sound hitting_leather volume 0.7
    show ep5 theball_128 with vpunch
    simon "(Shit.)" id ep5_26_theball_7f8d675e
    show ep5 theball_129 with d
    simon "(This guy's good!)" id ep5_26_theball_f48d4b5d



    show ep5 theball2_018 with d
    simon "(Damn! I'm going to end up drawing too much attention like this!)" id ep5_26_theball_5d024343
    show ep5 theball2_019 with d
    simon "(Is that Susan?!)" id ep5_26_theball_8fb95a31
    play sound door_heavy volume 0.7
    show ep5 theball2_020 with d
    simon "(Did she see me?)" id ep5_26_theball_90f736ce


$ debug_other_path()

stop music_2 fadeout 3



jump ep5_27_chase
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
