import sys
import os
import getpass
import pathlib

import subprocess


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('\nArraste arquivos para esse .bat\n')
        exit()

    if not getpass.getuser() == 'Avell':
        onedrive_root = os.path.join('c:/', 'Users', getpass.getuser(), 'OneDrive',
                                     '[SHARED] Visual Novel - Daz Studio')
    else:
        onedrive_root = os.path.join('d:/', 'OneDrive', '[SHARED] Visual Novel - Daz Studio')

    png_folders = [os.path.join(onedrive_root, 'IrayServer-Output', 'png8_sem_filtro'),
                   os.path.join(onedrive_root, 'IrayServer-Output', 'png16_sem_filtro')]

    for i in range(1, len(sys.argv)):
        source = sys.argv[i]
        file_name = source.split(os.path.sep)[-1]
        #print("source: " + source)
        if '_hover' in file_name or '_idle' in file_name or '_reward' in file_name:
            file_name_no_ext = file_name.split('.')[0]

            if "_" in file_name_no_ext:
                file_name_no_ext = file_name_no_ext.replace(' ', '_')
            underlines_strings = file_name_no_ext.split('_')

            subfolder = ""
            sublevels = min(3, len(underlines_strings)-1)

            for i in range(sublevels):
                subfolder = os.path.join(subfolder, underlines_strings[i])

            for png_folder in png_folders:
                output_folder = os.path.join(png_folder, subfolder)
                pathlib.Path(output_folder).mkdir(parents=True, exist_ok=True)
                output_file = os.path.join(output_folder, file_name_no_ext + '.png')
                magick_cmd = f'magick "{source}" "{output_file}"'
                #print(f'output: {output_file}')
                subprocess.run(magick_cmd)

            print(f'{file_name_no_ext} sent with sucess!')
