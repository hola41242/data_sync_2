py %0\..\send_to_pre_postwork.py %*
cmd \k