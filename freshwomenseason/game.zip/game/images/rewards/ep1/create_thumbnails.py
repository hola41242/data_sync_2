import sys
import os
import subprocess
import multiprocessing


def subprocess_function(cmd_command):
    subprocess.run(cmd_command)


if __name__ == '__main__':
    folder_to_check = sys.argv[1]
    pool = multiprocessing.Pool()

    def walk_dir(start_path):
        for content in os.listdir(start_path):
            content_name = os.fsdecode(content)
            path = os.path.join(start_path, content_name)
            if os.path.isdir(path):
                walk_dir(path)
            else:  # Is file
                if '.webp' in path and '_thumb.webp' not in path:
                    # print(content_name)

                    thumb_path = path.replace('.webp', '_thumb.webp')
                    imagemagick_command = f'magick "{path}" -resize 400x225 -sharpen 0x1 -quality 95 "{thumb_path}"'
                    pool.apply_async(subprocess_function, args=(imagemagick_command,))

    walk_dir(folder_to_check)

    pool.close()
    pool.join()
