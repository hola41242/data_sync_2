py %0\..\create_thumbnails.py "%~1"

cmd \k