label ep1_01_the_fancy_home:

    stop music fadeout 3
    scene black with Fade(2,1,1)
    show ep1 mon_fancyhome_pool with longer_dissolve

    $ quick_menu = True
    p "What a beautiful day!" id ep1_01_the_fancy_home_4ba41492

    play music play_with_fire_original
    show ep1 mon_fancyhome_pool_girl with long_dissolve
    p "Not a single care in the world." id ep1_01_the_fancy_home_09652527
    show ep1 mon_fancyhome_simon_girls with long_dissolve
    p "Just me and my girls sharing a delightful morning at my mansion." id ep1_01_the_fancy_home_8b1dcd29
    play sound swimming_1
    show ep1 mon_fancyhome_girls_up with vpunch
    pause 0.5
    play sound_2 girls_laughing volume 0.7
    show ep1 mon_fancyhome_girls_laugh with long_dissolve
    "*Giggles.*" id ep1_01_the_fancy_home_e83e8e19


    p "This is the dream life..." id ep1_01_the_fancy_home_beed750e
    stop sound fadeout 1
    show ep1 mon_fancyhome_distant with long_dissolve
    p "Yep..." id ep1_01_the_fancy_home_4a875baf
    p "But now it's time to wake up!" id ep1_01_the_fancy_home_dc7d77d9
    jump ep1_02_meet_lily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
