label ep1_05_mall:

    simon "(So, I've got some shopping to do, and I need to go see my new boss at the clothing store.)" id ep1_05_mall_e7846c88
    simon "(But before any of that, I think I'll take some time to enjoy myself.)" id ep1_05_mall_e6ebb146
    scene mall_day with fade
    simon "(There's a café over there. It might be nice to grab a drink.)" id ep1_05_mall_03c3689d
    simon "(They've got a bookstore too, and I remember there's that one book I was looking for.)" id ep1_05_mall_409f1d09
    simon "(Also, I'm pretty sure I saw an arcade up on the second floor. Might be fun to drop in.)" id ep1_05_mall_d9fb612b


    show tutorial_text_bar with d
    show black_fade with d
    "At certain points during the game, you'll be able to move around freely." id ep1_05_mall_65248d78
    "Take some time to explore by clicking on objects of interest." id ep1_05_mall_87aef793
    hide tutorial_text_bar with d
    hide black_fade with d
    call screen FR2_Mall
return

label ep1_05_mall_fr:
    scene mall_day with long_fade
    if chose_skip_debug('went_games') and chose_skip_debug('went_bookstore') and chose_skip_debug('went_cafe'):
        simon "(I think it's time I stopped by Susan's Clothing Store.)" id ep1_05_mall_fr_dd2ca28c
    call screen FR2_Mall
return


screen FR2_Mall():

    imagemap:

        idle img_root + "ep1/fr/mall_day_idle.webp"
        ground img_root + "ep1/fr/mall_day.webp"
        hover img_root + "ep1/fr/mall_day_hover.webp"


        if not chose_skip_debug('went_games'):
            hotspot (221, 43, 371, 325) action Jump('ep1_08_mall_games')
        if not chose_skip_debug('went_bookstore'):
            hotspot (1159, 62, 399, 391) action Jump('ep1_06_bookstore')
        if not chose_skip_debug('went_cafe'):
            hotspot (1059, 463, 493, 463) action Jump('ep1_07_cafe')
        if chose_skip_debug('went_games') and chose_skip_debug('went_bookstore') and chose_skip_debug('went_cafe'):
            hotspot (386, 470, 435, 344) action Jump('ep1_09_clothestore')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
