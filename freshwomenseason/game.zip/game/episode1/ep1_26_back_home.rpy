label ep1_26_back_home:


    show ep1 wed_suecar_simon_rideback with wipeleft
    play music iguana_americana volume 0.35
    simon "(The ride back sure is quiet.)" id ep1_26_back_home_73e12a6d
    simon "(I should text Dylan the location of The Beach House.)" id ep1_26_back_home_de1b4f5d
    if chose('ep1_agree_help_sue'):
        simon "(If I'm going to help Sue, he might be able to lend a hand.)" id ep1_26_back_home_68a8a4d4
    else:
        simon "(Just because I didn't agree to help Sue, that doesn't mean I'm not curious about her aunt.)" id ep1_26_back_home_c0b5d05d
    show ep1 wed_suecar_befriends with d
    simon "(I think her and I could be friends.)" id ep1_26_back_home_637d41da
    show ep1 wed_suecar_sue_mad with d
    sue "What are you smiling at, fucktard?" id ep1_26_back_home_346a5932
    show ep1 wed_suecar_befriends with d
    simon "(Or maybe not.)" id ep1_26_back_home_1a97c5d0
    show ep1 wed_suecar_simon_go with wipeleft
    simon "Well, I'll just be going then." id ep1_26_back_home_fabbda9b
    show ep1 wed_suecar_sue_hey with d
    sue "Hey." id ep1_26_back_home_daa88cb5
    show ep1 wed_suecar_simon_whatnow with d
    simon "What now?" id ep1_26_back_home_a57f6d41
    show ep1 wed_suecar_sue_thanks with d
    sue "Thanks." id ep1_26_back_home_37c9fba0
    simon "Oh." id ep1_26_back_home_1b880af0
    show ep1 wed_suecar_simon_welcome with d
    simon "You're welcome." id ep1_26_back_home_937beae2
    stop music fadeout 2
    simon "I guess." id ep1_26_back_home_4b2021c5

    show ep1 mon_simonhome_afternoon with long_fade
    simon "Wow, it's already after noon." id ep1_26_back_home_e6932bfa


    jump ep1_27_julia_call
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
