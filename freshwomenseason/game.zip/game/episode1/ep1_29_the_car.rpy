label ep1_29_the_car:

    show ep1 wed_lilyhome_simon_leaving with d
    simon "Fuck." id ep1_29_the_car_d86fecff
    show ep1 wed_lilyhome_simon_corner with d
    simon "(Man, that was so close!)" id ep1_29_the_car_318e7d37
    show ep1 wed_thecar_whistle with d
    simon "*Whistles.*" (what_italic=True)
    show ep1 wed_thecar_carclose with d
    play sound drama3 volume 0.4
    pause 0.5
    show ep1 wed_thecar_flashlight with d
    simon "What the — ?" id ep1_29_the_car_2f7e4b1f
    show ep1 wed_thecar_badge with d
    cop "Get in the car, now!" id ep1_29_the_car_fe61cbe1
    show ep1 wed_thecar_smile with d
    simon "Thanks, but I think I'll walk." id ep1_29_the_car_7f7bd883
    play sound open_car_door
    show ep1 wed_thecar_out with d

    cop "I wasn't asking." id ep1_29_the_car_a0a9b153
    cop "You were just seen trespassing on private property." id ep1_29_the_car_f6ff60df
    show ep1 wed_thecar_door with d
    cop "I'm taking you down to the station." id ep1_29_the_car_9f361dc6
    cop "We have a few questions we'd like to ask." id ep1_29_the_car_f82c1f39
    play sound punch
    show ep1 wed_thecar_shoulder with vpunch
    simon "Ouch!" id ep1_29_the_car_2e4f777a
    play sound car_door_close
    show ep1 wed_lilyhome_simon_car_light with d
    pause 0.5
    play sound car_drive_away volume 1

    jump ep1_30_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
