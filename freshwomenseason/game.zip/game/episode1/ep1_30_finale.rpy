

label ep1_30_finale:
    $ add_frame_to_finale = False
    show screen save_your_game(1, 1, 1, 0) with ending_fade


    $ set_finale_chars("Lily")
    $ finale_color = "864855"
    if chose_skip_debug('ep1_pantson'):
        $ finale_txt1 = _("You put on pants before talking to Lily.")
    else:
        $ finale_txt1 = _("You didn't put on pants before talking to Lily.")
    if chose_skip_debug('lily_husband'):
        $ finale_txt2 = _("You found out more about Lily's husband.")
    else:
        $ finale_txt2 = _("You didn't ask about Lily's husband.")
    if chose_skip_debug('callsher_lily'):
        $ finale_txt3 = _("You called Lily by her first name.")
    else:
        $ finale_txt3 = _("You called Lily by her last name.")
    if chose_skip_debug('connections_mraldersonsusan'):
        $ finale_txt4 = _("You discovered a connection between Susan and Mr. Alderson.")
    else:
        $ finale_txt4 = ""
    $ finale_txt5 = _("You and Lily got very close. Or was it just the wine?")

    scene ep1 finale_end_lily
    pause 
    hide screen save_your_game with long_fade
    $ award_manager.enable_notify()
    stop sound fadeout 2
    stop music fadeout 2


    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Chloe", "Dylan")
    $ finale_color = "2a5a3f"
    if chose_skip_debug('ep1_you_like_books'):
        if chose_skip_debug('you_like_fiction'):
            $ finale_txt1 = _("You told Chloe you like fiction books.")
        else:
            $ finale_txt1 = _("You told Chloe you like non-fiction books.")
    else:
        $ finale_txt1 = _("You told Chloe you don't like books.")
    if chose_skip_debug('join_bookclub'):
        $ finale_txt2 = _("You decided to join the book club.")
    else:
        $ finale_txt2 = _("You didn't give an answer about the book club.")
    if chose_skip_debug('ep1_chloe_susan'):
        $ finale_txt3 = _("You asked Chloe to investigate your boss.")
    else:
        $ finale_txt3 = _("You didn't ask Chloe to investigate your boss.")
    if chose_skip_debug('let_dylan_help'):
        $ finale_txt4 = _("You accepted Dylan's help with Chloe.")
    else:
        $ finale_txt4 = _("You refused Dylan's help with Chloe.")
    $ finale_txt5 = _("Chloe will call you about her findings.")

    show ep1 finale_end_chloe with d
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Alyssa")
    $ finale_color = "1572f1"
    if chose_skip_debug('ep1_cafe_americano'):
        $ finale_txt1 = _("You had an americano.")
    else:
        $ finale_txt1 = _("You didn't have any coffee.")
    if chose_skip_debug('ep1_joindance'):
        $ finale_txt2 = _("You agreed to try out the dance lessons.")
    else:
        $ finale_txt2 = _("You didn't give an answer about the dance lessons.")
    if chose_skip_debug('ep1_shirt_off_alyssa'):
        $ finale_txt3 = _("You showed Alyssa the scars on your back.")
    else:
        $ finale_txt3 = _("You didn't show Alyssa your scars.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("Alyssa's dance lessons are tomorrow.")

    show ep1 finale_end_alyssa with d
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Julia")
    $ finale_color = "b85f9f"
    $ finale_txt1 = _("You played Dance Dance Supreme with Julia at the arcade.")
    if chose_skip_debug('ep1_win_arcade'):
        $ finale_txt2 = _("You beat Julia at Dance Dance Supreme.")
    else:
        $ finale_txt2 = _("You lost to Julia at Dance Dance Supreme.")
    if chose_skip_debug('ep1_hangout_julia'):
        $ finale_txt3 = _("You decided it's fine to hang out with Julia, despite her busy schedule.")
    else:
        $ finale_txt3 = _("You're not sure how you feel about Julia being so busy.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("Julia wants to meet again for a rematch.")

    show ep1 finale_end_julia with d
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Sue", "Susan")
    $ finale_color = "cd8214"
    if chose_skip_debug('ep1_said_hi_sue'):
        $ finale_txt1 = _("You tried to say hi to Sue.")
    else:
        $ finale_txt1 = _("You didn't try to talk to Sue.")
    if chose_skip_debug('ep1_told_sue_magazine'):
        $ finale_txt2 = _("You told Sue about the magazine with Susan on it.")
    else:
        $ finale_txt2 = _("You didn't tell Sue about the magazine with Susan on it.")
    if chose_skip_debug('ep1_agree_help_sue'):
        $ finale_txt3 = _("You agreed to help Sue investigate Susan.")
    else:
        $ finale_txt3 = _("You didn't give Sue an answer about investigating Susan.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You discovered Sue's sweeter side.")

    show ep1 finale_end_sue with d
    show screen finale_scr with d
    pause
    hide screen finale_scr with d
    if is_demo:
        jump ep1_99_demo_credits
    else:
        call end_game_if_rpy_is_not_installed ('ep2_01_the_station.rpy')
        jump ep2_01_the_station
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
