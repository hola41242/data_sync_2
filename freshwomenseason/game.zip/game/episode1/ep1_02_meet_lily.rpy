label ep1_02_meet_lily:
    play sound alarm_clock
    show ep1 mon_simonhome_outside_morning with None
    stop music
    p "Back to reality." id ep1_02_meet_lily_7e70b8ef
    stop sound
    play music lighter_times volume 0.8
    show ep1 mon_simonhome_in_building with fade
    p "I just moved into my new place." id ep1_02_meet_lily_3cd60133
    show ep1 mon_simonhome_simon_inbed with fade
    p "Last night was my first night sleeping here." id ep1_02_meet_lily_3c7ef69a
    p "Man, I miss my old bed..." id ep1_02_meet_lily_6491f57a
    p "I came here for college and got a part-time job to support myself." id ep1_02_meet_lily_37b3b89e
    p "Classes start next week, and later today I'll be meeting my new boss." id ep1_02_meet_lily_5a0b485c
    show ep1 mon_simonhome_simon_gettingup with d
    p "Perhaps I should practice introducing myself." id ep1_02_meet_lily_f63b35f9
    show ep1 mon_simonhome_simon_naming with d

    p "Hi, I'm..." id ep1_02_meet_lily_e628152a
    if renpy.variant('web') and (renpy.variant('touch') or renpy.variant('mobile')) and (
        preferences.fullscreen or is_iOSWeb_cache) or is_macWeb_cache:
        $ name = "Simon"
        $ persistent.name = name
        jump ep1_02_meet_lily_afternaming
    else:
        menu:
            "Would you like to choose your character's name?"
            "Yes, I'll choose my name":
                label ep1_02_meet_lily_naming:

                    $ name = renpy.input(_("What is your name?"), length=32, screen = "inputname")

                    $ name = name.strip()
                    $ persistent.name = name
                    if name == "":
                        jump ep1_02_meet_lily_naming
                    else:
                        jump ep1_02_meet_lily_afternaming
            "No, use the default name":
                $ name = "Simon"
                $ persistent.name = name
                jump ep1_02_meet_lily_afternaming



screen inputname(prompt):
    style_prefix "inputname"
    if ask_name_input_name:
        add 'black_screen'
    vbox:
        xalign 0.5
        spacing 10
        pos 0.5, gui.input_name_prompt_y_pos
        xsize gui.dialogue_width

        text prompt style "inputname_prompt" xalign 0.5

        frame:
            padding (50, 12, 50, 8)
            xalign 0.5
            xminimum 567
            input value VariableInputValue("name_input_field", returnable=True):
                xalign 0.5
                color "#ffffff"
                pixel_width 567

        if renpy.variant('small'):
            hbox:
                textbutton _("Use default name") action Return('Simon') xalign 0.5 xsize 600
                textbutton _("OK") action Return(name_input_field) xalign 0.5 xsize 600

        else:
            textbutton _("OK") action Return(name_input_field) xalign 0.5
            textbutton _("Use default name") action Return('Simon') xalign 0.5




























style inputname_prompt is default

style inputname_prompt:
    properties gui.text_properties("dialogue")
    xalign 0.5

style inputname:
    xalign 0.5
    xmaximum gui.dialogue_width

style inputname_button is default:
    properties gui.button_properties("choice_button")

style inputname_button_text is default:
    properties gui.button_text_properties("choice_button")


label ep1_02_meet_lily_afternaming:














    simon "I'm [name]." id ep1_02_meet_lily_afternaming_7c714a65
    show ep1 mon_simonhome_simon_named with d
    simon "Well, the only thing for me to do today is take a tour of the big city." id ep1_02_meet_lily_afternaming_3f28de82
    show ep1 mon_simonhome_theneighbors with fade
    simon "Maybe I should introduce myself to my neighbors." id ep1_02_meet_lily_afternaming_20f67b3f
    show ep1 mon_simonhome_thecity with d
    simon "Or go sightseeing perhaps." id ep1_02_meet_lily_afternaming_8dfaec51
    show ep1 mon_simonhome_thesights with fade
    simon "Take in a nice view." id ep1_02_meet_lily_afternaming_92918d99
    show ep1 mon_simonhome_beautiful with d
    simon "See just how beautiful the world is out there." id ep1_02_meet_lily_afternaming_83505816
    show ep1 mon_simonhome_doorknock with d

    play sound knock_knock
    "*Knock, knock.*" (what_italic=True)


    show ep1 anim_lily_pan with d
    pause 13

    simon "(Someone's at the door.)" id ep1_02_meet_lily_afternaming_2df3526e
    scene ep1 mon_simonhome_simon_clothes with d
    stop music fadeout 4
    simon "(Maybe I should put on some pants first.)" id ep1_02_meet_lily_afternaming_bca42c72
    menu:
        "Nah, this is fine"(True):

            show ep1 mon_simonhome_door_closed with wiperight
            pause 0.5
            play sound opening_door_1 volume 0.75
            show ep1 mon_simonhome_door_lily_hi with wiperight
            play music stunned_man volume 0.15
            l "Hi."
            show ep1 mon_simonhome_door_lily_oh with d
            l "Oh dear..." id ep1_02_meet_lily_afternaming_3c54f4dd
            show ep1 mon_simonhome_door_lily_ahem with d
            l "Umm... *Ahem.* You're [name], right?" id ep1_02_meet_lily_afternaming_9b7d1ebb
            $ ep1_pantson = False
            $ player_choice("ep1_pantson:false")
        "Put on pants":
            play sound wearing_clothes_1
            show ep1 mon_simonhome_simon_pants with d
            simon "(At least let me put some pants on.)" id ep1_02_meet_lily_afternaming_4388e977
            show ep1 mon_simonhome_door_closed with wiperight
            pause 0.5
            play sound opening_door_1 volume 0.75
            show ep1 mon_simonhome_door_lily_hi with wiperight
            play music stunned_man volume 0.15
            l "Hi."
            show ep1 mon_simonhome_door_lily_youresimon with d
            l "You must be [name]." id ep1_02_meet_lily_afternaming_3169a7b2
            $ ep1_pantson = True
            $ player_choice("ep1_pantson:true")
    show ep1 mon_simonhome_door_simon_me with d
    simon "Yep, that's me." id ep1_02_meet_lily_afternaming_cdfa8883
    show ep1 mon_simonhome_lily_phone with d
    lily "I'm Lily. We spoke on the phone a few times." id ep1_02_meet_lily_afternaming_2edfeb2d
    show ep1 mon_simonhome_simon_thatslily with d
    simon "(She's Lily?!)" id ep1_02_meet_lily_afternaming_191b87a7
    show ep1 mon_simonhome_lily_hotphone with d
    simon "(She had such a mellow voice.)" id ep1_02_meet_lily_afternaming_421583fa
    simon "(But it's so hard to tell if a woman is hot or not by her voice alone...)" id ep1_02_meet_lily_afternaming_49b7e949
    scene ep1 mon_simonhome_lily_simon_sorry with None
    lily "*Ahem.* [name]?" id ep1_02_meet_lily_afternaming_3ed8d701
    simon "Ah, sorry." id ep1_02_meet_lily_afternaming_767ecb20
    simon "You're my landlady, right?" id ep1_02_meet_lily_afternaming_2adeb219
    show ep1 mon_simonhome_lily_thatsright with d
    lily "That's right." id ep1_02_meet_lily_afternaming_1129a82d
    lily "Sorry I wasn't in town yesterday to greet you when you arrived." id ep1_02_meet_lily_afternaming_388cb660
    show ep1 mon_simonhome_lily_findhere with d
    lily "I hope you've found everything to your liking in there." id ep1_02_meet_lily_afternaming_fca9ee10
    show ep1 mon_simonhome_simon_answers with d
    simon "I did. Thank you." id ep1_02_meet_lily_afternaming_b7db5238
    show ep1 mon_simonhome_lily_chauffeur with d
    lily "Did our chauffeur come to the right place to pick you up?" id ep1_02_meet_lily_afternaming_db4e520b

    show ep1 mon_simonhome_simon_mem_station with fade
    simon "(Right. She had her driver pick me up at the train station.)" id ep1_02_meet_lily_afternaming_50362d1e
    show ep1 mon_simonhome_simon_mem_keys with d
    simon "(He handed me the keys to my new apartment and treated me like a king.)" id ep1_02_meet_lily_afternaming_33c203e3
    simon "(I'm certainly not rich, but this lady must be loaded.)" id ep1_02_meet_lily_afternaming_61b6cadf
    show ep1 mon_simonhome_simon_answers with fade
    simon "He did, yes." id ep1_02_meet_lily_afternaming_cf8c3949
    show ep1 mon_simonhome_lily_chauffeur with d
    lily "And have you spoken with Susan yet?" id ep1_02_meet_lily_afternaming_f7bcfb7f
    show ep1 mon_simonhome_simon_newboss with d
    simon "(Susan's my new boss.)" id ep1_02_meet_lily_afternaming_359e6aa8
    simon "(They made some sort of arrangement where Lily will allow me to live here as long as I keep working for Susan.)" id ep1_02_meet_lily_afternaming_6fe275c1
    show ep1 mon_simonhome_simon_notyet with d
    simon "Not yet. I was actually planning on heading out and meeting her later." id ep1_02_meet_lily_afternaming_97c1b976
    simon "I need to buy some stuff at the mall anyway." id ep1_02_meet_lily_afternaming_5662b352
    simon "A towel, for instance." id ep1_02_meet_lily_afternaming_89bc4004
    show ep1 mon_simonhome_simon_towel with d
    simon "I forgot to bring one." id ep1_02_meet_lily_afternaming_9d05c2c5
    show ep1 mon_simonhome_lily_isee with d
    lily "I see." id ep1_02_meet_lily_afternaming_2ee4cc88
    lily "If you run into any issues, I don't live too far from here." id ep1_02_meet_lily_afternaming_864c5fd5
    lily "You have my number, so feel free to call or text whenever." id ep1_02_meet_lily_afternaming_7af762e7
    show ep1 mon_simonhome_simon_mrslily with d
    simon "Thank you, Lily... I mean, uh... Missus..." id ep1_02_meet_lily_afternaming_0f6056e7
    simon "Sorry, I didn't catch your last name." id ep1_02_meet_lily_afternaming_15a93435
    show ep1 mon_simonhome_lily_lastname with d
    lily "Just call me Lily." id ep1_02_meet_lily_afternaming_f96fbab7
    lily "I don't like using my husband's last name." id ep1_02_meet_lily_afternaming_7ea42ba5
    show ep1 mon_simonhome_out_lily with fade
    menu:
        "Ask about her husband"(True):

            show ep1 mon_simonhome_m_simon_husband with d
            simon "I haven't met your husband." id ep1_02_meet_lily_afternaming_041dcf8c
            simon "Is this place his?" id ep1_02_meet_lily_afternaming_f60ef768
            show ep1 mon_simonhome_m_lily_hewish with d
            lily "Hmph. He wishes." id ep1_02_meet_lily_afternaming_dd7058ef
            show ep1 mon_simonhome_m_lily_mylabor with d
            lily "These are my properties — the fruits of my own labor." id ep1_02_meet_lily_afternaming_c6a163fa
            show ep1 mon_simonhome_m_simon_question with d
            simon "What does he do for work then?" id ep1_02_meet_lily_afternaming_f80ce3e5
            show ep1 mon_simonhome_m_lily_he with d
            lily "He's..." id ep1_02_meet_lily_afternaming_9d01487f
            lily "... Well, he's a busy man." id ep1_02_meet_lily_afternaming_0dc58da5
            show ep1 mon_simonhome_m_simon_isee with d
            simon "Oh... I see." id ep1_02_meet_lily_afternaming_c7f90153
            simon "(Yeah. That's none of my business.)" id ep1_02_meet_lily_afternaming_b53bb78b
            show ep1 mon_simonhome_m_lily_alderson with d
            lily "Alderson." id ep1_02_meet_lily_afternaming_61d83a66
            show ep1 mon_simonhome_m_simon_what with d
            simon "Huh?" id ep1_02_meet_lily_afternaming_78cb84f6
            show ep1 mon_simonhome_m_lily_alderson with d
            lily "It's Lily Alderson." id ep1_02_meet_lily_afternaming_a804632e
            show ep1 mon_simonhome_m_lily_lily with d
            lily "But, please, just call me Lily." id ep1_02_meet_lily_afternaming_fdb065b8
            $ lily_husband = True
            $ player_choice("lily_husband:true")
        "Ask her about her last name":
            show ep1 mon_simonhome_m_simon_question with d
            simon "But isn't it your last name too?" id ep1_02_meet_lily_afternaming_afaa10a7
            simon "I mean, with you being married and all." id ep1_02_meet_lily_afternaming_fb668f83
            show ep1 mon_simonhome_m_simon_unless with d
            simon "Unless..." id ep1_02_meet_lily_afternaming_313fb288
            show ep1 mon_simonhome_m_simon_thinks with d
            simon "(He's either dead, or they're getting divorced.)" id ep1_02_meet_lily_afternaming_fa0eabc1
            simon "(Either way, I fucked up by bringing it up.)" id ep1_02_meet_lily_afternaming_cab2a59a
            show ep1 mon_simonhome_m_simon_sorry with d
            simon "Sorry. That's none of my business." id ep1_02_meet_lily_afternaming_70723928
            show ep1 mon_simonhome_m_lily_itsfine with d
            lily "It's fine." id ep1_02_meet_lily_afternaming_54d08638
            lily "And you're right. It's my last name too." id ep1_02_meet_lily_afternaming_5e98f6ec
            show ep1 mon_simonhome_m_lily_lily with d
            lily "Lily Alderson." id ep1_02_meet_lily_afternaming_759499bf
            $ lily_husband = True
            $ player_choice("lily_husband:true")
        "Better not ask":
            show ep1 mon_simonhome_m_simon_fine with d
            simon "Oh. Understood." id ep1_02_meet_lily_afternaming_fee21114
            $ player_choice("lily_husband:false")

    show ep1 mon_simonhome_lily_somewhere with d
    lily "Anyway, didn't you say you had some place to be?" id ep1_02_meet_lily_afternaming_a3b26ded
    show ep1 mon_simonhome_simon_forgot with d
    simon "Right! I almost forgot!" id ep1_02_meet_lily_afternaming_eea78ed7
    show ep1 mon_simonhome_lily_comeback with d
    lily "Let me know if you need anything when you get back." id ep1_02_meet_lily_afternaming_c524f55a
    lily "But, again, call me Lily." id ep1_02_meet_lily_afternaming_9dbf15ec
    if choice_made("lily_husband"):
        menu:
            "Call her Mrs. Alderson":
                show ep1 mon_simonhome_simon_lily with d
                simon "Thank you, Mrs. Alderson." id ep1_02_meet_lily_afternaming_174ed0e3
                show ep1 mon_simonhome_lily_itslily with d
                lily "What did I literally just finish saying?" id ep1_02_meet_lily_afternaming_a43fb61c
                lily "It's Lily." id ep1_02_meet_lily_afternaming_35639667
                $ callsher_lily = False
                $ player_choice("callsher_lily:false")
            "Call her Lily"(True):
                show ep1 mon_simonhome_simon_lily with d
                simon "Thank you, Lily." id ep1_02_meet_lily_afternaming_e68d3818
                $ callsher_lily = True
                $ player_choice("callsher_lily:true")
                $ points_lily += 1
    else:
        show ep1 mon_simonhome_simon_lily with d
        simon "Thank you, Lily!" id ep1_02_meet_lily_afternaming_01f62026
        $ player_choice("callsher_lily:true")
        $ callsher_lily = True
    show ep1 mon_simonhome_lily_mall_bus with d
    lily "If you're headed to the mall, you should take the bus." id ep1_02_meet_lily_afternaming_e017297d
    lily "The bus stop is just down the street." id ep1_02_meet_lily_afternaming_4b26e13f
    show ep1 mon_simonhome_lily_toohot with d
    lily "You could probably make it there on foot, but it's way too hot out there to even try." id ep1_02_meet_lily_afternaming_be2be356
    if chose("ep1_pantson"):
        stop music fadeout 4.0
    show ep1 mon_simonhome_simon_thanksagain with d
    simon "Got it. Thanks again!" id ep1_02_meet_lily_afternaming_1e8b5135
    simon "See you later." id ep1_02_meet_lily_afternaming_ba91d610
    if not chose("ep1_pantson"):
        show ep1 mon_simonhome_lily_nopants with None
        stop music
        lily "Are you really going to go out there like that?" id ep1_02_meet_lily_afternaming_e2b6f085

        show ep1 mon_simonhome_simon_ohshit with d
        simon "Oh, shit. That would've been bad!" id ep1_02_meet_lily_afternaming_1307c67d
        simon "Thank you, Lily!" id ep1_02_meet_lily_afternaming_785961ad
        play sound opening_door_1
        show ep1 mon_simonhome_enters with d
        pause
        show ep1 mon_simonhome_leaves with d
        pause

    show ep1 mon_simonhome_malltime with d
    simon "(Right. Time to head to the mall.)" id ep1_02_meet_lily_afternaming_6163c2df

    jump ep1_03_bus_stop
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
