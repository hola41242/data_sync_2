label ep1_27_julia_call:
    show ep1 wed_simonhome_aft_phone_ringing with d
    play sound phone_vibrating volume 0.3
    phone "*Bzzzzt.*" id ep1_27_julia_call_7cf5384a
    stop sound fadeout 0.5
    show ep1 wed_simonhome_aft_phone_hello with d
    simon "Hel —" id ep1_27_julia_call_4d73363e
    show ep1 wed_juliaroom_julia_happy_talks with d
    play music grateful volume 0.35
    julia "Heeeyy, Twinkle Toes!" id ep1_27_julia_call_70967107
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "Hi, Julia." id ep1_27_julia_call_d12a7cab
    simon "What's up?" id ep1_27_julia_call_53002c01
    show ep1 wed_juliaroom_julia_confident_talks with d
    julia "I'm calling to tell you I've been practicing. A lot!" id ep1_27_julia_call_90083034
    if not chose('ep1_win_arcade'):
        julia "You tricked me, so I don't know how good you really are." id ep1_27_julia_call_e6910517
        julia "But I'm gonna beat you fair and square next time!" id ep1_27_julia_call_bd3fb803
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "All right. Maybe I'll do some practicing myself!" id ep1_27_julia_call_ceba1c75
    show ep1 wed_juliaroom_julia_happy_talks with d
    julia "That's what I like to hear." id ep1_27_julia_call_7b7fa75d
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "So, when are we going to have our rematch?" id ep1_27_julia_call_9868f5f3
    show ep1 wed_juliaroom_julia_reg_talks with d
    julia "Well, I'm at the mall every Monday." id ep1_27_julia_call_ea1358b4
    julia "But we might be able to meet up before that." id ep1_27_julia_call_3f4b0add
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "I mean, my boss works at the mall, so I'll probably be around there quite a bit." id ep1_27_julia_call_e32d3996
    show ep1 wed_juliaroom_julia_happy_talks with d
    julia "Cool. I'll hit you up next time I'm there then." id ep1_27_julia_call_788bd86a
    show ep1 wed_juliaroom_julia_reg_talks with d
    julia "By the way, thanks for playing with me the other day." id ep1_27_julia_call_4d602d1f
    julia "Usually, people think that game is lame." id ep1_27_julia_call_fe3cf47d
    julia "And my coworkers have no time to hang out." id ep1_27_julia_call_c481b98d
    show ep1 wed_simonhome_phone_schoolgirl with d
    simon "(Yeah. Julia seems way too busy.)" id ep1_27_julia_call_0d37d116
    simon "(I almost forgot about that.)" id ep1_27_julia_call_731024d4
    simon "(Should I really be taking so much of her time like this?)" id ep1_27_julia_call_1ec8b266
    menu:
        "Sure {#ep1_27_julia_call}"(True):
            show ep1 wed_simonhome_phone_answer with d
            simon "(I mean, what's the big deal, right?)" id ep1_27_julia_call_fb633c73
            simon "(She seems to enjoy my company.)" id ep1_27_julia_call_c57827f5
            $ ep1_hangout_julia = True
            $ player_choice("ep1_hangout_julia:true")
            $ points_julia += 1
        "No {#ep1_27_julia_call}":
            $ player_choice("ep1_hangout_julia:false")
            show ep1 wed_simonhome_phone_answer with d
            simon "(Hmm, maybe not.)" id ep1_27_julia_call_103e3c37
    show ep1 wed_juliaroom_julia_reg_talks with d
    julia "[name]?" id ep1_27_julia_call_f3656921
    julia "[name], are you there?" id ep1_27_julia_call_d95b645e
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "Yeah, sorry. I'm here." id ep1_27_julia_call_55ba5632
    show ep1 wed_juliaroom_julia_happy_talks with d
    julia "You went silent on me there." id ep1_27_julia_call_5ca24704
    show ep1 wed_simonhome_phone_checks with d
    play sound smartphone_notification volume 0.5
    simon "Huh?" id ep1_27_julia_call_196da51b
    simon "(Oh, shit. Lily's calling!)" id ep1_27_julia_call_25f99bd4
    show ep1 wed_juliaroom_julia_reg_talks with d
    julia "Hey, there's something else I've been meaning to talk to you about..." id ep1_27_julia_call_134ff9ce
    show ep1 wed_juliaroom_julia_reg_silent with d
    simon "Sorry, someone else is calling. What were you saying?" id ep1_27_julia_call_f93b30a7
    show ep1 wed_juliaroom_julia_reg_talks with d
    julia "It's cool. Never mind." id ep1_27_julia_call_831ba47b
    show ep1 wed_juliaroom_julia_reg_silent with d
    simon "No, it sounded important." id ep1_27_julia_call_94844faf
    show ep1 wed_juliaroom_julia_happy_talks with d
    julia "We'll talk when I see you next time." id ep1_27_julia_call_062a7859
    julia "Don't worry about it." id ep1_27_julia_call_d64ecbbf
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "All right." id ep1_27_julia_call_4fe2af78
    show ep1 wed_juliaroom_julia_happy_talks with d
    stop music fadeout 4
    julia "Talk to you later." id ep1_27_julia_call_10fe5c5a
    show ep1 wed_juliaroom_julia_happy_silent with d
    simon "See you." id ep1_27_julia_call_cd83eaef
    jump ep1_28_lily_sink
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
