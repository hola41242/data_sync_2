label ep1_11_meet_emily:


    show ep1 mon_simonhome_neighbor_alyssamemory with d
    alyssa "Don't you have any neighbors?" (what_italic=True)
    show ep1 mon_simonhome_afternoon_gettingready with d
    simon "I guess I could try that first." id ep1_11_meet_emily_aab03f36
    show ep1 mon_simonhome_neighbor_quiet with d
    simon "Let's see..." id ep1_11_meet_emily_67be80ba
    stop music fadeout 4
    simon "It's so quiet here." id ep1_11_meet_emily_da566bf5
    show ep1 mon_simonhome_neighbor_light with d
    simon "There's a light on downstairs." id ep1_11_meet_emily_39e85709
    show ep1 mon_simonhome_neighbor_door with wipeleft
    menu:
        "Knock on the door":
            play sound knock_knock volume 0.7
            show ep1 mon_simonhome_neighbor_knock with d
            "*Knocks on the door.*"
        "Take a closer look"(True):
            show ep1 mon_simonhome_neighbor_sound with d
            play music hairdryer volume 0.5
            simon "There's a sound coming from in there." id ep1_11_meet_emily_b49d4204
            simon "Maybe a hairdryer?" id ep1_11_meet_emily_9df32688
            simon "There's also a sign on the door that says \"Emily.\"" id ep1_11_meet_emily_598eeb85

            play sound knock_knock
            show ep1 mon_simonhome_neighbor_knock with d
            stop music fadeout 2
            "*Knocks on the door.*"
            simon "Ummm, hello? Emily?" id ep1_11_meet_emily_376a0ef2

    n "Coming." id ep1_11_meet_emily_aa615d76
    play sound opening_door_1
    play music circle volume 0.1
    show ep1 mon_simonhome_neighbor_emily_hi with d

    n "Hi there." id ep1_11_meet_emily_7b8ba185
    show ep1 mon_simonhome_neighbor_imsimon with d
    simon "Hi. I'm [name]. I'm your new neighbor." id ep1_11_meet_emily_f74a4075
    show ep1 mon_simonhome_neighbor_emily_noise with d
    n "Sorry. Was I making too much noise?" id ep1_11_meet_emily_1a1504cf
    show ep1 mon_simonhome_neighbor_emily_noise_s with d
    simon "No, not at all." id ep1_11_meet_emily_650e38ab
    show ep1 mon_simonhome_neighbor_emily_know with d
    n "I didn't even know I had a new neighbor. Sorry." id ep1_11_meet_emily_50103b9c
    show ep1 mon_simonhome_neighbor_emily_noise_s with d
    simon "It's totally fine. I just moved in." id ep1_11_meet_emily_c5ef031b
    simon "That's actually why I dropped by." id ep1_11_meet_emily_9b567780
    show ep1 mon_simonhome_neighbor_towel with d
    simon "I was just about to take a shower..." id ep1_11_meet_emily_027c4a1a
    simon "... But then I realized I forgot to pack a towel!" id ep1_11_meet_emily_4426cb55
    show ep1 mon_simonhome_neighbor_emily_canthelp with d
    n "Oh." id ep1_11_meet_emily_3e7505ab
    n "Sorry, but I can't really help you with that." id ep1_11_meet_emily_11fd0269
    show ep1 mon_simonhome_neighbor_emily_see with d
    n "As you can see..." id ep1_11_meet_emily_7265e395
    show ep1 mon_simonhome_neighbor_emily_damn with d
    simon "Oh..." id ep1_11_meet_emily_d3eabd74
    show ep1 mon_simonhome_neighbor_emily_something with d
    n "Have you tried using something else as a towel?" id ep1_11_meet_emily_cd91e719
    simon "Well... No." id ep1_11_meet_emily_0b73bce8
    show ep1 mon_simonhome_neighbor_emily_improvise with d
    n "Improvise. Adapt. Overcome." id ep1_11_meet_emily_6bb5baa2
    show ep1 mon_simonhome_neighbor_remember with d
    simon "I'll keep those words in mind." id ep1_11_meet_emily_7d1b5209
    simon "Thanks anyway." id ep1_11_meet_emily_d356d55b
    simon "... And sorry for disturbing you." id ep1_11_meet_emily_4f7a9223
    show ep1 mon_simonhome_neighbor_emily_np with d
    n "Not a problem." id ep1_11_meet_emily_c15fb2ac
    n "Good luck!" id ep1_11_meet_emily_6177f699
    show ep1 mon_simonhome_neighbor_emily_door with d
    simon "(She didn't close the door all the way.)" id ep1_11_meet_emily_2aa144d6
    show ep1 mon_simonhome_neighbor_emily_oh with d
    simon "(Umm...)" id ep1_11_meet_emily_adc41a60
    menu:
        "Peek"(True):
            $ player_choice('ep1_peek_emily:true')
            show ep1 mon_simonhome_neighbor_emily_mirror1 with d
            pause
            show ep1 anim_emily_02_var1 with d
            pause
            show ep1 mon_simonhome_neighbor_emily_mirror2 with d
            pause
            show ep1 mon_simonhome_neighbor_emily_mirror3 with d
            pause
            show ep1 mon_simonhome_neighbor_emily_mirror4 with d
            pause
        "Leave":


            $ player_choice('ep1_peek_emily:false')

            pass



    show ep1 mon_simonhome_afternoon_goingout with wipeleft
    stop music fadeout 2
    simon "(I'll just go see Lily.)" id ep1_11_meet_emily_c1217608
    simon "(Her house is right down the street.)" id ep1_11_meet_emily_7d87c53f

    jump ep1_12_lilyhome
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
