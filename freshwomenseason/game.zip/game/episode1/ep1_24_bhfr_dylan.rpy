label ep1_24_bhfr_dylan:
    simon "Whoa, what the — ?" id ep1_24_bhfr_dylan_32ffc5fd
    simon "(Dylan would definitely find this interesting.)" id ep1_24_bhfr_dylan_51eaec22
    simon "(Maybe I should give him a call.)" id ep1_24_bhfr_dylan_2a298247
    $ renpy.music.set_volume(0.15)
    show ep1 wed_beachhouse_dylan_hello with d
    dylan "Hello?" id ep1_24_bhfr_dylan_f824a9e7
    show ep1 wed_beachhouse_dylan_silent_serious with d
    simon "Hey, Dylan. It's [name]." id ep1_24_bhfr_dylan_c42b1995
    show ep1 wed_beachhouse_dylan_heysimon with d
    dylan "[name]! What's going on, buddy?" id ep1_24_bhfr_dylan_ed02823c
    show ep1 wed_beachhouse_dylan_silent with d
    simon "Hey, do you remember the milf on the cover of that magazine?" id ep1_24_bhfr_dylan_25b5bae1
    show ep1 wed_beachhouse_dylan_talks with d
    dylan "Do I remember? I haven't stopped thinking about her!" id ep1_24_bhfr_dylan_2b81d436
    dylan "Your boss, right?" id ep1_24_bhfr_dylan_2931849f
    show ep1 wed_beachhouse_dylan_silent with d
    simon "Right, and I'm at her house as we speak." id ep1_24_bhfr_dylan_b23fff57
    show ep1 wed_beachhouse_dylan_talks with d
    dylan "What are you doing at your boss's house?" id ep1_24_bhfr_dylan_3ae72bf1
    dylan "Don't tell me she invited you in for a little overtime..." id ep1_24_bhfr_dylan_4e7836a1
    show ep1 wed_beachhouse_dylan_silent with d
    simon "Naw, man. I just came to grab something for her. She's not even here." id ep1_24_bhfr_dylan_c0612cad
    simon "Only, I ended up finding some sort of sex dungeon." id ep1_24_bhfr_dylan_763920ea
    simon "It's full of dildos and a bunch of leather clothes." id ep1_24_bhfr_dylan_0a6e9285
    show ep1 wed_beachhouse_dylan_heysimon with d
    dylan "Oh, I see." id ep1_24_bhfr_dylan_c327ddb7
    dylan "You went through her underwear drawer, huh?" id ep1_24_bhfr_dylan_0ba25586
    show ep1 wed_beachhouse_dylan_simon with d
    dylan "You pervert." id ep1_24_bhfr_dylan_cd4ea3a0
    show ep1 wed_beachhouse_dylan_silent with d
    simon "Nah, it's nothing like that." id ep1_24_bhfr_dylan_e5c7c0cf
    show ep1 wed_beachhouse_dylan_talks with d
    dylan "Sure, man. I'm not judging." id ep1_24_bhfr_dylan_b7554b35
    dylan "I'd do the same." id ep1_24_bhfr_dylan_47fcab11
    show ep1 wed_beachhouse_dylan_silent with d
    simon "What?" id ep1_24_bhfr_dylan_708b4972
    simon "That's not what I —" id ep1_24_bhfr_dylan_35eb429e
    simon "Whatever. Let me send you a picture. Then you'll see what I mean." id ep1_24_bhfr_dylan_7a286380
    simon "I'm going to tag the location as well. You've got to see this place." id ep1_24_bhfr_dylan_9f36dd92
    simon "Anyway, got to go." id ep1_24_bhfr_dylan_d5c59545
    simon "We'll talk later." id ep1_24_bhfr_dylan_4e3f09d7
    $ renpy.music.set_volume(0.5)
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
