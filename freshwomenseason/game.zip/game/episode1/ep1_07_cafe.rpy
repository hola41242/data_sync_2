
label ep1_07_cafe:
    hide screen cellphone
    stop music fadeout 4
    play music punch_1_2_original volume 0.15
    play sound door_shop_bell volume 0.75

    show ep1 mon_cafe_alyssa_dance1 with fade
    a "One..." id ep1_07_cafe_35001dd2
    show ep1 mon_cafe_alyssa_dance2 with dissolve
    a "Two..." id ep1_07_cafe_8c02e756
    show ep1 mon_cafe_alyssa_dance3 with dissolve
    a "Three..." id ep1_07_cafe_98b2b36c
    show ep1 mon_cafe_alyssa_dance4 with dissolve
    a "Four..." id ep1_07_cafe_a184d90b
    stop music
    show ep1 mon_cafe_alyssa_dance5 with vpunch
    a "!!!" (what_bold=True)
    show ep1 mon_cafe_alyssa_shy with dissolve
    a "Please tell me you didn't see that." id ep1_07_cafe_be39b0d1


    menu:
        "See what?"(True):
            stop music fadeout 2
            prot "See what?" id ep1_07_cafe_ae4b9fae
            prot "I saw absolutely no one dancing or anything." id ep1_07_cafe_4e9f7450
            show ep1 mon_cafe_alyssa_shy_good with dissolve
            a "Good because that would have been embarrassing!" id ep1_07_cafe_e253ae1b
            $ points_alyssa += 1
            $ alyssa_cafe_dance_joke = True
        "You mean the dance routine?":
            stop music fadeout 2
            prot "You've got some moves!" id ep1_07_cafe_99fb6116
            a "Uh... Thanks, I guess..." id ep1_07_cafe_5fa7167b
            show ep1 mon_cafe_alyssa_shy_bad with dissolve
            a "Well, that's embarrassing..." id ep1_07_cafe_52e1ce76
            $ alyssa_cafe_dance_joke = False

    show ep1 mon_cafe_alyssa_greet with dissolve
    play music cafe_de_philosophie volume 0.12
    a "Anyway! Welcome to MoonBucks Café!" id ep1_07_cafe_f4235027
    alyssa "My name is Alyssa, and I'll be your barista today." id ep1_07_cafe_d9513e7c
    alyssa "So, what can I get for you?" id ep1_07_cafe_16452827
    show ep1 mon_cafe_alyssa_wait with dissolve
    prot "Actually, I'm new in town, so I figured I'd stop in for a fancy cup of coffee..." id ep1_07_cafe_d4e79c29
    show ep1 mon_cafe_alyssa_menu with dissolve
    alyssa "Oh! Would you like to see our menu then?" id ep1_07_cafe_b2b51c92
    prot "That would be nice." id ep1_07_cafe_109066e1
    show ep1 mon_cafe_alyssa_walk with dissolve
    alyssa "I'll be right back." id ep1_07_cafe_d5d63002
    show ep1 mon_cafe_simon_menu with dissolve
    prot "Umm... I don't know what any of this means..." id ep1_07_cafe_b8081c50
    show ep1 mon_cafe_simon_menu_affogato with dissolve
    prot "I mean, what even is an affogato?" id ep1_07_cafe_f0efca9c
    show ep1 mon_cafe_alyssa_explain with dissolve
    alyssa "It's a shot of espresso poured over a scoop of vanilla ice cream." id ep1_07_cafe_03b3c1a8
    show ep1 mon_cafe_simon_menu_affogato with dissolve
    prot "Ice cream? Really?" id ep1_07_cafe_7496bfd3
    show ep1 mon_cafe_alyssa_explain_wonder with dissolve
    alyssa "Hmm... Maybe that's not your thing." id ep1_07_cafe_30fa171a
    show ep1 mon_cafe_alyssa_explain_idea with dissolve
    alyssa "How about we start you with an americano so we don't scare you off, huh?" id ep1_07_cafe_e3def3ae
    menu:
        "Americano it is then"(True):

            show ep1 mon_cafe_simon_menu_talks with dissolve
            prot "All right. One americano it is then." id ep1_07_cafe_04ee9b83
            show ep1 mon_cafe_alyssa_menu_happy with dissolve
            alyssa "Great! I'll be right back with your order." id ep1_07_cafe_cfd0f871
            show ep1 mon_cafe_alyssa_makes_coffee with dissolve
            play sound pouring_a_cup_of_tea volume 0.4
            alyssa "Usually people take their americanos to go, but you're welcome to stay if you'd like." id ep1_07_cafe_53677e11
            show ep1 mon_cafe_alyssa_back_americano with dissolve
            stop sound fadeout 0.2
            alyssa "Here you are." id ep1_07_cafe_f553f95b

            $ ep1_cafe_americano = True
            $ player_choice("ep1_cafe_americano:true")
        "I'm good, thanks":
            show ep1 mon_cafe_simon_menu_talks with dissolve
            prot "I think I'll pass for now, but thank you." id ep1_07_cafe_6a36f06b
            prot "I don't know the first thing about coffee. I probably shouldn't even have come." id ep1_07_cafe_dcd8c2e0
            show ep1 mon_cafe_alyssa_menu_happy with dissolve
            alyssa "Well, you're welcome to stay now that you're here." id ep1_07_cafe_3fbd9899
            $ ep1_cafe_americano = False
            $ player_choice("ep1_cafe_americano:false")
    show ep1 mon_cafe_alyssa_talks with dissolve
    alyssa "My boss isn't here yet, and we've got no other tables." id ep1_07_cafe_58206f5a
    show ep1 mon_cafe_alyssa_listens with dissolve
    prot "Is it always like this?" id ep1_07_cafe_f26ff36d
    prot "Seems quite empty." id ep1_07_cafe_0bee202f
    show ep1 mon_cafe_alyssa_talks with dissolve
    alyssa "We had some customers earlier, all kick-starting the day with a cup of coffee." id ep1_07_cafe_3914204b
    alyssa "We'll get another spike at lunch when people drop by for a sandwich or something sweet." id ep1_07_cafe_f11e8227
    alyssa "But I normally have this hour devoid of customers every day." id ep1_07_cafe_28f2b8df
    show ep1 mon_cafe_alyssa_listens with dissolve
    if chose('alyssa_cafe_dance_joke'):
        prot "Is that when you do the thing I didn't see you doing?" id ep1_07_cafe_5fc4d83a
    else:
        prot "Is that when you practice your moves?" id ep1_07_cafe_d1a96d1b
    show ep1 mon_cafe_alyssa_moves with dissolve
    alyssa "My body just moves on its own when certain songs come on!" id ep1_07_cafe_8041fb2a
    alyssa "And, yes, I do like to practice my dance moves when no one's around." id ep1_07_cafe_2f638e31
    menu:
        "Sorry for ruining your moment"(True):
            prot "Sorry for interrupting!" id ep1_07_cafe_b00cd38e
            show ep1 mon_cafe_alyssa_happy with dissolve
            alyssa "Nah, you're good! It's not like I have stage fright or anything." id ep1_07_cafe_591d098b
            alyssa "You just caught me off guard." id ep1_07_cafe_18ba1f18
            alyssa "Plus, this is a public place. No reason to apologize."
            $ points_alyssa += 1
        "I'm glad I got a glimpse":
            prot "I'm glad I got to catch a glimpse." id ep1_07_cafe_449b7add
            show ep1 mon_cafe_alyssa_happy with dissolve
            alyssa "That's what I get for dancing in public."
    show ep1 mon_cafe_alyssa_happy_question with dissolve
    alyssa "Now that you know some of my hobbies, it's only fair that you tell me something about yourself." id ep1_07_cafe_16da1ca3
    alyssa "You said you just moved here, right?" id ep1_07_cafe_e2f0507c
    show ep1 mon_fanservice_alyssa1 with dissolve
    prot "Yeah, I came for college." id ep1_07_cafe_ec4f3a58
    alyssa "Oh, and how's that going?" id ep1_07_cafe_c00fa1a3
    prot "Well, classes don't start till next week, so I don't really have an answer for that." id ep1_07_cafe_da59c3f5
    show ep1 mon_cafe_alyssa_happy_question3 with dissolve
    alyssa "Wait. You say you're new in town, but just how new are you?" id ep1_07_cafe_ad87b657
    show ep1 mon_cafe_simon_answer with dissolve
    prot "I just got here yesterday. I haven't even finished unpacking." id ep1_07_cafe_be3122f0
    prot "Which is like, one bag of clothes to be fair." id ep1_07_cafe_d7bd4b7d
    show ep1 mon_cafe_simon_ontable_dumb with dissolve
    prot "And this idiot forgot to pack a towel." id ep1_07_cafe_c5b9f5dd
    show ep1 mon_cafe_simon_ontable_dumb2 with dissolve
    prot "Guess what Mr. Idiot did right when he arrived at his new home?" id ep1_07_cafe_a029d779
    show ep1 mon_cafe_alyssa_happy_shower with dissolve
    alyssa "He took a shower." id ep1_07_cafe_d2215d3f
    show ep1 mon_cafe_simon_ontable_dumb with dissolve
    prot "He took a shower." id ep1_07_cafe_b26c47a1
    show ep1 mon_cafe_alyssa_happy_laughs with dissolve
    alyssa "Hahaha. Rookie mistake." id ep1_07_cafe_0d2e67c7
    show ep1 mon_cafe_alyssa_happy_question3 with dissolve
    alyssa "Wait, how did you dry off then?" id ep1_07_cafe_1d8c7dbd
    show ep1 mon_cafe_simon_ontable_dumb2 with dissolve
    prot "Well..." id ep1_07_cafe_62917185
    show ep1 mon_simonhome_int_drying with fade
    prot "I live on the second floor, and I have a window." id ep1_07_cafe_d4c53152
    prot "Let me tell you, it sure is windy in this town!" id ep1_07_cafe_ed91ea12
    show ep1 mon_cafe_alyssa_happy_laughs with fade
    alyssa "Oh my god!" id ep1_07_cafe_9e0b40e8
    show ep1 mon_cafe_alyssa_happy_question with dissolve
    alyssa "Don't you have any neighbors?" id ep1_07_cafe_0294bf88
    show ep1 mon_cafe_simon_ontable_dumb with dissolve
    prot "I do, but I don't think anyone saw me. I kept all the lights off." id ep1_07_cafe_f4709144
    show ep1 mon_cafe_alyssa_happy_question3 with dissolve
    alyssa "Didn't you think about asking one of them if they had a spare towel to lend you?" id ep1_07_cafe_0f755f0f
    show ep1 mon_cafe_simon_ontable_dumb2 with dissolve
    prot "Well..." id ep1_07_cafe_797e4f7b
    show ep1 mon_cafe_simon_ontable_dumbidea with dissolve
    prot "My landlady might have been able to help me out." id ep1_07_cafe_433669a1
    prot "But I don't think she'd be very keen to help if I showed up naked at her doorstep." id ep1_07_cafe_3b5a6c81
    show ep1 mon_cafe_alyssa_happy_question with dissolve
    alyssa "I suppose not." id ep1_07_cafe_274abe62
    show ep1 mon_cafe_simon_ontable_wait with dissolve
    prot "Wait, now you know more embarrassing stuff about me than I know about you!" id ep1_07_cafe_d7cbd189
    show ep1 mon_cafe_alyssa_happy_tease with dissolve
    alyssa "That's what you get for walking in on a girl when she's in the middle of doing something that should be kept private!" id ep1_07_cafe_28e62a43
    show ep1 mon_cafe_simon_ontable_yousaidit with dissolve
    prot "You just said this is a public place..." id ep1_07_cafe_aaaf9f2e
    show ep1 mon_cafe_alyssa_happy_tease2 with dissolve
    alyssa "Relax. I'm just teasing!" id ep1_07_cafe_1c408d88
    show ep1 mon_cafe_alyssa_happy_out with dissolve
    alyssa "I'm used to dancing in public." id ep1_07_cafe_b91bfbc1
    show ep1 mon_cafe_alyssa_legs with dissolve:
        yalign 0.0
    alyssa "Just not here, of course." id ep1_07_cafe_431e436f
    show ep1 mon_cafe_alyssa_legs:
        subpixel True
        yalign 0.0
        linear 3.0 yalign 1.0
    menu:
        "Comment on her great shape"(True):
            prot "You certainly have the legs for it." id ep1_07_cafe_7f0b4612
            show ep1 mon_cafe_alyssa_legs:
                subpixel True
                yalign 1.0
                linear 3.0 yalign 0.0
            prot "You look like a professional dancer." id ep1_07_cafe_8d5709f9
            show ep1 mon_cafe_alyssa_happy_out with dissolve
            alyssa "That's because I am one!" id ep1_07_cafe_806cc8ef
            alyssa "Well, not a true professional, but I have danced in front of people." id ep1_07_cafe_05d9d421
            $ ep1_compliment_alyssa = True
        "Don't say anything":
            pass
    show ep1 mon_cafe_alyssa_invitation_question with dissolve
    alyssa "I'm part of a dance team." id ep1_07_cafe_29663de5
    alyssa "Sometimes we hold performances." id ep1_07_cafe_3479b607
    show ep1 mon_cafe_alyssa_invitation_question_listens with dissolve
    prot "Sounds fun." id ep1_07_cafe_1a0fe84c
    show ep1 mon_cafe_alyssa_invitation with dissolve
    alyssa "You know what? You should come sometime!" id ep1_07_cafe_0849d192
    alyssa "We hold dance lessons every Thursday night." id ep1_07_cafe_a88e0185
    alyssa "I could even show you around town if that interests you." id ep1_07_cafe_86809241
    alyssa "My classes are also that day if you'd like to drop by." id ep1_07_cafe_2c395303
    show ep1 mon_cafe_alyssa_invitation_question with dissolve
    alyssa "Probably should have started with this, but do you like dancing?" id ep1_07_cafe_616873d5
    show ep1 mon_cafe_alyssa_invitation_question_listens with dissolve
    prot "Uh... No, not really." id ep1_07_cafe_bdf0d26c
    prot "I'm good at Dance Dance Supreme though." id ep1_07_cafe_a399c36c
    show ep1 mon_fanservice_alyssa2 with dissolve
    alyssa "What's that?" id ep1_07_cafe_81de3f7e
    prot "Oh, it's just this video game." id ep1_07_cafe_c601fd95
    alyssa "About dancing?" id ep1_07_cafe_0c98d651
    prot "Yeah. You should definitely try it out!" id ep1_07_cafe_631a489a
    show ep1 mon_cafe_alyssa_deal with dissolve
    alyssa "I could..." id ep1_07_cafe_b1d4f659
    alyssa "If you say yes to at least one dance lesson at my studio." id ep1_07_cafe_37e09f1c
    menu:
        "Deal"(True):
            show ep1 mon_cafe_alyssa_deal_happy with dissolve
            prot "You got it." id ep1_07_cafe_5e23c40b
            alyssa "Okay. See you Thursday night then!" id ep1_07_cafe_d0b47c7a
            $ ep1_joindance = True
            $ player_choice("ep1_joindance:true")
        "I'll think about it":
            show ep1 mon_cafe_alyssa_deal_think with dissolve
            prot "I'll have to think about it." id ep1_07_cafe_0d4bf241
            prot "But who knows." id ep1_07_cafe_3a2e5293
            show ep1 mon_cafe_alyssa_invitation_question with dissolve
            alyssa "Let me know when you decide." id ep1_07_cafe_a77ffe2d
            alyssa "You know where to find me!" id ep1_07_cafe_62e77450
            $ ep1_joindance = False
            $ player_choice("ep1_joindance:false")



    show ep1 mon_cafe_alyssa_invitation_question_listens with dissolve
    stop music fadeout 2
    prot "All right. Better get going now." id ep1_07_cafe_fe13d962
    show ep1 mon_cafe_alyssa_invitation_question with dissolve
    alyssa "I didn't catch your name!" id ep1_07_cafe_75a92814
    show ep1 mon_cafe_alyssa_invitation_question_listens with dissolve
    prot "Oh, sorry! It's [name]." id ep1_07_cafe_bdfd70dd
    show ep1 mon_cafe_alyssa_invitation_question with dissolve
    alyssa "Nice to meet you, [name]." id ep1_07_cafe_ff44609a
    play music fly_that_kite volume 0.2
    show ep1 mon_cafe_alyssa_invitation_question_listens with dissolve
    prot "Nice to meet you too." id ep1_07_cafe_63c04971
    show ep1 mon_cafe_alyssa_invitation_question with dissolve
    alyssa "See you around." id ep1_07_cafe_c34ab62e
    play sound door_shop_bell
    $ went_cafe = True

    jump ep1_05_mall_fr
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
