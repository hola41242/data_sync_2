label ep1_12c_lily_kitchen:
    show ep1 mon_lilyhome_simon_outofbath with d
    simon "Thanks for letting me use your bathroom." id ep1_12c_lily_kitchen_b51a333a
    show ep1 mon_lilyhome_lilytea with d
    play music high_line volume 0.20
    lily "Would you care for a cup of tea?" id ep1_12c_lily_kitchen_c3eaf7c0
    menu:
        "Tea sounds nice"(True):
            show ep1 mon_lilyhome_simondryingtalks with d
            simon "Yes, please." id ep1_12c_lily_kitchen_ca359716
            $ ep1_accept_tea = True
        "Not really into tea":
            show ep1 mon_lilyhome_simondryingtalks with d
            simon "Tea isn't really my thing." id ep1_12c_lily_kitchen_7bdfc8a7
            $ ep1_accept_tea = False
    show ep1 mon_lilyhome_lily_clothes with d
    lily "I'll put the kettle on. You can wear these." id ep1_12c_lily_kitchen_4179af48
    show ep1 mon_lilyhome_simondressing with d
    simon "So, when does your husband get back?" id ep1_12c_lily_kitchen_eaf4059d
    show ep1 mon_lilykitchen_lilytalks with d
    lily "In a week or two if I had to guess." id ep1_12c_lily_kitchen_8517c62f
    show ep1 mon_lilykitchen_simontalks with d
    simon "Does he travel a lot for work?" id ep1_12c_lily_kitchen_0a2cfe29
    show ep1 mon_lilykitchen_lilyangry_talks with d
    lily "So much so you'd think he's forgotten he has a wife and a home." id ep1_12c_lily_kitchen_42d3a24b
    show ep1 mon_lilykitchen_lilyangry_sink with d
    lily "The bastard said he would fix the kitchen sink before he left this time." id ep1_12c_lily_kitchen_9c22bca8
    show ep1 mon_lilykitchen_lilyangry_talks with d
    lily "Probably forgot about that too." id ep1_12c_lily_kitchen_d27fe77a
    show ep1 mon_lilykitchen_lilysilent with d
    simon "I could fix it for you." id ep1_12c_lily_kitchen_90112d40
    show ep1 mon_lilykitchen_lilydoubts with d
    lily "You know how to fix a broken sink?" id ep1_12c_lily_kitchen_fd18372c
    show ep1 mon_lilykitchen_simonexplain with d
    simon "When I was younger, I used to take things apart and put them back together again." id ep1_12c_lily_kitchen_2dd055a3
    simon "Also, the house I grew up in was a mess, so I've had to fix all sorts of things through the years." id ep1_12c_lily_kitchen_6348421a
    show ep1 mon_lilykitchen_lilytalks with d
    lily "Sounds like a rough childhood." id ep1_12c_lily_kitchen_b5016dfb
    lily "Was it your father who taught you all that?" id ep1_12c_lily_kitchen_f1df9acd
    show ep1 mon_lilykitchen_simonthinks with d
    simon "I don't remember much about my dad..." id ep1_12c_lily_kitchen_5c573f65
    show ep1 mon_lilykitchen_lilyscoffs with d
    lily "Ha. Men..." id ep1_12c_lily_kitchen_bcc80890
    show ep1 mon_lilykitchen_lilysilent with d
    simon "It's not like that. It's just, my memory isn't all that great." id ep1_12c_lily_kitchen_6050c252
    show ep1 mon_lilykitchen_simonexplain with d
    simon "I had an accident, so I don't remember much of my childhood." id ep1_12c_lily_kitchen_967e2a90
    show ep1 mon_lilykitchen_lilyoh with d
    lily "Oh!" id ep1_12c_lily_kitchen_7080bff1
    show ep1 mon_lilykitchen_lilysorry with d
    lily "I'm sorry to hear that!" id ep1_12c_lily_kitchen_fadd2b92
    show ep1 mon_lilykitchen_simonnice with d
    simon "Don't worry about it. The doctors say the memories will come back to me eventually." id ep1_12c_lily_kitchen_4cc692b4
    simon "Also, it's pretty cool to be given a fresh start." id ep1_12c_lily_kitchen_0756d2cd
    show ep1 mon_lilykitchen_lilyunderstands with d
    lily "I see." id ep1_12c_lily_kitchen_b5671827
    show ep1 mon_lilykitchen_lilytalks with d
    lily "Well, you're welcome to drop by and give the sink a shot when you're free." id ep1_12c_lily_kitchen_b1ffd4c0
    lily "For now, you should probably go get some rest. It's getting late." id ep1_12c_lily_kitchen_1497acd6
    show ep1 mon_lilykitchen_lilysilent with d
    simon "Right. Thanks again for letting me take a bath." id ep1_12c_lily_kitchen_58b3b7e4
    simon "And sorry for bothering you so late." id ep1_12c_lily_kitchen_f9d2c1b8
    show ep1 mon_lilykitchen_lilytalks with d
    lily "It's fine. I don't mind the company." id ep1_12c_lily_kitchen_7ed154b4
    stop music fadeout 4
    lily "Just text me first next time. You have my number." id ep1_12c_lily_kitchen_0cdb7390
    show ep1 mon_lilykitchen_lilysilent with d
    simon "Have a good night, Lily." id ep1_12c_lily_kitchen_e1e7c280
    lily "You too." id ep1_12c_lily_kitchen_f9b0fef3

    jump ep1_14_dreams
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
