
label ep1_04_flashbacks:
    stop sound fadeout 2
    play music eternity volume 0.2
    show ep1 mon_fb1_oldhouse_night with long_fade
    "Fifteen years ago..." id ep1_04_flashbacks_a30f6ff9
    show ep1 mon_fb1_oldhouse_father_arrives with medium_fade
    mother "You can't keep doing this!" id ep1_04_flashbacks_fa165aeb
    show ep1 mon_fb1_oldhouse_argument with long_dissolve
    father "I promise this will be the last time!" id ep1_04_flashbacks_f8f61ef9
    show ep1 mon_fb1_oldhouse_mothersees with long_dissolve
    pause
    show ep1 mon_fb1_oldhouse_simon with long_dissolve
    mother "Come on, [name]. It's your bed time." id ep1_04_flashbacks_793c38ce
    show ep1 mon_fb1_oldhouse_inbed with medium_fade
    simon "The next night, my father came home in the same state." id ep1_04_flashbacks_62e332b5
    simon "They argued again, but this time they made sure I couldn't hear them." id ep1_04_flashbacks_17105de1
    simon "All I knew was that dad was in trouble because of \"those people.\" The people he worked for..." id ep1_04_flashbacks_685b1d27
    simon "Things went on like that for a couple of weeks, my father coming home late every night." id ep1_04_flashbacks_bccd7691
    simon "Until the day he never came back." id ep1_04_flashbacks_c4b6825f
    show ep1 mon_fb1_oldhouse_day_father with medium_fade
    father "Honey, this is the last time. I promise." id ep1_04_flashbacks_15419a4d
    show ep1 mon_fb1_oldhouse_day_father_simon with long_dissolve
    father "Come here, [name]. Give your old man a hug." id ep1_04_flashbacks_f2290989
    simon "That was the last we ever saw of him." id ep1_04_flashbacks_8e9bb6af
    show ep1 mon_fb1_leavinghome with medium_fade
    simon "From then on, things went straight downhill." id ep1_04_flashbacks_686fd87c
    show ep1 mon_fb1_newhouse_poor with long_dissolve
    simon "Not long after, we had to move out of our old house." id ep1_04_flashbacks_617e0f32
    show ep1 mon_fb1_newhouse_cousins with medium_fade
    simon "Mom got a job, and suddenly I was sharing a room with three of my cousins." id ep1_04_flashbacks_6351c42b
    show ep1 mon_fb1_simon_studies_young with long_dissolve
    simon "I tried finding out what my father had done, what he had been working on, and where he might be." id ep1_04_flashbacks_073fa95f
    simon "But mom never wanted to talk about it." id ep1_04_flashbacks_eb7bc822
    show ep1 mon_fb1_simon_studies_teen with long_dissolve
    simon "That didn't stop me from doing my own research though." id ep1_04_flashbacks_47db0a9d
    show ep1 mon_fb1_simon_studies_adult with long_dissolve
    simon "I slowly gathered information over the years." id ep1_04_flashbacks_ffc581e8
    play sound wind_storm_2 fadein 2
    show ep1 mon_fb1_simon_investigates with medium_fade
    simon "When I turned eighteen, I decided it was time to go looking for him." id ep1_04_flashbacks_82f2c02b
    simon "I had all my research with me. I had it all figured out." id ep1_04_flashbacks_dab8a612
    simon "But then..." id ep1_04_flashbacks_3db3b371
    play sound thunder
    stop music
    show ep1 mon_fb1_lightstruck with vpunch
    play music heartbeat_distant
    pause 2

    show ep1 mon_fb1_hospital1 with longer_fade
    simon "It turns out you don't get superpowers when you're struck by lightning." id ep1_04_flashbacks_7862506e
    simon "You only get scars." id ep1_04_flashbacks_25cf6bff
    show ep1 mon_fb1_hospital2 with medium_fade


    simon "And in my case..." id ep1_04_flashbacks_c848d2df
    simon "Memory loss." id ep1_04_flashbacks_07b9090c
    show ep1 mon_fb1_hospital3 with long_dissolve
    simon "When I came to, I had no idea where I was." id ep1_04_flashbacks_f3958923
    show ep1 mon_fb1_hospital_mother with long_dissolve
    simon "I couldn't recognize my mother." id ep1_04_flashbacks_d2e1f8ab
    show ep1 mon_fb1_hospital_self with long_dissolve
    simon "I couldn't recognize my own reflection in the mirror." id ep1_04_flashbacks_6cd9014e
    show ep1 mon_fb1_hospital_pieces with medium_fade
    simon "I had to pick up the pieces." id ep1_04_flashbacks_79f29060
    simon "Remake myself." id ep1_04_flashbacks_7b684cea
    simon "Reassemble the shards of memories scattered every which way." id ep1_04_flashbacks_4b2e49ba
    show ep1 mon_fb1_hospital_emotions with medium_fade
    simon "They told me strong emotional reactions might bring back my memories." id ep1_04_flashbacks_beac4f7e
    simon "When I saw my mother that first time, I had no idea who she was..." id ep1_04_flashbacks_f3d03b46
    show ep1 mon_fb1_hospital_mother_nurse with long_dissolve
    simon "But when I saw those sad eyes of hers as she talked with the nurse..." id ep1_04_flashbacks_53a989da
    stop music fadeout 4
    simon "I knew it was a look I'd seen before." id ep1_04_flashbacks_72413ee4
    show ep1 mon_fb1_hospital_mother_sad with long_dissolve
    simon "It was the look of a person who thinks they're about to lose someone important to them." id ep1_04_flashbacks_6ae117a4
    play music coming_back volume 0.3 fadein 2 
    show ep1 mon_fb1_simon_mother with long_dissolve


    simon "... Mom?" id ep1_04_flashbacks_4b4c98da
    show ep1 mon_fb1_better with long_fade
    simon "Things started to get better after that." id ep1_04_flashbacks_6c70f8a0
    simon "She still wouldn't talk about dad though." id ep1_04_flashbacks_c1a927b7
    show ep1 mon_fb1_simon_research with medium_fade
    simon "I ended up finding my old research, but when I showed it to her, she just told me to drop it." id ep1_04_flashbacks_6a450a98
    simon "I couldn't." id ep1_04_flashbacks_1533284a
    show ep1 mon_fb1_simon_secret with medium_fade
    simon "I secretly held on to it." id ep1_04_flashbacks_c8a3d0ac
    simon "And now, I'm after the truth." id ep1_04_flashbacks_35772224

    stop music fadeout 4
    show ep1 mon_fb1_newtown with long_fade

    simon "The last lead I have to go on is this picture." id ep1_04_flashbacks_6f5e6c53
    simon "It's what led me to this town and to this woman, Susan." id ep1_04_flashbacks_98330e78
    simon "She got me a job in the town where my father used to work." id ep1_04_flashbacks_8f7ba4a9

    simon "All right. Enough with the flashbacks." id ep1_04_flashbacks_fb4a5395

    show ep1 mon_fb1_mall_susan with longer_fade
    play music fly_that_kite volume 0.2 fadein 2
    simon "(Anyway, here I am.)" id ep1_04_flashbacks_17ae8a25
    simon "(At least it's still early.)" id ep1_04_flashbacks_22114c97

    jump ep1_05_mall
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
