label ep1_28_lily_sink:

    show ep1 wed_simonhome_aft_phone_hello with d
    play sound analog_beep volume 0.5
    simon "Hey, Lily." id ep1_28_lily_sink_dd0c8fcc
    show ep1 wed_lilyhome_phone_simon with d
    lily "[name]." id ep1_28_lily_sink_cfeb32d7
    lily "I was wondering if you could come by later if you're not too busy." id ep1_28_lily_sink_99ee90e8
    show ep1 wed_lilyhome_phone_silent with d
    simon "Oh, is this about the sink?" id ep1_28_lily_sink_ac98de03
    show ep1 wed_lilyhome_phone_sink with d
    play music stunned_man volume 0.35
    lily "Yeah... Sure... The sink." id ep1_28_lily_sink_20acba52
    lily "So, what do you say?" id ep1_28_lily_sink_09aea408
    show ep1 wed_lilyhome_phone_silent with d
    simon "Sure, I'll drop by later on." id ep1_28_lily_sink_49cd8278
    show ep1 wed_lilyhome_phone_time with d
    lily "Don't make it too much later." id ep1_28_lily_sink_a28dd048
    simon "All right. See you soon then." id ep1_28_lily_sink_9eeec7fb

    show ep1 wed_lilyhome_outside with long_fade
    simon "(Looks like her husband isn't back yet.)" id ep1_28_lily_sink_3f3d333e
    show ep1 wed_lilyhome_simonbuzz with d
    play sound intercom_ring
    "*Ring.*" id ep1_28_lily_sink_135741a1
    show ep1 wed_lilyhome_buzzer with d
    play sound phone_receive_unhook
    "*Click.*" id ep1_28_lily_sink_09d06ab8
    simon "Umm, Lily?" id ep1_28_lily_sink_ecb6928a
    lily "Who is it?" id ep1_28_lily_sink_1010fd84
    simon "It's me, [name]." id ep1_28_lily_sink_74f90213
    lily "Oh, right. The sink." id ep1_28_lily_sink_931ed88f
    play sound gate_open
    show ep1 wed_lilyhome_gate_open with d
    lily "Come in." id ep1_28_lily_sink_4404220e
    show ep1 wed_lilyhome_lily_atdoor with fade

    lily "Hey." id ep1_28_lily_sink_1b8344d3
    menu:
        "Everything all right?"(True):
            show ep1 wed_lilyhome_lily_imfree with d
            lily "I'm free right now, or did you forget?" id ep1_28_lily_sink_b0e99dfb
            lily "I don't need a reason to drink." id ep1_28_lily_sink_d27a6319
        "Rough day?":
            show ep1 wed_lilyhome_lily_something with d
            lily "Something like that." id ep1_28_lily_sink_ffac4383
    show ep1 wed_lilyhome_lily_points with d
    lily "Well, you know the way to the kitchen." id ep1_28_lily_sink_925afc1f
    simon "What's wrong with the sink exactly?" id ep1_28_lily_sink_13ae83f7
    show ep1 wed_lilyhome_lily_sink_clogged with d
    lily "Probably clogged." id ep1_28_lily_sink_1b8dcc3f
    simon "Okay. Shouldn't be a hard fix then." id ep1_28_lily_sink_9c20c381
    lily "Do your thing then. I'll go top off my glass." id ep1_28_lily_sink_13eafc9f
    lily "Should I pour you some?" id ep1_28_lily_sink_5a2eb3a9
    menu:
        "Yes, thanks"(True):
            show ep1 wed_lilyhome_simon_sure with d
            simon "Sure." id ep1_28_lily_sink_7d1120e8
            show ep1 wed_lilyhome_lily_old with d
            lily "You're old enough to drink, right?" id ep1_28_lily_sink_82048854
            simon "Yeah, I'm 21." id ep1_28_lily_sink_1bfea186
            lily "Good." id ep1_28_lily_sink_799a4356
            show ep1 wed_lilyhome_lily_morewine with d
            lily "I'll be right back with the wine." id ep1_28_lily_sink_edccc76f
            $ wine_lily = True
        "No, thank you":
            show ep1 wed_lilyhome_simon_no with d
            simon "No, thank you." id ep1_28_lily_sink_bec1191a
            show ep1 wed_lilyhome_lily_beer with d
            lily "More of a beer guy?" id ep1_28_lily_sink_7ae6f32e
            simon "Something like that." id ep1_28_lily_sink_ae8662de
            show ep1 wed_lilyhome_lily_beback with d
            lily "More for me then." id ep1_28_lily_sink_8b4d2ed4
            lily "Be right back." id ep1_28_lily_sink_279b60ef
            $ wine_lily = False
    simon "I'll get to fixing then." id ep1_28_lily_sink_914f387a
    show ep1 wed_lilyhome_simon_fixing with d
    pause
    if chose('wine_lily'):
        show ep1 wed_lilyhome_lily_yourwine with wipedown
        lily "Here's your glass." id ep1_28_lily_sink_6c17a41d
    else:
        show ep1 wed_lilyhome_lily_back with wipedown
        lily "I'm back." id ep1_28_lily_sink_89345585
    show ep1 wed_lilyhome_lily_done with d
    lily "Done yet?" id ep1_28_lily_sink_464eae18
    simon "Almost." id ep1_28_lily_sink_3a2b0526
    show ep1 wed_lilyhome_lily_difficult with d
    lily "Looks complicated." id ep1_28_lily_sink_75bf329d
    show ep1 wed_lilyhome_lily_close with d
    lily "Did you do this sort of thing often?" id ep1_28_lily_sink_d477afe9
    menu:
        "Check her out for a moment"(True):
            show ep1 wed_lilyhome_lily_checkher with d
            pause
            if chose('wine_lily'):
                show ep1 wed_lilyhome_lily_yourglass with d
                lily "Your glass is over there." id ep1_28_lily_sink_1a0d1bf2
            else:
                show ep1 wed_lilyhome_lily_yousure with d
                lily "Sure you don't want a glass?" id ep1_28_lily_sink_4a0c75ec
        "Not now":
            pass
    show ep1 wed_lilyhome_sink_clogged with d
    simon "Our sink used to get backed up all the time." id ep1_28_lily_sink_fdef1a2c
    if chose('wine_lily'):
        menu:
            "Drink wine"(True):
                show ep1 wed_lilyhome_simon_drink with d
                pause
                $ drank_wine = True
            "Hold off for now":
                $ drank_wine = False
                pass
    show ep1 wed_lilyhome_simon_done with d
    simon "There. All done." id ep1_28_lily_sink_b586306e
    show ep1 wed_lilyhome_lily_wait with d
    simon "Just have to wait until —" id ep1_28_lily_sink_58b615e2
    show ep1 wed_lilyhome_lily_cantwait with d
    lily "Can't wait to try it out!" id ep1_28_lily_sink_7f450592
    simon "Wait! You shouldn't —" id ep1_28_lily_sink_66276e3d


    play sound pipe_burst_sink volume 0.8
    stop music
    show ep1 wed_lilyhome_lily_splash with vpunch
    "*Splash.*" id ep1_28_lily_sink_6ccbac6e
    stop sound fadeout 1
    show ep1 wed_lilyhome_lily_tits with d
    play music so_good_instrumental volume 0.35
    simon "(Wow... They're gorgeous.)" id ep1_28_lily_sink_8a9eefa5
    show ep1 wed_lilyhome_simon_hard with d
    lily "(Whoa. He suddenly got rock hard. I wonder why —)" id ep1_28_lily_sink_ed7953c0
    show ep1 wed_lilyhome_lily_notices with d
    lily "Huh?" id ep1_28_lily_sink_5d350176
    show ep1 wed_lilyhome_lily_turnaround with d
    lily "I'll get you a towel. " id ep1_28_lily_sink_80c7b688
    show ep1 wed_lilyhome_lily_thinking with d
    lily "(Was that just because of my boobs?)" id ep1_28_lily_sink_9e127fde
    lily "(Either way, I've got to change.)" id ep1_28_lily_sink_52a8185b
    stop music fadeout 4
    show ep1 wed_lilyhome_simon_thinking with fade
    simon "(I think she saw my boner.)" id ep1_28_lily_sink_47a456aa
    simon "(Maybe she didn't mind since she's had a few glasses of wine.)" id ep1_28_lily_sink_a1a473d0
    show ep1 wed_lilyhome_simon_takinglong with wipedown
    simon "(Why is she taking so long?)" id ep1_28_lily_sink_ab5df3ca
    show ep1 wed_lilyhome_simon_lily with wipedown
    simon "Lily?" id ep1_28_lily_sink_d69575af
    simon "(Is something the matter?)" id ep1_28_lily_sink_371f4929
    show ep1 wed_lilyhome_lily_answer with fade
    play music confrontation volume 0.30
    lily "Come on. Answer..." id ep1_28_lily_sink_6c028756
    female_voice_at_phone "Hello?" id ep1_28_lily_sink_b8a0f243
    show ep1 wed_lilyhome_lily_who with d
    lily "Who's this?" id ep1_28_lily_sink_330ca524
    play sound phone_call_end
    show ep1 wed_lilyhome_lily_hungup with d
    lily "That bitch hung up on me." id ep1_28_lily_sink_9903de13
    lily "I'll try him again." id ep1_28_lily_sink_59a50bd8
    show ep1 wed_lilyhome_husband_hi with d
    mr_alderson "Sorry, Lily! That was my secretary." id ep1_28_lily_sink_7692229c
    show ep1 wed_lilyhome_lily_phone_angry with d
    lily "(Secretary. Right.)" id ep1_28_lily_sink_c63b7ec5
    mr_alderson "I'm still at the office, working on a few things." id ep1_28_lily_sink_92b9fe15
    show ep1 wed_lilyhome_lily_phone_talking with d
    lily "Is that so?" id ep1_28_lily_sink_dda22e10
    show ep1 wed_lilyhome_lily_phone_angry with d
    mr_alderson "It is. By the way, I might have to stay here a little longer." id ep1_28_lily_sink_474fc538
    show ep1 wed_lilyhome_lily_phone_talking with d
    lily "How much longer?" id ep1_28_lily_sink_f8c8fa52
    show ep1 wed_lilyhome_lily_phone_angry with d
    mr_alderson "Another week at the very least." id ep1_28_lily_sink_d1e0b050
    show ep1 wed_lilyhome_lily_phone_think with d
    lily "Okay. But I think you'd better reconsider your priorities." id ep1_28_lily_sink_41afbecc
    lily "By next week, I might not be around anymore." id ep1_28_lily_sink_8ca9cdef
    show ep1 wed_lilyhome_lily_hangsup with d
    mr_alderson "Lily, hold on. We can always —" id ep1_28_lily_sink_ee7d0c10
    stop music fadeout 2
    show ep1 wed_lilyhome_lily_wine with d
    "*Gulp.*" id ep1_28_lily_sink_0a1142e7
    show ep1 wed_lilyhome_lily_simon_spooked with vpunch
    lily "[name]! You startled me!" id ep1_28_lily_sink_369260a0
    show ep1 wed_lilyhome_simon_sorry with d
    simon "Sorry, I didn't want to interrupt. It's just that you were taking a while..." id ep1_28_lily_sink_1e1f64bb
    show ep1 wed_lilyhome_lily_onthephone with d
    lily "I was on the phone..." id ep1_28_lily_sink_031e162d
    show ep1 wed_lilyhome_simon_isee with d
    simon "I see." id ep1_28_lily_sink_00a2964c
    simon "Well, I'm not really that wet, so there's no need for a towel." id ep1_28_lily_sink_438a941b
    show ep1 wed_lilyhome_lily_silly with d
    lily "Don't be silly." id ep1_28_lily_sink_1875387b
    play music rain_heavy fadein 7 volume 0.25
    lily "You're going to catch a cold if you go home like that." id ep1_28_lily_sink_9505f51e

    show ep1 wed_lilyhome_lily_rain with d
    lily "Besides, it's starting to rain." id ep1_28_lily_sink_bf6e828f

    show ep1 wed_lilyhome_simon_walking with d
    lily "Well, you could use a towel, and..." id ep1_28_lily_sink_20437ef5
    show ep1 wed_lilyhome_lily_hearme with d
    lily "[name]? Are you hearing me? " id ep1_28_lily_sink_6f1f72c6
    show ep1 wed_lilyhome_simon_yeahsorry with d
    simon "Uh? Yeah, sorry." id ep1_28_lily_sink_48bbb3ef
    play sound thunder volume 0.7
    show ep1 wed_lilyhome_thunder with thunder
    pause 1

    show ep1 wed_lilyhome_lily_ohright with d
    lily "Oh... That's right..." id ep1_28_lily_sink_b232e328
    lily "(Susan told me about his accident.)" id ep1_28_lily_sink_a9644147
    show ep1 wed_lilyhome_lily_stay with d
    lily "You know what? Why don't you just stay here tonight?" id ep1_28_lily_sink_e117320e
    show ep1 wed_lilyhome_simon_really with d
    simon "Would that be okay?" id ep1_28_lily_sink_92f94ac2
    show ep1 wed_lilyhome_lily_stay with d
    lily "Well, not in here of course. You can stay in the guest room." id ep1_28_lily_sink_158d11fa
    show ep1 wed_lilyhome_lily_soak with d
    lily "But you're not going to sleep in those clothes." id ep1_28_lily_sink_4f2ec86e
    lily "You'd soak through the sheets if you did." id ep1_28_lily_sink_a03be025
    show ep1 wed_lilyhome_lily_clothes with d
    lily "Here. It's not like my husband is going to need these for the foreseeable future." id ep1_28_lily_sink_824303c4
    lily "You know what to do." id ep1_28_lily_sink_475d47cb
    stop music fadeout 2
    jump ep1_28b_lily_sexy
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
