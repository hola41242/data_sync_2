default susan_question1 = False
default susan_question2 = False
default susan_question3 = False

label ep1_09_clothestore:
    hide screen cellphone
    hide screen FR2_Mall
    show ep1 mon_mall_simon_walking with fade
    simon "(Turned out to be a much more eventful day than I thought it might be...)" id ep1_09_clothestore_3b317a88
    simon "(But now, I think it's time for me to head to Susan's store and have that talk with her.)" id ep1_09_clothestore_6730648d
    show ep1 mon_mall_simon_walking2 with d
    simon "(They mostly sell women's clothing here.)" id ep1_09_clothestore_fd0b8311
    simon "(I wonder what sort of job she has for me.)" id ep1_09_clothestore_01e9a8e1
    play sound door_shop_bell
    show ep1 mon_clothestore_empty with fade
    simon "(I don't see Susan.)" id ep1_09_clothestore_0ecb9947
    show ep1 mon_clothestore_lookaround with d
    simon "(Maybe I should look around for a bit.)" id ep1_09_clothestore_613a54df
    show ep1 mon_clothestore_sees_sue with d
    stop music fadeout 2
    simon "(Wait. Isn't that the girl from before?)" id ep1_09_clothestore_2f4dceac
    simon "(What is she doing here?)" id ep1_09_clothestore_975e9758
    show ep1 mon_clothestore_sue_sees_you with d
    simon "(Oh, shit. She saw me!)" id ep1_09_clothestore_9546aff8
    menu:
        "Say hello"(True):
            simon "Umm... Hello?" id ep1_09_clothestore_72693f56
            $ ep1_said_hi_sue = True
            $ player_choice("ep1_said_hi_sue:true")
        "Don't say anything":
            $ player_choice("ep1_said_hi_sue:false")
    show ep1 mon_clothestore_sue_looksaway with d
    play sound door_shop_bell_leftear volume 0.5
    ep1_clothestore_girl "..." id ep1_09_clothestore_8e0553d8


    play music lessons_learned fadein 2 volume 0.25
    show ep1 anim_susan_pan with d
    pause 14

    show ep1 mon_clothestore_susan_walksin_talks with d

    susan "Come now, Sue. Be nice to the boy." id ep1_09_clothestore_fc1fec4d
    show ep1 mon_clothestore_susan_walksin_silent with d
    simon "(That's Susan. I can tell from the picture.)" id ep1_09_clothestore_ff9e1668
    show ep1 mon_clothestore_susan_walksin_talks with d
    susan "Hi, you must be [name]. I'm Susan, and this is Sue." id ep1_09_clothestore_e44b49be
    show ep1 mon_clothestore_susan_angry with d
    simon "(Wow, is Sue her dau —)" id ep1_09_clothestore_4de08ec9
    show ep1 mon_clothestore_susan_angry_talks with d
    susan "And no, she's NOT my daughter!" id ep1_09_clothestore_2dd39fa1
    show ep1 mon_clothestore_susan_angry with d
    simon "(Shit! Did I say that out loud?!)" id ep1_09_clothestore_3a540acf
    show ep1 mon_clothestore_susan_pointsatsue with d
    susan "Sue is my niece." id ep1_09_clothestore_68c2df41
    show ep1 mon_clothestore_susan_walksin_silent with d
    simon "I-I'm [name]." id ep1_09_clothestore_a3dfee47
    show ep1 mon_clothestore_susan_walksin_talks with d
    susan "Yes, I'm well aware." id ep1_09_clothestore_be498208
    show ep1 mon_fanservice_susan1 with d
    susan "And you're early." id ep1_09_clothestore_8e0470f1
    simon "I had to grab some stuff for my room, so I decided to drop by and meet you before we officially began working together." id ep1_09_clothestore_dea89943
    susan "I see."
    susan "Good call." id ep1_09_clothestore_c1dfc483
    susan "It shows you're taking the job seriously at least." id ep1_09_clothestore_dc1fede6
    susan "Well done!" id ep1_09_clothestore_74802a82
    show ep1 mon_clothestore_susan_walksin_silent with d
    simon "(Careful, Susan. You might reveal a bit too much of yourself if you keep going like that.)" id ep1_09_clothestore_2423e58d
    show ep1 mon_clothestore_susan_walksin_talks with d
    susan "I should explain what the work entails." id ep1_09_clothestore_c8abb7e2
    show ep1 mon_fanservice_susan3 with d

    susan "First, you'll be working for me." id ep1_09_clothestore_55e38d08
    susan "Not for this store." id ep1_09_clothestore_4f1e70d8
    simon "I see." id ep1_09_clothestore_00a2964c
    susan "I've already discussed everything with Lily, so you don't have to worry about rent." id ep1_09_clothestore_50431c0d
    simon "(Are they friends or something?)" id ep1_09_clothestore_5f285df1
    show ep1 mon_fanservice_susan2 with d
    susan "Also, I'll have no set schedule for you." id ep1_09_clothestore_04156a5e
    show ep1 mon_fanservice_susan4 with d
    susan "You just need to be available to do a couple deliveries for me, okay?" id ep1_09_clothestore_1a116493
    susan "That's the most important part: I need someone trustworthy for these deliveries." id ep1_09_clothestore_36064f16
    susan "And your mother said you might need some help settling in." id ep1_09_clothestore_2b4c1e10
    susan "So I guess you're the perfect fit for the job." id ep1_09_clothestore_dfb8cafa
    show ep1 mon_clothestore_susan_b_question with d
    susan "Any questions?" id ep1_09_clothestore_0bf8ac17


    label ep1_09_clothestore_questions:


        show ep1 mon_clothestore_susan_b with d
        menu:
            "When do I start?"(True) if not chose_skip_debug('susan_question1'):
                simon "So, when do I start?" id ep1_09_clothestore_questions_0b84250e
                show ep1 mon_clothestore_susan_b_talks with d
                susan "Don't worry. I'll text you when I need you." id ep1_09_clothestore_questions_f83cd4e2
                show ep1 mon_clothestore_susan_b_talks2 with d
                susan "Of course, it won't be urgent or anything. Just have a look at your phone from time to time." id ep1_09_clothestore_questions_0b059ad9
                $ susan_question1 = True
                jump ep1_09_clothestore_questions
            "So, this job is paying for my rent?"(True) if not chose_skip_debug('susan_question2'):
                simon "So, working for you pays my rent. Is that right?" id ep1_09_clothestore_questions_d6faaade
                show ep1 mon_clothestore_susan_b_talks2 with d
                susan "Right. You won't have to worry about rent. Plus, I might throw you a small bonus depending on the delivery." id ep1_09_clothestore_questions_d07f94d1
                $ susan_question2 = True
                jump ep1_09_clothestore_questions
            "How do you know my mother?"(True) if not chose_skip_debug('susan_question3'):
                simon "How do you and my mother know each other?" id ep1_09_clothestore_questions_539e0f58
                show ep1 mon_clothestore_susan_b_talks with d
                susan "We were friends back where you lived." id ep1_09_clothestore_questions_8b0b7cb1
                susan "Then one day, I moved out here." id ep1_09_clothestore_questions_b29ce848
                show ep1 mon_clothestore_susan_b with d
                simon "Then you two aren't friends anymore?" id ep1_09_clothestore_questions_5c0d2fa2
                show ep1 mon_clothestore_susan_b_complicated with d
                susan "It's complicated..." id ep1_09_clothestore_questions_15b6e15b
                show ep1 mon_clothestore_susan_b with d
                simon "What about my father? Did you know him too?" id ep1_09_clothestore_questions_6bed6f8b
                show ep1 mon_clothestore_susan_b_talks with d
                susan "We've met, but I can't say I knew him." id ep1_09_clothestore_questions_b2450cd9
                show ep1 mon_clothestore_susan_b with d
                simon "(You and me both, sister...)" id ep1_09_clothestore_questions_35b41537
                show ep1 mon_clothestore_susan_b_surprised with d
                simon "This is you in this picture, right?" id ep1_09_clothestore_questions_2a318703
                show ep1 mon_clothestore_susan_b_photo_talks with d
                susan "Where'd you get that?" id ep1_09_clothestore_questions_6d71a09e
                show ep1 mon_clothestore_susan_b_photo with d
                simon "My mother gave it to me so I could recognize you." id ep1_09_clothestore_questions_aad4799e
                simon "She told me you aren't on social media, so it was really hard to find a photo of you." id ep1_09_clothestore_questions_be19a7b4
                show ep1 mon_clothestore_susan_b_photo_talks with d
                susan "I see."
                susan "That was taken a long time ago." id ep1_09_clothestore_questions_1a4a322c
                show ep1 mon_clothestore_susan_b_photo with d
                simon "Who was in the other half of the picture? Was it my mom?" id ep1_09_clothestore_questions_188e3e9c
                show ep1 mon_clothestore_susan_b_photo_asks with d
                susan "Didn't you ask her that question?" id ep1_09_clothestore_questions_4a999ff0
                show ep1 mon_clothestore_susan_b_photo with d
                simon "I did not." id ep1_09_clothestore_questions_e6096831
                show ep1 mon_clothestore_susan_b_photo_asks with d
                susan "I think it'd be better if you heard that from her." id ep1_09_clothestore_questions_63b9ec1a
                $ susan_question3 = True
                jump ep1_09_clothestore_questions
            "No more questions":
                simon "Got it." id ep1_09_clothestore_questions_e1a84c4c

    show ep1 mon_clothestore_susan_b_sueworks with d
    susan "Oh, and last but not least, Sue works for me as well." id ep1_09_clothestore_questions_197b48ca
    show ep1 mon_clothestore_susan_b_suelooks with d
    sue "..." id ep1_09_clothestore_questions_65c614fe
    susan "So, the two of you may have to work together if the occasion calls for it." id ep1_09_clothestore_questions_12fb9301
    show ep1 mon_clothestore_susan_b with d
    simon "Understood. Well, I should be going then." id ep1_09_clothestore_questions_440860a6
    simon "It was nice to meet you both." id ep1_09_clothestore_questions_55f2576f
    show ep1 mon_clothestore_susan_b_talks with d
    susan "Likewise." id ep1_09_clothestore_questions_b8c661a3
    stop music fadeout 4
    show ep1 mon_clothestore_simonleaves with d
    pause

    jump ep1_10_home_afterstore
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
