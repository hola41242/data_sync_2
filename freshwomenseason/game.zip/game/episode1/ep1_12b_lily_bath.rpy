label ep1_12b_lily_bath:
    hide screen FR2_Mall
    scene ep1 mon_lilyhome_bathroom_big with long_fade
    simon "(This bathroom is bigger than my studio!)" id ep1_12b_lily_bath_032fbf8a
    simon "(I could live in here.)" id ep1_12b_lily_bath_7c966659
    play sound bathtub_filling volume 0.1 fadein 2 loop
    show ep1 mon_lilyhome_bathroom_shower with wipeup
    simon "(But for now, I guess I'll just enjoy a hot bath.)" id ep1_12b_lily_bath_e75b2c14
    show ep1 mon_lilyhome_bathroom_simonwonder with d
    simon "(Lily seems lonely...)" id ep1_12b_lily_bath_f84282e9
    simon "(... I wonder if she sometimes comes in here for a little fun...)" id ep1_12b_lily_bath_a37623e5
    play music sexy_time volume 0.5 fadein 4
    show ep1 mon_lilyhome_bathroom_lily3 with long_fade
    simon "(She could be a full ten years older than me...)" id ep1_12b_lily_bath_9ad0d139
    show ep1 mon_lilyhome_bathroom_lily4 with long_fade
    simon "(... But her beautiful skin still glows with youthful radiance...)" id ep1_12b_lily_bath_53255ff2

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_03_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_03_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_03 with long_fade
    simon "(... So soft and supple...)" id ep1_12b_lily_bath_2058ca11
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_02_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_02_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_02 with long_fade
    simon "(... She probably rubs a whole line of beauty products all over her body...)" id ep1_12b_lily_bath_7d5a8c89
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_02_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_02_var1_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_02_var1 with long_fade
    simon "(... Lily is so gorgeous...)" id ep1_12b_lily_bath_8f80dc09
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_01_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_01_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_01 with long_fade
    simon "(... She really knows how to take care of herself and stay in shape...)" id ep1_12b_lily_bath_bd1c05de
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_01_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_01_var1_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_01_var1 with long_fade
    simon "(She might be a little cold at times, but I can tell she has a warm soul...)" id ep1_12b_lily_bath_0418f1c1
    pause

    stop foley
    stop voicefx
    show ep1 mon_lilyhome_bathroom_lily7 with long_fade
    simon "(... And most of all...)" id ep1_12b_lily_bath_98148d50
    simon "(...She knows how to...)" id ep1_12b_lily_bath_d3623d18
    stop music
    stop sound
    show ep1 mon_lilyhome_lily_knockingdoor with None

    play sound knock_door_4_times
    lily "*Knock, knock.* [name], are you almost done in there?" id ep1_12b_lily_bath_1b41b210
    show ep1 mon_lilyhome_lily_knockingdoor_listens with d
    simon "Yes! I'm coming! Shit! I mean... Yeah, I'll just be another minute or two!" id ep1_12b_lily_bath_d2bb334a
    show ep1 mon_lilyhome_lily_knockingdoor_leaves with d
    lily "Don't take too long, all right?" id ep1_12b_lily_bath_ba52ad06
    $ renpy.end_replay()
    show ep1 mon_lilyhome_bathroom_end with fade
    simon "(Well, that was a nice bath.)" id ep1_12b_lily_bath_53a2c966

    jump ep1_12c_lily_kitchen
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
