label ep1_12_lilyhome:
    show ep1 mon_lilyhome_house with long_fade
    simon "Whoa! Her house is huge!" id ep1_12_lilyhome_038dd7c8
    show ep1 mon_lilyhome_simonthinks with d
    simon "I hope her husband isn't home." id ep1_12_lilyhome_60fd7131
    simon "He might not be in a good mood, based on how Lily was talking before." id ep1_12_lilyhome_e7c1a7b1
    show ep1 mon_lilyhome_lightson with d
    simon "The lights are on, so she's probably still up." id ep1_12_lilyhome_f51f01b2
    show ep1 mon_lilyhome_doorbell with d
    play sound intercom_ring
    pause
    play sound phone_receive_unhook
    show ep1 mon_lilyhome_intercomm_lily with d
    lily "Hello?" id ep1_12_lilyhome_d3830112
    show ep1 mon_lilyhome_intercomm_simon with d
    if chose('callsher_lily'):
        simon "Hey, Lily. It's me, [name]." id ep1_12_lilyhome_30ac70b5
    else:
        simon "Hello, Mrs. Alderson. It's me, [name]." id ep1_12_lilyhome_aeeeb2a0
    show ep1 mon_lilyhome_intercomm_lily with d
    lily "[name]? Is something the matter?" id ep1_12_lilyhome_0e198ca6

    show ep1 mon_lilyhome_intercomm_simon with d
    simon "May I come in?" id ep1_12_lilyhome_98d20e04
    show ep1 mon_lilyhome_intercomm_lily with d
    lily "Do you know what time it is?" id ep1_12_lilyhome_bfe980ba
    simon "..."
    lily "Well, can't just leave you out there in the cold."
    play sound gate_open volume 0.8
    show ep1 mon_lilyhome_entrance_opengate with d
    lily "Come in." id ep1_12_lilyhome_c2e37b93
    show ep1 mon_lilyhome_entrance_entering with d
    pause
    play sound opening_door_1 volume 0.8
    show ep1 mon_lilyhome_entrance_lily_opensdoor with fade
    play music stunned_man volume 0.25
    lily "So? Is there something wrong with your room?" id ep1_12_lilyhome_19fbca2f
    show ep1 mon_lilyhome_entrance_lily_silent with d
    simon "No, it's nothing like that. I just realized I forgot to buy a towel."
    simon "And I was wondering if I could borrow one from you." id ep1_12_lilyhome_2a956a87
    menu:
        "Joke"(True):
            simon "You'll get it back. It's not like you don't know where I live." id ep1_12_lilyhome_b19e9fe2
            $ points_lily += 1
        "Don't joke":
            pass
    show ep1 mon_lilyhome_ent_simontowel with d
    simon "I'll make sure to wash it and bring it back tomorrow." id ep1_12_lilyhome_e5b19bd1
    show ep1 mon_lilyhome_ent_nope with d
    lily "I can't let you just walk off with one of my nice towels." id ep1_12_lilyhome_e9aa306c
    show ep1 mon_lilyhome_entrance_lily_thinks with d
    lily "But I guess I did promise Susan I'd look out for you, so..." id ep1_12_lilyhome_7dffcd01
    show ep1 mon_lilyhome_entrance_lily_deepbreath with d
    lily "You may use my bathroom." id ep1_12_lilyhome_fa6c2169
    show ep1 mon_lilyhome_entrance_lily_borrow with d
    lily "I also wouldn't mind letting you borrow some of my husband's clothes if you need them." id ep1_12_lilyhome_a0a8db7c
    show ep1 mon_lilyhome_entrance_simonask with d
    if chose('lily_husband'):
        simon "Are you sure that's okay?" id ep1_12_lilyhome_66beb161
        simon "I couldn't help but notice you didn't seem too happy talking about him earlier." id ep1_12_lilyhome_9f52392c
        show ep1 mon_lilyhome_entrance_lily_deepbreath with d
        lily "Don't worry. He's not even home." id ep1_12_lilyhome_a1a0f7ff
        simon "Sorry about that by the way. I tend to ask too many questions." id ep1_12_lilyhome_3bee7441
        show ep1 mon_lilyhome_entrance_lily_borrow with d
        lily "It's okay." id ep1_12_lilyhome_158f96f9
        lily "Susan warned me you'd be like that." id ep1_12_lilyhome_56d6cb16
        simon "Are you two friends?" id ep1_12_lilyhome_1a3fde5f
        lily "She used to work with my husband." id ep1_12_lilyhome_82a4f8f9
        lily "But enough talk." id ep1_12_lilyhome_0fe35b68
        $ connections_mraldersonsusan = True
        $ player_choice("connections_mraldersonsusan:true")
    else:
        $ player_choice("connections_mraldersonsusan:false")
        simon "Will he be okay with that?" id ep1_12_lilyhome_44f3c531
        show ep1 mon_lilyhome_entrance_lily_scoffs with d
        lily "Who cares? He isn't even home." id ep1_12_lilyhome_4b29dee0
        lily "You can keep them for all I care." id ep1_12_lilyhome_8f447517
        show ep1 mon_lilyhome_entrance_simonask with d
        simon "..."
        show ep1 mon_lilyhome_entrance_lily_wontknow with d
        lily "Stop worrying. He won't even notice." id ep1_12_lilyhome_ba9c55e3
        if chose('callsher_lily'):
            simon "Thanks. I appreciate it, Lily." id ep1_12_lilyhome_7025757e
        else:
            simon "Thanks. I appreciate it, Mrs. Alderson." id ep1_12_lilyhome_09521c87
            lily "It's Lily." id ep1_12_lilyhome_35639667
    show ep1 mon_lilyhome_enter with d
    lily "Come. The bathroom's upstairs. I'll go get you some clothes." id ep1_12_lilyhome_af8ef5d1
    show ep1 mon_lilyhome_enter2 with d
    stop music fadeout 4
    lily "You'll find everything you need in there." id ep1_12_lilyhome_a6f41627
    lily "I'll finish my yoga session while you're doing you're thing." id ep1_12_lilyhome_c851f256

    jump ep1_12b_lily_bath
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
