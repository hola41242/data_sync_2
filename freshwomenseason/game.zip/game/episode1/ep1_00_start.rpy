
label start:
    $ quick_menu = False
    jump ep1_01_the_fancy_home
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
