label ep1_25_sue_beach:
    if not renpy.emscripten:
        $ renpy.block_rollback()
    hide screen ep1_fr_bh_multi_suitcaseroom
    hide screen cellphone
    scene ep1 wed_beach_simon_heavycase with d
    simon "(This is one heavy ass suitcase...)" id ep1_25_sue_beach_392c53b4
    simon "(I should bring it to Sue.)" id ep1_25_sue_beach_0aa6b7dc
    show ep1 wed_beach_sue_beach with wipeleft
    play music cowboy_junkies volume 0.35
    simon "No fucking way." id ep1_25_sue_beach_6cbcc3dd
    show ep1 wed_beach_sue_close with d
    menu:
        "Check her out a little"(True):
            show ep1 wed_beach_sue_beach_check with d
            pause
        "Compliment her":
            simon "Looking good, Sue." id ep1_25_sue_beach_8e03ab79
        "Don't do anything":
            pass
    show ep1 wed_beach_sue_view with d
    sue "Enjoying the view?" id ep1_25_sue_beach_39921fd3
    show ep1 wed_beach_simon_shethere with d
    simon "You didn't tell me your aunt was going to be in there!" id ep1_25_sue_beach_f903c8bd

    show ep1 wed_beach_sue_what with d
    sue "What?" id ep1_25_sue_beach_8e903214
    sue "Did she catch you?!" id ep1_25_sue_beach_e9ac7f5b
    show ep1 wed_beach_simon_youdknow with d
    simon "You would know the answer to that if you were actually keeping an eye out." id ep1_25_sue_beach_1f743345
    show ep1 wed_beach_sue_intown with d
    sue "I thought she was at her place in town." id ep1_25_sue_beach_4ce55b17
    show ep1 wed_beach_sue_gotcase with d
    sue "At least you got the suitcase." id ep1_25_sue_beach_b78e3ce0
    simon "Yeah. No thanks to you." id ep1_25_sue_beach_c43302cb
    simon "And no, she didn't see me." id ep1_25_sue_beach_ecbcbc97
    show ep1 wed_beach_sue_badass with d
    sue "Really?" id ep1_25_sue_beach_1a230ce6

    sue "That's kind of badass." id ep1_25_sue_beach_0758308c
    show ep1 wed_beach_sue_findout with d
    sue "So, what did you find out?" id ep1_25_sue_beach_9aa2d3d0
    show ep1 wed_beach_simon_sue_nothing with d
    simon "Nothing. She's completely clean." id ep1_25_sue_beach_8f6f507e
    simon "I mean... maybe too clean." id ep1_25_sue_beach_944a8dbc
    simon "There was a picture frame with no picture in it though." id ep1_25_sue_beach_d3193355
    stop music fadeout 4
    show ep1 wed_beach_simon_hiding with d
    simon "It does seem... like she's hiding something..." id ep1_25_sue_beach_69f8b0a3
    show ep1 wed_beach_sue_getit with d
    sue "Now you're feeling me." id ep1_25_sue_beach_53062fb8
    simon "Anyway, what now?" id ep1_25_sue_beach_ad6a05b9
    show ep1 wed_beach_sue_leave with d
    sue "Now we'll get you home." id ep1_25_sue_beach_5c383e42
    sue "But this is far from over." id ep1_25_sue_beach_f2e2808d
    show ep1 wed_beach_sue_eyeonher with d
    sue "Will you keep an eye on her for me?" id ep1_25_sue_beach_ee9ec02a
    menu:
        "Fine, I'll keep an eye on her"(True):
            simon "Sure." id ep1_25_sue_beach_2eac89ff
            $ ep1_agree_help_sue = True
            $ player_choice("ep1_agree_help_sue:true")
            sue "Good." id ep1_25_sue_beach_a8ec8438
        "No, I won't":
            $ player_choice("ep1_agree_help_sue:false")
            simon "I don't think so, Sue. Sounds risky." id ep1_25_sue_beach_296638cf
            sue "Don't be a pussy." id ep1_25_sue_beach_3b1a2796
            sue "I'll give you some time to think it over." id ep1_25_sue_beach_eaccdcee
        "Maybe":
            $ player_choice("ep1_agree_help_sue:false")
            simon "Let me think about it, okay?" id ep1_25_sue_beach_bcb1ddc0
            sue "Fine. But don't take too long." id ep1_25_sue_beach_9f9c2d57

    jump ep1_26_back_home
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
