label ep1_23_roadtrip_sue:
    show ep1 wed_simonhome_sue_princess with long_fade
    sue "Finally make it down, princess?" id ep1_23_roadtrip_sue_3a77355c
    simon "My god, it's so early!" id ep1_23_roadtrip_sue_e27754b7
    sue "Get in." id ep1_23_roadtrip_sue_1dbec0c6
    show ep1 wed_simonhome_sue_coffee with d
    sue "Here. I went ahead and got you a coffee." id ep1_23_roadtrip_sue_7f291a99
    menu:
        "Thanks"(True):
            simon "Thanks, Sue." id ep1_23_roadtrip_sue_1b5715b2
            sue "Don't worry about it." id ep1_23_roadtrip_sue_4e025db4
            $ points_sue += 1
        "Say nothing":
            pass
    sue "... Just don't spill it." id ep1_23_roadtrip_sue_db4c32b1

    play sound car_start volume 0.2
    show ep1 wed_suecar_sue_so with wiperight
    play music reckless volume 0.15

    sue "So..." id ep1_23_roadtrip_sue_9edd8db8
    sue "Auntie and your mother are friends, right?" id ep1_23_roadtrip_sue_c0c3b833

    show ep1 wed_suecar_simon_mom with d
    simon "Yeah, I just don't know how they met." id ep1_23_roadtrip_sue_5bc23eba
    simon "My mother didn't say much, but they must be on friendly enough terms for your aunt to give me a job." id ep1_23_roadtrip_sue_d830e9d1
    show ep1 wed_suecar_sue_susan with d
    sue "Nobody knows much about Auntie Susan." id ep1_23_roadtrip_sue_b48d2908
    show ep1 wed_suecar_simon_speaks with d
    simon "Not even you?" id ep1_23_roadtrip_sue_5f5205ba
    show ep1 wed_suecar_sue_speaks with d
    sue "Not even me, and it drives me crazy." id ep1_23_roadtrip_sue_1a7650ec
    show ep1 wed_suecar_simon_speaks with d
    simon "I thought the two of you were close." id ep1_23_roadtrip_sue_ae40ca22
    show ep1 wed_suecar_sue_speaks with d
    sue "We are." id ep1_23_roadtrip_sue_96908c5e
    sue "... I guess." id ep1_23_roadtrip_sue_dd2ba6ee
    show ep1 wed_suecar_simon_what with d
    simon "What is it you want to know then?" id ep1_23_roadtrip_sue_91206800
    show ep1 wed_suecar_sue_herdeal with d
    sue "I want to know what her deal is." id ep1_23_roadtrip_sue_77029ac6
    sue "She's hiding something. I can tell." id ep1_23_roadtrip_sue_107a5b44
    show ep1 wed_suecar_simon_speaks with d
    simon "Can't you just ask her?" id ep1_23_roadtrip_sue_cf46d062
    show ep1 wed_suecar_sue_freak with d
    sue "And say what? Hey, auntie, I think you're a freak. What are you hiding?" id ep1_23_roadtrip_sue_bdae063b
    show ep1 wed_suecar_simon_alternative with d
    simon "Okay. So is there an alternative?" id ep1_23_roadtrip_sue_2eb04e98
    sue "Auntie isn't exactly an open book." id ep1_23_roadtrip_sue_11461ad7
    show ep1 wed_suecar_sue_driving with d
    menu:
        "Tell her about the magazine"(True):
            show ep1 wed_suecar_simon_speaks with d
            simon "I saw her on the cover of a business magazine." id ep1_23_roadtrip_sue_cc7858fe
            show ep1 wed_suecar_sue_speaks with d
            sue "Auntie Susan?" id ep1_23_roadtrip_sue_29944d25
            show ep1 wed_suecar_simon_speaks with d
            simon "Yeah. It was an old magazine I found at the library on campus." id ep1_23_roadtrip_sue_facb7d91
            show ep1 wed_suecar_sue_speaks with d
            sue "And what did it say about her?" id ep1_23_roadtrip_sue_4a98cbbe
            show ep1 wed_suecar_simon_speaks with d
            simon "To be honest, not much." id ep1_23_roadtrip_sue_25b6fa2e
            simon "But my friend said the magazine was a big deal among the rich and powerful in this town." id ep1_23_roadtrip_sue_bf993e82
            $ ep1_told_sue_magazine = True
            $ player_choice("ep1_told_sue_magazine:true")
            $ points_sue += 1
        "Don't tell her":
            $ player_choice("ep1_told_sue_magazine:false")
    show ep1 wed_suecar_sue_speaks with d
    sue "All I know is that she built her business from the ground up." id ep1_23_roadtrip_sue_43d47e5c
    sue "All by herself." id ep1_23_roadtrip_sue_fc19738c
    show ep1 wed_suecar_simon_speaks with d
    stop music fadeout 2
    simon "Is she on your father's side or your mother's?" id ep1_23_roadtrip_sue_f68a698f
    show ep1 wed_suecar_sue_speaks with d
    sue "Neither." id ep1_23_roadtrip_sue_789d1ff2
    play music iguana_americana fadein 2 volume 0.2
    sue "She married my father's brother, Uncle Charlie." id ep1_23_roadtrip_sue_f7868798
    sue "He passed away a year ago." id ep1_23_roadtrip_sue_e5152130
    sue "It was a car crash." id ep1_23_roadtrip_sue_d8927d71
    show ep1 wed_suecar_sue_sad with d
    sue "We were real close." id ep1_23_roadtrip_sue_666c9b85
    sue "I used to hang out at their place a lot when I was younger." id ep1_23_roadtrip_sue_76be3dee
    show ep1 wed_suecar_sue_sad2 with d
    sue "I guess that's why she still keeps me around." id ep1_23_roadtrip_sue_8f74171e
    show ep1 wed_suecar_sue_sad3 with d
    sue "We both remind each other of him." id ep1_23_roadtrip_sue_4645f4c6
    show ep1 wed_suecar_simon_looksatsue with d
    simon "(Whoa. She seems like a totally different person all of a sudden!)" id ep1_23_roadtrip_sue_59a24832
    show ep1 wed_suecar_sue_sentimental with d
    sue "What are you looking at?!" id ep1_23_roadtrip_sue_6e468f7e
    sue "I just told you what you wanted to know. Don't get all sentimental on me." id ep1_23_roadtrip_sue_61b1b771
    show ep1 wed_suecar_sue_reason with d
    sue "Also, I'm telling you all this for a reason." id ep1_23_roadtrip_sue_e21dc831
    simon "Oh. Why's that?" id ep1_23_roadtrip_sue_ab9fdf82
    show ep1 wed_suecar_sue_keepaneye with d
    sue "I want you to keep an eye on her." id ep1_23_roadtrip_sue_a450bf36
    simon "And look for what exactly?" id ep1_23_roadtrip_sue_9cdd55b3
    show ep1 wed_suecar_sue_strange with d
    sue "I don't know. Anything strange." id ep1_23_roadtrip_sue_50f5f8e2
    show ep1 wed_suecar_sue_keepaneye with d
    sue "Just don't do anything dumb." id ep1_23_roadtrip_sue_2f974cac
    stop music fadeout 2
    sue "If she finds out, you're a dead man." id ep1_23_roadtrip_sue_42cda1b5

    jump ep1_24_bhfr
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
