label ep1_24_bhfr:
    show ep1 wed_beach_sue_here with long_fade
    sue "We're here." id ep1_24_bhfr_15f612b1
    play sound open_car_door volume 0.6
    show ep1 wed_beach_sue_the_beach_house with d
    sue "The Beach House." id ep1_24_bhfr_fb684943
    play sound keys_jangling volume 0.6
    show ep1 wed_beach_sue_takethese with d
    play music boom volume 0.15

    sue "Here." id ep1_24_bhfr_be1ad0f5
    sue "Take these." id ep1_24_bhfr_c747180c
    simon "You aren't coming in?" id ep1_24_bhfr_e4e04d35
    show ep1 wed_beach_sue_keepeye with d
    sue "I'll stay here and keep an eye out." id ep1_24_bhfr_5c5e1a6f
    show ep1 wed_beach_simon_behere with d
    simon "Keep an eye out? Are we not supposed to be in there?" id ep1_24_bhfr_779c70a5
    show ep1 wed_beach_sue_suitcase with d
    sue "We're fine. She asked me to get her suitcase for her." id ep1_24_bhfr_9b7de9c1
    sue "You'll see it as soon as you go inside." id ep1_24_bhfr_a5d68fd6
    simon "Then why don't you do it?" id ep1_24_bhfr_ff44d54b
    show ep1 wed_beach_sue_bitching with d
    sue "Quit your bitching." id ep1_24_bhfr_b4c9cfe2
    sue "I don't want auntie to find me snooping around her place." id ep1_24_bhfr_4f8e6aa0
    show ep1 wed_beach_simon_getcaught with d
    simon "What if I get caught?" id ep1_24_bhfr_ae0d338d
    show ep1 wed_beach_sue_younew with d
    sue "Then you can just say you got lost since it's your first time inside." id ep1_24_bhfr_3c2bbf94
    simon "Fine." id ep1_24_bhfr_2eac89ff
    show ep1 wed_beach_simon_betterbe with d
    simon "But there'd better be something in it for me." id ep1_24_bhfr_3288536e
    show ep1 wed_beach_sue_justgo with d
    sue "Shut up and go inside." id ep1_24_bhfr_1846a75c
    simon "Jesus, fine." id ep1_24_bhfr_43a2e989

    if renpy.emscripten:
        jump ep1_25_sue_beach
    else:
        jump ep1_fr_bh
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
