
label ep1_21_wakeup_sue:
    stop music fadeout 2
    play sound morning_birds fadein 1
    show ep1 wed_simonhome_morning with longest_dissolve
    pause
    show ep1 wed_simonhome_voice with long_fade
    play sound knock_knock
    pause 0.5

    sue_secret "[name]..."
    simon "Huh?" id ep1_21_wakeup_sue_196da51b

    sue_secret "[name]..."
    show ep1 wed_simonhome_simonlooks with Dissolve(1.5)
    simon "(Someone's calling my name...)" id ep1_21_wakeup_sue_8ff2a322
    simon "(... Sounds like Susan.)" id ep1_21_wakeup_sue_b3b846ce
    sue_secret "Get up, dipshit!" (what_bold=True)
    simon "(What the fuck?!)" id ep1_21_wakeup_sue_b60b8e57
    show ep1 wed_simonhome_simonup with d
    menu:
        "Who is it?"(True):
            sue "It's Sue." id ep1_21_wakeup_sue_7e5ac2a4
            sue "Get dressed. Time to go!" id ep1_21_wakeup_sue_d08f019c
        "Shut up!":
            sue_secret "..." id ep1_21_wakeup_sue_8fd40146
            sue_secret "Just open the damn door." id ep1_21_wakeup_sue_458182a4
    play sound opening_door_1
    show ep1 wed_simonhome_sue with d
    play music morning_rise volume 0.25
    simon "Sue?!" id ep1_21_wakeup_sue_194c14fb
    simon "(She speaks!)" id ep1_21_wakeup_sue_a14c8167
    simon "(And she sounds just like Susan!)" id ep1_21_wakeup_sue_5f9c298f
    simon "(... Uncanny.)" id ep1_21_wakeup_sue_e29bc329
    show ep1 wed_simonhome_sue_auntie with d
    sue "C'mon, auntie has a job for you." id ep1_21_wakeup_sue_9dbe2df7
    menu:
        "Make fun of her for saying 'auntie'":
            simon "(Auntie, huh? All right. Haha.)" id ep1_21_wakeup_sue_405538d5
        "Ignore it"(True):
            $ points_sue += 1
    show ep1 wed_simonhome_sue_silent with d
    simon "Didn't she say she'd let me know in advance?" id ep1_21_wakeup_sue_35d8aec5
    show ep1 wed_simonhome_sue_speaks with d
    sue "Consider me being here her letting you know in advance." id ep1_21_wakeup_sue_79518088
    simon "(What a bitch!)" id ep1_21_wakeup_sue_333139ad
    show ep1 wed_simonhome_sue_trip with d
    sue "Get your things. We're going on a little trip." id ep1_21_wakeup_sue_f93bed95
    simon "A trip? I have to be back by tonight though." id ep1_21_wakeup_sue_26863a89
    show ep1 wed_simonhome_sue_angry with d
    sue "You think I don't have anything better to do?" id ep1_21_wakeup_sue_5e232099
    sue "Of course we'll be back before then." id ep1_21_wakeup_sue_9265f54e
    show ep1 wed_simonhome_sue_silent with d
    simon "All right then..." id ep1_21_wakeup_sue_d6d7dac6
    show ep1 wed_simonhome_whereto with d
    simon "Where are we going?" id ep1_21_wakeup_sue_fcfd943e
    sue "To The Beach House." id ep1_21_wakeup_sue_8f1c5c35
    show ep1 wed_simonhome_bhouse with d
    simon "A beach house?" id ep1_21_wakeup_sue_b4fb1950
    show ep1 wed_simonhome_sue_beachhouse with d
    sue "Not a beach house. The Beach House." id ep1_21_wakeup_sue_0c39c50c
    sue "It belongs to Auntie Susan." id ep1_21_wakeup_sue_9c8e52b0
    sue "She needs us to fetch her something." id ep1_21_wakeup_sue_44ab7638
    show ep1 wed_simonhome_needyou with d
    simon "You mean, she needs you to fetch her something." id ep1_21_wakeup_sue_76152e89
    show ep1 wed_simonhome_youcoming with d
    sue "You work for us now, smartass." id ep1_21_wakeup_sue_6917fc92
    sue "So, you're coming with me." id ep1_21_wakeup_sue_b43f895a
    show ep1 wed_simonhome_gotit with d
    simon "Okay. I got you." id ep1_21_wakeup_sue_79b1262b
    simon "The thing is... I just woke up." id ep1_21_wakeup_sue_4364061d
    show ep1 wed_simonhome_sue_leaving with d
    sue "Yeah, yeah. We'll get you some coffee to go." id ep1_21_wakeup_sue_6e2f54bd
    sue "I'll be waiting downstairs." id ep1_21_wakeup_sue_382640fe
    stop music fadeout 4
    sue "Don't take too long." id ep1_21_wakeup_sue_b4bb58b8
    jump ep1_22_chloe_call
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
