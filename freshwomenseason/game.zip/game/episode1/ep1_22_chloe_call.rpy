label ep1_22_chloe_call:
    play sound phone_vibrating volume 0.4
    show ep1 wed_simonhome_phone_ringing with d
    phone "*Bzzzt.*" id ep1_22_chloe_call_7cf5384a
    stop sound fadeout 0.5
    show ep1 wed_simonhome_phone_hello with d
    play music happy_before_we_get_old volume 0.25
    simon "Hello?" id ep1_22_chloe_call_c2baa3e3
    show ep1 wed_chloeroom_chloe_hey with d
    chloe "Hey, [name]!" id ep1_22_chloe_call_add77a1c
    chloe "Sorry for calling this early." id ep1_22_chloe_call_7565b6ce
    show ep1 wed_chloeroom_chloe_question with d
    chloe "Did I wake you?" id ep1_22_chloe_call_9b342b33
    menu:
        "No, you didn't"(True):
            show ep1 wed_chloeroom_chloe_silent with d
            simon "Nope. Don't worry." id ep1_22_chloe_call_20b6afdc
            show ep1 wed_chloeroom_chloe_speaks with d
            chloe "Oh, that's a relief!" id ep1_22_chloe_call_87465454
            $ points_chloe += 1
        "No, some other girl did":
            show ep1 wed_chloeroom_chloe_silent with d
            simon "You didn't." id ep1_22_chloe_call_a7d458b7
            simon "But someone else did." id ep1_22_chloe_call_5a9a092d
            show ep1 wed_chloeroom_chloe_speaks with d
            chloe "A roommate?" id ep1_22_chloe_call_ce81ef33
            show ep1 wed_chloeroom_chloe_silent with d
            simon "No. Just this girl from work." id ep1_22_chloe_call_650f36d5
            show ep1 wed_chloeroom_chloe_sad_speaks with d
            chloe "Oh..." id ep1_22_chloe_call_73d1596b
            show ep1 wed_chloeroom_chloe_silent with d
            simon "It's not like that. I —" id ep1_22_chloe_call_8663775d
            show ep1 wed_chloeroom_chloe_speaks with d
            chloe "No worries." id ep1_22_chloe_call_d79bcc31
            $ ep1_chloe_sue = True

    show ep1 wed_chloeroom_chloe_speaks with d
    chloe "So, hey. I wanted to talk to you about something." id ep1_22_chloe_call_297a8b97
    show ep1 wed_chloeroom_chloe_silent with d
    simon "Yeah?" id ep1_22_chloe_call_34bf1b87
    show ep1 wed_chloeroom_chloe_speaks with d
    chloe "I was just about to do some digging, but I thought we should talk about it first." id ep1_22_chloe_call_49490e78
    chloe "You wanted me to find your father, right?" id ep1_22_chloe_call_441ec8e0
    show ep1 wed_chloeroom_chloe_silent with d
    simon "Yeah!" id ep1_22_chloe_call_ebe895b3
    show ep1 wed_chloeroom_chloe_concerned_speaks with d
    chloe "From my calculations, he's been missing for about thirteen years..." id ep1_22_chloe_call_8040a74e
    chloe "I want to help, but I also want you to know that —" id ep1_22_chloe_call_96bc1cce
    show ep1 wed_simonhome_phone_iknow with d
    simon "I know." id ep1_22_chloe_call_9b6cd65a
    simon "We don't have a great chance of finding him." id ep1_22_chloe_call_d58e03be
    show ep1 wed_chloeroom_chloe_silent with d
    simon "I just want to know what happened." id ep1_22_chloe_call_81de7643
    simon "But if you're not up to the task anymore, I understand." id ep1_22_chloe_call_160836b5
    show ep1 wed_chloeroom_chloe_happy_speaks with d
    chloe "What? Of course I am." id ep1_22_chloe_call_e9f9374f
    chloe "Don't worry about that. I'm on the case." id ep1_22_chloe_call_0e6964a5
    chloe "I'll have more information for you soon." id ep1_22_chloe_call_0fae9901
    show ep1 wed_chloeroom_chloe_silent with d
    simon "Thanks, Chloe." id ep1_22_chloe_call_453ebd13
    stop music fadeout 3
    show ep1 wed_chloeroom_chloe_speaks with d
    chloe "Talk to you later, [name]." id ep1_22_chloe_call_c1518d69


    jump ep1_23_roadtrip_sue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
