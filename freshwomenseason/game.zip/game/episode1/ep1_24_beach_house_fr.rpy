default ep1_susan_key = False
default ep1_tried_susan_key = False

label ep1_fr_bh:
    $ renpy.block_rollback()
    $ ep1_bh_queue_musics()
    show screen cellphone
    $ move_to('ep1_fr_bh_multi_ent')

label ep1_fr_bh_multi_ent:
    show tutorial_text_bar with d
    show black_fade with d
    $ renpy.music.set_volume(0.15)
    "Objective: Find the suitcase!" id ep1_fr_bh_multi_ent_ee5d2e4f
    "Click on doors and objects to explore." id ep1_fr_bh_multi_ent_28fa1f5d
    $ renpy.music.set_volume(0.3)
    hide tutorial_text_bar with d
    hide black_fade with d
    $ call_next_screen()

label ep1_24_bhfr_suitglass:
    simon "(I found it!)" id ep1_24_bhfr_suitglass_3c94ea5a
    simon "(It's inside that room...)" id ep1_24_bhfr_suitglass_9f9333ba
    simon "(I've got to find a way around.)" id ep1_24_bhfr_suitglass_e68dd5df
    return

label ep1_fr_bh_multi_maindoor:
    $ call_next_screen()

label ep1_fr_bh_multi_hall2:
    $ call_next_screen()

label ep1_fr_bh_multi_hall3:
    $ call_next_screen()

label ep1_fr_bh_multi_smallbathroom:
    $ call_next_screen()

label ep1_24_bhfr_mask:
    show ep1 fr_bh_multi_mask_idle with d
    simon "(Looks like a mask for a masquerade.)" id ep1_24_bhfr_mask_7a04af28
    simon "(And an interesting choice in clothes.)" id ep1_24_bhfr_mask_0fbf46e3
    simon "(Has Susan worn these?)" id ep1_24_bhfr_mask_2c630e86
    play music lessons_learned volume 0.15 fadein 2
    show ep1 fr_bh_susan_mask1 with d
    simon "(Man, I bet she looked hot in them.)" id ep1_24_bhfr_mask_1e144504
    show ep1 fr_bh_susan_mask2 with d
    simon "(She definitely has the body for it.)" id ep1_24_bhfr_mask_a246ded9
    show ep1 fr_bh_susan_mask3 with d
    simon "(And her share of interesting kinks.)" id ep1_24_bhfr_mask_8cca62d6
    show ep1 fr_bh_susan_mask4 with d
    simon "(I never would have imagined.)" id ep1_24_bhfr_mask_aecbab07
    $ ep1_bh_queue_musics()
    return

label ep1_fr_bh_multi_storage:
    play sound door_open volume 0.4
    $ enter_room_event('ep1_24_bhfr_dylan')
    $ call_next_screen()

label ep1_24_bhfr_mannequin:
    simon "(I guess Susan has a fetish or two.)" id ep1_24_bhfr_mannequin_26d30a79
    return

label ep1_24_bhfr_dildos:
    simon "(Why so many?)" id ep1_24_bhfr_dildos_2e7c85a8
    return

label ep1_24_bhfr_boxes:
    simon "(The boxes are sealed. Better not open them.)" id ep1_24_bhfr_boxes_7647128a
    return

label ep1_24_bhfr_see_susan:
    show ep1 fr_bh_multi_susan_leaving with d
    $ renpy.music.set_volume(0.15)
    simon "(Umm, she's still here?!)" id ep1_24_bhfr_see_susan_6c1c3320
    show ep1 fr_bh_multi_susan_catch with d
    susan "(Huh?)" id ep1_24_bhfr_see_susan_d2bbc94e
    show ep1 fr_bh_multi_simon_hiding with d
    simon "(Oh, shit!)" id ep1_24_bhfr_see_susan_cd0bd5ba
    show ep1 fr_bh_multi_susan_looking with d
    susan "(I thought I saw something...)" id ep1_24_bhfr_see_susan_c0d9ab73
    show ep1 fr_bh_multi_susan_nothing with d
    susan "(Probably nothing.)" id ep1_24_bhfr_see_susan_c9813d02
    show ep1 fr_bh_multi_livingroom_idle with d
    simon "(She's just leaving now from the look of it.)" id ep1_24_bhfr_see_susan_e6a5ca42
    simon "(That was a close one.)" id ep1_24_bhfr_see_susan_6a2a39f8
    $ renpy.music.set_volume(0.3)
    return

label ep1_fr_bh_multi_livingroom:
    $ enter_room_event('ep1_24_bhfr_see_susan')
    $ call_next_screen()

label ep1_fr_bh_multi_piano:
    $ call_next_screen()

label ep1_24_bhfr_painting:
    simon "(Looks like one of those random paintings you see in model homes.)" id ep1_24_bhfr_painting_b6f0dcbd
    return

label ep1_24_bhfr_portrait:
    simon "(There was a picture here before. Maybe her late husband?)" id ep1_24_bhfr_portrait_f46fccc0
    return

label ep1_fr_bh_multi_kitchen:
    $ call_next_screen()

label ep1_24_bhfr_kitchen2:
    simon "(Empty...)" id ep1_24_bhfr_kitchen2_b55a16eb
    return

label ep1_24_bhfr_trash:
    simon "(Takeout cartons... I guess she didn't want to cook yesterday.)" id ep1_24_bhfr_trash_9acdab9d
    return

label ep1_fr_bh_multi_bedroom:
    $ call_next_screen()

label ep1_24_bhfr_phone:
    show ep1 fr_bh_multi_phone_key with d
    simon "(A key! It probably opens something important.)" id ep1_24_bhfr_phone_5f7839e6
    play sound keys_jangling volume 0.4
    $ ep1_susan_key = True
    show ep1 fr_bh_multi_phone_idle with d
    simon "(Someone left their phone here.)" id ep1_24_bhfr_phone_5fbc8b6b
    simon "(I can't unlock it, but I can read the latest notification.)" id ep1_24_bhfr_phone_33d9bd63
    show ep1 fr_bh_phone_notification with d
    if not_english():
        unknown_sender "Last night was great. Can't wait for next time." (what_italic=True)
    simon "(Hmm...)" id ep1_24_bhfr_phone_b9c55da2
    return

label ep1_24_bhfr_vibrator:
    show ep1 fr_bh_multi_vibrator_idle with d
    simon "(This is probably her favorite toy.)" id ep1_24_bhfr_vibrator_18427b70
    simon "(She seems lonely. It makes sense she'd keep one of these close by.)" id ep1_24_bhfr_vibrator_04fd57f9
    return

label ep1_fr_bh_multi_outside:
    $ call_next_screen()

label ep1_24_bhfr_stairs:

    show ep1 fr_bh_multi_stairs_idle with d
    simon "(So that's where she went.)" id ep1_24_bhfr_stairs_6a2e3352
    simon "(I don't see anything important that way.)" id ep1_24_bhfr_stairs_899eec83
    return

label ep1_24_bhfr_book:
    show ep1 fr_bh_multi_book_idle with d
    simon "(A notebook with Susan's handwriting on it.)" id ep1_24_bhfr_book_18b9a4f1
    simon "(Lots of stuff about the store.)" id ep1_24_bhfr_book_0d290ad0
    simon "(There's a note at the bottom.)" id ep1_24_bhfr_book_d2b39339
    show ep1 fr_bh_book_creepy with d
    if not_english():
        "Keep an eye on the boy." (what_italic=True)
    simon "(Boy? Is that me?)" id ep1_24_bhfr_book_b84d52cc
    simon "(That's not at all ominous.)" id ep1_24_bhfr_book_86ec02ba
    return

label ep1_24_bhfr_view:
    show ep1 fr_bh_view_idle with d
    simon "(What a nice view.)" id ep1_24_bhfr_view_34f83f83
    simon "(Wait. Who's that?)" id ep1_24_bhfr_view_9c070086
    show ep1 fr_bh_view_sue with d
    simon "(Sue?!)" id ep1_24_bhfr_view_2a5a31cd
    show ep1 fr_bh_view_sue2 with d
    simon "(I can't believe it!)" id ep1_24_bhfr_view_bff123ae
    simon "(She's supposed to be keeping an eye out for Susan.)" id ep1_24_bhfr_view_b1e44e22
    return

label ep1_24_bhfr_playpiano:
    play music living_piano volume 0.7
    show ep1 fr_bh_playingpiano1 with d
    simon "(My hands just started moving on their own.)" id ep1_24_bhfr_playpiano_fc9977f3
    show ep1 fr_bh_playingpiano2 with d
    simon "(Somehow, they know exactly what they're doing.)" id ep1_24_bhfr_playpiano_340ebd8f
    show ep1 fr_bh_playingpiano3 with d
    simon "(I know this melody... from before.)" id ep1_24_bhfr_playpiano_e8b38b34
    $ ep1_bh_queue_musics()
    return

label ep1_fr_bh_multi_suitcaseroom:
    $ call_next_screen()

label ep1_fr_bh_multi_hall2_locked:
    play sound locked_door volume 0.7
    simon "(It's locked. None of the keys Sue gave me seem to work.)" id ep1_fr_bh_multi_hall2_locked_654e63e5
    simon "(There's probably another key somewhere in the house.)" id ep1_fr_bh_multi_hall2_locked_215f7db8
    return

label ep1_fr_bh_multi_hall2_unlock:
    play sound door_open volume 0.4
    $ ep1_tried_susan_key = True
    simon "(The key worked!)" id ep1_fr_bh_multi_hall2_unlock_85336093
    $ move_to('ep1_fr_bh_multi_suitcaseroom')

label ep1_24_bhfr_exit:
    "Are you sure you want to end free roam?" id ep1_24_bhfr_exit_737d3ea1
    menu:
        "Yes, end free roam":
            stop music fadeout 1.0
            jump ep1_25_sue_beach
        "Not yet":
            return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
