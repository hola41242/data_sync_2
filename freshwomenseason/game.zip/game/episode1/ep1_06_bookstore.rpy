

label ep1_06_bookstore:
    stop music fadeout 4
    hide screen cellphone

    play sound door_shop_bell
    show ep1 mon_bookstore_entrance_surprise with fade

    simon "Wow, this place looks even nicer on the inside." id ep1_06_bookstore_aa814dc1

    unknown_chloe "Don't you even mean \"bigger\" on the inside?" id ep1_06_bookstore_784ef453
    play music horizon volume 0.25
    simon "Huh?" id ep1_06_bookstore_708b4972
    show ep1 anim_chloe_pan with d
    $ pause(13)

    unknown_chloe "That's how the line is supposed to go." id ep1_06_bookstore_726ee499
    scene ep1 mon_bookstore_ent_chloe_reg with d
    unknown_chloe "They usually say it's bigger on the inside." id ep1_06_bookstore_f403dfd6
    unknown_chloe "You know... from Doctor Who..." id ep1_06_bookstore_2fd0301a

    simon "..." id ep1_06_bookstore_ba28090a
    show ep1 mon_bookstore_ent_chloesad with d
    unknown_chloe "Sorry..." id ep1_06_bookstore_4f3e8ea2
    show ep1 mon_bookstore_ent_simon_work with d
    simon "Umm, do you work here?" id ep1_06_bookstore_49fddca6
    unknown_chloe "Nope, But can I help you with anything?" id ep1_06_bookstore_8f3ac49d
    show ep1 mon_bookstore_ent_simon_speaks with d
    simon "Well, classes start next week, and I do have a couple books I need to grab." id ep1_06_bookstore_3518d253
    show ep1 mon_bookstore_ent_chloe_reg_fresh with d
    unknown_chloe "You a freshman?" id ep1_06_bookstore_25ab50b5
    show ep1 mon_bookstore_ent_simon_freshman with d
    simon "What gave it away?" id ep1_06_bookstore_d2043ab0
    show ep1 mon_bookstore_ent_chloe_smiles with d
    unknown_chloe "Just a guess. We all have this lost look about us at times."

    unknown_chloe "Wait. Don't tell me you go to Minerva Bay College too?" id ep1_06_bookstore_9ceaca51
    show ep1 mon_bookstore_ent_chloe_intrigued with d
    simon "Are you a student there as well?" id ep1_06_bookstore_ea873567

    show ep1 mon_bookstore_ent_chloe_too with d
    unknown_chloe "I started last semester, so I guess you could say I'm a freshwoman." id ep1_06_bookstore_5f0cf7bd
    show ep1 mon_bookstore_ent_simon_reg with d
    simon "Got ya. Well, I haven't visited the campus yet. I'm planning to do that tomorrow." id ep1_06_bookstore_4bb7d182
    show ep1 mon_bookstore_ent_chloe_chloe with d
    unknown_chloe "Oh, I see! I'm Chloe by the way." id ep1_06_bookstore_4c3c7660
    show ep1 mon_bookstore_ent_simon_reg with d
    simon "[name]." id ep1_06_bookstore_7c714a65

    show ep1 mon_bookstore_chloe_help with d
    chloe "So, what can I help you with?" id ep1_06_bookstore_07e7b62a
    show ep1 mon_bookstore_chloe_help_s with d
    simon "I thought you said you didn't work here." id ep1_06_bookstore_59548081
    show ep1 mon_bookstore_chloe_help_smile with d
    chloe "I don't. But I know this place better than anyone." id ep1_06_bookstore_48780c2d
    show ep1 mon_bookstore_chloe_followme with d
    chloe "Follow me. I'll show you where to get started." id ep1_06_bookstore_d829ce2d
    show ep1 mon_bookstore_chloe_back_letssee with d
    chloe "Let's see..." id ep1_06_bookstore_27f46b5a
    chloe "Ah! There you are!" id ep1_06_bookstore_501b0189
    show ep1 mon_bookstore_chloe_back_down with d
    chloe "You'll need this one." id ep1_06_bookstore_9dbcc265
    show ep1 mon_bookstore_chloe_back_up1 with d
    chloe "And that one." id ep1_06_bookstore_fbcf16db
    menu:
        "Grab the book"(True):
            play sound pulling_book_from_bookshelf
            show ep1 mon_bookstore_simon_back_book with d
            simon "I'll get it." id ep1_06_bookstore_aedaafa3
            $ ep1_bookshelf_you = True
            $ points_chloe += 1
        "Let her get it":
            show ep1 mon_bookstore_chloe_back_book with d
            chloe "Let me get that for you." id ep1_06_bookstore_9cb9dd02
            show ep1 mon_bookstore_chloe_back_service with d
            chloe "These shelves sure are high!" id ep1_06_bookstore_27e5a73b
            play sound pulling_book_from_bookshelf
            show ep1 mon_bookstore_chloe_back_book_you with d
            $ ep1_bookshelf_you = False
            chloe "Here you go." id ep1_06_bookstore_9a778225
    show ep1 mon_bookstore_simon_ent_all with d
    simon "Are these all I need?" id ep1_06_bookstore_91d44657
    show ep1 mon_bookstore_chloe_ent_light with d
    chloe "They'll do, but I could recommend some extra light reading if you'd like." id ep1_06_bookstore_0bc63108
    show ep1 mon_bookstore_chloe_simon_ent_books with d
    simon "You sure do like books." id ep1_06_bookstore_38663e06

    show ep1 mon_bookstore_ent_chloe_bookclub with d
    chloe "I run a book club at the college library." id ep1_06_bookstore_1bbd9cec
    show ep1 mon_bookstore_ent_chloe_reg_asks with d
    chloe "Are you into books?" id ep1_06_bookstore_a91af23a
    show ep1 mon_bookstore_ent_chloe_reg_silent with d
    menu:
        "Of course"(True):

            $ ep1_you_like_books = True
            simon "Of course I am! I love books." id ep1_06_bookstore_b284bcc7
            show ep1 mon_bookstore_ent_chloe_reg_speaks_happy with d
            chloe "Really?!" id ep1_06_bookstore_4736f977
            chloe "That's great!" id ep1_06_bookstore_50530756
            show ep1 mon_bookstore_ent_chloe_reg_silent with d
            $ points_chloe += 1
            chloe "What do you like to read?" id ep1_06_bookstore_e2b58344
            menu:
                "Fiction"(True):
                    $ you_like_fiction = True
                    $ player_choice("you_like_fiction:true")
                    simon "I'm more into fiction." id ep1_06_bookstore_069810b2
                    show ep1 mon_bookstore_ent_chloe_reg_speaks_veryhappy with d
                    chloe "Really? Science fiction? Fantasy? Epics?" id ep1_06_bookstore_26c58303
                    simon "Well, I..." id ep1_06_bookstore_30d5ac8f
                    chloe "You know what? You should join our book club!" id ep1_06_bookstore_cee7cc3d
                    show ep1 mon_bookstore_ent_chloe_reg_speaks_happy with d
                    $ points_chloe += 1
                    simon "(She's practically overflowing with excitement!)" id ep1_06_bookstore_b6083c46
                "Non-fiction":
                    simon "I mostly read non-fiction." id ep1_06_bookstore_18151196
                    $ player_choice("you_like_fiction:false")
                    show ep1 mon_bookstore_ent_chloe_reg_speaks with d
                    chloe "Self-help books and the like?" id ep1_06_bookstore_59ced397
                    chloe "I guess those have their merit..." id ep1_06_bookstore_777f0946
                    show ep1 mon_bookstore_ent_chloe_reg_speaks_happy with d
                    chloe "Still, I think you should drop by our book club." id ep1_06_bookstore_6994f878
        "Nah":
            $ ep1_you_like_books = False
            simon "I prefer movies and TV shows." id ep1_06_bookstore_953153a8
            show ep1 mon_bookstore_ent_chloe_reg_speaks with d
            chloe "Not Doctor Who apparently..." id ep1_06_bookstore_f79c6609
            show ep1 mon_bookstore_ent_chloe_reg_speaks_happy with d
            chloe "I also enjoy movies and shows, but most of the good ones are based on books anyway." id ep1_06_bookstore_06af3f5b
            chloe "All the more reason why you should stop by our book club." id ep1_06_bookstore_3fc297bf
    show ep1 mon_bookstore_ent_chloe_reg_speaks_veryhappy with d
    chloe "Let me tell you more about it." id ep1_06_bookstore_5083753e
    chloe "It's not the most popular club on campus, but we have fun." id ep1_06_bookstore_02cde465
    show ep1 mon_bookstore_ent_chloe_reg_speaks with d
    chloe "Honestly, I wish life were more like books sometimes." id ep1_06_bookstore_73e5ae2b
    show ep1 mon_bookstore_ent_chloe_reg_silent with d
    simon "How so?" id ep1_06_bookstore_58bb722e
    show ep1 mon_bookstore_ent_chloe_deepthought1 with d
    chloe "You know, it's just that in some books you can see the world through every character's eyes." id ep1_06_bookstore_8730f558
    chloe "That way, you get to know the whole truth." id ep1_06_bookstore_2362a1eb
    show ep1 mon_bookstore_ent_chloe_deepthought2 with d
    chloe "In real life, you never know who you can trust." id ep1_06_bookstore_6520b674
    chloe "That's why I like our book club. I can figure out the whole story there." id ep1_06_bookstore_b444063a
    show ep1 mon_bookstore_ent_chloe_reg_speaks with d
    chloe "We pick a book, and then we decide how many chapters to read per week." id ep1_06_bookstore_66bb7f17
    show ep1 mon_bookstore_chloe_points with d
    chloe "This month we're reading this one." id ep1_06_bookstore_9adde87f
    show ep1 mon_bookstore_chloe_excitement with d
    chloe "The story is actually pretty good!" id ep1_06_bookstore_b5f24b40
    show ep1 mon_bookstore_ent_chloe_reg_speaks with d
    chloe "This one was Dylan's suggestion." id ep1_06_bookstore_134d6aec
    chloe "He even gave me a version of it in Russian." id ep1_06_bookstore_df77dbe9
    chloe "Dylan's a member of our club." id ep1_06_bookstore_db5bcd16
    chloe "Right now, we only have three members." id ep1_06_bookstore_53025cd3
    stop music fadeout 2
    chloe "Me, another girl from my class, and Dylan. He's a foreign exchange student." id ep1_06_bookstore_bf8cec21

    show ep1 mon_bookstore_simon_fromrussia with d

    simon "From Russia, I presume?" id ep1_06_bookstore_e36fbcf1
    show ep1 mon_bookstore_enters_dylan with d
    play music one_last_breath volume 0.2
    dy "Precisely." (what_bold=True)
    simon "(He snuck up behind me. That guy's got a very strong accent.)" id ep1_06_bookstore_3c9144dc
    show ep1 mon_bookstore_chloe_dylan with d
    chloe "Dylan! Speak of the devil!" id ep1_06_bookstore_1a3434a3
    show ep1 mon_bookstore_dylan_book with d
    dylan "Hello, Chloe. I see you're reading the book I suggested." (what_bold=True)
    chloe "Yep. You chose a good one!" id ep1_06_bookstore_387fb476
    show ep1 mon_bookstore_theyseat with d
    chloe "Let's all have a seat!" id ep1_06_bookstore_de0bca47
    show ep1 mon_bookstore_sit_chloe_introduces_you with d
    chloe "By the way, this is [name]. I was just trying to convince him to join our club!" id ep1_06_bookstore_512f4d1d
    show ep1 mon_bookstore_sit_chloe_introduces_dylan with d
    chloe "[name], this is Dylan, the foreign exchange student I was telling you about." id ep1_06_bookstore_b8850aa0
    show ep1 mon_bookstore_sit_simonthink with d
    simon "(Oh, wow! This guy's good-looking and an exchange student. The girls must go crazy about him!)" id ep1_06_bookstore_762d0347
    simon "(Maybe we can be friends. Then some of his popularity might rub off on me!)" id ep1_06_bookstore_fe78124d
    show ep1 mon_bookstore_sit_simon_talks_dylan with d
    simon "Hello! Nice to meet you!" id ep1_06_bookstore_3907b1d6
    show ep1 mon_bookstore_chloe_goeat with d
    chloe "Since Dylan's here, how about I grab us some coffee?" id ep1_06_bookstore_a505d2eb
    chloe "I'll be right back." id ep1_06_bookstore_ce515304
    show ep1 mon_bookstore_chloe_dylan_book with d
    chloe "Dylan can tell you more about our college and the book club while I'm gone!" id ep1_06_bookstore_1cf48803
    show ep1 mon_bookstore_dylan_talks with d
    dylan "So..." (what_bold=True)
    play sound door_shop_bell volume 0.5
    dylan "Are you going to join the book club?" (what_bold=True)
    show ep1 mon_bookstore_dylan with d
    menu:
        "Sure"(True):
            simon "Sure. I mean, why not?" id ep1_06_bookstore_d23e99e1
            $ points_dylan += 1
            $ join_bookclub = True
            $ player_choice("join_bookclub:true")
        "Maybe":
            simon "I guess I could stop by... We'll see." id ep1_06_bookstore_109dece5
            $ player_choice("join_bookclub:false")

    show ep1 mon_bookstore_dylan_looksaround1 with d
    pause
    show ep1 mon_bookstore_dylan_looksaround2 with d
    pause

    stop music
    show ep1 mon_bookstore_realdylan_talks with None

    if chose('join_bookclub'):
        dylan "Dude! It's going to be awesome to have you!" id ep1_06_bookstore_5a8a6edb
    else:
        dylan "Dude! Please join the club. Help a bro out!" id ep1_06_bookstore_9355e613
    show ep1 mon_bookstore_simondylan_surprise with None
    simon "(What the... fuck?!)" id ep1_06_bookstore_f60b05fa
    simon "(Where'd his accent go?!)" id ep1_06_bookstore_3bdbb836
    play music coffee volume 0.2
    show ep1 mon_bookstore_realdylan_hehe with d
    dylan "I just pretend to be a foreign guy to get the girls to notice me!" id ep1_06_bookstore_024e5588
    dylan "... And, oh boy, does it work!" id ep1_06_bookstore_86fbff02
    show ep1 mon_bookstore_realdylan_talks with d
    dylan "But things are getting a little out of hand..." id ep1_06_bookstore_d73ea9ae
    show ep1 mon_bookstore_simondylan_what with d
    simon "Wait, so you're not from Russia?" id ep1_06_bookstore_b4899b66
    show ep1 mon_bookstore_realdylan_talks with d
    dylan "Naw, man! I'm from a small farming town!" id ep1_06_bookstore_081ebccc
    show ep1 mon_bookstore_realdylan_hair with d
    dylan "I even dyed my hair to make me look more exotic." id ep1_06_bookstore_363d81b1
    show ep1 mon_bookstore_realdylan_talks with d
    dylan "And, of course, there's the fucking accent!" id ep1_06_bookstore_e028c711
    dylan "But I mean, my name's Dylan, bro!" id ep1_06_bookstore_546f79ae
    show ep1 mon_bookstore_realdylan_asks with d
    dylan "Does that sound like a Russian name to you?" id ep1_06_bookstore_349dd107
    show ep1 mon_bookstore_simondylan_dontknow with d
    simon "I'm... not really sure..." id ep1_06_bookstore_ee0ea6de
    show ep1 mon_bookstore_realdylan_confused with d
    dylan "Me neither!" id ep1_06_bookstore_8be3597f
    dylan "I don't know how these people don't figure out I'm not from Russia though!" id ep1_06_bookstore_ab35a53b
    show ep1 mon_bookstore_simondylan_loosescrew with d
    simon "(I think this guy's got a screw loose...)" id ep1_06_bookstore_19e94ba9
    show ep1 mon_bookstore_simondylan_what with d
    simon "But why do all this in the first place?" id ep1_06_bookstore_bb30b609
    show ep1 mon_bookstore_darkdylan_drama with d
    dylan "You wouldn't understand..." id ep1_06_bookstore_88f3a39b
    dylan "You don't know what it's like, man..." id ep1_06_bookstore_036fc4ee
    show ep1 mon_bookstore_darkdylan_drama_sad with d
    dylan "Sure, the girls look at me, but looks don't cut it after a while." id ep1_06_bookstore_2483e17b
    dylan "I don't even know how to carry on a conversation, bro." id ep1_06_bookstore_b386f6b8
    show ep1 mon_bookstore_darkdylan_drama with d
    dylan "All girls want to talk about is their emotions and shit." id ep1_06_bookstore_6f9ef762
    dylan "I'm not good at that." id ep1_06_bookstore_8f6723b1
    show ep1 mon_bookstore_darkdylan_drama_sad with d
    dylan "And also..." id ep1_06_bookstore_6ab09018
    dylan "I'm about as interesting as drying paint." id ep1_06_bookstore_86da7c47
    dylan "That's why I pretend to be Russian." id ep1_06_bookstore_1c2085ca
    dylan "... It's even why I joined the book club." id ep1_06_bookstore_ab3dd04d
    show ep1 mon_bookstore_darkdylan_drama with d
    dylan "I was about to tell Chloe the truth..." id ep1_06_bookstore_d6d09030
    dylan "... But then I saw you, and you seem like a guy with your fair share of secrets." id ep1_06_bookstore_9e5af1d8
    show ep1 mon_bookstore_darkdylan_drama_bro with d
    dylan "So, now you know my secret, bro." id ep1_06_bookstore_5d9878f0
    dylan "Please, help a bro out!" id ep1_06_bookstore_3471c0ec
    show ep1 mon_bookstore_darkdylan_drama_silent with d
    simon "You seem like a guy with a lot of trauma..." id ep1_06_bookstore_44b7f606
    show ep1 mon_bookstore_darkdylan_drama_bro with d
    dylan "Does that mean you'll help me out, bro?" id ep1_06_bookstore_e7dfa79c
    menu:
        "Okay"(True):
            show ep1 mon_bookstore_realdylan_happy with d
            $ points_dylan += 1
            simon "All right. I'll see what I can do." id ep1_06_bookstore_73c0a48b
            dylan "Thanks, bro!" id ep1_06_bookstore_387d78f9
            dylan "You're my hero!" id ep1_06_bookstore_a2d5c60c
            show ep1 mon_bookstore_realdylan_talks with d
            dylan "I'll try to repay the favor whenever I can." id ep1_06_bookstore_237d0b5d
        "I'm not sure...":
            show ep1 mon_bookstore_realdylan_sad with d
            simon "I'm not sure. It sounds like you're taking a big risk." id ep1_06_bookstore_69fb06f1
            show ep1 mon_bookstore_realdylan_talks with d
            dylan "Bro, I can help you out too." id ep1_06_bookstore_55da4be6
    dylan "If you want girls, I can get you girls." id ep1_06_bookstore_1dd16add
    dylan "You'll be more popular if you're seen hanging out with the foreign guy." id ep1_06_bookstore_a9aa5fd2
    show ep1 mon_bookstore_realdylan_talks_sad with d
    dylan "I don't have any friends because I don't want anyone else to find out the truth." id ep1_06_bookstore_d2c6bf5f
    show ep1 mon_bookstore_realdylan_talks_happy with d
    dylan "But now, you know my secret!" id ep1_06_bookstore_aa2a4e25
    dylan "So we can be friends!" id ep1_06_bookstore_e69a31e7

    show ep1 mon_bookstore_simondylan_deal with d
    simon "I better not regret this." id ep1_06_bookstore_65aa355b
    stop music fadeout 2
    show ep1 mon_bookstore_realdylan_talks_happy with d
    play sound door_shop_bell volume 0.3
    dylan "You won't, bro! I promise!"
    play music horizon volume 0.25
    show ep1 mon_bookstore_chloe_isback with d
    chloe "I'm back!" id ep1_06_bookstore_af5ddd9c

    show ep1 mon_bookstore_sit_dylan with d
    dylan "Hey. Welcome back, Chloe." (what_bold=True)
    simon "(There he goes with the accent again.)" id ep1_06_bookstore_78f7ab65
    show ep1 mon_bookstore_sit_chloe with d
    chloe "What have you two been talking about?" id ep1_06_bookstore_d1d7c2be
    show ep1 mon_bookstore_sit_dylan_nervous with d
    dylan "Oh... *Ahem.*" id ep1_06_bookstore_20821dfc
    show ep1 mon_bookstore_sit_dylan_relief with d
    simon "Dylan here just convinced me to join the book club." id ep1_06_bookstore_873944b2
    show ep1 mon_bookstore_sit_dylan_happy with d
    dylan "Thanks, br — Uh..." id ep1_06_bookstore_9fe70077
    show ep1 mon_bookstore_sit_dylan with d

    dylan "I mean... I appreciate it, friend." (what_bold=True)


    show ep1 mon_bookstore_sit_chloe_happy with d
    chloe "Yay! That's great!" id ep1_06_bookstore_02e092cd
    chloe "Come join us after classes start." id ep1_06_bookstore_6a8e687e
    chloe "We meet at the library every Tuesday!" id ep1_06_bookstore_95481597
    simon "Will do!" id ep1_06_bookstore_576e46c6
    show ep1 mon_bookstore_sit_chloe with d
    chloe "Oh, and if you happen to need more books..." id ep1_06_bookstore_9fa98acf
    show ep1 mon_bookstore_sit_chloe_whispers with d
    chloe "*Whispers.* Come to the library on campus, and I'll get them for you." (what_italic=True)
    simon "Oh, thanks!" id ep1_06_bookstore_9e71447c
    show ep1 mon_bookstore_sit_chloe with d
    chloe "Well, I should get going." id ep1_06_bookstore_382efd9f
    chloe "It was nice meeting you, [name]." id ep1_06_bookstore_92ac34ca
    show ep1 mon_bookstore_sit_chloe_leave_bookclub with d
    chloe "I hope to see you again at the book club." id ep1_06_bookstore_1bb2859c
    show ep1 mon_bookstore_simon_bye with d
    simon "All right. See you later, guys!" id ep1_06_bookstore_e7806b24
    show ep1 mon_bookstore_sit_leaving_chloe with d
    stop music fadeout 2
    chloe "Bye!" id ep1_06_bookstore_33f00168
    show ep1 mon_bookstore_sit_leaving_dylan with d
    dylan "Thanks again, friend! This will be a real adventure!" (what_bold=True)
    play music fly_that_kite volume 0.7
    show ep1 mon_bookstore_sit_theyleft with d

    simon "I guess we'll see about that." id ep1_06_bookstore_49c880e2
    $ went_bookstore = True

    jump ep1_05_mall_fr
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
