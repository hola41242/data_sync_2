label ep1_20_alyssa_streets:

    show ep1 tue_street_simonout with long_fade
    simon "Wow, it's getting pretty late." id ep1_20_alyssa_streets_68b8e84c
    show ep1 tue_street_simonbike with d
    simon "I should head home. This has been a weird day." id ep1_20_alyssa_streets_79c2f88e
    show ep1 tue_street_simonhuh with d
    simon "Huh?" id ep1_20_alyssa_streets_196da51b
    play music alyssa volume 0.15


    show ep1 anim_alyssarun with d


    simon "Alyssa?" id ep1_20_alyssa_streets_200d2148
    pause
    show ep1 tue_street_alyssa_sawme with d
    simon "I think she saw me." id ep1_20_alyssa_streets_e2d79b7d
    menu:
        "Wave"(True):
            show ep1 tue_street_simon_wave with d
            pause
        "Do nothing":
            pass
    show ep1 tue_street_alyssa_hi with fade
    alyssa "Oh, hey! [name], right?" id ep1_20_alyssa_streets_dec7867f
    simon "Yup. " id ep1_20_alyssa_streets_6d1e3cd7
    show ep1 tue_street_alyssa_question with d
    alyssa "Do you live around here?" id ep1_20_alyssa_streets_de3799e5
    simon "Nope. I was just making a delivery for my boss." id ep1_20_alyssa_streets_0508f548
    show ep1 tue_street_alyssa_wow with d
    alyssa "Wow. First days on your own, and you already have a job?" id ep1_20_alyssa_streets_d121dc79
    alyssa "That's impressive!" id ep1_20_alyssa_streets_b832afc2
    simon "How about you? You live around here?" id ep1_20_alyssa_streets_74fdc2c0
    show ep1 tue_street_alyssa_goinghome with d
    alyssa "Actually, I was just heading home. I live that way." id ep1_20_alyssa_streets_79fd2112
    simon "So do I. We can walk back together." id ep1_20_alyssa_streets_bb96902d
    simon "So, no dance lessons tonight?" id ep1_20_alyssa_streets_b1e8c911
    alyssa "Nope. They're the day after tomorrow." id ep1_20_alyssa_streets_0e07e33e
    show ep1 tue_street_alyssa_question with d
    if chose('ep1_joindance'):
        alyssa "You're still coming, right?" id ep1_20_alyssa_streets_53e02aba
        simon "Yep. Wouldn't miss it." id ep1_20_alyssa_streets_29bd09ff
    else:
        alyssa "Speaking of which, have you decide if you're coming or not?" id ep1_20_alyssa_streets_63ffd4d1
        show ep1 tue_street_simon_thinks with d
        simon "I haven't given it much thought yet." id ep1_20_alyssa_streets_edf90c20
        simon "Can I get back to you later?" id ep1_20_alyssa_streets_ea3b03f7
        show ep1 tue_street_alyssa_sure with d
        alyssa "Sure." id ep1_20_alyssa_streets_7db12e50
    show ep1 tue_street_alyssa_number with fade
    alyssa "Give me your number. I'll text you later to remind you." id ep1_20_alyssa_streets_4ce7960d
    alyssa "You're not getting off the hook that easily, [name]." id ep1_20_alyssa_streets_47bef4bd
    show ep1 tue_street_alyssa_question2 with d
    alyssa "Hey, can I ask you something?" id ep1_20_alyssa_streets_3dd37b03
    simon "Sure." id ep1_20_alyssa_streets_7d1120e8
    alyssa "Why did you move to this town?" id ep1_20_alyssa_streets_6f21505e
    show ep1 tue_street_alyssa_imean with d
    alyssa "I mean, you told me it was for college." id ep1_20_alyssa_streets_2e35a2ad
    alyssa "But people usually want to leave this town, not come here." id ep1_20_alyssa_streets_c887ac66
    show ep1 tue_street_simon_city with d
    simon "Is there something wrong with this place?" id ep1_20_alyssa_streets_e8fbba9e
    show ep1 tue_street_alyssa_city with d
    alyssa "I wouldn't say there's anything particularly wrong about it..." id ep1_20_alyssa_streets_91f014b8
    alyssa "The weather is nice, and there's the beach, which is all right..." id ep1_20_alyssa_streets_8b8866ea
    show ep1 tue_street_alyssa_silent with d
    simon "But?" id ep1_20_alyssa_streets_538a19db
    alyssa "But... that's it." id ep1_20_alyssa_streets_5c342dcc
    alyssa "There isn't a whole lot more to do here, you know?" id ep1_20_alyssa_streets_04fd8cba
    show ep1 tue_street_alyssa_question2 with d
    alyssa "What was it like in your old town?" id ep1_20_alyssa_streets_3176f5b8
    show ep1 tue_street_simon_guess with d
    simon "It was fine, I guess." id ep1_20_alyssa_streets_669f5be2
    simon "I mean that as an actual guess too because I don't remember all that much." id ep1_20_alyssa_streets_461f3b41
    show ep1 tue_street_alyssa_what with d
    alyssa "What do you mean?" id ep1_20_alyssa_streets_3a67eea2
    show ep1 tue_street_simon_accident with d
    simon "Well, about a year ago something happened, and I spent a lot of time in the hospital." id ep1_20_alyssa_streets_03a1e096
    simon "And now my memory's kinda fuzzy." id ep1_20_alyssa_streets_b07d50ca
    show ep1 tue_street_alyssa_poorthing with d
    alyssa "Oh, you poor thing!" id ep1_20_alyssa_streets_e2f7e7b7
    alyssa "So, you don't remember anything from before?" id ep1_20_alyssa_streets_f942c3ee
    show ep1 tue_street_simon_remember with d
    simon "I remember some things." id ep1_20_alyssa_streets_0f2ee90b
    simon "People, emotions, places." id ep1_20_alyssa_streets_dc52c97c
    simon "But they're all just flashes." id ep1_20_alyssa_streets_00322875
    show ep1 tue_street_simon_parents with d
    simon "My mother helped a lot." id ep1_20_alyssa_streets_5d7c06f6
    stop music fadeout 4
    simon "At first, I didn't remember her at all." id ep1_20_alyssa_streets_9288f955
    simon "But the more time I spent with her, the more I remembered." id ep1_20_alyssa_streets_be351f35
    show ep1 tue_street_alysa_tough with d
    alyssa "That must have been so tough." id ep1_20_alyssa_streets_62482cc9
    alyssa "Come here." id ep1_20_alyssa_streets_ae6cb613
    show ep1 tue_street_alyssa_hug with long_dissolve
    play music light_storm volume 0.15
    queue music light_song
    pause
    alyssa "You can always make new memories at least." id ep1_20_alyssa_streets_0b326064
    show ep1 tue_street_alyssa_whathappened with d
    alyssa "But what happened to you? If you don't mind my asking..." id ep1_20_alyssa_streets_dd9e3e0f
    show ep1 tue_street_alyssa_silent2 with d
    simon "Promise you won't laugh?" id ep1_20_alyssa_streets_fa04ed87
    show ep1 tue_street_alyssa_serious with d
    alyssa "Why would I laugh? It sounds deadly serious." id ep1_20_alyssa_streets_75fe74a1
    show ep1 tue_street_alyssa_silent2 with d
    simon "I was struck by lightning." id ep1_20_alyssa_streets_f066e9f1
    show ep1 tue_street_alyssa_lightning with d
    alyssa "Are you serious? I've never met anyone who could say that happened to them." id ep1_20_alyssa_streets_be929c69
    show ep1 tue_street_alyssa_silent2 with d
    simon "It's not really something that happens on a day-to-day basis." id ep1_20_alyssa_streets_4a8f3c0b
    show ep1 tue_street_alyssa_serious with d
    alyssa "You are being serious though, right?" id ep1_20_alyssa_streets_5d944f6d
    show ep1 tue_street_alyssa_silent2 with d
    simon "Of course I am." id ep1_20_alyssa_streets_ccb68b8a
    show ep1 tue_street_simon_scars with d
    simon "I've even got the scars to prove it." id ep1_20_alyssa_streets_5e056a17
    alyssa "Oh, really?!" id ep1_20_alyssa_streets_c5868763
    menu:
        "Take shirt off"(True):
            show ep1 tue_street_simon_shirtoff with d
            simon "Check them out." id ep1_20_alyssa_streets_35e55f7c
            show ep1 tue_street_alyssa_omg with d
            alyssa "Oh my god!" id ep1_20_alyssa_streets_2f8bab6a
            alyssa "You didn't have to do that! Haha!" id ep1_20_alyssa_streets_a9cd9a84
            alyssa "I believe you." id ep1_20_alyssa_streets_e80bd2e3
            show ep1 tue_street_simon_shirton with d
            simon "Right. Now you do!" id ep1_20_alyssa_streets_89e9a2d2
            alyssa "Hahaha!" id ep1_20_alyssa_streets_e748cfae
            $ ep1_shirt_off_alyssa = True
            $ player_choice("ep1_shirt_off_alyssa:true")
        "Don't take it off":
            $ player_choice("ep1_shirt_off_alyssa:false")
    show ep1 tue_street_alyssa_battlescars with d
    alyssa "Battle scars. I like that." id ep1_20_alyssa_streets_d915d045
    show ep1 tue_street_simon_twothings with d
    simon "Hey. That's two embarrassing things you know about me now!" id ep1_20_alyssa_streets_47cca6b7
    simon "We need to even the score." id ep1_20_alyssa_streets_0b246073
    show ep1 tue_street_alyssa_wasnt with d
    alyssa "What?! That's not embarrassing!" id ep1_20_alyssa_streets_3185022b
    alyssa "It was quite personal though." id ep1_20_alyssa_streets_90918340
    show ep1 tue_street_alyssa_seedance with d
    alyssa "Come see me dance. That should make things fair." id ep1_20_alyssa_streets_1f7b8a95
    simon "I will. That's a promise." id ep1_20_alyssa_streets_0b20e769
    show ep1 tue_street_alyssa_really with d
    alyssa "Really?" id ep1_20_alyssa_streets_1317a223
    simon "Really!" id ep1_20_alyssa_streets_ebe895b3
    show ep1 tue_street_alyssa_seeyou with d
    alyssa "Great! I'll see you soon then." id ep1_20_alyssa_streets_b4ee133d
    show ep1 tue_street_alyssa_me with d
    alyssa "So, uh, this is my place." id ep1_20_alyssa_streets_24c52a41
    show ep1 tue_street_simon_good with d
    simon "P.S. It's got to be good to even the score!" id ep1_20_alyssa_streets_05703a6b
    alyssa "What's got to be good?" id ep1_20_alyssa_streets_14fe0841
    simon "The dance." id ep1_20_alyssa_streets_309b05aa
    stop music fadeout 4
    show ep1 tue_street_alyssa_nopromise with d
    alyssa "I'm not making any promises!" id ep1_20_alyssa_streets_279b73e8
    menu:
        "Check Alyssa out"(True):
            show ep1 tue_street_alyssa_ass with d
            pause
        "Don't check her out":
            pass
    show ep1 tue_street_simon_goodday with medium_fade
    simon "(Today was a good day.)" id ep1_20_alyssa_streets_bd087a51

    call ask_for_purcharse from _call_ask_for_purcharse
    call ask_for_review from _call_ask_for_review_1

    scene ep1 tue_simonhome_night with long_dissolve
    pause

    jump ep1_21_wakeup_sue
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
