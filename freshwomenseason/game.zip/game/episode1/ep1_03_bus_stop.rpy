
define episode_1_name = _("Episode 1 - A Fresh Start")

label ep1_03_bus_stop:


    play music you_cant_stop_me fadein 4 
    show oppaiman_presents with medium_fade
    pause 2


    scene black with medium_fade

    show black as ep1 with d
    show ep1 titlecard with None
    $ on_screen_translation(episode_1_name, interact=False)
    pause 4
    $ on_screen_translation(episode_1_name, interact=False)
    stop music fadeout 4
    $ on_screen_translation(episode_1_name, interact=False)
    pause 2
    show ep1 mon_busstop_simon with long_fade


    simon "(The mall isn't all that far from here.)" id ep1_03_bus_stop_53bc162f
    simon "I could probably get there quickly if I had a bike to ride.)" id ep1_03_bus_stop_0046986d
    show ep1 mon_busstop_simonsit with d
    simon "(For today, I'd better take the bus.)" id ep1_03_bus_stop_76e1587d
    simon "(Just like my new landlady suggested.)" id ep1_03_bus_stop_1a1155b6
    show ep1 mon_busstop_simonreact with d

    simon "(Damn...)" id ep1_03_bus_stop_2df71584
    play music hell_yeah volume 0.1
    show ep1 anim_sue_pan with d
    pause 13
    simon "(... She's smoking hot!)" id ep1_03_bus_stop_2d20c089
    simon "(Is she waiting for the bus too?)" id ep1_03_bus_stop_e7f88a65
    simon "(Maybe I can strike up a conversation.)" id ep1_03_bus_stop_9d020b1c


    show ep1 mon_busstop_buscoming with d
    simon "(There's the bus I need to take. Doesn't look like she's getting on this one.)" id ep1_03_bus_stop_6f534014
    simon "(What should I do?)" id ep1_03_bus_stop_7db58cf1
    menu:
        "Wait and talk to the girl"(True):
            show ep1 mon_busstop_suelooking with d
            simon "(Is she looking at me?)" id ep1_03_bus_stop_aab47b01
            simon "(Maybe we know each other...)" id ep1_03_bus_stop_67dbf070
            show ep1 mon_busstop_suelooking_closer with d
            simon "(From before...)" id ep1_03_bus_stop_714a0a24
            simon "(Now's my chance.)" id ep1_03_bus_stop_66cad465
            show ep1 mon_busstop_simon_hi with d
            simon "Hi, I'm —" id ep1_03_bus_stop_26189d3b
            show ep1 mon_busstop_mam with None
            ep1_busstop_man "Here, ma'am." id ep1_03_bus_stop_593ba5b3
            simon "(Huh?)" id ep1_03_bus_stop_b5a42478
            show ep1 mon_busstop_sue_car with d
            simon "(Ma'am?)" id ep1_03_bus_stop_cc02f319
            show ep1 mon_busstop_sue_car_ass with d
            simon "(Oh, great. She's getting in her car!)"
            play sound car_start volume 0.2
            show ep1 mon_busstop_sue_leaving with fade
            stop music fadeout 4
            simon "(And now she's gone forever...)" id ep1_03_bus_stop_f80e7986
            simon "(... She sure did remind me of someone though.)" id ep1_03_bus_stop_c94377c8
            show ep1 mon_busstop_simonsad with d
            simon "(At least I tried...)" id ep1_03_bus_stop_610d0f89
            play sound bus_stop_arrival volume 0.3
            show ep1 mon_busstop_newbus with wipeup
            "A few minutes later..." (what_italic=True)
            $ ep1_tried_talk_sue = True

            simon "(Finally, the next bus is here.)" id ep1_03_bus_stop_f41d3326
        "Take the bus":
            stop music fadeout 2
            $ ep1_tried_talk_sue = False
            pass


    show ep1 mon_bus_simon with fade
    simon "(All right, [name]. Focus.)" id ep1_03_bus_stop_3525abbd

    show ep1 mon_bus_simon_deepthought with long_dissolve
    simon "(Remember what you're here for.)" id ep1_03_bus_stop_2c685f9f
    jump ep1_04_flashbacks
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
