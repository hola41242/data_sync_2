label ep1_18_tue_susan:
    show ep1 tue_mall_entrance with long_fade

    simon "(Thanks to Dylan's help back there, I'm still on time for my meeting with Susan.)" id ep1_18_tue_susan_827a278a
    show ep1 tue_mall_susan with fade
    play music lessons_learned fadein 2 volume 0.25
    menu:
        "Hi, Susan":
            pass
        "Hey, boss"(True):
            show ep1 tue_mall_hiboss with d
            susan "Hello, [name]." id ep1_18_tue_susan_6538de21
            $ points_susan += 1
    show ep1 tue_mall_susanearly with d
    susan "Good. You're early." id ep1_18_tue_susan_c9ae3aab
    show ep1 tue_mall_susandelivery with d
    susan "I need you to deliver this package to this address." id ep1_18_tue_susan_b5fa30b6
    show ep1 tue_mall_susanearly with d
    susan "Get over there, ring the doorbell, deliver the box, and head back home." id ep1_18_tue_susan_5ac65138
    susan "Simple as that." id ep1_18_tue_susan_e6636839
    susan "There's a bicycle you can use in the parking lot." id ep1_18_tue_susan_a6f586da
    susan "Any questions?" id ep1_18_tue_susan_0bf8ac17
    show ep1 tue_mall_susansilent with d
    menu:
        "What am I delivering?"(True):

            show ep1 tue_mall_susananswer with d
            susan "We sell clothes here, [name]. What else would you be delivering?" id ep1_18_tue_susan_16295bc4
            simon "(I guess I asked for that.)" id ep1_18_tue_susan_dbfba238
        "Who's the customer?":
            show ep1 tue_mall_susananswer with d
            susan "Her name's on the box, right above the address." id ep1_18_tue_susan_cc103fd0
            simon "Oh, right." id ep1_18_tue_susan_e1d90913
        "Nope":
            pass
    show ep1 tue_mall_susanearly with d
    susan "You can keep the bike, as long as you remember to bring it to work whenever there's a delivery." id ep1_18_tue_susan_f27e1a45
    simon "Thanks." id ep1_18_tue_susan_d9b17823

    stop music fadeout 2
    show ep1 tue_mall_simonbike_wonder with fade
    simon "(Delivery boy, huh?)" id ep1_18_tue_susan_02fadd29
    simon "(I wonder if the customer's hot.)" id ep1_18_tue_susan_9c6010cc
    jump ep1_19_sexy_customer
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
