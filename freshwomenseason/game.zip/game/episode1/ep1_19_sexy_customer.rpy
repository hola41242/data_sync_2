label ep1_19_sexy_customer:

    show ep1 tue_delivery_mae_cake with long_fade
    play sound prepare_cake volume 0.5
    pause
    show ep1 tue_delivery_mae_bake with d
    stop sound fadeout 1
    play sound kitchen_oven volume 0.5
    pause
    show ep1 tue_delivery_simon_hello with fade
    stop sound fadeout 1
    play sound door_bell volume 0.4
    simon "Hello! Delivery from Susan's Clothing Store for a Miss Mae!" id ep1_19_sexy_customer_9312e422
    play sound opening_door_1
    show ep1 tue_delivery_mae_opendoor with wiperight
    play music strange_behaviour volume 0.25
    customer "Oh, it's here. Thank you!" id ep1_19_sexy_customer_fd2fdb93
    show ep1 tue_delivery_mae_analyzing with d
    customer "(Wow! This delivery boy's much more handsome than her previous one...)" id ep1_19_sexy_customer_237c75f5
    show ep1 tue_delivery_mae_opendoor with d
    customer "Honey, that's a bit too heavy for me. Could you bring it inside?" id ep1_19_sexy_customer_c67f374f
    show ep1 tue_delivery_mae_thisway with d
    customer "Come on in! Right this way." id ep1_19_sexy_customer_cfd3f4b0
    simon "Okay." id ep1_19_sexy_customer_3c2f5362
    show ep1 tue_delivery_simon_boxdown with fade
    simon "That's a load off! That package was pretty heavy." id ep1_19_sexy_customer_dad93152
    show ep1 tue_delivery_mae_thankyou with d
    customer "Thank you so much." id ep1_19_sexy_customer_a0b036cb
    show ep1 tue_delivery_mae_tense_shoulders with d
    customer "Honey, your shoulders are so tense!" id ep1_19_sexy_customer_e111eb7f
    customer "You're going to be in a lot of pain tomorrow if you don't relieve some of that tension." id ep1_19_sexy_customer_785b79de
    show ep1 tue_delivery_mae_masseuse with d
    customer "And you're just in luck! I'm a professional masseuse, so I know just what you need." id ep1_19_sexy_customer_53a18ad2
    show ep1 tue_delivery_mae_sithere with d
    customer "Just have a seat for one minute. You can leave whenever if you don't enjoy the massage." id ep1_19_sexy_customer_da673a70
    simon "I've got some time to spare today, so I don't see a problem giving it a try." id ep1_19_sexy_customer_1ae20b57
    show ep1 tue_delivery_simon_noproblem with wipeup
    customer "There! I found a muscle knot already." id ep1_19_sexy_customer_ffa8222a
    simon "(Wow... She's fantastic. And her hands are so soft...)" id ep1_19_sexy_customer_75a8ffb3
    show ep1 tue_delivery_simon_shoulder_thinks with d
    customer "(He has such strong, firm shoulders...)" id ep1_19_sexy_customer_1561d42c
    show ep1 tue_delivery_mae_shoulder_talks with d
    customer "Is that to your liking? Ah, I didn't get your name." id ep1_19_sexy_customer_e7db5b98
    show ep1 tue_delivery_simon_shoulder_talks with d
    simon "I'm [name], and it's great! I feel so much better already, ma'am!" id ep1_19_sexy_customer_d2cc836f
    show ep1 tue_delivery_mae_biceps_talks with d
    customer "Call me Mae, all right?" id ep1_19_sexy_customer_a9f03751
    customer "You need to fully stretch out your arms after lugging around that heavy box." id ep1_19_sexy_customer_6beaa204
    show ep1 tue_delivery_simon_biceps_yeah with d
    simon "Yeah... It sure feels like it..." id ep1_19_sexy_customer_80eb7893
    customer "Take off your shirt. I'll rub down your arms." id ep1_19_sexy_customer_1e16a30b
    show ep1 tue_delivery_mae_shirt_off with d
    simon "Okay. I can't turn down a free massage from a professional, can I?" id ep1_19_sexy_customer_4d1852d3
    show ep1 tue_delivery_simon_feeling with d
    simon "(That feeling... Are those her...?)" id ep1_19_sexy_customer_37f67a3e
    show ep1 tue_delivery_simon_feeling_tits with d
    simon "(Nice...)" id ep1_19_sexy_customer_763e9eaf
    show ep1 tue_delivery_mae_takecare with d
    customer "A handsome young boy like you needs to take care of himself, or he'll end up getting hurt..." id ep1_19_sexy_customer_6c30091c
    show ep1 tue_delivery_simon_mae_gentle with d
    simon "(What a wonderful feeling... She's so gentle...)" id ep1_19_sexy_customer_d17d8585
    show ep1 tue_delivery_mae_takecare with d
    customer "Are you a student at Minerva Bay College?" id ep1_19_sexy_customer_57df2cd7
    show ep1 tue_delivery_simon_mae_breasts with d
    simon "(Is she doing that on purpose?)" id ep1_19_sexy_customer_01b594ea
    simon "(Her tits are so soft...)" id ep1_19_sexy_customer_3dedd5de
    show ep1 tue_delivery_simon_mae_breasts2 with d
    simon "I am! I just got here, and classes start next week." id ep1_19_sexy_customer_2ac186d2
    show ep1 tue_delivery_mae_liedown with d
    customer "That's wonderful!" id ep1_19_sexy_customer_3d079c94
    customer "[name], I'd like you to lie down so I can give you a special scalp massage to stimulate blood flow to the brain..."
    customer "... But I'll need you to take off your pants so I can keep my massage table clean." id ep1_19_sexy_customer_0fc79966
    customer "Also, those heavy jeans are probably absolutely stifling." id ep1_19_sexy_customer_d1356586
    simon "(I think I know where this is going...)" id ep1_19_sexy_customer_2d5fe142
    menu:
        "Take the jeans off"(True):
            $ player_choice('ep1_mae_sex:true')
            stop music fadeout 2
            simon "(... And I'm all in.)" id ep1_19_sexy_customer_ffa590c7
            simon "All right then." id ep1_19_sexy_customer_01aca596
            play sound taking_pants_off volume 0.6
            show ep1 tue_delivery_simon_pantsoff with medium_wipedown
            play music la_nuit_est_longue_instrumental volume 0.25
            simon "My legs could use a breather..." id ep1_19_sexy_customer_77ef5983
            stop sound fadeout 1

        "Don't take them off" if not _in_replay:
            $ player_choice('ep1_mae_sex:false')
            stop music fadeout 4
            show ep1 tue_delivery_simon_shouldgo with d
            simon "Sorry, but I think I should go." id ep1_19_sexy_customer_95d9e32d
            simon "Thank you for the massage though." id ep1_19_sexy_customer_18ccc330
            show ep1 tue_delivery_simon_go with d
            simon "My work here is done!" id ep1_19_sexy_customer_3687b3b0
            jump ep1_20_alyssa_streets

    show ep1 tue_delivery_simon_mae_headmassage with wipeup
    customer "This massage will help relax your mind so you can study better." id ep1_19_sexy_customer_4b4f6072
    show ep1 tue_delivery_simon_mae_nipple_pov with d
    simon "(Damn... I can see one of her nipples...)" id ep1_19_sexy_customer_bd452164
    show ep1 tue_delivery_simon_mae_nipple with d
    customer "(Wow... Check the other package he's carrying in his underwear... He must be huge...)" id ep1_19_sexy_customer_06cf4073
    show ep1 tue_delivery_simon_mae_headmassage with d
    customer "You know what? You deserve one of my most special massages..." id ep1_19_sexy_customer_bf583db7
    simon "And what are those like?" id ep1_19_sexy_customer_44b3e7e4
    show ep1 tue_delivery_mae_explains with d
    customer "Very simple... I'm going to relieve all the tension in your pulmonary chakra. You're going to breathe a whole lot easier." id ep1_19_sexy_customer_0ae61c4d
    customer "But since you're such a strong boy, I'm going to need to use all my weight." id ep1_19_sexy_customer_e16d84ce
    simon "Does that mean that...?" id ep1_19_sexy_customer_76297109
    show ep1 tue_delivery_mae_over with d
    simon "!!!" id ep1_19_sexy_customer_ad7bf70d
    customer "Stay still, okay?" id ep1_19_sexy_customer_e9edcbbf
    customer "If you move, this massage may not have the desired effect." id ep1_19_sexy_customer_0eea3679
    customer "Let me work my magic." id ep1_19_sexy_customer_0533c0c0
    show ep1 tue_delivery_mae_rubbing with d
    simon "(Wow... She's dry humping me... What a wonderful feeling...)" id ep1_19_sexy_customer_eb9aff00
    simon "(She knows what she wants, and she has no problem taking it...)" id ep1_19_sexy_customer_fa1fde15
    show ep1 tue_delivery_mae_moans with d
    customer "*Moans softly.*" id ep1_19_sexy_customer_dd1c1fe7
    customer "I can feel is... Your chakra is so blocked up... It's just asking for release..." id ep1_19_sexy_customer_3232be95
    simon "(Hmmmm... I'm feeling something wet down there...)" id ep1_19_sexy_customer_7d86ae3f
    show ep1 tue_delivery_mae_wet with d
    simon "(Is she...?)" id ep1_19_sexy_customer_8d070013
    customer "*Breathes heavily.*" id ep1_19_sexy_customer_d956149d
    show ep1 tue_delivery_mae_nopanties with d
    simon "(Mmm... She's not wearing any panties...)" id ep1_19_sexy_customer_9abebc46
    show ep1 tue_delivery_mae_gettinghot with d
    customer "It's getting so hot in here." id ep1_19_sexy_customer_b9c322b0
    show ep1 tue_delivery_mae_takeoff with d
    customer "I'd better take this off." id ep1_19_sexy_customer_6ea8f235
    show ep1 tue_delivery_mae_woman with d
    customer "Could you check my heart rate?" id ep1_19_sexy_customer_caaf093d
    simon "(I love her attitude...)" id ep1_19_sexy_customer_22c4e239
    show ep1 tue_delivery_simon_wonderful with d
    simon "Your heart rate seems perfect." id ep1_19_sexy_customer_48986afb
    show ep1 tue_delivery_mae_hug with d
    customer "Let me hold you, [name]!" id ep1_19_sexy_customer_0110d8e6
    show ep1 tue_delivery_simon_control with d
    simon "(She's really taking control of the situation...)" id ep1_19_sexy_customer_7c6875fc
    simon "*Muffled* Hmmph..." id ep1_19_sexy_customer_7078b1c2
    show ep1 tue_delivery_mae_closeeyes with d
    customer "Close your eyes, [name]..." id ep1_19_sexy_customer_98aaa204
    stop music fadeout 4
    simon "Okay." id ep1_19_sexy_customer_d9b17823
    scene black with d
    customer "Are they closed?" id ep1_19_sexy_customer_c65582f9
    simon "Yes..." id ep1_19_sexy_customer_39c79515
    customer "Keep them closed..." id ep1_19_sexy_customer_8c81577c
    play sound underwear_off volume 0.2
    simon "(She's taking off my underwear...)" id ep1_19_sexy_customer_146917df
    customer "Wow..." id ep1_19_sexy_customer_3d2dbeac
    customer "I've never seen one this big!" id ep1_19_sexy_customer_ab4f88be
    play music the_release volume 0.25
    show ep1 tue_delivery_simon_tip with d
    customer "It's time for you to pay me back for the massage, [name]. From the inside..." id ep1_19_sexy_customer_a1f75a9f
    customer "(Will it fit?)" id ep1_19_sexy_customer_a27f5e72
    show ep1 tue_delivery_simon_omg with d
    simon "Oh my god..." id ep1_19_sexy_customer_23432470
    simon "You're so tight." id ep1_19_sexy_customer_0a9b752f
    show ep1 tue_delivery_mae_bigger with d
    customer "WOW!! IT FEELS SO MUCH BIGGER WHEN YOU'RE INSIDE ME!" id ep1_19_sexy_customer_e681717a
    show ep1 tue_delivery_mae_howisit with d
    customer "How does it feel for you, [name]?" id ep1_19_sexy_customer_cf62c9ad
    simon "It feels so fucking good." id ep1_19_sexy_customer_04ab53d8
    show ep1 tue_delivery_mae_faster with d
    customer "Mmmm..." id ep1_19_sexy_customer_a922253e
    simon "(She's picking up the pace...)" id ep1_19_sexy_customer_71fff5e0
    show ep1 tue_delivery_mae_faster_even with d
    customer "Yes..." id ep1_19_sexy_customer_506e1593
    simon "That's great..." id ep1_19_sexy_customer_92ce0cd0
    show ep1 tue_delivery_mae_having_fun with d
    customer "It's been so long since I've had someone to have fun with." id ep1_19_sexy_customer_c1d0e6a6
    show ep1 tue_delivery_mae_hands with d
    simon "(She's going too fast...)" id ep1_19_sexy_customer_a8cae507
    simon "Is everything okay?" id ep1_19_sexy_customer_cff78847
    simon "(She's so tight. It feels like she's going to crush my dick.)" id ep1_19_sexy_customer_2ead6e3b
    show ep1 tue_delivery_mae_imgonna with d
    customer "[name]..." id ep1_19_sexy_customer_11b39084
    customer "I'm gonna..." id ep1_19_sexy_customer_020c283a
    show ep1 tue_delivery_mae_cum with vpunch
    customer "CUM!!" id ep1_19_sexy_customer_dc046ff6
    show ep1 tue_delivery_mae_phew with d
    customer "That's it... *Phew.*" id ep1_19_sexy_customer_012e82ea
    customer "Haha... Wow..." id ep1_19_sexy_customer_2f899f15
    simon "How was it?" id ep1_19_sexy_customer_8e65e4b1
    show ep1 tue_delivery_mae_allineeded with d
    customer "It was exactly what I needed." id ep1_19_sexy_customer_f3ee1a46
    customer "I'm impressed. That's not how I expected that to go..." id ep1_19_sexy_customer_93c6d987
    show ep1 tue_delivery_simon_meneither with d
    simon "Me neither..." id ep1_19_sexy_customer_468ebc72
    show ep1 tue_delivery_mae_smell with d
    customer "What's that smell?" id ep1_19_sexy_customer_011585dd
    stop music
    show ep1 tue_delivery_mae_mycake_smoke with None
    play sound beeps_fire_alarm volume 0.4
    customer "MY CAKE!!!" id ep1_19_sexy_customer_532ccaa6
    show ep1 tue_delivery_mae_mycake with None
    simon "Shit..." id ep1_19_sexy_customer_27ead22b
    stop sound fadeout 2
    customer "I'm sorry, but you have to go now, delivery boy." id ep1_19_sexy_customer_248f4bfc
    show ep1 tue_delivery_mae_havetogo with d
    customer "I'll walk you to the door." id ep1_19_sexy_customer_3363e9f0
    simon "All right." id ep1_19_sexy_customer_aaf874de
    show ep1 tue_delivery_mae_door with d
    customer "I appreciate the service." id ep1_19_sexy_customer_48423cd8
    $ renpy.end_replay()
    show ep1 tue_delivery_old_rest with None
    old_customer "After all that, my lower back is going to be out of commission for a few days." id ep1_19_sexy_customer_ca49cad3
    show ep1 tue_delivery_simon_wait with d
    simon "(Wait, what?! She looked decades younger before!)" id ep1_19_sexy_customer_82f8b61a
    simon "(Was I daydreaming?)" id ep1_19_sexy_customer_046e06d6
    show ep1 tue_delivery_old_thanks with d
    old_customer "You're the best delivery I ever received from Susan's store." id ep1_19_sexy_customer_40cf3d3d

    show ep1 tue_delivery_simon_go with d
    simon "Whatever. My work here is done." id ep1_19_sexy_customer_cfdb950a

    jump ep1_20_alyssa_streets
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
