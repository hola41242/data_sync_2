label ep1_16_college_dylan:
    play music coming_from_reality volume 0.15
    show ep1 tue_campus_benchdylan_hi with d
    dylan "Privyet." (what_bold=True)
    show ep1 tue_campus_benchsimon_dylan with d
    simon "Ah, Dylan. Didn't see you there." id ep1_16_college_dylan_fbc92d56
    show ep1 tue_campus_benchdylan_here with d
    dylan "What are you doing here, dude?" id ep1_16_college_dylan_7081321f
    dylan "You're a week too early." id ep1_16_college_dylan_bb2809aa
    simon "I know. I just came to drop some documents off." id ep1_16_college_dylan_32e81a94
    show ep1 tue_campus_benchdylan_good with d
    dylan "Got ya." id ep1_16_college_dylan_dd092c6c
    dylan "You done?" id ep1_16_college_dylan_f878d876
    show ep1 tue_campus_benchsimon_where with d
    simon "No. I'm not sure where I'm supposed to go." id ep1_16_college_dylan_3884ef6b
    show ep1 tue_campus_benchdylan_letmesee with d
    dylan "Let me see." id ep1_16_college_dylan_1beb1459
    show ep1 tue_campus_benchdylan_overthere with d
    dylan "Oh. See that line over there?" id ep1_16_college_dylan_c40ed64c
    dylan "That's the place you're looking for." id ep1_16_college_dylan_82565ffb
    stop music
    play sound people_talking volume 0.15
    show ep1 tue_campus_line with None
    simon "Holy shit!" id ep1_16_college_dylan_2ffe8669
    show ep1 tue_campus_benchdylan_imhere with d
    dylan "But, hey, that's what I'm here for." id ep1_16_college_dylan_ddc3236b
    dylan "I know the girls who work there, and they let me cut the line all the time." id ep1_16_college_dylan_0d4f7940
    show ep1 tue_campus_benchdylan_letmedo with d
    play music coffee volume 0.15
    dylan "Here. Let me do that for you." id ep1_16_college_dylan_be41d78c
    simon "Seriously?" id ep1_16_college_dylan_5ed5024e
    show ep1 tue_campus_benchdylan_come with d
    dylan "Or, even better, come with me." id ep1_16_college_dylan_ecc81044
    stop sound fadeout 2
    show ep1 tue_campusoffice_dylancharm with wipeleft
    dylan "Hey there, cutie!" (what_bold=True)
    dylan "I'm here to talk international business. Do I need the password?" (what_bold=True)
    show ep1 tue_campusoffice_clerkno with d
    ep1_clerk "Oh, Dylan. You know you don't." id ep1_16_college_dylan_b5b9854e
    show ep1 tue_campusoffice_dylanyes with d
    dylan "True, but I must ask. How else to see those pretty eyes of yours?" (what_bold=True)
    show ep1 tue_campusoffice_clerkblushes with d
    ep1_clerk "Oh, Dylan!" id ep1_16_college_dylan_0bc8ede5
    show ep1 tue_campusoffice_dylanfriend with d
    dylan "Is it okay if my friend joins me?" (what_bold=True)
    show ep1 tue_campusoffice_clerknotsure with d
    ep1_clerk "Umm..." id ep1_16_college_dylan_a5b2ede0
    ep1_clerk "That goes against the rules of the —" id ep1_16_college_dylan_f9f0e79f

    play music cant_stop_wont_stop volume 0.2
    show ep1 tue_campusoffice_dylanwinks_charm with None
    dylan "Oh, honey buns..." (what_bold=True)
    dylan "You know how much I appreciate your many talents..." (what_bold=True)
    dylan "Could you do me this tiny little favor? Just this once...?" (what_bold=True)
    show ep1 tue_campusoffice_clerkyes_charm with d
    ep1_clerk "I guess I could make just one exception."
    show ep1 tue_campusoffice_dylandocs with d
    stop music fadeout 5
    dylan "I'll just drop these off at the office, and you can consider this matter handled!" id ep1_16_college_dylan_ca666db7
    jump ep1_16b_dylan_partners
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
