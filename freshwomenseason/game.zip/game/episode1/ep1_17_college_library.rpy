label ep1_17_college_library:
    show ep1 tue_library_lib with long_fade
    dylan "Welcome to the library." id ep1_17_college_library_23ea2cac
    dylan "And..." id ep1_17_college_library_9012d7e2
    dylan "Oh! There she is!" id ep1_17_college_library_52741e21
    show ep1 tue_library_dylan_hichloe with d
    play music horizon volume 0.25
    chloe "Hey, Dylan!" id ep1_17_college_library_5200431e
    show ep1 tue_library_chloe_hidylan with d
    dylan "Hello, Chloe!" (what_bold=True)
    show ep1 tue_library_chloe_hisimon with d
    chloe "And — oh, [name]! I'm so glad to see you made it!" id ep1_17_college_library_b2ebf248
    show ep1 tue_library_chloe_question1 with d
    chloe "Are you here for our club?" id ep1_17_college_library_b5779f92
    if chose('join_bookclub'):
        menu:
            "Yep, that's right"(True):
                show ep1 tue_library_simon_looksnice with d
                simon "Yeah. This place sure looks nice." id ep1_17_college_library_1967b969
            "Not exactly":
                show ep1 tue_library_simon_dylanfoundme with d
                simon "Dylan found me wandering around and brought me this way." id ep1_17_college_library_c797b687
        if chose('let_dylan_help'):
            show ep1 tue_library_dylan_helpsimon with d
            dylan "I'm pretty sure he came here to see you too, Chloe." id ep1_17_college_library_80a4a169
            show ep1 tue_library_chloe_ohcute with d
            chloe "Oh? Isn't that adorable." id ep1_17_college_library_c294d56f
            $ points_chloe += 1
    else:
        show ep1 tue_library_simon_lookatdylan with d
        simon "You know what? Yeah, I think I'll join you guys." id ep1_17_college_library_1bb2b128
        show ep1 tue_library_chloe_great with d
        chloe "That's great!" id ep1_17_college_library_d0e67a7d
    show ep1 tue_library_chloe_tour1 with d
    chloe "Come on! Let me give you a tour." id ep1_17_college_library_3fb2f949
    show ep1 tue_library_chloe_tour2 with d
    chloe "We usually have our meetings here." id ep1_17_college_library_917e7bfa
    chloe "As you can see, there aren't many people around." id ep1_17_college_library_04bf37c5
    show ep1 tue_library_chloe_tour3 with d
    chloe "This section is filled with old books that no one cares about." id ep1_17_college_library_8d332bef
    menu:
        "Not even you?"(True):
            $ points_chloe += 1
            show ep1 tue_library_chloe_mything with d
            chloe "They're not really my cup of tea." id ep1_17_college_library_360a05b8
            chloe "However, there are some interesting stories among them." id ep1_17_college_library_d64cef9e
            show ep1 tue_library_chloe_maycare with d
            chloe "So, maybe I do care?" id ep1_17_college_library_4ee4bb8b
        "What are they about?":
            pass
    show ep1 tue_library_chloe_skimming with d
    chloe "I tried skimming through a few of them." id ep1_17_college_library_6b93ded4
    show ep1 tue_library_chloe_grabsbook with d
    chloe "One of them caught my attention. It's about this town." id ep1_17_college_library_59cdf73b
    chloe "Most are just some old history books." id ep1_17_college_library_0483661e
    show ep1 tue_library_simon_mybook with d
    stop music fadeout 4
    simon "By the way, you said you had some light reading for me." id ep1_17_college_library_a7672cc5
    show ep1 tue_library_chloe_goget with d
    chloe "Oh, yeah! Let me go get it for you." id ep1_17_college_library_fe16f02a


    show ep1 tue_library_simon_lookold with long_fade
    simon "These sure look old." id ep1_17_college_library_92c61c35
    show ep1 tue_library_simon_wait with d
    play music sprawling volume 0.25
    simon "Wait, what's this?" id ep1_17_college_library_982bd88d
    show ep1 tue_library_simon_magazine with d
    simon "This is my boss." id ep1_17_college_library_0ae02b16
    dylan "Mmm... She's a total milf, dude!" id ep1_17_college_library_7058e462
    simon "What's she doing on the cover of a magazine?" id ep1_17_college_library_5763c340
    show ep1 tue_library_simon_businessmag with d
    simon "Must be about her business if I had to guess." id ep1_17_college_library_398070d6
    simon "Got to check out the main article." id ep1_17_college_library_6e45decf
    show ep1 tue_library_chloe_foundit with d
    chloe "Found it!" id ep1_17_college_library_e296a71b
    show ep1 tue_library_chloe_huh with d
    chloe "Huh?" id ep1_17_college_library_81870a4d
    show ep1 tue_library_chloe_imback with d
    chloe "Hey, I'm back with your book!" id ep1_17_college_library_3d40a54b
    chloe "Did you find something interesting over here?" id ep1_17_college_library_010ce81d
    show ep1 tue_library_simon_myboss with d
    simon "Yeah. My boss is on the cover of this old magazine." id ep1_17_college_library_763633e7
    simon "But the article doesn't say much about her." id ep1_17_college_library_74cf5fd1
    show ep1 tue_library_simon_garbage with d
    chloe "Oh, that magazine's garbage." id ep1_17_college_library_37b5a9b1
    chloe "It's just a way for the rich and powerful people of this town to stroke their egos." id ep1_17_college_library_6379e80c
    show ep1 tue_library_chloe_yourboss with d
    chloe "I guess your boss is among their ranks." id ep1_17_college_library_46eca56d
    show ep1 tue_library_simon_dontknowmuch with d
    stop music fadeout 4
    simon "I don't know much about her, only that she's friends with my mom." id ep1_17_college_library_68ac92c9
    simon "She doesn't like talking much about her past. At least, that's how it felt." id ep1_17_college_library_ff77e694
    show ep1 tue_library_dylan_jobforchloe with d


    play music coffee volume 0.25
    dylan "Sounds like a job for Chloe." (what_bold=True)
    show ep1 tue_library_chloe_dylan with d
    chloe "Dylan!" id ep1_17_college_library_c66b83ac
    show ep1 tue_library_dylan_chloepi with d
    dylan "What? You're like a professional private investigator." (what_bold=True)



    dylan "If we were back in the motherland, she'd be KGB for sure." (what_bold=True)
    dylan "Chloe can find out anything about anyone." (what_bold=True)
    show ep1 tue_library_simon_doubts with d
    simon "(Really? Anyone, Dylan?!)" id ep1_17_college_library_9f3967f9
    show ep1 tue_library_chloe_humble with d
    chloe "Honestly, it's not all that hard." id ep1_17_college_library_6763c4ad
    chloe "People share way too much about themselves online." id ep1_17_college_library_b8dda987
    show ep1 tue_library_chloe_looking with d
    chloe "Are you looking into someone?" id ep1_17_college_library_b2a8a0d4
    show ep1 tue_library_simon_mydad with d
    simon "You know what, I am." id ep1_17_college_library_478d2fe3
    simon "My dad went missing when I was six." id ep1_17_college_library_d15b5a1c
    simon "I wanted to find out what happened to him." id ep1_17_college_library_115681be
    simon "I think he was involved with some bad people." id ep1_17_college_library_fab90ae0
    show ep1 tue_library_chloe_tricky with d
    chloe "That's going to be a bit more tricky." id ep1_17_college_library_4a86def8
    chloe "I can't use the library's Wi-Fi to search all that. Text me what you know about him, and I'll see what I can find." id ep1_17_college_library_0490868d
    show ep1 tue_library_simon_donthave with d
    simon "I mean, you don't have to." id ep1_17_college_library_aa31bb5e
    show ep1 tue_library_chloe_exciting with d
    chloe "Are you kidding? It sounds so interesting!" id ep1_17_college_library_9e4429c1
    show ep1 tue_library_dylan_shecan with d
    dylan "Told you! She's your girl." (what_bold=True)
    dylan "I bet she could dig up some dirt on your boss as well if you're interested!" (what_bold=True)
    simon "My boss and my landlady seem very well acquainted." id ep1_17_college_library_9bf05f5c
    simon "That's kind of weird, right?" id ep1_17_college_library_1551ec9d

    if chose('connections_mraldersonsusan'):
        simon "Apparently, my landlady's husband used to work with my boss, Susan." id ep1_17_college_library_40b028f8
        show ep1 tue_library_chloe_exciting with d
        chloe "The plot thickens." id ep1_17_college_library_938303f5

    show ep1 tue_library_dylan_shecan with d

    dylan "Well, do you want Chloe to look into her?" (what_bold=True)
    menu:
        "Do it"(True):
            show ep1 tue_library_simon_letsdoit with d
            simon "Okay. Let's do it!" id ep1_17_college_library_43c304d3
            $ points_chloe += 1
            $ ep1_chloe_susan = True
        "Don't do it":
            show ep1 tue_library_simon_notnow with d
            simon "Not quite yet." id ep1_17_college_library_cd05ab23
            $ ep1_chloe_susan = False
    show ep1 tue_library_simon_gowork with d
    simon "And speaking of Susan, I've got to get to work." id ep1_17_college_library_e8ee0b25
    show ep1 tue_library_chloe_textyou with d
    chloe "I'll text you what I find." id ep1_17_college_library_f4f32b43
    dylan "I'll walk you out." (what_bold=True)
    stop music fadeout 3
    show ep1 tue_library_simon_how with d
    simon "How? Just how does she not know the truth about you?" id ep1_17_college_library_0c37749b
    show ep1 tue_library_dylan_secret with d
    dylan "Come on, dude. I've got more than one secret!" id ep1_17_college_library_9bea7546
    show ep1 tue_library_simon_how with d
    simon "All right. Well, I should get going." id ep1_17_college_library_3fe9e1cf
    simon "Thanks for today, Dylan. You're a real lifesaver." id ep1_17_college_library_2b4435c2
    show ep1 tue_library_dylan_secret with d
    dylan "No worries, bro." id ep1_17_college_library_81e69b82
    jump ep1_18_tue_susan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
