label ep1_16b_dylan_partners:
    show ep1 tue_campusoffice_simonthanks with long_fade
    simon "Thanks, man!" id ep1_16b_dylan_partners_e32a63d8
    show ep1 tue_campusoffice_dylansecret with d

    play music out_of_nowhere volume 0.1
    dylan "By the way, you didn't tell anyone about our secret, did you?" id ep1_16b_dylan_partners_456b995c
    show ep1 tue_campusoffice_simonour with d
    simon "OUR secret?" id ep1_16b_dylan_partners_397429a0
    dylan "Yeah, man. You know the one." id ep1_16b_dylan_partners_b42d2546
    show ep1 tue_campusoffice_simonyour with d
    simon "I know YOUR secret." id ep1_16b_dylan_partners_397a8a68
    show ep1 tue_campusoffice_dylanpartners with d
    dylan "We're partners in crime, dude." id ep1_16b_dylan_partners_7524cac0
    simon "I guess you're right..." id ep1_16b_dylan_partners_96a62f92
    dylan "Don't worry. If we ever get caught, Chloe can bail us out." id ep1_16b_dylan_partners_2dc9bf5c
    show ep1 tue_campusoffice_simonchloe with d
    simon "Chloe? I thought she didn't know." id ep1_16b_dylan_partners_2d602f4b
    show ep1 tue_campusoffice_dylanshedoesnt with d
    dylan "She doesn't." id ep1_16b_dylan_partners_0323af94
    dylan "But she's the smartest girl you'll ever meet." id ep1_16b_dylan_partners_39dc959e
    dylan "She's gotten me out of trouble several times already." id ep1_16b_dylan_partners_e49db585
    show ep1 tue_campusoffice_simonareyou with d
    simon "Are the two of you...?" id ep1_16b_dylan_partners_a593d2bb
    show ep1 tue_campusoffice_dylanno with d
    dylan "No way! She's not my type, man." id ep1_16b_dylan_partners_3c39d2a8
    show ep1 tue_campusoffice_dylaninterested with d
    dylan "Why? Are you interested?" id ep1_16b_dylan_partners_4de98c41
    dylan "I could put in a word with her if you want." id ep1_16b_dylan_partners_b2accb3b
    menu:
        "Accept"(True):
            show ep1 tue_campusoffice_simonthink with d
            simon "I mean... Sure?" id ep1_16b_dylan_partners_9defb4e9
            $ let_dylan_help = True
            $ player_choice("let_dylan_help:true")
        "Don't accept":
            show ep1 tue_campusoffice_simonthink with d
            simon "Nah, better not." id ep1_16b_dylan_partners_1e3435bd
            $ let_dylan_help = False
            $ player_choice("let_dylan_help:false")
    show ep1 tue_campusoffice_dylanletsgo with d
    stop music fadeout 4
    dylan "Speaking of Chloe, she's probably at the book club right now. Let's head over!" id ep1_16b_dylan_partners_ee0e1147
    jump ep1_17_college_library
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
