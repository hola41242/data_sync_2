label ep1_28b_lily_sexy:
    $ award_manager.block_notify()
    show ep1 wed_lilyrain_simon_outshower with long_fade
    simon "(I think I misjudged Lily. She seems like a good person.)" id ep1_28b_lily_sexy_b3830565
    simon "(I should use this opportunity to get close with her.)" id ep1_28b_lily_sexy_006b9b0a
    show ep1 wed_lilyrain_fall_simonfoot1 with d
    simon "(Maybe that way she'll open up some more.)" id ep1_28b_lily_sexy_4d862433
    show ep1 wed_lilyrain_fall_simonfoot2 with d
    simon "(Perhaps not too close though. I don't know if I can control myself around those...)" id ep1_28b_lily_sexy_45450365
    play sound water_puddle
    show ep1 wed_lilyrain_fall_simonfoot3 with d
    pause 0.3
    show ep1 wed_lilyrain_fall_simonfall1 with d
    pause 0.3
    play sound body_thud
    show ep1 wed_lilyrain_fall_simonfall2 with d
    pause 0.3
    show ep1 wed_lilyrain_fall_simonfall3 with d
    pause 0.1
    play sound falling_body_floor
    show ep1 wed_lilyrain_fall_simonfall3 with vpunch
    lily "OUCH!" id ep1_28b_lily_sexy_1454ed43
    play music in_viaggio_verso_lalba volume 0.3
    show ep1 wed_lilyrain_fall_panoramic with d:
        xalign 1.0
        linear 5.0 xalign 0.4
    simon "(Oh, no...)" id ep1_28b_lily_sexy_6ec8c807
    simon "(I can't believe I just did that.)" id ep1_28b_lily_sexy_3b9aef08
    show ep1 wed_lilyrain_fall_lily_react with d
    lily "..." id ep1_28b_lily_sexy_2b1dcaac
    show ep1 wed_lilyrain_fall_simon_react with d
    simon "..." id ep1_28b_lily_sexy_ba28090a
    show ep1 wed_lilyrain_fall_lily_off with d
    lily "*Ahem* Could you, uh... move?" id ep1_28b_lily_sexy_42e8e294
    show ep1 wed_lilyrain_fall_simon_off with d
    simon "Yeah, sure. Sorry, I..." id ep1_28b_lily_sexy_9f1bdff7
    show ep1 wed_lilyrain_fall_lily_dick with d
    lily "*Gasp.*" (what_italic=True)
    lily "(It's so big...)" id ep1_28b_lily_sexy_4e0b859c
    show ep1 wed_lilyrain_fall_lily_up with hpunch
    lily "WHAT DO YOU THINK YOU'RE DOING?!" id ep1_28b_lily_sexy_3b38cff7
    show ep1 wed_lilyrain_fall_simon_towel with d
    simon "I'm sorry!" id ep1_28b_lily_sexy_ad3b2ee3
    show ep1 wed_lilyrain_fall_lily_angry with d
    lily "Just..." id ep1_28b_lily_sexy_c979561c
    stop music fadeout 2
    lily "... Go back to your room!" id ep1_28b_lily_sexy_fa05bc94
    simon "All right, Lily." id ep1_28b_lily_sexy_b69a87ca
    show ep1 wed_lilyrain_simon_thatnight with medium_fade
    simon "(Lily's probably going to kick me out of her house the second it stops raining.)" id ep1_28b_lily_sexy_7032ae56
    simon "(And I fucked up everything...)" id ep1_28b_lily_sexy_08ee0528
    show ep1 wed_lilyrain_lily_cantsleep with d
    lily "(I can't sleep. I haven't had sex for months.)" id ep1_28b_lily_sexy_2bcf7077
    lily "(And now I can't stop thinking about...)" id ep1_28b_lily_sexy_6fcd8e7d
    play music lost_horse volume 0.35
    show ep1 wed_lilyrain_simon_mydick with d
    simon "(... My dick. She saw my dick.)" id ep1_28b_lily_sexy_b617f101
    show ep1 wed_lilyrain_lily_large with d
    lily "(It was quite big. Definitely bigger than my husband's.)" id ep1_28b_lily_sexy_ccd8bed7
    show ep1 wed_lilyrain_simon_face with d
    simon "(She made that weird face. She must not have liked it.)" id ep1_28b_lily_sexy_8cae76ae
    simon "(But I didn't really have any control back there. She's just so hot.)" id ep1_28b_lily_sexy_7669507d
    show ep1 wed_lilyrain_lily_bigger with d
    lily "(I've been with my fair share of men before getting married, and my husband's was the largest I've ever seen up close.)" id ep1_28b_lily_sexy_a2eb0d53
    lily "(Until now...)" id ep1_28b_lily_sexy_eded45e6
    show ep1 wed_lilyrain_simon_horny with d
    simon "(I'm getting horny again. I'm never going to be able to sleep like this.)" id ep1_28b_lily_sexy_f4a1adca
    simon "(Maybe I should get a glass of water to help calm my nerves.)" id ep1_28b_lily_sexy_7c0d6924
    show ep1 wed_lilyrain_lily_lookagain with d
    lily "(I want to get one more good look. Just to be sure.)" id ep1_28b_lily_sexy_b8e32c5f
    lily "(He's probably asleep. I wonder if I could just...?)" id ep1_28b_lily_sexy_8f8732e9
    show ep1 wed_lilyrain_simon_cantbelieve with wipedown
    simon "(I can't believe it!)" id ep1_28b_lily_sexy_941e421e
    show ep1 wed_lilyrain_lily_surprised with d
    pause
    show ep1 wed_lilyrain_simon_window with d
    simon "(Lily left a window open. Everything's going to get soaked.)" id ep1_28b_lily_sexy_0b0da4d6
    show ep1 wed_lilyrain_lily_phew with d
    pause
    show ep1 wed_lilyrain_simon_better with d
    simon "Okay. That's better." id ep1_28b_lily_sexy_a954b660
    simon "I'd better head back to my room." id ep1_28b_lily_sexy_7af2d7cd
    show ep1 wed_lilyrain_lily_see_again with d
    simon "(What's Lily doing in my room?)" id ep1_28b_lily_sexy_5f7e034f
    show ep1 wed_lilyrain_lily_youknow with d
    lily "I want to see it again." id ep1_28b_lily_sexy_eb86e41d
    simon "See what again?" id ep1_28b_lily_sexy_114cd794
    lily "Your... You know." id ep1_28b_lily_sexy_d06e41a1
    simon "(Is this really happening?)" id ep1_28b_lily_sexy_21e89356
    show ep1 wed_lilyrain_lily_toobig with d
    lily "It was just so big. I can't get it out of my head." id ep1_28b_lily_sexy_f039ac24
    lily "I must have been seeing things. I need to see it once more to make sure, then I'll be able to go back to bed." id ep1_28b_lily_sexy_e30606cf
    show ep1 wed_lilyrain_simon_justsee with d
    simon "You just want to see it?" id ep1_28b_lily_sexy_ebef7132
    lily "That's right. Consider it payment for your stay here." id ep1_28b_lily_sexy_c612337e
    simon "(Sounds like extortion.)" id ep1_28b_lily_sexy_6da9b9ba
    simon "(But what do I have to lose?)" id ep1_28b_lily_sexy_d137950e
    simon "If you insist." id ep1_28b_lily_sexy_037e5d39
    play sound underwear_off volume 0.24
    show ep1 wed_lilyrain_simon_pantsdown with d
    stop sound fadeout 0.5

    lily "It's pretty big. But not quite as big as I thought." id ep1_28b_lily_sexy_a3781b53
    stop music fadeout 4
    show ep1 wed_lilyrain_lily_settled with d
    lily "I'm glad that's settled." id ep1_28b_lily_sexy_17d3acfa
    show ep1 wed_lilyrain_simon_wait with d
    simon "Wait! That's because I'm not totally hard yet." id ep1_28b_lily_sexy_12dd33d1
    show ep1 wed_lilyrain_simon_encouragement with d
    lily "What do you mean?" id ep1_28b_lily_sexy_a74fe9b9
    show ep1 wed_lilyrain_simon_encouragement_silent with d
    simon "Well... if you could give me some encouragement..." id ep1_28b_lily_sexy_63fbb9d6

    queue music [belong_to_you, neverend] volume 0.25
    simon "... I could show you how big it really gets." id ep1_28b_lily_sexy_080965cb
    show ep1 wed_lilyrain_finewhat with d
    lily "Fine. What sort of encouragement?" id ep1_28b_lily_sexy_8b27ab44

    menu:
        "Tits":
            show ep1 wed_lilyrain_choice with d
            simon "Tits would be a good start." id ep1_28b_lily_sexy_cbe3863b
            show ep1 wed_lilyrain_tits with d
            lily "Is this good?"
            simon "Perfect. They're beautiful." id ep1_28b_lily_sexy_20e10ab7
            show ep1 wed_lilyrain_dick with d
            lily "(Wow, he really meant it! His dick is bigger than I thought!)"
            lily "(He's getting aroused just from looking at me...)"
            lily "(My nipples are as hard as diamonds.)" id ep1_28b_lily_sexy_ded653dc
            show ep1 wed_lilyrain_nipples with d
            lily "Does doing this help?" id ep1_28b_lily_sexy_f3b1c157
        "Ass":
            show ep1 wed_lilyrain_choice with d
            simon "How about some ass?" id ep1_28b_lily_sexy_1926764d
            show ep1 wed_lilyrain_ass with d
            lily "Like this?" id ep1_28b_lily_sexy_c78231e6
            simon "Perfect. You have a beautiful butt." id ep1_28b_lily_sexy_d9da9ce0
            show ep1 wed_lilyrain_dick with d
            lily "(Wow, he really meant it! His dick is bigger than I thought!)"
            lily "(He's getting aroused just from looking at me...)"
            show ep1 wed_lilyrain_ass_now with d
            lily "How about now?"
        "Pussy":
            show ep1 wed_lilyrain_choice with d
            simon "How about you take off your panties?" id ep1_28b_lily_sexy_c6225f39
            show ep1 wed_lilyrain_lily_seriously with d
            lily "Seriously?" id ep1_28b_lily_sexy_2f587b91
            simon "I think it's fair considering what I'm showing you." id ep1_28b_lily_sexy_fef8a1a7
            show ep1 wed_lilyrain_pussy with d
            lily "How's this?" id ep1_28b_lily_sexy_6210eb9f
            simon "A good start, but I can barely see anything." id ep1_28b_lily_sexy_6232c9f1
            show ep1 wed_lilyrain_pussy_now with d
            lily "How about now?"
            simon "Perfect!" id ep1_28b_lily_sexy_8a26b72d
            simon "(Her pussy lips are so smooth!)" id ep1_28b_lily_sexy_de026f4d
            show ep1 wed_lilyrain_dick with d
            lily "(Wow, he really meant it. His dick is bigger than I thought.)" id ep1_28b_lily_sexy_7345637f



    show ep1 wed_lilyrain_lily_thatbig with d
    lily "(Oh...)" id ep1_28b_lily_sexy_d0bf1546
    lily "(It's bigger than big...)" id ep1_28b_lily_sexy_ac0cc587
    lily "(... IT'S HUGE!)" id ep1_28b_lily_sexy_acd9ed5d
    show ep1 wed_lilyrain_simon_enjoying with d
    simon "(Hehe, didn't she say she just wanted to see it? Whatever. I'm enjoying this.)" id ep1_28b_lily_sexy_dc8d8c7c
    show ep1 wed_lilyrain_lily_barelyfits with d
    lily "(It's so warm. I can feel it pulsing.)" id ep1_28b_lily_sexy_f9880d45
    lily "(I can barely wrap my hand around it.)" id ep1_28b_lily_sexy_ba27039e
    simon "(This feels great.)" id ep1_28b_lily_sexy_b6d8906e
    lily "(And it smells delectable.)" id ep1_28b_lily_sexy_cf800ff9
    show ep1 wed_lilyrain_shereally with d
    simon "(Huh? Is she really...?)" id ep1_28b_lily_sexy_3efb626c
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_05_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_05_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_05 with d
    simon "Ahh..." id ep1_28b_lily_sexy_cc4cfaec
    lily "(It's been so long since I've done this...)" id ep1_28b_lily_sexy_fa9e5663
    lily "Do you like that?"
    simon "I love it. Keep going." id ep1_28b_lily_sexy_e0721083


    lily "(I'm getting so wet.)" id ep1_28b_lily_sexy_801362d7
    lily "(I need to know if I can fit it all in my mouth.)" id ep1_28b_lily_sexy_e73b5301
    pause
    stop foley
    stop voicefx
    show ep1 wed_lilyrain_lily_licks with d
    simon "(Is she really going to...?!)" id ep1_28b_lily_sexy_e50c2392
    show ep1 wed_lilyrain_lily_licking with d
    simon "(Oh, god! Her technique is perfect!)" id ep1_28b_lily_sexy_f27b39aa
    show ep1 wed_lilyrain_lily_cantcontrol with d
    lily "(I can't control myself!)" id ep1_28b_lily_sexy_777992f6
    simon "(I won't last long if she keeps that up! I'd better change up the game.)" id ep1_28b_lily_sexy_9a34441e
    show ep1 wed_lilyrain_simon_eyes with d
    simon "I want to look you in the eye when we do this." id ep1_28b_lily_sexy_e5972659
    show ep1 wed_lilyrain_lily_likethem with d
    lily "You really like them, don't you?" id ep1_28b_lily_sexy_4cd15017
    lily "Every time you come by, you stare at them." id ep1_28b_lily_sexy_00ea8959
    simon "I can't control myself. The urge is just too strong." id ep1_28b_lily_sexy_401ef606
    show ep1 wed_lilyrain_lily_braoff with d
    lily "That's fine. I like it when people look at me." id ep1_28b_lily_sexy_46efd480
    show ep1 wed_lilyrain_lily_fuckmytits with d
    lily "Do you want to fuck my tits, [name]?" id ep1_28b_lily_sexy_de236e8a
    simon "I'm so glad you asked!" id ep1_28b_lily_sexy_edadb3f4
    show ep1 wed_lilyrain_simon_overhere with d
    simon "Here. It'll be easier over here." id ep1_28b_lily_sexy_3d9904cc
    lily "I like a man who takes control of the situation." id ep1_28b_lily_sexy_6d1f7e4d
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_07_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_07_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_07 with d
    simon "Your boobs are perfect for this, Lily!" id ep1_28b_lily_sexy_0188cddf
    pause
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep1_anim_lily_07_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep1_anim_lily_07_var1_foley fadein 0.5 fadeout 0.5
    show ep1 anim_lily_07_var1 with d
    lily "Ahh. Fuck my tits, [name]!" id ep1_28b_lily_sexy_e008f45d
    pause
    stop foley
    stop voicefx
    show ep1 wed_lilyrain_lily_titjob with d
    simon "Ahhh... Just like that! That's perfect!" id ep1_28b_lily_sexy_8f446dd1
    simon "(I've been dreaming of this moment!)" id ep1_28b_lily_sexy_f17e0300
    simon "And just when I thought it couldn't get any better!" id ep1_28b_lily_sexy_65ebbf78
    lily "(And I thought he wasn't going to get any bigger...)" id ep1_28b_lily_sexy_60ad1b7b
    lily "(This is my chance. I have to know if I can fit it all.)" id ep1_28b_lily_sexy_0a91b948
    show ep1 wed_lilyrain_lily_deepthroat with vpunch
    simon "Ahhhh..." id ep1_28b_lily_sexy_3cb27ac9
    simon "(She did it!)" id ep1_28b_lily_sexy_d4367228
    show ep1 wed_lilyrain_lily_gasps with d
    lily "*Gasp.*"
    simon "(I can't believe she did it!)" id ep1_28b_lily_sexy_d3c8704c
    show ep1 wed_lilyrain_simon_neverbefore with d
    simon "(I've never gotten a blowjob like that. Mature women really are more experienced.)" id ep1_28b_lily_sexy_ba4064d7
    show ep1 wed_lilyrain_lily_horny with d
    lily "(I'm so turned on right now.)" id ep1_28b_lily_sexy_ccd4a0f8
    lily "(I can't believe I'm doing this!)" id ep1_28b_lily_sexy_23a81460
    simon "Ahhhh... If you keep that up I'm going to —" id ep1_28b_lily_sexy_6244806c
    show ep1 wed_lilyrain_lily_notyet with d
    lily "No, not yet!" id ep1_28b_lily_sexy_51654e1b
    show ep1 wed_lilyrain_lily_needthis with d
    lily "I need this." id ep1_28b_lily_sexy_b01b17dc
    simon "(Wow. She's willing to go all the way!)" id ep1_28b_lily_sexy_eea41e6c
    simon "All right. I'll try to control myself!" id ep1_28b_lily_sexy_8d1630ba
    show ep1 wed_lilyrain_lily_liedown with d
    lily "Lie down with me." id ep1_28b_lily_sexy_db1cc862
    show ep1 wed_lilyrain_lily_not_in with d
    lily "Don't put it in yet." id ep1_28b_lily_sexy_20ce10c3
    lily "Put it between my thighs." id ep1_28b_lily_sexy_855cffc7
    simon "Okay." id ep1_28b_lily_sexy_7d1120e8
    show ep1 wed_lilyrain_lily_thighjob with d
    lily "Yes, like that!" id ep1_28b_lily_sexy_959560dd
    lily "(I can't believe how wet I am!)" id ep1_28b_lily_sexy_ddfc5e30
    show ep1 wed_lilyrain_simon_tight with d
    simon "(She's got a tight grip on me. I could stay like this forever.)" id ep1_28b_lily_sexy_f24565f6
    show ep1 wed_lilyrain_lily_simonhand with d
    lily "Ahhhhh... That's good!" id ep1_28b_lily_sexy_670c8ae1
    simon "(I've got an idea.)" id ep1_28b_lily_sexy_97929973
    show ep1 wed_lilyrain_simon_masturbates with d
    simon "I think you'll like this." id ep1_28b_lily_sexy_5c30bb25
    show ep1 wed_lilyrain_lily_m_dontstop with d
    lily "Ahhh... That's amazing! Don't stop!" id ep1_28b_lily_sexy_816f288c
    lily "Mmmmmm..." id ep1_28b_lily_sexy_9df4d876
    show ep1 wed_lilyrain_lily_m_wet with d
    lily "Don't stop. Don't stop!" id ep1_28b_lily_sexy_1319023c
    simon "(She's so wet!)" id ep1_28b_lily_sexy_08ad1d4a
    show ep1 wed_lilyrain_m_cum with d
    lily "Aaaaaaaahhhh!" id ep1_28b_lily_sexy_3967c0c7
    show ep1 wed_lilyrain_lily_stickit with d
    lily "It's time. Shove it in all at once, [name]!" id ep1_28b_lily_sexy_b5a2e7e9
    simon "Are you sure?" id ep1_28b_lily_sexy_4b1d3f09
    lily "Yes!" id ep1_28b_lily_sexy_79fc794c
    show ep1 wed_lilyrain_lily_argh with hpunch
    lily "AAAAAAAARGH!" id ep1_28b_lily_sexy_ad32c7bd
    lily "TAKE IT BACK OUT!" id ep1_28b_lily_sexy_d44fcdcb
    show ep1 wed_lilyrain_lily_worthit with d
    lily "How about we go a bit slower...?" id ep1_28b_lily_sexy_70690d3e
    show ep1 wed_lilyrain_simon_thisgood with d
    simon "Is this better?" id ep1_28b_lily_sexy_2bf80abe
    lily "Ahhh... Ahhh... That's great!" id ep1_28b_lily_sexy_e0f6fd4d
    show ep1 wed_lilyrain_simon_kiss with d
    lily "Mmph..." id ep1_28b_lily_sexy_ec51a748
    show ep1 wed_lilyrain_lily_idea with d
    lily "I've got an idea." id ep1_28b_lily_sexy_750dd648
    simon "(Did I do something wrong?)" id ep1_28b_lily_sexy_187a7591
    show ep1 wed_lilyrain_d_likethis with d
    lily "I like this position better." id ep1_28b_lily_sexy_6c5b2eb4
    simon "I like the way you think, Lily." id ep1_28b_lily_sexy_5f1d17ac
    show ep1 wed_lilyrain_d_perfectfit with d
    simon "(I should just follow her lead.)" id ep1_28b_lily_sexy_9b7c511c
    simon "It's the perfect fit, Lily." id ep1_28b_lily_sexy_c710c072
    show ep1 wed_lilyrain_d_inside with d
    lily "Mmmmm... I want all of you back inside me again!" id ep1_28b_lily_sexy_84296ab4
    show ep1 wed_lilyrain_d_wish with d
    simon "As you wish." id ep1_28b_lily_sexy_f3416c8a
    lily "Yes, yes!" id ep1_28b_lily_sexy_f78da4e4
    simon "Is that how you like it?" id ep1_28b_lily_sexy_9e625812
    lily "Mmmm... Just like that!" id ep1_28b_lily_sexy_3304d5cb
    simon "(I don't know if I can take much more!)" id ep1_28b_lily_sexy_30a0d76a
    show ep1 wed_lilyrain_d_comeagain with d
    lily "If you keep going, I'm going to cum again!" id ep1_28b_lily_sexy_d215d85e
    simon "I'm close too! " id ep1_28b_lily_sexy_3c549d5d
    lily "Then do it! Keep going!" id ep1_28b_lily_sexy_70492771
    show ep1 wed_lilyrain_d_lily_almost with d
    lily "Yes, yes... THAT'S IT, I'M..." id ep1_28b_lily_sexy_a98dd383
    show ep1 wed_lilyrain_d_lily_cum with vpunch
    stop music fadeout 4
    lily "Mmmmmmph..." id ep1_28b_lily_sexy_3e1192b7
    simon "Aaaaaahh..." id ep1_28b_lily_sexy_d1535f7f
    show ep1 wed_lilyrain_lily_amazing with long_fade
    lily "Wow... That was..." id ep1_28b_lily_sexy_0b7e6003
    simon "Amazing..." id ep1_28b_lily_sexy_360f07bd
    show ep1 wed_lilyrain_lily_curiosity with d
    lily "Yes. Thank you for satisfying my..." id ep1_28b_lily_sexy_0091f1e5
    lily "... curiosity..." id ep1_28b_lily_sexy_99fae429
    simon "Whenever you feel your curiosity peak again, just give me a call." id ep1_28b_lily_sexy_f923b9be
    $ renpy.end_replay()
    show ep1 wed_lilyrain_lily_cantagain with d
    play music cumulus volume 0.25

    lily "[name], this can't happen again." id ep1_28b_lily_sexy_386ce0dc
    show ep1 wed_lilyrain_simon_married with d
    simon "I know. You're married, but..." id ep1_28b_lily_sexy_d1cac4f5
    show ep1 wed_lilyrain_lily_notime with d
    lily "This is hardly the time for that conversation, [name]." id ep1_28b_lily_sexy_bee561d8
    simon "Fine." id ep1_28b_lily_sexy_2eac89ff
    show ep1 wed_lilyrain_simon_rain_over with d
    simon "I didn't even realize it, but the rain's stopped." id ep1_28b_lily_sexy_5f92f91e
    show ep1 wed_lilyrain_simon_lily with d

    simon "Umm... Lily?" id ep1_28b_lily_sexy_f01ce536
    show ep1 wed_lilyrain_lily_yes with d
    lily "Yes?" id ep1_28b_lily_sexy_d3830112
    show ep1 wed_lilyrain_lily_husband with d
    simon "About your husband... " id ep1_28b_lily_sexy_11ba1970
    show ep1 wed_lilyrain_lily_no with d
    stop music fadeout 2
    lily "I just told you, I don't want to talk about him." id ep1_28b_lily_sexy_27358b32
    simon "When did you say he was coming back?" id ep1_28b_lily_sexy_e367201f
    show ep1 wed_lilyrain_lily_cantbe with vpunch
    play music ghost_witch volume 0.25
    lily "IT CAN'T BE!" id ep1_28b_lily_sexy_13739d20
    lily "YOU HAVE TO LEAVE!" id ep1_28b_lily_sexy_b4622d0d
    show ep1 wed_lilyrain_simon_shit with d
    simon "Holy shit... Is there a back way out?" id ep1_28b_lily_sexy_150c89d8
    show ep1 wed_lilyrain_lily_back with d
    lily "Yes, thank the lord." id ep1_28b_lily_sexy_a750fca2
    lily "You're going to have to walk home!" id ep1_28b_lily_sexy_45dacef0
    lily "But you should be able to handle that." id ep1_28b_lily_sexy_1745f6e1

    jump ep1_29_the_car
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
