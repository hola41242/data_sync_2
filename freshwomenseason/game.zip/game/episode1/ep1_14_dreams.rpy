label ep1_14_dreams:

    show ep1 mon_dream_simon_getshome with d
    simon "(What a busy day.)" id ep1_14_dreams_33179b91
    show ep1 mon_dream_simon_sleeps with d
    simon "(Time for some shut-eye.)" id ep1_14_dreams_823b77a1
    show ep1 mon_dream_simon_morning with long_fade
    play sound heavy_door_hinge volume 0.2
    simon "*Snore.*" id ep1_14_dreams_9fbe1ea9
    show ep1 mon_dream_simon_morning_visitant with d
    ep1_dreams_girl "He's asleep..." id ep1_14_dreams_8add6711
    ep1_dreams_girl "Perfect!" id ep1_14_dreams_8026a07a
    show ep1 mon_dream_simon_warm with fade
    "*Slurp, slurp.*" id ep1_14_dreams_8fa38f9b
    simon "(So warm.)" id ep1_14_dreams_eb3bc3dd
    show ep1 mon_dream_simon_huh with d
    pause
    play music make_me_mad volume 0.25 

    show ep1 mon_dream_emily_how with d
    simon "Huh?!" id ep1_14_dreams_a7348e03
    simon "What're you doing?" id ep1_14_dreams_b9cba79e
    simon "How'd you even get in here?" id ep1_14_dreams_f3e6a549
    show ep1 mon_dream_emily_turned with d
    emily "Does it really matter?" id ep1_14_dreams_54cbb64d
    show ep1 mon_dream_emily_how with d
    simon "Yes! Well, uh. Mmm..." id ep1_14_dreams_06707b2f
    show ep1 mon_dream_simon_noticed with d
    emily "I got so turned on after watching you spy on me last night." id ep1_14_dreams_9b4258a5
    show ep1 mon_dream_emily_how with d
    simon "Oh. You saw that?" id ep1_14_dreams_3c4b6f7b
    show ep1 mon_dream_emily_wanted with d
    emily "Yep. And this is exactly what you wanted, isn't it?" id ep1_14_dreams_81a5eab0
    emily "You wanted to see more than a peek, didn't you?" id ep1_14_dreams_c8e20979
    show ep1 mon_dream_emily_how with d
    simon "Well, yeah..." id ep1_14_dreams_417af5ce
    show ep1 mon_dream_simon_yes with d
    emily "Then enjoy!" id ep1_14_dreams_c3a4a02e
    show ep1 mon_dream_simon_nice with d
    simon "This feels great by the way." id ep1_14_dreams_3ea51526
    simon "I just didn't expect you to appear out of nowhere." id ep1_14_dreams_a25f7163
    show ep1 mon_dream_simon_gethere with d
    simon "How did you get in? Did I forget to lock my door?" id ep1_14_dreams_28734fe2

    emily "Don't dwell on all that, sweetie." id ep1_14_dreams_fb8517c6
    show ep1 mon_dream_emily_dontthink with d
    simon "Where are your clothes? Did you sneak in here naked?" id ep1_14_dreams_0bd5417c
    show ep1 mon_dream_emily_seriously with d
    emily "Are you seriously asking that right now?" id ep1_14_dreams_fc4d36d9
    show ep1 mon_dream_emily_howabout with d
    emily "Well, how about..." id ep1_14_dreams_c8965ba9
    play sound finger_snap volume 2

    show ep1 mon_dream_emily_magic with d
    emily "... now?" id ep1_14_dreams_3f729339
    simon "How did you — ?" id ep1_14_dreams_66a18c29
    show ep1 mon_dream_emily_qusetions with d
    emily "You like asking questions, don't you?" id ep1_14_dreams_77aca2ac
    show ep1 mon_dream_simon_imagining with d
    simon "Am I imagining this? I do tend to fantasize a lot." id ep1_14_dreams_9b42ef71
    show ep1 mon_dream_emily_notexactly with d
    emily "Not quite." id ep1_14_dreams_bdcdf57f
    show ep1 mon_dream_simon_imagining with d
    simon "Is this a dream then?" id ep1_14_dreams_388bbe82
    show ep1 mon_dream_emily_over with d
    emily "Correct! And you should really be enjoying yourself by the end of it." id ep1_14_dreams_e651a575
    show ep1 mon_dream_simon_prophecy with d
    simon "Did you come here to bring me a prophecy or something?" id ep1_14_dreams_c75300d8
    stop music fadeout 2
    show ep1 mon_dream_emily_sure with d
    emily "Why not?!" id ep1_14_dreams_87f3054a
    emily "I predict that your life..." id ep1_14_dreams_33296004
    show ep1 mon_dream_emily_this with d

    play music hot_damn volume 0.2 
    emily "Will have a whole lot of these." id ep1_14_dreams_b9421fbe
    simon "You're an excellent fortuneteller." id ep1_14_dreams_eb06e836
    show ep1 mon_dream_simon_thinks with d
    simon "(I don't know if it's just because this is a dream, but her skin is so soft!)" id ep1_14_dreams_21e76311
    emily "My skin is, indeed, quite soft." id ep1_14_dreams_6ecee88c
    show ep1 mon_dream_simon_surprised with d
    simon "Wait. How are you able to read my mind?" id ep1_14_dreams_c6feccd7
    show ep1 mon_dream_emily_dream with d
    emily "Dream, remember?" id ep1_14_dreams_2ee836d7
    simon "Oh, right..." id ep1_14_dreams_087af9ca
    show ep1 mon_dream_emily_more with d
    emily "I have more visions in store for you." id ep1_14_dreams_fee8b0d1
    simon "I like what I'm seeing already." id ep1_14_dreams_271bba9f
    emily "Is that so? Just wait till you see the rest." id ep1_14_dreams_ea41e9b6
    show ep1 mon_dream_simon_whoa with d
    simon "Whoa." id ep1_14_dreams_81129524
    show ep1 mon_dream_emily_like with d
    emily "Do you like what you see now?" id ep1_14_dreams_c9d4e0b8
    simon "Very much so." id ep1_14_dreams_26471d04
    emily "And I see something I like... down there..." id ep1_14_dreams_87853829
    show ep1 mon_dream_emily_huge with d
    emily "Your dick is huge, [name]." id ep1_14_dreams_64ce51e6
    emily "Ahhh..." id ep1_14_dreams_fc0ed323
    simon "Oh... You're so warm..." id ep1_14_dreams_8052f1be
    show ep1 mon_dream_emily_fit with d
    emily "I don't know if it'll all fit." id ep1_14_dreams_8ac336d1
    emily "I have an idea." id ep1_14_dreams_e935d747
    show ep1 mon_dream_emily_sixtynine with d
    emily "Ah, there you go! That way you can make me feel good too!" id ep1_14_dreams_0775829c
    emily "Wow! It's so big!" id ep1_14_dreams_b1f54c37
    show ep1 mon_dream_emily_tongue with d
    emily "Aaaahhh... That's exactly how I like it. You're so talented with your tongue!" id ep1_14_dreams_4c90bf13
    simon "Mmmph..."
    show ep1 mon_dream_emily_try with d
    emily "Did you say something, sweetie?" id ep1_14_dreams_c53471f7
    show ep1 mon_dream_emily_wet with d
    simon "Mmmph..."
    emily "Ahhh... You've got me so wet. You deserve a reward." id ep1_14_dreams_4ee7ccc9
    simon "Mmmpphh..." id ep1_14_dreams_52c559c5
    show ep1 mon_dream_emily_enjoying with d
    emily "I guess that means you're enjoying yourself." id ep1_14_dreams_b62fd04c
    emily "I bet you'll enjoy this even more..." id ep1_14_dreams_9099f504
    show ep1 mon_dream_emily_blow1 with d
    emily "(It's filling my mouth...)" id ep1_14_dreams_6ee32bd2
    emily "(I don't know if I can handle much more...)" id ep1_14_dreams_1587f747
    show ep1 mon_dream_emily_blow2 with d
    emily "(Feels like I'm about to dislocate my jaw...)" id ep1_14_dreams_a3b43368
    emily "(C'mon, Emily!)" id ep1_14_dreams_f58beda1
    show ep1 mon_dream_emily_in with vpunch
    simon "MMPPHH!" id ep1_14_dreams_506fc2ae
    show ep1 mon_dream_emily_out with d
    emily "*Gasp...*" id ep1_14_dreams_2d9bc733
    simon "Mmph?" id ep1_14_dreams_736b3f03
    show ep1 mon_dream_emily_finale with d
    emily "I agree. Time for the big finale." id ep1_14_dreams_66791d1b
    emily "That's what you were trying to say, isn't it? That you wanted to fuck me?" id ep1_14_dreams_0f8a950b
    show ep1 mon_dream_simon_controlling with d
    simon "For this being my dream, you're very controlling..." id ep1_14_dreams_a22fe1b6
    emily "I'll make it worth your while." id ep1_14_dreams_40d710a4
    show ep1 mon_dream_simon_rhythm with d
    simon "Ahhh... Your rhythm is perfect, Emily." id ep1_14_dreams_bfda5883
    emily "I'm going to help you get rid of all that exhaustion you built up yesterday." id ep1_14_dreams_aeada530
    show ep1 mon_dream_emily_tire with d
    emily "But right now, I might have to tire you out just a little bit more." id ep1_14_dreams_1cdbe2c6
    simon "I have a feeling I'm going to wake up pretty relaxed tomorrow." id ep1_14_dreams_71e95fb0
    emily "Since you wanted prophecies..." id ep1_14_dreams_9e8e1e6b
    simon "Don't tell me you have a real one." id ep1_14_dreams_f1007830
    show ep1 mon_dream_emily_hint with d
    emily "It's more like a tip." id ep1_14_dreams_d99f3edb
    emily "Real Emily likes to be on top too." id ep1_14_dreams_f45f46e3
    simon "And how do you know that? You're just a figment of my imagination." id ep1_14_dreams_caa00517
    show ep1 mon_dream_emily_control with d
    emily "She likes to be in control." id ep1_14_dreams_ebf7609f
    emily "Or do you think you caught that glimpse of her on accident...?" id ep1_14_dreams_ebe2a9b3
    show ep1 mon_dream_emily_allthis with d
    emily "...That glimpse of all this?" id ep1_14_dreams_08b4af9e
    show ep1 mon_dream_simon_onpurpose with d
    simon "Did she leave her door open on purpose?" id ep1_14_dreams_f19b366e
    emily "That's what I'd do." id ep1_14_dreams_325266dd
    simon "I —" id ep1_14_dreams_9bf3b23a
    show ep1 mon_dream_emily_rest with d
    emily "Shhh... Just enjoy the rest of the dream, [name]!" id ep1_14_dreams_c5d962ff
    show ep1 mon_dream_emily_likethat with d
    emily "Yeah... Just like that..." id ep1_14_dreams_3ee593c9
    simon "Emily, I'm going to —" id ep1_14_dreams_a7a9c70d
    emily "Keep going! Don't stop!" id ep1_14_dreams_9d11246e
    show ep1 mon_dream_emily_dowhatever with d
    emily "Cum for me, [name]!" id ep1_14_dreams_61bebb40
    emily "Fill my slutty pussy up with all that warm jizz..." id ep1_14_dreams_dc5ebc40
    show ep1 mon_dream_simon_cums with vpunch
    emily "OH! GOD!" id ep1_14_dreams_189d5ffd
    simon "Ahhhhh... Fuck!!!" id ep1_14_dreams_55f6cfa6
    show ep1 mon_dream_emily_cums with d
    emily "Mmmm... That was great!" id ep1_14_dreams_4ea15694
    emily "Okay. Now you have my permission to relax..." id ep1_14_dreams_14fdb6dd

    stop music fadeout 2
    show ep1 mon_dream_emily_now with d
    emily "You know what happens now, right?" id ep1_14_dreams_73b643c9
    simon "What?" id ep1_14_dreams_196da51b
    show ep1 mon_dream_emily_beep with d
    emily "Beep." id ep1_14_dreams_04dba0eb
    show ep1 mon_dream_emily_now with d
    simon "What?!" id ep1_14_dreams_708b4972
    show ep1 tue_simonhome_wakingup with None
    play sound alarm_clock
    "*Beep. Beep. Beep.*" id ep1_14_dreams_89204f3a
    simon "Ah... Right." id ep1_14_dreams_074d7c18
    $ renpy.end_replay()

    jump ep1_15_tue_morning
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
