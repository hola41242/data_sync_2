label ep1_08_mall_games:
    hide screen cellphone
    stop music fadeout 4
    play sound door_shop_bell
    show ep1 mon_arcade_arcade_entrance with fade
    simon "(Whoa. This place looks nice!)" id ep1_08_mall_games_c86740dd
    simon "I wonder if they have Dance Dance Supreme here." id ep1_08_mall_games_445014fc
    show ep1 mon_arcade_julia_shows with hpunch
    j "Did you just say DANCE DANCE SUPREME?!" id ep1_08_mall_games_c8a9464e
    show ep1 mon_arcade_simon_jumps with d
    simon "(Holy shit! That girl just popped out of nowhere!)" id ep1_08_mall_games_b6885310
    j "HAHAHA!" id ep1_08_mall_games_9901dbe9
    play music red_light_boogie volume 0.15
    show ep1 mon_arcade_julia_ent_talks_laugh with d
    j "Pretty jumpy there, aren't ya?" id ep1_08_mall_games_8ff8a34e
    show ep1 mon_arcade_julia_ent_silent_reg with d
    simon "Wh-who are you?!" id ep1_08_mall_games_d0232435
    simon "(She almost gave me a heart attack!)" id ep1_08_mall_games_e0f16f4a
    show ep1 mon_arcade_julia_ent_silent_checkedout with d
    simon "(She is kind of pretty though.)" id ep1_08_mall_games_0944c765
    show ep1 mon_arcade_simon_ent_talks_sorry with d
    simon "Sorry, it's just that I'm new here, so I wasn't expecting anyone to talk to me..." id ep1_08_mall_games_639edf85
    show ep1 mon_arcade_julia_ent_talks_reg with d
    j "I heard you mention Dance Dance Supreme..." id ep1_08_mall_games_a7e807d2
    j "... So I couldn't miss the opportunity to find a worthy opponent!" id ep1_08_mall_games_8984409d
    show ep1 mon_arcade_julia_ent_talks_smiles with d
    julia "Name's Julia by the way." id ep1_08_mall_games_47117862
    show ep1 mon_arcade_julia_ent_talks_teasing with d
    julia "Remember it when I wipe the floor with your ass in a 1v1 match." id ep1_08_mall_games_6e77127b
    show ep1 mon_arcade_julia_ent_silent_reg with d
    simon "(What...?)" id ep1_08_mall_games_f9714a83
    show ep1 mon_arcade_julia_ent_talks_reg with d
    julia "I'm the best Dance Dance Supreme player this world has ever seen!" id ep1_08_mall_games_5c1ec7ad
    show ep1 mon_arcade_julia_ent_talks_points with d
    julia "See those losers over there? They thought they could beat me." id ep1_08_mall_games_026191f9
    julia "Then I showed them what's what." id ep1_08_mall_games_8521a1b3
    show ep1 mon_arcade_kids with d
    simon "(Those three guys over there...?)" id ep1_08_mall_games_02c5f4fe
    show ep1 mon_arcade_kids2 with d
    simon "(... They look like their souls have been ripped from their bodies.)" id ep1_08_mall_games_ef9a13c5
    show ep1 mon_arcade_kids3 with d
    simon "(The joys of life seem unknown to them.)" id ep1_08_mall_games_caf9ba85
    show ep1 mon_arcade_kids4 with d
    simon "(Their gazes are lifeless and lost.)" id ep1_08_mall_games_ed3df6bb
    show ep1 mon_arcade_kids with d
    simon "(Is she THAT good?)" id ep1_08_mall_games_4987ae49
    show ep1 mon_arcade_julia_ent_talks_teasing with d
    stop music fadeout 2
    julia "Oh? Are you gonna chicken out?" id ep1_08_mall_games_d46febb0

    show ep1 mon_arcade_simonmind_1 with fade
    play music free_will_possession volume 0.4

    simon "Silly, silly Julia..." id ep1_08_mall_games_cda0d69e
    simon "So confident." id ep1_08_mall_games_1d1e0224
    simon "I may not remember much from before my accident..." id ep1_08_mall_games_37cd2865

    show ep1 mon_arcade_simonmind_hospital with d
    simon "But as soon as I got back from the hospital, I felt the urge to play." id ep1_08_mall_games_1a161b04
    show ep1 mon_arcade_simonmind_2 with d
    simon "Oh, the hours I've spent on this game..." id ep1_08_mall_games_306aa7cd
    simon "The skills I've learned..." id ep1_08_mall_games_724797c4
    show ep1 mon_arcade_simonmind_3 with hpunch
    simon "When it comes to Dance Dance Supreme..." id ep1_08_mall_games_a1162224
    show ep1 mon_arcade_simonmind_4 with vpunch
    simon "I AM A GOD!" id ep1_08_mall_games_e7979e14
    stop music
    show ep1 mon_arcade_simon_ent_talks_confident with None
    simon "Sure, let's play." id ep1_08_mall_games_9c0e1283
    play music slime_time volume 0.15

    show ep1 mon_arcade_julia_play_talks_reg with d
    julia "I'll enter our names into the machine. What's your name?" id ep1_08_mall_games_46d9048a
    simon "I'm [name]." id ep1_08_mall_games_7c714a65
    julia "[name]... Done!" id ep1_08_mall_games_d94f9697
    show ep1 mon_arcade_julia_play_talks_teasing with d
    julia "Not like your name is going to show up when I'm done with you anyway." id ep1_08_mall_games_283a8462
    julia "Hahahaha!" id ep1_08_mall_games_6d654ed9
    show ep1 mon_arcade_julia_play_talks_curious with d
    julia "Interesting... Not even a blink in response." id ep1_08_mall_games_82e1aeef
    show ep1 mon_arcade_julia_play_talks_reg with d
    julia "You know what? We should make this more interesting..." id ep1_08_mall_games_da00a719
    show ep1 mon_arcade_julia_play_silent_reg with d
    simon "How so?" id ep1_08_mall_games_58bb722e
    show ep1 mon_arcade_julia_play_talks_happy with d
    julia "A prize for the winner of course!" id ep1_08_mall_games_225c3ddc
    show ep1 mon_arcade_julia_play_talks_sexy with d
    julia "If you win, I'll give you something you won't want to miss out on." id ep1_08_mall_games_9cad295f
    show ep1 mon_arcade_julia_play_talks_reg with d
    julia "But that's not gonna happen." id ep1_08_mall_games_d3d3d7b9
    julia "And when I win, I get to pick my prize." id ep1_08_mall_games_6291ea67
    julia "How's that?" id ep1_08_mall_games_acdd552c
    show ep1 mon_arcade_julia_play_silent_reg with d
    simon "You've got yourself a deal." id ep1_08_mall_games_5a3d1afa
    show ep1 mon_arcade_simon_play_silent_thinking with d
    simon "(She seems pretty confident, but I am VERY GOOD at this game...)" id ep1_08_mall_games_e86e8e55

    "(How should I play?)" id ep1_08_mall_games_3612805b
    menu:
        "Fair game"(True):

            show ep1 mon_arcade_simon_play_talks_reg with d
            simon "Show me what you're made of!" id ep1_08_mall_games_df4d9e89
            jump ep1_08_mall_games_fair
        "Crush her":
            show ep1 mon_arcade_simon_play_talks_reg with d
            simon "You're going to regret betting against me!" id ep1_08_mall_games_c81b9932
            jump ep1_08_mall_games_crush
        "Maybe I should just let her win":
            show ep1 mon_arcade_simon_play_talks_reg with d
            simon "Let's see how this goes!" id ep1_08_mall_games_c48fd8a1
            jump ep1_08_mall_games_lose
    return

    label ep1_08_mall_games_fair:
        show ep1 mon_arcade_both_play_talking with wipeup
        play sound game_sfx_1 volume 0.5
        simon "Whoa, you're pretty good!" id ep1_08_mall_games_fair_a1f68280

        pause 0.5
        play sound game_sfx_2 volume 0.5
        julia "You're not half bad yourself!" id ep1_08_mall_games_fair_8cecbc27

        show ep1 mon_arcade_both_play_toughpart with d
        play sound game_sfx_6 volume 0.5
        simon "Here comes the tough part..." id ep1_08_mall_games_fair_19d581ab
        pause 0.5
        play sound game_sfx_error volume 3
        julia "Ugh... No way!" id ep1_08_mall_games_fair_b5c27197

        show ep1 mon_arcade_both_play_simonwins with vpunch
        play sound game_sfx_9 volume 0.5
        ep1_arcade_machine "[name!u] WINS!" (what_bold=True)
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "I'll admit, I didn't think you'd be that good." id ep1_08_mall_games_fair_14ad3ced
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "You move like the wind, Twinkle Toes." id ep1_08_mall_games_fair_26187c38
        julia "But you're just lucky I was out of practice." id ep1_08_mall_games_fair_7d791755
        show ep1 mon_arcade_simon_play_silent_thinking2 with d
        simon "(Huh? Didn't she say she just played against those other guys?)" id ep1_08_mall_games_fair_27ea85c1
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "Well, I should get going..." id ep1_08_mall_games_fair_c2862d5e
        show ep1 mon_arcade_simon_play_talks_prize with d
        simon "Wait. What about my prize?" id ep1_08_mall_games_fair_3d2ae840
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "Oh, I haven't forgotten." id ep1_08_mall_games_fair_ed066fff
        show ep1 mon_arcade_julia_play_talks_service with d
        julia "I've got something wet and velvety just for you." id ep1_08_mall_games_fair_a5c11d98
        julia "How's that sound?" id ep1_08_mall_games_fair_bd89f76b
        show ep1 mon_arcade_simon_play_silent_surprised with d
        simon "*Gulp.*" id ep1_08_mall_games_fair_e15c5913
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "Be right back." id ep1_08_mall_games_fair_2a270b37
        show ep1 mon_arcade_simon_play_silent_happy with d
        simon "(Oh, boy. This is too good!)" id ep1_08_mall_games_fair_c073c950
        simon "(Most people would make fun of me for playing a game like this.)" id ep1_08_mall_games_fair_520a4a70
        simon "(I wish they could all see me now!)" id ep1_08_mall_games_fair_022e0663
        show ep1 mon_arcade_julia_ent_silent_ice with wipeup
        simon "(She's back!)" id ep1_08_mall_games_fair_0f7a9f8f
        stop music fadeout 4
        simon "What have you got there?" id ep1_08_mall_games_fair_e5495b76
        stop music
        show ep1 mon_arcade_julia_ent_talks_giveice with None
        julia "Ice cream for the winner!" id ep1_08_mall_games_fair_22cbfe83
        play music red_light_boogie volume 0.17
        show ep1 mon_arcade_simon_ent_talks_looksice with d
        simon "Oh..." id ep1_08_mall_games_fair_d3eabd74
        show ep1 mon_arcade_simon_ent_silent_disappointed with d
        simon "(Should have seen that coming...)" id ep1_08_mall_games_fair_65f28595
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "You look like you've been playing this game your entire life." id ep1_08_mall_games_fair_55d8849e
        julia "I only started playing it when I lived in Japan last year." id ep1_08_mall_games_fair_027eec74
        show ep1 mon_arcade_julia_ent_silent_ice_reg with d
        simon "Oh, you lived abroad? That must have been nice." id ep1_08_mall_games_fair_1ecff84e
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "It was fun, but I got homesick." id ep1_08_mall_games_fair_353b095f
        show ep1 mon_arcade_julia_ent_silent_ice_happy with d
        simon "What were you doing over there? You must be really smart if it was for an exchange program!" id ep1_08_mall_games_fair_e6bdf647
        show ep1 mon_arcade_julia_ent_talks_ice_unsure with d
        julia "I don't know if smart's the right word..." id ep1_08_mall_games_fair_aa925ace
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "I studied the language and got a part-time job there." id ep1_08_mall_games_fair_e26bbb97
        julia "But none of that helped me land a good job once I returned." id ep1_08_mall_games_fair_d5350292
        show ep1 mon_arcade_simon_ent_silent_thinking with d
        simon "(Is her job that bad?)" id ep1_08_mall_games_fair_b1e5e0b6
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "Don't get me wrong. I have a good job, but I'm in charge of all the boring stuff." id ep1_08_mall_games_fair_5472fc5b


        show ep1 mon_arcade_flashback_01 with d
        julia "It's all spreadsheets and reports." id ep1_08_mall_games_fair_03eeb217
        julia "Big numbers. Lots of math."

        show ep1 mon_arcade_flashback_02 with d
        julia "And nonstop meetings."

        show ep1 mon_arcade_simon_ent_silent_thinking with d
        simon "(Sounds like a decent job to me.)" id ep1_08_mall_games_fair_44c565f9
        show ep1 mon_arcade_julia_ent_talks_ice_unsure with d
        julia "Plus, my schedule is a mess." id ep1_08_mall_games_fair_8d784ef2
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "That's why I come here so often." id ep1_08_mall_games_fair_2115060b
        show ep1 mon_arcade_julia_ent_silent_ice_reg with d
        simon "Does that mean I'll get to see you again?" id ep1_08_mall_games_fair_37fa9e02
        show ep1 mon_arcade_julia_ent_talks_ice_happy with d
        julia "Is that something you'd be interested in?" id ep1_08_mall_games_fair_db964867
        julia "Next time, how about we spice up the bet?" id ep1_08_mall_games_fair_4c56a992
        julia "With something more..." id ep1_08_mall_games_fair_eb8f0c92
        show ep1 mon_arcade_julia_ent_talks_ice_service with d
        julia "... interesting." id ep1_08_mall_games_fair_6b16cea0
        show ep1 mon_arcade_julia_ent_talks_ice_confident with d
        julia "I won't back down until I beat you." id ep1_08_mall_games_fair_87a03d1d
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "For now though, I gotta go. I'm probably late for a meeting or something." id ep1_08_mall_games_fair_14f2722a
        show ep1 mon_arcade_julia_ent_silent_ice_happy with d
        simon "Same time next week?" id ep1_08_mall_games_fair_e9863322
        show ep1 mon_arcade_julia_ent_talks_ice_reg with d
        julia "Give me your number. I'll call you for a rematch!"
        show ep1 mon_arcade_julia_ent_silent_ice_reg with d
        simon "Okay!"
        show ep1 mon_arcade_julia_ent_talks_ice_happy with d
        julia "It's a date!" id ep1_08_mall_games_fair_bd5a3d16
        show ep1 mon_arcade_julia_play_talks_leaving with d

        julia "See you, Twinkle Toes!"
        $ ep1_win_arcade = True
        $ player_choice("ep1_win_arcade:true")

        jump ep1_08_mall_games_finale

    label ep1_08_mall_games_crush:
        show ep1 mon_arcade_both_play_talking with wipedown
        play sound game_sfx_1 volume 0.5
        julia "Damn, you're fast!" id ep1_08_mall_games_crush_72ad6596
        pause 0.5
        play sound game_sfx_2 volume 0.5
        simon "I'm just getting started." id ep1_08_mall_games_crush_579d82f0
        show ep1 mon_arcade_both_play_toughpart with d
        play sound game_sfx_6 volume 0.5
        julia "Oh, boy. Here comes the tough part!" id ep1_08_mall_games_crush_8714a88d
        show ep1 mon_arcade_both_play_simonwins with vpunch
        play sound game_sfx_9 volume 0.5
        ep1_arcade_machine "[name!u] WINS!" (what_bold=True)
        show ep1 mon_arcade_julia_play_talks_sad with d
        julia "Ouch..." id ep1_08_mall_games_crush_72e04642
        julia "It seems I've underestimated you..." id ep1_08_mall_games_crush_46f72d54
        show ep1 mon_arcade_julia_play_talks_serious with d
        julia "How'd you do it?" id ep1_08_mall_games_crush_5a465aa4
        julia "Were you cheating or something?" id ep1_08_mall_games_crush_2faa53fd
        show ep1 mon_arcade_simon_ent_talks_confident with d
        simon "I'm just that good." id ep1_08_mall_games_crush_4d6d8cd8
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "Then you don't deserve a prize!" id ep1_08_mall_games_crush_a18ba87f
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "It wasn't a fair game." id ep1_08_mall_games_crush_3ecc2376
        show ep1 mon_arcade_simon_play_talks_prize with d
        simon "Oh, come on. I didn't cheat!" id ep1_08_mall_games_crush_de7c0cb1
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "No, but from the way you move, you must be a pro or something." id ep1_08_mall_games_crush_04514f00
        show ep1 mon_arcade_simon_play_talks_reg with d
        simon "I've been playing this game forever." id ep1_08_mall_games_crush_9dc16dba
        show ep1 mon_arcade_simon_play_silent_thinking with d
        simon "(I think...)" id ep1_08_mall_games_crush_85731982
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "Well, that explains it!" id ep1_08_mall_games_crush_a3931897
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "I only really started playing last year." id ep1_08_mall_games_crush_4920d383
        julia "... It's pretty big in Japan, you know." id ep1_08_mall_games_crush_4d7aea7a
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Oh, yeah. I bet they're pretty good over there." id ep1_08_mall_games_crush_e98f23de
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "They are. I learned from the best." id ep1_08_mall_games_crush_431882a1
        stop music fadeout 2
        julia "I got really good when I lived in Tokyo." id ep1_08_mall_games_crush_8f59a75c
        show ep1 mon_arcade_simon_play_talks_surprised with d
        simon "You went to Japan to learn a game?" id ep1_08_mall_games_crush_cf3cb9b6
        show ep1 mon_arcade_julia_play_talks_serious with d
        julia "No, of course not!" id ep1_08_mall_games_crush_c74cc1d6
        play music red_light_boogie volume 0.2
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "I went there to study the language." id ep1_08_mall_games_crush_12486347
        julia "I also tried to get a part-time job while I was at it." id ep1_08_mall_games_crush_7813901d
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Oh, that sounds cool." id ep1_08_mall_games_crush_e1f3fb5c
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "Yeah, but things didn't work out as planned." id ep1_08_mall_games_crush_0847d4e6
        julia "So, it's back to work here." id ep1_08_mall_games_crush_2735dead
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "Which reminds me, I've probably got a meeting or something." id ep1_08_mall_games_crush_45723e82


        show ep1 mon_arcade_flashback_01 with d
        julia "Another day of spreadsheets and reports." id ep1_08_mall_games_crush_d99efd7e
        julia "Big numbers. Lots of math."

        show ep1 mon_arcade_flashback_02 with d
        julia "And nonstop meetings."

        show ep1 mon_arcade_simon_ent_silent_thinking with d
        simon "(Sounds like any old job to me.)"
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "It was cool playing with you though." id ep1_08_mall_games_crush_6288a19f
        show ep1 mon_arcade_julia_play_talks_happy with d
        julia "Next time, I'll be better. You can count on that!" id ep1_08_mall_games_crush_dfdd1912
        julia "Then we can talk prizes." id ep1_08_mall_games_crush_0a4cd5c4
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "Give me your number. I'll call you for a rematch!"
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Okay!"
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "See you around!" id ep1_08_mall_games_crush_fe680808
        show ep1 mon_arcade_julia_ent_silent_leaving with d
        simon "Yep, see you..." id ep1_08_mall_games_crush_01168573
        $ ep1_win_arcade = True
        $ player_choice("ep1_win_arcade:true")

        jump ep1_08_mall_games_finale

    label ep1_08_mall_games_lose:
        show ep1 mon_arcade_both_play_talking with wipeleft
        play sound game_sfx_1 volume 0.5
        julia "Hahaha. I thought you might at least TRY!" id ep1_08_mall_games_lose_e1f46005
        pause 0.5
        play sound game_sfx_error  volume 3
        simon "..."
        pause 0.5
        play sound game_sfx_2 volume 0.5
        julia "This is like taking candy from a baby!" id ep1_08_mall_games_lose_0d8fd4ef
        pause 0.5
        play sound game_sfx_error volume 3
        simon "..."
        show ep1 mon_arcade_both_play_toughpart with d
        play sound game_sfx_6 volume 0.5
        julia "Bwahahaha. If I had known you'd be this bad, I would have played with my eyes shut!" id ep1_08_mall_games_lose_a5c9c97b
        show ep1 mon_arcade_both_play_juliawins with vpunch
        play sound game_sfx_9 volume 0.5
        ep1_arcade_machine "JULIA WINS!" (what_bold=True)
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "I hope you're not a sore loser!" id ep1_08_mall_games_lose_8a8a2142
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "(This girl's got an attitude on her!)" id ep1_08_mall_games_lose_761d96ce

        menu:
            "Ask for a rematch":
                show ep1 mon_arcade_simon_play_talks_reg with d
                simon "All right. Let's go once more." id ep1_08_mall_games_lose_1bf70ccf
                show ep1 mon_arcade_julia_play_talks_teasing with d
                julia "Isn't one public humiliation enough?" id ep1_08_mall_games_lose_defdfa60
                julia "Well, your funeral." id ep1_08_mall_games_lose_154c90bb
                jump ep1_08_mall_games_crush
            "Don't say anything":
                pass
        show ep1 mon_arcade_julia_play_talks_queen with d
        julia "Still the queen, baby!" id ep1_08_mall_games_lose_a0f9e87d
        show ep1 mon_arcade_julia_play_talks_teasing with d
        julia "But you've got talent. That, I can see." id ep1_08_mall_games_lose_6eae4243
        show ep1 mon_arcade_julia_play_talks_happy with d
        julia "Maybe we should give it another go." id ep1_08_mall_games_lose_4647e779
        stop music fadeout 4
        julia "Another time, that is." id ep1_08_mall_games_lose_a9f4efea
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "I should be getting back to work." id ep1_08_mall_games_lose_44f1fb94


        show ep1 mon_arcade_flashback_01 with d
        julia "Another day of spreadsheets and reports awaits." id ep1_08_mall_games_lose_3a5db966
        julia "Big numbers. Lots of math."

        show ep1 mon_arcade_flashback_02 with d
        julia "And nonstop meetings."

        show ep1 mon_arcade_simon_ent_silent_thinking with d
        simon "(Sounds like a pretty ordinary job.)"
        play music red_light_boogie volume 0.15
        julia "But I'm not going anywhere without my prize, of course." id ep1_08_mall_games_lose_3ffd18bb
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Oh, I forgot all about that." id ep1_08_mall_games_lose_12fcc48d
        simon "So, what is thy bidding, my queen?" id ep1_08_mall_games_lose_b217342e
        show ep1 mon_arcade_julia_play_talks_happy with d
        julia "Oh, that's just how I like it!" id ep1_08_mall_games_lose_2fa48006
        julia "You were holding back, weren't you?" id ep1_08_mall_games_lose_19b69e96
        show ep1 mon_arcade_simon_play_talks_oops with d
        simon "Whaaat? No way..." id ep1_08_mall_games_lose_8d9ab02e
        show ep1 mon_arcade_julia_play_talks_serious with d
        julia "Sure you weren't..." id ep1_08_mall_games_lose_fad5ec86
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "Let's play again next week." id ep1_08_mall_games_lose_0afc55fd
        show ep1 mon_arcade_julia_play_talks_happy with d
        julia "That's my bidding." id ep1_08_mall_games_lose_f66aebbb
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Your wish is my command." id ep1_08_mall_games_lose_c5b7b341
        show ep1 mon_arcade_julia_play_talks_reg with d
        julia "Give me your number. I'll call you for a rematch!"
        show ep1 mon_arcade_julia_play_silent_reg with d
        simon "Okay!"
        show ep1 mon_arcade_julia_play_talks_leaving with d
        julia "All right. Gotta go now." id ep1_08_mall_games_lose_8c3d6a51
        show ep1 mon_arcade_julia_ent_silent_leaving with d
        julia "See you, Twinkle Toes!"
        simon "See you, Julia!" id ep1_08_mall_games_lose_4806190c
        $ ep1_win_arcade = False
        $ player_choice("ep1_win_arcade:false")

        jump ep1_08_mall_games_finale


label ep1_08_mall_games_finale:
    show ep1 mon_arcade_simon_ent_leaving with d
    stop music fadeout 4
    simon "(I'd better get going too.)" id ep1_08_mall_games_finale_b4db878c
    simon "(I still have some time to kill.)" id ep1_08_mall_games_finale_90c3b752
    play sound door_shop_bell
    $ went_games = True
    jump ep1_05_mall_fr

    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
