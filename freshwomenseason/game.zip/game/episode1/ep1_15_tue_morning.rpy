label ep1_15_tue_morning:
    stop music fadeout 2

    simon "(Too bad it was only a dream...)" id ep1_15_tue_morning_e84f46e0
    stop sound fadeout 0.5
    show ep1 tue_simonhome_thinking with d
    simon "(I have to check in with Susan later at the mall.)" id ep1_15_tue_morning_28edd7f1
    simon "(I guess I should take the afternoon to check the campus out.)" id ep1_15_tue_morning_2a81329c
    simon "(I'm sure they'll have a bunch of documents for me to sign, so I should get that out of the way as soon as possible.)" id ep1_15_tue_morning_6302fabd
    stop sound fadeout 1

    show ep1 tue_busstop_wondersue with wipeleft
    simon "(I wonder if I'll see Sue again.)" id ep1_15_tue_morning_9b274f84
    simon "(She scares me.)" id ep1_15_tue_morning_b00c2ec1
    simon "(The campus isn't that far away. The walk won't kill me.)" id ep1_15_tue_morning_f79b4a4d
    show ep1 tue_campus_notbad with fade
    play music journey volume 0.5
    simon "(This place doesn't look so bad.)" id ep1_15_tue_morning_dcfef56b
    simon "(I'll just drop these off and take a walk around the campus.)" id ep1_15_tue_morning_823555c1
    show ep1 tue_campus_going1 with fade
    simon "(Where am I supposed to do that though?)" id ep1_15_tue_morning_37297230
    show ep1 tue_campus_going2 with fade
    simon "(Maybe here?)" id ep1_15_tue_morning_9b762650
    simon "(Nope.)" id ep1_15_tue_morning_0b5c5a47
    show ep1 tue_campus_going3 with fade
    simon "(This looks like the right place.)" id ep1_15_tue_morning_921f6798
    simon "(Wrong again.)" id ep1_15_tue_morning_b2c87db1
    show ep1 tue_campus_nosigns with wipeleft
    simon "(There are no signs showing me where to go.)" id ep1_15_tue_morning_cb05cc6b
    stop music fadeout 2
    show ep1 tue_campus_sitbench with d
    simon "(Maybe I should ask for help.)" id ep1_15_tue_morning_c45b2f6b
    show ep1 tue_campus_benchsimon_huh with d
    simon "Huh?" id ep1_15_tue_morning_196da51b
    jump ep1_16_college_dylan
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
