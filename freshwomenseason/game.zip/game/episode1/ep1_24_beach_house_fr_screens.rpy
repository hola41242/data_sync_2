screen ep1_fr_bh_multi_ent():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (732, 205, 452, 671) action MoveTo('ep1_fr_bh_multi_maindoor')
        hotspot (1500, 737, 236, 270) action StartEvent('ep1_24_bhfr_suitglass')

screen ep1_fr_bh_multi_maindoor():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (1501, 5, 416, 1067) action MoveTo('ep1_fr_bh_multi_hall2')
        hotspot (0, 5, 500, 1065) action MoveTo('ep1_fr_bh_multi_hall3')
        hotspot (581, 93, 467, 940) action MoveTo('ep1_fr_bh_multi_livingroom')

screen ep1_fr_bh_multi_hall2():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (1694, 0, 223, 1077) action MoveTo('ep1_fr_bh_multi_maindoor')


        if chose('ep1_susan_key'):
            if chose('ep1_tried_susan_key'):
                hotspot (574, 0, 948, 1079) action MoveTo('ep1_fr_bh_multi_suitcaseroom')
            else:
                hotspot (574, 0, 948, 1079) action StartEvent('ep1_fr_bh_multi_hall2_unlock')
        else:
            hotspot (574, 0, 948, 1079) action StartEvent('ep1_fr_bh_multi_hall2_locked')

screen ep1_fr_bh_multi_suitcaseroom():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (698, 426, 507, 653) action StartEvent('ep1_24_bhfr_exit')
        hotspot (1638, 0, 280, 1076) action MoveTo('ep1_fr_bh_multi_hall2')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 1478 ypos 705

screen ep1_fr_bh_multi_hall3():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (1516, 804, 399, 270) action MoveTo('ep1_fr_bh_multi_maindoor')
        hotspot (232, 0, 655, 1079) action MoveTo('ep1_fr_bh_multi_smallbathroom')
        hotspot (1124, 142, 309, 935) action MoveTo('ep1_fr_bh_multi_storage')


screen ep1_fr_bh_multi_smallbathroom():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (447, 890, 1035, 189) action MoveTo('ep1_fr_bh_multi_hall3')
        if is_event_new('ep1_24_bhfr_mask'):
            hotspot (944, 663, 409, 161) action StartEvent('ep1_24_bhfr_mask')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 934 ypos 549

screen ep1_fr_bh_multi_storage():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (472, 874, 475, 205) action MoveTo('ep1_fr_bh_multi_hall3')
        if is_event_new('ep1_24_bhfr_mannequin'):
            hotspot (202, 192, 586, 604) action StartEvent('ep1_24_bhfr_mannequin')
        if is_event_new('ep1_24_bhfr_dildos'):
            hotspot (789, 189, 813, 321) action StartEvent('ep1_24_bhfr_dildos')
        if is_event_new('ep1_24_bhfr_boxes'):
            hotspot (975, 526, 649, 553) action StartEvent('ep1_24_bhfr_boxes')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 546 ypos 166

screen ep1_fr_bh_multi_livingroom():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (627, 880, 842, 197) action MoveTo('ep1_fr_bh_multi_maindoor')
        hotspot (6, 2, 240, 1068) action MoveTo('ep1_fr_bh_multi_bedroom')
        hotspot (1660, 3, 258, 1076) action MoveTo('ep1_fr_bh_multi_kitchen')
        hotspot (789, 323, 352, 361) action MoveTo('ep1_fr_bh_multi_piano')
        if is_event_new('ep1_24_bhfr_painting'):
            hotspot (547, 268, 212, 270) action StartEvent('ep1_24_bhfr_painting')

screen ep1_fr_bh_multi_piano():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (443, 887, 1035, 190) action MoveTo('ep1_fr_bh_multi_livingroom')
        if is_event_new('ep1_24_bhfr_portrait'):
            hotspot (1356, 10, 317, 355) action StartEvent('ep1_24_bhfr_portrait')
        if is_event_new('ep1_24_bhfr_playpiano'):
            hotspot (239, 542, 1521, 332) action StartEvent('ep1_24_bhfr_playpiano')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 328 ypos 208

screen ep1_fr_bh_multi_kitchen():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()




        hotspot (619, 883, 852, 196) action MoveTo('ep1_fr_bh_multi_livingroom')
        if is_event_new('ep1_24_bhfr_kitchen2'):
            hotspot (0, 2, 1604, 522) action StartEvent('ep1_24_bhfr_kitchen2')
        if is_event_new('ep1_24_bhfr_trash'):
            hotspot (1645, 679, 211, 337) action StartEvent('ep1_24_bhfr_trash')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 0 ypos 654

screen ep1_fr_bh_multi_bedroom():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (537, 883, 715, 194) action MoveTo('ep1_fr_bh_multi_livingroom')
        hotspot (1178, 0, 349, 491) action MoveTo('ep1_fr_bh_multi_outside')
        if is_event_new('ep1_24_bhfr_phone'):
            hotspot (1352, 756, 386, 320) action StartEvent('ep1_24_bhfr_phone')
        if is_event_new('ep1_24_bhfr_vibrator'):
            hotspot (1623, 382, 224, 212) action StartEvent('ep1_24_bhfr_vibrator')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 1060 ypos 723

screen ep1_fr_bh_multi_outside():
    tag free_roam
    imagemap:
        idle get_screen_idle_name()
        hover get_screen_hover_name()

        hotspot (390, 879, 603, 197) action MoveTo('ep1_fr_bh_multi_bedroom')


        if is_event_new('ep1_24_bhfr_book'):
            hotspot (1125, 484, 133, 123) action StartEvent('ep1_24_bhfr_book')
        if is_event_new('ep1_24_bhfr_stairs'):
            hotspot (2, 623, 288, 456) action StartEvent('ep1_24_bhfr_stairs')
        if is_event_new('ep1_24_bhfr_view'):
            hotspot (1, 2, 1913, 453) action StartEvent('ep1_24_bhfr_view')

        if screen_has_reward():
            imagebutton auto get_reward_button_name() action CollectReward() xpos 894 ypos 607
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
