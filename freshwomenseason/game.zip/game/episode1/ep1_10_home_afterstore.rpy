label ep1_10_home_afterstore:


    show ep1 mon_simonhome_afternoon with long_fade
    simon "(What a day!)" id ep1_10_home_afterstore_0c6e909c
    show ep1 mon_simonhome_afternoon_thinking with fade
    play music calm volume 0.5
    simon "(It was nice meeting Julia at the arcade.)" id ep1_10_home_afterstore_ec4ecb88
    show ep1 mon_simonhome_afternoon_julia with medium_fade
    menu:
        "She sure is fun"(True):
            $ points_julia += 2
        "She's hot":
            $ points_julia += 1
        "She's a bit too competitive":
            pass
    show ep1 mon_simonhome_afternoon_chloe with medium_fade
    simon "(And Chloe from the library...)" id ep1_10_home_afterstore_150add84
    menu:
        "She seems smart"(True):
            $ points_chloe += 2
        "She's hot":
            $ points_chloe += 1
        "She's a bit too nerdy":
            pass
    show ep1 mon_simonhome_afternoon_alyssa with medium_fade
    simon "(And of course, Alyssa at the café...)" id ep1_10_home_afterstore_182b4ea8
    menu:
        "She's so kind"(True):
            $ points_alyssa += 2
        "She's hot":
            $ points_alyssa += 1
        "She seems way too busy":
            pass
    show ep1 mon_simonhome_afternoon_susan with medium_fade
    simon "(Susan seems a bit too serious, but...)" id ep1_10_home_afterstore_48677cb3
    menu:
        "There's something interesting about her"(True):
            $ points_susan += 2
        "She's hot":
            $ points_susan += 1
        "No, she's too serious":
            pass
    show ep1 mon_simonhome_afternoon_sue with medium_fade
    simon "(And Sue, well...)" id ep1_10_home_afterstore_dff977cc
    menu:
        "She's a total mystery"(True):
            $ points_sue += 2
        "She's hot":
            $ points_sue += 1
        "She scares me":
            pass
    show ep1 mon_simonhome_afternoon_tired with medium_fade
    stop music fadeout 3
    simon "(It's barely after noon, but I'm already pretty tired.)" id ep1_10_home_afterstore_ff00e528
    show ep1 mon_simonhome_afternoon_resting with d
    simon "(I should get some rest.)" id ep1_10_home_afterstore_ffa160ee
    show ep1 mon_simonhome_afternoon_resting2 with long_fade
    play music sweet_crop volume 0.5
    pause
    show ep1 mon_simonhome_afternoon_wakesup with d
    simon "(I guess I really was tired.)" id ep1_10_home_afterstore_05c88a2e
    simon "(Man, it's hot in here...)" id ep1_10_home_afterstore_89b001cf
    simon "(I need a shower.)" id ep1_10_home_afterstore_60417308
    show ep1 mon_simonhome_afternoon_shower with d
    simon "Oh, shit." id ep1_10_home_afterstore_7484b521
    simon "(I forgot to buy a towel.)" id ep1_10_home_afterstore_9ac45bff
    show ep1 mon_simonhome_afternoon_forgot with d
    simon "Shit." id ep1_10_home_afterstore_0ae78473
    show ep1 mon_simonhome_afternoon_dry with d
    simon "Dammit." id ep1_10_home_afterstore_ffaa8237
    show ep1 mon_simonhome_afternoon_dry2 with d
    simon "Not again." id ep1_10_home_afterstore_869d4e1e
    show ep1 mon_simonhome_afternoon_checksphone with d
    simon "(Lily told me to text her when I got back from the mall if I needed anything.)" id ep1_10_home_afterstore_dd6f5324
    show ep1 mon_simonhome_afternoon_gettingready with d
    simon "(Maybe she can help me out.)" id ep1_10_home_afterstore_5e33db26

    jump ep1_11_meet_emily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
