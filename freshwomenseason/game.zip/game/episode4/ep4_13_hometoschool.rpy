
label ep4_13_hometoschool:


    play music train_ride fadein 2 volume 0.32

    if choice_made('ep4_suetalk_so_lets_go') or choice_made_skip_debug('ep4_suetalk_you_better_drive'):

        show ep4 hometoschool_001 with long_fade


        sue "Here we are. Home sweet home." id ep4_13_hometoschool_135882b6

        if choice_made('ep4_sue_invite'):
            show ep4 hometoschool_002 with d
            sue "Well, for now at least." id ep4_13_hometoschool_ce66260f
            show ep4 hometoschool_003 with d
            sue "I'll come pick you up later tonight." id ep4_13_hometoschool_70638ae8
            show ep4 hometoschool_004 with d
            simon "Thanks, Sue." id ep4_13_hometoschool_1b5715b2
            show ep4 hometoschool_005 with d
            sue "I hope you enjoy cooking and cleaning." id ep4_13_hometoschool_51711806
            show ep4 hometoschool_006 with d
            simon "Wait. That's not what we agreed on." id ep4_13_hometoschool_613d3e26
            show ep4 hometoschool_007 with d
            sue "My house, my rules." id ep4_13_hometoschool_e5382e50
            play sound engine
            show ep4 hometoschool_008 with d
            simon "What the...?" id ep4_13_hometoschool_2f7e4b1f
            show ep4 hometoschool_009 with d
            sue "See you when I see you!" id ep4_13_hometoschool_9d8f0ac6
        else:

            show ep4 hometoschool_010 with d
            simon "(Yep. Home...)" id ep4_13_hometoschool_67936028
            show ep4 hometoschool_011 with d
            sue "So, what are you waiting for?" id ep4_13_hometoschool_abd64dba
            show ep4 hometoschool_012 with d
            simon "Oh, right." id ep4_13_hometoschool_fed060c5
            show ep4 hometoschool_013 with d
            simon "I'll just get changed and catch the bus from here." id ep4_13_hometoschool_588bbb47
            show ep4 hometoschool_014 with d
            sue "See you later, [name]." id ep4_13_hometoschool_8bcd46dc
            play sound engine
            show ep4 hometoschool_015 with d
            simon "See you..." id ep4_13_hometoschool_cc1cc23f

        $ debug_other_path()

    show ep4 hometoschool_016 with wipeleft
    simon "(Today's a very important day.)" id ep4_13_hometoschool_5a125518
    show ep4 hometoschool_017 with d
    simon "(Still, being back inside these four walls leaves me with this gross feeling.)" id ep4_13_hometoschool_5d0456ef
    show ep4 hometoschool_018 with d
    simon "(Hmm...)" id ep4_13_hometoschool_b9c55da2
    show ep4 hometoschool_019 with d
    simon "(This is Emily's apartment.)" id ep4_13_hometoschool_a5c826d7
    show ep4 hometoschool_020 with d
    simon "(And my key.)" id ep4_13_hometoschool_78762236
    show ep4 hometoschool_021 with d
    simon "(I wonder if...?)" id ep4_13_hometoschool_c97c33fe

    menu:
        "Try the key"(True):
            $ ep4_hometoschool_test_the_key = True
            $ player_choice("ep4_hometoschool_test_the_key:true")
            show ep4 hometoschool_022 with d
            simon "(Let's see...)" id ep4_13_hometoschool_58e9919e
            show ep4 hometoschool_023 with d
            simon "(It fits!)" id ep4_13_hometoschool_80ad8d26
            play sound door_locking 
            show ep4 hometoschool_024 with d
            simon "(But it won't turn.)" id ep4_13_hometoschool_d0fd080b
            show ep4 hometoschool_025 with d
            simon "(Same as the other key I tried on my door.)" id ep4_13_hometoschool_917efadf
            show ep4 hometoschool_026 with d
            simon "(So, does the other key she gave me open the door to her room?)" id ep4_13_hometoschool_d0628120
            show ep4 hometoschool_027 with d
            simon "(That certainly sounds like something Emily might do.)" id ep4_13_hometoschool_8bffa446
        "Don't try it":

            $ ep4_hometoschool_do_not_test = True
            $ player_choice("ep4_hometoschool_do_not_test:true")
            simon "(Nah, better not.)" id ep4_13_hometoschool_6f458b7b
            show ep4 hometoschool_027 with d
            simon "(The less I get involved with Emily, the better.)" id ep4_13_hometoschool_9bc4cedd



    show ep4 hometoschool_029 with d
    simon "(Well, at least my key still works.)" id ep4_13_hometoschool_cb250acf
    show ep4 hometoschool_030 with d
    simon "(Now, all I have to do is check and see if someone's here this time.)" id ep4_13_hometoschool_a29c452d
    play sound car_door_open
    show ep4 hometoschool_031 with d
    show ep4 hometoschool_031_1 with d
    show ep4 hometoschool_031 with d
    simon "Hmm..." id ep4_13_hometoschool_92c095c3
    show ep4 hometoschool_032 with d
    simon "(Good.)" id ep4_13_hometoschool_0d8bf056
    simon "(No one here.)" id ep4_13_hometoschool_128252dd
    show ep4 hometoschool_033 with d
    simon "(That's how it should be.)" id ep4_13_hometoschool_efae6e41
    play sound bed_movement_1
    show ep4 hometoschool_034 with d
    simon "(Finally, some time to clear my mind.)" id ep4_13_hometoschool_fc383c6e
    play sound phone_vibrate2 volume 0.6
    show ep4 hometoschool_035 with d
    simon "(I spoke too soon.)" id ep4_13_hometoschool_95edfd08
    stop sound
    show ep4 hometoschool_036 with d
    simon "Hello?" id ep4_13_hometoschool_c2baa3e3
    show ep4 hometoschool_037 with d
    simon "Oh! Hey, Alyssa!" id ep4_13_hometoschool_ad90a9e2
    show ep4 hometoschool_038 with d
    alyssa "Hi, [name]!" id ep4_13_hometoschool_843e39cd
    alyssa "I remembered you saying today's your first day of class, so I wanted to congratulate you!" id ep4_13_hometoschool_35b7a021
    show ep4 hometoschool_039 with d
    alyssa "Excited?" id ep4_13_hometoschool_30890175
    show ep4 hometoschool_040 with d
    simon "Excited might not be the right word..." id ep4_13_hometoschool_a8f55e86
    show ep4 hometoschool_041 with d
    alyssa "Oh yeah? Did something happen?" id ep4_13_hometoschool_ff95ea21
    show ep4 hometoschool_042 with d
    simon "Yeah... A small problem with my living situation." (what_italic=True)
    show ep4 hometoschool_043 with d
    alyssa "Oh. That sounds serious." id ep4_13_hometoschool_eeced86e
    alyssa "What happened?" id ep4_13_hometoschool_7ec1588d
    show ep4 hometoschool_044 with d
    simon "I just have to find another place to live..." id ep4_13_hometoschool_4e1505d5
    show ep4 hometoschool_045 with d
    simon "... Quite soon too." id ep4_13_hometoschool_b4e2138e
    show ep4 hometoschool_043 with d
    alyssa "Oh no!" id ep4_13_hometoschool_d1c107ed
    alyssa "But why?" id ep4_13_hometoschool_0192a31a
    show ep4 hometoschool_046 with d
    alyssa "You're making me worried!" id ep4_13_hometoschool_7fefce9b
    show ep4 hometoschool_047 with d
    simon "No, no. Nothing to worry about." (what_italic=True)
    simon "I'll survive." (what_italic=True)
    show ep4 hometoschool_048 with d
    alyssa "Have you checked the college dorms?" id ep4_13_hometoschool_9653be14
    show ep4 hometoschool_049 with d
    simon "I thought about them before coming here." id ep4_13_hometoschool_e16b51d5
    simon "I was told the college usually takes a week to have them looked into." id ep4_13_hometoschool_c98d4812
    show ep4 hometoschool_050 with d
    simon "My case is a little more... urgent." id ep4_13_hometoschool_6b6360b6
    show ep4 hometoschool_051 with d
    alyssa "My goodness..." id ep4_13_hometoschool_0b5a80aa
    alyssa "So it is quite bad." id ep4_13_hometoschool_088c1c6c
    show ep4 hometoschool_052 with d

    alyssa "But please, don't let that ruin your big day!" id ep4_13_hometoschool_955b09fe

    if choice_made('points_alyssa', 5):
        $ ep4_alyssa_invite = True
        $ player_choice("ep4_alyssa_invite:true")
        show ep4 hometoschool_053 with d
        alyssa "I actually called to ask a favor, but now I'm seeing this as a good opportunity for something else." id ep4_13_hometoschool_5993f769
        show ep4 hometoschool_054 with d
        simon "Oh really? What's the favor?" (what_italic=True)
        show ep4 hometoschool_055 with d
        alyssa "Well, before we get to that, I might have a solution to your problem." id ep4_13_hometoschool_9adf736b
        show ep4 hometoschool_056 with d
        alyssa "You could always stay at the dance studio if it's just for a few days." id ep4_13_hometoschool_889d8d43

        alyssa "It's not much, but it has a bathroom and a place to sleep." id ep4_13_hometoschool_8fb064ff
        show ep4 hometoschool_058 with d
        simon "Wow!" id ep4_13_hometoschool_fbac6252
        simon "Seriously? Could I really stay there?" id ep4_13_hometoschool_20acb71e
        show ep4 hometoschool_059 with d
        alyssa "Of course! But you don't have to commit to staying right now." id ep4_13_hometoschool_5aeb9267
        show ep4 hometoschool_060 with d
        alyssa "In fact, I think I should lead with the favor I've got to ask." id ep4_13_hometoschool_e7774363
    else:

        show ep4 hometoschool_055 with d
        alyssa "I'm sure you'll figure it out." id ep4_13_hometoschool_97457e73
        show ep4 hometoschool_056 with d
        alyssa "You've come so far and accomplished so much!" id ep4_13_hometoschool_6b754494
        show ep4 hometoschool_061 with d
        simon "Yeah. I guess I have." id ep4_13_hometoschool_ccf4a630
        show ep4 hometoschool_062 with d
        simon "Anyway, how are things with you?" id ep4_13_hometoschool_2077ff30
        show ep4 hometoschool_060 with d
        alyssa "Oh, right!" id ep4_13_hometoschool_e9733bf1
        alyssa "I wanted to ask you a favor." id ep4_13_hometoschool_11b33cc2


    $ debug_other_path()
    show ep4 hometoschool_063 with d

    alyssa "So, this is the week of that event I mentioned." id ep4_13_hometoschool_8f5db0d1

    if choice_made('ep3_07_cafe2_agree_to_help'):
        show ep4 hometoschool_064 with d
        alyssa "So we have to start practicing." id ep4_13_hometoschool_c21f3193
    else:

        show ep4 hometoschool_065 with d
        alyssa "And I know you said you didn't want to participate, so I won't insist." id ep4_13_hometoschool_97007ab7
        show ep4 hometoschool_066 with d
        alyssa "But since you already know the moves, I started to wonder..." id ep4_13_hometoschool_e556d9be

    $ debug_other_path()

    show ep4 hometoschool_067 with d
    alyssa "Would you like to help during practice?" id ep4_13_hometoschool_88aa5756
    show ep4 hometoschool_068 with d
    simon "Uh, how can I help?" id ep4_13_hometoschool_de881fba
    simon "You know a lot more than I do." id ep4_13_hometoschool_a92da3f4
    show ep4 hometoschool_069 with d
    alyssa "Um, actually... you did the move better." id ep4_13_hometoschool_e359e063
    show ep4 hometoschool_070 with d
    alyssa "Your posture was perfect." id ep4_13_hometoschool_0b55cc51
    alyssa "Much closer to the original." id ep4_13_hometoschool_16ef6441
    show ep4 hometoschool_071 with d
    simon "Really? But you said I had some things to work on." (what_italic=True)
    show ep4 hometoschool_072 with d
    alyssa "I was a little jealous of your natural talent... Maybe that's why I said those things." id ep4_13_hometoschool_7b813363
    show ep4 hometoschool_073 with d
    alyssa "But the truth is, it was nearly flawless." id ep4_13_hometoschool_8cc9a51e
    show ep4 hometoschool_074 with d
    simon "This event... Is it the charity ball?" id ep4_13_hometoschool_c12669d0
    show ep4 hometoschool_075 with d
    alyssa "Yeah! How'd you figure that out?" (what_italic=True)
    show ep4 hometoschool_076_1 with d
    pause
    show ep4 hometoschool_076 with d
    simon "Susan, the woman organizing the event, is my boss." id ep4_13_hometoschool_2d669a2e
    show ep4 hometoschool_077 with d
    alyssa "Oh, that makes sense." (what_italic=True)
    show ep4 hometoschool_078 with d
    simon "(Hmm... So it really is the same event.)" id ep4_13_hometoschool_30ccdb2f
    show ep4 hometoschool_079 with d
    simon "(Maybe I can find out a little more if I help Alyssa.)" id ep4_13_hometoschool_60026008
    show ep4 hometoschool_080 with d
    simon "Okay. I'll do what I can." id ep4_13_hometoschool_703713c2
    show ep4 hometoschool_081 with d
    alyssa "Really? That's awesome!" id ep4_13_hometoschool_dcb13e66
    show ep4 hometoschool_082 with d
    alyssa "There's just only one tiny problem..." id ep4_13_hometoschool_dc57bce8
    show ep4 hometoschool_083 with d
    simon "What would that be...?" id ep4_13_hometoschool_8be1b14a
    show ep4 hometoschool_084 with d
    alyssa "It has to be today." id ep4_13_hometoschool_4efcf5d3
    alyssa "Is that all right?" id ep4_13_hometoschool_1088ac9d
    show ep4 hometoschool_085 with d
    simon "Well, I have to go to class soon..." id ep4_13_hometoschool_09d5f22c
    show ep4 hometoschool_086 with d
    simon "But how about tonight." id ep4_13_hometoschool_79d275e8
    simon "Does that work for you?" id ep4_13_hometoschool_a2fefa51
    show ep4 hometoschool_087 with d
    alyssa "It's perfect! I'll be waiting." id ep4_13_hometoschool_75d935c2
    show ep4 hometoschool_088 with d
    simon "All right." (what_italic=True)
    show ep4 hometoschool_089 with d
    alyssa "Hmm." id ep4_13_hometoschool_a15bdfae
    simon "Alyssa? Did you say something?" (what_italic=True)
    show ep4 hometoschool_090 with d
    alyssa "Umm... No." id ep4_13_hometoschool_c65f18bf
    show ep4 hometoschool_091 with d
    alyssa "I just..." id ep4_13_hometoschool_3c9728b7
    show ep4 hometoschool_092 with d
    alyssa "I really hope we do well at this event." id ep4_13_hometoschool_ed4ace5a
    show ep4 hometoschool_093 with d
    alyssa "This would give the studio a lot of visibility." id ep4_13_hometoschool_c2f84079
    show ep4 hometoschool_094 with d
    alyssa "And god knows how much we need that." id ep4_13_hometoschool_a4faa346
    show ep4 hometoschool_095 with d
    simon "Well, I'll try my best." (what_italic=True)
    show ep4 hometoschool_094 with d
    alyssa "Thank you, [name]." id ep4_13_hometoschool_09345954
    show ep4 hometoschool_096 with d
    alyssa "See you later." id ep4_13_hometoschool_ec22ce71
    show ep4 hometoschool_097 with d
    alyssa "I really hope this works out." id ep4_13_hometoschool_e61b3d45
    show ep4 hometoschool_098 with d
    alyssa "I need this." id ep4_13_hometoschool_c222f675
    show ep4 hometoschool_099 with d
    if not_english():
        "Under New Management" (what_italic=True)
    else:
        pause
    jump ep4_14_dylanphone
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
