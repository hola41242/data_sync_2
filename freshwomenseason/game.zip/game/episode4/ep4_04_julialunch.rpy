
label ep4_04_julialunch:
    play music ido_mainman fadein 4.0 volume 0.45
    show ep4 julialunch_001 with wipeleft
    simon "(Oh, she's already here.)" id ep4_04_julialunch_606c14cf
    show ep4 julialunch_002 with d

    simon "Hi, Julia." id ep4_04_julialunch_d1bb5e67

    if choice_made('ep2_julia_kiss'):
        show ep4 julialunch_003 with d
        julia "Twinkle Toes!!" id ep4_04_julialunch_371804b6
        show ep4 julialunch_004 with d
        simon "(Oh...)" id ep4_04_julialunch_adc41a60

        menu:
            "Kiss Julia"(True):
                $ ep4_julialunch_kiss_julia = True
                $ player_choice("ep4_julialunch_kiss_julia:true")
                $ points_julia += 1
                show ep4 julialunch_005 with d
                pause
                show ep4 julialunch_006 with d
                julia "Oh..."
                show ep4 julialunch_007 with d
                julia "Hello, hello." id ep4_04_julialunch_fd210e8f
            "Hug Julia":

                $ ep4_julialunch_hug_julia = True
                $ player_choice("ep4_julialunch_hug_julia:true")
                show ep4 julialunch_008 with d
                julia "Oh..."
                show ep4 julialunch_009 with d
                julia "Well, hello there." id ep4_04_julialunch_c1be97ea
    else:

        show ep4 julialunch_010 with d
        julia "Hi, [name]!" id ep4_04_julialunch_986ab295




    julia "Your call caught me by surprise." id ep4_04_julialunch_d089c956

    show ep4 julialunch_012 with d
    julia "But I do have to say, this place is one hell of an improvement over that smelly old arcade!" id ep4_04_julialunch_3e5b53b0
    show ep4 julialunch_013 with d
    simon "You got that right!" id ep4_04_julialunch_921de464
    show ep4 julialunch_014 with d
    simon "Guess I still owe you for that day." id ep4_04_julialunch_0d789300
    show ep4 julialunch_015 with d
    julia "Umm... You're acting weird." id ep4_04_julialunch_91aeda3d
    show ep4 julialunch_016 with d
    julia "What's going on?" id ep4_04_julialunch_5bd4e6c2
    show ep4 julialunch_017 with d
    simon "I'll tell you everything once we're inside." id ep4_04_julialunch_646cf7b8
    play sound door_open3 volume 0.5
    play sound_2 restaurant_ambience1 fadein 2 volume 0.1
    show ep4 julialunch_018 with fade
    simon "(Of course, I couldn't tell her \"everything.\")"
    show ep4 julialunch_019 with d
    simon "(I only told her the parts she needed to understand my situation.)" id ep4_04_julialunch_7ab5a87e
    stop sound fadeout 3.0
    show ep4 julialunch_020 with d
    simon "(In the end, lunch was a lot more fun than I expected.)" id ep4_04_julialunch_82234201
    play sound plate_set_down_3 volume 0.3
    show ep4 julialunch_021 with d
    julia "So, if I've got this straight, you're basically homeless now, huh?" id ep4_04_julialunch_6ee0bccf
    julia "Or is this your idea of a new pickup line...?" id ep4_04_julialunch_92f23a0a
    show ep4 julialunch_022 with d
    julia "Like: Hey, pretty little thing, I'm homeless, so could I share your bed?" id ep4_04_julialunch_96f650b8
    show ep4 julialunch_023 with d
    simon "That's not quite how I'd word it..." id ep4_04_julialunch_06c1114d
    simon "... But, yeah, I'm basically homeless now." id ep4_04_julialunch_10774145
    show ep4 julialunch_024 with d
    simon "Don't worry though. This isn't my attempt at a cheap pickup line." id ep4_04_julialunch_5fd60add
    simon "And I'll be fine." id ep4_04_julialunch_59f1d8ac
    show ep4 julialunch_025 with d
    simon "What I'm most concerned about is what'll become of you after scarfing down all that dessert." id ep4_04_julialunch_3fe06f61
    show ep4 julialunch_026 with d
    julia "I don't have to worry myself with calories." id ep4_04_julialunch_7df95442
    julia "It all goes to my big genius brain." id ep4_04_julialunch_4538a99f
    show ep4 julialunch_027 with d
    simon "Ah, so you're a genius now, are you?" id ep4_04_julialunch_c5872bd8
    simon "That's fresh." id ep4_04_julialunch_49c49d6f
    show ep4 julialunch_028 with d
    julia "Of course I am!" id ep4_04_julialunch_96d83c4a
    julia "Just to give an example of my genius, I knew that Lily woman was going to be a pain in the ass." id ep4_04_julialunch_eaa8d10b
    show ep4 julialunch_029 with d

    if chose("ep4_lunch2_i_fucked_your_wife"):
        julia "But kicking you out when you did nothing wrong..." id ep4_04_julialunch_5bdbcb73
        julia "That's low." id ep4_04_julialunch_8a1db266
        show ep4 julialunch_030 with d
        simon "(Well, I did tell her husband I fucked his wife.)" id ep4_04_julialunch_b45a541d
    else:

        julia "But her husband is even more of a pain." id ep4_04_julialunch_f294d5ef
        julia "I bet he's just insecure about the fact she had a good-looking college guy living in her building." id ep4_04_julialunch_44a43a92
        show ep4 julialunch_030 with d
        simon "(That, and me almost getting into a fist fight with her husband.)" id ep4_04_julialunch_7722424f

    show ep4 julialunch_031 with d
    simon "(Not to mention the fact that I was spying on Lily.)" id ep4_04_julialunch_5b413b3f
    simon "(And that we had sex.)" id ep4_04_julialunch_cd0ec5be
    simon "(But you don't need to know all that, Julia.)" id ep4_04_julialunch_794b8133
    show ep4 julialunch_032 with d
    julia "Furthermore..." id ep4_04_julialunch_1887f6de
    simon "Huh?" id ep4_04_julialunch_196da51b
    show ep4 julialunch_033 with d
    julia "... That's not the only proof I've got of my genius." id ep4_04_julialunch_0d2fdcdf
    show ep4 julialunch_034 with d
    simon "Oh yeah? What else you got?" id ep4_04_julialunch_d7979061
    play sound fork_scrapeplate_3 volume 0.3
    show ep4 julialunch_035 with d
    julia "Remember when I told you I was on the college's waiting list?" id ep4_04_julialunch_2a9dbdbe
    show ep4 julialunch_036 with d
    simon "Yeah, I remember something like that." id ep4_04_julialunch_6d1105ab
    show ep4 julialunch_035 with d
    julia "Well, the thing is, I figured all that out, and now I'm in." id ep4_04_julialunch_f4746d59
    show ep4 julialunch_037 with d
    simon "Wow, Julia. That's awesome!" id ep4_04_julialunch_dfb2e8a0
    show ep4 julialunch_038 with d
    julia "And that's not all." id ep4_04_julialunch_a8005da8
    show ep4 julialunch_039 with d
    julia "Guess which college I'm going to?" id ep4_04_julialunch_db5c5e31
    show ep4 julialunch_040 with d
    simon "No way. Really?!" id ep4_04_julialunch_76ff1d76
    show ep4 julialunch_041 with d
    julia "YEP!" id ep4_04_julialunch_c0d2b2ae
    show ep4 julialunch_042 with d
    julia "So I guess you'll just have to see me again tomorrow." id ep4_04_julialunch_655eed2d
    show ep4 julialunch_043 with d
    simon "Umm... Tomorrow...?" id ep4_04_julialunch_b1d420d8
    show ep4 julialunch_044 with d
    julia "Yeah. You're coming tomorrow, right?" id ep4_04_julialunch_814f76af
    julia "To the first day of class?" id ep4_04_julialunch_6db0784b
    show ep4 julialunch_045 with d
    julia "Wait... You're coming, right?" id ep4_04_julialunch_a71768e2
    show ep4 julialunch_046 with d
    simon "Honestly, I'm not really sure..." id ep4_04_julialunch_c8576557
    show ep4 julialunch_047 with d
    simon "I don't even have a place to stay." id ep4_04_julialunch_a24393ef
    simon "Does it still make sense for me to go to class?" id ep4_04_julialunch_33a4b303
    simon "Wouldn't it be better to take care of everything else first?" id ep4_04_julialunch_72148d40
    play sound wood_hit volume 0.5 
    show ep4 julialunch_048 with vpunch
    julia "Listen here, [name]!" id ep4_04_julialunch_ff4b6928
    show ep4 julialunch_049 with d
    julia "Do you know how many people would kill to be in your shoes?" id ep4_04_julialunch_228747c8
    julia "Being able to get an education?" id ep4_04_julialunch_f9ce0365
    show ep4 julialunch_050 with d
    julia "You've also got a job, so you'll land on your feet." id ep4_04_julialunch_2e14c201
    show ep4 julialunch_051 with d


    julia "And what's more..." id ep4_04_julialunch_7e1ab921


    if choice_made('ep1_win_arcade'):
        julia "You're the best Dance Dance Supreme player in the whole wide world!" id ep4_04_julialunch_7a061b13
        julia "Even better than me, I must admit." id ep4_04_julialunch_7daf40a4
        show ep4 julialunch_052 with d
        julia "Have you ever thought about going pro?" id ep4_04_julialunch_a0518503
    else:

        julia "You're not too shabby at Dance Dance Supreme, I must admit." id ep4_04_julialunch_0e47f869
        show ep4 julialunch_053 with d
        julia "But of course, you're no match for the great Julia!" id ep4_04_julialunch_90360614

    $ debug_other_path()

    show ep4 julialunch_054 with d
    julia "Anyway. Do what you gotta do and get ready to see me on campus tomorrow." id ep4_04_julialunch_ae472589
    show ep4 julialunch_055 with d
    julia "And you'd better be excited about it." id ep4_04_julialunch_5bf24933
    julia "You deserve this." id ep4_04_julialunch_d8583ff6
    show ep4 julialunch_056 with d
    simon "Wow..." id ep4_04_julialunch_063ea2e3
    show ep4 julialunch_057 with d
    simon "(I think she's right.)" id ep4_04_julialunch_4647c8a4
    show ep4 julialunch_058 with d
    simon "(With all of Julia's yelling, I thought we were going to get kicked out.)" id ep4_04_julialunch_e5d6f66f
    show ep4 julialunch_059 with d
    simon "(Thankfully, they didn't really seem to care.)" id ep4_04_julialunch_3ad969a5
    show ep4 julialunch_060 with d
    simon "(I've already been kicked to the curb once today. Once more wouldn't hurt.)" id ep4_04_julialunch_04579ae7
    play sound bottlewine_set_down volume 0.5
    stop sound_2 fadeout 3
    show ep4 julialunch_061 with d
    simon "(It's time to start thinking about what really matters.)" id ep4_04_julialunch_ed6b757b
    stop music fadeout 4
    show ep4 julialunch_062 with fade
    simon "(Time to head home — while I still have one.)" id ep4_04_julialunch_1f1c7ca2
    jump ep4_05_emilyvisit
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
