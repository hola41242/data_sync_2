
label ep4_07_dream:
    play music dreamland fadein 3 volume 0.4
    show ep4 dream_001 with long_fade
    simon "(I have to go see Susan.)" id ep4_07_dream_9369834f
    simon "(She said she wants to \"have a talk\" with me.)"
    simon "(Wait. How did I get here?)" id ep4_07_dream_09687cb8
    show ep4 dream_002 with d
    simon "(Oh, I'm dreaming.)" id ep4_07_dream_7ff3df35
    simon "(Will I see Emily again?)" id ep4_07_dream_e839d908

    if not choice_made('red_drink'):
        play sound coming_angel volume 0.25
        show ep4 dream_002_1 with d
        simon "..." id ep4_07_dream_ba28090a
        pause 0.5
        show ep4 dream_003_1 with d
        pause 0.5
        show ep4 dream_003 with d
        angela "Emily? Who's Emily?" id ep4_07_dream_a9e3537b
        show ep4 dream_004 with d
        simon "Oh! Hi, Angela." id ep4_07_dream_0641f17c
        show ep4 dream_005 with d
        simon "Wait, Angela?! What are you doing in my dream?" id ep4_07_dream_fd9bfd3a
        show ep4 dream_006 with d
        angela "It was you who called me here." id ep4_07_dream_18c0ac2b
        show ep4 dream_007 with d
        simon "How so?" id ep4_07_dream_58bb722e
        show ep4 dream_006_1 with d
        angela "Back when you chose the blue drink..." id ep4_07_dream_4c70f695
        angela "That was your subconscious saying you want me." id ep4_07_dream_0f96f310
        show ep4 dream_008 with d
        simon "Right..." id ep4_07_dream_41326fcf
        show ep4 dream_009 with d
        angela "Basically, I'm your consciousness manifest, and this is the shape I took." id ep4_07_dream_0d5be828
        show ep4 dream_009_1 with d
        simon "I like this shape." id ep4_07_dream_4b66f6e7
        show ep4 dream_010 with d
        simon "If we're in a dream, does that mean I can do..." id ep4_07_dream_bd6a35ef
        show ep4 dream_011 with d
        simon "... whatever I want?" id ep4_07_dream_a368f7dc
        show ep4 dream_012 with d
        angela "Yes! So today we're going to face your fears!" id ep4_07_dream_792ea943
        angela "Your boss is waiting for you." id ep4_07_dream_9832b03f
        show ep4 dream_008_1 with d
        simon "Are you serious?" id ep4_07_dream_3b7038ff
        show ep4 dream_006 with d
        angela "Absolutely! After all, your conscience is showing you the way." id ep4_07_dream_c4241b1e
        show ep4 dream_013 with d
        angela "Off you go!" id ep4_07_dream_ed5c8f0d
    else:

        play sound booom
        show ep4 dream_014 with vpunch
        devilla "And who the fuck is this Emily bitch?" (what_bold=True)
        show ep4 dream_015 with d
        simon "Huh? Devilla?" id ep4_07_dream_52bcefc1
        simon "What are you doing here?" id ep4_07_dream_30e5d247
        show ep4 dream_016 with d
        devilla "Look around you, boy." (what_bold=True)
        devilla "You died and went to hell." (what_bold=True)
        show ep4 dream_017 with d
        simon "What?!"
        show ep4 dream_018 with d
        simon "Hmm... Hell doesn't look so bad." id ep4_07_dream_adedd8ba
        show ep4 dream_019 with d
        simon "But what did I do to end up here?" id ep4_07_dream_760e7a77
        show ep4 dream_020 with d
        devilla "You drank the red drink. Remember?" (what_bold=True)
        show ep4 dream_021 with d
        devilla "Now, poof! Your conscience sent you straight to hell." (what_bold=True)
        show ep4 dream_022 with d
        simon "Right. Of course." id ep4_07_dream_8a26c9bc
        simon "Now, if you don't mind, I'm going to wake up from this dream real quick." id ep4_07_dream_09370435
        show ep4 dream_023 with d
        devilla "Wait. You're in hell." (what_bold=True)
        devilla "You have to suffer down here." (what_bold=True)
        show ep4 dream_024 with d
        devilla "Go talk to your boss." (what_bold=True)

    show ep4 dream_025 with Dissolve(1)
    simon "Shit. Let's get this over with then." id ep4_07_dream_d1581de5
    show ep4 dream_026 with d
    simon "Hello, Susan. I..." id ep4_07_dream_ed269bee
    show ep4 dream_027 with d
    susan "Hi, Charlie! It's a pity you couldn't make it today." id ep4_07_dream_ec66d7ce
    show ep4 dream_028 with d
    simon "(Charlie?)" id ep4_07_dream_f21ff88e
    show ep4 dream_029 with d
    susan "I want you here tomorrow though, just as soon as I'm done talking with you-know-who." id ep4_07_dream_93025913
    show ep4 dream_030 with d
    simon "(Is she talking about... my father?)" id ep4_07_dream_37077b4c
    show ep4 dream_031 with d
    susan "[name]?" id ep4_07_dream_bfb9526b
    show ep4 dream_032 with d
    simon "Oh. Hey." id ep4_07_dream_19ae6390
    show ep4 dream_033 with d
    susan "Why are you naked?" id ep4_07_dream_fac9c74f
    show ep4 dream_034 with vpunch
    simon "What?!"
    play sound evil_laugh volume 0.5
    show ep4 dream_035 with hpunch
    pause 2
    play sound impact
    stop music
    show ep4 dream_036 with vpunch
    simon "What?!" id ep4_07_dream_1f3d8403
    show ep4 dream_037 with d
    simon "Ah! It was just a dream." id ep4_07_dream_85effa9f

    jump ep4_08_susanphone
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
