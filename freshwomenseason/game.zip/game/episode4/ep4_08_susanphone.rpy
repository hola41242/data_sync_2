
label ep4_08_susanphone:
    show ep4 susanphone_001 with d
    simon "(She was right.)" id ep4_08_susanphone_f49e6fc0
    simon "(I have to talk to Susan.)" id ep4_08_susanphone_b9ef2d76
    show ep4 susanphone_002 with d
    simon "(Maybe she can help with work too.)" id ep4_08_susanphone_8c139319
    show ep4 susanphone_003 with d
    simon "(She probably isn't awake yet, so I'll just text her.)" id ep4_08_susanphone_a71a8130
    show ep4 susanphone_004 with d
    simon "(She'll probably text me back when she wakes up.)" id ep4_08_susanphone_bad87645
    play sound phone_vibrate volume 0.5 
    show ep4 susanphone_005 with d
    play music coming_back fadein 7 volume 0.32
    simon "(What?)" id ep4_08_susanphone_4d12b589

    show ep4 susanphone_006 with d
    simon "(I guess she was up after all.)" id ep4_08_susanphone_2ee16cf3
    show ep4 susanphone_007 with d
    susan "Hey, [name]. You messaged?" (what_italic=True)
    show ep4 susanphone_008 with d
    simon "Sorry to bother you so early." id ep4_08_susanphone_92fe50ef
    simon "I wanted to talk to you about work." id ep4_08_susanphone_4a722532
    show ep4 susanphone_009 with d
    simon "I was curious to know if you had any jobs for me." id ep4_08_susanphone_75888fd1
    show ep4 susanphone_007 with d
    susan "Sure, I do. But don't you have class today?" (what_italic=True)
    show ep4 susanphone_010 with d
    simon "I do, but none so early in the morning." id ep4_08_susanphone_bc0f3b6d
    show ep4 susanphone_011 with d
    susan "Well, if that's case... there is this job I've been wanting to discuss." (what_italic=True)
    susan "Think you could come by my beach house?" (what_italic=True)
    show ep4 susanphone_012 with d
    susan "I know you know the address." id ep4_08_susanphone_16c9f7c1
    show ep4 susanphone_013 with d
    simon "(Oh, shit! She knows!)" id ep4_08_susanphone_6575a69e
    show ep4 susanphone_014 with d
    simon "Umm... Right now?" id ep4_08_susanphone_a42a0fd6
    show ep4 susanphone_015 with d
    susan "Yeah, now." id ep4_08_susanphone_dcf71fbc
    susan "This won't take long." id ep4_08_susanphone_95d59cd7
    show ep4 susanphone_016 with d
    simon "I'm on my way then." id ep4_08_susanphone_53767e6c




    jump ep4_09_susanhome
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
