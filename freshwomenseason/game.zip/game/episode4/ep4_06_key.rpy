
label ep4_06_key:

    show ep4 key_001 with d
    simon "(Phew... I could use some rest.)" id ep4_06_key_1d56859d
    show ep4 key_002 with d
    simon "(Let's see if she really gave me my own key.)" id ep4_06_key_79e4b51b
    play sound key_in volume 0.5
    show ep4 key_003 with d
    simon "(It fits.)" id ep4_06_key_3e5dd198
    play sound trying_open_door volume 0.5
    show ep4 key_004 with d
    simon "(But it won't turn... Damn it, Emily.)" id ep4_06_key_44f932ea
    show ep4 key_005 with d
    simon "(You gave me the wrong key!)" id ep4_06_key_31f3cd8a
    show ep4 key_006 with d
    simon "(Oh, right. There are two of them.)" id ep4_06_key_b08bb70b
    play sound door_unlock volume 0.5 
    show ep4 key_007 with d
    simon "(The second one works.)" id ep4_06_key_e5f80db0
    show ep4 key_008 with d
    simon "(I guess she was telling the truth after all.)" id ep4_06_key_04b9ea95
    show ep4 key_009 with d
    simon "(But the two keys are practically identical.)" id ep4_06_key_c6e7a4e8
    show ep4 key_010 with d
    simon "(Does this key open another door in this building then?)" id ep4_06_key_6cf832f9
    play sound key_table volume 0.5
    show ep4 key_011 with d
    simon "(Coming from Emily, it could be that. Or it could be nothing at all.)" id ep4_06_key_36dc04a6
    show ep4 key_012 with d
    simon "(Not like it matters though.)" id ep4_06_key_58f94d05
    simon "(It's not like I'm going to be here long enough to find out.)" id ep4_06_key_5f1492fa
    show ep4 key_013 with d
    simon "(I should take a nap.)" id ep4_06_key_4515f570
    play sound bed 
    stop music fadeout 5
    show ep4 key_014 with d
    simon "(I have to rest up if I want to be ready for class.)" id ep4_06_key_ab9e3a51
    show ep4 key_015 with medium_dissolve
    simon "(Tomorrow's going to be a long day.)" id ep4_06_key_0ff18059

    jump ep4_07_dream
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
