label ep4_26_finale:
    $ add_frame_to_finale = False
    stop sound_2 fadeout 15
    stop sound fadeout 15
    stop music fadeout 15

    show screen save_your_game(4, 1, 4, 0) with ending_fade
    show ep4 finale_end_lily
    pause

    $ award_manager.enable_notify()

    $ set_finale_chars("Lily")
    $ finale_color = "CF4730"
    $ finale_txt1 = _("You finally met Sam.")
    if chose_finale('ep4_lunch_shake_his_hand'):
        $ finale_txt2 = _("And you shook his hand.")
    else:
        $ finale_txt2 = _("And you didn't shake his hand.")
    if chose_finale('ep4_lunch2_i_fucked_your_wife'):
        $ finale_txt3 = _("You told Sam that you had sex with Lily. He wasn't very happy about it.")
    else:
        $ finale_txt3 = _("You took the moral high ground by letting Sam know that Lily's upset with him.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You got kicked out of the apartment.")

    hide screen save_your_game with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars ("Julia")
    $ finale_color = "C161D4"
    $ finale_txt1 = _("You had lunch with Julia.")

    if chose_finale('ep2_julia_kiss'):
        if chose_finale('ep4_julialunch_kiss_julia'):
            $ finale_txt2 = _("You kissed Julia when you saw her.")
        else:
            $ finale_txt2 = _("You decided not to kiss Julia in public.")
    else:
        $ finale_txt2 = ""

    if chose_finale('ep3_sat_chloesex_continue'):
        if chose_finale('ep2_julia_kiss'):
            $ finale_txt3 = _("Julia seemed a bit jealous when she saw you and Chloe together.")
        else:
            $ finale_txt3 = ""
    else:
        $ finale_txt3 = ""

    if chose_finale('ep4_julia_invite'):
        $ finale_txt4 = _("Julia invited you to stay at her house.")
    else:
        $ finale_txt4 = ""
        $ finale_txt5 = ""

    if chose_finale('ep4_livingsituation_julia'):
        $ finale_txt5 = _("You stayed at Julia's.")
    else:
        if chose_finale('ep4_julia_invite'):
            $ finale_txt5 =  ""
        else:
            $ finale_txt5 = _("But you stayed somewhere else.")

    show ep4 finale_end_julia with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars ("Susan")
    $ finale_color = "8C91ED"
    $ finale_txt1 = _("You met Susan at The Beach House.")
    if chose_finale('ep4_susanhome_to_agree'):
        $ finale_txt2 = _("You tried to hide information from Susan, but things didn't turn out well.")
    else:
        $ finale_txt2 = _("You told Susan the truth about your memories of the accident.")
    if chose_finale('ep4_susanhome_tell_the_truth'):
        if chose_finale('ep4_susanhome_i_was_spying_on_you'):
            $ finale_txt3 = _("You told Susan that you were spying on her.")
        if chose_finale('ep4_susanhome_no'):
            $ finale_txt4 = _("And you said you did it by yourself, even though it was Sue's idea.")
        else:
            if chose_finale('ep4_susanhome_tell_what_happened'):
                $ finale_txt4 = _("You mentioned that Sue was in on the spying, and you explained how Charlie died.")
            else:
                $ finale_txt4 = _("You mentioned that Sue was in on the spying, but you decided not to mention anything else about the accident.")
    else:
        $ finale_txt3 = _("You told Susan that Sue was spying on her.")
        $ finale_txt4 = ""
    if chose_finale('ep4_susanhome_tell_what_happened') or chose_finale('ep4_susanhome_no'):
        if chose_finale('ep4_susanhome_accept_the_job'):
            $ finale_txt5 = _("You learned more about your father, and you accepted the job at the ball.")
        else:
            $ finale_txt5 = _("You learned more about your father, but you refused the job at the ball.")
    else:
        $ finale_txt5 = _("You learned more about your father.")

    show ep4 finale_end_susan with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    $ set_finale_chars ("Sue")
    $ finale_color = "D6D6D6"
    $ finale_txt1 = _("Sue overheard you talking to Susan.")
    if chose_finale('ep4_susanhome_suespy1') or chose_finale('ep4_susanhome_suespy2'):
        $ finale_txt2 = _("You told Susan that Sue sent you to spy on her.")
        $ finale_txt2 = _("Sue tried to run you over with her car.")
        $ finale_txt3 = ""
        $ finale_txt4 = ""
        $ finale_txt5 = _("She seemed very mad at you.")
    else:
        if chose_finale('ep4_susanhome_no'):
            $ finale_txt2 = _("You didn't tell Susan that Sue sent you to spy on her.")
        else:
            $ finale_txt2 = ""
        if chose_finale('ep4_sue_invite'):
            $ finale_txt3 = _("Sue invited you to stay at her place.")
            if chose_finale('ep4_livingsituation_sue'):
                $ finale_txt5 = _("You stayed at Sue's.")
            else:
                $ finale_txt5 = _("But you stayed somewhere else.")
        else:
            $ finale_txt3 = ""
            $ finale_txt5 = ""
        if chose_finale('ep4_suetalk_yea') or chose_finale('ep4_suetalk_90'):
            $ finale_txt4 = _("You had sex with Sue.")
        else:
            $ finale_txt4 = _("You didn't have sex with Sue.")

    show ep4 finale_end_sue with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Chloe")
    $ finale_color = "4FDB85"
    $ finale_txt1 = _("You met Chloe on campus.")
    if chose_finale('ep3_sat_chloesex_continue'):
        if chose_finale('ep2_julia_kiss'):
            $ finale_txt2 = _("Chloe didn't seem to mind the fact that Julia got jealous.")
        else:
            $ finale_txt2 = _("Chloe thanked you for accepting her.")
    else:
        if chose_finale('ep4_university_it_was_too_much'):
            $ finale_txt2 = _("When Chloe apologized, you told her she went too far.")
        else:
            $ finale_txt2 = _("You accepted Chloe's apology.")
    $ finale_txt3 = ""
    if chose_finale('ep4_chloe_invite'):
        $ finale_txt4 = _("Chloe invited you to stay at her place.")
        if chose_finale('ep4_livingsituation_chloe'):
            $ finale_txt5 = _("You stayed at Chloe's")
        else:
            $ finale_txt5 = _("But you stayed somewhere else.")
    else:
        $ finale_txt4 = ""
        $ finale_txt5 = ""

    show ep4 finale_end_chloe with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Alyssa")
    $ finale_color = "A6F2F5"
    $ finale_txt1 = _("You practiced your dance moves with Alyssa.")
    if chose_finale('ep2_alyssa_kiss'):
        if chose_finale('ep4_alyssasex_take_the_step'):
            $ finale_txt2 = _("You had sex with Alyssa.")
        else:
            $ finale_txt2 = _("You didn't have sex with Alyssa.")
    else:
        $ finale_txt2 = ""
    $ finale_txt3 = ""
    if chose_finale('ep4_alyssa_invite'):
        $ finale_txt4 = _("Alyssa invited you to stay at her place.")
        if chose_finale('ep4_livingsituation_here'):
            $ finale_txt5 = _("You stayed at Alyssa's")
        else:
            $ finale_txt5 = _("But you stayed somewhere else.")
    else:
        $ finale_txt4 = ""
        $ finale_txt5 = ""

    show ep4 finale_end_alyssa with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars ("Dylan")
    $ finale_color = "FCFF4B"
    $ finale_txt1 = _("You went to college with Dylan.")
    if chose_finale('ep4_dylanphone_i_want_style'):
        $ finale_txt2 = _("You decided to ride in style and got noticed by a girl.")
    else:
        $ finale_txt2 = _("You decided to take it easy and not call too much attention to yourself.")
    $ finale_txt3 = ""
    $ finale_txt4 = _("Dylan invited you to stay at his place.")
    if chose_finale('ep4_livingsituation_dylan'):
        $ finale_txt5 = _("You stayed at Dylan's.")
    else:
        $ finale_txt5 = _("But you stayed somewhere else.")


    show ep4 finale_end_dylan with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Emily")
    $ finale_color = "CF3F30"
    $ finale_txt1 = _("Emily visited you.")
    if chose_finale('ep4_emilyvisit_agree_with_emily'):
        $ finale_txt2 = _("You had sex with her.")
    else:
        $ finale_txt2 = _("You didn't have sex with her.")
    $ finale_txt3 = _("She gave you a key to her apartment.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You found the other half of the picture of Susan with you and Emily on it.")

    show ep4 finale_end_emily with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    call end_game_if_rpy_is_not_installed ('ep5_01_intro.rpy')

    jump ep5_01_intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
