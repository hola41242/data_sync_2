
label ep4_25_dylannight:

    show ep4 dylannight_001 with d
    pause 5
    show ep4 dylannight_002 with d
    pause 5
    show ep4 dylannight_003 with d
    pause 5
    jump ep4_26_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
