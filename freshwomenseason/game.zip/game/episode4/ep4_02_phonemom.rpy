
label ep4_02_phonemom:
    play music making_sense fadeout 5 fadein 5.0 volume 0.3
    show ep4 phonemom_001 with long_fade
    simon "(Well, that was pointless.)" id ep4_02_phonemom_d7efea43
    simon "(I'll have to move out soon.)" id ep4_02_phonemom_09f6eceb
    show ep4 phonemom_002 with d
    simon "(My plans have gone straight down the shitter.)" id ep4_02_phonemom_17b52965
    simon "(Maybe I should have listened to mom.)" id ep4_02_phonemom_c798312c
    show ep4 phonemom_003 with d
    simon "(Mom!)" id ep4_02_phonemom_745f1361
    show ep4 phonemom_004 with d
    simon "(It's a desperate move, but she might be my last chance.)" id ep4_02_phonemom_08449abf
    play sound cell_phone_ring volume 0.5
    show ep4 phonemom_005 with d
    simon "(She always changes the subject whenever I talk about dad though.)" id ep4_02_phonemom_5133ac94
    stop sound fadeout 0.5
    show ep4 phonemom_006 with d
    mother "[name]? Is that you?" (what_italic=True)
    simon "Hi, mom." id ep4_02_phonemom_76cca80c
    mother "[name]!" id ep4_02_phonemom_fa3fc98b (what_italic=True)
    mother "To what do I owe the honor of my son calling me?" (what_italic=True)
    mother "Is everything all right?" (what_italic=True)
    show ep4 phonemom_007 with d
    mother "Are you feeling sick?" (what_italic=True)
    mother "Have you been eating well?" (what_italic=True)
    show ep4 phonemom_008 with d
    simon "I'm fine, mom. How about you?" id ep4_02_phonemom_91f34dc4
    show ep4 phonemom_009 with d
    mother "I'm great!" (what_italic=True)
    mother "Your aunt took the kids on vacation, so I'm finally getting a chance to breathe." (what_italic=True)
    show ep4 phonemom_010 with d
    simon "Mom, they're almost my age." id ep4_02_phonemom_7d38d880
    simon "You can't really call them children anymore." id ep4_02_phonemom_7e0eaa0e
    show ep4 phonemom_011 with d
    mother "Of course they're still children!" (what_italic=True)
    mother "You are too." (what_italic=True)
    mother "Don't think that just because you're going to college you're not my child anymore." (what_italic=True)
    show ep4 phonemom_012 with d
    mother "Speaking of which, tomorrow's the big day, right?" (what_italic=True)
    mother "Are you excited?" (what_italic=True)

    menu:
        "Yes, but..."(True):
            $ ep4_phonemom_yes_but = True
            $ player_choice("ep4_phonemom_yes_but:true")
            show ep4 phonemom_013 with d
            simon "Yeah, I'm excited, but..." id ep4_02_phonemom_67bc69d3
            show ep4 phonemom_014 with d
            mother "... But you've got another reason for calling, huh?" (what_italic=True)
            mother "Mothers always know." (what_italic=True)
            show ep4 phonemom_015 with d
            mother "You know, I worried a lot when you said you wanted to move to Minerva Bay." id ep4_02_phonemom_d693a10c
            mother "But you studied so hard and got into college." id ep4_02_phonemom_2ccbfbbb
            show ep4 phonemom_016 with d
            mother "And after your accident... I just couldn't say no." id ep4_02_phonemom_173fea35
            show ep4 phonemom_017 with d
            simon "(This hasn't been easy for her either...)" (what_italic=True)
            simon "Mom... we need to talk about dad." (what_italic=True)
            show ep4 phonemom_018 with d
            mother "Oh, is that what this is all about?" id ep4_02_phonemom_5f849cc2
            mother "I thought it was going to be girl trouble!" id ep4_02_phonemom_36fe92d8
            mother "Or boy trouble. I don't judge." id ep4_02_phonemom_c09e2e9d
            show ep4 phonemom_019 with d
            mother "You know, Susan called. She said her niece is single..." id ep4_02_phonemom_0c091e27
            mother "I think she's about your age." id ep4_02_phonemom_bbda7b0a
            show ep4 phonemom_020 with d
            simon "Mom." (what_italic=True)
            show ep4 phonemom_021 with d
            simon "This is serious." (what_italic=True)
        "Honestly, no":

            $ ep4_phonemom_no = True
            $ player_choice("ep4_phonemom_no:true")
            show ep4 phonemom_022 with d
            simon "Honestly, no. I think I've had enough of this city and the people in it." id ep4_02_phonemom_63e23722
            show ep4 phonemom_023 with d
            mother "Why, [name]? You shouldn't be like that." id ep4_02_phonemom_1c8f7316
            mother "You've only been there a few days." id ep4_02_phonemom_9db204ee
            show ep4 phonemom_024 with d
            simon "You know why I came here." (what_italic=True)



    show ep4 phonemom_025 with d
    mother "I figured you'd let that go." (what_italic=True)
    mother "I thought that obsession of yours might be long gone." (what_italic=True)
    show ep4 phonemom_026 with d
    mother "But deep down, I knew you wouldn't stop." id ep4_02_phonemom_4c4769f2
    mother "I saw you found the documents I hid." id ep4_02_phonemom_81fb7c73
    show ep4 phonemom_027 with d
    mother "So I've been waiting for the moment when you'd come face-to-face with the same answers I did." id ep4_02_phonemom_29d1b432
    mother "But I wanted to spare you from the pain!" id ep4_02_phonemom_cda1adc9
    show ep4 phonemom_028 with d
    mother "He's gone, son!" id ep4_02_phonemom_05ce5c2f
    show ep4 phonemom_029 with d
    mother "The reason I never told you anything is because there's nothing to find out!" (what_italic=True)
    mother "I lost almost everything in my search for your father." (what_italic=True)
    show ep4 phonemom_027 with d
    mother "I lost the house and used up all of our savings on investigators and lawyers." id ep4_02_phonemom_430e3284
    mother "I almost lost you to the state even with how much I was neglecting you." id ep4_02_phonemom_74ace789
    show ep4 phonemom_030 with d
    mother "To see you following the same path... it breaks my heart." id ep4_02_phonemom_e08bc29b
    simon "Mom." (what_italic=True)
    show ep4 phonemom_031 with d
    mother "What is it, [name]?" id ep4_02_phonemom_ec79901a
    show ep4 phonemom_032 with d
    simon "I think it's time for me to come home." id ep4_02_phonemom_b7f1a0bd
    show ep4 phonemom_033 with d
    mother "Thank god for that, son." (what_italic=True)
    simon "See you soon, mom." id ep4_02_phonemom_15451488
    show ep4 phonemom_034 with d
    simon "(Three days. I have three days to get ready.)" id ep4_02_phonemom_d1316a2f
    show ep4 phonemom_035 with d
    simon "(Better start soon while I still have a roof over my head.)" id ep4_02_phonemom_97ee75e4
    jump ep4_03_juliaphone
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
