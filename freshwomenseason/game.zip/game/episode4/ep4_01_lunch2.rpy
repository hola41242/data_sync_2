define episode_4_name = _("Episode 4 - Refresh")
label ep4_01_lunch2:
    $ validate_mods()
    play music little_touch_of_heaven fadein 3 volume 0.55
    scene ep4 lunch_001 with long_fade
    sam "Boy, are you hearing me?" id ep4_01_lunch2_840151f9

    show ep4 lunch_002 with d
    sam "Are you with the cleaning staff? They're staying in the back." id ep4_01_lunch2_92a8bef0

    simon "(Shit... I didn't know he was going to be here.)" id ep4_01_lunch2_b850c209
    show ep4 lunch_004 with d
    simon "(Maybe I should keep my mouth closed and just...)" id ep4_01_lunch2_9bcba4cf

    lily "Sam, who is it?" (what_italic=True)
    show ep4 lunch_005 with d
    simon "..." id ep4_01_lunch2_ba28090a
    show ep4 lunch_006 with d
    lily "Oh... It's you, [name]." id ep4_01_lunch2_8490cf00
    show ep4 lunch_007 with d
    sam "[name]? No way!" id ep4_01_lunch2_91c70184
    show ep4 lunch_008 with d
    sam "Fred's kid?" id ep4_01_lunch2_bf97a7ef
    sam "He's all grown up now!" id ep4_01_lunch2_11c2c8d7
    show ep4 lunch_009 with d
    sam "It's been so long since I saw you last." id ep4_01_lunch2_167d8186
    sam "You probably don't even remember me." id ep4_01_lunch2_49d6f84e
    show ep4 lunch_010 with d
    sam "Just call me Sam." id ep4_01_lunch2_3414506b

    menu:
        "Shake his hand"(True):
            $ ep4_lunch_shake_his_hand = True
            $ player_choice("ep4_lunch_shake_his_hand:true")
            $ points_lily += 1
            show ep4 lunch_011 with d
            simon "(So this is Sam... There's something off about him.)" id ep4_01_lunch2_d177ab83
            show ep4 lunch_012 with d
            simon "(Why is he acting like this?)" id ep4_01_lunch2_20d24073
            simon "(This isn't the Sam I remember.)" id ep4_01_lunch2_a80a0b03
            simon "(Last time we saw each other, he...)" id ep4_01_lunch2_7564dc9f
            simon "(... He...)" id ep4_01_lunch2_2aff96bd
        "Don't shake his hand":

            $ ep4_lunch_dont_shake_his_hand = True
            $ player_choice("ep4_lunch_dont_shake_his_hand:true")
            show ep4 lunch_013 with d
            simon "Sam..." id ep4_01_lunch2_735f566b
            show ep4 lunch_014 with d
            sam "Ah, so you do remember me." id ep4_01_lunch2_600ea199
            show ep4 lunch_015 with d
            simon "Do I remember you?" id ep4_01_lunch2_77ddc1e5
            simon "Of course, I do..." id ep4_01_lunch2_e8a8f96d
            simon "I remember that you..." id ep4_01_lunch2_106d3469
            simon "... You..." id ep4_01_lunch2_647df8cc



    stop music fadeout 2

    play sound_2 heartbeat_distant volume 0.5
    show ep4 lunch_016_1 with Dissolve(1)
    sam "[name]?" id ep4_01_lunch2_c8db7f9d
    show black as ep4 with Dissolve(1.5)
    play sound body_fall volume 0.5
    pause 1
    lily "[name!u]!" id ep4_01_lunch2_47a67d5c
    pause 4
    lily "[name!u], WAKE UP!" id ep4_01_lunch2_125f06bd
    pause 0.5
    stop sound_2 fadeout 4
    show ep4 lunch_017 with Dissolve(4)
    lily "[name]?" id ep4_01_lunch2_115817d4
    show ep4 lunch_018 with d
    simon "What happened?" id ep4_01_lunch2_9aa9ef74
    show ep4 lunch_019 with d
    lily "I don't know..." id ep4_01_lunch2_224cb06f
    lily "You just showed up at my doorstep, and then you passed out." id ep4_01_lunch2_98737d46
    show ep4 lunch_020 with d
    simon "Oh, right. I remember..." id ep4_01_lunch2_3eea1d72
    show ep4 lunch_021 with d
    simon "(I probably imagined the whole thing.)" id ep4_01_lunch2_d48bf0cd
    show ep4 lunch_022 with d
    simon "I thought I saw your husband." id ep4_01_lunch2_aa72ba35
    simon "Good thing he's not really here." id ep4_01_lunch2_626845e6
    show ep4 lunch_023 with d
    lily "[name]!" id ep4_01_lunch2_bcba4ae9
    play music they_already_knew_it fadein 1 volume 0.3
    show ep4 lunch_024 with d
    sam "Wow... I leave the room for a few seconds, and you're already hitting on my wife?" id ep4_01_lunch2_644e53ec
    show ep4 lunch_025 with d
    simon "Shit." id ep4_01_lunch2_0ae78473
    show ep4 lunch_026 with d
    sam "Hahaha! You should have seen your face!" id ep4_01_lunch2_57b65c27
    sam "Relax! I was just kidding." id ep4_01_lunch2_ac95f6d5
    show ep4 lunch_027 with d
    sam "My Lily would never fall for the charms of a kid." id ep4_01_lunch2_32ef5e69
    show ep4 lunch_028 with d
    pause
    show ep4 lunch_029 with d
    lily "*Sigh.*" id ep4_01_lunch2_e88655ee
    show ep4 lunch_030 with d
    lily "Excuse me, you two. I need to get ready." id ep4_01_lunch2_e4f58719
    show ep4 lunch_031 with d
    sam "Oh, that's right!" id ep4_01_lunch2_87fff6fe
    sam "Hey... Come with me, [name]." id ep4_01_lunch2_76220380
    show ep4 lunch_031_1 with d
    sam "So, you like barbecue?" id ep4_01_lunch2_80923701
    show ep4 lunch_032 with d
    lily "Huh?" id ep4_01_lunch2_5d350176
    show ep4 lunch_033 with d
    lily "What's this?" id ep4_01_lunch2_1fae6b34
    show ep4 lunch_034 with fade
    sam "Since you stopped by, you should join us for lunch." id ep4_01_lunch2_785e04cd
    show ep4 lunch_035 with d
    simon "(I can't believe this is the same Sam I met before.)" id ep4_01_lunch2_4773df1e
    simon "(Now he's right here in front of me, playing the good husband.)" id ep4_01_lunch2_2e3f3489
    show ep4 lunch_036 with d
    simon "(Since Lily's not around, we'll be able to speak freely.)" id ep4_01_lunch2_a514afa1
    show ep4 lunch_037 with d
    simon "Sam, I wanted to..." id ep4_01_lunch2_6458b71f
    show ep4 lunch_038 with d
    sam "Beer?" id ep4_01_lunch2_37f05bfa
    show ep4 lunch_039 with d
    simon "Um, okay." id ep4_01_lunch2_679dd59d
    show ep4 lunch_040 with d
    sam "They say it's bad luck to drink without a cheers first." id ep4_01_lunch2_5470e4e9
    play sound wineglass volume 0.5
    show ep4 lunch_041 with d
    sam "The last time we saw each other, you weren't even old enough to drink." id ep4_01_lunch2_88558942
    show ep4 lunch_042 with d
    simon "So you do remember." id ep4_01_lunch2_8c2f3cb9
    show ep4 lunch_043 with d
    sam "Of course I do." id ep4_01_lunch2_cc09afde
    show ep4 lunch_044 with d
    sam "I'm sorry for the scene you had to witness back then, champ." id ep4_01_lunch2_806a3288
    show ep4 lunch_045 with d
    simon "Oh, are you sorry now?" id ep4_01_lunch2_4d2b2806
    show ep4 lunch_046 with d
    sam "I am. It wasn't exactly my proudest moment." id ep4_01_lunch2_a8fa9230
    sam "That definitely wasn't me at my best." id ep4_01_lunch2_6d646152
    show ep4 lunch_047 with d
    sam "As for your father... Well, he..." id ep4_01_lunch2_204b708a

    show ep4 lunch2_001 with d
    simon "I know you had something to do with what happened to him." id ep4_01_lunch2_3c972309
    show ep4 lunch2_002 with d
    sam "Oh yeah?" id ep4_01_lunch2_dc4df439
    sam "And what do you think you know?" id ep4_01_lunch2_c86b7b52
    show ep4 lunch2_003 with d
    simon "You may know about my accident and may have heard about the amnesia, but I'm starting to remember things." id ep4_01_lunch2_c9c8cfbe
    show ep4 lunch2_004 with d
    simon "Things like the last time we saw each other." id ep4_01_lunch2_ac518322
    simon "I remember what you did." id ep4_01_lunch2_afa4f544
    show ep4 lunch2_005 with d
    simon "And I know that you, Lily, and Susan did something to my father." id ep4_01_lunch2_8235a594
    simon "Then, after whatever you did, he disappeared." id ep4_01_lunch2_0b11ac15
    show ep4 lunch2_006 with d
    sam "Is that so?" id ep4_01_lunch2_1f1e9c0b
    sam "And who told you all that? Was it my Lily?" id ep4_01_lunch2_3111b6ae
    show ep4 lunch2_007 with d
    simon "No..." id ep4_01_lunch2_bf1ec59a
    show ep4 lunch2_008 with medium_fade
    simon "I..." (what_italic=True)
    show ep4 lunch2_009 with d
    simon "... I overheard the two of them talking." (what_italic=True)
    show ep4 lunch2_010 with d
    lily "(My god...)" id ep4_01_lunch2_e4d53fb7
    show ep4 lunch2_011 with medium_fade
    sam "Is that so...? You were eavesdropping on them?" id ep4_01_lunch2_0756314d
    show ep4 lunch2_012 with d
    simon "Yeah..." id ep4_01_lunch2_fceb2bd0
    show ep4 lunch2_013 with d
    simon "But that's not what's important here!" id ep4_01_lunch2_9bff5048
    show ep4 lunch2_014 with d
    sam "No, no. I think it is important." id ep4_01_lunch2_3775cdc7
    show ep4 lunch2_015 with d
    sam "You seem like a smart guy, champ." id ep4_01_lunch2_57b0202f
    sam "Kids like you are good at some things, I must admit." id ep4_01_lunch2_988d18d3
    show ep4 lunch2_016 with d
    sam "This grill right here, for example. I just can't seem to fix it." id ep4_01_lunch2_94e46673
    sam "I'm terrible at that kind of stuff." id ep4_01_lunch2_03e7d53c
    show ep4 lunch2_017 with d
    sam "There are several things around this house I've been meaning to fix." id ep4_01_lunch2_463273b7
    show ep4 lunch2_018 with d
    simon "Where are you going with this?" id ep4_01_lunch2_99b06f3f
    show ep4 lunch2_019 with d
    sam "The funny thing is..." id ep4_01_lunch2_8440add0
    sam "I got home and found that the sink had been fixed." id ep4_01_lunch2_9f927dd7
    sam "My Lily told me that was your work." id ep4_01_lunch2_981de472
    show ep4 lunch2_020 with d
    sam "And now you're telling me you overheard her and Susan talking." id ep4_01_lunch2_4394913d
    sam "You seem to have spent a lot of time with my wife while I was out."
    show ep4 lunch2_021 with d
    sam "Hah!" id ep4_01_lunch2_d0a4cf79
    show ep4 lunch2_022 with d
    sam "I get it. I really do." id ep4_01_lunch2_6c630264
    sam "I was your age once." id ep4_01_lunch2_85400854
    sam "And I also had an eye for older women." id ep4_01_lunch2_c8380d3d
    show ep4 lunch2_023 with d
    sam "But with just one look, I can tell you don't have what they like." id ep4_01_lunch2_b5e15b5f
    show ep4 lunch2_024 with d
    sam "You're a nobody." id ep4_01_lunch2_28b94944
    show ep4 lunch2_025 with d
    sam "Just like your father." id ep4_01_lunch2_646ac8e2
    play sound slap volume 2
    show ep4 lunch2_026 with hpunch
    simon "What did you just say?" id ep4_01_lunch2_6d6196fe
    show ep4 lunch2_027 with d
    sam "He also had his eye on Lily." id ep4_01_lunch2_f9544113
    sam "She's hot. I get it." id ep4_01_lunch2_12b56444
    show ep4 lunch2_028 with d
    sam "But she never gave a shit about your father, and she won't give a shit about you either." id ep4_01_lunch2_78d3e7ed
    sam "The apple really doesn't fall far from the tree, does it?" id ep4_01_lunch2_2bc662b0
    show ep4 lunch2_029 with d
    simon "You know what, Sam...?" id ep4_01_lunch2_128c61a2


    menu:
        "I fucked your wife":
            $ ep4_lunch2_i_fucked_your_wife = True
            $ player_choice("ep4_lunch2_i_fucked_your_wife:true")

            $ points_lily -= 1
            show ep4 lunch_065 with d
            simon "I had to come talk to Lily, so I decided to take care of some things you forgot to do..." id ep4_01_lunch2_dc2b4783
            show ep4 lunch_066 with d
            simon "... like fixing your sink and fucking your wife." id ep4_01_lunch2_73329f9d
            play sound punch_miss 
            show ep4 lunch_067 with hpunch
            sam "YOU SON OF A WHORE!" id ep4_01_lunch2_470e3a7f
            play sound body_fall volume 0.5
            show ep4 lunch_068 with vpunch
            simon "(How do you like that?)"
            show ep4 lunch_069 with d
            simon "(Oh, fuck.)" id ep4_01_lunch2_dc191d02
            show ep4 lunch_070 with d
            lily "SAM!" id ep4_01_lunch2_9e74e792

            show ep4 lunch2_030 with d
            lily "Stop it! Both of you!" id ep4_01_lunch2_fd420917
            show ep4 lunch2_031 with d
            simon "Lily, I —" id ep4_01_lunch2_c2ec35b8
            show ep4 lunch2_032 with d
            lily "Please, [name]." id ep4_01_lunch2_36a8925f
            lily "Not another word." id ep4_01_lunch2_ff81643c
            show ep4 lunch2_033 with d
            lily "All of this... was a mistake." id ep4_01_lunch2_7fb3187d
            lily "There was no need for any of it." id ep4_01_lunch2_661898c8
            show ep4 lunch2_034 with d
            lily "I think you'd better find another place to stay, [name]." id ep4_01_lunch2_8dc92560
            lily "It'd be for the best if you moved out as soon as possible." id ep4_01_lunch2_45a56ed3
            show ep4 lunch2_035 with d
            lily "Letting you get so close was a mistake." id ep4_01_lunch2_dd03968f
            show ep4 lunch2_036 with d
            simon "A mistake?" id ep4_01_lunch2_1d5bffc7
            show ep4 lunch2_037 with d
            simon "You're right. You did make a mistake, Lily." id ep4_01_lunch2_ba5a8f8d
            simon "But that mistake had nothing to do with me." id ep4_01_lunch2_656299ce
            show ep4 lunch2_038 with d
            lily "[name]..."
            show ep4 lunch2_039 with d
            lily "I can find another place for you to stay if you —" id ep4_01_lunch2_d6ce02a7
            show ep4 lunch2_040 with d
            simon "Don't worry about it." id ep4_01_lunch2_93d2e0ce
            show ep4 lunch2_041 with d
            simon "I'll take care of this myself." id ep4_01_lunch2_a2cdd05f
            simon "Just like I've always done." id ep4_01_lunch2_0b916e24
            stop music fadeout 2
            show ep4 lunch2_042 with d
            simon "I'll see myself out." id ep4_01_lunch2_65ac9c2d
            show ep4 lunch2_043 with d
            lily "[name]..."
            show black as ep4 with fade
        "It's you she doesn't give a shit about"(True):

            $ ep4_lunch2_its_you_who_is_shit = True
            $ player_choice("ep4_lunch2_its_you_who_is_shit:true")
            $ points_lily += 1
            show ep4 lunch2_044 with d
            simon "At least I'm not blind." id ep4_01_lunch2_e25ec717
            show ep4 lunch2_045 with d
            simon "You have an amazing wife, but you're losing her because you can't see two feet in front of you." id ep4_01_lunch2_ff0504e3
            show ep4 lunch2_046 with d
            simon "Maybe you're right and I really don't have everything you have." id ep4_01_lunch2_9134a175
            simon "But I think it's better to be like that than to be as blind as a bat." id ep4_01_lunch2_e3647483
            show ep4 lunch2_047 with d
            sam "You little shit..." id ep4_01_lunch2_ca9f701e
            show ep4 lunch2_048 with d
            sam "Who do you think you're talking to?" id ep4_01_lunch2_e0286f12
            show ep4 lunch2_049 with d
            lily "Sam!" id ep4_01_lunch2_300230bf
            show ep4 lunch2_050 with d
            lily "Let him go right this instant!" id ep4_01_lunch2_32e2966f
            show ep4 lunch2_051 with d
            sam "What? Are you protecting this pipsqueak now?" id ep4_01_lunch2_0028b5b4
            show ep4 lunch2_052 with d
            lily "He's not wrong, Sam." id ep4_01_lunch2_d2fa5880
            lily "And he said nothing to offend." id ep4_01_lunch2_4590594c
            show ep4 lunch2_053 with d
            lily "You, on the other hand, have nothing but harsh words for the boy." id ep4_01_lunch2_a01f7d7b
            show ep4 lunch2_054 with d
            lily "He's much more of a man than you'll ever be." id ep4_01_lunch2_782db977
            show ep4 lunch2_055 with d
            sam "Oh yeah?" id ep4_01_lunch2_0352d191
            show ep4 lunch2_056 with d
            sam "If he's such a man, then maybe he should be paying his own bills, huh?" id ep4_01_lunch2_6f68fc90
            sam "How about that?" id ep4_01_lunch2_7e031172
            show ep4 lunch2_057 with d
            sam "How about you find a place of your own?" id ep4_01_lunch2_4bc6c595
            show ep4 lunch2_058 with d
            simon "What? He can't kick me out!" id ep4_01_lunch2_a0923ad6
            show ep4 lunch2_059 with d
            lily "Actually... Sam bought the building... It's his now." id ep4_01_lunch2_81511494
            show ep4 lunch2_060 with d
            simon "What?" id ep4_01_lunch2_708b4972
            show ep4 lunch2_061 with d
            lily "I... I can't help you, [name]." id ep4_01_lunch2_5b4b3675
            show ep4 lunch2_062 with d
            simon "Goddammit!" id ep4_01_lunch2_b5e9e7ab
            show ep4 lunch2_063 with d
            sam "Fuck off, twerp." id ep4_01_lunch2_59b810b5
            show ep4 lunch2_064 with d
            lily "I think you'd better go." id ep4_01_lunch2_d87d4dad
            lily "I'll try to think of something." id ep4_01_lunch2_7b4bd7f5
            show ep4 lunch2_065 with d
            sam "Like hell you will." id ep4_01_lunch2_3921ca5d
            stop music fadeout 2
            show ep4 lunch2_066 with d
            lily "[name]... Just go." id ep4_01_lunch2_36f03bc1
            show ep4 lunch2_067 with d
            simon "Well, shit..." id ep4_01_lunch2_27ead22b
            show black as ep4 with fade



    play music you_cant_stop_me fadein 4 volume 0.3
    show black as ep4 with None

    show oppaiman_presents with medium_fade
    pause 2


    scene black as ep4 with medium_fade
    show black_screen as ep4 with d

    show ep4 titlecard with None
    $ on_screen_translation(episode_4_name, interact=False)
    pause 4
    $ on_screen_translation(episode_4_name, interact=False)
    stop music fadeout 4
    $ on_screen_translation(episode_4_name, interact=False)
    pause 4

    jump ep4_02_phonemom
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
