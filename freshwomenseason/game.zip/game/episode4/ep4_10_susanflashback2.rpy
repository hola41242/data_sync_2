
label ep4_10_susanflashback:
    play music yes fadein 3 volume 0.3
    show ep4 susanflashback2_001 with d
    susan "So what happened was this..." id ep4_10_susanflashback_81ec07b1
    show ep4 susanflashback_002 with white_fade
    susan "Shortly after the two of them met, Sam began to push your father into making some rather risky investments." (what_italic=True)
    show ep4 susanflashback_003 with d
    susan "Your father saw it all as a challenge and bought into Sam's ideas." (what_italic=True)
    show ep4 susanflashback_004 with d
    susan "But then, Sam began distancing himself from the investments as they grew riskier and riskier." (what_italic=True)
    show ep4 susanflashback_005 with d
    susan "In the end, your father was stuck with the debt while Sam kept the profits." (what_italic=True)
    susan "Actually, we all took our share of the profits, but we had no idea Sam was manipulating your father like that." (what_italic=True)
    show ep4 susanflashback_006 with d
    susan "The two of them ended up getting in a fight, and then your father started acting really weird." (what_italic=True)
    show ep4 susanflashback_007 with d
    susan "Not long after that..." (what_italic=True)


    show ep4 susanflashback_008 with d
    susan "... he disappeared." (what_italic=True)
    show ep4 susanflashback_009 with d
    susan "That's when you began your investigation." (what_italic=True)
    show ep4 susanflashback_009_1 with d
    susan "And then..." (what_italic=True)
    play sound thunder
    show ep4 susanflashback_009_2 with vpunch
    pause 0.5
    stop music
    show white as ep4 with Dissolve(1)
    susan "... your accident." (what_italic=True)
    show ep4 susanflashback2_010 with white_fade
    play music blood_meridian volume 0.3
    simon "So you really don't know where he is." id ep4_10_susanflashback_80246d41
    show ep4 susanflashback2_011 with d
    susan "I'm sorry, [name]." id ep4_10_susanflashback_2850a709
    stop sound fadeout 5
    show ep4 susanflashback2_012 with d
    simon "From what you're telling me though, he might still be out there..." id ep4_10_susanflashback_e1b2e98a
    show ep4 susanflashback2_013 with d
    susan "[name], he abandoned you and your mother... You should stop looking for him." id ep4_10_susanflashback_0310d161
    show ep4 susanflashback2_014 with d
    simon "I want to know what happened." id ep4_10_susanflashback_00de629f
    simon "And if what you say is true, he has some explaining to do." id ep4_10_susanflashback_0272a496
    show ep4 susanflashback2_015 with d
    susan "I get it." id ep4_10_susanflashback_5f5287bb
    show ep4 susanflashback2_016 with d
    simon "Oh, and one last thing." id ep4_10_susanflashback_de9b948a
    show ep4 susanflashback2_017 with d
    simon "Who was with you in this photo?" id ep4_10_susanflashback_d6366514
    simon "It's the last clue I have to go on." id ep4_10_susanflashback_a3f51365
    show ep4 susanflashback2_018 with d
    susan "I remember this photo." id ep4_10_susanflashback_f30e2426
    susan "It was your mother who took it." id ep4_10_susanflashback_a8abccc1
    susan "She's not exactly a gifted photographer." id ep4_10_susanflashback_a22b97f9
    show ep4 susanflashback2_019 with d
    susan "There was no one else." id ep4_10_susanflashback_8a268a94
    susan "It was taken at our annual charity ball." id ep4_10_susanflashback_ccffeef2
    show ep4 susanflashback2_020 with d
    simon "A charity ball?" id ep4_10_susanflashback_61406d30
    show ep4 susanflashback2_021 with d
    susan "That's right... We felt so horrible about everything that happened to your father, so every year since his disappearance, we've been raising money for charity." id ep4_10_susanflashback_df5ea566
    show ep4 susanflashback2_022 with d
    susan "The next one is this week." id ep4_10_susanflashback_79714486
    show ep4 susanflashback2_023 with d
    simon "(So that's the important event Alyssa mentioned!)" id ep4_10_susanflashback_c432e351
    simon "(Chloe said the ball was important too.)" id ep4_10_susanflashback_8e8c958f
    simon "(If there's anyone who knows anything about my father, that's where I'll find them!)" id ep4_10_susanflashback_6636bf8c

    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
