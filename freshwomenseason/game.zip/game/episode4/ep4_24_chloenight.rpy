
label ep4_24_chloenight:

    show ep4 chloenight_001 with long_fade
    pause 3
    show ep4 chloenight_002 with d
    pause 3
    show ep4 chloenight_003 with d
    pause 3
    jump ep4_26_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
