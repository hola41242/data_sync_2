
label ep4_09_susanhome:
    play music blood_in_the_bayou fadeout 3 fadein 3 volume 0.45
    show ep4 susanhome_001 with long_fade
    simon "(This reminds me of that day with Sue.)" id ep4_09_susanhome_8ae21e3a
    simon "(Sue seemed to think there was a lot of mystery surrounding Susan's place.)" id ep4_09_susanhome_27f4a353
    show ep4 susanhome_001_1 with d
    pause
    play sound bus_brakes
    show ep4 susanhome_002 with d
    simon "(So far though, I haven't seen anything special about it.)" id ep4_09_susanhome_b2c1a75f
    stop sound
    show ep4 susanhome_003 with d
    simon "(Except for this view maybe.)" id ep4_09_susanhome_94b93776
    show ep4 susanhome_004 with fade
    simon "(Oh, there she is.)" id ep4_09_susanhome_800989b5
    show ep4 susanhome_005 with d
    susan "Hi, [name]." id ep4_09_susanhome_caf08989
    susan "Thanks for dropping by." id ep4_09_susanhome_9db6f87b
    show ep4 susanhome_006 with d
    susan "Please come in." id ep4_09_susanhome_22104051
    show ep4 susanhome_007 with d
    simon "(I wonder if she had another talk with Lily yesterday.)" id ep4_09_susanhome_16823e55
    simon "(Does Susan know I've snooped around her place twice now?)" id ep4_09_susanhome_8278cb86
    show ep4 susanhome_008 with d
    simon "(The first time was when I came here with Sue.)" id ep4_09_susanhome_8ebc6db5
    simon "(The second time was with Chloe's drone.)" id ep4_09_susanhome_9db2bd64
    show ep4 susanhome_009 with d
    susan "Please, have a seat." id ep4_09_susanhome_8b763b26
    show ep4 susanhome_010 with d
    susan "Like I said on the phone, this won't take long." id ep4_09_susanhome_98f40a05
    show ep4 susanhome_011 with d
    susan "But first things first..." id ep4_09_susanhome_7488bd6b
    susan "Are you all right? You haven't said a word." id ep4_09_susanhome_eb45f42b
    show ep4 susanhome_012 with d
    susan "Oh, I know why that might be!" id ep4_09_susanhome_a95d9c2b
    susan "You're nervous because today is your first day of classes." id ep4_09_susanhome_f02d1782
    susan "Is that it?" id ep4_09_susanhome_b2f67f41

    menu:
        "Agree with her":
            $ ep4_susanhome_to_agree = True
            $ player_choice("ep4_susanhome_to_agree:true")
            show ep4 susanhome_013 with d
            simon "Yep." id ep4_09_susanhome_30996514
            simon "That's exactly it." id ep4_09_susanhome_797c0cf5


            if not choice_made('ep3_the_ride_tell_her_the_truth'):
                show ep4 susanhome_014 with d
                susan "Or is it really that you're nervous because you lied to me about Charlie?"
                show ep4 susanhome_015 with d
                simon "What are you talking about?" id ep4_09_susanhome_b9a35022
                show ep4 susanhome_014 with d
                susan "You said you remembered him, but you weren't telling the whole truth." id ep4_09_susanhome_39eaf50e
                show ep4 susanhome_016 with d
                susan "It's funny because I usually know when someone's lying." id ep4_09_susanhome_cb60d9a1
                susan "I guess I just wanted to believe you." id ep4_09_susanhome_3d7cc7f5
                show ep4 susanhome_017 with d
                susan "But after talking to Lily, I decided to investigate things further." id ep4_09_susanhome_d759e8fb
                susan "Charlie was on the phone when the accident happened." id ep4_09_susanhome_6639e5f6
                show ep4 susanhome_018 with d
                susan "He was talking to you, wasn't he?" id ep4_09_susanhome_c8a42854
                susan "You called his phone more than a few times." id ep4_09_susanhome_446055a3
                show ep4 susanhome_019 with d
                susan "He wasn't the type to talk on the phone when he was driving." id ep4_09_susanhome_b1af64d1
                susan "He always said it was dangerous." id ep4_09_susanhome_374ce131
                show ep4 susanhome_020 with d
                susan "But you were very persistent, weren't you, [name]?" id ep4_09_susanhome_e3289b0f
                show ep4 susanhome_021 with d
                simon "I..." id ep4_09_susanhome_9bf3b23a
                simon "I needed to talk to him." id ep4_09_susanhome_b179ebac
            else:

                show ep4 susanhome_022 with d
                susan "But that's not all, is it?" id ep4_09_susanhome_07a6df94
                show ep4 susanhome_014 with d
                susan "The last time we talked, you tried telling me that you remembered Charlie." id ep4_09_susanhome_18f1df32
                susan "But I didn't listen. And now you probably don't trust me." id ep4_09_susanhome_8d6622aa
                show ep4 susanhome_023 with d
                simon "Well, do you believe me now?" id ep4_09_susanhome_7d435976
                show ep4 susanhome_024 with d
                susan "I do." id ep4_09_susanhome_f7315852
                show ep4 susanhome_025 with d
                susan "I found out he was talking on the phone at the time of the accident." id ep4_09_susanhome_f463dd8b
                susan "Was it with you?" id ep4_09_susanhome_bcb68086

                menu:
                    "Yes, it was with me":
                        $ ep4_susanhome_yea = True

                        $ player_choice("ep4_susanhome_yea:true")
                        show ep4 susanhome_026 with d
                        simon "It was. I was so mad at him for some reason." id ep4_09_susanhome_b90d8204
                        show ep4 susanhome_027 with d
                        simon "I think I might have been the reason he got distracted." id ep4_09_susanhome_fd2dde33
                    "Lie and say no":

                        $ ep4_susanhome_no = True
                        $ player_choice("ep4_susanhome_no:true")
                        $ points_susan -= 1

                        show ep4 susanhome_028 with d
                        simon "No. It must have been someone else." id ep4_09_susanhome_7a1fcd97
                        show ep4 susanhome_029 with d
                        susan "Liar." id ep4_09_susanhome_bc9dcc4e
                        susan "It's as plain as the look on your face." id ep4_09_susanhome_b134f4a1



            play music big_man fadein 2 volume 0.45
            show ep4 susanhome_030 with vpunch
            sue "WHAT?!" id ep4_09_susanhome_15efdb31
            show ep4 susanhome_031 with d
            sue "So it was your fault that my uncle..." id ep4_09_susanhome_d24d7c77
            show ep4 susanhome_032 with d
            sue "All of that was because of you!" id ep4_09_susanhome_ae459692
            show ep4 susanhome_033 with d
            simon "Sue!" id ep4_09_susanhome_6635eb6b
            simon "No, I —" id ep4_09_susanhome_f87a8999
            show ep4 susanhome_034 with d
            sue "After everything auntie did for your father!" id ep4_09_susanhome_fc7c7f6f
            show ep4 susanhome_035 with d
            simon "What are you talking about?!" id ep4_09_susanhome_cd71b2bb
            show ep4 susanhome_036 with d
            susan "*Sigh.* Sue, please..." id ep4_09_susanhome_90e1a3ce
            susan "Go back to your room." id ep4_09_susanhome_90025965
            show ep4 susanhome_037 with d
            sue "What?! Why?" id ep4_09_susanhome_0f07b378
            show ep4 susanhome_038 with d
            sue "If anyone should go anywhere, it's him!" id ep4_09_susanhome_a79e067b
            sue "He should go to jail!" id ep4_09_susanhome_d09636c9
            show ep4 susanhome_039 with d
            susan "Sue, please." id ep4_09_susanhome_508b1073
            show ep4 susanhome_040 with d
            sue "Fuck this!" id ep4_09_susanhome_5a34b1cc
            stop music fadeout 5 
            show ep4 susanhome_041 with d
            simon "Will she be okay?" id ep4_09_susanhome_fdb41f8c
            show ep4 susanhome_042 with d
            susan "Eventually." id ep4_09_susanhome_b13b9381
            show ep4 susanhome_043 with d
            simon "How about you? Aren't you going to yell at me too?" id ep4_09_susanhome_2c8585f4
            show ep4 susanhome_044 with d
            susan "I... I can't even process what's going on right now, [name]." id ep4_09_susanhome_a1d4958d
            show ep4 susanhome_045 with d
            simon "I've told you everything I know." id ep4_09_susanhome_ed6f0811
            simon "I guess you'll just have to think it over later." id ep4_09_susanhome_d04256b5
            simon "But for now, I want to know what Sue meant by \"everything\" you did for my father."
            show ep4 susanhome_046 with d
            susan "Well..."

            show ep4 susanhome_047 with d
            susan "If we're going there, we'd better talk outside."
            susan "It's high time you found out what really happened to your father."
            jump ep4_09_susanhome_badending
        "Tell the truth"(True):

            $ ep4_susanhome_tell_the_truth = True
            $ player_choice("ep4_susanhome_tell_the_truth:true")
            show ep4 susanhome_059 with d
            simon "(What have I got to lose?)" id ep4_09_susanhome_c28bffe1
            show ep4 susanhome_060 with d
            simon "Have you talked to Lily the past few days?" id ep4_09_susanhome_7f39c1ca
            show ep4 susanhome_061 with d
            susan "Huh?"
            susan "I mean, not today or yesterday, but she did drop by the day before that." id ep4_09_susanhome_e6c42bb9
            show ep4 susanhome_062 with d
            simon "Good. Then you still don't know." id ep4_09_susanhome_2211675b
            show ep4 susanhome_063 with d
            susan "Still don't know what?" id ep4_09_susanhome_9beb1651
            show ep4 susanhome_064 with d
            simon "I wanted to know more about my father, but no one would give me any straight answers." id ep4_09_susanhome_ee3988ba
            show ep4 susanhome_065 with d
            simon "Not you, not Lily, not my mother..." id ep4_09_susanhome_a8874bcc
            simon "So I decided to investigate it myself." id ep4_09_susanhome_50b848f5
            show ep4 susanhome_066 with d
            simon "Let's just say, I know you know a lot more than you're letting on." id ep4_09_susanhome_0fdf58d6
            show ep4 susanhome_067 with d
            susan "[name], we've talked about this." id ep4_09_susanhome_d76c17d0
            show ep4 susanhome_068 with d
            simon "No. We really haven't." id ep4_09_susanhome_387b6dde
            simon "Otherwise, you would have told me about the \"awful things\" you guys did to my father."
            show ep4 susanhome_069 with d
            susan "What? How do you know about that?" id ep4_09_susanhome_dfdadd7b
            susan "Have you been spying on me, [name]?" id ep4_09_susanhome_fdcc4049
            show ep4 susanhome_070 with d
            simon "I ha —" id ep4_09_susanhome_fee1021f
            stop music fadeout 3
            show ep4 susanhome_071 with d
            sue "Shit." id ep4_09_susanhome_b049befc
            show ep4 susanhome_072 with d
            susan "Sue? You up and moving?" id ep4_09_susanhome_01331fd2
            show ep4 susanhome_073 with d
            sue "Yeah. I just woke up." id ep4_09_susanhome_9bc398cb
            show ep4 susanhome_074 with d
            susan "Give me a second, [name]." id ep4_09_susanhome_9c2576a0
            show ep4 susanhome_075 with d
            susan "Is everything all right?" id ep4_09_susanhome_30903563
            show ep4 susanhome_076 with d
            sue "I'm just a little dizzy is all." id ep4_09_susanhome_3517a32d
            sue "Could you get me some water?" id ep4_09_susanhome_5be7c799
            show ep4 susanhome_077 with d
            susan "Of course!" id ep4_09_susanhome_83e40f60
            show ep4 susanhome_078 with d
            susan "I'll be right back." id ep4_09_susanhome_66c1a823
            play music big_man fadein 3 volume 0.45
            show ep4 susanhome_079 with d
            sue "*Whispers.* Hey, moron!" id ep4_09_susanhome_f738f3db
            show ep4 susanhome_080 with d
            sue "What in the fuck do you think you're doing?!" id ep4_09_susanhome_a3c98699
            show ep4 susanhome_081 with d
            simon "Sue? What are you doing here?" id ep4_09_susanhome_f997a19b
            show ep4 susanhome_082 with d
            sue "I'm just hanging around, not being an idiot." id ep4_09_susanhome_cfc444d3
            sue "Unlike you apparently." id ep4_09_susanhome_b79d0695
            show ep4 susanhome_083 with d
            simon "What?" id ep4_09_susanhome_708b4972
            show ep4 susanhome_084 with d
            sue "What the fuck are you telling her?" id ep4_09_susanhome_88d70a08
            show ep4 susanhome_085 with d
            simon "The truth. I have to." id ep4_09_susanhome_33e762d5
            show ep4 susanhome_086 with d
            susan "What truth, [name]?" id ep4_09_susanhome_df4a1a22

            menu:
                "I have been spying on you"(True):
                    $ ep4_susanhome_i_was_spying_on_you = True
                    $ player_choice("ep4_susanhome_i_was_spying_on_you:true")
                    show ep4 susanhome_087 with d
                    simon "I have been spying on you, Susan." id ep4_09_susanhome_a0b68ede
                    play sound glass_break 
                    show ep4 susanhome_089_1 with vpunch
                    pause 0.5
                    show ep4 susanhome_088 with d

                    susan "What?"
                    show ep4 susanhome_090 with d
                    simon "You know I came to this town looking for information on my father." id ep4_09_susanhome_3c833d50
                    show ep4 susanhome_091 with d
                    simon "Nobody, you included, would tell me anything, so I figured out a way." id ep4_09_susanhome_41c0a648
                    show ep4 susanhome_092 with d
                    susan "You figured out a way? And that involved spying on me?" id ep4_09_susanhome_b31a2b80
                    show ep4 susanhome_093 with d
                    susan "What? Have you set up cameras all around my house?" id ep4_09_susanhome_143479e9
                    show ep4 susanhome_094 with d
                    simon "Actually, we used a drone." id ep4_09_susanhome_8d62177c
                    show ep4 susanhome_095 with d
                    susan "Seriously?" id ep4_09_susanhome_5d53fea3
                    show ep4 susanhome_094 with d
                    simon "I had help from a friend." id ep4_09_susanhome_9baa00e9
                    simon "Someone from college." id ep4_09_susanhome_63915f42
                    show ep4 susanhome_096 with d
                    susan "Wow... I had no idea you'd stoop so low." id ep4_09_susanhome_4de3c242
                    show ep4 susanhome_097 with d
                    susan "But getting to the bottom of this is clearly very important to you." id ep4_09_susanhome_33815b13
                    susan "It's not something you're going to let go." id ep4_09_susanhome_41cffee6
                    show ep4 susanhome_098 with d
                    sue "So, what did you find out?" id ep4_09_susanhome_c7b1eda2
                    show ep4 susanhome_099 with d
                    susan "Sue?" id ep4_09_susanhome_4bbefb44
                    susan "Are you in on this too?" id ep4_09_susanhome_2b41600a
                    show ep4 susanhome_100 with d
                    sue "I... I, umm..." id ep4_09_susanhome_1e1b669d

                    menu:
                        "No, I acted alone"(True):
                            $ ep4_susanhome_no = True
                            $ player_choice("ep4_susanhome_no:true")
                            $ points_sue += 1
                            show ep4 susanhome_101 with d
                            simon "No, she had no idea what I was doing." id ep4_09_susanhome_01f05409
                            show ep4 susanhome_102 with d
                            susan "Okay." id ep4_09_susanhome_f49ee96d
                            show ep4 susanhome_103 with d
                            susan "Well then... what did you learn exactly?" id ep4_09_susanhome_7dd14b62
                            show ep4 susanhome_104 with d
                            simon "I found out that you, Lily, and Sam did something to my father." id ep4_09_susanhome_a567f6a3
                            show ep4 susanhome_105 with d
                            simon "Maybe Charlie too, for all I know." id ep4_09_susanhome_0d51b205
                            show ep4 susanhome_106 with d
                            sue "What?!" id ep4_09_susanhome_bb6f85b9
                            show ep4 susanhome_107 with d
                            simon "Where's my father?!" id ep4_09_susanhome_d3fb8f58
                            show ep4 susanhome_108 with d
                            susan "Oh, [name]..." id ep4_09_susanhome_4021f372
                            show ep4 susanhome_109 with d
                            susan "I really don't know." id ep4_09_susanhome_56713a67
                            show ep4 susanhome_110 with d
                            simon "Stop with the lies." id ep4_09_susanhome_7ebc3ce2
                            simon "I didn't lie to you. The least you could do is grant me that common courtesy." id ep4_09_susanhome_cc27d8bf
                            show ep4 susanhome_111 with d
                            susan "Well..."
                            show ep4 susanhome_112 with d
                            susan "The truth is, I really don't know where your father could be, [name]." id ep4_09_susanhome_187df086
                            show ep4 susanhome_113 with d
                            simon "What's that supposed to mean?" id ep4_09_susanhome_181107cc
                            show ep4 susanhome_114 with d
                            simon "Then what about all the terrible things you did to him?" id ep4_09_susanhome_14c2bd2b
                            show ep4 susanhome_115 with d
                            sue "Uncle Charlie had nothing to do with it. I can tell you that much!" id ep4_09_susanhome_bd8a6e18
                            show ep4 susanhome_116 with d
                            simon "Then why was I so angry at him that night?" id ep4_09_susanhome_d711147f
                            show ep4 susanhome_117 with d
                            sue "What night?" id ep4_09_susanhome_50fa156b
                            show ep4 susanhome_118 with vpunch
                            simon "THE NIGHT OF THE ACCIDENT." id ep4_09_susanhome_c9565209
                            simon "I was talking to him on the phone." id ep4_09_susanhome_a55766d4
                            show ep4 susanhome_119 with d
                            simon "We argued, and right after he got in that car crash." id ep4_09_susanhome_9eb27a63
                            show ep4 susanhome_120 with d
                            sue "What...?" id ep4_09_susanhome_2b986c87
                            sue "So you...?" id ep4_09_susanhome_10df7d68
                            sue "It was your fault that he...?" id ep4_09_susanhome_8bae1111
                            show ep4 susanhome_121 with d
                            simon "I don't know. I still can't remember everything clearly." id ep4_09_susanhome_de7c35ce
                            simon "But that might be the case." id ep4_09_susanhome_fcd496e8
                            show ep4 susanhome_122 with d
                            simon "Honestly, I have no idea who I was back then or why I treated Charlie so badly." id ep4_09_susanhome_3f569df1
                            simon "But this new me is being honest with you, and I've told you everything I know." id ep4_09_susanhome_b32c3f0c
                            show ep4 susanhome_123 with d
                            simon "So it's your turn, Susan." id ep4_09_susanhome_e1d83515
                            show ep4 susanhome_124 with d
                            susan "I... I need some time to process all of this." id ep4_09_susanhome_a403a43a
                            show ep4 susanhome_125 with d
                            simon "No. I don't have any more time to waste." id ep4_09_susanhome_a09707d3
                            show ep4 susanhome_126 with d
                            susan "Well then." id ep4_09_susanhome_fbdf4fcb
                            susan "Let's talk." id ep4_09_susanhome_99675236
                            show ep4 susanhome_127 with d
                            sue "What?! Did you hear what he just confessed to?" id ep4_09_susanhome_fac6be34
                            show ep4 susanhome_128 with d
                            susan "Yes, Sue. He just told us everything." id ep4_09_susanhome_d7121a41
                            susan "But no matter what he did, he deserves to know what happened." id ep4_09_susanhome_5b68f17c
                            show ep4 susanhome_129 with d
                            simon "(Finally!)" id ep4_09_susanhome_7d309131
                            show ep4 susanhome_130 with d
                            sue "But, auntie —!" id ep4_09_susanhome_5f94166b
                            show ep4 susanhome_131 with d
                            susan "Sue. You should leave." id ep4_09_susanhome_1b1b5940
                            show ep4 susanhome_132 with d
                            stop music fadeout 3
                            sue "But, I..." id ep4_09_susanhome_0183d124
                            show ep4 susanhome_133 with d
                            sue "Fine." id ep4_09_susanhome_8394ec67
                            sue "But this isn't over!" id ep4_09_susanhome_705a3439
                            show ep4 susanhome_134 with d

                            susan "Come on, [name]. It's time for me to tell you the truth."
                            jump ep4_09_susanhome_goodending
                        "She knew all about it!":

                            $ ep4_susanhome_suespy1 = True
                            $ player_choice("ep4_susanhome_suespy1:true")
                            jump ep4_09_susanhome_suespy
                "Sue sent me to spy on you":

                    $ ep4_susanhome_suespy2 = True
                    $ player_choice("ep4_susanhome_suespy2:true")

                    jump ep4_09_susanhome_suespy


label ep4_09_susanhome_suespy:
    $ points_sue -= 1
    show ep4 susanhome_155 with d
    simon "Sue asked me to snoop around your place." id ep4_09_susanhome_suespy_e64d22e7
    simon "She thinks there's something fishy going on with you." id ep4_09_susanhome_suespy_11db7954
    show ep4 susanhome_156 with d
    simon "And that you had something to do with Charlie's accident." id ep4_09_susanhome_suespy_a92e31b5
    show ep4 susanhome_157 with d
    sue "What are you doing?" id ep4_09_susanhome_suespy_19c57586
    show ep4 susanhome_158 with d
    susan "Is this...? Is this true, Sue?" id ep4_09_susanhome_suespy_d8ab9353
    show ep4 susanhome_159 with d
    sue "N-no..." id ep4_09_susanhome_suespy_eb2feb04
    show ep4 susanhome_160 with d
    susan "Do you really think I would have done anything to hurt Charlie?" id ep4_09_susanhome_suespy_08fa00eb
    show ep4 susanhome_161 with d
    sue "I don't know!" id ep4_09_susanhome_suespy_43c03976
    show ep4 susanhome_162 with d
    sue "You just act so weird all the time!" id ep4_09_susanhome_suespy_2be26e7a
    sue "I never know what you're really feeling." id ep4_09_susanhome_suespy_ad48e2de
    show ep4 susanhome_163 with d
    susan "What do you want me to do?" id ep4_09_susanhome_suespy_1415e555
    susan "Mope around the house all day?" id ep4_09_susanhome_suespy_e9c614c0
    show ep4 susanhome_164 with d
    susan "You're making this into an obsession, Sue!" id ep4_09_susanhome_suespy_098eff1f
    susan "Everyone has their own way of dealing with grief!" id ep4_09_susanhome_suespy_ee6e1f5c
    show ep4 susanhome_165 with d
    sue "I just want to know what happened to my uncle!" id ep4_09_susanhome_suespy_a8a7dfe5

    menu:
        "Tell her what happened"(True):
            $ ep4_susanhome_tell_what_happened = True
            $ player_choice("ep4_susanhome_tell_what_happened:true")
            show ep4 susanhome_166 with d
            simon "I... may have an answer for you." id ep4_09_susanhome_suespy_2d921435
            show ep4 susanhome_167 with d
            sue "What do you mean?" id ep4_09_susanhome_suespy_3c7f2a57
            show ep4 susanhome_168 with d
            susan "Yeah. What do you mean, [name]?" id ep4_09_susanhome_suespy_ef71e3c2
            show ep4 susanhome_169 with d
            simon "I told you I remembered Charlie." id ep4_09_susanhome_suespy_c04e9e95
            simon "We were talking on the phone..." id ep4_09_susanhome_suespy_b997be39
            show ep4 susanhome_170 with d
            simon "... on the night of the accident." id ep4_09_susanhome_suespy_494386d5
            show ep4 susanhome_171 with d
            susan "Charlie always had a strict rule against talking on the phone when he was driving..." id ep4_09_susanhome_suespy_affcb9b5
            show ep4 susanhome_172 with d
            simon "It was an important call." id ep4_09_susanhome_suespy_8d0a265b
            simon "I don't remember what it was about, but I remember being very angry at him." id ep4_09_susanhome_suespy_5de70a8f
            show ep4 susanhome_173 with d
            simon "Maybe that's how he lost control." id ep4_09_susanhome_suespy_2b51864a
            show ep4 susanhome_174 with d
            sue "Why were you mad at Uncle Charlie?!" id ep4_09_susanhome_suespy_9c55af07
            show ep4 susanhome_175 with d
            simon "I don't know." id ep4_09_susanhome_suespy_4ec05ed7
            simon "I'd love to figure that out though." id ep4_09_susanhome_suespy_98043d86
            show ep4 susanhome_176 with d
            simon "It was so... weird." id ep4_09_susanhome_suespy_cfc945f7
            simon "It didn't feel like it was really me in that memory." id ep4_09_susanhome_suespy_98453d6f
            show ep4 susanhome_177 with d
            sue "What?! Don't give me that shit!" id ep4_09_susanhome_suespy_3c3aaf67
            sue "Are you telling me you're some new man or something?" id ep4_09_susanhome_suespy_a3ee7330
            show ep4 susanhome_178 with d
            sue "Oh please!" id ep4_09_susanhome_suespy_c28b9caf
            show ep4 susanhome_179 with d
            susan "Sue."
            show ep4 susanhome_180 with d
            sue "What?" id ep4_09_susanhome_suespy_0ae7b6b7
            show ep4 susanhome_181 with d
            susan "Maybe you should hang out in your room for a while." id ep4_09_susanhome_suespy_03acaa3e
            show ep4 susanhome_182 with d
            sue "What? Why?" id ep4_09_susanhome_suespy_b329a640
            show ep4 susanhome_183 with d
            susan "This matter is more delicate than it seems." id ep4_09_susanhome_suespy_f84970d9
            show ep4 susanhome_184 with d
            sue "I won't be left out again!" id ep4_09_susanhome_suespy_4315de13
            show ep4 susanhome_185 with d
            susan "Sue."
            susan "I promise to tell you everything you want to know." id ep4_09_susanhome_suespy_3b4dee6e
            stop music fadeout 5
            susan "But please just go to your room for now." id ep4_09_susanhome_suespy_354da8d1

            show ep4 susanhome_186 with d
            sue "Fine. Whatever." id ep4_09_susanhome_suespy_bb365526
            show ep4 susanhome_187 with d
            sue "And you... We're going to have a little chat later on." id ep4_09_susanhome_suespy_8451db07
            show ep4 susanhome_188 with d
            sue "Fucktard." id ep4_09_susanhome_suespy_259f29a7
            show ep4 susanhome_135_1 with d
            susan "Come on, [name]. It's time I told you the truth."

            jump ep4_09_susanhome_goodending
        "Don't say anything":

            $ ep4_susanhome_not_say_anything = True
            $ player_choice("ep4_susanhome_not_say_anything:true")
            show ep4 susanhome_189 with d
            simon "I think there are just some things we'll never find out." id ep4_09_susanhome_suespy_e0f427df
            show ep4 susanhome_190 with d
            susan "Is that so?" id ep4_09_susanhome_suespy_e1906dea
            susan "Because I distinctly remember you telling me you remembered Charlie." id ep4_09_susanhome_suespy_18998e52
            show ep4 susanhome_191 with d
            simon "Shit..." id ep4_09_susanhome_suespy_27ead22b
            show ep4 susanhome_135_1 with d
            susan "Anyway, we should continue this talk outside."
            susan "It's high time you found out what really happened to your father."
            jump ep4_09_susanhome_badending

label ep4_09_susanhome_badending:

    show ep4 susanhome_048 with fade
    simon "Are you really going to tell me?"
    show ep4 susanhome_049 with d
    susan "I'm not happy with how this happened, [name]." id ep4_09_susanhome_badending_4e1e1514
    susan "But you deserve to know the truth." id ep4_09_susanhome_badending_f3311285
    show ep4 susanhome_050 with d
    susan "Sit."
    call ep4_10_susanflashback from _call_ep4_10_susanflashback
    show ep4 susanhome_051 with d
    susan "The fact is, that's why I responded to your message in the first place." id ep4_09_susanhome_badending_25b0aa6c
    susan "I wanted to ask for your help with something at the event." id ep4_09_susanhome_badending_99e0b056
    show ep4 susanhome_052 with d
    susan "But after everything I've heard today..." id ep4_09_susanhome_badending_042da371
    susan "I don't know if I'm comfortable counting on you." id ep4_09_susanhome_badending_b840a671
    show ep4 susanhome_053 with d
    susan "Sue and I are going to need some time to work through this." id ep4_09_susanhome_badending_e22b44c7


    show ep4 susanhome_055 with d
    simon "I get it." id ep4_09_susanhome_badending_ed76ed5d
    simon "I think I should go." id ep4_09_susanhome_badending_69d3e612
    show ep4 susanhome_056 with d
    susan "That would probably be for the best." id ep4_09_susanhome_badending_6e2df224
    show ep4 susanhome_057 with d
    susan "I'll walk you to the door." id ep4_09_susanhome_badending_96261e1c

    stop music fadeout 5
    show ep4 susanhome_058 with d
    simon "That's not necessary." id ep4_09_susanhome_badending_75f0b7ab
    simon "I'll show myself out." id ep4_09_susanhome_badending_73d285de

    jump ep4_11_suetalk

label ep4_09_susanhome_goodending:
    if choice_made('ep4_susanhome_i_was_spying_on_you'):
        show ep4 susanhome_135 with d
        simon "Where are we going exactly?" id ep4_09_susanhome_goodending_fcfd943e
        show ep4 susanhome_136 with fade
        susan "I just wanted to make sure there weren't any drones flying circles over my head." id ep4_09_susanhome_goodending_b91ac974
        show ep4 susanhome_137 with d
        simon "Okay. I deserved that one." id ep4_09_susanhome_goodending_649db933
    else:
        show ep4 susanhome_048 with fade
        simon "Are you really going to tell me?"

    $ debug_other_path()
    show ep4 susanhome_049 with d
    susan "You deserve to know the truth." id ep4_09_susanhome_goodending_105731b8
    show ep4 susanhome_050 with d
    susan "Have a seat."
    call ep4_10_susanflashback from _call_ep4_10_susanflashback_1

    play music stay_lost_with_me fadeout 2 fadein 5 volume 0.45
    show ep4 susanhome_050 with d
    susan "Please, let's sit back down. I'm not quite done yet." id ep4_09_susanhome_goodending_5f33228b
    show ep4 susanhome_138 with d
    susan "If that settles things, there's something about the event I could really use your help with." id ep4_09_susanhome_goodending_0896d7c4
    show ep4 susanhome_139 with d
    susan "I'd pay extra of course." id ep4_09_susanhome_goodending_afb94300
    show ep4 susanhome_140 with d
    simon "(God knows I could use some extra cash.)" id ep4_09_susanhome_goodending_775fbd1e
    show ep4 susanhome_141 with d
    simon "Sure. I'm in." id ep4_09_susanhome_goodending_ff0bfdd5
    show ep4 susanhome_142 with d
    susan "Excellent."
    susan "I need you to make an out-of-town delivery." id ep4_09_susanhome_goodending_ae6df03b
    show ep4 susanhome_143 with d
    simon "Ummm... On a bike...?" id ep4_09_susanhome_goodending_e64ed2fd
    show ep4 susanhome_144 with d
    susan "Of course not." id ep4_09_susanhome_goodending_ed9eba61
    susan "You'll accompany my driver." id ep4_09_susanhome_goodending_c834e547
    susan "Then you'll get back the day after the ball." id ep4_09_susanhome_goodending_9d07f202
    show ep4 susanhome_140 with d
    simon "(Not good.)" id ep4_09_susanhome_goodending_b98044d7
    if choice_made('ep3_07_cafe2_agree_to_help'):
        simon "(I promised Alyssa I'd dance with her group.)" id ep4_09_susanhome_goodending_595e585d
        simon "(But I can't exactly tell Susan about that.)" id ep4_09_susanhome_goodending_4ca72052
        show ep4 susanhome_148 with d
        simon "Actually, I can't." id ep4_09_susanhome_goodending_728cde27
        simon "I already have important plans for that night." id ep4_09_susanhome_goodending_47973c6c
        show ep4 susanhome_150 with d
        susan "Well, I guess I can find someone else in time."
        susan "Plus, we both could probably use some time apart to think about what we discussed today."
        susan "Maybe it's for the best."
        show ep4 susanhome_151 with d
        simon "Thank you, Susan."
    else:
        simon "(I need to go to the ball.)" id ep4_09_susanhome_goodending_abf716a5
        simon "(But I could also use the money.)" id ep4_09_susanhome_goodending_97aaf7c4
        simon "(What should I do?)" id ep4_09_susanhome_goodending_16d9ddc7

        menu:
            "Take the job"(True):
                $ ep4_susanhome_accept_the_job = True
                $ player_choice("ep4_susanhome_accept_the_job:true")
                show ep4 susanhome_145 with d
                simon "All right. I'll do it." id ep4_09_susanhome_goodending_63079082
                show ep4 susanhome_146 with d
                susan "Excellent."
                susan "On the day of the ball, I'll be waiting for you at the store after noon." id ep4_09_susanhome_goodending_9714be4a
                show ep4 susanhome_147 with d
                simon "Got it." id ep4_09_susanhome_goodending_3c2f5362
            "Don't take the job":

                $ ep4_susanhome_refuse_work = True
                $ player_choice("ep4_susanhome_refuse_work:true")
                show ep4 susanhome_148 with d
                simon "Um... Is it okay if I didn't?" id ep4_09_susanhome_goodending_44f940d8
                show ep4 susanhome_149 with d
                susan "Oh... Well, you messaged about work, so I figured you'd take the job." id ep4_09_susanhome_goodending_f9928ec1
                show ep4 susanhome_150 with d
                susan "Well, I guess I can find someone else in time."
                susan "Plus, we both could probably use some time apart to think about what we discussed today."
                susan "Maybe it's for the best."
                show ep4 susanhome_151 with d
                simon "Thank you, Susan."

    show ep4 susanhome_152 with d
    simon "Well, I should go." id ep4_09_susanhome_goodending_1ad53053
    show ep4 susanhome_153 with d
    susan "Yes, of course." id ep4_09_susanhome_goodending_4881b1a6
    stop music fadeout 5
    show ep4 susanhome_154 with d
    susan "Have a nice day, [name]." id ep4_09_susanhome_goodending_d6e72820
    jump ep4_11_suetalk
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
