label ep4_205_nightleaving:

play music idk volume 1 fadein 2
play sound door_closing2
show ep4 nightleaving_1 with Dissolve(3.0)
pause 5.0
show ep4 nightleaving_2 with d
pause 5.0
play sound door_opening
show ep4 nightleaving_3 with d
pause 5.0
show ep4 nightleaving_4 with d
pause 5.0
show ep4 nightleaving_5 with d
pause 5.0
show ep4 nightleaving_21 with d
pause 5.0
show ep4 nightleaving_22 with d
pause 5.0
show ep4 nightleaving_23 with d
pause 5.0
show ep4 nightleaving_6 with d
pause 5.0
show ep4 nightleaving_7 with d
pause 5.0
show ep4 nightleaving_8 with d
pause 5.0
show ep4 nightleaving_9 with d
pause 5.0
show ep4 nightleaving_10 with d
pause 5.0
show ep4 nightleaving_24 with d
pause 5.0
show ep4 nightleaving_25 with d
pause 5.0
show ep4 nightleaving_19 with d
pause 5.0
show ep4 nightleaving_20 with d
pause 5.0
show ep4 nightleaving_26 with d
pause 5.0
show ep4 nightleaving_11 with d
pause 5.0
show ep4 nightleaving_12 with d
pause 5.0
play sound light_switch_dimmer
show ep4 nightleaving_13 with d
pause 5.0
play sound door_closing2 
show ep4 nightleaving_14 with d
pause 5.0
show ep4 nightleaving_15 with d
pause 5.0
show ep4 nightleaving_27 with d
pause 5.0

if choice_made('ep4_livingsituation_here'):

    show ep4 nightleaving_16 with d
    pause 5.0
    show ep4 nightleaving_17 with d
    pause 5.0
    show ep4 nightleaving_18 with d
    pause 5.0

    jump ep4_21_alyssanight


if choice_made('ep4_livingsituation_julia'):

    show ep4 nightleaving_16 with d
    pause 5.0
    show ep4 nightleaving_17 with d
    pause 5.0
    show ep4 nightleaving_18 with d
    pause 5.0

    jump ep4_22_julianight



if choice_made('ep4_livingsituation_sue'):

    show ep4 nightleaving_28 with d
    pause 5.0
    show ep4 nightleaving_29 with d
    pause 5.0
    play sound car_horn_honk_26 volume 0.8
    show ep4 nightleaving_30 with d
    pause 5.0

    jump ep4_23_suenight


if choice_made('ep4_livingsituation_chloe'):

    show ep4 nightleaving_16 with d
    pause 5.0
    show ep4 nightleaving_17 with d
    pause 5.0
    show ep4 nightleaving_18 with d
    pause 5.0

    jump ep4_24_chloenight



show ep4 nightleaving_28 with d
pause 5.0
show ep4 nightleaving_29 with d
pause 5.0
play sound car_horn_honk_26 volume 0.8
show ep4 nightleaving_30 with d
pause 5.0

jump ep4_25_dylannight
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
