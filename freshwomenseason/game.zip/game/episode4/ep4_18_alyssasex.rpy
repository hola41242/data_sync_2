label ep4_18_alyssasex:
play music circle volume 0.35 fadeout 2 fadein 2
show ep4 alyssasex_001 with long_fade
simon "I don't know how you do it!" id ep4_18_alyssasex_28238bb2
simon "You haven't even broken a sweat." id ep4_18_alyssasex_4c973a06
show ep4 alyssasex_002 with d
alyssa "I think you get used to it over time!" id ep4_18_alyssasex_64e7094c
alyssa "There are days when I finish practice and just go straight home. It's like second nature to me now." id ep4_18_alyssasex_ce4e992a
show ep4 alyssasex_003 with d
alyssa "Today even tired me out though." id ep4_18_alyssasex_cc2bd879
alyssa "I think we deserve a warm shower." id ep4_18_alyssasex_d553aafc
show ep4 alyssasex_004 with d
simon "I wouldn't be opposed to the idea..." id ep4_18_alyssasex_e0a681b0
show ep4 alyssasex_005 with d
alyssa "Come on! The locker room is this way." id ep4_18_alyssasex_a84e40db
show ep4 alyssasex_006 with d
alyssa "But don't go getting any funny ideas!" id ep4_18_alyssasex_ee821c18
alyssa "You go to the boys' locker room, and I go to the girls'." id ep4_18_alyssasex_95eafee4
show ep4 alyssasex_007 with d
alyssa "And no peeking this time." id ep4_18_alyssasex_8e813a34
show ep4 alyssasex_008 with d
simon "How do I know you won't peek?" id ep4_18_alyssasex_f001a334
show ep4 alyssasex_009 with d
alyssa "Don't be silly! That's totally your thing." id ep4_18_alyssasex_2dcb4636
alyssa "I still haven't forgotten the day you caught a glimpse of me dancing in the café." id ep4_18_alyssasex_a11878ad
show ep4 alyssasex_010 with d
simon "Sorry about that." id ep4_18_alyssasex_7c4267e5
show ep4 alyssasex_011 with d
alyssa "I didn't mean it in a bad way!" id ep4_18_alyssasex_fc8cb1cd
alyssa "I'm not accusing you or anything." id ep4_18_alyssasex_bac1c0b9
show ep4 alyssasex_012 with d
simon "Well, I should, uh..." id ep4_18_alyssasex_08090911
show ep4 alyssasex_013 with d
alyssa "Right. Of course!" id ep4_18_alyssasex_8dd23fa9
show ep4 alyssasex_014 with d
alyssa "Everything's going to turn out all right, [name]." id ep4_18_alyssasex_9531614e
play sound door_closing2
show ep4 alyssasex_015 with d
alyssa "You'll feel like yourself again real soon." id ep4_18_alyssasex_68a1fd18
play sound bath volume 1.2
show ep4 alyssasex_016 with wiperight
simon "(I don't even know what \"myself\" is supposed to feel like.)" id ep4_18_alyssasex_df4c1c42
show ep4 alyssasex_017 with d
simon "(But I know she's just trying to help.)" id ep4_18_alyssasex_2c734424
play sound faucet_closing
show ep4 alyssasex_018 with d
simon "(The least I can do is not ruin her night with these thoughts of mine.)" id ep4_18_alyssasex_2fb11a22
show ep4 alyssasex_019 with d
simon "(Maybe I'd better just head home.)" id ep4_18_alyssasex_7044383e
show ep4 alyssasex_020 with d
simon "(I should just...)" id ep4_18_alyssasex_c6fd4c88
play sound knock_door_4_times
show ep4 alyssasex_021 with d
alyssa "[name]?" (what_italic=True)
show ep4 alyssasex_022 with d
simon "Coming." id ep4_18_alyssasex_f7e58b03
show ep4 alyssasex_023 with d
alyssa "Okay! Take your time." id ep4_18_alyssasex_a949acc2
show ep4 alyssasex_024 with d
alyssa "I only came back here because..." id ep4_18_alyssasex_b1d1a9dd
show ep4 alyssasex_025 with d
alyssa "... I don't know. I just had this weird feeling." id ep4_18_alyssasex_5b885f7a
show ep4 alyssasex_026 with d
alyssa "I know you're not in the best of moods." id ep4_18_alyssasex_66d0715a
alyssa "But I just wanted to tell you that it's okay to feel that way." id ep4_18_alyssasex_f1a6b721
show ep4 alyssasex_027 with d
alyssa "Anyone who really knows and cares for you will understand what you're going through." id ep4_18_alyssasex_bffe767d
show ep4 alyssasex_028 with d
alyssa "And I know you must be thinking that no one really knows you, but that's not true." (what_italic=True)
alyssa "You are who you are. The past doesn't matter." (what_italic=True)
show ep4 alyssasex_029 with d
alyssa "And most importantly..." id ep4_18_alyssasex_ea373905
show ep4 alyssasex_030 with d
alyssa "... you need to know that..." id ep4_18_alyssasex_9afbf810
play sound door_open5
show ep4 alyssasex_031 with d
alyssa "... you're not alone." id ep4_18_alyssasex_d20fb810
show ep4 alyssasex_032 with d
""
show ep4 alyssasex_033 with d
alyssa "My mom always says a good hug fixes all wounds." id ep4_18_alyssasex_1761d3e3
show ep4 alyssasex_034 with d
alyssa "She may not be one hundred percent correct, but it certainly makes things better, huh?" id ep4_18_alyssasex_a9f25b7a


simon "Thanks, Alyssa. I needed that." id ep4_18_alyssasex_7ebfa67c

if choice_made('ep2_alyssa_kiss') or _in_replay:
    show ep4 alyssasex_035 with d
    alyssa "Do you know how I can make it even better?" id ep4_18_alyssasex_8f4aaefe
    show ep4 alyssasex_036 with d
    simon "How?" id ep4_18_alyssasex_0d1f6d99
    show ep4 alyssasex_037_1 with d
    alyssa "Like this." id ep4_18_alyssasex_7d27d585
    show ep4 alyssasex_037 with d
    pause
    show ep4 alyssasex_038 with d
    simon "I think I needed that too." id ep4_18_alyssasex_026c8327
    show ep4 alyssasex_039 with d
    alyssa "Well then maybe you'll like..." id ep4_18_alyssasex_0ec1211e
    show ep4 alyssasex_040 with d
    alyssa "... this." id ep4_18_alyssasex_55952d7e
    pause
    show ep4 alyssasex_041 with d
    alyssa "I was thinking..." id ep4_18_alyssasex_d51801c8
    alyssa "We first met at the café. You could count that as a first date." id ep4_18_alyssasex_0a9d52c9
    show ep4 alyssasex_042 with d
    alyssa "Then you came here, and we gazed at the moon together." id ep4_18_alyssasex_e53ca5e8
    alyssa "That would be our second date." id ep4_18_alyssasex_df94d298
    show ep4 alyssasex_043 with d
    simon "That one did feel like a date, but the first one..." id ep4_18_alyssasex_fc65335f
    show ep4 alyssasex_044 with d
    alyssa "Let me finish!"
    show ep4 alyssasex_045 with d
    alyssa "That would make this our third date!" id ep4_18_alyssasex_e54856d6
    show ep4 alyssasex_046 with d
    simon "Ohhh..." id ep4_18_alyssasex_8e2120d3
    show ep4 alyssasex_047 with d
    alyssa "And you know what that means, don't you? The third date?" id ep4_18_alyssasex_b51888e2
    show ep4 alyssasex_048 with d
    simon "But if you're counting every little meeting, this would be like our fifth date..." id ep4_18_alyssasex_c0931293
    show ep4 alyssasex_049 with d
    alyssa "That just means I made you hold out even longer!" id ep4_18_alyssasex_cee1bfb4
    show ep4 alyssasex_050 with d
    simon "Hold out for what? Um... I had that accident, you know... so there are quite a few things I don't remember." id ep4_18_alyssasex_689b447b
    show ep4 alyssasex_051 with d
    simon "Would you mind spelling it out for me?" id ep4_18_alyssasex_98f70191
    show ep4 alyssasex_052 with d
    stop music fadeout 6
    alyssa "Well... usually people mark the third date with a special something..." id ep4_18_alyssasex_761efebd
    show ep4 alyssasex_053 with d
    alyssa "... They tend to take a big step forward." id ep4_18_alyssasex_d33131b4
    show ep4 alyssasex_054 with d
    alyssa "Would you like to take that step with me, [name]?" id ep4_18_alyssasex_185e5b47

    menu:
        "Take the step"(True):
            play music whole_lot_better fadein 2 volume 0.37
            $ ep4_alyssasex_take_the_step = True
            $ player_choice("ep4_alyssasex_take_the_step:true")
            show ep4 alyssasex_055 with d
            simon "I hope this answers your question..." id ep4_18_alyssasex_6b8dc3b3
            show ep4 alyssasex_056 with d
            alyssa "Mmmm..." id ep4_18_alyssasex_bea83461
            show ep4 alyssasex_057 with d
            simon "But I only want to take this step with you if you're totally comfortable with it, okay?" id ep4_18_alyssasex_b28d86b9
            show ep4 alyssasex_058 with d
            alyssa "And I hope that..." id ep4_18_alyssasex_57acda36
            play sound towel_drop volume 0.5
            show ep4 alyssasex_059 with d
            alyssa "... this answers your question." id ep4_18_alyssasex_53c7c813
            show ep4 alyssasex_060 with d:
                yalign 1.0
                ease 8 yalign 0.0
            simon "(Holy fuck...! I could get lost in those thighs...)" id ep4_18_alyssasex_511ffc35
            simon "(... and that fit body of hers.)" id ep4_18_alyssasex_7dc5c1e0
            show ep4 alyssasex_061 with d
            simon "(Will I be able to last long with her?)" id ep4_18_alyssasex_94789dc5
            show ep4 alyssasex_062 with d
            alyssa "You're not regretting your decision, are you?" id ep4_18_alyssasex_b2d37442
            play sound shirtoff3 volume 0.8
            show ep4 alyssasex_063 with d
            simon "Not one tiny little bit." id ep4_18_alyssasex_650e38ab
            show ep4 alyssasex_064 with d
            alyssa "Mmm, glad to hear it!" id ep4_18_alyssasex_1d91940c

            if choice_made('ep1_shirt_off_alyssa'):
                show ep4 alyssasex_065 with d
                alyssa "I love your battle scars." id ep4_18_alyssasex_6dbb7914
            else:

                show ep4 alyssasex_066 with d
                alyssa "(Wow, he really was serious about the scars that time.)" id ep4_18_alyssasex_15eb5d80

            show ep4 alyssasex_067 with d
            simon "(She's squeezing me tight.)" id ep4_18_alyssasex_515ffe24
            show ep4 alyssasex_068 with d
            simon "(And her breasts are pressing up against me!)" id ep4_18_alyssasex_126ae454
            simon "(They're so soft...)" id ep4_18_alyssasex_9d3a0c8c
            show ep4 alyssasex_069 with d
            simon "(I guess that, given the situation, I shouldn't be ashamed I got hard from a hug.)" id ep4_18_alyssasex_d7116a61
            show ep4 alyssasex_070 with d
            alyssa "Glad to see you so excited!" id ep4_18_alyssasex_cd877b40
            play sound jeans_off_1 volume 0.8
            show ep4 alyssasex_071 with d
            alyssa "I hope this can become one of the good new memories you can build from." id ep4_18_alyssasex_6023991c
            play sound jeans_off_2 volume 0.8
            show ep4 alyssasex_072 with d
            alyssa "Oh..."
            show ep4 alyssasex_073 with d
            alyssa "Wow..."
            show ep4 alyssasex_074 with d
            alyssa "*Giggles.*" (what_italic=True)
            show ep4 alyssasex_075 with d
            alyssa "It's the size of my forearm!" id ep4_18_alyssasex_e18f8104

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_076_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_076_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_076 with d
            alyssa "Let's see here..." id ep4_18_alyssasex_f47f5e69
            alyssa "... Do you like it when I do this?" id ep4_18_alyssasex_ea9ab990
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_077_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_077_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_077 with d
            simon "Ohhhh..." id ep4_18_alyssasex_5a09ea95
            simon "That's perfect." id ep4_18_alyssasex_1db79a37
            simon "I never would have imagined someone who exercises so much could have such soft hands." id ep4_18_alyssasex_0877d8db
            alyssa "Just because I work out, that doesn't mean I don't have a feminine side!" id ep4_18_alyssasex_832b4022
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_079_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_079_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_079 with d
            simon "Indeed."
            simon "I love your muscular form." id ep4_18_alyssasex_be975dd6
            pause

            stop foley
            stop voicefx
            show ep4 alyssasex_080 with d
            alyssa "You promise?" id ep4_18_alyssasex_25e8db9c
            show ep4 alyssasex_081 with d
            alyssa "People usually say it makes me look a bit... masculine." id ep4_18_alyssasex_b7deec70
            simon "I certainly don't think so." id ep4_18_alyssasex_55baa306
            show ep4 alyssasex_082 with d
            pause
            show ep4 alyssasex_083 with d
            simon "I see a whole lot of feminine." id ep4_18_alyssasex_e2de78cf
            show ep4 alyssasex_084 with d
            alyssa "The breasts help, I know..." id ep4_18_alyssasex_25c3ae35
            simon "(Fuck! They're almost as big as Susan's!)" id ep4_18_alyssasex_cafd4edd
            simon "(At least bigger than Lily's!)" id ep4_18_alyssasex_7d9e1a90
            show ep4 alyssasex_085 with d
            alyssa "What is it, [name]? You think they don't fit my frame?" id ep4_18_alyssasex_988920b4
            show ep4 alyssasex_086 with d
            simon "No! That's not it at all!" id ep4_18_alyssasex_e1c1c9ae
            show ep4 alyssasex_087 with d
            simon "I think they're very..." id ep4_18_alyssasex_e6749325
            show ep4 alyssasex_088 with d
            alyssa "They're very...?" id ep4_18_alyssasex_c93edebe
            show ep4 alyssasex_089 with d
            simon "Just wow..." id ep4_18_alyssasex_063ea2e3
            show ep4 alyssasex_090 with d
            alyssa "Very wow? I've never gotten that response before..." id ep4_18_alyssasex_ae0a8c6b
            show ep4 alyssasex_091 with d
            alyssa "Haha. You should see the look on your face!" id ep4_18_alyssasex_0d97bcd5
            alyssa "Relax, I'm just playing with you. I'm glad you like them." id ep4_18_alyssasex_25c6e905
            show ep4 alyssasex_092 with d
            simon "Oh... I'll show you just how much I like them." id ep4_18_alyssasex_75440e09

            show ep4 alyssasex_093_1 with d
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_093_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_093_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_093 with d
            alyssa "Mmmmm..." id ep4_18_alyssasex_2f4106af
            alyssa "[name]..." id ep4_18_alyssasex_d1bdc74c
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_094_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_094_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_094 with d
            alyssa "Aaahh!" id ep4_18_alyssasex_9858b37c
            alyssa "Oh god..." id ep4_18_alyssasex_00f31f06
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_095_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_095_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_095 with d
            alyssa "Take it easy, [name]... They're really sensitive..." id ep4_18_alyssasex_0f9a2423
            simon "Do you want me to stop?" id ep4_18_alyssasex_8018a212
            alyssa "No! Not at all! Just... take it easy..." id ep4_18_alyssasex_25ec93eb
            alyssa "... Otherwise, I'll get there way too fast." id ep4_18_alyssasex_e443dc21
            pause

            label ep4_18_alyssasex_loop1:
                menu:
                    "Handjob":
                        image ep4 anim_alyssasex_handjob_combo:
                            "ep4 anim_alyssasex_076" with Dissolve(0.1)
                            pause 5
                            "ep4 anim_alyssasex_077" with Dissolve(0.1)
                            pause 5
                            "ep4 anim_alyssasex_079" with Dissolve(0.1)
                            pause 5
                            repeat
                        $ allow_voicefx = True
                        if is_voice_installed:
                            play voicefx ep4_anim_alyssasex_handjob_combo_voicefx fadein 0.5 fadeout 0.5
                            play foley ep4_anim_alyssasex_handjob_combo_foley fadein 0.5 fadeout 0.5
                        show ep4 anim_alyssasex_handjob_combo with d
                        pause
                        jump ep4_18_alyssasex_loop1
                    "Tit sucking":
                        image ep4 anim_alyssasex_tits_combo:
                            "ep4 anim_alyssasex_093" with Dissolve(0.1)
                            pause 5
                            "ep4 anim_alyssasex_094" with Dissolve(0.1)
                            pause 5
                            "ep4 anim_alyssasex_095" with Dissolve(0.1)
                            pause 5
                            repeat
                        $ allow_voicefx = True
                        if is_voice_installed:
                            play voicefx ep4_anim_alyssasex_tits_combo_voicefx fadein 0.5 fadeout 0.5
                            play foley ep4_anim_alyssasex_tits_combo_foley fadein 0.5 fadeout 0.5
                        show ep4 anim_alyssasex_tits_combo with d
                        pause
                        jump ep4_18_alyssasex_loop1
                    "Continue" if True:
                        $ renpy.pause()

            stop foley
            stop voicefx
            show ep4 alyssasex_098 with d
            alyssa "I think I'm going to get there way too quick." id ep4_18_alyssasex_loop1_b6318a5a
            show ep4 alyssasex_099 with d
            simon "By get there you mean...?" id ep4_18_alyssasex_loop1_0dd46e34
            show ep4 alyssasex_100 with d
            simon "Aaah! Got it!" id ep4_18_alyssasex_loop1_91f9f847
            show ep4 alyssasex_099 with d
            simon "But wouldn't that be a good thing?" id ep4_18_alyssasex_loop1_989f0d65
            show ep4 alyssasex_098 with d
            alyssa "I can... get there... with you just fondling my breasts..." id ep4_18_alyssasex_loop1_9d529afe
            alyssa "Isn't that kind of... weird?" id ep4_18_alyssasex_loop1_a3e816af
            show ep4 alyssasex_101 with d
            simon "Not really." id ep4_18_alyssasex_loop1_945b3f2d
            simon "And now I just want to see that happen." id ep4_18_alyssasex_loop1_8a09cef3
            show ep4 alyssasex_102 with d
            alyssa "AAAAHHH..." id ep4_18_alyssasex_loop1_ec338fa2
            show ep4 alyssasex_103 with d
            alyssa "That feels so good, [name]... I think I'm just about there..." id ep4_18_alyssasex_loop1_a324791d
            show ep4 alyssasex_104 with d
            simon "Really?" id ep4_18_alyssasex_loop1_c1761c50
            show ep4 alyssasex_105 with d
            alyssa "Yeah." id ep4_18_alyssasex_loop1_23357989
            show ep4 alyssasex_106 with d
            alyssa "Please... just keep going..." id ep4_18_alyssasex_loop1_a4a1521f

            menu:
                "Tease her a little more":
                    $ ep4_alyssasex_tease_her_a_little_more = True
                    $ player_choice("ep4_alyssasex_tease_her_a_little_more:true")
                    show ep4 alyssasex_107 with d
                    simon "I've got an idea of how to make things more interesting." id ep4_18_alyssasex_loop1_0ccd80fb
                    play sound close_locker volume 0.8
                    show ep4 alyssasex_108 with d
                    alyssa "What are you planning to do?" id ep4_18_alyssasex_loop1_43417854
                    show ep4 alyssasex_109 with d
                    simon "I'll give you what you want." id ep4_18_alyssasex_loop1_a0b70493
                    show ep4 alyssasex_110 with d
                    simon "But you're going to have to wait a little longer for it." id ep4_18_alyssasex_loop1_34a9ca09
                    show ep4 alyssasex_111 with d
                    alyssa "Aww! That's mean!" id ep4_18_alyssasex_loop1_c3908857
                    show ep4 alyssasex_112 with d
                    alyssa "But, strangely, it makes me even more..." id ep4_18_alyssasex_loop1_8dbe9c45
                    show ep4 alyssasex_113 with d
                    simon "It makes you even more..." id ep4_18_alyssasex_loop1_204492e6
                    show ep4 alyssasex_114 with d
                    simon "... horny?" id ep4_18_alyssasex_loop1_4689df61
                    show ep4 alyssasex_115 with d
                    alyssa "How can you just blurt that out?" id ep4_18_alyssasex_loop1_8b35a324
                    alyssa "Don't tell me you're not... horny too?" id ep4_18_alyssasex_loop1_e588625c
                    show ep4 alyssasex_116 with d
                    simon "Look for yourself." id ep4_18_alyssasex_loop1_67deb4a1
                    show ep4 alyssasex_117 with d
                    alyssa "Where is this side of you coming from? I never could have imagined you'd be like this..." id ep4_18_alyssasex_loop1_3c7ffc01
                    show ep4 alyssasex_118 with d
                    alyssa "But I could get used to it." id ep4_18_alyssasex_loop1_2db17c6b
                    show ep4 alyssasex_119 with d
                    alyssa "I think I like this controlling side of you." id ep4_18_alyssasex_loop1_4aea029f
                    alyssa "And I can see you're enjoying it too." id ep4_18_alyssasex_loop1_695b8261
                    show ep4 alyssasex_120 with d
                    alyssa "I think you'll like this next part then..." id ep4_18_alyssasex_loop1_b20011c9
                "Make her cum":

                    $ ep4_alyssasex_make_her_come = True
                    $ player_choice("ep4_alyssasex_make_her_come:true")
                    show ep4 alyssasex_121 with d
                    alyssa "Aaaahhh!" id ep4_18_alyssasex_loop1_2b10a454
                    simon "It'll be worth it." id ep4_18_alyssasex_loop1_69eeb974
                    show ep4 alyssasex_122 with d
                    alyssa "Mmmmm... So good..." id ep4_18_alyssasex_loop1_efeceffe
                    show ep4 alyssasex_123 with d
                    alyssa "Aaahh... Ahh... Just like that..." id ep4_18_alyssasex_loop1_2b0bbee5
                    show ep4 alyssasex_124 with d
                    alyssa "Mmmm... [name], keep going. I'm going to... going to..." id ep4_18_alyssasex_loop1_213359c3

                    show ep4 alyssasex_125 with vpunch
                    alyssa "Aaaaaahhh..." id ep4_18_alyssasex_loop1_efa7fdbb
                    show ep4 alyssasex_126 with vpunch
                    simon "Are you okay?" id ep4_18_alyssasex_loop1_30ddab2a
                    show ep4 alyssasex_127 with d
                    alyssa "Yeah... I just..." id ep4_18_alyssasex_loop1_a22a3171
                    show ep4 alyssasex_128 with d
                    alyssa "Wow..."
                    play sound close_locker volume 0.7
                    show ep4 alyssasex_129 with d
                    alyssa "I think I need a second to catch my breath..." id ep4_18_alyssasex_loop1_53b5c6f5
                    show ep4 alyssasex_130 with d
                    simon "Well, I can always just —" id ep4_18_alyssasex_loop1_d880c4ea
                    show ep4 alyssasex_131 with d
                    alyssa "Oh no! We're not done here yet!" id ep4_18_alyssasex_loop1_1aed9f5d
                    show ep4 alyssasex_120 with d
                    alyssa "Not until you get there too." id ep4_18_alyssasex_loop1_36b1bac8

            show ep4 alyssasex_132 with d
            simon "I do love your ideas." id ep4_18_alyssasex_loop1_8f892a12
            show ep4 alyssasex_133 with d
            alyssa "Mmm... I just thought of a fairer way of moving forward..." id ep4_18_alyssasex_loop1_7d1afaaa
            show ep4 alyssasex_134 with d
            alyssa "... After all, I'm a woman of simple tastes." id ep4_18_alyssasex_loop1_d31f2630
            alyssa "I get there real quick." id ep4_18_alyssasex_loop1_de91460c
            show ep4 alyssasex_135 with d
            alyssa "But with you I'll have to use..." id ep4_18_alyssasex_loop1_4a84dfa3
            show ep4 alyssasex_136 with d
            alyssa "... other methods." id ep4_18_alyssasex_loop1_97ff543b
            show ep4 alyssasex_137 with d
            simon "Don't worry. I'm in no rush." id ep4_18_alyssasex_loop1_d27192d6
            simon "I'll take it easy with you. You ready?" id ep4_18_alyssasex_loop1_f68dfb00
            show ep4 alyssasex_138 with d
            alyssa "Like a true gentleman! I'm ready." id ep4_18_alyssasex_loop1_cf9319b9
            show ep4 alyssasex_139 with d
            simon "Then allow me to..." id ep4_18_alyssasex_loop1_60f70207
            show ep4 alyssasex_140 with d
            alyssa "Aaaahh..." id ep4_18_alyssasex_loop1_8386a685
            show ep4 alyssasex_141 with d
            alyssa "(I don't think I was as ready as I thought...)" id ep4_18_alyssasex_loop1_1a2a70cc
            show ep4 alyssasex_142 with d
            alyssa "(And he hasn't even put it all in yet.)" id ep4_18_alyssasex_loop1_a6432859
            alyssa "(A true, true gentleman!)" id ep4_18_alyssasex_loop1_bfc8acc6
            show ep4 alyssasex_143 with d
            alyssa "(I want him to stick it all in.)" id ep4_18_alyssasex_loop1_a4892041
            alyssa "(But I don't want to have to ask for it...)" id ep4_18_alyssasex_loop1_cef53b52
            show ep4 alyssasex_144 with d
            alyssa "(Ah! I think I've got an idea!)" id ep4_18_alyssasex_loop1_a9b4f19b
            show ep4 alyssasex_145 with d
            alyssa "Hey, [name]... You're strong, aren't you?" id ep4_18_alyssasex_loop1_2d546a10
            show ep4 alyssasex_146 with d
            simon "Why? Am I being too rough?" id ep4_18_alyssasex_loop1_73757ee3
            show ep4 alyssasex_147 with d
            alyssa "No! It's just that I had another idea..." id ep4_18_alyssasex_loop1_043b8ba1
            alyssa "Hold on tight." id ep4_18_alyssasex_loop1_772f9216
            play sound close_locker volume 0.8
            show ep4 alyssasex_148 with d
            simon "Ahh!" id ep4_18_alyssasex_loop1_01456d74


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_150_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_150_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_150 with d
            alyssa "(It's buried to the hilt!)" id ep4_18_alyssasex_loop1_9b922f85
            simon "I knew I'd like your ideas." id ep4_18_alyssasex_loop1_c97c7981
            simon "(She's got the ass of an athlete. It's perfect for this position!)" id ep4_18_alyssasex_loop1_c74c1a4b
            simon "(This way, I have more room to maneuver, so I can fit my whole dick inside her.)" id ep4_18_alyssasex_loop1_940a00eb
            simon "(She's so hot!)" id ep4_18_alyssasex_loop1_9db450d9
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_150_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_150_var1_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_150_var1 with d
            simon "(And she's loving it!)" id ep4_18_alyssasex_loop1_fdded84c
            simon "(She might be enjoying it more than I am.)" id ep4_18_alyssasex_loop1_e3618baf
            simon "(She makes me feel so special.)" id ep4_18_alyssasex_loop1_4f6eab64
            pause


            stop foley
            stop voicefx
            show ep4 alyssasex_153 with d
            alyssa "Ah..." id ep4_18_alyssasex_loop1_3f24e6fe
            show ep4 alyssasex_154 with vpunch
            alyssa "Aaaaaahhhhnnggg!" id ep4_18_alyssasex_loop1_3252a000
            show ep4 alyssasex_155 with d
            simon "(Oh my god. Did she cum already?)" id ep4_18_alyssasex_loop1_accc1b7d
            play sound close_locker volume 0.7
            show ep4 alyssasex_155_1 with d
            alyssa "Oh..."
            show ep4 alyssasex_156 with d
            alyssa "That was amazing..." id ep4_18_alyssasex_loop1_eaf9b3de
            show ep4 alyssasex_157 with d
            alyssa "... But I want more!" id ep4_18_alyssasex_loop1_4c19b0b0

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_163_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_163_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_163 with d
            simon "There's a request I can't deny." id ep4_18_alyssasex_loop1_745f3da9
            simon "Aaaahh..." id ep4_18_alyssasex_loop1_3a7b8a0f
            alyssa "Aaaahh... Right there... Just like that..." id ep4_18_alyssasex_loop1_7eace71c
            alyssa "Your hand... It's..." id ep4_18_alyssasex_loop1_2a7410c1
            simon "Ahh... I think I got it now." id ep4_18_alyssasex_loop1_a49df726
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_163_var4_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_163_var4_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_163_var4 with d
            simon "You're the kind of woman who gets turned on by more than just penetration." id ep4_18_alyssasex_loop1_1c554c42
            alyssa "There's more than one way of getting there." id ep4_18_alyssasex_loop1_ef086a3f
            alyssa "I see all of them as complementary..." id ep4_18_alyssasex_loop1_f0709eed
            alyssa "My breasts being fondled..." id ep4_18_alyssasex_loop1_67e93a09
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_163_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_163_var1_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_163_var1 with d
            alyssa "Your hand down there..." id ep4_18_alyssasex_loop1_a55b4e9a
            alyssa "All the while with you inside me..." id ep4_18_alyssasex_loop1_59ed1d97
            pause

            label ep4_18_alyssasex_loop2:
                menu:
                    "Fuck her from the front":
                        image ep4 anim_alyssasex_front_combo:
                            "ep4 anim_alyssasex_150" with Dissolve(0.1)
                            pause 5
                            "ep4 anim_alyssasex_150_var1" with Dissolve(0.1)
                            pause 8
                            repeat
                        $ allow_voicefx = True
                        if is_voice_installed:
                            play voicefx ep4_anim_alyssasex_front_combo_voicefx fadein 0.5 fadeout 0.5
                            play foley ep4_anim_alyssasex_front_combo_foley fadein 0.5 fadeout 0.5
                        show ep4 anim_alyssasex_front_combo with d
                        pause
                        jump ep4_18_alyssasex_loop2
                    "Fuck her from behind":
                        image ep4 anim_alyssasex_behind_combo:
                            "ep4 anim_alyssasex_163" with Dissolve(0.1)
                            pause 6
                            "ep4 anim_alyssasex_163_var4" with Dissolve(0.1)
                            pause 6
                            "ep4 anim_alyssasex_163_var1" with Dissolve(0.1)
                            pause 6
                            repeat
                        $ allow_voicefx = True
                        if is_voice_installed:
                            play voicefx ep4_anim_alyssasex_behind_combo_voicefx fadein 0.5 fadeout 0.5
                            play foley ep4_anim_alyssasex_behind_combo_foley fadein 0.5 fadeout 0.5
                        show ep4 anim_alyssasex_behind_combo with d
                        pause
                        jump ep4_18_alyssasex_loop2
                    "Continue" if True:
                        $ renpy.pause()

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_163_var3_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_163_var3_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_163_var3 with d
            alyssa "Every part... of my body..." id ep4_18_alyssasex_loop2_d53b8d29
            alyssa "My whole body, it's..." id ep4_18_alyssasex_loop2_43d032bb
            pause
            stop foley
            stop voicefx
            show ep4 alyssasex_172 with vpunch
            pause 0.5
            show ep4 alyssasex_172 with vpunch
            pause 0.5
            show ep4 alyssasex_172 with vpunch
            alyssa "Oh, [name]!" id ep4_18_alyssasex_loop2_0a315ffd
            show ep4 alyssasex_173 with d
            alyssa "Ahhh... Wow." id ep4_18_alyssasex_loop2_00cf8a56
            show ep4 alyssasex_174 with d
            simon "Does everything feel good?" id ep4_18_alyssasex_loop2_e5792c71
            show ep4 alyssasex_175 with d
            alyssa "It's more than good..." id ep4_18_alyssasex_loop2_a4b862fa
            alyssa "... Everything feels great." id ep4_18_alyssasex_loop2_ebf3d0a0
            alyssa "I just came..." id ep4_18_alyssasex_loop2_d1cd8e77
            alyssa "... so many times..." id ep4_18_alyssasex_loop2_bd623264
            show ep4 alyssasex_177 with d
            alyssa "It's only fair that you do the same." id ep4_18_alyssasex_loop2_1a2a925d

            show ep4 alyssasex_179 with d
            alyssa "Will you come for me, [name]?" id ep4_18_alyssasex_loop2_5b783d09
            show ep4 alyssasex_181 with d
            alyssa "I want it all over my breasts." id ep4_18_alyssasex_loop2_d81985da
            alyssa "Like I said... it doesn't end until you get there as well." id ep4_18_alyssasex_loop2_b4e38723



            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_178_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_178_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_178 with d
            simon "(Fuck...I wouldn't say no to something like that, even if I wanted to.)" id ep4_18_alyssasex_loop2_a2d4b29f
            simon "You don't have to ask me twice!" id ep4_18_alyssasex_loop2_f63740fa
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_184_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_184_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_184 with d
            alyssa "Do you like it when I do this, [name]?" id ep4_18_alyssasex_loop2_b2034fa8
            simon "That's perfect, Alyssa..." id ep4_18_alyssasex_loop2_5b87a361
            alyssa "It's so good for me too, [name]." id ep4_18_alyssasex_loop2_13d036c6
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_184_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_184_var1_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_184_var1 with d
            alyssa "Aaahhnngg..." id ep4_18_alyssasex_loop2_eab015bb
            simon "(Is she going to cum again?!)" id ep4_18_alyssasex_loop2_40dd906a
            simon "(It would be amazing if we could cum together!)" id ep4_18_alyssasex_loop2_a7e8d26c
            alyssa "Ahhh..." id ep4_18_alyssasex_loop2_68fc47bf


            image ep4 anim_alyssasex_handjob_combo:
                "ep4 anim_alyssasex_185" with Dissolve(0.1)
                pause 5
                "ep4 anim_alyssasex_178" with Dissolve(0.1)
                pause 5
                "ep4 anim_alyssasex_184" with Dissolve(0.1)
                pause 5
                repeat

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_alyssasex_handjob_combo_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_alyssasex_handjob_combo_foley fadein 0.5 fadeout 0.5
            show ep4 anim_alyssasex_handjob_combo with d
            alyssa "Ahhhhh..." id ep4_18_alyssasex_loop2_185bcfb5
            alyssa "Give me everything you've got, [name]!" id ep4_18_alyssasex_loop2_430815f4
            pause

            menu:
                "Cum":
                    pass



            stop foley
            stop voicefx
            show ep4 alyssasex_187 with hpunch
            pause 0.5
            show ep4 alyssasex_187 with hpunch
            pause 0.5
            show ep4 alyssasex_187 with hpunch

            simon "Aaaahhh!" id ep4_18_alyssasex_loop2_c8dff4f7
            show ep4 alyssasex_188 with d
            alyssa "Ahh... There it is..." id ep4_18_alyssasex_loop2_8beb3353
            alyssa "It feels so warm..." id ep4_18_alyssasex_loop2_621ad725
            show ep4 alyssasex_189 with d
            simon "Wow... Phew..." id ep4_18_alyssasex_loop2_c4ee3ba6
            show ep4 alyssasex_190 with d
            alyssa "Okay... Now we can say we're done." id ep4_18_alyssasex_loop2_1489804a
            show ep4 alyssasex_191 with d
            simon "I'm spent. That's for sure." id ep4_18_alyssasex_loop2_83ec78e7
            show ep4 alyssasex_192 with d
            alyssa "Hahaha." id ep4_18_alyssasex_loop2_9cddd628
            show ep4 alyssasex_193 with d
            alyssa "Well, I'm glad we did it in the locker room." id ep4_18_alyssasex_loop2_2d12f7bd
            show ep4 alyssasex_194 with d
            simon "Might as well take another shower." id ep4_18_alyssasex_loop2_3e2fb3c4
            show ep4 alyssasex_195 with d
            simon "Shall we?" id ep4_18_alyssasex_loop2_9aa8eeca
            show ep4 alyssasex_196 with d
            alyssa "After you." id ep4_18_alyssasex_loop2_0925f70d
            play music circle fadeout 2 fadein 2 volume 0.4
            play sound bath volume 0.7
            show ep4 alyssasex_197 with longer_fade
            simon "(I feel so much better, and it's all thanks to her.)" id ep4_18_alyssasex_loop2_d6066dac
            show ep4 alyssasex_198 with d
            alyssa "Hey!" id ep4_18_alyssasex_loop2_791a9c05
            alyssa "You're staring!" id ep4_18_alyssasex_loop2_cce381ef
            show ep4 alyssasex_199 with d
            simon "Sorry! My mind was elsewhere..." id ep4_18_alyssasex_loop2_fd5e1873
            show ep4 alyssasex_200 with d
            alyssa "Ah. That's all right!" id ep4_18_alyssasex_loop2_d49bb1d2

            show ep4 alyssasex_201 with d
            simon "I was thinking about joining you..." id ep4_18_alyssasex_loop2_5ab28b65
            show ep4 alyssasex_202 with d
            alyssa "Wow. Okay! Hahaha." id ep4_18_alyssasex_loop2_7aee1aff
            play sound faucet_closing
            show black as ep4
            pause
            show ep4 alyssasex_203 with d
            alyssa "Thanks for today, [name]." id ep4_18_alyssasex_loop2_868fcd4a
            show ep4 alyssasex_204 with d
            simon "What? I'm the one who should be thanking you." id ep4_18_alyssasex_loop2_4fcd4684
            show ep4 alyssasex_205 with d
            alyssa "You're great, really." id ep4_18_alyssasex_loop2_db3e1b76
            show ep4 alyssasex_206 with d
            alyssa "You've got nothing to worry about." id ep4_18_alyssasex_loop2_9063254c
            show ep4 alyssasex_207 with d
            simon "You're right."
            show ep4 alyssasex_208 with d
            simon "And I'm at my peak when I'm with you!" id ep4_18_alyssasex_loop2_b25b7cf5
            show ep4 alyssasex_209 with d
            alyssa "Oh! Is that so?!"


            show ep4 alyssasex_combo1 with d
            $ renpy.pause(8)
            show text _ ("Click to continue") with d:
                xpos 0.5
                ypos 0.9
            $ renpy.pause(2)
            hide text _ ("Click to continue") with d
            $ renpy.pause()

            image ep4 alyssasex_combo1:
                "ep4 alyssasex_197_1" with Dissolve(1)
                pause 5
                "ep4 alyssasex_197_2" with Dissolve(1)
                pause 5
                "ep4 alyssasex_197_3" with Dissolve(1)
                pause 5
                "ep4 alyssasex_197_4" with Dissolve(1)
                pause 5
                "ep4 alyssasex_197_5" with Dissolve(1)
                pause 5
                repeat

            stop music fadeout 3 

            show ep4 alyssasex_210 with d
            alyssa "Let's get out of here. Otherwise, I'm going to melt." id ep4_18_alyssasex_loop2_166a59ae
            $ renpy.end_replay()

        "Don't take the step" if not _in_replay:
            $ ep4_alyssasex_dont_take_the_step = True
            $ player_choice("ep4_alyssasex_dont_take_the_step:true")
            show ep4 alyssasex_211 with d
            simon "I can't." id ep4_18_alyssasex_loop2_01190cf8
            show ep4 alyssasex_212 with d
            alyssa "Oh..."
            show ep4 alyssasex_213 with d
            simon "It's not that I don't want it." id ep4_18_alyssasex_loop2_a839d5af
            simon "It's just that the timing's not the greatest." id ep4_18_alyssasex_loop2_184ecc1d
            show ep4 alyssasex_214 with d
            alyssa "I understand. Thank you for being honest with me." id ep4_18_alyssasex_loop2_57687f72
            show ep4 alyssasex_215 with d
            alyssa "This is more than enough for now." id ep4_18_alyssasex_loop2_7e916121
            show ep4 alyssasex_216 with d
            simon "Thank you for understanding." id ep4_18_alyssasex_loop2_29614714
            simon "I've just got a lot going on right now. My head is practically spinning." id ep4_18_alyssasex_loop2_2b0dc9ae
            show ep4 alyssasex_217 with d
            alyssa "Of course I understand!" id ep4_18_alyssasex_loop2_93a2f717
else:




    show ep4 alyssasex_218 with d
    alyssa "I'm here if you need me. Just remember, you can always count on me." id ep4_18_alyssasex_loop2_7eb029be
    show ep4 alyssasex_219 with d
    simon "Thanks, Alyssa." id ep4_18_alyssasex_loop2_81435a97
    stop music fadeout 4
    show ep4 alyssasex_220 with d
    alyssa "Now... I should go get dressed. I'm starting to feel a chill." id ep4_18_alyssasex_loop2_99af15a2
    show ep4 alyssasex_221 with d

    alyssa "I'll be back right back!" id ep4_18_alyssasex_loop2_391d3e96

$ debug_other_path()
jump ep4_19_livingsituation
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
