
label ep4_23_suenight:
    show ep4 suenight_001 with d
    pause 5
    show ep4 suenight_002 with d
    pause 5
    show ep4 suenight_003 with d
    pause 5
    jump ep4_26_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
