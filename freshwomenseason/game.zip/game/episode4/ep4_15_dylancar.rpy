
label ep4_15_dylancar:

    play music far_away_feelings fadeout 4 fadein 3 volume 0.35
    play sound traffic fadein 3 volume 0.5
    show ep4 dylancar_001 with wipeleft
    dylan "Oh, man." id ep4_15_dylancar_9f78afd8
    dylan "Your first day at college..." id ep4_15_dylancar_3bcc081e
    show ep4 dylancar_002 with d
    dylan "You're going to love it." id ep4_15_dylancar_ea269b58
    show ep4 dylancar_003 with d
    dylan "You..." id ep4_15_dylancar_c6e22c81
    show ep4 dylancar_004 with d
    dylan "Bro... are you ok?" id ep4_15_dylancar_cfe465b8
    show ep4 dylancar_005 with d
    simon "Huh?" id ep4_15_dylancar_196da51b
    show ep4 dylancar_006 with d
    simon "Oh... yeah." id ep4_15_dylancar_b01c4d4b
    stop sound fadeout 5
    play sound car_stop_breakes volume 0.5
    show ep4 dylancar_007 with d
    simon "Sorry, Dylan." id ep4_15_dylancar_dac97300
    show ep4 dylancar_008 with d
    dylan "It's fine, man." id ep4_15_dylancar_d4425f76
    stop sound  fadeout 2
    show ep4 dylancar_009 with d
    dylan "You know, I was going to wait for you to tell me, but I think it'll be better if I just ask." id ep4_15_dylancar_7538477d
    show ep4 dylancar_010 with d
    dylan "Yesterday with Lily didn't go too well, did it?" id ep4_15_dylancar_f14ea7e2
    show ep4 dylancar_011 with d
    simon "It did not." id ep4_15_dylancar_8ffbd91b
    play sound punching_bag volume 0.5
    show ep4 dylancar_012 with d
    dylan "Sorry, bro." id ep4_15_dylancar_c33fdf7c
    show ep4 dylancar_013 with d
    simon "I haven't even told you the worst part yet." id ep4_15_dylancar_b92556fa
    show ep4 dylancar_014 with d
    simon "I got kicked out of the apartment!" id ep4_15_dylancar_3e5b2043
    show ep4 dylancar_015 with d
    dylan "You live with her?!" id ep4_15_dylancar_372d5470
    show ep4 dylancar_016 with d
    simon "Of course I don't!" id ep4_15_dylancar_9998b762
    show ep4 dylancar_017 with d
    if chose("ep4_lunch2_i_fucked_your_wife"):
        simon "It's just, her husband owns the building I live in." id ep4_15_dylancar_67463fa3
    else:
        simon "It's just, she owns the building I live in." id ep4_15_dylancar_f4ee712a
    play sound car_honk volume 0.3 
    show ep4 dylancar_018 with vpunch
    dylan "Ah, got it." id ep4_15_dylancar_aaa2ab71
    play sound jeep_start_2 volume 0.3
    show ep4 dylancar_019 with d
    dylan "Wait, so you don't have a place to stay?" id ep4_15_dylancar_93fcf4cf
    stop sound fadeout 3
    show ep4 dylancar_020 with d
    simon "Basically, yeah." id ep4_15_dylancar_fd3e09ba
    show ep4 dylancar_021 with d
    dylan "Dude, that's..." id ep4_15_dylancar_f6fd3ced
    show ep4 dylancar_022 with d
    dylan "... Awesome!" id ep4_15_dylancar_c7342146
    play sound car_pass_by_2 volume 0.5
    show ep4 dylancar_023 with d
    simon "How is that awesome?!" id ep4_15_dylancar_146388c4
    show ep4 dylancar_024 with d
    dylan "Man, I've always wanted a roommate!" id ep4_15_dylancar_4e1cf0a5
    show ep4 dylancar_025 with d
    dylan "You should come live with me." id ep4_15_dylancar_564e4ade
    show ep4 dylancar_026 with d
    dylan "We can bring back women!" id ep4_15_dylancar_b0f2fe09
    show ep4 dylancar_027 with d
    dylan "We can drink and watch movies." id ep4_15_dylancar_e7bc1404
    show ep4 dylancar_028 with d
    simon "Could I really stay at your place?" id ep4_15_dylancar_c8172819
    show ep4 dylancar_029 with d
    dylan "Of course, bro!" id ep4_15_dylancar_075e6948
    show ep4 dylancar_030 with d
    simon "But, wait, if we bring back girls, won't they figure out you're not a foreigner?" id ep4_15_dylancar_9cf72837
    show ep4 dylancar_031 with d
    dylan "Dude, you haven't seen my room." id ep4_15_dylancar_fd03af8a
    dylan "It's very authentic." id ep4_15_dylancar_2ffdf7bc
    show ep4 dylancar_032 with d
    simon "More Russian stuff?" id ep4_15_dylancar_8043229b
    show ep4 dylancar_033 with d
    dylan "More Russian stuff!" id ep4_15_dylancar_dc1379a0
    show ep4 dylancar_034 with d
    simon "Holy shit, Dylan." id ep4_15_dylancar_f9cce24f
    show ep4 dylancar_035 with d
    dylan "But seriously..." id ep4_15_dylancar_1fcda6e2
    dylan "My door's always open for you, bro. Just give me a call." id ep4_15_dylancar_7f8d66ab

    stop music fadeout 3

    show ep4 dylancar_036 with d
    simon "Thanks, dude. I'll let you know." id ep4_15_dylancar_4c904dd7
    jump ep4_16_university
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
