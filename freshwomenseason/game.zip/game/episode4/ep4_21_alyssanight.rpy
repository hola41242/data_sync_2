
label ep4_21_alyssanight:

    show ep4 alyssanight_001 with d
    pause 5.0
    show ep4 alyssanight_002 with d
    pause 4.0
    show ep4 alyssanight_003 with d
    pause 3.0
    jump ep4_26_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
