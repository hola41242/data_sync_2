
label ep4_16_university:



    if choice_made('ep4_dylanphone_i_want_style'):
        play music i_feel_good fadein 4 volume 0.32
        play sound car_stop_breakes volume 0.5
        show ep4 university_001 with d
        dylan "And... we're here!" id ep4_16_university_96f7da7c
        show ep4 university_002 with d
        simon "Dylan..." id ep4_16_university_6a94ab6d
        simon "I didn't think it would be this crowded here!" id ep4_16_university_1f1d6165
        show ep4 university_003 with d
        dylan "Pfft." id ep4_16_university_0aa361fc
        dylan "I thought you said you wanted to do this in style." id ep4_16_university_d6edc8e5
        show ep4 university_004 with d
        simon "Yeah, but..." id ep4_16_university_09d6bab7

        show ep4 university_005 with d
        dylan "And don't forget your hat." id ep4_16_university_47fa7908

        show ep4 university_006 with d
        simon "Well, I guess that's what I agreed to." id ep4_16_university_c51b1b35
        show ep4 university_007 with d
        dylan "Here we go." id ep4_16_university_8e3a65ab
        play sound school_crowd volume 0.2 fadein 2
        show ep4 university_008 with wipeleft
        simon "(I guess now people think I'm a weirdo.)" id ep4_16_university_40441bd4
        show ep4 university_009 with d
        simon "(Good for me.)" id ep4_16_university_8625ef3f
        show ep4 university_010 with d
        simon "What's up?" id ep4_16_university_8d606c9c
        show ep4 university_011 with d
        student_uni_female "Hey." id ep4_16_university_02a5abe0
        show ep4 university_012 with d
        dylan "Bro!" id ep4_16_university_5d0c7ddb
        show ep4 university_013 with d
        dylan "Nice." id ep4_16_university_cae67c16
        show ep4 university_014 with d
        dylan "Next time, try an accent." id ep4_16_university_b70f340a
        show ep4 university_015 with d
        dylan "Trust me, bro. It always works." id ep4_16_university_eeafe419
        show ep4 university_016 with d
        simon "Oh really? Maybe I will..." id ep4_16_university_fa75f400
        stop sound fadeout 3
        show ep4 university_017 with d
        librarian "Gentlemen." id ep4_16_university_d5584643
        show ep4 university_018 with d
        dylan "Ma'am." (what_bold=True)
        show ep4 university_019 with d
        librarian "Please take off your hats before entering."
        show ep4 university_020 with d
        dylan "Oh man..." (what_bold=True)
        show ep4 university_021 with d
        simon "The going was good while it lasted."
        jump ep4_16_university_library
    else:

        play music i_feel_good fadein 2 volume 0.32
        play sound car_stop_breakes volume 0.5
        show ep4 university_022 with d
        dylan "Well... here we are." id ep4_16_university_eb6240a6

        show ep4 university_023 with d
        simon "I thought there'd be more people around." id ep4_16_university_dbe21504

        show ep4 university_024 with d
        dylan "This is like the back door of the campus." id ep4_16_university_d1a59f5e
        show ep4 university_025 with d
        dylan "Only without the fun you usually have with back doors." id ep4_16_university_b59374a4
        show ep4 university_026 with d
        dylan "If you catch my drift." id ep4_16_university_f06d1c97
        show ep4 university_027 with d
        simon "I'm at a complete loss for words." id ep4_16_university_3331e444
        show ep4 university_028 with d

        dylan "What? Never visited the back door with a girl before?" id ep4_16_university_1b43920c

        if choice_made('ep4_emilyvisit_anal'):
            show ep4 university_029 with d
            simon "Of course I have." id ep4_16_university_4b96bd95
            show ep4 university_030 with d
            simon "As a matter of fact, it was with this girl I met up with yesterday..." id ep4_16_university_f7dfc354
            show ep4 university_031 with d
            dylan "My boy! You truly are a legend!" id ep4_16_university_1f42a09a
            show ep4 university_032 with d
            dylan "You'll do just fine here." id ep4_16_university_a7072bd5
            dylan "Trust me." id ep4_16_university_3249cbd9
            show ep4 university_033 with d
            dylan "All you have to do is follow your ol' friend Dylan here." id ep4_16_university_af1eb013
        else:

            show ep4 university_034 with d
            simon "Not that I remember..." id ep4_16_university_52b96816
            show ep4 university_035 with d
            dylan "Dude... that's something you'd remember." id ep4_16_university_c71ea648
            show ep4 university_036 with d
            simon "Oh really?" id ep4_16_university_c1761c50
            simon "And you have experience in the matter?" id ep4_16_university_10cc7a0f
            show ep4 university_037 with d
            dylan "Umm..." id ep4_16_university_3b57c19d
            show ep4 university_038 with d
            dylan "Pssht... You know, dude?" id ep4_16_university_e4c5bb4f
            show ep4 university_039 with d
            simon "I really don't." id ep4_16_university_945b3f2d
            show ep4 university_040 with d
            dylan "Hey, look over there." id ep4_16_university_053cc0c5
            show ep4 university_041 with d
            dylan "I think that's where we need to go." id ep4_16_university_e1be95bf
            show ep4 university_042 with d
            simon "What? Where?" id ep4_16_university_9725e91b
            show ep4 university_043 with d
            simon "Hey, you still haven't answered me!" id ep4_16_university_1564e7b3

        $ debug_other_path()
        play sound school_crowd fadein 2 volume 0.5
        show ep4 university_044 with wipeleft
        dylan "Come on. The library's this way." id ep4_16_university_da324f93
        show ep4 university_019_1 with d
        librarian "Please take off your hat before entering."
        show ep4 university_020_1 with d
        dylan "Dude..." (what_bold=True)
        show ep4 university_021_1 with d
        simon "It was good while it lasted."
        show ep4 university_045 with d
        dylan "After you, bro." id ep4_16_university_520306cf
        stop sound fadeout 2

    $ debug_other_path()

label ep4_16_university_library:

    show ep4 university_046 with wipeleft
    simon "Are you sure we should be here?" id ep4_16_university_library_f6d7e6ff
    show ep4 university_047 with d
    dylan "What do you mean?" id ep4_16_university_library_7326f107
    stop music
    play sound shhh volume 0.35
    show ep4 university_048 with vpunch
    librarian "Shhhh!" id ep4_16_university_library_74e435c1
    show ep4 university_049 with d
    simon "*Whispering.* That's what I mean." id ep4_16_university_library_bf621e97
    show ep4 university_050 with d
    simon "*Whispering.* Isn't there some lecture we're supposed to attend?"
    simon "*Whispering.* It'll be hard to hold a lecture if everyone's supposed to stay quiet." id ep4_16_university_library_b6a9b7af
    show ep4 university_051 with d
    dylan "The opening lecture? That boring thing? Nah." id ep4_16_university_library_427755a1
    dylan "It's way better to hang here." id ep4_16_university_library_f7497f37
    show ep4 university_052 with d
    dylan "Besides, she's here too." id ep4_16_university_library_8625a362
    show ep4 university_053 with d
    simon "Who's she?" id ep4_16_university_library_29a208d7
    play music corner_head fadeout 2 fadein 2 volume 0.32
    show ep4 university_054 with d
    chloe "H-hi, [name]." id ep4_16_university_library_9778030d
    show ep4 university_055 with d
    simon "Oh! Hey, Chloe!" id ep4_16_university_library_12f806cb
    show ep4 university_056 with d
    simon "Are you okay?" id ep4_16_university_library_30ddab2a
    show ep4 university_057 with d
    chloe "Yeah..." id ep4_16_university_library_a5196002
    show ep4 university_058 with d
    chloe "But I wanted to apologize." id ep4_16_university_library_4f36dc5c
    show ep4 university_059 with d
    simon "Apologize? What for?" id ep4_16_university_library_8557527e
    show ep4 university_060 with d
    chloe "Umm..." id ep4_16_university_library_c56309fb
    show ep4 university_061 with d
    dylan "You know what? I just remembered that I have some international business to attend to." (what_bold=True)
    show ep4 university_062 with d
    dylan "See you later, friends." (what_bold=True)
    show ep4 university_063 with d
    simon "Right..." id ep4_16_university_library_41326fcf
    show ep4 university_064 with d
    simon "So..." id ep4_16_university_library_71d93eb4
    show ep4 university_065 with d
    chloe "Sorry about the other day." id ep4_16_university_library_d25286f0
    chloe "I get kind of intense when I'm..." id ep4_16_university_library_aebc1605
    show ep4 university_066 with d
    chloe "... excited." id ep4_16_university_library_0af2686d
    show ep4 university_067 with d

    chloe "I might have pushed you too far." id ep4_16_university_library_f892deb1

    if choice_made('ep3_sat_chloesex_continue'):
        show ep4 university_068 with d
        chloe "But I'm so glad you could accept me for who I am." id ep4_16_university_library_ccadab3a
        show ep4 university_069 with d
        chloe "It's hard to be an open book sometimes." id ep4_16_university_library_e2e85662
        show ep4 university_070 with d
        chloe "Thank you for that." id ep4_16_university_library_07f7f0f0
        show ep4 university_071 with d
        simon "You don't need to thank me." id ep4_16_university_library_e37b5dcb
        show ep4 university_072 with None
        julia "Heeey, Twinkle T-" id ep4_16_university_library_7eda3386
        show ep4 university_073 with d
        julia "Oh." id ep4_16_university_library_3141d613
        show ep4 university_074 with d
        simon "Hey, Julia!" id ep4_16_university_library_ab549b9e
        show ep4 university_075 with d


        julia "Sorry to interrupt." id ep4_16_university_library_a9d31dab

        if choice_made('ep2_julia_kiss'):
            show ep4 university_076 with d
            simon "(Oh fuck.)" id ep4_16_university_library_33a71ad8
            show ep4 university_077 with d
            simon "(This situation could so easily go to shit.)" id ep4_16_university_library_d0ca7e5d
            show ep4 university_078 with d
            simon "(Think, [name]. Think!)" id ep4_16_university_library_0b7d49ba
            show ep4 university_079 with d
            chloe "Hi, I'm Chloe!" id ep4_16_university_library_e63cd933
            chloe "I'm helping the incoming freshmen like [name] here." id ep4_16_university_library_31190b17
            show ep4 university_080 with d
            chloe "Right?" id ep4_16_university_library_42a5a921
            show ep4 university_081 with d
            simon "(Whoa. Thanks, Chloe!)" id ep4_16_university_library_01fb914d
            show ep4 university_082 with d
            simon "That's right." id ep4_16_university_library_f5864122
            show ep4 university_083 with d
            julia "I'm Julia."
            julia "Do you hug them all, or just the ones you think are cute?" id ep4_16_university_library_482f3d06
            show ep4 university_084 with d
            chloe "What?" id ep4_16_university_library_8ea20703
            show ep4 university_085 with d
            julia "Never mind." id ep4_16_university_library_99a82154

        $ debug_other_path()
    else:


        menu:
            "It was too much":
                $ ep4_university_it_was_too_much = True
                $ player_choice("ep4_university_it_was_too_much:true")
                show ep4 university_086 with d
                simon "You really had me worried." id ep4_16_university_library_e2682b4e
                simon "I didn't think things would go down like that." id ep4_16_university_library_7e9a66e4
                show ep4 university_087 with d
                chloe "I'm sorry." id ep4_16_university_library_75c38f83
                show ep4 university_088 with d
                simon "It's okay. It's just not really my thing." id ep4_16_university_library_40a8d92d
                show ep4 university_089 with d
                chloe "I understand!" id ep4_16_university_library_a70753e8
            "It's fine"(True):

                $ ep4_university_its_fine = True
                $ player_choice("ep4_university_its_fine:true")
                show ep4 university_090 with d
                $ points_chloe += 1
                simon "It's fine." id ep4_16_university_library_9b1d8aef
                simon "I just think you scared me a bit." id ep4_16_university_library_f6e0fb44
                show ep4 university_091 with d
                chloe "I can't blame you for feeling that way." id ep4_16_university_library_15ffb8fd
                show ep4 university_092 with d
                chloe "I'm really sorry." id ep4_16_university_library_4cd4a373
                show ep4 university_093 with d
                simon "It's okay. It's all in the past." id ep4_16_university_library_6656aefb



        show ep4 university_094 with d
        julia "Hey, Twinkle Toes!" id ep4_16_university_library_f277a5f6
        show ep4 university_095 with d
        julia "Oh, and hello to you too." id ep4_16_university_library_75484f86
        show ep4 university_096 with d
        chloe "Hi, I'm Chloe! Are you [name]'s friend?" id ep4_16_university_library_34601df2
        show ep4 university_097 with d
        julia "That's right. I am" id ep4_16_university_library_f7b1b878
        julia "I'm Julia."

    $ debug_other_path()

    show ep4 university_098 with d
    julia "Glad you ended up coming after all." id ep4_16_university_library_28450e83
    show ep4 university_099 with d
    chloe "Why? Were you thinking about not coming to class?" id ep4_16_university_library_52ec8f90
    show ep4 university_100 with d
    simon "Well... I haven't had a chance to tell you yet, but things with Lily didn't end very well yesterday." id ep4_16_university_library_fbecc090
    show ep4 university_101 with d
    chloe "Oh no! What happened?" id ep4_16_university_library_93f79665
    show ep4 university_102 with d
    julia "Wait. Does she know about all that too?" id ep4_16_university_library_202514b5
    show ep4 university_103 with d
    simon "Yeah. Chloe's been helping me with this mess." id ep4_16_university_library_c147f050
    show ep4 university_104 with d
    simon "The latest news is that we weren't able to talk all that much..." id ep4_16_university_library_7f79d903
    show ep4 university_105 with d
    simon "... And I may have overstepped some boundaries..." id ep4_16_university_library_0091af6d
    show ep4 university_106 with d
    simon "Then I got kicked out of my apartment." id ep4_16_university_library_9cb872bf
    show ep4 university_107 with d
    chloe "Oh no! What are you going to do?" id ep4_16_university_library_b0259cf4
    show ep4 university_108 with d
    chloe "Do you have a place to stay?" id ep4_16_university_library_9dab7a75
    show ep4 university_109 with d
    simon "I'm still trying to work that part out." id ep4_16_university_library_31e56751

    simon "But Dylan invited me to stay at his place." id ep4_16_university_library_c514f916

    if choice_made('points_chloe', 8):
        $ ep4_chloe_invite = True
        $ player_choice("ep4_chloe_invite:true")
        show ep4 university_110 with d
        chloe "Well... that could work..." id ep4_16_university_library_20276bf2
        show ep4 university_111 with d
        chloe "But if it doesn't work out, we've got a spare room at my place." id ep4_16_university_library_b755315b
        show ep4 university_112 with d
        julia "*Gasps.*" id ep4_16_university_library_0b0e670f
        show ep4 university_113 with d
        chloe "Dylan is a great friend, but I couldn't imagine being his roommate." id ep4_16_university_library_279b5477
        show ep4 university_114 with d
        chloe "Whatever you decide, just let me know." id ep4_16_university_library_06f14820
    else:

        show ep4 university_115 with d
        chloe "Ah, that's good!" id ep4_16_university_library_37a99a69
        chloe "Glad you have that figured out at least." id ep4_16_university_library_8adbc372

    $ debug_other_path()

    show ep4 university_116 with d
    chloe "Anyway, you can always talk to the campus faculty about housing." id ep4_16_university_library_8c9af5a3
    chloe "They should be talking about all that at the opening lecture." id ep4_16_university_library_12f6de1f
    show ep4 university_117 with d
    simon "Right. Are you heading that way too?" id ep4_16_university_library_2483f7a7
    show ep4 university_118 with d
    chloe "No, that's just for the freshmen." id ep4_16_university_library_055f67ec
    show ep4 university_119 with d
    chloe "But you should go." id ep4_16_university_library_d6d94824
    show ep4 university_120 with d
    simon "All right then." id ep4_16_university_library_4fe2af78
    simon "Shall we, Julia?" id ep4_16_university_library_64dd5807
    show ep4 university_121 with d
    julia "I was already moving in that direction." id ep4_16_university_library_cef7218e
    show ep4 university_122 with d
    simon "Thanks for the help, Chloe! See you later." id ep4_16_university_library_6c07a3df
    show ep4 university_123 with d
    chloe "See you, [name]." id ep4_16_university_library_47b2e5bc
    show ep4 university_124 with d

    chloe "Nice to meet you, Julia!" id ep4_16_university_library_4c56202a

    play music same_kind_of_paradise fadeout 3 fadein 2 volume 0.32

    if choice_made_skip_debug("ep4_chloe_invite"):

        show ep4 university_125 with wipeleft
        julia "So... you're staying at Chloe's then?" id ep4_16_university_library_3c8f6015
        show ep4 university_126 with d
        simon "I still haven't decided." id ep4_16_university_library_2a8a4e74
        show ep4 university_127 with d
        julia "She's pretty. Maybe you should." id ep4_16_university_library_a0b5e8b3

    show ep4 university_128 with d
    julia "It's a shame I can't help with the whole living situation." id ep4_16_university_library_9341b840
    show ep4 university_129 with d
    simon "It's fine, Julia." id ep4_16_university_library_f337810b
    simon "You've done enough already, giving me the courage to come here today and all." id ep4_16_university_library_5ddab98e

    simon "For that alone I'm eternally grateful." id ep4_16_university_library_43ea8178

    if choice_made('points_julia', 5):
        $ ep4_julia_invite = True
        $ player_choice("ep4_julia_invite:true")
        show ep4 university_130 with d
        julia "Aww..." id ep4_16_university_library_17798e76
        show ep4 university_131 with d
        julia "You know... I can't really invite anyone over to my place." id ep4_16_university_library_33ea9724
        julia "Even more so a boy." id ep4_16_university_library_3ae7a2d9
        show ep4 university_132 with d
        julia "However..." id ep4_16_university_library_19f40bad
        show ep4 university_133 with d
        julia "My mother always watches her talk shows on TV, and they always start at midnight." id ep4_16_university_library_4a7e3ba0
        julia "I doubt she'd hear if anyone were to slip in through my bedroom window around that time." id ep4_16_university_library_86c2ac88
        show ep4 university_134 with d
        simon "How nice of her to have a set schedule..." id ep4_16_university_library_e2dc16f1
        show ep4 university_135 with d
        simon "Oh! You're telling me to — " id ep4_16_university_library_c84b9530
        show ep4 university_136 with d
        julia "Technically, I'm not telling you jack shit..." id ep4_16_university_library_da78a433
        julia "I'm just talking to myself." id ep4_16_university_library_28c09fcb
        show ep4 university_137 with d
        simon "Thanks, Julia. I'll let you know what I decide." id ep4_16_university_library_1f3143bf

    $ debug_other_path()

    show ep4 university_138 with d
    julia "Well, I think we're here." id ep4_16_university_library_6b4b186c
    show ep4 university_139 with d
    simon "Are you sure this is the place?" id ep4_16_university_library_e076ac24
    show ep4 university_140 with d
    julia "I'm a genius, remember?" id ep4_16_university_library_6954b60d
    show ep4 university_141 with d
    simon "Right." id ep4_16_university_library_150bf38b
    simon "Then why come to college if you're a genius?" id ep4_16_university_library_0b9f85fa
    show ep4 university_142 with d
    julia "People need to find some inspiration, obviously." id ep4_16_university_library_3c4c2ee7
    show ep4 university_143 with d
    simon "Ah, of course. That makes sense." id ep4_16_university_library_e7edc5dc
    show ep4 university_144 with d
    simon "(The opening lecture was a bunch of bullshit about what not to do.)" id ep4_16_university_library_4918838c
    show ep4 university_145 with d
    simon "(But it somehow put Julia in a good mood.)" id ep4_16_university_library_1ea36def
    show ep4 university_146 with d
    simon "(She looks like she belongs here.)" id ep4_16_university_library_7bfb629e
    show ep4 university_147 with wipeleft
    simon "(She even got along well with Chloe and Dylan after she had more time to talk with them.)" id ep4_16_university_library_ae8d0f40
    stop music fadeout 5
    show ep4 university_148 with d
    simon "(It almost made me forget about all my other problems.)" id ep4_16_university_library_336faada
    show ep4 university_149 with d
    simon "(Almost.)" id ep4_16_university_library_1a6a5bf1
    show ep4 university_150 with d
    simon "(I still had to meet Alyssa and figure out some way to get into the charity ball.)" id ep4_16_university_library_d60f2dd3

    jump ep4_17_alyssadance
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
