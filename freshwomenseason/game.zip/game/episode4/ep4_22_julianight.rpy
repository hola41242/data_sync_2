
label ep4_22_julianight:

    show ep4 julianight_001 with long_fade
    pause 3
    show ep4 julianight_006 with d
    pause 3
    show ep4 julianight_002 with d
    pause 3
    show ep4 julianight_007 with d
    pause 3
    show ep4 julianight_003 with d
    pause 3
    show ep4 julianight_004 with d
    pause 3
    show ep4 julianight_005 with d
    pause 3
    jump ep4_26_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
