
label ep4_17_alyssadance:


show ep4 alyssadance_001 with long_fade
play music here_with_me volume 0.35

simon "(Well, at least this time I know who the teacher is.)" id ep4_17_alyssadance_37ff8c54
show ep4 alyssadance_002 with d
simon "(Speaking of the teacher, where is she?)" id ep4_17_alyssadance_4af85241
show ep4 alyssadance_003 with d
simon "(Oh...)" id ep4_17_alyssadance_adc41a60
show ep4 alyssadance_004 with d
simon "(Damn... She's amazing.)" id ep4_17_alyssadance_76742b2e
show ep4 alyssadance_005 with d
alyssa "Huh?" id ep4_17_alyssadance_bbdfc535
show ep4 alyssadance_006 with d
alyssa "[name], is that you?" id ep4_17_alyssadance_20d38f28
show ep4 alyssadance_007 with d
simon "Yep." id ep4_17_alyssadance_30996514
simon "And I swear I wasn't peeking." id ep4_17_alyssadance_75d06f37
show ep4 alyssadance_008 with d
alyssa "I've gotten used to it. Haha." id ep4_17_alyssadance_af54b107
show ep4 alyssadance_009 with d
alyssa "Come on in." id ep4_17_alyssadance_ae34562b
play sound door_shop_bell volume 0.5
show ep4 alyssadance_010 with d
alyssa "Wow, I see you came prepared!" id ep4_17_alyssadance_e8189b8e
show ep4 alyssadance_011 with d
simon "And I see you already started practicing." id ep4_17_alyssadance_a119e612
show ep4 alyssadance_012 with d
alyssa "I have to be ready." id ep4_17_alyssadance_99f7bb06
show ep4 alyssadance_013 with d
simon "You seem a bit anxious." id ep4_17_alyssadance_9d92d5f5
simon "I got that same feeling over the phone." id ep4_17_alyssadance_77d29582
simon "Is everything ok?" id ep4_17_alyssadance_6d463e10
show ep4 alyssadance_014 with d
alyssa "Yeah." id ep4_17_alyssadance_23357989
alyssa "I just want everything to go well so I can devote more time to this studio." id ep4_17_alyssadance_bb80275f
show ep4 alyssadance_015 with d
simon "I imagine working two jobs is absolutely exhausting." id ep4_17_alyssadance_b6c43108
show ep4 alyssadance_016 with d
alyssa "It is! But we've just got to keep pushing forward." id ep4_17_alyssadance_c8bba39c
show ep4 alyssadance_017 with d
simon "Keep pushing forward..." id ep4_17_alyssadance_7de4b347
show ep4 alyssadance_018 with d
simon "Even when we face adversity, we have to keep pushing forward." id ep4_17_alyssadance_a08c325a
show ep4 alyssadance_019 with d
simon "Though recently I've been feeling like I'm not going to make it another step." id ep4_17_alyssadance_472fa64b
show ep4 alyssadance_020 with d
alyssa "[name]..." id ep4_17_alyssadance_d1bdc74c
show ep4 alyssadance_021 with d
simon "But I'm trying." id ep4_17_alyssadance_870267b3
show ep4 alyssadance_022 with d
alyssa "Great." id ep4_17_alyssadance_e1eb5ae0
alyssa "That's something we can always fall back on." id ep4_17_alyssadance_21a3d4a4
alyssa "Trying." id ep4_17_alyssadance_e98e91eb
show ep4 alyssadance_023 with d
simon "And speaking of trying, how'd that last step go again?" id ep4_17_alyssadance_51cda6cc
show ep4 alyssadance_024 with d
alyssa "Right, the steps! Let's warm up first though." id ep4_17_alyssadance_69608f88
play music so_good_instrumental volume 0.35
show ep4 alyssadance_025 with pushright
alyssa "Let me help." id ep4_17_alyssadance_03ae852f
play sound bone 
show ep4 alyssadance_026 with d
alyssa "Wow, you're really tense." id ep4_17_alyssadance_b53c9916
show ep4 alyssadance_027 with d
alyssa "This whole apartment thing has you wound up pretty tight, huh?" id ep4_17_alyssadance_f9fb025f
show ep4 alyssadance_028 with d
simon "Yeah, it does..." id ep4_17_alyssadance_04ca3818
show ep4 alyssadance_029 with d
simon "But I'll get over it." id ep4_17_alyssadance_58e8eeb6
show ep4 alyssadance_030 with d
simon "(I'm not the only one with problems after all.)" id ep4_17_alyssadance_1b4562ce
simon "(But for now, let's put all that aside.)" id ep4_17_alyssadance_1946fc0f
show ep4 alyssadance_031 with d
alyssa "Wow, looks like the stretching is already working!" id ep4_17_alyssadance_8cb81f63
show ep4 alyssadance_032 with pushright
simon "Shall we?" id ep4_17_alyssadance_9aa8eeca



show ep4 alyssadance_combo1 with d
$ renpy.pause(8)
show text _ ("Click to continue") with d:
    xpos 0.5
    ypos 0.9
$ renpy.pause(2)
hide text _ ("Click to continue") with d
$ renpy.pause()

jump ep4_18_alyssasex
show ep4 alyssadance_032_1 with d

image ep4 alyssadance_combo1:
    "ep4 alyssadance_032_1" with Dissolve(1, alpha=True)
    pause 5
    "ep4 alyssadance_032_2" with Dissolve(1, alpha=True)
    pause 5
    "ep4 alyssadance_032_3" with Dissolve(1, alpha=True)
    pause 5
    "ep4 alyssadance_032_4" with Dissolve(1, alpha=True)
    pause 5
    "ep4 alyssadance_032_5" with Dissolve(1, alpha=True)
    pause 5
    repeat
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
