
label ep4_03_juliaphone:
    show ep4 juliaphone_001 with d
    simon "(What a memorable start to college life.)"

    simon "(I'm still on the verge of becoming homeless though.)" id ep4_03_juliaphone_93f55943

    show ep4 juliaphone_002 with d
    simon "(How long ago was my last meal?)" id ep4_03_juliaphone_5477e972
    simon "(I still haven't stocked my fridge with food.)" id ep4_03_juliaphone_3d41f004
    simon "(Maybe going out to lunch will help me clear my head.)" id ep4_03_juliaphone_1f472b25
    show ep4 juliaphone_003 with d
    stop music fadeout 5
    simon "(Lunch with a friend might be nice.)" id ep4_03_juliaphone_f16823a0
    simon "(Hmmm... Let's see.)" id ep4_03_juliaphone_44f9bf1a

    simon "(I saw Alyssa yesterday. Better not bother her.)" id ep4_03_juliaphone_f54448e8
    simon "(Same goes for Chloe and Dylan.)" id ep4_03_juliaphone_9ebc1378

    show ep4 juliaphone_005 with d

    simon "(Come to think of it, it's been a while since I last spoke with Julia.)" id ep4_03_juliaphone_ac3e39e4


    if choice_made('ep2_julia_kiss'):
        play sound cell_phone_ring volume 0.5
        show ep4 juliaphone_006 with d
        simon "(And considering how things went last time, I definitely want to see her again.)" id ep4_03_juliaphone_d8c2b481
        stop sound fadeout 1
        show ep4 juliaphone_007 with d
        play music whole_hearted fadein 3 volume 0.5
        julia "Hey, Twinkle Toes!" id ep4_03_juliaphone_4febce07
        julia "You finally called!" id ep4_03_juliaphone_007fab6b
        julia "So you're the type of guy who follows up with a phone call."
        show ep4 juliaphone_008 with d
        julia "Although... it did take you a few days!" id ep4_03_juliaphone_5a055571
        show ep4 juliaphone_009 with d
        simon "You know me. The perfect gentleman." (what_italic=True)
        show ep4 juliaphone_007 with d
        julia "Oh, yeah. Sure." id ep4_03_juliaphone_d8c6bf50
        show ep4 juliaphone_010 with d
        julia "*Giggle.*" id ep4_03_juliaphone_9b92be32
        show ep4 juliaphone_011 with d
        julia "So, what's up?" id ep4_03_juliaphone_bd21dedc
        show ep4 juliaphone_012 with d
        simon "I was just here thinking... We haven't had a chance to chat after the last time we saw each other." (what_italic=True)
        show ep4 juliaphone_013 with d
        julia "*Whispers.* I've been thinking about that a lot too." id ep4_03_juliaphone_e69d7f29
        show ep4 juliaphone_014 with d
        julia "I would like to see you again." id ep4_03_juliaphone_28c001aa
        show ep4 juliaphone_015 with d
        simon "You read my mind!" (what_italic=True)
        simon "How do you feel about lunch today?" (what_italic=True)
        show ep4 juliaphone_016 with d
        julia "A lunch date? That sounds great!" id ep4_03_juliaphone_11394307
        show ep4 juliaphone_017 with d
        simon "Well, it wouldn't really be a date... I just wanted to go out for a bite to eat." id ep4_03_juliaphone_3e4f558a
        show ep4 juliaphone_018 with d
        julia "All right, Twinkle Toes!" id ep4_03_juliaphone_ea17f6f0
        julia "Send me the address, and I'll meet you there!" id ep4_03_juliaphone_85bee4d5
        show ep4 juliaphone_019 with d
        julia "By the way, is everything okay?" id ep4_03_juliaphone_7f5ded11
        julia "You sound different somehow." id ep4_03_juliaphone_158c4810
        stop music fadeout 3.0
        show ep4 juliaphone_020 with d
        simon "Oh, nothing to worry about. See you soon, Julia." id ep4_03_juliaphone_e27cba49
        julia "See ya!" (what_italic=True)
    else:

        play sound cell_phone_ring volume 0.5
        show ep4 juliaphone_021 with d
        simon "(I have this feeling things didn't end very well last time.)" id ep4_03_juliaphone_a2d56564
        stop sound fadeout 1
        show ep4 juliaphone_022 with d
        play music whole_hearted fadein 3 volume 0.35
        julia "Oh! Hey, you." id ep4_03_juliaphone_25cb94dc
        show ep4 juliaphone_023 with d
        simon "Hey, Julia. How are you?" (what_italic=True)
        show ep4 juliaphone_024 with d
        julia "Fine. You?" id ep4_03_juliaphone_b91c4b92
        show ep4 juliaphone_025 with d
        simon "Things took a weird turn the last time we saw each other." id ep4_03_juliaphone_10d8b263
        simon "So I was wondering if you'd like to have lunch with me today and talk it over." id ep4_03_juliaphone_00f1a5a2
        show ep4 juliaphone_026 with d
        julia "Oh... I thought you just didn't want to see me anymore..." id ep4_03_juliaphone_f72667a6
        julia "Well, never mind all that." id ep4_03_juliaphone_3905409d
        show ep4 juliaphone_027 with d
        julia "I'd love to. Do you have a place in mind?" id ep4_03_juliaphone_759bba61
        show ep4 juliaphone_028 with d
        simon "I'll text you." (what_italic=True)
        show ep4 juliaphone_029 with d
        julia "You didn't answer my question though. How are you?" id ep4_03_juliaphone_310dc550
        show ep4 juliaphone_030 with d
        simon "I'm good. I'll fill you in on the details when I see you." id ep4_03_juliaphone_4f4488fd
        stop music fadeout 3.0
        simon "See you there." id ep4_03_juliaphone_f3ada306
        julia "See ya!" (what_italic=True)




    $ debug_other_path()
    jump ep4_04_julialunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
