
label ep4_20_homelasttime:

$ award_manager.block_notify()

show ep4 homelasttime_001 with wiperight
stop music fadeout 5
simon "(Looks like it's going to rain.)" id ep4_20_homelasttime_7d50a8d1
show ep4 homelasttime_002 with d
simon "(I'd better hurry.)" id ep4_20_homelasttime_1b0ce3de
show ep4 homelasttime_003 with d
simon "(I hate storms.)" id ep4_20_homelasttime_84340eb9
show ep4 homelasttime_004_1 with wiperight
pause
play sound thunder_crack_fast volume 0.8 
show ep4 homelasttime_004 with vpunch
simon "(Phew... Almost got caught in that.)" id ep4_20_homelasttime_1032f9ce
show ep4 homelasttime_005 with d
simon "(Let me take inventory of my stuff.)" id ep4_20_homelasttime_18260c95
stop sound fadeout 2
show ep4 homelasttime_006 with d
simon "(I just need to pack up my clothes...)" id ep4_20_homelasttime_ce87c966
show ep4 homelasttime_007 with d
simon "(I'll be taking you with me.)" id ep4_20_homelasttime_fde8a817
show ep4 homelasttime_008 with d
simon "(Hmmm...)" id ep4_20_homelasttime_f523318e
show ep4 homelasttime_009 with d
simon "(The keys...)" id ep4_20_homelasttime_deddb3d6
play sound key_in_lock
show ep4 homelasttime_010 with d
simon "(Well, I've got nothing to lose.)" id ep4_20_homelasttime_00165c12
play sound door_open5 volume 0.5 
show ep4 homelasttime_011 with d
simon "(It actually works.)" id ep4_20_homelasttime_b109e120
play sound door_squeak_2
show ep4 homelasttime_012 with d
simon "Emily...?" id ep4_20_homelasttime_d019c823
stop sound
show ep4 homelasttime_013 with d
simon "(It's so dark in here.)" id ep4_20_homelasttime_1695556e


show ep4 homelasttime_014 with d
simon "(Then this is just the key to her apartment.)" id ep4_20_homelasttime_8b256bcb
show ep4 homelasttime_015 with d
simon "(Wait. What's that?)" id ep4_20_homelasttime_75581f69
show ep4 homelasttime_016 with d
simon "(No...)" id ep4_20_homelasttime_be36d12d
show ep4 homelasttime_017 with d
simon "(It's that picture of Susan... And the other person in the picture is...)" id ep4_20_homelasttime_518a1b39
show ep4 homelasttime_018 with d
simon "Emily!" id ep4_20_homelasttime_37cf406d
show ep4 homelasttime_019 with d
simon "(But it's not just her in it...)" id ep4_20_homelasttime_73215fc3
show ep4 homelasttime_020 with d
simon "(The third person...)" id ep4_20_homelasttime_fcbc9467
play sound hit_reverb_dark_1 fadein 0.3
show ep4 homelasttime_020_1 with d
simon "(... is me?)" id ep4_20_homelasttime_fdf7e11d

simon "What in the fuck is going on?!" id ep4_20_homelasttime_bb60dd07

simon "How is this possible?!" id ep4_20_homelasttime_55078d99
play sound_2 thunder_clap volume 0.7
show black as ep4 with Dissolve(3.0)
pause 1.0

jump ep4_205_nightleaving
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
