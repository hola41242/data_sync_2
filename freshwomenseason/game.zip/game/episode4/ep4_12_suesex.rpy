
label ep4_12_suesex:
    stop music fadeout 2
    show ep4 suesex_001 with d
    simon "My thoughts sure go a lot of places when you do that." id ep4_12_suesex_75390457

    play music immortal_gods volume 0.35
    show ep4 suesex_002 with d
    sue "I figured that might happen." id ep4_12_suesex_c77c70cf
    show ep4 suesex_003 with d
    pause 1.5
    show ep4 suesex_003_1 with d
    pause 2
    show ep4 suesex_003_2 with d
    pause 3
    show ep4 suesex_004 with d
    simon "So, is this why you brought me out here?" id ep4_12_suesex_40934d58

    simon "Did you have some ulterior motive?" id ep4_12_suesex_2685dda4
    show ep4 suesex_006 with d
    sue "Don't be so sure of yourself, hotshot." id ep4_12_suesex_2e41794d
    sue "I just said my mind tends to go places here." id ep4_12_suesex_549fb4c5
    show ep4 suesex_007 with d
    sue "And my mind just happened to lead me to where my hand was on your cock." id ep4_12_suesex_65d5741e
    show ep4 suesex_008 with d
    simon "Is this what you usually think about when you come here?" id ep4_12_suesex_cfb664e6
    show ep4 suesex_009 with d
    sue "Well..."
    show ep4 suesex_010 with d
    sue "I have been thinking about... that." id ep4_12_suesex_eff751cc
    play sound jeans_off_2 volume 1
    show ep4 suesex_011 with d
    sue "Ahh..." id ep4_12_suesex_f8c68a5f
    show ep4 suesex_012 with d
    sue "Just as big as I remember." id ep4_12_suesex_a360f3e3
    show ep4 suesex_013 with d
    simon "It hasn't been that long." id ep4_12_suesex_5fa39969
    show ep4 suesex_014 with d
    sue "I was so sleepy last time though." id ep4_12_suesex_9206f3ed
    sue "Today, I'm wide awake." id ep4_12_suesex_46a51c89
    show ep4 suesex_015 with d
    sue "I'll be able to appreciate it so much more." id ep4_12_suesex_31cbe864

    show ep4 suesex_017 with d
    simon "Then get over here." id ep4_12_suesex_c4c04ceb
    show ep4 suesex_018 with d
    sue "Wow, you certainly got bossy real quick." id ep4_12_suesex_bab54a44
    show ep4 suesex_019 with d
    simon "I know you like it like that." id ep4_12_suesex_6dd94004
    show ep4 suesex_020 with d
    sue "I showed you a sweeter side of mine today." id ep4_12_suesex_67b4992c

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_024_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_024_var1_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_024_var1 with d
    sue "I'm glad that didn't ruin the mood." id ep4_12_suesex_806aacc7
    simon "Ruin it?" id ep4_12_suesex_b465bcab
    sue "Yeah. I'm glad you stayed tough for me." id ep4_12_suesex_f2d585bb
    sue "Really..." id ep4_12_suesex_1cac10e1

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_024_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_024_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_024 with d
    sue "Really glad..." id ep4_12_suesex_aec3de0b
    simon "(Fuck...)" id ep4_12_suesex_1de3ca68
    simon "(This is so good...)" id ep4_12_suesex_9662479b
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_024_var2_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_024_var2_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_024_var2 with d
    simon "(Her tongue is so warm...)" id ep4_12_suesex_cd281493
    simon "(Oh, that's right.)" id ep4_12_suesex_9e3d580f
    simon "(She likes it rough.)" id ep4_12_suesex_e6e69a04
    simon "(She's so bossy, but when it comes to sex, she likes to be the one bossed around.)" id ep4_12_suesex_f5f02791

    pause

    menu:
        "Get up, Sue":
            pass

    stop foley
    stop voicefx
    show ep4 suesex_027 with d
    simon "Get up, Sue." id ep4_12_suesex_e58db708
    sue "Ah..." id ep4_12_suesex_7a182655

    show ep4 suesex_028 with d
    sue "Are you going to tell me what to do now?" id ep4_12_suesex_7eeed474
    show ep4 suesex_029 with d
    simon "Trust me. I know what I'm doing." id ep4_12_suesex_5cf145e9
    show ep4 suesex_030 with d
    sue "So sure of yourself." id ep4_12_suesex_fa5fe1e4
    show ep4 suesex_031 with d
    sue "Let's see how long you can keep that up." id ep4_12_suesex_1c4ed287
    show ep4 suesex_032 with d
    simon "No, no, no." id ep4_12_suesex_d193de61
    show ep4 suesex_033 with d
    simon "Up." id ep4_12_suesex_0a6ac994
    show ep4 suesex_034 with d
    sue "Ah, I see. That's what you're talking about." id ep4_12_suesex_d7b50321
    sue "Let me get ready for you then." id ep4_12_suesex_c0eb2555
    show ep4 suesex_035 with d
    pause 1
    show ep4 suesex_035_1 with d
    play sound cloth_whoosh
    pause 0.6
    show ep4 suesex_036 with d
    sue "Just like this." id ep4_12_suesex_1968e985
    show ep4 suesex_036_2 with d
    pause 2
    show ep4 suesex_036_1 with d
    pause 2
    show ep4 suesex_037 with d
    simon "Take it all off." id ep4_12_suesex_b5e2b924
    show ep4 suesex_038 with d
    sue "You sure are taking this seriously." id ep4_12_suesex_81389975
    show ep4 suesex_039 with d
    sue "(Though I can't say I'm not enjoying it.)" id ep4_12_suesex_cb75f244
    show ep4 suesex_040 with d
    simon "I said everything." id ep4_12_suesex_c79c2039
    play sound dress
    show ep4 suesex_041 with d
    sue "Well then..."
    show ep4 suesex_042 with d
    sue "Good?" id ep4_12_suesex_97bf7007
    show ep4 suesex_043 with d
    simon "There you go." id ep4_12_suesex_9f483e04
    simon "Much better." id ep4_12_suesex_a4af0cff
    show ep4 suesex_044 with d
    sue "Perks of never wearing a bra." id ep4_12_suesex_7a968554
    show ep4 suesex_045 with d
    sue "Are you satisfied now?" id ep4_12_suesex_3b93235a
    play sound dress2 volume 0.6
    show ep4 suesex_046 with d
    simon "Getting there." id ep4_12_suesex_f3980402
    show ep4 suesex_047 with d
    sue "Oh? There's more then?" id ep4_12_suesex_37215e20
    show ep4 suesex_048 with d
    simon "Of course there's more." id ep4_12_suesex_ae2c859e
    simon "There are rules." id ep4_12_suesex_7ebfc3ec
    show ep4 suesex_049 with d
    sue "Oh really?" id ep4_12_suesex_3b3b4976
    show ep4 suesex_050 with d
    simon "Yes. And my rules are..." id ep4_12_suesex_bbaee40f


    show ep4 suesex_051 with d
    sue "Hmm..."

    menu:
        "Tease her":
            show ep4 suesex_052 with d
            simon "You can touch..." id ep4_12_suesex_ad4010af

            show ep4 suesex_053 with None
            simon "But you can't look." id ep4_12_suesex_5993bd79
            show ep4 suesex_054 with d
            sue "Aww... That's not fair." id ep4_12_suesex_5b5adcf0
            show ep4 suesex_055 with d
            sue "I want to look at it." id ep4_12_suesex_7790c126
            show ep4 suesex_056 with d
            simon "Do you know what's better than looking?" id ep4_12_suesex_dfa76d6b
            show ep4 suesex_057 with d
            sue "What?" id ep4_12_suesex_8e903214
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_suesex_058_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_suesex_058_foley fadein 0.5 fadeout 0.5
            show ep4 anim_suesex_058 with d
            simon "Feeling." id ep4_12_suesex_9c84ecb0




            sue "Aaaahhhh..." id ep4_12_suesex_2683a332
            sue "You're such a tease, [name]!" id ep4_12_suesex_d573ffbd


            stop foley
            stop voicefx
            show ep4 suesex_054 with d
            sue "Come here." id ep4_12_suesex_5d193e5c
        "I want you on top":




            simon "I want you on top." id ep4_12_suesex_0080fab4

            show ep4 suesex_060 with d
            sue "On top?" id ep4_12_suesex_3fae3004
            show ep4 suesex_060_1 with d
            sue "Quite bossy today, aren't we?" id ep4_12_suesex_f6d01847
            sue "Good!" id ep4_12_suesex_6f6cc87d
            show ep4 suesex_061 with d
            sue "I've been dying to do this again." id ep4_12_suesex_afeefbe0
            show ep4 suesex_062 with d
            sue "Not only is your dick long, it's just so thick." id ep4_12_suesex_084a0cb5
            show ep4 suesex_063 with d
            sue "I feel like it fills me completely!" id ep4_12_suesex_3461b488
            show ep4 suesex_064 with d
            simon "See? When you're not looking, you can feel so much more." id ep4_12_suesex_736eaf01
            show ep4 suesex_065 with d
            simon "(And at the same time... the view from back here is great.)" id ep4_12_suesex_db62639c
            show ep4 suesex_066 with d
            sue "I bet you're enjoying watching." id ep4_12_suesex_6a234ea5
            show ep4 suesex_067 with d
            sue "But, hey, even I gave in a little when it came to my rules..." id ep4_12_suesex_dafb9f24

            show ep4 suesex_068 with d
            simon "Ah... You want me to go easy on you." id ep4_12_suesex_c9149c2c
            show ep4 suesex_069 with d
            sue "No. Actually, I'd rather go easy on you today." id ep4_12_suesex_d1eb6ae6
            show ep4 suesex_070 with d
            sue "Come. Let's get you more comfortable." id ep4_12_suesex_e15f8d9c


    show ep4 suesex_071 with d
    simon "You know I can't drive." id ep4_12_suesex_6d5d5f39
    show ep4 suesex_072 with d
    sue "Don't worry." id ep4_12_suesex_4bb4e83f
    sue "I'll take the wheel." id ep4_12_suesex_c176c2c4


    show ep4 suesex_073 with d
    sue "(Finally!)" id ep4_12_suesex_6ec4d96c



    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_075_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_075_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_075 with d
    simon "Fuck!" id ep4_12_suesex_b5e9e7ab
    simon "(It's better than I remembered.)" id ep4_12_suesex_9de524aa
    simon "(Her mouth is so warm and wet.)" id ep4_12_suesex_b9c380b6
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_074_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_074_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_074 with d
    simon "Aaahh..." id ep4_12_suesex_f073064a
    simon "(Her hair smells nice too.)" id ep4_12_suesex_39ee7477
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_076_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_076_var1_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_076_var1 with d
    simon "(Honestly, it's a good thing I can't drive.)" id ep4_12_suesex_cf7d7864
    simon "(That way, I can concentrate on what she's doing.)" id ep4_12_suesex_734c1964
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_077_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_077_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_077 with d
    simon "(On what we're doing...)" id ep4_12_suesex_4ddf0b17
    simon "(In her car.)" id ep4_12_suesex_06b8012f
    pause

    stop foley
    stop voicefx
    show ep4 suesex_079 with d
    simon "(Wait, is this even hers?!)" id ep4_12_suesex_3f050170


    show ep4 suesex_080 with d
    sue "[name]? What's wrong?" id ep4_12_suesex_a6d007a2
    show ep4 suesex_081 with d
    simon "This car is yours, right?" id ep4_12_suesex_5cf84bed
    show ep4 suesex_082 with d
    sue "Yeah... Why?" id ep4_12_suesex_36d6caaf
    show ep4 suesex_083 with d
    simon "Ah... That means we don't have to worry..." id ep4_12_suesex_927a80ea
    show ep4 suesex_084 with d
    simon "... about the mess." id ep4_12_suesex_84c3e263
    show ep4 suesex_085 with d
    sue "I do!" id ep4_12_suesex_ae7d5208
    sue "I'm the one who's going to have to clean it after!" id ep4_12_suesex_3ae1cc05
    show ep4 suesex_086 with d
    sue "Why bring that up?" id ep4_12_suesex_45dedcfe
    sue "Are you thinking about doing something dirty to me?" id ep4_12_suesex_0feea409
    show ep4 suesex_088 with d
    simon "Maybe."

    simon "Would you be mad if I did?" id ep4_12_suesex_34aa61e1
    show ep4 suesex_089 with d
    sue "Maybe."
    show ep4 suesex_090 with d
    sue "You'll never know until you try." id ep4_12_suesex_67b34d02
    show ep4 suesex_091 with d
    simon "Well, in that case..." id ep4_12_suesex_b19bf3dc


    show ep4 suesex_092 with d
    sue "Hmm?"
    show ep4 suesex_093 with d
    sue "Ah!" id ep4_12_suesex_57795aa3
    show ep4 suesex_094 with d
    sue "Not bad." id ep4_12_suesex_8da19517
    show ep4 suesex_095 with d
    sue "It's a little tight like this, so there isn't much space to maneuver." id ep4_12_suesex_b46a5597
    sue "But that makes your dick feel even bigger!" id ep4_12_suesex_cee5fb08
    show ep4 suesex_096 with d
    sue "Aaaahh..." id ep4_12_suesex_10c944f4
    show ep4 suesex_097 with d
    simon "(She's right.)" id ep4_12_suesex_8022298a
    show ep4 suesex_098 with d
    simon "(She seems even tighter than before!)" id ep4_12_suesex_a1166240
    show ep4 suesex_099 with d
    sue "So what do you think?" id ep4_12_suesex_cd2ec896
    sue "Am I making things easy for you?" id ep4_12_suesex_56dab649
    show ep4 suesex_100 with d
    simon "Well, there's always a way to turn the tables." id ep4_12_suesex_be74b29a
    show ep4 suesex_101 with d
    stop music fadeout 5
    sue "Is that so?" id ep4_12_suesex_36c89906
    sue "You must have more ideas." id ep4_12_suesex_5f7afde5
    show ep4 suesex_102 with d
    simon "I know you like to be in control, but I want to be on top this time." id ep4_12_suesex_a409140e
    play sound bed 
    show ep4 suesex_103 with d
    pause
    show ep4 suesex_104 with d
    sue "I like that." id ep4_12_suesex_d0a93857
    show ep4 suesex_105 with d
    sue "But just because I'm not on top, that doesn't mean I'm not in control." id ep4_12_suesex_7b721a95
    play music body_on_fire fadein 0.5 volume 0.3
    show ep4 suesex_106 with hpunch
    sue "For example, if I did something like this." id ep4_12_suesex_681676d4
    show ep4 suesex_107 with vpunch
    sue "And this." id ep4_12_suesex_0b559901
    show ep4 suesex_108 with d
    simon "(I can barely breathe!)" id ep4_12_suesex_fc9d39b4
    show ep4 suesex_109 with d
    simon "(But she's pulling me so deep inside of her...)" id ep4_12_suesex_1f4aa07e
    simon "(Damn. I don't think I've ever been this hard in my life!)" id ep4_12_suesex_b9591000
    show ep4 suesex_110 with d
    simon "Ahh... That's it." id ep4_12_suesex_a5e74dee
    show ep4 suesex_111 with d
    simon "Just like that, Sue..." id ep4_12_suesex_beb4d13e
    show ep4 suesex_112 with d
    simon "(Shit. I'm getting so close to cumming.)" id ep4_12_suesex_0f122ee3
    simon "(I can't cum before she does!)" id ep4_12_suesex_c0fa98f8
    show ep4 suesex_113 with d
    simon "Hey, Sue." id ep4_12_suesex_76c3817e
    show ep4 suesex_114 with d
    simon "There's more space in the back we can use." id ep4_12_suesex_68b37d0d
    show ep4 suesex_115 with d
    sue "Need some space to breathe, huh?" id ep4_12_suesex_39bed22b
    show ep4 suesex_116 with d
    simon "Maybe."
    show ep4 suesex_117 with d
    simon "Or maybe I just want to fuck you from behind." id ep4_12_suesex_69374afd
    show ep4 suesex_118 with d
    sue "Wow." id ep4_12_suesex_ec30d84c
    sue "Let's see if you really mean that." id ep4_12_suesex_27b4ef43
    show ep4 suesex_119 with d
    simon "Do you think I'd joke about something so serious?" id ep4_12_suesex_063a2b28
    show ep4 suesex_120 with d
    simon "I take that ass deadly serious." id ep4_12_suesex_4ad8f85c
    show ep4 suesex_121 with d
    sue "Of course you do." id ep4_12_suesex_2ad62305


    show ep4 suesex_123 with d
    sue "Wait... More space in the back... fuck me from behind..." id ep4_12_suesex_dd6c4388
    sue "You're not thinking what I think you're thinking, are you?" id ep4_12_suesex_f3511308

    simon "I wasn't..." id ep4_12_suesex_9578f385
    show ep4 suesex_125 with d
    simon "But now..." id ep4_12_suesex_4cf23468
    show ep4 suesex_126 with d
    sue "No way." id ep4_12_suesex_40aaad88
    show ep4 suesex_127 with d
    sue "Have you seen the size of the tool you're packing?" id ep4_12_suesex_dda8b4a1
    show ep4 suesex_128 with d
    sue "I've never seen anything like it." id ep4_12_suesex_1e183693
    show ep4 suesex_129 with d
    simon "Well, you know how to make a man happy and let him down at the same time." id ep4_12_suesex_2e71672d
    show ep4 suesex_130 with d
    sue "Get used to it." id ep4_12_suesex_5bfb69c4
    show ep4 suesex_131 with d
    sue "Also..." id ep4_12_suesex_edb0ebbe
    show ep4 suesex_132 with d
    sue "There's still so much of me to explore." id ep4_12_suesex_f4ab53ce
    show ep4 suesex_133 with d
    sue "You can check out my ass..." id ep4_12_suesex_8b0b328e
    show ep4 suesex_134 with d
    sue "You can grab my tits..." id ep4_12_suesex_1e0b23cd
    show ep4 suesex_135 with d
    sue "Good, huh?" id ep4_12_suesex_758cfcd3
    show ep4 suesex_136 with d
    sue "And you've still got my pussy to fuck." id ep4_12_suesex_4c18193f



    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_137_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_137_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_137 with d
    sue "Ahhhh, [name]..." nointeract
    pause 125/30


    stop foley
    stop voicefx
    show ep4 suesex_138 with d
    simon "FUCK..." id ep4_12_suesex_a50aea58
    sue "Give me everything, [name]!" id ep4_12_suesex_c7f3d434

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_137_var1_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_137_var1_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_137_var1 with d
    sue "Ahhhh, [name]..." nointeract
    pause 80/30

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_137_var2_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_137_var2_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_137_var2 with d
    simon "Back it up. Let me fucking plow that pussy." id ep4_12_suesex_00e79928
    sue "Just like that!" id ep4_12_suesex_9f14522c
    sue "Fuck me, [name]! Fuck me!" id ep4_12_suesex_dfa99efa
    pause

    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_137_var3_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_137_var3_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_137_var3 with d
    sue "Harder!" id ep4_12_suesex_984271a0
    simon "You like that, don't you?" id ep4_12_suesex_e859bf4b
    sue "Ahhh..." id ep4_12_suesex_872ff8e3
    sue "Your dick feels so good inside me..." id ep4_12_suesex_777545fe
    sue "Mmmmm..." id ep4_12_suesex_21d33f87
    pause
    stop foley
    stop voicefx
    show ep4 suesex_142 with d
    sue "I have an idea." id ep4_12_suesex_faac8653
    show ep4 suesex_143 with d
    sue "Get over here..." id ep4_12_suesex_f0a2cdd0
    show ep4 suesex_144 with d
    sue "I want you to watch as it goes in." id ep4_12_suesex_f9a37063
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_145_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_145_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_145 with d


    simon "Yeah... Plus, I can get a good look at that ass." id ep4_12_suesex_627a08aa
    pause

    menu:
        "Slap her ass"(True):
            $ ep4_suesex_slap_her_ass = True
            $ player_choice("ep4_suesex_slap_her_ass:true")
            play sound slap volume 3 
            stop foley
            stop voicefx
            show ep4 suesex_146 with hpunch
            sue "Aaahhnng..." id ep4_12_suesex_90f520b9
            show ep4 suesex_147 with d
            sue "I didn't think you were going to do that..." id ep4_12_suesex_ba5b7f63
            show ep4 suesex_148 with d
            simon "(I took a risk...)" id ep4_12_suesex_3d9198bc
            show ep4 suesex_149 with d
            sue "Do it again!" id ep4_12_suesex_069abba2
            play sound slap volume 3 
            show ep4 suesex_150 with hpunch
            simon "(And it paid off!)" id ep4_12_suesex_e6f2401e


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_suesex_146_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_suesex_146_foley fadein 0.5 fadeout 0.5
            show ep4 anim_suesex_146 with d
            sue "Again!" id ep4_12_suesex_92a4fcd1

            simon "My pleasure." id ep4_12_suesex_b01d239d


            sue "Aaaahhhh... Yes..." id ep4_12_suesex_daa3bb43

            sue "That's it, [name]! Fuck me!" id ep4_12_suesex_9e3a57e7
            sue "Spank my little ass!"
            pause
            stop foley
            stop voicefx
            show ep4 suesex_154 with d
            sue "(Ahhh... I knew he was the one.)" id ep4_12_suesex_318cc4f2
        "Don't slap her ass":

            $ ep4_suesex_dont_spank_sues_ass = True
            $ player_choice("ep4_suesex_dont_spank_sues_ass:true")


            simon "Hmm..." id ep4_12_suesex_92c095c3
            stop foley
            stop voicefx
            show ep4 suesex_156 with d
            sue "Hmm?"
            show ep4 suesex_157 with d
            simon "(Nah.)" id ep4_12_suesex_8632d5a1
            show ep4 suesex_158 with d
            sue "(I didn't think he'd be the type to do that...)" id ep4_12_suesex_a638624e
            show ep4 suesex_159 with d
            sue "(But still, he makes me feel so wonderful!)" id ep4_12_suesex_4ec3ed9e



    show ep4 suesex_160 with d
    sue "Yes, yes... Keep going..." id ep4_12_suesex_42195dd7
    show ep4 suesex_161 with d
    sue "Give me everything you've got, [name]!" id ep4_12_suesex_5ec4e6a8
    show ep4 suesex_162 with d
    simon "I'm close to giving you every last drop!" id ep4_12_suesex_017f8209
    show ep4 suesex_163 with d
    sue "(Ahhh... So good!)" id ep4_12_suesex_3de76593
    show ep4 suesex_164 with d
    simon "(If she keeps this up, I'll end up cumming soon!)" id ep4_12_suesex_60c333e5
    show ep4 suesex_165 with d
    sue "(If he keeps this up, I'll end up cumming!)" id ep4_12_suesex_a909a3b8
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_166_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_166_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_166 with d
    simon "(It looks like she's close too.)" id ep4_12_suesex_e6e577af
    $ allow_voicefx = False
    if is_voice_installed:
        play voicefx ep4_anim_suesex_167_voicefx fadein 0.5 fadeout 0.5
        play foley ep4_anim_suesex_167_foley fadein 0.5 fadeout 0.5
    show ep4 anim_suesex_167 with d
    sue "(I have to make him cum first!)" id ep4_12_suesex_d1edb586
    simon "(I can do it!)" id ep4_12_suesex_a9b932e6
    pause
    menu:
        "Cum":
            pass
    stop foley
    stop voicefx
    show ep4 suesex_169 with d
    sue "(I can do it!)" id ep4_12_suesex_53ec058a
    show ep4 suesex_170 with d
    simon "Aaaahhh!" id ep4_12_suesex_c8dff4f7
    show ep4 suesex_171 with d
    sue "AAAAAAHHHH!" id ep4_12_suesex_e17e987c
    show ep4 suesex_172 with d
    simon "(I'm so close!)" id ep4_12_suesex_81dee503
    show ep4 suesex_173 with d
    sue "(Almost there...)" id ep4_12_suesex_66e8192f
    show ep4 suesex_174 with d
    simon "Aaaaaahhh..." id ep4_12_suesex_0df34661
    sue "Oh my god. Oh my god. Oh fuck!" id ep4_12_suesex_d023b48e


    show ep4 suesex_175 with vpunch
    pause 0.5
    show ep4 suesex_175 with vpunch
    pause 0.5
    show ep4 suesex_175 with vpunch
    pause 0.5
    sue "Aaaaaaahhhh..." id ep4_12_suesex_dd9bf6eb
    show ep4 suesex_176 with d
    stop music fadeout 4
    sue "(We came!)" id ep4_12_suesex_e0bff403
    show ep4 suesex_177 with d
    simon "(At the same time!)" id ep4_12_suesex_75562763
    show ep4 suesex_178 with d
    sue "Wow... that was..." id ep4_12_suesex_5da21402
    show ep4 suesex_179 with d
    simon "Amazing." id ep4_12_suesex_ac462caa
    show ep4 suesex_180 with d
    sue "Hmm..."
    play music like_the_ocean fadein 2 volume 0.2
    show ep4 suesex_181 with d
    simon "That's what you were going to say, wasn't it?" id ep4_12_suesex_e04e0ca3
    show ep4 suesex_182 with d
    sue "Maybe."
    show ep4 suesex_183 with d
    simon "Of course..." id ep4_12_suesex_41326fcf
    show ep4 suesex_184 with d
    simon "You can say nice things every once in a while, you know?" id ep4_12_suesex_b1c45f9d
    show ep4 suesex_185 with d
    sue "I..." id ep4_12_suesex_c904db46
    show ep4 suesex_186 with d
    sue "All right, fine." id ep4_12_suesex_340a3d1b
    show ep4 suesex_187 with d
    sue "It was good." id ep4_12_suesex_f6a5822a
    sue "Happy now?" id ep4_12_suesex_f685edfd
    show ep4 suesex_188 with d
    simon "I'd say that was way more than good." id ep4_12_suesex_e1f4e2db
    show ep4 suesex_189 with d
    sue "Don't push your luck, bud." id ep4_12_suesex_4cf98780
    show ep4 suesex_190 with d
    simon "All right. I'll take what I can get." id ep4_12_suesex_07609f5d
    show ep4 suesex_191 with d
    sue "Heh." id ep4_12_suesex_7cf873e1
    show ep4 suesex_192 with d
    sue "Smartass." id ep4_12_suesex_259f29a7
    show ep4 suesex_193 with d
    sue "Still not as soft as my bed, but not half bad." id ep4_12_suesex_0b18065e
    show ep4 suesex_194 with d
    simon "Thanks..." id ep4_12_suesex_bb919a8e
    show ep4 suesex_195 with d
    simon "I guess." id ep4_12_suesex_4b2021c5
    show ep4 suesex_196 with d
    sue "Shut up." id ep4_12_suesex_af5f9b0b
    show ep4 suesex_197 with d
    sue "Let's just..." id ep4_12_suesex_985672ce
    show ep4 suesex_198 with d
    sue "... enjoy the view." id ep4_12_suesex_0f682a07
    show ep4 suesex_199 with d
    simon "You were right." id ep4_12_suesex_206bc7ed
    simon "It is quite the view." id ep4_12_suesex_340e1216
    show ep4 suesex_200 with d
    sue "Yes, it is. Beautiful, even after the sunrise." id ep4_12_suesex_f50b3ea9
    show ep4 suesex_201 with d
    simon "True." id ep4_12_suesex_49b7339a
    show ep4 suesex_202 with d
    simon "Oh shit!" id ep4_12_suesex_2ffe8669
    show ep4 suesex_203 with d
    simon "The sun's up!" id ep4_12_suesex_9b5957d2
    simon "I have to go to class!" id ep4_12_suesex_581110bc
    show ep4 suesex_204 with d
    sue "Relax. I said I'd take you there." id ep4_12_suesex_67719305
    show ep4 suesex_205 with d
    simon "Oh, right." id ep4_12_suesex_150bf38b
    show ep4 suesex_206 with d
    sue "You should probably head home and clean yourself up first though." id ep4_12_suesex_a255173f
    stop music fadeout 3
    show ep4 suesex_207 with d
    simon "Right. Of course." id ep4_12_suesex_fed060c5
    show ep4 suesex_214 with long_fade
    simon "Thanks, Sue." id ep4_12_suesex_1b5715b2
    show ep4 suesex_215 with d
    simon "Will you let me drive?" id ep4_12_suesex_2a3deae9
    play sound engine_start volume 0.5 
    show ep4 suesex_216 with d
    sue "No fucking way." id ep4_12_suesex_3740a33c
    $ renpy.end_replay()
    jump ep4_13_hometoschool
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
