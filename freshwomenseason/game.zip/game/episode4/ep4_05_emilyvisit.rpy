
label ep4_05_emilyvisit:
play sound door_opening volume 0.5
show ep4 emilyvisit_001 with wipeleft
simon "(Looks like someone got here before me.)" id ep4_05_emilyvisit_19472e98
play music doppelgangers volume 0.57
show ep4 emilyvisit_002 with d
simon "(No fucking way.)" id ep4_05_emilyvisit_c98e7a2d
show ep4 emilyvisit_003 with d
simon "You again...?" id ep4_05_emilyvisit_2f23c11b
show ep4 emilyvisit_004 with d
emily "Huh? Oh! Hi, [name]." id ep4_05_emilyvisit_564da47b
show ep4 emilyvisit_005 with d
simon "What do you mean, hi?!" id ep4_05_emilyvisit_e54016cc
simon "What are you doing in my apartment..." id ep4_05_emilyvisit_0f4d3e77
simon "... AGAIN?" id ep4_05_emilyvisit_480acfa7

show ep4 emilyvisit_006 with d
emily "Wow, you sure are on edge today." id ep4_05_emilyvisit_c95bb871
show ep4 emilyvisit_007 with d
simon "Emily. You're in my room." id ep4_05_emilyvisit_c228e62b
show ep4 emilyvisit_008 with d
simon "And you're naked." id ep4_05_emilyvisit_92265143
show ep4 emilyvisit_009 with d
emily "Ah, that. I like sleeping in the nude." id ep4_05_emilyvisit_f6944125
show ep4 emilyvisit_010 with d
simon "Tell me the truth." id ep4_05_emilyvisit_13a7aada
simon "Was it you who stole my underwear?" id ep4_05_emilyvisit_14c650fb
show ep4 emilyvisit_011 with d
emily "No." id ep4_05_emilyvisit_6e71811a
show ep4 emilyvisit_012 with d
emily "I just borrowed them." id ep4_05_emilyvisit_53413927
show ep4 emilyvisit_013 with d
simon "That's no different from stealing..." id ep4_05_emilyvisit_3e782d4f
simon "You took something from my house without my permission..." id ep4_05_emilyvisit_f867609c
show ep4 emilyvisit_014 with d
simon "You know what? I give up." id ep4_05_emilyvisit_b366dc26
show ep4 emilyvisit_015 with d
simon "Fuck this place." id ep4_05_emilyvisit_7d7a66ec
show ep4 emilyvisit_016 with d
emily "Yeah, fuck this place!" id ep4_05_emilyvisit_4d53d884
show ep4 emilyvisit_017 with d
simon "And as for you..." id ep4_05_emilyvisit_1eb2e28e
show ep4 emilyvisit_018 with d
emily "As for me?" id ep4_05_emilyvisit_7e15f2b8
show ep4 emilyvisit_019 with d
emily "Fuck me too, right?" id ep4_05_emilyvisit_4bb1957d
show ep4 emilyvisit_020 with d
simon "Huh?" id ep4_05_emilyvisit_708b4972
show ep4 emilyvisit_021 with d
emily "You heard me. Fuck me. Fuck me silly." id ep4_05_emilyvisit_4f9562f4
show ep4 emilyvisit_022 with d
simon "You're insane, Emily." id ep4_05_emilyvisit_23f8b9f6
show ep4 emilyvisit_023 with d
emily "Or maybe, I'm the sanest person here." id ep4_05_emilyvisit_04a33d05
show ep4 emilyvisit_024 with d
simon "Hehe." id ep4_05_emilyvisit_1fef46eb
stop music fadeout 4
show ep4 emilyvisit_025 with d
simon "Hahahaha!" id ep4_05_emilyvisit_da3cfffd
show ep4 emilyvisit_026 with d
emily "I know I'm right." id ep4_05_emilyvisit_21d33718
emily "And you are going to fuck me." id ep4_05_emilyvisit_aa958248

menu:
    "Agree with Emily"(True):
        play music stick_with_me volume 0.5
        $ ep4_emilyvisit_agree_with_emily = True
        $ player_choice("ep4_emilyvisit_agree_with_emily:true")
        $ points_emily += 1
        show ep4 emilyvisit_027 with d
        simon "You know what?" id ep4_05_emilyvisit_de93686f
        simon "You're right." id ep4_05_emilyvisit_94ac25bb
        show ep4 emilyvisit_028 with d
        simon "Fuck you, Emily." id ep4_05_emilyvisit_9f571523
        show ep4 emilyvisit_029 with d
        emily "Yes. Fuck me good!" id ep4_05_emilyvisit_fbb6b1e6
        show ep4 emilyvisit_030 with d
        simon "But tell me something... This is the first time for us, right?" id ep4_05_emilyvisit_a0072f98
        show ep4 emilyvisit_031 with d
        emily "What do you think?" id ep4_05_emilyvisit_ab3fae94
        show ep4 emilyvisit_032 with d
        simon "I think it doesn't even matter anymore." id ep4_05_emilyvisit_e015e310
        show ep4 emilyvisit_033 with d
        simon "I could ask a bunch of questions, but I know the answers would all be vague or nonsensical." id ep4_05_emilyvisit_100c0be3
        show ep4 emilyvisit_034 with d
        simon "So I guess the best thing to do is just not ask..." id ep4_05_emilyvisit_ce893a0a
        show ep4 emilyvisit_035 with d
        simon "... And instead, let you do what you do best." id ep4_05_emilyvisit_1ed43f05
        play sound jeans_off_2 volume 1 
        show ep4 emilyvisit_036 with d
        emily "Now that's what I'm talking about!" id ep4_05_emilyvisit_60a882af
        show ep4 emilyvisit_037 with d
        emily "And you know I do things right." id ep4_05_emilyvisit_a0e3633d
        show ep4 emilyvisit_038 with d
        simon "If you say so..." id ep4_05_emilyvisit_419fbd99
        show ep4 emilyvisit_039 with d
        simon "... Let's see if..." id ep4_05_emilyvisit_85e77ecb
        show ep4 emilyvisit_040 with d
        simon "Oh..." id ep4_05_emilyvisit_d3eabd74
        show ep4 emilyvisit_041 with d
        simon "Oh my god..." id ep4_05_emilyvisit_23432470
        show ep4 emilyvisit_042 with d
        emily "I know exactly what you like." id ep4_05_emilyvisit_01b34cb8
        show ep4 emilyvisit_043 with d
        simon "How...? How do you know that?" id ep4_05_emilyvisit_c4a05224
        simon "Did you learn the way from my underwear?!" id ep4_05_emilyvisit_d048000f
        show ep4 emilyvisit_044 with d
        simon "Are you some sort of witch or something?" id ep4_05_emilyvisit_e015e749
        show ep4 emilyvisit_045 with d
        emily "Do you really want me to answer that? Or would you rather I keep sucking you off?" id ep4_05_emilyvisit_83aa7d9d
        show ep4 emilyvisit_046 with d
        simon "No more questions, Your Honor." id ep4_05_emilyvisit_1d52162e
        show ep4 emilyvisit_047 with d
        simon "(Wow... Preference is a very personal thing.)" id ep4_05_emilyvisit_d75a2093
        show ep4 emilyvisit_048 with d
        simon "(... And for me, this is perfect.)" id ep4_05_emilyvisit_221c0a45
        show ep4 emilyvisit_049 with d
        simon "(This feels like a tailored service. She's doing it exactly how I like it.)" id ep4_05_emilyvisit_d63aa657
        show ep4 emilyvisit_050 with d
        simon "(And I don't even have to say a word!)" id ep4_05_emilyvisit_43580bfd
        show ep4 emilyvisit_051 with d
        simon "(If the foreplay is this good...I wonder what the sex will be like...)" id ep4_05_emilyvisit_c239f88f
        show ep4 emilyvisit_052 with d
        simon "(Would it be better than in my dream?)" id ep4_05_emilyvisit_29eba65b
        show ep4 emilyvisit_053 with d
        simon "(Damn, she's right.)" id ep4_05_emilyvisit_0ab5673a
        simon "(I really want to fuck her.)" id ep4_05_emilyvisit_ad4b76fe
        show ep4 emilyvisit_054 with d
        emily "I think you're ready." id ep4_05_emilyvisit_9ff40eda
        show ep4 emilyvisit_055 with d
        simon "What? How do you — ?" id ep4_05_emilyvisit_1013f0a4
        show ep4 emilyvisit_056 with d
        emily "Shhh... Leave everything to me." id ep4_05_emilyvisit_528e1566
        show ep4 emilyvisit_056_1 with d
        simon "All right." id ep4_05_emilyvisit_278c9e73
        show ep4 emilyvisit_057 with d
        emily "Leave it all in Emily's capable hands." id ep4_05_emilyvisit_59310144
        show ep4 emilyvisit_058 with d
        simon "Aren't you afraid the neighbors will see you?" id ep4_05_emilyvisit_4895f46a
        show ep4 emilyvisit_059 with d
        emily "What neighbors?" id ep4_05_emilyvisit_36986f31
        show ep4 emilyvisit_060 with d:
            yalign 1.0
            ease 8 yalign 0.0
        emily "I don't see anyone..." id ep4_05_emilyvisit_3ef849f0
        show ep4 emilyvisit_061 with d
        emily "Maybe you want to have a look?" id ep4_05_emilyvisit_29883232
        show ep4 emilyvisit_062 with d
        simon "Oh, I'm definitely going to want to see things up close." id ep4_05_emilyvisit_c414aa63
        show ep4 emilyvisit_063 with d
        emily "Yes... Just like that." id ep4_05_emilyvisit_14a82cae
        show ep4 emilyvisit_064_1 with d
        emily "Oh..." id ep4_05_emilyvisit_cd113912



        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_064_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_064_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_064 with d
        emily "Aahhnngg..." id ep4_05_emilyvisit_8a6f0eb9
        simon "This is even better..." id ep4_05_emilyvisit_d3f1576a
        pause

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_064_var1_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_064_var1_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_064_var1 with d
        simon "... than in my dream." id ep4_05_emilyvisit_c90f6da7
        emily "Aww, how cute!" id ep4_05_emilyvisit_80348fc1
        emily "You mean you've been dreaming about me?" id ep4_05_emilyvisit_007ebde9
        pause

        stop foley
        stop voicefx
        show ep4 emilyvisit_067 with d
        simon "Well, I..." id ep4_05_emilyvisit_30d5ac8f
        show ep4 emilyvisit_068 with d
        emily "What did we do in this dreams of yours?" id ep4_05_emilyvisit_3408addd
        show ep4 emilyvisit_069 with d
        emily "Was it similar to what we're doing now?" id ep4_05_emilyvisit_46500062
        show ep4 emilyvisit_070 with d
        simon "It was, down to the fact that I had no idea what was going to happen next." id ep4_05_emilyvisit_07c1cca5
        show ep4 emilyvisit_071 with d
        emily "Isn't that just amazing? And so liberating!" id ep4_05_emilyvisit_7a4af54f
        emily "It's great to have zero cares in the world." id ep4_05_emilyvisit_77ffafda
        show ep4 emilyvisit_072 with d
        simon "It's also a little scary if I'm being honest." id ep4_05_emilyvisit_7d8b618d
        show ep4 emilyvisit_073 with d
        emily "So... are you going to keep fucking me or what?" id ep4_05_emilyvisit_aefa855f
        show ep4 emilyvisit_074 with d
        simon "Who knows?" id ep4_05_emilyvisit_b83720cf
        show ep4 emilyvisit_075 with d
        emily "I think your dick already gave us the answer to that question." id ep4_05_emilyvisit_4e576781
        show ep4 emilyvisit_076 with d
        simon "Hey, what are you doing?!" id ep4_05_emilyvisit_3f81a4ef
        play sound heavy_fabric_flattening volume 0.6
        show ep4 emilyvisit_077 with d
        emily "Come here." id ep4_05_emilyvisit_f97e050b
        show ep4 emilyvisit_078 with d
        emily "Fuck me harder." id ep4_05_emilyvisit_464696d2
        show ep4 emilyvisit_079 with d
        emily "You brought a cute girl over a few days ago." id ep4_05_emilyvisit_a7b2e658
        show ep4 emilyvisit_080 with d
        emily "Are you going to fuck me the same way you fucked her?" id ep4_05_emilyvisit_91aeb374

        emily "Hmm?" id ep4_05_emilyvisit_e47d2dde

        if choice_made('ep2_julia_kiss'):
            show ep4 emilyvisit_087 with d
            simon "Could we not talk about her?" id ep4_05_emilyvisit_46356faf
        else:
            show ep4 emilyvisit_082 with d
            simon "I prefer to focus on the here and now." id ep4_05_emilyvisit_913b1620


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep4_anim_emilyvisit_081_voicefx fadein 0.5 fadeout 0.5
                play foley ep4_anim_emilyvisit_081_foley fadein 0.5 fadeout 0.5
            show ep4 anim_emilyvisit_081 with d
            emily "Good answer." id ep4_05_emilyvisit_1050faf7
            simon "Anyway, we didn't have sex. Things didn't come to that." id ep4_05_emilyvisit_b11f6b51
            emily "What a pity. She was such a beautiful little thing." id ep4_05_emilyvisit_ce5a60d5
            emily "She doesn't know what she's missing." id ep4_05_emilyvisit_4a990a3b
            emily "Leave that to me then... I'll... finish... what she... started." id ep4_05_emilyvisit_b422b269
            pause

        $ debug_other_path()

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_081_var3_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_081_var3_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_081_var3 with d
        simon "(She has the face of an airhead, but she catches onto a lot more than she shows.)" id ep4_05_emilyvisit_6e5c77e3
        simon "(I should stay away from people like her.)" id ep4_05_emilyvisit_4f8f37e4
        simon "(There's just one problem...)" id ep4_05_emilyvisit_e2a406a2
        simon "(... She's so fucking hot!)" id ep4_05_emilyvisit_3948ae17
        simon "(And she screws like she really knows me...)" id ep4_05_emilyvisit_af195d1b
        pause 

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_094_var1_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_094_var1_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_094_var1 with d
        emily "Aaahhnngg... So good..." id ep4_05_emilyvisit_35945d64
        simon "(Sometimes, I guess it pays off to stick your dick in crazy.)" id ep4_05_emilyvisit_faec1ef3
        pause
        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_094_var3_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_094_var3_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_094_var3 with d
        simon "(She seems to be enjoying herself too... I think it might be worth experimenting a little more and seeing what she's into.)" id ep4_05_emilyvisit_579ba290
        pause

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_094_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_094_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_094 with d
        emily "Aaah..."
        emily "Yes..." id ep4_05_emilyvisit_16ffc79a
        emily "Just like that..."

        image ep4 anim_emilyvisit_combo1:
            "ep4 anim_emilyvisit_095" with Dissolve(0.1)
            pause 5
            "ep4 anim_emilyvisit_081" with Dissolve(0.1)
            pause 5
            "ep4 anim_emilyvisit_081_var3" with Dissolve(0.1)
            pause 5
            "ep4 anim_emilyvisit_094_var1" with Dissolve(0.1)
            pause 5
            "ep4 anim_emilyvisit_094_var3" with Dissolve(0.1)
            pause 5
            "ep4 anim_emilyvisit_094" with Dissolve(0.1)
            pause 5
            repeat

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_combo1_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_combo1_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_combo1 with d
        emily "You really know how to treat a girl, [name]!" id ep4_05_emilyvisit_7e5665af
        emily "Mmmmm..." id ep4_05_emilyvisit_5bc0802b
        pause

        menu:
            "Continue":
                pass

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_096_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_096_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_096 with d
        emily "I hope you don't mind..." id ep4_05_emilyvisit_c6f24abb
        pause

        $ allow_voicefx = False
        if is_voice_installed:
            play voicefx ep4_anim_emilyvisit_097_voicefx fadein 0.5 fadeout 0.5
            play foley ep4_anim_emilyvisit_097_foley fadein 0.5 fadeout 0.5
        show ep4 anim_emilyvisit_097 with d
        emily "... if I lend you a hand." id ep4_05_emilyvisit_0842be5e
        pause

        stop foley
        stop voicefx
        show ep4 emilyvisit_099 with d
        simon "In that case, let me help you out." id ep4_05_emilyvisit_4e294631
        show ep4 emilyvisit_100 with d
        emily "Yes! Right there!" id ep4_05_emilyvisit_56e9f8e0
        show ep4 emilyvisit_101 with d
        simon "(Somehow I knew she'd like that.)" id ep4_05_emilyvisit_0e2aebd8
        show ep4 emilyvisit_102 with d
        simon "(This feels so natural!)" id ep4_05_emilyvisit_e6cc8974
        show ep4 emilyvisit_103 with d
        simon "(I can do whatever I want to!)" id ep4_05_emilyvisit_5461843b
        show ep4 emilyvisit_104 with d
        emily "I've wanted this for so long!" id ep4_05_emilyvisit_5a7c00f1
        show ep4 emilyvisit_105 with d
        simon "So long? So you really did leave that door open on purpose!" id ep4_05_emilyvisit_e7c48eb7
        show ep4 emilyvisit_106 with d
        emily "Of course! I wanted you to be thinking of me." id ep4_05_emilyvisit_8971d16f
        show ep4 emilyvisit_107 with d
        emily "Do you like my strategy?" id ep4_05_emilyvisit_e98d4dfa
        show ep4 emilyvisit_108 with d
        emily "I improvised, adapted, and overcame." id ep4_05_emilyvisit_8a380413
        show ep4 emilyvisit_109 with d
        emily "Time to adapt again." id ep4_05_emilyvisit_5fd179c0
        show ep4 emilyvisit_110 with d
        emily "Your turn to lie back." id ep4_05_emilyvisit_3acafd84
        play sound body_fall_mat8 volume 0.7
        show ep4 emilyvisit_111 with hpunch
        simon "What the...?" id ep4_05_emilyvisit_2f7e4b1f
        play sound bed volume 0.7
        show ep4 emilyvisit_112 with vpunch
        emily "Shhh..." id ep4_05_emilyvisit_f1c5756b
        show ep4 emilyvisit_113 with d
        emily "... Just enjoy it." id ep4_05_emilyvisit_145ae954
        show ep4 emilyvisit_114 with d
        emily "As you said before..."
        show ep4 emilyvisit_115 with d
        emily "... I'll do what I do best." id ep4_05_emilyvisit_f8a0ed05
        show ep4 emilyvisit_116 with d
        simon "My god..." id ep4_05_emilyvisit_320b64f4
        show ep4 emilyvisit_117 with d
        emily "And I take this cowgirl stuff pretty seriously." id ep4_05_emilyvisit_7aad3919
        show ep4 emilyvisit_118 with d
        emily "I love riding you, [name]!" id ep4_05_emilyvisit_c8ce59dd
        show ep4 emilyvisit_119 with d
        simon "(Wow, I didn't know she had so much energy!)" id ep4_05_emilyvisit_03353c04
        show ep4 emilyvisit_120 with d
        simon "It's just one surprise after another with you, Emily." id ep4_05_emilyvisit_e0d89d67
        show ep4 emilyvisit_121 with d
        emily "Hope you like surprises..." id ep4_05_emilyvisit_8d723a70
        show ep4 emilyvisit_122 with d
        emily "... Because I have one more..." id ep4_05_emilyvisit_314e64fd
        show ep4 emilyvisit_123 with d
        simon "Oh, and what's that?" id ep4_05_emilyvisit_f35ba22c
        show ep4 emilyvisit_124 with d
        emily "I'm going to give you a choice." id ep4_05_emilyvisit_d8afcae5
        show ep4 emilyvisit_125 with d
        emily "You can only choose one option!" id ep4_05_emilyvisit_6acde372
        show ep4 emilyvisit_126 with d
        emily "And it's just this once." id ep4_05_emilyvisit_e0430794
        stop music fadeout 4
        show ep4 emilyvisit_127 with d
        emily "I'll let you choose how you want to finish." id ep4_05_emilyvisit_b0082d03
        show ep4 emilyvisit_128 with d
        emily "We can do it however you want." id ep4_05_emilyvisit_8aa2fe87

        menu:
            "Anal":
                play music fun volume 0.45
                $ ep4_emilyvisit_anal = True
                $ player_choice("ep4_emilyvisit_anal:true")
                show ep4 emilyvisit_129 with d
                simon "Since you insist... I want to fuck you from behind." id ep4_05_emilyvisit_5602d2ee
                show ep4 emilyvisit_130 with d
                emily "Are you talking about...?" id ep4_05_emilyvisit_92bf2a77
                show ep4 emilyvisit_131 with d
                pause
                show ep4 emilyvisit_132 with d
                pause
                show ep4 emilyvisit_131 with d
                pause
                show ep4 emilyvisit_133 with d
                emily "Ooooh... How daring..." id ep4_05_emilyvisit_ed7898f3
                show ep4 emilyvisit_134 with d
                emily "I like that." id ep4_05_emilyvisit_96cb51b8
                show ep4 emilyvisit_135 with d
                simon "Really? Will you let me?" id ep4_05_emilyvisit_3ebb27e2

                show ep4 emilyvisit_136 with d
                emily "But of course. As long as you lube yourself up." id ep4_05_emilyvisit_de548b57
                show ep4 emilyvisit_137 with d
                emily "I might not be able to walk for a few days, but a deal's a deal." id ep4_05_emilyvisit_a80d14aa
                show ep4 emilyvisit_138 with d
                emily "Besides... I kind of expected you would ask for that." id ep4_05_emilyvisit_4f285b18
                show ep4 emilyvisit_139 with d
                emily "Just... go easy on me, 'kay?" id ep4_05_emilyvisit_7a2710bc
                play sound lotion_bottle1 volume 0.7
                show ep4 emilyvisit_140 with d
                simon "I will, promise." id ep4_05_emilyvisit_7ef17585
                show ep4 emilyvisit_141 with d
                simon "Ready?" id ep4_05_emilyvisit_88270d02
                show ep4 emilyvisit_142 with d
                emily "As ready as I can be." id ep4_05_emilyvisit_e085c88d
                show ep4 emilyvisit_143 with d
                simon "Here I go." id ep4_05_emilyvisit_18c49fac
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep4_anim_emilyvisit_144_1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep4_anim_emilyvisit_144_1_foley fadein 0.5 fadeout 0.5
                show ep4 anim_emilyvisit_144_1 with d
                pause 3
                stop foley
                stop voicefx
                show ep4 emilyvisit_144 with d
                emily "AAAAHHH!" id ep4_05_emilyvisit_1d0637e4
                show ep4 emilyvisit_145 with d
                simon "Are you okay?" id ep4_05_emilyvisit_30ddab2a
                show ep4 emilyvisit_146 with d
                emily "Keep going..." id ep4_05_emilyvisit_6b226c22
                show ep4 emilyvisit_147 with d
                emily "Mmmm..."
                show ep4 emilyvisit_148 with d
                emily "Mmmmph..." id ep4_05_emilyvisit_c380da88
                show ep4 emilyvisit_149 with d
                simon "(I can't believe I'm actually doing this...)" id ep4_05_emilyvisit_9fba551d
                simon "(I was worried at first, but she seems to be enjoying it!)" id ep4_05_emilyvisit_685e8fa4
                show ep4 emilyvisit_150 with d
                simon "Um... Can I go deeper?" id ep4_05_emilyvisit_8f020285
                show ep4 emilyvisit_151 with d
                emily "You haven't put it all in yet?! My god..." id ep4_05_emilyvisit_574b92eb
                show ep4 emilyvisit_152 with d
                emily "All right. Let's do it..." id ep4_05_emilyvisit_016aebc4
                show ep4 emilyvisit_153 with vpunch
                emily "Aaaaahhhh!" id ep4_05_emilyvisit_37ee1d48
                simon "Aaaahhh..." id ep4_05_emilyvisit_643c7c6f
                show ep4 emilyvisit_154 with d
                simon "(She pulled me inside her!)" id ep4_05_emilyvisit_1a48f4d5
                simon "(She didn't have to take me all at once!)" id ep4_05_emilyvisit_75638598
                show ep4 emilyvisit_155 with d
                simon "Holy fuck..." id ep4_05_emilyvisit_28cc8dc5
                show ep4 emilyvisit_156 with d
                simon "That was amazing!" id ep4_05_emilyvisit_8546d969
                show ep4 emilyvisit_157 with d
                emily "Tell me I'm going to make you cum..." id ep4_05_emilyvisit_7c25ff0d
                show ep4 emilyvisit_158 with d
                simon "Oh, you have no idea..." id ep4_05_emilyvisit_6f5a4eee
                play sound heavy_fabric_movement volume 0.7
                show ep4 emilyvisit_159 with d
                emily "Will you cum in my ass?" id ep4_05_emilyvisit_dfbac12a
                show ep4 emilyvisit_160 with d
                simon "Can I?!" id ep4_05_emilyvisit_d341dd23
                show ep4 emilyvisit_161 with d
                emily "I said you could do it however you wanted..." id ep4_05_emilyvisit_39cd27de
                show ep4 emilyvisit_162 with d
                simon "(She really wasn't kidding!)" id ep4_05_emilyvisit_4fb59695
                show ep4 emilyvisit_162_1 with d
                simon "Ohhhh!" id ep4_05_emilyvisit_adb14431
                show ep4 emilyvisit_163 with d
                simon "(Holy shit! This is fantastic!)" id ep4_05_emilyvisit_6eb43c40
                show ep4 emilyvisit_164 with d
                emily "Ahhh... Ahhh... Ahhhh..." id ep4_05_emilyvisit_d5570196
                show ep4 emilyvisit_165 with d
                simon "Emily, I'm going to..." id ep4_05_emilyvisit_a7a9c70d
                show ep4 emilyvisit_166 with d
                simon "Aaaahhhhhhh..." id ep4_05_emilyvisit_506e2ae6
                show ep4 emilyvisit_167 with hpunch
                emily "Aaaaahhhh..." id ep4_05_emilyvisit_d6e88d11
                show ep4 emilyvisit_168 with hpunch
                emily "Wow..."
                show ep4 emilyvisit_169 with hpunch
                emily "It just keeps coming..." id ep4_05_emilyvisit_d96c726a
                stop music fadeout 10
                show ep4 emilyvisit_170 with d
                simon "Wow... I didn't think we'd go this far." id ep4_05_emilyvisit_75e5ede7
                show ep4 emilyvisit_171 with d
                emily "I'm surprised by how much you enjoyed that." id ep4_05_emilyvisit_0956a15b
                emily "Live and learn." id ep4_05_emilyvisit_6c35304f
                show ep4 emilyvisit_172 with d
                emily "Aaahhh..."
                show ep4 emilyvisit_173 with d
                simon "Are you going to fall back asleep there?" id ep4_05_emilyvisit_2afc8200
                show ep4 emilyvisit_174 with d
                emily "Oh, that's right! I gotta go!" id ep4_05_emilyvisit_a1557d97
                show ep4 emilyvisit_244 with d
                emily "I'm just going to use your shower real quick."
                show ep4 emilyvisit_245 with d
                simon "Of course, it's right over th —"
                show ep4 emilyvisit_246 with d
                emily "I know where it is."
                show ep4 emilyvisit_247 with d
                simon "(Of course she does.)"
            "Deepthroat":

                play music fun volume 0.3
                $ ep4_emilyvisit_deepthroat = True
                $ player_choice("ep4_emilyvisit_deepthroat:true")
                show ep4 emilyvisit_175 with d
                simon "In that case, I want to stick it in your mouth." id ep4_05_emilyvisit_de5c4f42
                show ep4 emilyvisit_176 with d
                simon "Let's see how deep you can take it." id ep4_05_emilyvisit_783a4fa1

                show ep4 emilyvisit_177 with d
                emily "Oh, a classic!" id ep4_05_emilyvisit_c8a4b8d4
                show ep4 emilyvisit_178 with d
                emily "It won't be easy... but girls like a challenge." id ep4_05_emilyvisit_6ccaa5f4
                show ep4 emilyvisit_179 with d
                emily "Wow... It's huge." id ep4_05_emilyvisit_981ff849
                show ep4 emilyvisit_180 with d
                emily "I need both hands to get a good grip!" id ep4_05_emilyvisit_3b7b05c5
                show ep4 emilyvisit_181 with d
                emily "I haven't tried going this deep before, but since it's what you want, I simply can't say no." id ep4_05_emilyvisit_4f5dc40b
                show ep4 emilyvisit_182 with d
                simon "I'll go easy on you." id ep4_05_emilyvisit_abdf4837
                show ep4 emilyvisit_183 with d
                emily "Let's see here..." id ep4_05_emilyvisit_b1ff039e
                simon "(I believe in you, Emily.)" id ep4_05_emilyvisit_983baa5d
                show ep4 emilyvisit_184 with d
                emily "Hmmmph..."
                simon "Huh?" id ep4_05_emilyvisit_196da51b
                show ep4 emilyvisit_185 with d
                simon "What was that?" id ep4_05_emilyvisit_40e3eda2
                show ep4 emilyvisit_186 with d
                emily "*Gasp...*"
                show ep4 emilyvisit_187 with d
                emily "I... I don't think... I can..." id ep4_05_emilyvisit_19b7bfe3
                show ep4 emilyvisit_188 with d
                simon "Ah. That's okay." id ep4_05_emilyvisit_51b40e82
                show ep4 emilyvisit_189 with d
                emily "No. It's not okay." id ep4_05_emilyvisit_9b61efd8
                show ep4 emilyvisit_190 with d
                emily "I have to. It's my duty!" id ep4_05_emilyvisit_468cdc45
                show ep4 emilyvisit_191 with d
                emily "I'll just take it all at once!" id ep4_05_emilyvisit_8a13018a
                simon "What? All at once — ?" id ep4_05_emilyvisit_9dda0419
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep4_anim_emilyvisit_192_voicefx fadein 0.5 fadeout 0.5
                    play foley ep4_anim_emilyvisit_192_foley fadein 0.5 fadeout 0.5
                show ep4 anim_emilyvisit_192 with d
                pause 2 
                stop foley
                stop voicefx
                show ep4 emilyvisit_193 with vpunch
                simon "Oohhh..." id ep4_05_emilyvisit_5a09ea95
                emily "Hmmmmpph!" id ep4_05_emilyvisit_a9015c75
                simon "My god!" id ep4_05_emilyvisit_9551d55c
                show ep4 emilyvisit_194 with d
                emily "*Gasp...*" id ep4_05_emilyvisit_c5c771a2
                show ep4 emilyvisit_195 with d
                emily "Again!" id ep4_05_emilyvisit_69d54599
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep4_anim_emilyvisit_192_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep4_anim_emilyvisit_192_var1_foley fadein 0.5 fadeout 0.5
                show ep4 anim_emilyvisit_192_var1 with d

                pause 195/30
                stop foley
                stop voicefx
                show ep4 emilyvisit_196 with hpunch
                emily "Urph!" id ep4_05_emilyvisit_a39dcb68
                show ep4 emilyvisit_197 with d
                emily "Mmph..." id ep4_05_emilyvisit_8a941191
                simon "(She did it!)" id ep4_05_emilyvisit_d4367228
                show ep4 emilyvisit_198 with d
                simon "(She's insane!)" id ep4_05_emilyvisit_915f67d0
                show ep4 emilyvisit_199 with d
                simon "(She's not stopping...)" id ep4_05_emilyvisit_eb3bd17b
                show ep4 emilyvisit_200 with d
                simon "(And if she keeps this up, I won't have time to warn her...)" id ep4_05_emilyvisit_2f6b16fd
                show ep4 emilyvisit_201 with d
                simon "Emily..." id ep4_05_emilyvisit_9e64a95a
                show ep4 emilyvisit_202 with d
                emily "Hmm?!" id ep4_05_emilyvisit_7062b379
                show ep4 emilyvisit_203 with hpunch
                pause 0.5
                show ep4 emilyvisit_203 with hpunch
                pause 0.5
                show ep4 emilyvisit_203 with hpunch
                pause 0.5
                simon "Aaaaaaahhh!" id ep4_05_emilyvisit_21b62d8e
                show ep4 emilyvisit_204 with d
                emily "Aaah..."
                show ep4 emilyvisit_205 with d
                emily "Wow... look..." id ep4_05_emilyvisit_aace6434
                show ep4 emilyvisit_206 with d
                emily "*Gulp*" id ep4_05_emilyvisit_029e9bcd
                show ep4 emilyvisit_207 with d
                emily "Aaahhh." id ep4_05_emilyvisit_c83b203f
                show ep4 emilyvisit_208 with d
                simon "Fuck..." id ep4_05_emilyvisit_10eba243
                show ep4 emilyvisit_209 with d
                emily "Did I do that right?" id ep4_05_emilyvisit_c33b79cc
                show ep4 emilyvisit_210 with d
                simon "More than right." id ep4_05_emilyvisit_2a65801d
                show ep4 emilyvisit_211 with d
                emily "Excellent!" id ep4_05_emilyvisit_5df8b2fd
                show ep4 emilyvisit_212 with d
                stop music fadeout 3
                emily "Now, if you don't mind. I need to go wash up." id ep4_05_emilyvisit_0a5d0e9a
                show ep4 emilyvisit_245 with d
                simon "Of course. Right over there!" id ep4_05_emilyvisit_76ef0b8f
            "Creampie":

                play music fun volume 0.3
                $ ep4_emilyvisit_creampie = True
                $ player_choice("ep4_emilyvisit_creampie:true")
                show ep4 emilyvisit_213 with d
                simon "I want to know what it's like cumming inside you." id ep4_05_emilyvisit_5faeb312
                show ep4 emilyvisit_214 with d
                emily "Bold choice! Good thing I'm on birth control." id ep4_05_emilyvisit_03e6b4e4
                show ep4 emilyvisit_215 with d
                simon "Good to know." id ep4_05_emilyvisit_08d49329
                show ep4 emilyvisit_216 with d
                emily "Well, since that's the case..." id ep4_05_emilyvisit_dc29042f
                play sound bed_movement_1 volume 0.7 
                show ep4 emilyvisit_217 with d
                emily "Let me do all the work for you." id ep4_05_emilyvisit_2db50cba
                show ep4 emilyvisit_218 with d
                emily "Your job will be to just relax..." id ep4_05_emilyvisit_c4bf5c6a
                show ep4 emilyvisit_219 with d
                emily "... Let me take care of the rest." id ep4_05_emilyvisit_56910266
                show ep4 emilyvisit_220 with d
                pause
                show ep4 emilyvisit_221 with d
                simon "I need a job to do too." id ep4_05_emilyvisit_f69136ad
                show ep4 emilyvisit_222 with d
                emily "Of course you do!" id ep4_05_emilyvisit_20d7c760
                emily "Your job is the most important one." id ep4_05_emilyvisit_29ca5188
                show ep4 emilyvisit_223 with d
                emily "The grand finale!" id ep4_05_emilyvisit_b60393b0
                show ep4 emilyvisit_224 with d
                simon "So your job is to get me there." id ep4_05_emilyvisit_ab03fd22
                show ep4 emilyvisit_225 with d
                emily "Exactly." id ep4_05_emilyvisit_fbf41123
                show ep4 emilyvisit_226 with d
                emily "And to get you there I'll use..." id ep4_05_emilyvisit_1848af1b
                show ep4 emilyvisit_227 with d
                emily "... everything I know." id ep4_05_emilyvisit_33010da6
                show ep4 emilyvisit_228 with d
                simon "Ahhh..." id ep4_05_emilyvisit_ca6c5119
                show ep4 emilyvisit_229 with d
                simon "Not bad." id ep4_05_emilyvisit_f158b8e3

                image ep4 anim_emilyvisit_combo2:
                    "ep4 anim_emilyvisit_230" with Dissolve(0.1)
                    pause 9
                    "ep4 anim_emilyvisit_231" with Dissolve(0.1)
                    pause 9


                    "ep4 anim_emilyvisit_230_var1" with Dissolve(0.1)
                    pause 9
                    "ep4 anim_emilyvisit_234" with Dissolve(0.1)
                    pause 9
                    "ep4 anim_emilyvisit_235" with Dissolve(0.1)
                    pause 9
                    repeat



                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep4_anim_emilyvisit_combo2_voicefx fadein 0.5 fadeout 0.5
                    play foley ep4_anim_emilyvisit_combo2_foley fadein 0.5 fadeout 0.5
                show ep4 anim_emilyvisit_combo2 with d
                simon "Now, if I may..." id ep4_05_emilyvisit_9da2a87f
                emily "Ahhh..." id ep4_05_emilyvisit_fc0ed323
                emily "Right there..."
                emily "Hold me tighter!" id ep4_05_emilyvisit_fa8ea3cb
                simon "Ah..." id ep4_05_emilyvisit_ea7af8ef
                emily "Ahhhh... I'm almost there..." id ep4_05_emilyvisit_20056bac
                simon "Me too..." id ep4_05_emilyvisit_0572bda9
                pause

                menu:
                    "Cum":
                        pass

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep4_anim_emilyvisit_236_voicefx fadein 0.5 fadeout 0.5
                    play foley ep4_anim_emilyvisit_236_foley fadein 0.5 fadeout 0.5
                show ep4 anim_emilyvisit_236 with d
                emily "Then let's cum together!" id ep4_05_emilyvisit_a99c2142
                emily "Cum inside me, [name]!" id ep4_05_emilyvisit_2bb6bce4
                pause


                stop foley
                stop voicefx
                show ep4 emilyvisit_238 with vpunch
                pause 0.5
                show ep4 emilyvisit_238 with vpunch
                pause 0.5
                show ep4 emilyvisit_238 with vpunch
                pause 0.5
                simon "Aaaahhh!" id ep4_05_emilyvisit_c8dff4f7
                emily "Aaaaahhhhhh..." id ep4_05_emilyvisit_6f602a1f
                show ep4 emilyvisit_239 with d
                emily "Wow... look at that..." id ep4_05_emilyvisit_fc9ef70b
                show ep4 emilyvisit_240 with d
                emily "Was this what you wanted?" id ep4_05_emilyvisit_4344f9a3
                show ep4 emilyvisit_241 with d
                simon "It was good, huh?" id ep4_05_emilyvisit_110af7b6

                show ep4 emilyvisit_242 with d
                emily "It was amazing." id ep4_05_emilyvisit_f6791b71
                show ep4 emilyvisit_243 with d
                emily "But I think I need to clean up now." id ep4_05_emilyvisit_d1ddaaef
                show ep4 emilyvisit_244 with d
                stop music fadeout 3
                emily "I'll just use your shower real quick."
                show ep4 emilyvisit_245 with d
                simon "Of course, it's over th —"
                show ep4 emilyvisit_246 with d
                emily "I know where it is."
                show ep4 emilyvisit_247 with d
                simon "(Of course she does.)"




        play sound chair_swivel_seat volume 0.5
        show ep4 emilyvisit_248 with d
        play music birthday_suite fadein 3 volume 0.45
        simon "Oof..." id ep4_05_emilyvisit_19d88932
        show ep4 emilyvisit_249 with d
        simon "(I didn't get a wink of sleep last night.)" id ep4_05_emilyvisit_38fc27f4
        simon "(I think my body is finally giving in.)" id ep4_05_emilyvisit_b15c8151
        show ep4 emilyvisit_250 with d
        simon "(I should get some rest while she's in there.)" id ep4_05_emilyvisit_e7d752c1
        show ep4 emilyvisit_251 with d
        emily "[name]..." (what_italic=True)
        show ep4 emilyvisit_252 with d
        simon "..." id ep4_05_emilyvisit_ba28090a
        play sound vision_transition
        show ep4 emilyvisit_253 with white_fade
        emily "[name]..." (what_italic=True)
        play sound chair_swivel_shake
        show ep4 emilyvisit_254 with hpunch
        emily "[name]!" id ep4_05_emilyvisit_815d45a5
        simon "What?!" id ep4_05_emilyvisit_6c871165
        show ep4 emilyvisit_255 with d
        emily "I have to go now. Will you show me to the door?" id ep4_05_emilyvisit_bcb506db
        $ renpy.end_replay()
        show ep4 emilyvisit_256 with d
        simon "Sure." id ep4_05_emilyvisit_7d1120e8
        show ep4 emilyvisit_257 with d
        emily "Why are you doing that?" id ep4_05_emilyvisit_c36bee27
        show ep4 emilyvisit_258 with d
        simon "I have more neighbors than just you, Emily." id ep4_05_emilyvisit_0b5867a5
        show ep4 emilyvisit_259 with d
        emily "If you say so..." id ep4_05_emilyvisit_4deb4852
        show ep4 emilyvisit_260 with d
        emily "Oh, right. I have something for you." id ep4_05_emilyvisit_ad557fc8
        show ep4 emilyvisit_261 with d
        emily "You can consider this the final gift of the day." id ep4_05_emilyvisit_91c49150

    "Disagree with Emily" if not _in_replay:
        play music birthday_suite fadein 3 volume 0.3
        $ ep4_emilyvisit_disagree_with_emily = True
        $ player_choice("ep4_emilyvisit_disagree_with_emily:true")
        show ep4 emilyvisit_262 with d
        simon "You know what, Emily?" id ep4_05_emilyvisit_c28e88e4
        simon "I may not remember much about my father, but one thing's for sure..." id ep4_05_emilyvisit_249de27c

        show ep4 emilyvisit_263 with d
        simon "He definitely would have told me never to stick my dick in crazy." id ep4_05_emilyvisit_456eb97d
        show ep4 emilyvisit_264 with d
        simon "I think you'd better go." id ep4_05_emilyvisit_74b2407f
        $ renpy.end_replay()
        show ep4 emilyvisit_265 with d
        emily "Wow..."
        play sound door_open volume 0.5
        show ep4 emilyvisit_266 with d
        emily "You're nothing like the person I thought you were." id ep4_05_emilyvisit_673958cd
        show ep4 emilyvisit_267 with d
        emily "It's a shame we won't be able to have our fun." id ep4_05_emilyvisit_b208365b
        show ep4 emilyvisit_268 with d
        emily "But I know the stars will soon align, and we'll have our fun once more." id ep4_05_emilyvisit_28bbe231
        show ep4 emilyvisit_269 with d
        emily "Oh, right." id ep4_05_emilyvisit_bfe6f0e8
        show ep4 emilyvisit_270 with d
        emily "I almost forgot. I have something to give you." id ep4_05_emilyvisit_26a52a17
        show ep4 emilyvisit_271 with d
        simon "Enough with the presents, Emily." id ep4_05_emilyvisit_ccbd3d34
        show ep4 emilyvisit_261 with d
        emily "Consider this my parting gift." id ep4_05_emilyvisit_477dc168



show ep4 emilyvisit_272 with d
simon "What are these for?" id ep4_05_emilyvisit_61c35072
emily "One is your apartment key." id ep4_05_emilyvisit_08a414d1
emily "I figured I'd have to return it to you eventually." id ep4_05_emilyvisit_bd2a4c28
play sound large_key_chain volume 0.5
show ep4 emilyvisit_273 with d
emily "The other one... Well, you'll learn real soon what that one's for." id ep4_05_emilyvisit_ba7e6288
show ep4 emilyvisit_274 with d
emily "See you around, [name]." id ep4_05_emilyvisit_50b6c69b
show ep4 emilyvisit_275 with d
simon "(She's definitely still up to something.)" id ep4_05_emilyvisit_d5cf77c4
jump ep4_06_key
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
