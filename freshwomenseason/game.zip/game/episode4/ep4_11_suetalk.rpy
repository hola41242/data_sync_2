
label ep4_11_suetalk:


    if not choice_made('ep2_sue_stop') and not choice_made_skip_debug('ep4_susanhome_suespy1') and not choice_made_skip_debug('ep4_susanhome_suespy2'):

        show ep4 suetalk_001 with long_fade
        sue "Hey, dipshit." (what_italic=True)

        play music tell_me_lies fadein 2 volume 0.37
        show ep4 suetalk_002 with d
        simon "What the...?" id ep4_11_suetalk_2f7e4b1f
        show ep4 suetalk_003 with d
        sue "Yeah, I'm talking to you." id ep4_11_suetalk_08f77f33
        show ep4 suetalk_004 with d
        sue "Is it true?" id ep4_11_suetalk_4cd3b323
        show ep4 suetalk_005 with d
        simon "Is what true?" id ep4_11_suetalk_d8ee461c
        show ep4 suetalk_006 with d
        sue "Do you really have amnesia?" id ep4_11_suetalk_e35d107a
        show ep4 suetalk_007 with d
        simon "(Of course! She must not have heard!)" id ep4_11_suetalk_b2921232
        show ep4 suetalk_008 with d
        simon "Where did you find this?" id ep4_11_suetalk_44611bee
        show ep4 suetalk_009 with d
        sue "I went through auntie's things while the two of you were having your chat." id ep4_11_suetalk_9ef2eb75
        show ep4 suetalk_010 with d
        sue "Why didn't you tell me?" id ep4_11_suetalk_b66e9aa4
        show ep4 suetalk_011 with d
        simon "It's not something I go around telling people as soon as I meet them." id ep4_11_suetalk_5cbdeca5
        simon "But yeah, it's true." id ep4_11_suetalk_8c96caaf
        show ep4 suetalk_012 with d
        sue "So you really don't remember most of your past." id ep4_11_suetalk_1e35f4f2
        show ep4 suetalk_013 with d
        simon "That's right..." id ep4_11_suetalk_327d4745
        show ep4 suetalk_014 with d
        sue "Then it's like you were born yesterday." id ep4_11_suetalk_ca7988f4
        show ep4 suetalk_015 with d
        simon "I mean, when you put it like that..." id ep4_11_suetalk_4b5db9f8
        show ep4 suetalk_016_1 with d
        pause 0.5
        show ep4 suetalk_016 with d
        sue "Have you ever learned how to drive?" id ep4_11_suetalk_68c11f52
        play sound door_car
        show ep4 suetalk_017 with d
        simon "I'm not sure." id ep4_11_suetalk_4ec05ed7
        play sound door_car2
        show ep4 suetalk_018 with d
        sue "Good." id ep4_11_suetalk_a8ec8438
        sue "Hop in." id ep4_11_suetalk_03267b8b
        show ep4 suetalk_019 with d
        simon "What are you doing?" id ep4_11_suetalk_b9cba79e
        show ep4 suetalk_020 with d
        sue "I'm being nice." id ep4_11_suetalk_e7dbe976
        sue "I'll give you a lift back to the campus." id ep4_11_suetalk_9ca84f19
        show ep4 suetalk_021 with d
        sue "But first, I'm going to teach you a few things about driving." id ep4_11_suetalk_07b4b7ba
        show ep4 suetalk_022 with d
        simon "What?! But I don't know the first thing about —" id ep4_11_suetalk_7a29a88d
        show ep4 suetalk_023 with d
        sue "You don't actually know if you know or not. Isn't that right?" id ep4_11_suetalk_ae3100b0
        show ep4 suetalk_024 with d
        simon "Come again?" id ep4_11_suetalk_ad5a1cdb
        show ep4 suetalk_025 with d
        sue "My point exactly." id ep4_11_suetalk_df039a38
        sue "Come on." id ep4_11_suetalk_f7ca296a
        show ep4 suetalk_026 with d
        sue "There streets are pretty empty around this time." id ep4_11_suetalk_4034069a

        show ep4 suetalk_027 with fade
        sue "And don't worry. I'm not going to let you drive on the road or anything." id ep4_11_suetalk_d314dc47
        sue "I just want you to figure something out." id ep4_11_suetalk_f22664a7
        show ep4 suetalk_028 with d
        sue "What do you say?" id ep4_11_suetalk_97bf7007

        menu:
            "Drive"(True):
                $ ep4_suetalk_so_lets_go = True
                $ player_choice("ep4_suetalk_so_lets_go:true")
                $ points_sue += 1
                show ep4 suetalk_029 with d
                simon "I can do this!" id ep4_11_suetalk_2b656d00
                show ep4 suetalk_030 with d
                sue "So first, you have to —" id ep4_11_suetalk_855a5045
                play sound car_accelerating volume 0.8 
                show ep4 suetalk_031 with d
                simon "Relax." id ep4_11_suetalk_71956934
                simon "I got this." id ep4_11_suetalk_50007ffc
                show ep4 suetalk_032 with d
                pause 0.7
                show ep4 suetalk_033 with d
                pause 0.7
                stop sound fadeout 1
                show ep4 suetalk_034 with d
                simon "So?" id ep4_11_suetalk_98c878ca
                show ep4 suetalk_035 with d
                sue "Wow." id ep4_11_suetalk_ec30d84c
                sue "You did absolutely everything wrong." id ep4_11_suetalk_24e80974
                show ep4 suetalk_036 with d
                sue "But it was cute of you to try." id ep4_11_suetalk_90471f62
            "Don't drive":

                $ ep4_suetalk_you_better_drive = True
                $ player_choice("ep4_suetalk_you_better_drive:true")
                show ep4 suetalk_037 with d
                simon "I don't know, Sue." id ep4_11_suetalk_0c4be95f
                simon "It doesn't seem like a great idea to me." id ep4_11_suetalk_b68154b2
                show ep4 suetalk_038 with d
                sue "Pussy." id ep4_11_suetalk_91224a8a
                show ep4 suetalk_039 with d
                sue "Fine, I didn't know where I was going with this anyway." id ep4_11_suetalk_1b1d1167



        show ep4 suetalk_040 with d
        sue "Let me." id ep4_11_suetalk_5a0a7253
        show ep4 suetalk_041 with d
        simon "Oh..." id ep4_11_suetalk_d3eabd74
        show ep4 suetalk_042 with d
        simon "(Nice.)" id ep4_11_suetalk_b84b8dac
        show ep4 suetalk_043 with d
        sue "Dumbass." id ep4_11_suetalk_fa726049
        play sound engine_start volume 0.8 
        show ep4 suetalk_044 with d
        simon "Hehe." id ep4_11_suetalk_db3fb730
        stop sound fadeout 3


        show ep4 suetalk_045 with long_fade
        simon "So..." id ep4_11_suetalk_71d93eb4
        show ep4 suetalk_046 with d
        simon "Where's all this compassion coming from all of a sudden?" id ep4_11_suetalk_de6d2f63
        show ep4 suetalk_047 with d
        simon "You looked a little unwound back there." id ep4_11_suetalk_a362d812
        show ep4 suetalk_048 with d
        sue "Yeah. But then when I found out about your amnesia, I had a thought." id ep4_11_suetalk_95c5c485
        show ep4 suetalk_049 with d
        sue "I can't exactly blame you for things you don't even remember." id ep4_11_suetalk_4ec8c52d
        show ep4 suetalk_050 with d
        sue "I don't have the right." id ep4_11_suetalk_9ee0f7b4
        show ep4 suetalk_051 with d
        sue "So I decided to do something nice for a change." id ep4_11_suetalk_9ce8e087
        show ep4 suetalk_052 with d
        simon "By driving me to college?" id ep4_11_suetalk_cbd76fda
        play sound car_engine_off volume 0.4
        show ep4 suetalk_053 with d
        sue "Yeah..." id ep4_11_suetalk_c52eac61
        sue "But I wanted to take you somewhere first." id ep4_11_suetalk_7da13ceb
        show ep4 suetalk_054 with d
        stop music fadeout 3
        sue "Auntie thinks her house has the best view around." id ep4_11_suetalk_a37f6e44
        sue "But I know another place." id ep4_11_suetalk_88404bba
        play sound door_car
        show ep4 suetalk_055 with d
        sue "We're here." id ep4_11_suetalk_9dd5eb12
        play sound beach fadein 2 volume 0.16 loop
        show ep4 suetalk_056 with fade
        simon "Wow. Not bad." id ep4_11_suetalk_afdd427f
        show ep4 suetalk_057 with d
        sue "Take a closer look." id ep4_11_suetalk_e97bd044
        show ep4 suetalk_058 with d
        simon "What are we doing out here?" id ep4_11_suetalk_c59d2397
        stop sound fadeout 5
        show ep4 suetalk_059 with d
        queue music [is_it_alright, could_i_believe] volume 0.4
        sue "I usually come out here to think." id ep4_11_suetalk_c7aeefa3
        sue "And I've been thinking..." id ep4_11_suetalk_a88a7699
        show ep4 suetalk_060 with d
        sue "Accidents aren't usually good things, but you had a chance to start over with yours." id ep4_11_suetalk_33357eac
        sue "And I know it wasn't your choice." id ep4_11_suetalk_c5c19864
        show ep4 suetalk_061 with d
        sue "But right now, I do have a choice." id ep4_11_suetalk_b15be79e
        show ep4 suetalk_062 with d
        sue "My parents never cared much for me." id ep4_11_suetalk_6bd02add
        sue "I was pretty much always home alone." id ep4_11_suetalk_7785f422
        sue "Uncle Charlie was the only person in my family to ever make me smile." id ep4_11_suetalk_e0cdd620
        show ep4 suetalk_063 with d
        sue "So after he was out of the picture, things with my parents got even worse." id ep4_11_suetalk_b1592e79
        show ep4 suetalk_064 with d
        sue "But I might have been making things difficult for them as well." id ep4_11_suetalk_a964a26e
        sue "That's why I want to forget all of this about Aunt Susan." id ep4_11_suetalk_d5fae3d6
        sue "I don't want you to investigate her anymore." id ep4_11_suetalk_2f1c61dd
        show ep4 suetalk_065 with d
        simon "Consider it done." id ep4_11_suetalk_4f72b971
        simon "I've heard everything she's got to say anyway." id ep4_11_suetalk_3e0d4cc2
        show ep4 suetalk_066 with d
        simon "It's nice to know more about you though." id ep4_11_suetalk_c2d63df3
        simon "The not-so-good experiences also form part of who we are." id ep4_11_suetalk_732f5885
        show ep4 suetalk_067 with d
        simon "And I'm sorry about your parents." id ep4_11_suetalk_457c774b
        simon "I had no idea they were like that." id ep4_11_suetalk_2318db1e
        show ep4 suetalk_068 with d
        sue "It's like I'm not even there." id ep4_11_suetalk_b4ff2a5c
        show ep4 suetalk_069 with d
        sue "I could — I don't know — take an elephant home, and they wouldn't bat an eyelash." id ep4_11_suetalk_42faf90f
        sue "They'd never notice." id ep4_11_suetalk_5fd062b2
        show ep4 suetalk_070 with d
        simon "(Oh...)" id ep4_11_suetalk_adc41a60
        show ep4 suetalk_071 with d
        simon "What if, instead of an elephant, it were a person?" id ep4_11_suetalk_bb6e785d
        show ep4 suetalk_072 with d
        sue "It'd be like they were invisible." id ep4_11_suetalk_d189dacf
        show ep4 suetalk_073 with d
        sue "Why? You need a place to crash or something?" id ep4_11_suetalk_0c738307

        menu:
            "Ask to stay at her place"(True) if points_sue >= 7 or config.developer:
                $ ep4_sue_invite = True
                $ player_choice("ep4_sue_invite:true")
                show ep4 suetalk_074 with d
                simon "Kind of, yeah." id ep4_11_suetalk_50494c89
                show ep4 suetalk_075 with d
                sue "Oh really?"
                show ep4 suetalk_076 with d
                simon "Please?" id ep4_11_suetalk_1059ae98
                simon "Just until I can find another place." id ep4_11_suetalk_d468bec6
                show ep4 suetalk_077 with d
                sue "Why? What happened to your old place?" id ep4_11_suetalk_3b20d6f5
                show ep4 suetalk_078 with d
                simon "Well..." id ep4_11_suetalk_bf4a2a91
                show ep4 suetalk_079 with d
                sue "You know what? I don't even want to know." id ep4_11_suetalk_430555b8
                show ep4 suetalk_080 with d
                sue "All right. You can stay with me for a few days." id ep4_11_suetalk_ab9fb2b1
                show ep4 suetalk_081 with d
                simon "Really?" id ep4_11_suetalk_c1761c50
                show ep4 suetalk_082 with d
                sue "Yeah, but don't be getting any ideas." id ep4_11_suetalk_3b7b19b1
                sue "You cook your own food and tidy up after yourself." id ep4_11_suetalk_552a9b69
                show ep4 suetalk_083 with d
                sue "I'm no one's maid." id ep4_11_suetalk_6c0987c1
                show ep4 suetalk_084 with d
                simon "Thank you, Sue." id ep4_11_suetalk_4beaef61
                simon "I can take care of myself." id ep4_11_suetalk_075ba07d
                show ep4 suetalk_085 with d
                simon "Are you sure your parents won't care?" id ep4_11_suetalk_15540dcd
                show ep4 suetalk_086 with d
                sue "If they do notice you... all the better." id ep4_11_suetalk_ef608cf1
                sue "They'd be pretty pissed, but they wouldn't say anything about it to you." id ep4_11_suetalk_8be6742a
                show ep4 suetalk_087 with d
                simon "Got it." id ep4_11_suetalk_d4c01a79
                show ep4 suetalk_088 with d
                simon "And for the record, you'd make a terrible maid." id ep4_11_suetalk_585315ee
                show ep4 suetalk_089 with d
                sue "What? I'd be a killer maid if I put my mind to it." id ep4_11_suetalk_e4cc3a14
                show ep4 suetalk_090 with d
                simon "Hmmm..." id ep4_11_suetalk_29542a38
                show ep4 suetalk_091 with d
                sue "What's going on in that filthy mind of yours?" id ep4_11_suetalk_6e39016d
                show ep4 suetalk_092 with white_fade
                simon "Nothing..." id ep4_11_suetalk_e3e2f771
                show ep4 suetalk_093 with d
                sue "Right. I bet it was something dirty." id ep4_11_suetalk_5cd7718d
                show ep4 suetalk_094 with white_fade
                simon "No way." id ep4_11_suetalk_3f86a073
                show ep4 suetalk_095 with d
                sue "Yeah?" id ep4_11_suetalk_c81bc158
                show ep4 suetalk_096 with d
                sue "What's this then?" id ep4_11_suetalk_29302089
                show ep4 suetalk_097 with d
                sue "I took you in as my roommate less than a minute ago, and you're already thinking about screwing me?" id ep4_11_suetalk_80c86626

                menu:
                    "Yeah"(True):
                        $ ep4_suetalk_yea = True
                        $ player_choice("ep4_suetalk_yea:true")
                        jump ep4_12_suesex
                    "No, sorry":

                        $ ep4_suetalk_no = True
                        $ player_choice("ep4_suetalk_no:true")
                        pass
            "Don't ask":




                $ ep4_suetalk_do_not_ask = True
                $ player_choice("ep4_suetalk_do_not_ask:true")
                show ep4 suetalk_098 with d
                simon "No. Forget I even mentioned it." id ep4_11_suetalk_7f68fe16
                show ep4 suetalk_099 with d
                sue "Are you okay?" id ep4_11_suetalk_79b40f2f
                show ep4 suetalk_100 with d
                simon "Yes and no." id ep4_11_suetalk_2e4043bc
                simon "But I'll be fine." id ep4_11_suetalk_44129ae7
                show ep4 suetalk_101 with d
                simon "At the moment, I'd prefer to talk about something else." id ep4_11_suetalk_7c318fc5
                show ep4 suetalk_102 with d
                sue "If you say so." id ep4_11_suetalk_6f96eca3
                show ep4 suetalk_103 with d
                sue "You seem really tense and anxious." id ep4_11_suetalk_2b328918
                sue "Do you really have that much going on in that mind of yours?" id ep4_11_suetalk_8d2758eb


                show ep4 suetalk_104 with d
                simon "Yeah, I've got a lot going on involving my dad, Susan, and a few other people." id ep4_11_suetalk_6e59c038
                show ep4 suetalk_105 with d
                sue "Hmm. Look at you self-reflecting." id ep4_11_suetalk_b4233382
                sue "I thought men let their helmet heads do all the thinking." id ep4_11_suetalk_65ef8050
                show ep4 suetalk_106 with d
                simon "We only think about sex ninety percent of the time." id ep4_11_suetalk_f6256e85
                simon "The other ten percent is devoted to other matters." id ep4_11_suetalk_a40edb08
                show ep4 suetalk_107 with d
                sue "Is that so?"
                show ep4 suetalk_097 with d
                sue "And what if I do this?" id ep4_11_suetalk_fcea311f
                sue "Where does your mind go?" id ep4_11_suetalk_25627c2a

                menu:
                    "The ninety percent (Sex)"(True):
                        $ ep4_suetalk_90 = True
                        $ player_choice("ep4_suetalk_90:true")
                        jump ep4_12_suesex
                    "The ten percent (Other matters)":

                        $ ep4_suetalk_10 = True
                        $ player_choice("ep4_suetalk_10:true")
                        pass






        show ep4 suetalk_108 with d
        simon "Sorry, Sue." id ep4_11_suetalk_dd15d0a8
        simon "My mind went somewhere else for a moment." id ep4_11_suetalk_77454ce0
        show ep4 suetalk_109 with d
        sue "Oh? Somewhere serious?" id ep4_11_suetalk_02be0302
        show ep4 suetalk_110 with d
        simon "Yeah. You're not the only one with family issues." id ep4_11_suetalk_73ed5bf1
        show ep4 suetalk_111 with d
        sue "What happened to your father anyway?" id ep4_11_suetalk_7aa3ae51
        show ep4 suetalk_112 with d
        simon "That's the question I've been asking myself these past few years." id ep4_11_suetalk_e03a4023
        show ep4 suetalk_113 with d
        sue "Right..." id ep4_11_suetalk_4efb860e
        show ep4 suetalk_114 with d
        sue "I think we're both obsessed over our father figures." id ep4_11_suetalk_97ecd5b6
        stop sound fadeout 5
        show ep4 suetalk_115 with d
        simon "You're probably the only person who really gets me." id ep4_11_suetalk_a00a9c4c
        show ep4 suetalk_116 with d
        sue "I guess so." id ep4_11_suetalk_49115de0
        show ep4 suetalk_117 with d
        simon "You know... you can be pretty sweet when you want to be." id ep4_11_suetalk_a05e0491
        stop music
        play sound hitting_leather
        show ep4 suetalk_118 with hpunch
        simon "Ouch!" id ep4_11_suetalk_2e4f777a
        show ep4 suetalk_119 with d
        simon "Why'd you have to go and do that?!" id ep4_11_suetalk_4620d423
        show ep4 suetalk_120 with d
        sue "Dumbass." id ep4_11_suetalk_259f29a7
        play sound door_car
        show ep4 suetalk_121 with d
        simon "Ouch..." id ep4_11_suetalk_9b8dc3ec
        play sound door_car2
        show ep4 suetalk_122 with d
        sue "Come on. I'll take you back." id ep4_11_suetalk_4dc284fc
        show ep4 suetalk_123 with d
        simon "Ah, right!" id ep4_11_suetalk_2543e950
        show ep4 suetalk_124 with wipedown
        simon "Thanks for that, by the way." id ep4_11_suetalk_cb904609
    else:

        show ep4 suetalk_125 with long_fade
        simon "(That sure ended well.)" id ep4_11_suetalk_c2a74671
        play music game_changer_2 volume 0.45
        play sound engine volume 0.5 
        show ep4 suetalk_126 with None
        simon "What the — ?" id ep4_11_suetalk_73c82f91
        play sound car_fast volume 0.5
        show ep4 suetalk_127 with None
        pause 1.5

        show ep4 suetalk_128 with vpunch
        stop sound fadeout 3
        sue "Asshole!" id ep4_11_suetalk_3c67c94b
        show ep4 suetalk_129 with d
        simon "What the fuck...?" id ep4_11_suetalk_09a34dcf
        show ep4 suetalk_130 with d
        simon "(She's insane!)" id ep4_11_suetalk_75014743
        stop music fadeout 3
        show ep4 suetalk_131 with d
        simon "(Goddamn. What a giant waste of time.)" id ep4_11_suetalk_a177b46a
        simon "(At least it's still early.)" id ep4_11_suetalk_d457dafd
        show ep4 suetalk_132 with long_fade
        simon "(I hope this day gets a whole lot better.)" id ep4_11_suetalk_cedb8b3c
        show ep4 suetalk_133 with fade
        simon "(At least I'll get to campus early.)" id ep4_11_suetalk_2271fda3

    jump ep4_13_hometoschool
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
