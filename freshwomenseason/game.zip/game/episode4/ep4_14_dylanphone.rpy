
label ep4_14_dylanphone:

    show ep4 dylanphone_001 with d
    simon "(She got pretty serious at the end there.)" id ep4_14_dylanphone_7693d1df
    show ep4 dylanphone_002 with d
    simon "(I hope everything's going all right on her end.)" id ep4_14_dylanphone_24b50e27
    show ep4 dylanphone_003 with d
    simon "(Well, I guess I should go get changed.)" id ep4_14_dylanphone_6c8a11d9
    show ep4 dylanphone_004 with d
    simon "(I should be able to get ready with time to spare.)" id ep4_14_dylanphone_58da2ccb
    play sound shower fadein 2
    show ep4 dylanphone_005 with wipeleft

    simon "(Maybe I should get to campus quickly and find out more about the dorms.)" id ep4_14_dylanphone_f0a52d14

    stop sound fadeout 1
    play sound_2 dress_shirt
    show ep4 dylanphone_006 with wipeleft
    simon "(I need to find a place to stay as soon as possible.)" id ep4_14_dylanphone_ae2fe552
    stop music fadeout 2
    play sound cell_phone_vibrate volume 0.5
    show ep4 dylanphone_007 with d
    simon "(Maybe I could check in with...)" id ep4_14_dylanphone_1585f721
    show ep4 dylanphone_008 with d
    simon "Huh?" id ep4_14_dylanphone_196da51b
    stop sound fadeout 2
    show ep4 dylanphone_009 with d
    simon "Hey, Dylan." id ep4_14_dylanphone_6610dafe
    show ep4 dylanphone_013 with d
    dylan "Bro! You've been MIA for the last twenty-four hours!" (what_italic=True)
    dylan "What happened?" (what_italic=True)
    show ep4 dylanphone_011 with d
    simon "Well... a lot, honestly." id ep4_14_dylanphone_6249dd62
    show ep4 dylanphone_012 with d
    simon "I'll tell you when I get to campus." id ep4_14_dylanphone_31a5ea7d
    show ep4 dylanphone_010 with d
    dylan "No, sir. You'll tell me right now." (what_italic=True)
    show ep4 dylanphone_013 with d
    dylan "Come on down." id ep4_14_dylanphone_304f6402
    show ep4 dylanphone_014 with d
    simon "What do you mean?" id ep4_14_dylanphone_181107cc
    show ep4 dylanphone_015 with d
    simon "Are you, by chance...?" id ep4_14_dylanphone_95bbc96d
    show ep4 dylanphone_016 with d
    simon "Dylan, please tell me that isn't you." id ep4_14_dylanphone_eaf49a49
    play music outside_st_petersburg fadein 3 volume 0.3
    show ep4 dylanphone_017 with None
    dylan "Who else would it be?" id ep4_14_dylanphone_c8b8b544
    show ep4 dylanphone_018 with d
    simon "My god, Dylan." (what_italic=True)
    show ep4 dylanphone_019 with d
    dylan "Hurry up!" id ep4_14_dylanphone_7f2bb44b
    dylan "Or do you not want to travel in style?" id ep4_14_dylanphone_2ae0a9c0

    menu:
        "I want style"(True):
            $ ep4_dylanphone_i_want_style = True
            $ player_choice("ep4_dylanphone_i_want_style:true")
            $ points_dylan += 1
            show ep4 dylanphone_020 with d
            simon "Okay, you convinced me." id ep4_14_dylanphone_99578af3
            simon "If we're going to do this, let's travel in style." id ep4_14_dylanphone_e4570018
            show ep4 dylanphone_021 with d
            dylan "That's what I'm talking about!" (what_italic=True)
            show ep4 dylanphone_028_1 with d
            dylan "Bro!"
        "I want normalcy":


            $ ep4_dylanphone_i_want_normalcy = True
            $ player_choice("ep4_dylanphone_i_want_normalcy:true")
            show ep4 dylanphone_022 with d
            simon "Man, I just want to get to class." id ep4_14_dylanphone_64674e28
            simon "Nothing flashy." id ep4_14_dylanphone_10294428
            show ep4 dylanphone_023 with d
            dylan "Bro, sometimes you hurt my feelings." (what_italic=True)
            show ep4 dylanphone_024 with d
            simon "Damn it, Dylan..." id ep4_14_dylanphone_2fc2c4d5
            show ep4 dylanphone_025 with d
            dylan "But, all right." (what_italic=True)
            dylan "We'll do it your way." (what_italic=True)
            dylan "I'll come in through the less crowded parking lot." (what_italic=True)
            dylan "Like an ordinary person." (what_italic=True)
            show ep4 dylanphone_026 with d
            simon "Like an ordinary person? As opposed to?" id ep4_14_dylanphone_ca4c5d14
            show ep4 dylanphone_027 with d
            dylan "I guess you'll never know." (what_italic=True)
            show ep4 dylanphone_028 with d
            dylan "Bro!"




    show ep4 dylanphone_029 with d
    simon "Just one more thing..." id ep4_14_dylanphone_18e27c09
    show ep4 dylanphone_030 with d
    simon "Why are you wearing that?" id ep4_14_dylanphone_f7c1f2b1
    show ep4 dylanphone_031 with d
    simon "And where do you get all these different vehicles from?" id ep4_14_dylanphone_569694e4
    show ep4 dylanphone_032 with d
    dylan "Technically, those were two things you just asked." id ep4_14_dylanphone_c4a25388
    show ep4 dylanphone_033 with d
    dylan "But, I mean, how else would people know I'm Russian?" id ep4_14_dylanphone_16b420e3
    show ep4 dylanphone_034 with d
    simon "But you're not..." id ep4_14_dylanphone_d397d0b1


    show ep4 dylanphone_035 with d
    simon "Never mind." id ep4_14_dylanphone_675085d1


    if choice_made('ep4_dylanphone_i_want_style'):
        show ep4 dylanphone_036 with d
        dylan "Oh, I almost forgot." id ep4_14_dylanphone_39222794
        show ep4 dylanphone_037 with d
        dylan "I've got one for you too." id ep4_14_dylanphone_3b6c0e0f
        show ep4 dylanphone_038 with d
        simon "Wait. I don't want to pretend to be Russian." id ep4_14_dylanphone_b8b4c604
        show ep4 dylanphone_039 with d
        dylan "It's okay, man." id ep4_14_dylanphone_98c7009f
        dylan "You're my friend." id ep4_14_dylanphone_e85b3def
        dylan "So it's totally not cultural appropriation." id ep4_14_dylanphone_ae2d3248
        show ep4 dylanphone_040 with d
        simon "That's not how that wor —" id ep4_14_dylanphone_2bc732c6
        show ep4 dylanphone_041 with d
        simon "Never mind. Just give me the hat." id ep4_14_dylanphone_7fb0af8b
        show ep4 dylanphone_042 with d
        dylan "That's the spirit, bro!" id ep4_14_dylanphone_fd14ce31
        play sound jeep_start_idle volume 0.5 
        show ep4 dylanphone_043 with d
        dylan "Come on!"
        show ep4 dylanphone_044 with vpunch
        simon "Whoa!" id ep4_14_dylanphone_88bc8af3
        show ep4 dylanphone_045 with d
        dylan "Hold onto your hat, cowboy!" id ep4_14_dylanphone_c57fa5f1
        show ep4 dylanphone_046 with d
        simon "Yeah, I almost lost it there!" id ep4_14_dylanphone_1ad3f3d1
        stop sound fadeout 2
        show ep4 dylanphone_047 with d
        dylan "Everything's fine now." id ep4_14_dylanphone_0fb679e0
        dylan "I'll take it from here." id ep4_14_dylanphone_cc187c8a
        stop music fadeout 2
    else:


        play sound jeep_start_away volume 0.5
        show ep4 dylanphone_048 with d
        dylan "Come on!"
        show ep4 dylanphone_049 with vpunch
        simon "Not again!" id ep4_14_dylanphone_b8a3e3cc
        stop sound fadeout 2
        show ep4 dylanphone_050 with d
        dylan "You should have gotten used to this by now, bro!" id ep4_14_dylanphone_5b77cc0b
        stop music fadeout 2

    $ debug_other_path()
    pause
    jump ep4_15_dylancar
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
