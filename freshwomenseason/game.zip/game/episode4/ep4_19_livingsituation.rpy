
label ep4_19_livingsituation:

show ep4 livingsituation_001 with long_fade
play music stay_lost_with_me fadein 2 volume 0.4
simon "(This place is so nice.)" id ep4_19_livingsituation_bea09d90
show ep4 livingsituation_002 with d
simon "(I wonder how the ball is going to look.)" id ep4_19_livingsituation_4e448e70
show ep4 livingsituation_003 with d
simon "(Will anyone recognize me there?)" id ep4_19_livingsituation_1a7bf02f
simon "(The son of the man being honored?)" id ep4_19_livingsituation_52aeceea
show ep4 livingsituation_004 with d
simon "(No. I bet they won't even mention my father's name.)" id ep4_19_livingsituation_6889177a
show ep4 livingsituation_005 with d
alyssa "[name]?" id ep4_19_livingsituation_54f26c95
show ep4 livingsituation_006 with d
simon "Oh. What's up?" id ep4_19_livingsituation_b547cfb8
show ep4 livingsituation_007 with d
alyssa "Blink." id ep4_19_livingsituation_c801aff0
show ep4 livingsituation_008 with d
alyssa "You were so focused you forgot to blink." id ep4_19_livingsituation_3036488a
show ep4 livingsituation_009 with d
simon "Hmm. I didn't even notice." id ep4_19_livingsituation_cf01c83e
show ep4 livingsituation_010 with d
alyssa "Speaking of focus... how's the housing situation going to go?" id ep4_19_livingsituation_834ba6c0
alyssa "Have you decided where you're going to spend the night?" id ep4_19_livingsituation_0f4f5106
show ep4 livingsituation_011 with d
simon "(Yeah. I think it's time I made an actual decision.)" id ep4_19_livingsituation_3c85b9f9

menu:
    "Here"(True) if choice_made_skip_debug('ep4_alyssa_invite') or config.developer:
        $ ep4_livingsituation_here = True
        $ player_choice("ep4_livingsituation_here:true")
        show ep4 livingsituation_012 with d
        simon "I thought about what you said, and I think I'll stay here — if it's not too much trouble." id ep4_19_livingsituation_59444bb5
        show ep4 livingsituation_013 with d
        alyssa "No, none at all!" id ep4_19_livingsituation_f8afb50b
        alyssa "It'll be great to have someone to talk to." id ep4_19_livingsituation_07b21a6a
        show ep4 livingsituation_014 with d
        simon "Wait, are you staying here too?" id ep4_19_livingsituation_922baac9
        show ep4 livingsituation_015 with d
        alyssa "Yeah. I took tomorrow off so I could use the morning to practice." id ep4_19_livingsituation_3404427b

        alyssa "I hope you don't mind waking up early." id ep4_19_livingsituation_4ab20b73
        show ep4 livingsituation_017 with d
        simon "Not at all." id ep4_19_livingsituation_ab0a3a63
        simon "Thank you, Alyssa." id ep4_19_livingsituation_81435a97
        show ep4 livingsituation_018 with d
        simon "Since it's not too late, I should stop by my place and grab my stuff." id ep4_19_livingsituation_af8e20c0
        show ep4 livingsituation_019 with d
        alyssa "Oh, right. You do that." id ep4_19_livingsituation_fcfe4af2
        alyssa "I'll tidy up here in the meantime." id ep4_19_livingsituation_7cab94d9
        show ep4 livingsituation_020 with d
        alyssa "See you soon, [name]!" id ep4_19_livingsituation_792ee84d

    "Julia"(True) if choice_made_skip_debug('ep4_julia_invite') or config.developer:
        $ ep4_livingsituation_julia = True
        $ player_choice("ep4_livingsituation_julia:true")
        show ep4 livingsituation_021 with d
        simon "I'm staying at a friend's house, but only until I find somewhere more permanent."
        show ep4 livingsituation_022 with d
        alyssa "That's great! Glad you found somewhere to stay!"

        show ep4 livingsituation_018 with d
        simon "Speaking of which, I should get going."
        show ep4 livingsituation_019 with d
        alyssa "Of course."
        show ep4 livingsituation_020 with d
        alyssa "See you later, [name]!"

    "Chloe"(True) if choice_made_skip_debug('ep4_chloe_invite') or config.developer:
        $ ep4_livingsituation_chloe = True
        $ player_choice("ep4_livingsituation_chloe:true")
        show ep4 livingsituation_021 with d
        simon "I'm staying at a friend's house, but only until I find somewhere more permanent."
        show ep4 livingsituation_022 with d
        alyssa "That's great! Glad you found somewhere to stay!"

        show ep4 livingsituation_018 with d
        simon "Speaking of which, I should get going."
        show ep4 livingsituation_019 with d
        alyssa "Of course."
        show ep4 livingsituation_020 with d
        alyssa "See you later, [name]!"

    "Sue"(True) if choice_made_skip_debug('ep4_sue_invite') or config.developer:
        $ ep4_livingsituation_sue = True
        $ player_choice("ep4_livingsituation_sue:true")
        show ep4 livingsituation_021 with d
        simon "I'm staying at a friend's house, but only until I find somewhere more permanent."
        show ep4 livingsituation_022 with d
        alyssa "That's great! Glad you found somewhere to stay!"

        show ep4 livingsituation_018 with d
        simon "Speaking of which, I should get going."
        show ep4 livingsituation_019 with d
        alyssa "Of course."
        show ep4 livingsituation_020 with d
        alyssa "See you later, [name]!"
    "Dylan"(True):

        $ ep4_livingsituation_dylan = True
        $ player_choice("ep4_livingsituation_dylan:true")
        show ep4 livingsituation_023 with d
        simon "Do you remember that Russian friend of mine?" id ep4_19_livingsituation_cbd927b4
        show ep4 livingsituation_024 with d
        alyssa "Of course. The gentleman!" id ep4_19_livingsituation_463759de
        show ep4 livingsituation_025 with d
        simon "Yeah... That's him alright." id ep4_19_livingsituation_bcdfd2ba
        show ep4 livingsituation_026 with d
        simon "I'm going to stay at his house." id ep4_19_livingsituation_52d3b497
        simon "He's a good friend." id ep4_19_livingsituation_7927d6f2
        show ep4 livingsituation_027 with d
        alyssa "I'm glad you're already making so many friends!" id ep4_19_livingsituation_833f18e8

        show ep4 livingsituation_018 with d
        simon "Speaking of which, I should get going."
        show ep4 livingsituation_019 with d
        alyssa "Of course."
        show ep4 livingsituation_020 with d
        alyssa "See you later, [name]!"



$ debug_other_path()

jump ep4_20_homelasttime
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
