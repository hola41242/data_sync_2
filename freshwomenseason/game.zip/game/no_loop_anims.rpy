init -2000 python:
    no_loop_anims = [
        "ep6 anim_15fps",
        "ep3 anim_sat_chloesex_037",
        "ep4 anim_emilyvisit_192",
        "ep4 anim_emilyvisit_192_var1",
        "ep4 anim_emilyvisit_144_1",
        "ep4 anim_suesex_137",
        "ep4 anim_suesex_137_var1",
        "ep5 anim_gabbysex_049",
        "ep5 anim_gabbysex_046",
        "ep5 anim_gabbysex_052",
        "ep5 anim_lilysex_038",
        "ep5 anim_lilysex_074"
        "ep7 anim_hellsangels_001",
        "ep6 anim_nursesex_052",
        "ep6 anim_nursesex_038",
        "ep6 anim_nursesex_033",
        "ep6 anim_nursesex_055_var1",
        "ep6 anim_chloesex_024",
        "ep7 anim_gabbysex_038",
    ]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
