init:
    $ rewards_link_to_gallery = {}
    default ep1_fr_viewed_events = {}
    default current_screen = None

    $ ep1_fr_collected_rewards = {
        'ep1_fr_bh_multi_smallbathroom' : False,
        'ep1_fr_bh_multi_storage': False,
        'ep1_fr_bh_multi_piano':False,
        'ep1_fr_bh_multi_kitchen':False,
        'ep1_fr_bh_multi_bedroom': False,
        'ep1_fr_bh_multi_outside': False,
        'ep1_fr_bh_multi_suitcaseroom':False
    }

init 42 python:
    import random   
    num_rewards_found = 0

    _reward_index = 0
    for screen_name, value in ep1_fr_collected_rewards.iteritems():
        rewards_link_to_gallery[screen_name] = _reward_index
        if str(_reward_index) in persistent.gallery_unlock:
            ep1_fr_collected_rewards[screen_name] = True
        
        _reward_index += 1


    def ep1_bh_queue_musics(randomize = True):
        music_list = [audio.at_dawn, audio.giants_were_here, audio.one_chance]
        if randomize:
            random.shuffle(music_list)
        
        renpy.music.stop(fadeout = 2)
        renpy.music.queue(music_list, loop = True, tight = True, fadein = 1)

    def call_next_screen():
        renpy.block_rollback()
        renpy.transition(config.intra_transition)
        renpy.call_screen(current_screen)

    def collect_reward():
        global num_rewards_found
        renpy.block_rollback()
        ep1_fr_collected_rewards[current_screen] = True
        renpy.show(get_scene_base_image())
        renpy.transition(config.intra_transition)   
        
        if persistent.gallery_unlock and len(persistent.gallery_unlock) >= 1:            
            renpy.notify(_("Reward Unlocked!"))
        else:
            renpy.say(None, _("You've found a reward!"))
            renpy.say(None, _("Rewards are special renders hidden in certain areas when you have free roam."))
            renpy.show ('phone_pointer')
            renpy.transition(config.intra_transition)   
            renpy.say(None, _("You can check them out on your phone's gallery app."))
            renpy.hide ('phone_pointer')
            renpy.transition(config.intra_transition)   
        
        
        
        reward_index = rewards_link_to_gallery[current_screen]
        persistent.gallery_unlock.append(str(reward_index))
        
        renpy.call_screen(current_screen)  

    def get_screen_idle_name():
        return images_root + "ep1/fr/bh/" + get_scene_base_image() + '.webp'
    def get_screen_hover_name():
        return images_root + "ep1/fr/bh/" + current_screen.replace('ep1_', 'ep1 ') + "_hover.webp"    
    def get_reward_button_name():
        return images_root + "ep1/fr/bh/" + current_screen.replace('ep1_', 'ep1 ').replace('multi','reward') + "_%s.webp"

    def screen_has_reward():        
        return (current_screen in ep1_fr_collected_rewards 
        and ep1_fr_collected_rewards[current_screen] == False
        and not str(rewards_link_to_gallery[current_screen]) in persistent.gallery_unlock)


    def get_scene_base_image():
        render_name = current_screen.replace('ep1_', 'ep1 ') 
        if screen_has_reward():            
            render_name += '_reward'
        else:
            render_name += '_idle'
        
        return render_name

    def enter_room_event(event_name):
        renpy.block_rollback()
        if is_event_new(event_name):
            start_event(event_name)

    def is_event_new(event_name):
        return not event_name in ep1_fr_viewed_events

    def move_to(new_screen):
        global current_screen
        current_screen = new_screen   
        
        renpy.transition(config.intra_transition)
        renpy.show(get_scene_base_image())
        renpy.call(new_screen)

    @renpy.pure
    class MoveTo(Action, DictEquality):       
        args = None
        def __init__(self, screen, *args, **kwargs):
            self.screen = screen
            self.args = args
            self.kwargs = kwargs
        
        def predict(self):
            renpy.predict_screen(self.screen, *self.args, **self.kwargs)
        
        def __call__(self):
            move_to(self.screen) 


    @renpy.pure
    class CollectReward(Action, DictEquality):       
        args = None
        def __init__(self, *args, **kwargs):            
            self.args = args
            self.kwargs = kwargs
        
        def __call__(self):
            renpy.call('collect_reward_label')


    event_label = None
    @renpy.pure
    class StartEvent(Action, DictEquality):       
        args = None
        def __init__(self, event):            
            self.event = event
        
        def __call__(self):            
            start_event(self.event)

    def start_event(new_event):
        global event_label
        event_label = new_event
        renpy.call('start_event_label')   


label collect_reward_label:
    $ collect_reward()

label start_event_label:
    $ renpy.block_rollback()
    $ renpy.call(event_label)
    $ ep1_fr_viewed_events[event_label] = True
    $ renpy.block_rollback()
    $ renpy.show(get_scene_base_image())
    $ renpy.transition(config.intra_transition)
    $ renpy.call_screen(current_screen)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
