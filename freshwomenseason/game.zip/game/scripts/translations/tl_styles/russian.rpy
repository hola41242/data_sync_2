translate russian python:
    set_russian_fonts()

init python:
    def set_russian_fonts():
        set_text_font_and_choice(font_noto_sans, 0.9)
        set_name_text_font(font_evolve_sans)
        set_main_menu_font(font_evolve_sans)
        set_button_and_interface_font(font_evolve_sans)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
