translate thai python:
    set_thai_fonts()

init python:
    def set_thai_fonts():
        set_text_font_and_choice(font_noto_sans_thai)
        set_name_text_font(font_noto_sans_thai)
        set_main_menu_font(font_noto_sans_thai)
        set_button_and_interface_font(font_noto_sans_thai)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
