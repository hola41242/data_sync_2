translate czech python:
    set_czech_fonts()

init python:
    def set_czech_fonts():
        set_text_font_and_choice(font_applied_sans)
        set_name_text_font(font_evolve_sans)
        set_main_menu_font(font_evolve_sans)
        set_button_and_interface_font(font_applied_sans)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
