init -1001 python:

    gui_initial_state = {}
    font_cabin_regular = 'gui/font/cabin-regular.ttf'
    font_myrlissa = 'gui/font/Myrlissa.otf'
    font_evolve_sans = 'gui/font/Evolve Sans Medium.otf'
    font_noto_sans = 'gui/font/NotoSans-Regular.ttf'
    font_source_hans_CN = 'gui/font/SourceHanSansCN-Medium.otf'

    def source_hans_override(f):
        return font_source_hans_CN

    font_noto_sans_thai = 'gui/font/NotoSansThai-Medium.ttf'
    def noto_sans_thai_override(f):
        return font_noto_sans_thai

    def noto_sans_kr_override(f):
        return font_noto_sans_kr_bold


    config.font_transforms["schinese"] = source_hans_override
    config.font_transforms["tchinese"] = source_hans_override
    config.font_transforms["japanese"] = source_hans_override
    config.font_transforms["korean"] = noto_sans_kr_override
    config.font_transforms["thai"] = noto_sans_thai_override


    font_dejavu_sans = "DejaVuSans.ttf"
    font_college_block = "gui/font/College Block.otf"
    font_applied_sans = 'gui/font/AppliedSansProRg.ttf'

    font_noto_sans_kr_bold = 'gui/font/NotoSansKR-Bold.otf'

    def set_text_font_and_choice(font, size_multiplier=1.0):
        gui.text_font = font
        gui.choice_button_text_font = font
        
        gui.text_size = round(gui_initial_state['text_size'] * size_multiplier)

    def set_button_and_interface_font(font):
        gui.interface_font = font
        gui.interface_text_font = font
        gui.button_text_font = font
        gui.input_text_font = font
        gui.label_text_font = font
        gui.prompt_text_font = font
        gui.hyperlink_text_font = font
        
        if _preferences.language in ['schinese', 'tchinese', 'thai', 'japanese', 'korean']:
            preferences.font_transform = _preferences.language
        else:
            preferences.font_transform = None


    def set_name_text_font(font, size=50):
        gui.name_text_font = font
        if renpy.variant('small'):
            size = round(size*1.3)
        gui.name_text_size = size

    def set_main_menu_font(font):
        gui.main_menu_button_font = font



    def dejavu_sans_override(f):
        if _preferences.language in ['schinese', 'tchinese', 'japanese']:
            return font_source_hans_CN
        elif _preferences.language in ['korean']:
            return font_noto_sans_kr_bold
        elif _preferences.language in ['czech']:
            return font_applied_sans
        elif _preferences.language in ['polish']:
            return font_applied_sans
        elif _preferences.language in ['russian']:
            return font_evolve_sans
        elif _preferences.language in ['thai']:
            return font_noto_sans_thai
        elif _preferences.language in ['turkish']:
            return font_evolve_sans
        elif _preferences.language in ['french', 'german', 'italian', 'portuguese', None]:
            return font_evolve_sans
        else:
            return font_evolve_sans

    def remove_fonts():
        if ('schinese' not in valid_languages
        and 'tchinese' not in valid_languages
        and 'japanese' not in valid_languages):
            build.classify('game/{}'.format(font_source_hans_CN), None)
        
        if 'korean' not in valid_languages:
            build.classify('game/{}'.format(font_noto_sans_kr_bold), None)
        
        if 'russian' not in valid_languages:
            build.classify('game/{}'.format(font_noto_sans), None)
        
        if ('czech' not in valid_languages
        and 'polish' not in valid_languages):
            build.classify('game/{}'.format(font_applied_sans), None)

    config.font_transforms["dejavusans"] = dejavu_sans_override
    config.font_transforms["opendyslexic"] = dejavu_sans_override
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
