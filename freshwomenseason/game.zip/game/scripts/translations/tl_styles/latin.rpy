translate None python:
    set_latin_fonts()

translate french python:
    set_latin_fonts()

translate italian python:
    set_latin_fonts()

translate german python:
    set_latin_fonts()

translate portuguese python:
    set_latin_fonts()

translate eportuguese python:
    set_latin_fonts()

translate spanish python:
    set_latin_fonts()

translate latam python:
    set_latin_fonts()

init python:
    def set_latin_fonts():
        set_text_font_and_choice(font_cabin_regular)
        set_name_text_font(font_myrlissa, 85)
        set_main_menu_font(font_college_block)
        set_button_and_interface_font(font_evolve_sans)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
