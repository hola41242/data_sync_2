translate korean python:
    set_korean_fonts()

init python:
    def set_korean_fonts():
        set_text_font_and_choice(font_noto_sans_kr_bold)
        set_name_text_font(font_noto_sans_kr_bold)
        set_main_menu_font(font_noto_sans_kr_bold)
        set_button_and_interface_font(font_noto_sans_kr_bold)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
