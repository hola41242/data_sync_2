translate japanese python:
    set_schinese_fonts()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
