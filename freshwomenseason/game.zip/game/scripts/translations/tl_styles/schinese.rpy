translate schinese python:
    set_schinese_fonts()

init python:
    def set_schinese_fonts():
        set_text_font_and_choice(font_source_hans_CN)
        set_name_text_font(font_source_hans_CN)
        set_main_menu_font(font_source_hans_CN)
        set_button_and_interface_font(font_source_hans_CN)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
