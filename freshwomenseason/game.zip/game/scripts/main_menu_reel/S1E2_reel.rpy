image main_menu_screenshots_A_S1E2:
    "ep2 fri_game_home_julia_ghosts"
    main_menu_zoom_in
    main_menu_wait_5
    "ep2 fri_storage_h_sue_what"
    main_menu_zoom_in
    main_menu_wait_5
    repeat

image main_menu_screenshots_B_S1E2:
    main_menu_wait_5
    "ep2 thu_chloehome_chloe_up_silent"
    main_menu_zoom_in
    main_menu_wait_5
    "ep2 thu_dance_students_dance3"
    main_menu_zoom_in
    repeat



init python:
    global main_menu_logo_path
    main_menu_logo_path['S1E2'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
