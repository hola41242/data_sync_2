image main_menu_screenshots_A_S1E3:
    "ep3 sat_challenge_142"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_cafe2_012"
    main_menu_zoom_in
    main_menu_wait_5
    repeat

image main_menu_screenshots_B_S1E3:
    main_menu_wait_5
    "ep3 sat_chloetalk_017"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_susanlily_036"
    main_menu_zoom_in
    repeat



init python:
    global main_menu_logo_path
    main_menu_logo_path['S1E3'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
