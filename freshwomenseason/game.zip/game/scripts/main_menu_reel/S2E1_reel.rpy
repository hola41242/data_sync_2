image main_menu_screenshots_A_S2E1:
    "ep6 callingchloe_014"
    main_menu_zoom_in
    main_menu_wait_5
    "ep6 meetingchloe_024"
    main_menu_zoom_in
    main_menu_wait_5
    "ep6 sam_043"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S2E1:
    main_menu_wait_5
    "ep6 chloesex_009"
    main_menu_zoom_in
    main_menu_wait_5
    "ep6 deadend_027"
    main_menu_zoom_in
    main_menu_wait_5
    "ep6 thenurse_004"
    main_menu_zoom_in
    repeat

init python:
    global main_menu_logo_path
    main_menu_logo_path['S2E1'] = "gui/main/freshwomen_logo_season_2_episode_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
