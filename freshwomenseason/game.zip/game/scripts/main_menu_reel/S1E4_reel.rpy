image main_menu_screenshots_A_S1E4:
    "ep4 susanhome_006"
    main_menu_zoom_in
    main_menu_wait_5
    "ep4 alyssasex_209"
    main_menu_zoom_in
    main_menu_wait_5
    repeat

image main_menu_screenshots_B_S1E4:
    main_menu_wait_5
    "ep4 suesex_006"
    main_menu_zoom_in
    main_menu_wait_5
    "ep4 juliaphone_018"
    main_menu_zoom_in
    repeat



init python:
    global main_menu_logo_path
    main_menu_logo_path['S1E4'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
