image main_menu_screenshots_A_S1:
    "ep3 sat_chloesex_008"
    main_menu_zoom_in
    main_menu_wait_5
    "ep4 alyssasex_005"
    main_menu_zoom_in
    main_menu_wait_5
    "ep4 julialunch_053"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_challenge_003_2"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 mon_simonhome_neighbor_emily_know"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_susanlily_038"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S1:
    main_menu_wait_5
    "ep1 mon_simonhome_m_lily_itsfine"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 wed_beach_sue_badass"
    main_menu_zoom_in
    main_menu_wait_5
    "ep5 gabbyclass_004"
    main_menu_zoom_in
    main_menu_wait_5
    "ep4 dream_018"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_challenge_141"
    main_menu_zoom_in
    main_menu_wait_5
    "ep3 sat_dylan_bike_023"
    main_menu_zoom_in
    repeat


init python:
    global main_menu_logo_path
    main_menu_logo_path['S1'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
