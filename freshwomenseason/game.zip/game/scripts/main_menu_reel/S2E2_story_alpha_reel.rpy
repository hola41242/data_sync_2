image main_menu_screenshots_A_S2E2_story_alpha:
    "ep7 gabbysex_086"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 funwithgabby_033"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 newplace_076"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S2E2_story_alpha:
    main_menu_wait_5
    "ep7 gettingcaught_021"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 chores_a_017"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 gabbysex_102"
    main_menu_zoom_in
    repeat


init python:
    global main_menu_logo_path
    main_menu_logo_path['S2E2_story_alpha'] = "gui/main/freshwomen_logo_season_2_episode_2.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
