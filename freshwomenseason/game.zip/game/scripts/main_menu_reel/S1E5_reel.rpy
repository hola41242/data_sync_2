image main_menu_screenshots_A_S1E5:
    "ep5 gabbysex_016"
    main_menu_zoom_in
    main_menu_wait_5
    "ep5 juliaday_018"
    main_menu_zoom_in
    main_menu_wait_5
    repeat

image main_menu_screenshots_B_S1E5:
    main_menu_wait_5
    "ep5 lilysex_011_1"
    main_menu_zoom_in
    main_menu_wait_5
    "ep5 fratparty_014"
    main_menu_zoom_in
    repeat



init python:
    global main_menu_logo_path
    main_menu_logo_path['S1E5'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
