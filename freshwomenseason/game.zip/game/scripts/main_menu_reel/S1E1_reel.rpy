image main_menu_screenshots_A_S1E1:
    "ep1 mon_arcade_julia_play_talks_reg"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 mon_cafe_alyssa_happy_out"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 mon_simonhome_neighbor_emily_know"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S1E1:
    main_menu_wait_5
    "ep1 mon_simonhome_m_lily_itsfine"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 wed_beach_sue_badass"
    main_menu_zoom_in
    main_menu_wait_5
    "ep1 mon_bookstore_chloe_isback"
    main_menu_zoom_in
    repeat



init python:
    global main_menu_logo_path
    main_menu_logo_path['S1E1'] = "gui/main/freshwomen_logo_season_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
