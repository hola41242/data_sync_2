image main_menu_screenshots_A_S2E2P1:
    "ep7 aftergabby_012"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 funwithgabby_026"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 resolution_023"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S2E2P1:
    main_menu_wait_5
    "ep7 funwithgabby_033"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 thedelivery_001_3"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 gabbysex_117"
    main_menu_zoom_in
    repeat

init python:
    global main_menu_logo_path
    main_menu_logo_path['S2E2P1'] = "gui/main/freshwomen_logo_season_2_episode_2_part_1.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
