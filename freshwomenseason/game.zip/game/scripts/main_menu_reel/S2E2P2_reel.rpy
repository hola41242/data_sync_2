image main_menu_screenshots_A_S2E2P2:
    "ep7 newplace_088"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 chores_056"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 wingman_050"
    main_menu_zoom_in
    main_menu_wait_5
    repeat
image main_menu_screenshots_B_S2E2P2:
    main_menu_wait_5
    "ep7 chores_041"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 wingman_051"
    main_menu_zoom_in
    main_menu_wait_5
    "ep7 newplace_064"
    main_menu_zoom_in
    repeat

init python:
    global main_menu_logo_path
    main_menu_logo_path['S2E2P2'] = "gui/main/freshwomen_logo_season_2_episode_2_part_2.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
