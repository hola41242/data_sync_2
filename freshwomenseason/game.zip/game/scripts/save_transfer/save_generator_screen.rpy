screen girl_button(girl):
    default height_int = 270
    default width_int = 213
    frame:
        maximum width_int, height_int
        padding 0, 0
        background Solid( "#00000000" )

        if girl in girls_selected:
            add "gui/save_generator/" + girl + "_hover.webp" fit "contain"
            add "gui/save_generator/checked.webp" fit "contain"
        else:
            add "gui/save_generator/" + girl + "_idle.webp" fit "contain"
            add "gui/save_generator/not_checked.webp" fit "contain"

        imagebutton auto 'gui/save_generator/border_%s.webp':
            action Function(toggle_girl_selected, girl)
            selected girl in girls_selected

        label _(girl.title()):
            align (0.5, 0.95)



screen save_generator_screen():
    zorder 100
    add "gui/save_generator/save_generator_background.png"
    $ chars_per_row = 5


    vbox:
        align 0.5, 0.05
        spacing 10
        text _("Select who you're in good terms with") xalign 0.5
        text _("Sexual Interest in:") style "generate_choices_description" xalign 0.5

        for index in range(len(available_girls)):
            if index % chars_per_row == 0:
                hbox:
                    align (0.5, (0.22 + (0.25 * (index/chars_per_row))))
                    spacing 20
                    for girl_idx in range(index, index + chars_per_row):
                        if girl_idx < len(available_girls):
                            $ girl = sorted(available_girls)[girl_idx]
                            use girl_button(girl)

    vbox:
        align 0.5, 0.96
        text _("Friendship with:") style "generate_choices_description" xalign 0.5
        hbox:
            align 0.5, 1
            spacing 20
            use girl_button('dylan')







    hbox:
        align 0.05, 0.99
        textbutton "Return" style "generate_choices_button":
            action Return()


    hbox:
        align 0.95, 0.99
        textbutton _("START SEASON 2") style "generate_choices_button":
            action Function(start_season_2_generated)

style generate_choices_button_text is text:
    color "#fba0af"
    hover_color "#ffffff"
    font gui.main_menu_button_font
    size gui.main_menu_button_font_size
    hover_size (gui.main_menu_button_font_size + 5)
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]

style generate_choices_description is text:
    color "#ffffff"
    font gui.main_menu_button_font
    size 40
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
