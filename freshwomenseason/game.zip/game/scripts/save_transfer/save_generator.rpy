init python:
    available_girls = ['julia', 'alyssa', 'chloe', 'lily', 'sue', 'susan', 'emily', 'devilla', 'angela', 'gabby']
    girls_selected = ['julia', 'alyssa', 'chloe', 'lily', 'sue', 'susan', 'emily', 'devilla', 'angela', 'gabby', 'dylan']

    positive_variables_of_girls = {
        'chloe': {
            'points_chloe': 8,
            'ep1_bookshelf_you': True,
            'you_like_fiction': True,
            'ep1_chloe_susan': True,
            'ep2_chloe_gooddetective': True,
            'ep2_dictionarygirl': True,
            'ep2_chlow_knowsabout_sue_search': True,
            'ep3_06_cafe_tell_the_truth': True,
            'ep3_08_bookstore_good_idea': True,
            'ep3_sat_vanbear_i_hope_so': True,
            'ep3_sat_susanlily_open_the_lid': True,
            'ep3_sat_chloesex_continue': True,
            'ep3_sat_chloesex_remove_clothes': True,
            'ep3_chloetalk_no': True
        },
        'julia': {
            'points_julia': 9,
            'ep1_win_arcade': True,
            'ep1_hangout_julia': True,
            'ep2_more_than_friends': True,
            'ep2_julia_glitch': True,
            'ep2_julia_glitch_2': False,
            'ep2_julia_kiss': True,
            'ep4_julialunch_kiss_julia': True,
            'ep5_juliaroof_we_will': True
        },
        'lily': {
            'points_lily': 6,
            'ep1_pantson': False,
            'lily_husband': True,
            'callsher_lily': True,
            'ep1_accept_tea': True,
            'wine_lily': True,
            'drank_wine': True,
            'ep5_lilyhome_to_stay': True,
            'ep5_lilyhome_i_want_to': True
        },
        'sue': {
            'points_sue': 10,
            'ep1_tried_talk_sue': True,
            'ep1_told_sue_magazine': True,
            'ep1_agree_help_sue': True,
            'ep2_sue_hug': True,
            'ep2_sue_stop': False,
            'ep2_sue_takeiteasy': False,
            'ep4_suetalk_so_lets_go': True,
            'ep4_sue_invite': True,
            'ep4_suetalk_yea': True,
            'ep4_suesex_slap_her_ass': True
        },
        'susan': {
            'points_susan': 3,
            'ep3_the_ride_tell_her_the_truth': True,
            'ep4_susanhome_tell_the_truth': True,
            'ep4_susanhome_i_was_spying_on_you': True,
            'ep4_susanhome_no': True,
            'ep4_susanhome_accept_the_job': True,
        },
        'dylan': {
            'points_dylan': 5,
            'join_bookclub': True,
            'let_dylan_help': True,
            'ep3_station_defend_dylan': True,
            'ep4_dylanphone_i_want_style': True,
            'ep4_livingsituation_dylan': True,
            'ep5_beerpong_miss_the_ball_on_purpose': True,
            'ep5_universityclass_defend_dylan' : True,
        },
        'alyssa': {
            'points_alyssa': 9,
            'alyssa_cafe_dance_joke': True,
            'ep1_cafe_americano': True,
            'ep1_compliment_alyssa': True,
            'ep1_shirt_off_alyssa': True,
            'ep1_joindance': True,
            'ep2_alyssa_kiss': True,
            'ep3_06_cafe_accept': True,
            'ep3_07_cafe2_agree_to_help': True,
            'ep3_07_cafe2_hug_her_tighter': True,
            'ep4_alyssasex_take_the_step': True,
            
            'ep1_fr_bh_multi_smallbathroom' : True,
            'ep1_fr_bh_multi_storage': True,
            'ep1_fr_bh_multi_piano':True,
            'ep1_fr_bh_multi_kitchen':True,
            'ep1_fr_bh_multi_bedroom': True,
            'ep1_fr_bh_multi_outside': True,
            'ep1_fr_bh_multi_suitcaseroom': True
        },
        'emily': {
            'points_emily': 1,
            'ep1_peek_emily': True,
            'ep4_emilyvisit_agree_with_emily': True,
            'ep4_hometoschool_test_the_key': True
        },
        'mae': {
            'ep1_mae_sex': True,
            'ep5_chase_dont_go_with_mae': True
        },
        'angela': {
            'red_drink': False,
            'ep3_04_challenge_surrender_to_angela': False,
            'ep3_04_challenge_survive_angela': True,
            'ep3_04_challenge_won': True,
            'ep3_04_challenge_fuck_both': True
        },
        'devilla': {
            'ep3_04_challenge_surrender_to_devilla': False,
            'ep3_04_challenge_resist_some_more': True,
            'ep5_angels_ask_devilla_for_help': True
        },
        'sam': {
            'ep4_lunch_shake_his_hand': True,
            'ep4_lunch2_its_you_who_is_shit': True,
            'ep5_blackout_release_sam': True
        },
        'debra': {
            'ep4_phonemom_yes_but': True
        },
        'watson': {
            'ep5_universityclass_world_economy': True,
            'ep5_universityclass_defend_dylan': True
        },
        'gabby': {
            'ep5_gabbyclass_talk_to_gabby': True,
            'ep5_gabbyclass_ready': True
        }
    }

    def set_positive_relationship(girl):
        for var_name, var_value in positive_variables_of_girls[girl].items():
            globals()[var_name] = var_value

    def start_season_2_generated():
        for girl in girls_selected:
            set_positive_relationship(girl)
        
        
        renpy.jump('ep6_01_goodfather')

    def toggle_girl_selected(girl):
        global girls_selected
        if girl in girls_selected:
            girls_selected.remove(girl)
        else:
            girls_selected.append(girl)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
