init -1 python:
    help_data = {
        "title": ("""Having problems with the game? Read this"""),
        "intro_1": ("""Please read through the post to find help with the most common issues."""),
        "if_your_issue_isnt_listed": ("""If your issue isn’t listed here, please post a report in the bug reports forum."""),
        "discord_click_black_boxes": ("""Click the black squares to reveal the answer."""),
        "verify_integrity": ("""If you run into any error, the first thing you should try is to verify the game cache.
Try the following steps:

1. Right-click the game in your library
2. Select Properties > Local files > Verify integrity of game files

Steam will download any missing files.

Relaunch the game and see if the problem persists."""),
        "problem_1": ("""I don’t see any animations when I play the game. I only see a black screen."""),
        "solution_1": ("""The game needs an audio device enabled to play animations. Enable output for sound and try playing the game again."""),
        "problem_2": ("""I tried to mod/cheat, and now my game doesn’t work."""),
        "solution_2": ("""Mods and cheats aren’t supported and will break your game. Delete everything in the installation folder and install the game from scratch to fix it. Your save files may break from modifying the game as well."""),
        "problem_3_pc": ("""I want to delete my save files; how do I do it?"""),
        "solution_3_pc": ("""When playing, open the save menu, hover any save, and press the delete key to delete saves."""),
        "problem_4_pc": ("""My game is stuttering/lagging; how can I fix it?"""),
        "solution_4_pc": ("""There are several ways to fix this. Try the following and see if anything works for you.
1. Make sure that G-sync is turned off. If you have an NVIDIA GPU, you can turn it off in the NVIDIA control panel. Make sure that your monitor’s refresh rate is set correctly from here as well.
2. While playing, press Shift+G and test the different render options to see if the stuttering is reduced. If it fails, revert the setting to \"Choose automatically\".
3. Try playing the game in windowed mode and reduce the window size. If the stutter disappears, your device specifications might be too low to get rid of the stuttering."""),
        "problem_5_pc": ("""My game is crashing due to memory errors; how can I fix it?"""),
        "solution_5_pc": ("""Try playing the game in windowed mode and reduce the window size. If the game doesn’t crash, your PC specifications might be too low to play fullscreen. If it still crashes, post a bug report with the error code in the bug reports forum."""),
        "problem_6_pc": ("""The upper left corner displays a text message that says “NO DC”. How do I remove it?"""),
        "solution_6_pc": ("""Open NVIDIA control panel. Go to Manage 3d settings and change \"Threaded Optimization\" to \"Auto\"."""),
        "problem_7_pc": ("""I’m having issues saving/loading the game, getting errors like \"NameError: name 'some name' is not defined\"."""),
        "solution_7_pc": ("""We’ve seen this issue happen for players with an excessive amount of saves (>50 pages of saves, and maybe even less).
At some point, Ren’Py struggles to handle saving/loading depending on CPU. The solution is to delete save files until the issue goes away.
Hover saves in the save/load menu and press the Delete button to remove them."""),
        "problem_8": ("""Where are my saves located?"""),
        "solution_8_pc": ("""Windows: %APPDATA%/RenPy/FreshWomen-1593632962
Mac: ~/Library/RenPy/FreshWomen-1593632962
Linux: ~/.renpy/FreshWomen-1593632962"""),
        "problem_9_android": ("""I can't install the APK or ZIP"""),
        "solution_9_android": ("""Try unzipping the file with ZArchiver"""),
        "question_not_listed": ("""My question isn't listed here; what do I do?"""),
        "question_not_listed_answer_1_pc": ("""Post your question in our Steam Forum"""),
        "question_not_listed_answer_2": ("""Post your question in our Discord Server (English Only)"""),
        "refund_question": ("""I want my money back; how to I request a refund?"""),
        "refund_answer": ("""Click this link to request a refund:"""),
        "refund_request": ("""If you want a refund, click here."""),
        "goodbye": ("""Cheers,
Oppai-Man"""),
    }
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
