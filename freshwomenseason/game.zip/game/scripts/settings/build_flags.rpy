
define config.image_cache_size_mb = 600
define config.auto_voice = "audio/voice/{episode}/{scene}/{id}.opus"
define config.default_music_volume = 0.4
init -2001 python:

    release_version = True
    compressed_version = False
    img_resolutions = [1080]
    video_resolutions = [720, 1080]
    config.steam_appid = None
    oppai_version = 'Season 1 Full HD (470)'
    version_name = 'Season 1'
    config.debug = False
    full_episodes = [1, 2, 3, 4, 5]
    partial_episodes = {}
    valid_languages = ['english', 'french', 'german', 'italian', 'polish', 'czech', 'portuguese', 'russian', 'spanish', 'schinese', 'tchinese', 'japanese', 'korean', 'thai', 'turkish']
    platforms = ['pc', 'mac']
    is_demo = ""
    audio_folder_path = "audio/music/{}.opus"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
