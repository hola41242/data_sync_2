init -100 python:


    mutable_characters =  [
        {'name': 'Alyssa', 'voice_tags': ['a', 'alyssa']},
        {'name': 'Angela', 'voice_tags': ['angela']},
        {'name': 'Carolyne', 'voice_tags': ['carolyne', 'nurse',]},
        {'name': 'Charlie', 'voice_tags': ['charlie']},
        {'name': 'Chery', 'voice_tags': ['chery']},
        {'name': 'Chloe', 'voice_tags': ['c', 'unknown_chloe', 'chloe']},
        {'name': 'Donna', 'voice_tags': ['donna']},
        {'name': _('Debra'), 'voice_tags': ['mother']},
        {'name': 'Devilla', 'voice_tags': ['devilla']},
        {'name': 'Dylan', 'voice_tags': ['dy', 'dylan']},
        {'name': 'Emily', 'voice_tags': ['n', 'emily', 'ep1_dreams_girl']},
        {'name': 'Fred', 'voice_tags': ['fred', 'deliveryman', 'father', 'man']},
        {'name': 'Gabby', 'voice_tags': ['gabby', 'student_uni_female']},
        {'name': _('Janine'), 'voice_tags': ['ep1_clerk']},
        {'name': 'Jessa', 'voice_tags': ['jessa']},
        {'name': 'Julia', 'voice_tags': ['j', 'julia']},
        {'name': 'Lily', 'voice_tags': ['l', 'lily']},
        {'name': 'Mae', 'voice_tags': ['customer', 'old_customer', 'woman_customer']},
        {'name': 'Ms. Watson', 'voice_tags': ['watson', 'professor']}, 
        {'name': 'Susan', 'voice_tags': ['s', 'susan']},
        {'name': 'Sue', 'voice_tags': ['sue', 'sue_secret', 'ep1_clothestore_girl']},
        {'name': 'Sam', 'voice_tags': ['sam', 'mr_alderson']},
        {'name': _('Other Male'), 'voice_tags': ["bad_man", "arthur", "male_professor", "reporter", "prof_nelson", "jason", "student_uni_male",
        "student_dance_male", "tyler", "security", "officer", "policeman", "cop", "janitor", "boy", "ep1_busstop_man", "dean", "bruce", "alfredo"]},
        {'name': _('Other Female'), 'voice_tags': ["student_dance_female", "woman", "aluna", "girl2", "girl1", "girls", "waitress", 
        "student_uni_female", "librarian", "clerk", "female_voice_at_phone", "secretary", "heather", "juliamon", "claire"]},
    ]



    def mute_character(character):
        for voice_tag in character["voice_tags"]:
            
            
            
            
            if not voice_tag in persistent._voice_mute:
                persistent._voice_mute.add(voice_tag)
            else:
                persistent._voice_mute.remove(voice_tag)


    def get_name_with_status(character):
        char_name = character["name"]
        if character["voice_tags"][0] in persistent._voice_mute:
            return _t(char_name) + ' ' + _("MUTED")
        else:
            return char_name
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
