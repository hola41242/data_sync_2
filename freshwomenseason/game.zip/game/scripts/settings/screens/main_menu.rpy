

transform main_menu_zoom_in:
    parallel:
        xcenter 0.5
        subpixel True
        linear 6 zoom 1.1
    parallel:
        ease 2 alpha 1

transform main_menu_wait_5:
    parallel:
        linear 1 zoom 1.117

    parallel:
        ease 2 alpha 0
        pause 2
        zoom 1

    parallel:
        pause 6

transform main_menu_logo_fade_out:
    pause 10
    ease 2 alpha 0


style main_menu_textbutton_text:
    color "#fba0af"
    hover_color "#ffffff"
    font gui.main_menu_button_font
    size gui.main_menu_button_font_size
    hover_size (gui.main_menu_button_font_size + 10)
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]


style main_menu_textbutton_text_green:
    color "#30f730"
    hover_color "#d7ffd9"
    font gui.main_menu_button_font
    size (gui.main_menu_button_font_size - 20)
    hover_size (gui.main_menu_button_font_size - 10)
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]


style main_menu_textbutton_text_blue:
    color "#11e2f5"
    hover_color "#ffffff"
    font gui.main_menu_button_font
    size gui.main_menu_button_font_size
    hover_size (gui.main_menu_button_font_size + 10)
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]

style main_menu_subtitle_text:
    color "#ede6e7"

    font gui.main_menu_button_font
    size round(gui.main_menu_button_font_size*0.6)
    hover_size round((gui.main_menu_button_font_size + 10)*0.6)
    outlines [ (absolute(4), "#000000", absolute(0), absolute(1)),
                (absolute(4), "#250038", absolute(0), absolute(7)) ]

screen main_menu():
    tag menu
    variant "fast_demo"
    add "images/zweb/ep6/chloesex/ep6 chloesex_007.webp"
    timer 0.001 action Start('ep6_16_chloesex')


screen main_menu():
    tag menu
    style_prefix "main_menu"
    key "alt_shift_K_j" action Start('chapter_selector')

    $ active_reel = 'S1'
    if check_if_next_rpy_is_built('ep7_08_chores.rpy'):
        $ active_reel = 'S2E2P2'
    elif check_if_next_rpy_is_built('ep7_01_resolution.rpy'):
        $ active_reel = 'S2E2P1'
    elif full_episodes == [1, 2, 3, 4, 5, 6]:
        $ active_reel = 'S2E1'
    elif full_episodes == [1, 2, 3, 4, 5]:
        $ active_reel = 'S1'
    elif check_if_next_rpy_is_built('ep5_01_intro.rpy'):
        $ active_reel = 'S1E5'
    elif check_if_next_rpy_is_built('ep4_01_lucnh2.rpy'):
        $ active_reel = 'S1E4'
    elif check_if_next_rpy_is_built('ep3_01_the_ride.rpy'):
        $ active_reel = 'S1E3'
    elif check_if_next_rpy_is_built('ep2_01_the_station.rpy'):
        $ active_reel = 'S1E2'
    elif full_episodes == [1]:
        $ active_reel = 'S1E1'

    add "main_menu_screenshots_B_{}".format(active_reel)
    add "main_menu_screenshots_A_{}".format(active_reel)


    if is_debug_mode() and release_version:
        frame:
            padding 40, 20
            align 0.5, 0.65
            text _("Hey! You're in Developer Mode!")
            text _("This can happen if you're using mods, altered the game in any way, or are a part of the dev-team.")
        frame:
            padding 40, 20
            align 0.5, 0.8
            textbutton _("CLICK TO DISABLE DEBUG MODE") action Function(disable_debug_mode)

    $ main_menu_left_side = 340
    $ main_menu_first_button = 650
    $ main_menu_spacing = 80 if not renpy.variant('small') else  95


    add main_menu_logo_path[active_reel]:
        pos main_menu_left_side, 300
        anchor 0.5, 0.5


    if enable_chapter_selector or 6 in full_episodes:
        textbutton _("NEW GAME"):
            pos main_menu_left_side, main_menu_first_button
            anchor 0.5, 0.5
            action ShowMenu('new_game_screen')
            text_style "main_menu_textbutton_text"
    else:
        textbutton _("NEW GAME"):
            pos main_menu_left_side, main_menu_first_button
            anchor 0.5, 0.5
            action Start()
            text_style "main_menu_textbutton_text"


    textbutton _("CONTINUE"):
        pos main_menu_left_side, main_menu_first_button + main_menu_spacing
        anchor 0.5, 0.5
        action ShowMenu("load")
        text_style "main_menu_textbutton_text"

    textbutton _("OPTIONS"):
        anchor 0.5, 0.5
        pos main_menu_left_side, main_menu_first_button + main_menu_spacing * 2
        action ShowMenu("preferences")
        text_style "main_menu_textbutton_text"


    if not is_demo and renpy.seen_image('ep5 finale_lily'):
        textbutton _("NEXT EPISODE NOTIFICATION"):
            anchor 0, 0.99
            pos 30, 1070
            action OpenURL("https://oppai-man.com/next-episode-notification/")
            text_style "main_menu_textbutton_text"


    vbox:
        pos 1880, 1080/2
        spacing 30
        align 0.99, 0.5

        if patreon_cta in ctas or config.developer:
            imagebutton auto main_menu_gui_button('patreon'):
                action OpenURL(my_own_platform_url)
                xalign 0.999

        if (steam_acquisition_cta in ctas or config.developer):
            imagebutton auto main_menu_gui_button('steam'):
                action Function(steam_acquisition_action)
                xalign 0.999

        if (steam_retention_cta in ctas or config.developer) and renpy.seen_image('ep5 finale_lily'):
            imagebutton auto main_menu_gui_button('steam'):
                action Function(steam_retention_action)
                xalign 0.999

        if itch_cta in ctas or config.developer:
            imagebutton auto main_menu_gui_button('itch'):
                action OpenURL("http://oppai.me/freshwomen-itch")
                xalign 0.999

        if discord_cta in ctas or config.developer:
            imagebutton auto main_menu_gui_button('discord'):
                action OpenURL("https://discord.gg/oppaiman")
                xalign 0.999

        if email_cta in ctas or config.developer:
            imagebutton auto main_menu_gui_button('newsletter'):
                action OpenURL("http://oppai.me/4k-images")
                xalign 0.999




    text "[oppai_version]":
        pos 1880, 1040
        align 0.99, 0.99
        font gui.interface_text_font
        size 20
        color gui.accent_color
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
