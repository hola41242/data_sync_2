
default went_mall = False
default went_bookstore = False
default went_cafe = False
default went_games = False


default connections_lilysusan = False
default connections_mraldersonsusan = False


default points_lily = 0
default points_julia = 0
default points_alyssa = 0
default points_chloe = 0
default points_dylan = 0
default points_susan = 0
default points_sue = 0
default points_emily = 0
default points_sam = 0


default ep1_cafe_americano = False
default alyssa_cafe_dance_joke = False
default ep1_joindance = False
default ep1_compliment_alyssa = False
default ep1_shirt_off_alyssa = False
default ep2_alyssa_kiss = False


default ep1_win_arcade = False
default ep1_hangout_julia = False
default ep2_more_than_friends = False
default ep2_julia_glitch = False
default ep2_julia_glitch_2 = False
default ep2_julia_kiss = False


default took_susan_photo = True
default saw_susan_photo = False


default callsher_lily = False
default wine_lily = False
default drank_wine = False
default lily_husband = False
default ep1_accept_tea = False
default ep1_pantson = False
default ep2_lily_no_pants = False


default let_dylan_help = False
default you_like_fiction = False
default join_bookclub = False
default ep1_bookshelf_you = False
default ep1_chloe_susan = False
default ep1_you_like_books = True
default ep1_chloe_sue = False
default ep2_chlow_knowsabout_sue_search = False
default ep2_chloe_gooddetective = False
default ep2_dictionarygirl = False


default ep1_tried_talk_sue = False
default ep1_agree_help_sue = False
default ep1_said_hi_sue = False
default ep1_told_sue_magazine = False
default ep2_sue_stop = False
default ep2_sue_sex = False
default ep2_sue_dominated = False
default ep2_sue_takeiteasy = False
default ep2_sue_hug = False


default ep2_dylan_knowsabout_lily = False
default red_drink = False
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
