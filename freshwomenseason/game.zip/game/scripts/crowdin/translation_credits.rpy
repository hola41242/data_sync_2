
define -15 top_translators = {
    'tchinese': ["FrEeZe (FrEeZe66501)"],
    None: ["Pulse333"],
    'thai': ["THE PKUBSO", "nabank-TH", "Jupiter Cute", "Phobias (sk8mzzbk)"],
    'korean': ["Seunghee Seong", "이상화 (yippee7942)", "그린Tea (Hoit_626)", "REMOVED_USER", "BUMMY (nightmare460)"],
    'eportuguese': ["David Luís"],
    'schinese': ["Albert 'Windyshine' Chen"],
    'italian': ["RedStarITA", "Trhasm", "FeelIrie"],
    'japanese': ["Sunjaco", "Mary \"hoja83\" Misaki", "PeaceKeeper_Jackson"],
    'russian': ["KOTA3"],
    'czech': ["vaxicek", "HonzaCZ"],
    'turkish': ["Zonagh", "cenkxxxxx"],
    'french': ["Meteion", "Kuu1147"],
    'german': ["BigPaul87", "PitzonXD"],
    'polish': ["Pivoltus Rex", "dUMPLINGbOI", "Patriot77"],
    'spanish': ["Lamasutra", "MidnightLux", "NotCook1e"],
    'portuguese': ["Heathens", "Gomyde", "TsundereWriter"],
}
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
