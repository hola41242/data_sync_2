
default persistent.gallery_unlock = []

init python:
    g = Gallery()

    gui_root = 'gui/'
    images_root = img_root

    g.locked_button = gui_root + 'gallery/locked_button.webp'
    g.hover_border = gui_root +'gallery/hover_border.webp'
    g.idle_border = gui_root +'gallery/idle_border.webp'
    g.transition = dissolve

    gallery_renders = [
        'ep1/alyssa/rewards_ep1_alyssa_1.webp', 
        'ep1/alyssa/rewards_ep1_alyssa_2.webp', 
        'ep1/alyssa/rewards_ep1_alyssa_3.webp', 
        'ep1/alyssa/rewards_ep1_alyssa_4.webp',
        'ep1/alyssa/rewards_ep1_alyssa_5.webp',
        'ep1/alyssa/rewards_ep1_alyssa_6.webp',
        'ep1/alyssa/rewards_ep1_alyssa_7.webp'
    ] 

    gallery_thumbnails = [ ] 







    for i in range(0, len(gallery_renders)):
        g.button(str(i))
        g.image(images_root + "rewards/" + gallery_renders[i])
        g.condition("'{}' in persistent.gallery_unlock".format(str(i)))
        thumbnail = images_root + "rewards/" + gallery_renders[i].replace('.webp','_thumb.webp')
        gallery_thumbnails.append(thumbnail)



screen gallery_alyssa():
    zorder 101
    add "rewards_ep1_alyssa_2"
    add "gui/black_fade.webp"
    add "gui/black_fade.webp"
    add "gui/black_fade.webp"
    label _("Alyssa's Gallery"):
        pos 60, 60
        text_size 40


    modal True
    viewport id "chloe_v":


        xmaximum 1800
        ymaximum 800
        yalign 0.5
        xalign 0.5

        has grid 4 2
        style_prefix "gallery_stuff"
        for i in range(0, 8):
            if i < len(gallery_renders):
                add g.make_button(str(i), gallery_thumbnails[i])
            else:
                null

    textbutton _("Return"):
        style "return_button"
        action Hide('gallery_alyssa', dissolve)
        xalign 0.03
        yalign 0.88



style gallery_stuff_grid:
    xalign 0.5
    yalign 0.5
    xspacing 20
    yspacing 20


style gallery_stuff_hbox:
    xalign 0.5
    yanchor 0.9
    ypos 0.95
    xspacing 10
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
