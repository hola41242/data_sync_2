
screen awards():
    tag menu
    $ award_manager.check_new_awards()
    use game_menu("Gallery"):
        vpgrid:
            xfill True
            cols 4
            spacing 15
            mousewheel True
            draggable True
            scrollbars "vertical"

            for award in award_manager.replay_awards:
                use award(award.title, award.task, award.image, award.unlock_str, award.unlocked, award.replay, award.btn_action, award.song)


            for i in range((4 - (len(award_manager.replay_awards) %4))%4):
                null

            $ second_section_count = 0
            if 1 in full_episodes:
                $ second_section_count += 1
                use alyssa_gallery_btn(_("Alyssa's Gallery"), persistent.gallery_unlock)

            for award in award_manager.image_awards:
                if not award.hidden or award.unlocked:
                    use award(award.title, award.task, award.image, award.unlock_str, award.unlocked, award.replay, award.btn_action, award.song)


                    $ second_section_count += 1

            if award_manager.hidden_count() or config.developer:
                use award("", _t(_("Hidden memories remaining:")) + " " + str(award_manager.hidden_count()), 'gui/awards/locked_button.webp', None, False, None, NullAction, None)


                $ second_section_count +=1

            for i in range((4 - (second_section_count %4))%4):
                null


screen award(title, task, image_url, fullscreen_url, unlocked, replay, btn_action, song):
    default height_int = 200
    default width_int = round(height_int * 16/9)
    frame:
        maximum width_int, height_int
        padding 0, 0

        add image_url fit 'contain'


        default border = 'gui/awards/border_%s.webp' if isinstance(replay, str) else 'gui/awards/border2_%s.webp'
        if not isinstance(replay, str) and song:
            imagebutton auto border action [mr.Play(song), Function(btn_action)] at zoom89 sensitive unlocked
        else:
            imagebutton auto border action Function(btn_action) at zoom89 sensitive unlocked
        text task:
            size 23
            pos 10, (height_int - 5)
            anchor 0.0, 0.99
            font gui.interface_text_font

        if unlocked:
            text title:
                size 23
                pos 10, 10
                font gui.interface_text_font

        if isinstance(replay, str):
            add 'gui/awards/film.png' xpos (width_int - 35) ypos 35 anchor (0.5, 0.5)


screen alyssa_gallery_btn(title, unlocked):
    default height_int = 200
    default width_int = round(height_int * 16/9)
    frame:
        maximum width_int, height_int
        padding 0, 0

        default image_url = 'rewards_ep1_alyssa_7' if unlocked else 'gui/awards/locked_button.webp'
        add image_url fit 'contain'

        imagebutton auto 'gui/awards/border2_%s.webp':
            action Show("gallery_alyssa", dissolve)
            at zoom89
            sensitive unlocked

        text title:
            size 25
            pos 10, 10
            font gui.interface_text_font
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
