label ep_credits:

    scene black

    with d

    show game_gui_logo with d

    pause 2

    hide game_gui_logo with d

    show cred at Move((0.5, credits_y_position), (0.5, 0.0), credits_stringpeed, repeat=False, bounce=False, xanchor="center", yanchor="bottom")
    with d

    show gui_credits_julia as girl at right with credits_dissolve
    show gui_credits_lily as girl at left with credits_dissolve
    show gui_credits_chloe2 as girl at right with credits_dissolve
    show gui_credits_emily as girl at left with credits_dissolve
    show gui_credits_alyssa as girl at right with credits_dissolve
    show gui_credits_sue as girl at left with credits_dissolve
    show gui_credits_susan as girl at right with credits_dissolve
    hide girl with long_dissolve

    hide cred with d




init python:
    def size_tag(size):
        return "{size=" + str(size) + "}"

    def convert_cred_dict_to_string(cred_dict, font_size):
        string = ''
        for title, name_list in cred_dict.items():
            string += '\n{color=#fa9fae}' + size_tag(font_size)  +  _t(title) + '{/color}{/size}\n'
            for cred_name in name_list:
                string += size_tag(font_size) + cred_name + "{/size}\n"
        
        return string

    credits_string = convert_cred_dict_to_string(main_credits_dict, 45)
    credits_y_position = credits_string.count('\n') * 55.0/1080.0
    music_credits_string = convert_cred_dict_to_string(music_by_credits, 40)
    credits_string += music_credits_string

    credits_y_position += music_credits_string.count('\n') * 50.0/1080.0

    credits_y_position += 1





init:
    image cred = Text(credits_string, text_align=0.5)



define credits_stringpeed = 80
define num_girls = 7
define delay_between_girls = credits_stringpeed/(num_girls)
define credits_dissolve = MultipleTransition([
    False, Dissolve(1.5),
    True, Pause(delay_between_girls-1.5),
    True])
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
