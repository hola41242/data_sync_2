define itch_io_id = 'freshwomen'
define f95_thread_url = 'https://f95zone.to/threads/freshwomen-ep-5-beta-oppai-man.79740/'
define dik_games_url = 'https://dikgames.com/freshwomen/'
define lewd_zone_url = 'https://lewdzone.com/game/freshwomen/'
define itch_io_url = 'http://oppai.me/freshwomen-itch'
define my_own_platform_url = 'https://www.freshwomen.net/'
define steam_acquisition_announcement_url = 'https://steamcommunity.com/games/1350650/announcements/detail/3376028523046117230'
define steam_game_id = '1350650'
define discord_url = 'https://discord.gg/oppaiman'
define newsletter_subscribe_url = 'http://oppai.me/4k-images'
define create_crowdin_account = 'http://oppai.me/freshwomen-crowdin-invite'
define discord_translation_community = 'https://discord.gg/7Abenm8sV7'
define protagonist_default_name = 'Simon'
define config.name = "FreshWomen"
define build.name = "FreshWomen"
define config.version = ""
define build.version = ""

define main_menu_music_volume = 0.5
define config.main_menu_music = "gui/audio/hit_the_ground_running.ogg"

define config.save_directory = "FreshWomen-1593632962"

define has_walkthrough_pdf = True













define -3 gui.accent_color = '#fa9fae'

define -3 gui.idle_color = '#888888'



define -3 gui.idle_small_color = '#aaaaaa'


define -3 gui.hover_color = '#ff5571'




define -3 gui.selected_color = '#ffffff'


define -3 gui.insensitive_color = '#8888887f'



define -3 gui.muted_color = '#512800'
define -3 gui.hover_muted_color = '#7a3d00'


define -3 gui.text_color = '#FADB8A'
define -3 gui.interface_text_color = '#ffffff'
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
