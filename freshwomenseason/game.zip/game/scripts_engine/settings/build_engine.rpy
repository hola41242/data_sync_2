
define config.has_sound = True
define config.has_music = True
define config.has_voice = True

define config.menu_include_disabled = True


default preferences.text_cps = 0
default preferences.afm_time = 17.7

define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.intra_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = None
define config.window = None
define config.window_show_transition = None
define config.window_hide_transition = None

define config.default_sfx_volume = 1
define config.default_voice_volume = 1

default preferences.gl_powersave = 'auto'
define config.enable_language_autodetect = True
define build.include_i686 = False

define config.window_icon = "gui/window_icon.png"

init -1 python:
    main_menu_logo_path = {}


init python:
    renpy.music.register_channel("sound_2", "sfx", loop=False)
    renpy.music.register_channel("sound_3", "sfx", loop=False)
    renpy.music.register_channel("sound_4", "sfx", loop=False)

    renpy.music.register_channel("music_2", "music", loop=True)

    renpy.music.register_channel("foley", "sfx", loop=True)
    renpy.music.register_channel("voicefx", "sfx", loop=True)

init -996 python:
    img_root = "images/" 
    build.destination = 'C:/vn_local_data/renpy_builds'
    def build_archive_and_classify():
        created_archives = []
        for glob_path, archive in archive_content:
            if archive not in created_archives and archive != '':
                build.archive(archive, "all")
                created_archives.append(archive)
            build.classify(glob_path, archive)



    build_archive_and_classify()
    build.classify('game/storyboard/**/**.**', None)
    build.classify('game/audio_wav/**/**.**', None)
    build.classify('utilities/**/**.**', None)
    build.classify('utilities/**/**', None)
    build.classify('game/audio/**/**.pkf', None)
    build.classify('game/tl/*.rpy', None)
    remove_fonts()
    if 'web' in platforms:
        build.classify('game/scripts/crowdin/reverse_tl/*.*', None)
        build.classify('game/python-packages/**.**', None)
        build.classify('game/python-packages/**/**.**', None)
        build.classify('game/**/**.rpy', None)
    build.documentation('*.html')
    build.documentation('*.txt')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
