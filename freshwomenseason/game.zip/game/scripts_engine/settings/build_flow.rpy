define ep6_beta_50 = False
define ep6_full_100 = True
default next_episode_name = 'Season 2'
init -1 python:
    def check_if_next_rpy_is_built(next_rpy):
        
        episode = int(next_rpy[2])
        if episode in full_episodes:
            return True
        
        if episode in partial_episodes:
            for rpy in partial_episodes[episode]:
                if rpy == next_rpy:
                    return True
        
        return False
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
