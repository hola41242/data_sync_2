define gui.text_outlines = [ (absolute(4), "#000000", 0, 0) ]
define gui.dialogue_text_outlines = [ (absolute(4), "#000000", 0, 0) ]
define gui.name_text_outlines = [ (absolute(4), "#000000", 0, 0) ]

default last_show_image = 'Last Show Image'

default name = protagonist_default_name
default persistent.age_gate = None
default name_input_field = ''
default youtuber_mode = False

init -1900 python:
    def is_steam_version():
        return config.steam_appid


init python:
    import time

    if renpy.emscripten:
        preferences.audio_when_unfocused = False
        
        import emscripten
        if emscripten.run_script_int("window.matchMedia('(display-mode: standalone)').matches;"):
            preferences.web_cache_preload = True
        else:
            preferences.web_cache_preload = False

    def restart_game():
        if renpy.emscripten:
            renpy.save_persistent()
            time.sleep(4)
            import emscripten
            print(emscripten.run_script_string('document.location.reload()'))
        
        elif renpy.windows or renpy.macintosh or renpy.linux:
            renpy.utter_restart()
        return False


    def save(var_name):
        globals()[var_name] = True

    def is_label_worth_checking(labl_name):
        for rank0_list in organize_labls.rank0:  
            for rank1_list in rank0_list:
                if labl_name == rank1_list[0]:
                    return True
                
                for j in range(1, len(rank1_list)):  
                    if labl_name == rank1_list[j]:    
                        return True
        
        return False 

    def label_callback(labl_name, abnormal):
        
        
        crowdin_label_callback(labl_name, abnormal)
        
        
        if not is_label_worth_checking(labl_name):
            
            return
        
        award_manager.check_new_awards()




define config.label_callback = label_callback
define config.say_arguments_callback = checkpoint_count

init -2000 python:
    checkpoints_count = 0
    last_checkpoint_count = 0

    def end_game_correctly():
        MainMenu(confirm=False)()

    def show_statement_replace(render_name, at_list=[], layer='master', what=None, zorder=0, tag=None, behind=[],atl=None):
        
        if name and name != protagonist_default_name:
            persistent.name = name
        
        
        crowdin_timer_start(2)
        if config.developer:
            last_show_image = str(render_name[0])
            if len(render_name) > 1:
                last_show_image = last_show_image + ' ' + str(render_name[1])
            renpy.show_screen('debug_screen', last_show_image)
        else:
            renpy.show_screen('debug_screen', '')
        
        renpy.show(render_name, at_list=at_list, layer=layer, what=what, zorder=zorder, tag=tag, behind=behind,atl=atl)

    def pause(seconds):
        crowdin_timer_start(seconds)
        renpy.pause(seconds)

    def on_screen_translation(text, interact=True):
        if not_english():
            narrator(text, interact=interact)

    def not_english():
        return _preferences.language is not None

    def _t(string):
        return renpy.translate_string(string)

default gui_original_state = {}
default yt_shorts_mode = False
init python:
    def validate_mods():
        for mod in ["1mod.rpy",  '1NewCheatMod.rpy']:
            if renpy.loadable(mod):
                renpy.call_screen('mod_alert')
                break

    def main_menu_gui_button(cta):
        android_tag = '' if not renpy.variant('small') else 'android_'
        dynamic_path = "gui/main/{}{}_%s.png".format(android_tag, cta)
        if renpy.exists(dynamic_path):
            return dynamic_path
        else:
            return "gui/main/{}_%s.png".format(cta)

    def toggle_youtuber_mode():
        global youtuber_mode
        youtuber_mode = not youtuber_mode
        if config.developer:
            store.name = 'Oppai-Man'
            persistent.name = 'Oppai-Man'

    def toggle_yt_shorts_mode():
        global yt_shorts_mode
        yt_shorts_mode = not yt_shorts_mode
        if config.developer:
            store.name = 'Oppai-Man'
            persistent.name = 'Oppai-Man'
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
