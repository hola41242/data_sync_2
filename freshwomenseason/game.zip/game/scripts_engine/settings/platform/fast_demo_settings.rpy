init -1 python:

    def set_fast_demo_settings():
        config.main_menu_music = None
        preferences.web_cache_preload = True
        preferences.audio_when_minimized = False 
        preferences.audio_when_unfocused = False 
        config.variants.insert(0, 'fast_demo')
        for delete_key in ['game_menu', 'hide_windows', 'rollback', 'help', 'accessibility', 'rollforward', 'screenshot']:
            config.keymap[delete_key] = [ ]


    master_volume = 1.0
    master_volume_mute = False

    def set_volume(volume):
        global master_volume, master_volume_mute
        master_volume_mute = False
        
        master_volume = volume
        preferences.set_volume('music', master_volume * config.default_music_volume)
        preferences.set_volume('sfx', master_volume)
        preferences.set_volume('voice', master_volume)

    def get_volume():
        return master_volume

    def toggle_mute():
        global master_volume_mute
        master_volume_mute = not master_volume_mute
        if master_volume_mute:
            preferences.set_volume('music', 0.0)
            preferences.set_volume('sfx', 0.0)
            preferences.set_volume('voice', 0.0)
        else:
            preferences.set_volume('music', master_volume * config.default_music_volume)
            preferences.set_volume('sfx', master_volume)
            preferences.set_volume('voice', master_volume)
        
        return master_volume_mute
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
