init -1900 python:

    def is_iOSWeb():
        if renpy.emscripten:
            import emscripten
            res = emscripten.run_script_int('/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.userAgent.indexOf("Mac") != -1 && navigator.maxTouchPoints > 1)')
            return True if res else False
        return False



    def ios_specific_load():
        if is_iOSWeb():
            for res in [2160, 1440, 1080]:
                if res in img_resolutions and len(img_resolutions) > 1:
                    img_resolutions.remove(res)
                
                if res in video_resolutions and len(video_resolutions) > 1:
                    video_resolutions.remove(res)

init python:
    is_iOSWeb_cache = is_iOSWeb()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
