init -2 python:
    allowed_fullscreen = True
    if renpy.emscripten:
        if is_macWeb() or is_iOSWeb() or renpy.variant('small'):
            allowed_fullscreen = False
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
