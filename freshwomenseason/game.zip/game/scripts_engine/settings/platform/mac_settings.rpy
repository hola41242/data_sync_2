init -1900 python:

    def is_macWeb():
        if renpy.emscripten:
            import emscripten
            res = emscripten.run_script_int('/(macintosh|macintel|macppc|mac68k|macos)/.test(navigator.userAgent.toLowerCase());')
            return True if res else False
        return False


init python:
    is_macWeb_cache = is_macWeb()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
