label chapter_selector:
    $ name = 'Pedrinho Silva'
    stop music fadeout 3
    call screen debug_episode
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
