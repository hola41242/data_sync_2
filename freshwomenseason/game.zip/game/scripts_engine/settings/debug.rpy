define config.show = show_statement_replace

default enable_chapter_selector = False
define enable_debug_choices = False
define config.autoreload = False
define config.menu_arguments_callback = debug_menu_arguments_callback
define debug_preferences = False

init -1 python:
    if config.developer and not preferences.get_mute('music'):
        preferences.set_volume('music', 1)
        preferences.set_volume('sfx', 1)
        preferences.set_volume('voice', 1)

    def disable_debug_mode():
        config.developer = False
        config.debug = False
        global enable_chapter_selector
        enable_chapter_selector = False
        global enable_debug_choices
        enable_debug_choices = False

    def is_debug_mode():
        return any([config.developer, config.debug, enable_chapter_selector, enable_debug_choices]) and not youtuber_mode

    def debug_paths(var_name, int_value_required = 0):
        if not config.developer and not enable_debug_choices:
            return 
        
        save_checkpoint(1) 
        if var_name not in globals():
            if int_value_required == 0:
                globals()[var_name] = False
            else:
                globals()[var_name] = 0
        
        narrator("{b}{color=#FFBA01}Consequences of past choices:\n{/color}{/b}" + str(var_name), interact=False)
        change_value = renpy.display_menu([('{color=#08CB2a}Branch A (Yes){/color}', True), ('{color=#8cd3ff}Branch B (No){/color}', False)])
        set_var_value(var_name, change_value, int_value_required)


    def debug_menu():
        if not (config.developer or enable_debug_choices):
            return 
        
        save_checkpoint(2)


    def debug_menu_arguments_callback(*args, **kwargs):
        debug_menu()
        return args, kwargs


    def save_checkpoint(count):        
        renpy.checkpoint(hard=False)
        global checkpoints_count; checkpoints_count = count


    def set_var_value(var_name, is_positive, int_value_required):
        if int_value_required != 0:
            if is_positive:
                globals()[var_name] = int_value_required
            else:
                globals()[var_name] = 0
        else:
            if is_positive:
                globals()[var_name] = True
            else:
                globals()[var_name] = False

    def debug_other_paths():
        debug_other_path()

    def debug_other_path():
        if not is_debug_mode() or _in_replay:
            return
        global last_checkpoint_count; last_checkpoint_count = checkpoints_count
        narrator("{b}{color=#FFBA01}Do you want to try the alternative branch?{/color}{/b}", interact=False)
        if renpy.display_menu([('{color=#08CB2a}Yes{/color}', True), ('{color=#FF0000}No{/color}', False)]):
            renpy.rollback(checkpoints=last_checkpoint_count)   

    def chose(var_string, int_min_requirement = 0):
        return choice_made(var_string, int_min_requirement)

    def chose_skip_debug(var_string, int_min_requirement = 0):       
        return choice_made_skip_debug(var_string, int_min_requirement)

    def chose_finale(var_string, int_min_requirement = 0):       
        return choice_made_skip_debug(var_string, int_min_requirement)

    def choice_made(var_string, int_min_requirement = 0):
        
        
        debug_paths(var_string, int_min_requirement)
        return choice_made_skip_debug(var_string, int_min_requirement)

    def choice_made_skip_debug(var_string, int_min_requirement = 0):
        if not hasattr(renpy.store, var_string):
            return False
        
        if int_min_requirement == 0:
            return getattr(renpy.store, var_string)
        
        return getattr(renpy.store, var_string) >= int_min_requirement


    def update_current_speech_id():
        
        global current_speech_id
        
        if renpy.game.context().translate_identifier is not None:
            current_speech_id = renpy.game.context().translate_identifier
        else:
            current_speech_id = ""
        
        
        if is_debug_mode():
            renpy.show_screen('character_debug_screen', current_speech_id)


    def checkpoint_count(who, interact=True, **kwargs):
        update_current_speech_id()
        
        global checkpoints_count, last_checkpoint_count
        checkpoints_count += 1
        
        return_dict = { "interact" : interact}
        for k, v in kwargs.items():
            return_dict[k] = v
        
        
        return (), return_dict
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
