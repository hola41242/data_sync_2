
define finale_txt1 = ""
define finale_txt2 = ""
define finale_txt3 = ""
define finale_txt4 = ""
define finale_txt5 = ""
define finale_char = ""
define finale_char2 = ""
define finale_color = ""
default add_frame_to_finale = False
screen finale_scr():
    frame:
        if add_frame_to_finale:
            background Solid("#000000BF")
        else:
            background Solid("#00000000")
        minimum (750, 1080)

        vbox:
            ypos 200
            xoffset 30
            xmaximum 700

            spacing 15

            if finale_char2:
                text "{color=[finale_color]}" + _t(finale_char) + " & " +  _t(finale_char2) +"{/color}":
                    font gui.name_text_font
                    size gui.name_text_size
            else:
                text "{color=[finale_color]}" + _t(finale_char) + "{/color}":
                    font gui.name_text_font
                    size gui.name_text_size
            text _t(finale_txt1)
            text _t(finale_txt2)
            text _t(finale_txt3)
            text _t(finale_txt4)
            text _t(finale_txt5)


screen save_your_game(internal_episode_number, marketing_season, marketing_episode, part):

    add "ep{} gui_save_your_game".format(internal_episode_number)
    frame:
        background Solid("#000000BF")
        xmaximum 1920
        ypos 360

        padding 120, 50, 50, 50
        has vbox
        spacing -40
        if marketing_season == 1:
            if config.name == 'FreshWomen':

                text _t(_("END OF EPISODE [marketing_episode]")):
                    size 130
                    font gui.main_menu_button_font
                    outlines [ (absolute(5), "#000000", absolute(0), absolute(1)),
                            (absolute(5), "#250038", absolute(0), absolute(7)) ]

            elif config.name == "Forbidden Fantasy":

                text _t(_("END OF CHAPTER [marketing_episode]")):
                    size 130
                    font gui.main_menu_button_font
                    outlines [ (absolute(5), "#000000", absolute(0), absolute(1)),
                            (absolute(5), "#250038", absolute(0), absolute(7)) ]

        elif part:
            text _t(_("End of Season [marketing_season] Episode [marketing_episode] Part [part]")):
                size 110
                font gui.main_menu_button_font
                outlines [ (absolute(5), "#000000", absolute(0), absolute(1)),
                        (absolute(5), "#250038", absolute(0), absolute(7)) ]

        else:
            text _t(_("End of Season [marketing_season] Episode [marketing_episode]")):
                size 130
                font gui.main_menu_button_font
                outlines [ (absolute(5), "#000000", absolute(0), absolute(1)),
                        (absolute(5), "#250038", absolute(0), absolute(7)) ]

        text _t(_("Save your game now.")):
            size 60
            outlines []


init python:
    def set_finale_chars(char1, char2=''):
        global finale_char; global finale_char2
        finale_char = char1
        finale_char2 = char2



init python:
    def set_finale_chars(char1, char2=''):
        global finale_char; global finale_char2
        finale_char = char1
        finale_char2 = char2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
