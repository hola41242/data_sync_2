default persistent.img_resolution = 0


init -1899 python:

    active_img_resolution = 0

    min_height_to_activate_resolution={
        720: 0,
        1080: 900,
        1440: 1200,
        2160: 1700}

    def hd_to_fullhd(s):
        return Transform(s, zoom=float(1080.0)/720.0)

    config.displayable_prefix["hd"] = hd_to_fullhd

    def qhd_to_fullhd(s):
        return Transform(s, zoom=float(1080.0)/1440.0)

    config.displayable_prefix["qhd"] = qhd_to_fullhd

    def uhd_to_fullhd(s):
        return Transform(s, zoom=float(1080.0)/2160.0)

    config.displayable_prefix["uhd"] = uhd_to_fullhd

    config.late_images_scan = False
    config.image_extensions =  [ ".jpg", ".jpeg", ".png", ".webp" ]
    config.images_directory = 'images'

    def _scan_images_directory():
        global active_img_resolution
        
        
        _scan_images_directory_2('gui/loading', '', '3d')
        
        ios_specific_load()
        if not persistent.img_resolution or persistent.img_resolution not in img_resolutions:
            if len(img_resolutions) > 1:
                active_img_resolution = default_resolution_per_system()
                if active_img_resolution not in img_resolutions:
                    active_img_resolution = img_resolutions[0]
            else:
                persistent.img_resolution = img_resolutions[0]
                active_img_resolution = img_resolutions[0]
        
        elif persistent.img_resolution:
            active_img_resolution = persistent.img_resolution
        
        
        
        if active_img_resolution == 2160:
            _scan_images_directory_2('images_2160', 'uhd:', '3d')
            _scan_images_directory_2('images', '', '3d')
        elif active_img_resolution == 1440:
            _scan_images_directory_2('images_1440', 'qhd:', '3d')
            _scan_images_directory_2('images', '', '3d')
        elif active_img_resolution == 1080:
            _scan_images_directory_2('images', '', '3d')
        elif active_img_resolution == 720:
            _scan_images_directory_2('images_720', 'hd:', '3d')
            _scan_images_directory_2('images', '', '3d')



    def _scan_images_directory_2(directory, load_prefix, image_type):
        import os
        
        prefix = directory.rstrip('/') + '/'
        
        for fn in renpy.list_files():
            if not fn.startswith(prefix):
                continue
            
            can_load_image = True
            basename = os.path.basename(fn)
            base, ext = os.path.splitext(basename)
            
            base = base.lower()
            base = base.partition("@")[0]
            if renpy.has_image(base, exact=True):
                continue
            
            if not ext.lower() in config.image_extensions:
                continue
            
            
            
            fn = load_prefix + fn
            renpy.image(base, fn)


    def auto_detect_resolution_first_time():
        if (persistent.img_resolution == 0 
            or persistent.video_resolution == 0 
            or (config.developer and not release_version) 
            or persistent.img_resolution not in img_resolutions
            or persistent.video_resolution not in video_resolutions):
            
            
            if not renpy.emscripten:
                
                width, height = renpy.display.core.get_size()
            else:
                import pygame_sdl2 as pygame
                
                width, height = pygame.display.get_drawable_size()
            
            height_from_width = round(width*9/16)
            height = min(height, height_from_width)
            
            
            desired_img_resolution = img_resolutions[0]
            desired_video_resolution = video_resolutions[0]
            
            for resolution, min_height in min_height_to_activate_resolution.items():
                if height >= min_height:
                    if resolution in img_resolutions: 
                        desired_img_resolution = resolution
                    if resolution in video_resolutions: 
                        desired_video_resolution = resolution
            
            
            
            
            if (active_video_resolution != desired_video_resolution 
                or active_img_resolution != desired_img_resolution):
                
                
                
                
                
                
                persistent.img_resolution = desired_img_resolution
                persistent.video_resolution = desired_video_resolution
                renpy.save_persistent()
                
                return True
        
        return False


    def default_resolution_per_system():
        if not renpy.variant('small'):
            return 1080
        elif renpy.variant('small'):
            return 720
        
        return 720
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
