
init 1 python:

    def scan_storyboard_directory():
        if not persistent.img_resolution:
            return
        _scan_images_directory_2('storyboard', '', 'ystoryboard')

    scan_storyboard_directory()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
