label splashscreen:

    if is_demo == 'fast_demo_chloe':
        $ set_fast_demo_settings()
        return

    if not renpy.android and not renpy.emscripten:
        scene loading_screen
        pause 0.05
        if auto_detect_resolution_first_time():
            $ restart_game()

    scene black
    $ try_to_set_the_language()

    if config.developer:
        call screen play_with_sound
        $ skip_intros = True
        if skip_intros:
            play music config.main_menu_music fadein 1 volume main_menu_music_volume
            return

    if len(valid_languages) > 1:
        call screen language_selector_pregame

    if not renpy.emscripten:
        if renpy.emscripten:
            $ renpy.movie_cutscene('gui/oppaiman_splash.webm')
        else:
            if patreon_cta in ctas:
                $ renpy.movie_cutscene('gui/oppaiman_splash.webm')
            else:
                $ renpy.movie_cutscene('gui/oppaiman_splash_discord.webm')

        play music config.main_menu_music fadein 1 volume main_menu_music_volume 
    else:
        play music config.main_menu_music fadein 1 volume main_menu_music_volume
        call logo_cta (0.5) from _call_logo_cta_2
    scene black
    show screen warning_intro_scr with fade      
    pause 2
    hide screen warning_intro_scr with fade
    $ validate_mods()


screen play_with_sound():
    zorder 200
    style_prefix "confirm"
    add "gui/overlay/confirm.webp"

    frame:
        has vbox
        align .5, .5
        spacing 45
        label "Do you want to start the game with music and sfx?":
            style "confirm_prompt"
            xalign 0.5

        hbox:
            xalign 0.5
            spacing 150

            textbutton "Yes" action [Preference("all mute", "disable"), Return()]
            textbutton "No" action [Preference("all mute", "enable"), Return()]


screen warning_intro_scr():
    if config.name == 'Forbidden Fantasy':
        add "ef1 thechosenone_030"
    else:
        add "warning_intro"
    style_prefix "warning_intro"
    frame:
        background Solid("#000000BF")
        xmaximum 800
        anchor 0.99, 0.99
        pos 1840, 1000

        padding 25, 25
        has vbox
        spacing 0
        xalign 0.5
        text _t(_("WARNING!")):
            size 70

        text _t(_("This game contains adult material and is reserved for an adult public."))
        text _t(_("All characters in this game are fictional and over the legal age of 18 years old."))
        text ""
        text _t(_("If you are easily offended or in a tough period of your life, this game is not for you."))


style warning_intro_text:
    size 35
    text_align 0.5
    xalign 0.5
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
