init:
    transform zoom20:
        zoom 2.0

screen language_img_btn(language_str, pregame=False):
    $ lang_renpy = language_str if language_str != 'english' else None
    $ image_auto_path = "gui/language/{}_%s.png".format(language_str)
    if not pregame:
        if renpy.variant("small"):
            imagebutton auto image_auto_path action Language(lang_renpy) at zoom20
        else:
            imagebutton auto image_auto_path action Language(lang_renpy)

    else:
        if renpy.variant("small"):
            imagebutton auto image_auto_path action [Language(lang_renpy), Return()] at zoom20
        else:
            imagebutton auto image_auto_path action [Language(lang_renpy), Return()]


screen select_language():
    tag menu
    use game_menu(_("Select Language"), scroll="viewport"):
        hbox:
            vbox:
                spacing 5
                if release_version or True:
                    style_prefix "check"
                    label _("Language")

                    for lang in valid_languages:
                        use language_img_btn(lang)


                    null height (2 * gui.pref_spacing)
                    textbutton _("OK") action ShowMenu("preferences")
            vbox:
                $ translators_list = top_translators.get(_preferences.language, [])
                if translators_list:

                    label _("Translated by")
                    for translator in translators_list:
                        text translator size gui.text_size

screen select_language():
    variant "small" tag menu

    use game_menu(_("Select Language"), scroll="viewport"):
        vbox:

            xfill True
            vpgrid:
                cols 2
                spacing 5
                for lang in valid_languages:
                    use language_img_btn(lang)

                if len(valid_languages)%2 == 1:
                    null

            null height (2 * gui.pref_spacing)
            textbutton _("OK") action ShowMenu("preferences")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
