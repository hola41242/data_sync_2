
init -100 python:
    import math

screen character_voice_btn(character):
    textbutton _(get_name_with_status(character)) action Function(mute_character, character)

screen character_voices():
    tag menu
    default index = 0
    default n_columns = 4
    default n_rows = math.ceil(len(mutable_characters)/n_columns)

    use game_menu(_("Character Voices"), scroll="viewport"):
        style_prefix "check"
        vbox:
            label _("Voices")
            hbox:
                for column in range(n_columns):
                    vbox:
                        spacing 5
                        for row in range(n_rows):
                            $ index = column * n_rows + row
                            if index < len(mutable_characters):
                                use character_voice_btn(mutable_characters[index])


            null height (4 * gui.pref_spacing)
            textbutton _("OK") action ShowMenu("preferences")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
