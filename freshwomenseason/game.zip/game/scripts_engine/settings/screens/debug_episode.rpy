
screen debug_episode():
    tag debug_screen
    modal True
    zorder 200
    viewport:
        xmaximum 1870
        xpos 50

        yfill True
        scrollbars "vertical"
        draggable True
        mousewheel True
        has vbox
        text 'Select Scene to Load'

        for rank0_list in reversed(organize_labls.rank0):
            text rank0_list[0] xpos 10

            vpgrid:
                $ vpgrip_elem_count = 0
                left_margin 10
                xfill True
                cols 6
                spacing 2
                for i in range(1, len(rank0_list)):
                    $ rank1_list = rank0_list[i]
                    textbutton organize_labls.remove_from_start(rank1_list[0], rank0_list[0]) action Function(debug_scene, rank1_list[0]) text_size 20
                    $ vpgrip_elem_count+=1
                    for j in range(1, len(rank1_list)):
                        textbutton organize_labls.remove_from_start(rank1_list[j], rank0_list[0]) action Function(debug_scene, rank1_list[j]) text_size 20
                        $ vpgrip_elem_count+=1
                $ vpgrip_elem_count =vpgrip_elem_count%6
                if vpgrip_elem_count > 0:
                    for i in range(6- vpgrip_elem_count):
                        null

            null height 20

init python:
    def debug_scene(label):
        
        renpy.music.stop(channel='music', fadeout=3)
        renpy.jump(label)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
