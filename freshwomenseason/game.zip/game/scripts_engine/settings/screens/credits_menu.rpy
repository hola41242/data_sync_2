

screen credits_menu():
    tag menu
    use game_menu(_("Credits"), scroll="viewport"):
        vbox:
            spacing 5
            xalign 0.5
            textbutton _("OK") action ShowMenu("preferences")
            for title, name_list in main_credits_dict.items():
                if name_list:
                    text title size gui.text_size color gui.accent_color
                    for cred_name in name_list:
                        text cred_name size gui.text_size

                    null height (10)
            textbutton _("OK") action ShowMenu("preferences")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
