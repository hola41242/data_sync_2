init python:
    import inspect
    import pygame.scrap

    def to_clipboard(text):
        renpy.notify('Copied to Clipboard')
        pygame.scrap.put(pygame.scrap.SCRAP_TEXT, text)

screen character_debug_screen(speech_id):
    tag debug_screen_2
    zorder 100

    if not youtuber_mode:
        textbutton speech_id:
            text_size 20
            align 0.98, 0.02
            text_style "debug_button"
            action Function(to_clipboard, speech_id)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
