
screen help():
    tag menu





    use game_menu(_("Help"), scroll="viewport"):


        style_prefix 'help'
        vbox:
            spacing 9

            if is_android():
                null height (16 * gui.pref_spacing)
                text _("Go to our Discord Server and send your request on the #help-and-bug-reports channel.")
                text _("Our community will be happy to help you out!")
                text _("English-Only")
                textbutton _(">>>> Click here to Ask for help on Discord <<<<"):
                    action OpenURL("https://discord.gg/oppaiman")
            else:
                label help_data['title']

                if is_steam_version() and is_desktop():
                    text help_data['verify_integrity']



                $ active_question = help_data['question_not_listed']
                textbutton active_question:
                    action ToggleSetMembership(help_buttons, active_question)
                    text_size gui.notify_text_size

                if active_question in help_buttons:
                    if is_steam_version():
                        textbutton ("-> " + _t(help_data['question_not_listed_answer_1_pc'])):
                            action OpenURL('steam://openurl/https://steamcommunity.com/app/1350650/discussions/')
                            text_size gui.notify_text_size
                    textbutton ("-> " + _t(help_data['question_not_listed_answer_2'])):
                        action OpenURL('https://discord.gg/oppaiman')
                        text_size gui.notify_text_size

                $ active_question = None
                for category, line in build_help_post.lines:
                    if category == Const.question:
                        $ active_question = line
                        textbutton active_question:
                            action ToggleSetMembership(help_buttons, active_question)
                            text_size gui.notify_text_size
                    else:
                        if active_question in help_buttons:
                            text ("-> " + _t(line))

                if is_steam_version() and is_desktop():
                    $ active_question = help_data['refund_request']
                    textbutton _t(active_question):
                        action OpenURL(refund_url())
                        text_size gui.notify_text_size




style help_text:
    size gui.notify_text_size



default help_buttons = []

init python:

    class Device:
        PC = 'PC'
        ANDROID = 'Android'
        ANY = 'Any'
        ALL = 'All'

    class Const:
        question = 'question'
        answer = 'Answer'


    class BuildHelpPost:
        def __init__(self):
            self.data = help_data
            self.lines = []
            
            self.devices = [Device.PC] if is_desktop() else [Device.ANDROID]
            self.devices.extend([Device.ALL])
            
            self.build_txt(self.data)
        
        def categorize_solution(self, problem_index, data):
            common = 'solution_{}'.format(problem_index) in data
            pc = 'solution_{}_pc'.format(problem_index) in data
            android = 'solution_{}_android'.format(problem_index) in data
            
            if all((pc,
                    not android,
                    not common)):
                return Device.PC
            
            if all((not pc,
                    android,
                    not common)):
                return Device.ANDROID
            
            if all((not pc,
                    not android,
                    common)):
                return Device.ALL
            
            if all((pc,
                    android)):
                return Device.ALL
        
        def build_txt(self, data):
            self.lines = []
            
            
            
            
            for i in range(10):
                self.append_question(i)
                self.append_solution(i)
        
        
        def device_tag(self, device):
            return ''
        
        def append_question(self, index):
            device = self.categorize_solution(index, self.data)
            if device not in self.devices:
                return
            
            question = self.get_content(index, 'problem', device)
            
            formatted_question = question
            self.lines.append((Const.question, formatted_question))
        
        def append_solution(self, index):
            device = self.categorize_solution(index, self.data)
            if device not in self.devices:
                return
            solution = self.get_content(index, 'solution', device)
            
            formatted_solution = solution
            self.lines.append((Const.answer, formatted_solution))
        
        def get_content(self, index, key, device):
            common = '{}_{}'.format(key, index)
            pc = '{}_pc'.format(common)
            android = '{}_android'.format(common)
            if device == Device.PC and pc in self.data:
                return self.data[pc]
            if device == Device.ANDROID and android in self.data:
                return self.data[android]
            
            return self.data[common]

    build_help_post = BuildHelpPost()

    def get_steam_language_id():
        if not _preferences.language:
            return 'english'
        override = {
            'portuguese': 'brazilian',
            'korean': 'koreana',
            'eportuguese': 'portuguese'
        }
        return override.get(_preferences.language, _preferences.language)

    def refund_url():
        return "https://store.steampowered.com/steam_refunds/?l={}".format(get_steam_language_id())
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
