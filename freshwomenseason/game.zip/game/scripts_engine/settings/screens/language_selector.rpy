
screen language_selector_pregame():
    if config.name == 'Forbidden Fantasy':
        add "gui/overlay/game_menu.webp"
    vbox:
        spacing 5
        align 0.5, 0.5
        for lang in valid_languages:
            use language_img_btn(lang, True)




screen language_selector_pregame():
    if config.name == 'Forbidden Fantasy':
        add "gui/overlay/game_menu.webp"
    variant "small"
    vpgrid:
        cols 2
        spacing 5
        align 0.5, 0.5
        for lang in valid_languages:
            use language_img_btn(lang, True)

        if len(valid_languages)%2 == 1:
            null
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
