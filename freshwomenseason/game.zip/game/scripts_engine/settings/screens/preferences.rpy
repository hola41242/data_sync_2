init offset = -1

init python:

    import pygame_sdl2 as pygame

screen display_performance():
    tag menu
    use game_menu(_("Performance and Resolution"), scroll="viewport"):
        hbox:
            vbox:
                xfill True
                style_prefix "radio"

                if renpy.emscripten:
                    $ width, height = pygame.display.get_drawable_size()
                else:
                    $ width, height = renpy.display.core.get_size()
                $ height_from_width = round(width*9/16)
                $ height = min(height, height_from_width)

                label _("Animation")
                for res, res_name in [(720, '720p 30fps'),
                                    (1080, '1080p 60fps'),
                                    (1440, '1440p 60fps'),
                                    (2160, '1800p 60fps')]:
                    if height >= min_height_to_activate_resolution[res] and res in video_resolutions:
                        textbutton res_name:
                            action SetVariable('persistent.video_resolution', res)

                label _("Image")
                for res, res_name in [(720, '720p'),
                                    (1080, '1080p'),
                                    (1440, '1440p'),
                                    (2160, '2160p')]:
                    if height >= min_height_to_activate_resolution[res] and res in img_resolutions:
                        textbutton res_name:
                            action SetVariable('persistent.img_resolution', res)

                if renpy.emscripten:
                    text "Screen size: {}x{}".format(width, height) size 22

                if active_video_resolution != persistent.video_resolution or active_img_resolution != persistent.img_resolution:
                    textbutton _("Restart the game to change resolution") action Function(restart_game)
                    if config.developer:
                        text "Developers must resize the screen to the correct size. current : {}".format(height) size 22


                else:
                    null height (1 * gui.pref_spacing)

                text _("1440p and 2160p are only available from Season 2 onward.") size 22

                null height (2 * gui.pref_spacing)
                textbutton _("OK") action ShowMenu("preferences")
            vbox:
                null


screen preferences():
    tag menu
    use game_menu(_("Options"), scroll=None):

        vbox:

            hbox:
                xfill True
                box_wrap True
                if not renpy.android:
                    vbox:
                        style_prefix "radio"

                        label _("Display")

                        if renpy.variant("pc") or renpy.emscripten:
                            textbutton _("Performance") action ShowMenu('display_performance')

                        if ((renpy.variant("pc") or renpy.emscripten) 
                            and not renpy.variant("steam_deck")
                            and allowed_fullscreen):
                            textbutton _("Window") action Preference("display", "window") default True
                            textbutton _("Fullscreen") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "check"
                    label _("Skip")

                    textbutton _("Unseen Text") action Preference("skip", "toggle")
                    textbutton _("After Choices") action Preference("after choices", "toggle")
                    textbutton _("Transitions") action InvertSelected(Preference("transitions", "toggle"))

                vbox:
                    if len(valid_languages) > 1:
                        style_prefix "check"
                        label _("Language")
                        textbutton _("Select Language") action ShowMenu('select_language')

                    if config.name == 'Forbidden Fantasy':
                        textbutton _("Credits"):
                            action ShowMenu('credits_menu')



            null height (4 * gui.pref_spacing)

            hbox:

                box_wrap True

                vbox:
                    style_prefix "slider"
                    if not config.developer or debug_preferences:

                        if is_voice_installed:
                            label _("Voice")
                            textbutton _("Mute/Unmute a Character") action ShowMenu('character_voices')
                            null height gui.pref_spacing
                    label _("Auto-Forward Delay")
                    bar value Preference("auto-forward time")

                    if renpy.variant ('touch'):
                        textbutton _("Enable Auto") action Preference("auto-forward", "toggle")

                vbox:
                    style_prefix "slider"


                    label _("Music Volume")
                    if config.developer or debug_preferences:
                        text "{}".format(preferences.get_volume('music'))
                    else:
                        bar value Preference("music volume")

                    label _("Sound Volume")
                    if config.developer or debug_preferences:
                        text "{}".format(preferences.get_volume('sfx'))
                    else:
                        bar value Preference("sound volume")

                    if is_voice_installed:
                        label _("Voice Volume")
                        if config.developer or debug_preferences:
                            text "{}".format(preferences.get_volume('voice'))
                        else:
                            bar value Preference("voice volume")


                    textbutton _("Mute All") action Preference("all mute", "toggle") style "mute_all_button"






style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.button_text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.button_text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.button_text_properties("slider_button")

style slider_vbox:
    xsize 675
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
