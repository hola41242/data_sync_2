
init:
    transform zoom5:
        zoom 0.5

default quick_buttons_at_bottom = True

screen quick_buttons():

    hbox:
        style_prefix "quick"

        if quick_buttons_at_bottom:
            if not renpy.emscripten:
                align 1.0, 1.0
            else:
                align 0.8, 1.0
        else:
            align 0.5, 0.0

        textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
        textbutton _("Auto") action Preference("auto-forward", "toggle")
        if not _in_replay:
            textbutton _("Save") action ShowMenu('save')
            textbutton _("Load") action ShowMenu('load')
            textbutton _("Q.Save") action QuickSave()
            textbutton _("Q.Load") action QuickLoad()
        else:
            textbutton _("End Replay") action EndReplay(confirm=True)

        textbutton _("Prefs") action ShowMenu('preferences')



        if _preferences.language is not None:
            if config.name == 'FreshWomen':
                if not renpy.variant('steam_big_picture') and not renpy.variant("small") and not renpy.emscripten:
                    if CrowdinLink.singleton is None:
                        textbutton _("Help us proofread the game") action Function(enable_proofreader_mode)
                    else:
                        textbutton _("Disable proofreader mode") action Function(disable_proofreader_mode)
            else:
                textbutton _("Help us proofread the game") action Function(open_crowdin_forbidden_fantasy)
            textbutton _("Switch to English") action Language(None)

        if (_preferences.language != try_to_set_the_language()  
        and config.default_language in renpy.known_languages()
        and config.default_language in valid_languages):
            textbutton _("Switch to [config.default_language]") action Language(try_to_set_the_language())




screen quick_menu():

    zorder 100
    on "show" action Show("hover_here_for_menu", transition=dissolve)

    if quick_menu:
        if not youtuber_mode:
            hbox:
                style_prefix "quick"
                align 0.00, 1.00
                textbutton _("Back") action Rollback()

            if is_demo and buy_full_game_cta in ctas:
                frame:
                    background Solid("#f0424e")
                    padding (15, 15)
                    align 1.0, 0.0
                    textbutton _("BUY FULL GAME"):
                        action OpenURL(get_buy_full_game_url('quick_menu'))
                        text_color "#ffffff"
                        text_hover_color "#fdffa0"
                        text_size 30

        mousearea:
            area (0, 0.9, 1.0, 0.1)
            hovered [SetVariable('quick_buttons_at_bottom', True), 
                Show("quick_buttons", transition=dissolve), 
                Hide("hover_here_for_menu", transition=dissolve)]
            unhovered [Hide("quick_buttons", transition=dissolve), Show("hover_here_for_menu", transition=dissolve)]

        mousearea:
            area (0, 0.0, 1.0, 0.1)
            hovered [
                SetVariable('quick_buttons_at_bottom', False), 
                Show("quick_buttons", transition=dissolve),
                Hide("hover_here_for_menu", transition=dissolve)]
            unhovered [Hide("quick_buttons", transition=dissolve), Show("hover_here_for_menu", transition=dissolve)]


screen quick_menu():

    zorder 100
    variant "fast_demo"

    if is_demo and buy_full_game_cta in ctas:
        frame:
            background Solid("#f0424e")
            padding (5, 5)
            align 1.0, 0.0
            textbutton _("BUY FULL GAME"):
                action OpenURL(get_buy_full_game_url('quick_menu'))
                text_color "#ffffff"
                text_hover_color "#fdffa0"
                text_size gui.interface_text_size


screen hover_here_for_menu():
    zorder 100
    if quick_menu and not youtuber_mode:
        hbox:
            style_prefix "quick"
            if not renpy.emscripten:
                align 0.98, 1.00
            else:
                align 0.8, 1.0
            text "..." xalign 1.00




init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.button_text_properties("quick_button")


screen quick_menu():

    variant "small"
    zorder 100
    if quick_menu:

        hbox:
            style_prefix "quick"
            align 0.01, 1.0
            spacing 1
            textbutton _("Back") action Rollback() text_align 0.0
            if _in_replay:
                textbutton _("End Replay") action EndReplay(confirm=True) text_align 1.0
            else:
                textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True) text_align 0.0



        hbox:
            style_prefix "quick"

            align 0.8, 1.0
            spacing 1

            textbutton _("Menu") action ShowMenu() text_align 1.0


        if is_demo and buy_full_game_cta in ctas:
            frame:
                background Solid("#f0424e")
                padding (15, 15)
                align 1.0, 0.0
                textbutton _("BUY FULL GAME"):
                    action OpenURL(get_buy_full_game_url('quick_menu'))
                    text_color "#ffffff"
                    text_hover_color "#fdffa0"
                    text_size 50




















screen mute_button():
    imagebutton auto "gui/web/mute_%s.png" action Preference("all mute", "toggle") align 0.005, 0.95 at zoom8

screen mute_button():
    variant "small"
    imagebutton auto "gui/web/mute_%s.png" action Preference("all mute", "toggle") align 0.005, 1.0 at zoom150


screen fullscreen_button():
    imagebutton auto "gui/web/fullscreen_%s.png" action ToggleVariable("preferences.fullscreen") align 0.995, 0.95 at zoom8

screen fullscreen_button():
    variant "small"
    imagebutton auto "gui/web/fullscreen_%s.png" action ToggleVariable("preferences.fullscreen") align 0.995, 1.0 at zoom150
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
