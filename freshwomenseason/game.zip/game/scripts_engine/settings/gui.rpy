init offset = -2









init python:
    gui.init(1920, 1080)









define gui.text_font = font_cabin_regular


define gui.name_text_font = font_myrlissa


define gui.interface_text_font = font_evolve_sans


default gui.text_size = 44


define gui.name_text_size = 60


define gui.interface_text_size = 36


define gui.label_text_size = 36


define gui.notify_text_size = 24


define gui.title_text_size = 75





define gui.main_menu_background = "gui/overlay/game_menu.webp"
define gui.game_menu_background = "gui/overlay/game_menu.webp"








define gui.textbox_height = 290



define gui.textbox_yalign = 1.0





define gui.name_xpos = round(1920*(1-0.0)/2)

define gui.name_ypos = 0



define gui.name_xalign = 0.5



define gui.namebox_width = None
define gui.namebox_height = None



define gui.namebox_borders = Borders(0, 0, 0, 0)



define gui.namebox_tile = False






define gui.dialogue_xpos = round(1920*0.5)

define gui.dialogue_ypos = 80


define gui.dialogue_width = round(1920*0.5)





define gui.dialogue_text_xalign = 0.5








define gui.button_width = None
define gui.button_height = None


define gui.button_borders = Borders(6, 6, 6, 6)



define gui.button_tile = False
define gui.main_menu_button_font = font_college_block
define gui.main_menu_button_font_size = 0


define gui.button_text_font = gui.interface_text_font


define gui.button_text_size = gui.interface_text_size


define gui.button_text_idle_color = gui.idle_color
define gui.button_text_hover_color = gui.hover_color
define gui.button_text_selected_color = gui.selected_color
define gui.button_text_insensitive_color = gui.insensitive_color



define gui.button_text_xalign = 0.0








define gui.radio_button_borders = Borders(27, 6, 6, 6)

define gui.check_button_borders = Borders(27, 6, 6, 6)

define gui.confirm_button_text_xalign = 0.5

define gui.page_button_borders = Borders(15, 6, 15, 6)

define gui.quick_button_borders = Borders(15, 6, 15, 0)
define gui.quick_button_text_size = 21
define gui.quick_button_text_idle_color = gui.idle_small_color
define gui.quick_button_text_selected_color = gui.accent_color




















define gui.navigation_xpos = 60


define gui.skip_ypos = 15


define gui.notify_ypos = 68


define gui.choice_spacing = 33


define gui.navigation_spacing = 6


define gui.pref_spacing = 15


define gui.pref_button_spacing = 0


define gui.page_spacing = 0


define gui.slot_spacing = 1


define gui.main_menu_text_xalign = 1.0








define gui.frame_borders = Borders(6, 6, 6, 6)


define gui.confirm_frame_borders = Borders(60, 60, 60, 60)


define gui.skip_frame_borders = Borders(1, 1, 1, 1)


define gui.notify_frame_borders = Borders(24, 8, 60, 8)


define gui.frame_tile = False











define gui.bar_size = 38
define gui.scrollbar_size = 18
define gui.slider_size = 38


define gui.bar_tile = False
define gui.scrollbar_tile = False
define gui.slider_tile = False


define gui.bar_borders = Borders(6, 6, 6, 6)
define gui.scrollbar_borders = Borders(6, 6, 6, 6)
define gui.slider_borders = Borders(6, 6, 6, 6)


define gui.vbar_borders = Borders(6, 6, 6, 6)
define gui.vscrollbar_borders = Borders(6, 6, 6, 6)
define gui.vslider_borders = Borders(6, 6, 6, 6)



define gui.unscrollable = "hide"







define config.history_length = 250



define gui.history_height = 210



define gui.history_name_xpos = 233
define gui.history_name_ypos = 0
define gui.history_name_width = 233
define gui.history_name_xalign = 1.0


define gui.history_text_xpos = 255
define gui.history_text_ypos = 3
define gui.history_text_width = 1110
define gui.history_text_xalign = 0.0







define gui.nvl_borders = Borders(0, 15, 0, 30)



define gui.nvl_list_length = 6



define gui.nvl_height = 173



define gui.nvl_spacing = 15



define gui.nvl_name_xpos = 645
define gui.nvl_name_ypos = 0
define gui.nvl_name_width = 225
define gui.nvl_name_xalign = 1.0


define gui.nvl_text_xpos = 675
define gui.nvl_text_ypos = 12
define gui.nvl_text_width = 885
define gui.nvl_text_xalign = 0.0



define gui.nvl_thought_xpos = 360
define gui.nvl_thought_ypos = 0
define gui.nvl_thought_width = 1170
define gui.nvl_thought_xalign = 0.0


define gui.nvl_button_xpos = 675
define gui.nvl_button_xalign = 0.0







define gui.language = "unicode"









define gui.slot_button_width = 379
define gui.slot_button_height = 262
define gui.slot_button_borders = Borders(10, 0, 0, 0)
define gui.slot_button_text_size = 18
define gui.slot_button_text_xalign = 0.5
define gui.slot_button_text_idle_color = gui.idle_small_color
define gui.slot_button_text_selected_idle_color = gui.selected_color
define gui.slot_button_text_selected_hover_color = gui.hover_color

define gui.save_slots_xalign = 0.9
define gui.save_slots_yalign = -0.4


define config.thumbnail_width = 359
define config.thumbnail_height = 202


define gui.file_slot_cols = 4
define gui.file_slot_rows = 3

define gui.page_label_xalign = 0.45
define gui.page_label_yalign = -0.12






define gui.choice_button_width = 800
define gui.choice_button_height = None
define gui.choice_button_tile = False
define gui.choice_button_borders = Borders(50, 8, 50, 8)
define gui.choice_button_text_font = gui.text_font
define gui.choice_button_text_size = 38
define gui.choice_button_text_xalign = 0.5
define gui.choice_button_text_idle_color = "#cccccc"
define gui.choice_button_text_hover_color = "#ffffff"
define gui.choice_button_text_insensitive_color = "#333333"





define gui.input_name_prompt_y_pos = 700
define gui.input_name_defaultname_y_pos = gui.dialogue_ypos











init python:










    if renpy.variant("touch") or renpy.variant("small"):
        gui.quick_button_borders = Borders(60, 30, 60, 0)


    if config.name == 'FreshWomen':
        gui.main_menu_button_font_size = 60
    else:
        gui.main_menu_button_font_size = 40


    if renpy.variant("small"):
        
        
        
        if not renpy.variant("steam_big_picture"):
            gui.page_label_xalign = 0.4
            gui.page_label_yalign = -0.1
            gui.save_slots_xalign = 0.99
            gui.save_slots_yalign = 0.41
            
            gui.slot_button_width = 492
            gui.slot_button_height = 341
            
            config.thumbnail_width = 467
            config.thumbnail_height = 262
            
            gui.slot_button_text_size = 32
        
        
        
        gui.dialogue_width = 1400
        gui.choice_button_text_size = 50
        gui.pref_spacing = 10
        
        
        gui.text_size = 55
        gui.name_text_size = 70 
        gui.notify_text_size = 38
        gui.interface_text_size = 45
        gui.button_text_size = 45
        gui.label_text_size = 46
        
        if config.name == 'FreshWomen':
            gui.main_menu_button_font_size = 70
        else:
            gui.main_menu_button_font_size = 50
        
        
        gui.textbox_height = 320
        gui.name_xalign = 0.5
        gui.name_xpos = 960
        gui.text_xpos = 135
        gui.text_width = 1750
        
        
        gui.slider_size = 54
        
        gui.choice_button_width = 1860
        
        gui.navigation_spacing = 30
        gui.pref_button_spacing = 15
        
        gui.history_height = 285
        gui.history_text_width = 1035
        
        gui.quick_button_text_size = 75
        
        
        if not renpy.variant("steam_big_picture"):
            gui.file_slot_cols = 3
            gui.file_slot_rows = 2
        
        
        gui.nvl_height = 255
        
        gui.nvl_name_width = 458
        gui.nvl_name_xpos = 488
        
        gui.nvl_text_width = 1373
        gui.nvl_text_xpos = 518
        gui.nvl_text_ypos = 8
        
        gui.nvl_thought_width = 1860
        gui.nvl_thought_xpos = 30
        
        gui.nvl_button_width = 1860
        gui.nvl_button_xpos = 30
        
        
        
        gui.input_name_prompt_y_pos = 150
        gui.input_name_defaultname_y_pos = 350


    gui_initial_state['text_size'] = gui.text_size
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
