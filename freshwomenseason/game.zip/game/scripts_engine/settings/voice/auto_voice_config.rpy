init -1500 python:

    class VoiceInfo(_object):
        """
        An object returned by VoiceInfo and get_voice_info().
        """
        
        def __init__(self):
            
            self.filename = _voice.play
            self.auto_filename = None
            self.tlid = None
            self.sustain = _voice.sustain
            self.tag = _voice.tag
            
            if not self.filename and config.auto_voice:
                
                for tlid in [
                    renpy.game.context().translate_identifier,
                    renpy.game.context().alternate_translate_identifier,
                    renpy.game.context().deferred_translate_identifier,
                    ]:
                    
                    if tlid is None:
                        continue
                    
                    if isinstance(config.auto_voice, (str, unicode)):
                        splitted_tlid = tlid.split("_")
                        fn = config.auto_voice.format(id=tlid, episode=splitted_tlid[0], scene=splitted_tlid[1])
                    else:
                        fn = config.auto_voice(tlid)
                    
                    self.auto_filename = fn
                    
                    if fn and renpy.loadable(fn):
                        
                        if _voice.tlid == tlid:
                            self.sustain = True
                        else:
                            self.filename = fn
                        
                        break
            
            self.tlid = renpy.game.context().translate_identifier or renpy.game.context().deferred_translate_identifier
            
            if self.filename:
                self.sustain = False
            elif self.sustain and (self.sustain != "preference"):
                self.filename = _last_voice_play
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
