define config.periodic_callback = periodic_emphasize_voice
define config.emphasize_audio_channels = []
define config.all_character_callbacks = [character_voice_callback]
init -100 python:

    all_pause_screens = ['save', 'load', 'preferences', 'help', 'awards', 'walkthrough_screen']


    allow_voicefx = False
    voicefx_fade_volume = 0

    def periodic_emphasize_voice():
        global allow_voicefx
        global voicefx_fade_volume
        no_pause_active = True
        for screen in all_pause_screens:
            if renpy.get_screen(screen):
                no_pause_active = False
                
                renpy.music.set_volume(0.0, channel='foley')
                renpy.music.set_volume(0.0, channel='voicefx')
        
        if no_pause_active:
            
            renpy.music.set_volume(1.0, channel='foley')
            
            if allow_voicefx and not renpy.music.get_playing('voice'):
                if voicefx_fade_volume < 1:
                    voicefx_fade_volume += 1.0/5.0
                    if voicefx_fade_volume > 0.8:
                        voicefx_fade_volume = 0.8
            
            elif voicefx_fade_volume > 0:
                voicefx_fade_volume -= 1.0/5.0
                if voicefx_fade_volume < 0:
                    voicefx_fade_volume = 0
            
            
            renpy.music.set_volume(voicefx_fade_volume, channel='voicefx')

    def character_voice_callback(event, interact=True, **kwargs):
        global allow_voicefx
        
        if not interact:
            return
        
        if event == 'begin':
            allow_voicefx = True
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
