init -1 python:


















    is_voice_installed = True
    config.has_voice = is_voice_installed
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
