init python in organize_labls:

    ignore_labels = ['asyncrequest_test','collect_reward_label', 'end_of_alpha', 'start_event_label', 'load_screen', 'ep_credits',
                  'ep_aftercredits', 'load_screen','joystick_preferences_screen', 'main_menu_screen', 'preferences_screen',
                  'start' , 'splashscreen', 'save_screen', 'ep1_24_bhfr', 'ep1_fr_bh',
                  'go_to_translate', 'tl_test', 'translate_unit', 'visit_steam_acquisition',
                  'visit_steam_retention', 'thanks_cta', 'newsletter_subscribe_cta', 'logo', 'julia_cta', 'julia_logo_cta', 
                  'end_of_beta', 'awards_data', 'ask_for_review', 'ask_for_name', 'ask_name', 'ef1_99_credits']
    unorganized_label_list = []
    for label_name in renpy.get_all_labels():
        if not label_name in ignore_labels and not label_name.startswith('_'):
            should_add = True
            for ignore_start in ignore_labels:
                if label_name.startswith(ignore_start):
                    should_add = False
                    break
            for forbiden_word in ['loop', 'defaultname', 'lily_naming','clothestore_questions', 'badending', 'goodending']:
                if forbiden_word in label_name:
                    should_add = False
                    break
            if should_add:
                unorganized_label_list.append(label_name)


    unorganized_label_list.sort()   
    rank0 = []

    ga_events = {}

    last_first_name = ''
    last_second_third_names = ''
    for label_name in unorganized_label_list:
        splits = label_name.split('_')
        for split in splits:
            split.strip()
        if len(splits) >=2:
            first_name = splits[0]
            
            if last_first_name != first_name:
                last_first_name = first_name
                rank1 = [first_name]  
                rank0.append(rank1)
            
            if len(splits) >= 3:
                second_third_names = splits[1] + '_' + splits[2]
            else:
                second_third_names = splits[1]
            
            if last_second_third_names != second_third_names:
                last_second_third_names= second_third_names
                rank2 = []
                rank1.append(rank2)
            
            rank2.append(label_name)
            middle = rank2[0]
            middle = middle[len(first_name)+1:]
            end = label_name[len(first_name) + len(middle)+2:]
            if len(end) == 0:
                end = '_'
            
            ga_event = "{}:{}:{}".format(first_name, middle,end)
            ga_events[label_name] = ga_event












    def remove_from_start(full_label, prefix):
        return full_label.replace(prefix, '').strip('_')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
