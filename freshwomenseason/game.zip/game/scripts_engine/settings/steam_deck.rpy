define _renpysteam.keyboard_mode = "always"

init -3 python:
    if renpy.variant("steam_deck") or renpy.variant("steam_big_picture"):
        renpy.game.preferences.pad_enabled = True
        print('Playing on Steam Deck or big picture')
        if "large" in config.variants:
            config.variants.remove("large")
        if "medium" in config.variants:
            config.variants.remove("medium")
        config.variants.insert(0, "small")
        config.variants.insert(0, "touch")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
