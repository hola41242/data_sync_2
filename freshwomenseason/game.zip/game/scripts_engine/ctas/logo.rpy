init python:

    def logo_url_str():
        if is_demo:
            url = get_buy_full_game_url('logo_cta')
            string_part_a = 'freshwomen.net'
            string_part_b = ''
        elif patreon_cta in ctas:
            url = my_own_platform_url
            string_part_a = 'freshwomen.net'
            string_part_b = ''
        elif steam_acquisition_cta in ctas:
            url = 'call:visit_steam_acquisition'
            string_part_a = 'OppaiMan'
            string_part_b = ' on Steam'
        elif steam_retention_cta in ctas:
            url = 'call:visit_steam_retention'
            string_part_a = 'OppaiMan'
            string_part_b = ' on Steam'
        elif itch_cta in ctas:
            url = itch_io_url
            string_part_a = 'OppaiMan'
            string_part_b = ' on Itch'
        else:
            url = discord_url
            string_part_a = 'discord.gg/'
            string_part_b = 'OppaiMan'
        
        return "{size=80}{a=" + url + "}{color=#ffffff}" + string_part_a + "{/color}{color=#d3afd7}" + string_part_b + "{/color}{/a}{/size}"

init:
    image logo_click = Text(logo_url_str(), text_align=0)


label logo_cta(pause_duration=0):

    scene logo_url with d
    show logo_click:
        yanchor 0.5 ypos 0.5
        xanchor 0 xpos 0.4
    with d
    if pause_duration:
        $ renpy.pause(pause_duration)
    else:
        pause
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
