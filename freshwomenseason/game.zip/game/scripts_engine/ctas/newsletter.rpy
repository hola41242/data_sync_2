init -100 python:


    def click_to_subscribe_newslleter():
        newsletter_str = _("Click here to subscribe")
        return "{click=" + newsletter_subscribe_url + "}" + _t(newsletter_str) + " {/click}"

screen newsletter_cta_scr():

    style_prefix "newsletter"
    vbox:
        text _t(_("Get notified when the NEXT EPISODE comes out"))
        text _t(_("BONUS: Get 4K images of the girls in your inbox"))

        text click_to_subscribe_newslleter()

        text '{☝️}'

style newsletter_text is thanks_text

style newsletter_vbox is thanks_vbox:
    ypos 800

label newsletter_subscribe_cta:

    scene mailing_list_bg with fade
    if config.name == 'Forbidden Fantasy':

        show mailing_image:
            yanchor 0.5 ypos 0.4
            xanchor 0.5 xpos 0.5
        with d

    show screen newsletter_cta_scr with d
    pause

    hide screen newsletter_cta_scr with d
    if config.name == 'Forbidden Fantasy':
        hide mailing_image with d
    hide mailing_list_bg with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
