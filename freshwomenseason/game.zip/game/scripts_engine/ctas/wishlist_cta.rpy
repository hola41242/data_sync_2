
init -100 python:
    def click_to_wishlist_season2():
        wishlist_str = _("Wishlist Season 2 on Steam")
        url = 'call:visit_steam_acquisition'
        return "{click=" + url + "}" + _t(wishlist_str) + " {/click}"

screen wishlist_cta_scr():
    style_prefix "thanks"
    vbox:
        text '{👇}'
        text click_to_wishlist_season2()
        text '{☝️}'

label wishlist_cta:
    scene wishlist_cta_image with fade
    show screen wishlist_cta_scr with d

    pause
    hide screen wishlist_cta_scr with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
