
screen buy_full_game_cta_2_screen():
    style_prefix "julia"
    vbox:
        xoffset 30
        xmaximum 700
        ypos 50
        spacing 5

        text _t(_("You have reached the end of the demo."))
        if config.name == "FreshWomen":
            text _t(_("Please support the development of FreshWomen:"))
        elif config.name == 'Forbidden Fantasy':
            text _t(_("Please support the development of Forbidden Fantasy:"))
        if buy_full_game_cta in ctas:
            text '{👇}'

            text click_to_buy_full_game_str('buy_2')

            text '{☝️}'
        else:
            text click_top_right_buy()

        text _t(_("As a supporter you get access to the latest episodes and previews."))
        text _t(_("Thank you very much for playing!"))



label buy_full_game_cta_2:
    scene julia_cta_image with fade
    show screen buy_full_game_cta_2_screen with d
    pause
    hide screen buy_full_game_cta_2_screen with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
