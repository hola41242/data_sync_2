init -99 python:
    import webbrowser
    def get_buy_full_game_url(medium):
        if renpy.emscripten:
            import emscripten 
            try:
                buy_full_game_url = emscripten.run_script_string('new URLSearchParams(window.location.search).get("buy_full_game_url");')
                if buy_full_game_url:
                    return buy_full_game_url
            
            except:
                pass
        
        return '{}?utm_source=demo1&utm_medium={}&utm_campaign={}'.format(my_own_platform_url, medium, medium)

    def click_to_buy_full_game_str(medium):
        url = get_buy_full_game_url(medium)
        string = _("Click to buy the full game")
        return "{click=" + url + "}" + _t(string) + " {/click}"

    def click_top_right_buy():
        string = _("Click on the top right  button to buy the full game.")
        return  _t(string)

    def open_buy_url():
        webbrowser.open(get_buy_full_game_url('auto'))


screen buy_full_game_cta_1_screen():
    style_prefix "thanks"
    vbox:

        if buy_full_game_cta in ctas:
            text click_to_buy_full_game_str('buy_1_top')
        else:
            text click_top_right_buy()

        text _t(_("This game is only possible thanks to the generous donations and support from hundreds of thousands of Supporters."))
        text ""
        text _t(_("A huge thanks to all my Supporters that had faith in me."))
        text _t(_("Thank you for believing in this game."))
        text ""
        text _t(_("Thank you for playing!"))



        if buy_full_game_cta in ctas:
            text '{👇}'

            text click_to_buy_full_game_str('buy_1_bottom')

            text '{☝️}'
        else:
            text click_top_right_buy()


label buy_full_game_cta_1:
    scene after_credits with d
    show screen buy_full_game_cta_1_screen with d

    pause
    hide screen buy_full_game_cta_1_screen with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
