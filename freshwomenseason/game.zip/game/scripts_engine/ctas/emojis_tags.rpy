init -10 python:

    def point_up_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/point_up.png')]

    config.self_closing_custom_text_tags["☝️"] = point_up_tag

    def point_down_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/point_down.png')]

    config.self_closing_custom_text_tags["👇"] = point_down_tag

    def point_left_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/point_left.png')]

    config.self_closing_custom_text_tags["👈"] = point_left_tag

    def point_right_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/point_right.png')]

    config.self_closing_custom_text_tags["👉"] = point_right_tag

    def star_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/star_60.png')]

    config.self_closing_custom_text_tags["⭐"] = star_tag

    def steam_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/steam.png')]

    config.self_closing_custom_text_tags["steam"] = steam_tag

    def patreon_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/patreon.png')]

    config.self_closing_custom_text_tags["patreon"] = patreon_tag

    def itch_tag(tag, argument):
        return [(renpy.TEXT_TAG, 'image=gui/emoji/itch.png')]

    config.self_closing_custom_text_tags["itch"] = itch_tag


    def click_tag(tag, argument, contents):
        return [
                (renpy.TEXT_TAG, u"b"),
                (renpy.TEXT_TAG, u"a={}".format(argument)),
                (renpy.TEXT_TAG, u"color=#fa9fae"),
            ] + contents + [
                (renpy.TEXT_TAG, u"/color"),
                (renpy.TEXT_TAG, u"/a"),
                (renpy.TEXT_TAG, u"/b"),
            ]

    config.custom_text_tags["click"] = click_tag
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
