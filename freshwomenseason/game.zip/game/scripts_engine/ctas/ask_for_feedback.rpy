label ask_for_feedback(form_id):

    scene black_screen as review_layer with long_dissolve

    "Do you want to give feedback on Story Alpha?"
    menu:
        "Yes, I want to give feedback"(True):
            "This will open a new tab on your browser."
            $ review_ep7_storyalpha(form_id)
        "No, thanks.":
            pass
    hide review_layer with d

    init python:
        import webbrowser

        def return_url (form_id):
            return "https://freshwomen.net/survey/{}/?utm_source=ingame&utm_medium=ask_for_feedback&utm_campaign=S2E2_Story_alpha&utm_id=survey".format(
        form_id)



        def review_ep7_storyalpha(form_id):
            webbrowser.open(return_url(form_id))
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
