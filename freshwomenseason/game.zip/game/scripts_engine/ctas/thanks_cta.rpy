init -100 python:

    def get_patreon_url(medium):
        return my_own_platform_url

    def click_to_support_patreon_str():
        patreon_url = get_patreon_url('credits_thanks')
        patreon_str = _("Click to support the game development on Patreon")
        return "{click=" + patreon_url + "}" + _t(patreon_str) + " {patreon}{/click}"

    def click_to_support_steam_acq_str():
        steam_acq_str = _("Click to support the game development on Steam")
        return "{click=call_in_new_context:visit_steam_acquisition}" + _t(steam_acq_str) + " {steam}{/click}"

    def click_to_support_steam_ret_str():
        steam_ret_str = _("Click to support the game development on Steam")
        return "{click=call_in_new_context:visit_steam_retention}" + _t(steam_ret_str) + " {steam}{/click}"

    def click_to_support_itch_str():
        itch_str = _("Click to support the game development on Itch.io")
        return "{click=itch_io_url}" + _t(itch_str) + " {itch}{/click}"

    def enclose_size(size, content):
        return "{size=" + str(size) + "}" + content + "{/size}"




screen thanks_cta_scr():
    style_prefix "thanks"
    vbox:
        if config.name == 'FreshWomen':
            text _t(_("FreshWomen will return in [next_episode_name]"))
        elif config.name == 'Forbidden Fantasy':
            text _t(_("Forbidden Fantasy will return in [next_episode_name]"))

        text _t(_("This game is only possible thanks to the generous donations and support from thousands of Supporters."))
        text ""
        text _t(_("A huge thanks to all my Supporters that had faith in me."))
        text _t(_("Thank you for believing in this game."))
        text ""
        text _t(_("Thank you for playing!"))

        text _t(_("Stay tuned for the next episode."))

        text '{👇}'

        if patreon_cta in ctas or config.developer:
            text click_to_support_patreon_str()
        if (steam_acquisition_cta in ctas or config.developer) and steam_acquisition_announcement_url:
            text click_to_support_steam_acq_str()
        if (steam_retention_cta in ctas or config.developer) and config.steam_appid:
            text click_to_support_steam_ret_str()
        if (itch_cta in ctas or config.developer) and itch_io_url:
            text click_to_support_itch_str()

        text '{☝️}'


style thanks_text:
    size 40
    text_align 0.5
    xalign 0.5

style thanks_vbox:
    xalign 0.5
    xmaximum 1200
    ypos 200
    spacing 5

label thanks_cta:
    scene after_credits with d
    show screen thanks_cta_scr with d

    pause
    hide screen thanks_cta_scr with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
