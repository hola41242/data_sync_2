screen buy_full_game_cta_3_screen():

    style_prefix "newsletter"
    vbox:
        text _t(_("Continue the story with 8 more hours of content"))

        if buy_full_game_cta in ctas:
            text click_to_buy_full_game_str('buy_3')
        else:
            text click_top_right_buy()

        text '{☝️}'


label buy_full_game_cta_3:
    scene mailing_list_bg with fade





    show screen buy_full_game_cta_3_screen with d
    pause
    if is_demo == 'fast_demo_chloe':
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause
        pause


    hide screen buy_full_game_cta_3_screen with d

    hide mailing_list_bg with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
