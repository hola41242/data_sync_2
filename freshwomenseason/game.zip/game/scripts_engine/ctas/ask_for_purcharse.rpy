label ask_for_purcharse:
    if is_demo and buy_full_game_cta in ctas:
        scene black_screen as review_layer with long_dissolve
        menu:
            "Are you enjoying this game so far?"
            "Yes!"(True):
                menu:
                    "Would you like to buy this game?"
                    "Buy the full game"(True):
                        "A new browser page will be opened where you can buy the full game."
                        $ buy_full_game_interstitial()
                    "No, continue with the free demo":
                        pass
            "No, thank you":
                pass

        hide review_layer with d


init python:
    import webbrowser
    import threading
    import time    
    import random

    def buy_full_game_interstitial():
        
        webbrowser.open(get_buy_full_game_url('interstitial'))
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
