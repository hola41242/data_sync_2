
screen julia_cta_scr():
    style_prefix "julia"
    vbox:
        xoffset 30
        xmaximum 700
        ypos 50
        spacing 5

        text _t(_("You have reached the end of this version."))
        text _t(_("Please support the development of [config.name]:"))

        text '{👇}'

        if patreon_cta in ctas or config.developer:
            text click_to_support_patreon_str()
        if (steam_acquisition_cta in ctas or config.developer) and steam_acquisition_announcement_url:
            text click_to_support_steam_acq_str()
        if (steam_retention_cta in ctas or config.developer) and config.steam_appid:
            text click_to_support_steam_ret_str()
        if (itch_cta in ctas or config.developer) and itch_io_url:
            text click_to_support_itch_str()

        text '{☝️}'

        text _t(_("As a supporter you get access to the latest news and previews."))
        text _t(_("Thank you very much for playing!"))

style julia_text:
    size 35


label julia_cta:
    if config.name == 'FreshWomen':
        scene julia_cta_image with fade
    elif config.name == 'Forbidden Fantasy':
        scene ef1 returnhome_010 with fade
    show screen julia_cta_scr with d
    pause
    hide screen julia_cta_scr with d
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
