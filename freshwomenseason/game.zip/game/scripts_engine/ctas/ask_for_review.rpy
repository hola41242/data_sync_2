label ask_for_review:
    if is_steam_version() or is_demo:
        return

        menu:
            "Are you enjoying this game so far?"
            "Yes!"(True):
                "Would you please take a moment to review this game?"
                "Reviews are the only way people know that my game is of high quality."
                "Also, I read the reviews to find out what to fix in future patches."
                if renpy.emscripten:
                    "Scroll down the page and click on the star rating you think is right for this game"
                else:
                    menu:
                        "Do you want to review this game?"
                        "Yes, I want to review this game"(True):
                            menu:
                                "Where did you download this game?"
                                "Itch.io":
                                    $ review_game_itch()
                                "F95zone":

                                    $ review_game_f95()
                                    show ask_review_f95 as review_layer with d
                                "Dikgames":

                                    $ review_game_dikgames()
                                    show ask_review_dikgames as review_layer with d
                                "Lewdzone":

                                    $ review_game_lewdzone()
                                    show ask_review_lewdzone as review_layer with d
                                "Other place":

                                    $ save("downloaded_from_other_place")
                                    "Go to the place where you downloaded this game, and write your review."

                            if not chose_skip_debug("downloaded_from_other_place"):
                                "A new browser page will be opened where you can write your review."

                            "Thanks. I really, truly, appreciate your time."
                        "No, I don't want to review this game":
                            pass
            "No, I'm not":
                pass

    hide review_layer with d


init python:
    import webbrowser
    import threading
    import time    
    import random

    def review_game_itch():
        if random.randint(0,9) == 0:
            webbrowser.open('https://oppaiman.itch.io/{}/comments'.format(itch_io_id)) 
        else:                       
            webbrowser.open('https://oppaiman.itch.io/{}/rate?source=game'.format(itch_io_id))

    def review_game_f95():
        webbrowser.open(f95_thread_url)

    def review_game_dikgames():
        webbrowser.open(dik_games_url)

    def review_game_lewdzone():
        webbrowser.open(lewd_zone_url)

    def download_native_android_version():
        webbrowser.open(my_own_platform_url)

    def player_choice(event_id):
        
        pass
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
