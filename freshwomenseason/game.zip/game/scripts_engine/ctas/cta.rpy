

label visit_steam_acquisition:
    $ steam_acquisition_action()
    return

label visit_wishlist_season2_steam:
    $ steam_wishlist_season_2()
    return

label visit_steam_retention:
    $ steam_retention_action()
    return

init -1 python:

    def is_desktop():
        return any([renpy.windows, renpy.macintosh, renpy.linux]) or (
                renpy.variant('web') 
                and not renpy.variant('mobile'))

    def is_android():
        return renpy.android or renpy.ios or (renpy.variant('web')
                            and (renpy.variant('touch') 
                                or renpy.variant('mobile')))

    import locale

    steam_banished_regions = ['de']
    ctas = set()
    patreon_cta = 'patreon'
    steam_acquisition_cta = 'steam_acquisition'
    steam_retention_cta = 'steam_retention'
    itch_cta = 'itch'
    email_cta = 'email'
    discord_cta = 'discord'
    buy_full_game_cta = 'buy_full_game'



    def steam_acquisition_action():
        for url in [steam_acquisition_announcement_url,
                    'steam://openurl/{}'.format(steam_acquisition_announcement_url)]:
            webbrowser.open(url)


    def steam_wishlist_season_2():
        wishlist_season_2_url = 'https://store.steampowered.com/app/2691310/FreshWomen__Season_2/'
        for url in [steam_acquisition_announcement_url,
                    'steam://openurl/{}'.format(steam_acquisition_announcement_url)]:
            webbrowser.open(url)


    def steam_retention_action():
        for url in ['steam://advertise/{}'.format(config.steam_appid)]:
            webbrowser.open(url)







    english_speaking_locale = [
        'en'
    ]
    patreon_too_expensive_regions = [
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        'ru', 
        
        
        
        
        
        
        
        
        

    ]





    def get_ctas():
        if 'web' in platforms and is_demo:
            ctas.clear()
            if not is_macWeb() and not is_iOSWeb():
                ctas.add(buy_full_game_cta)
            return
        
        locale, region = renpy.translation.detect_user_locale()
        if not is_steam_version():
            if (region not in patreon_too_expensive_regions
                or region in steam_banished_regions
                or locale in english_speaking_locale):
                
                ctas.add(patreon_cta)
            
            if is_desktop() and (region in patreon_too_expensive_regions 
                                    or locale not in english_speaking_locale
                                    or patreon_cta not in ctas) and config.steam_appid: 
                ctas.add(steam_acquisition_cta)
        
        
        else:
            if config.steam_appid:
                ctas.add(steam_retention_cta)
        
        ctas.add(email_cta)
        ctas.add(discord_cta)


    get_ctas()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
