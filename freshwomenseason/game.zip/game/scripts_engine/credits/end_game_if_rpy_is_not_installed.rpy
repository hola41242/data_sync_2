label end_game_if_rpy_is_not_installed(rpy_name):
    if not check_if_next_rpy_is_built(rpy_name):
        scene black with long_fade
        call thanks_cta from _call_thanks_cta
        stop music fadeout 3
        if not check_if_next_rpy_is_built(rpy_name):
            call julia_cta from _call_julia_cta

            call newsletter_subscribe_cta from _call_newsletter_subscribe_cta
            play music alter_ego
            call ep_credits from _call_ep_credits
            stop music fadeout 5
            call logo_cta from _call_logo_cta
            if not check_if_next_rpy_is_built(rpy_name):
                $ MainMenu(confirm=False)()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
