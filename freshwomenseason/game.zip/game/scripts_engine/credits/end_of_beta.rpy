default percentage_completed = 25

init python:
    def end_of_beta_click_here():
        str_0 = _t(_("Click here to write your feedback"))
        lines = ["{click=https://discord.gg/YT7hUM8fQQ}" + str_0 + "{/click}",
                '{☝️}']
        return '\n'.join(lines)

label end_of_beta(episode_number=9):
    scene black with long_fade

    "Thanks for playing the BETA of Chapter [episode_number]"

    "This is [percentage_completed] percent of the content we planned for this episode."

    "And we'd like to receive your feedback so we can keep improving."

    "Write your thoughts on our Discord channel #beta-report"

    $ narrator(end_of_beta_click_here())

    call thanks_cta from _call_thanks_cta_1
    stop music fadeout 3
    call julia_cta from _call_julia_cta_1
    call newsletter_subscribe_cta from _call_newsletter_subscribe_cta_1

    call logo_cta from _call_logo_cta_1
    $ MainMenu(confirm=False)()


label end_of_partial_episode(episode_number=9):
    scene black with long_fade
    call thanks_cta from _call_thanks_cta_6
    stop music fadeout 3
    call julia_cta from _call_julia_cta_6

    call newsletter_subscribe_cta from _call_newsletter_subscribe_cta_6
    call ef1_99_credits from _call_ef1_99_credits
    stop music fadeout 5
    call logo_cta from _call_logo_cta_8
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
