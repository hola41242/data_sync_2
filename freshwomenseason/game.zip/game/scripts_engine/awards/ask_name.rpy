default ask_name_input_name = False

label ask_name:
    $ ask_name_input_name = True
    $ persistent.name = renpy.input(
                                _("What is your name?"),
                                length=32,
                                screen = "inputname")
    $ ask_name_input_name = False
    $ renpy.save_persistent()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
