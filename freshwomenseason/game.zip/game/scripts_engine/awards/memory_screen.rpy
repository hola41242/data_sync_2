init:
    transform zoom8:
        zoom 0.8

    transform zoom150:
        zoom 1.5

    transform zoom88:
        zoom 0.88

    transform zoom89:
        zoom 0.89

    transform zoom9:
        zoom 0.9

screen memory(award, image_url):
    modal True tag memo

    if 'anim' in image_url:
        add (image_url + '_beg')
    add image_url

    imagebutton auto "gui/awards/close_%s.png":
        action [Hide('memory', transition=dissolve)]
        at zoom8
        align (0.95, 0.08)
        anchor (0.5, 0.5)
    if award.album:
        imagebutton auto "gui/awards/left_%s.png":
            action Function(award.prev_img)
            at zoom8
            align (0.83, 0.18)
            anchor (0.5, 0.5)

        text award.position_str():
            size 40
            align (0.89, 0.18)
            anchor (0.5, 0.5)
        imagebutton auto "gui/awards/right_%s.png":
            action Function(award.next_img)
            at zoom8
            align (0.95, 0.18)
            anchor (0.5, 0.5)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
