default persistent.awards = []
default persistent.name = ''

init python:
    import json

    def replay_scope():
        return {
            'ep2_dictionarygirl': True,
            'name': persistent.name,
            'ep2_julia_kiss': True,
            'ep3_04_challenge_won': True
        }

    mr = MusicRoom(fadeout=1.0, single_track=True)


    class Award(NoRollback):
        def __init__(self, title, task, unlock_str, hidden, replay, song):
            self.title = title
            self.task = task
            self.unlock_str = unlock_str 
            
            self.replay = replay
            self.index = 0
            
            self.album = False
            self.scene = False
            
            if song:
                self.song = audio_folder_path.format(song)
                mr.add(self.song, always_unlocked=True)
            else:
                self.song = None
            
            if replay:
                if isinstance(replay, list):
                    self.album = True
                    self.replay.insert(0, self.unlock_str)
                    self.btn_action = ShowMenu('memory', self, self.replay[self.index])
                else:
                    self.scene = True
                    self.btn_action = self.check_name_and_replay
            else:               
                self.btn_action = ShowMenu('memory', self, self.unlock_str)
            
            self.hidden = hidden and not self.scene   
            
            if self.unlock_str in persistent.awards:
                self.unlocked = True
                self.set_unlocked_image()
            else:
                self.unlocked = False            
                self.image = 'gui/awards/locked_button.webp'
            
            
            self.unlock()
        
        def check_name_and_replay(self):
            if persistent.name in ['', protagonist_default_name] or config.developer: 
                renpy.call_in_new_context('ask_name')
            renpy.call_replay(self.replay, scope=replay_scope())
        
        def set_unlocked_image(self):      
            achievement.grant(self.title)
            achievement.sync()
            self.image = 'gui/awards/thumbs/' + self.unlock_str + '_thumb.webp'
        
        def next_img(self):
            self.index += 1
            self.index %= len(self.replay)
            img = self.replay[self.index]
            self.btn_action = ShowMenu('memory', self, self.replay[self.index])
            renpy.transition(dissolve)
            renpy.show_screen('memory', self, img)
        
        def prev_img(self):
            self.index -= 1
            if self.index < 0:
                self.index += len(self.replay)
            
            img = self.replay[self.index]
            self.btn_action = ShowMenu('memory', self, self.replay[self.index])
            renpy.transition(dissolve)
            renpy.show_screen('memory', self, img)
        
        def position_str(self):
            return str(self.index+1) + '/' + str(len(self.replay))
        
        def unlock(self):
            if (renpy.seen_image(self.unlock_str)):
                
                self.unlocked = True
                self.set_unlocked_image()
                
                if self.unlock_str not in persistent.awards:
                    persistent.awards.append(self.unlock_str)
                
                return True
            
            return False
        
        def album_count(self):
            return '{}x'.format(len(self.replay))


    class AwardManager(NoRollback):
        
        def __init__(self):
            
            if config.developer and not release_version:           
                self.sort_awards() 
                pass 
            
            
            global awards_data
            awards_data = self.filter_awards_data(awards_data)
            self.awards = [Award(title, task, unlock_str, hidden, replay, song) for title, task, unlock_str, hidden, replay, song in awards_data]
            self.replay_awards = [award for award in self.awards if  isinstance(award.replay,str)]
            self.image_awards = [award for award in self.awards if award not in self.replay_awards]
            self.notifications = True
        
        
        def filter_awards_data(self, awards_data):
            awards_data_filtered = []
            print()
            for title, task, unlock_str, hidden, replay, song in awards_data:
                award_episode = int(unlock_str[2:3]) 
                
                if award_episode in full_episodes or award_episode in partial_episodes:
                    awards_data_filtered.append((title, task, unlock_str, hidden, replay, song))
            return awards_data_filtered
        
        def sort_awards(self):
            pass
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        def hidden_count(self):
            count = 0
            for award in self.image_awards:
                if award.hidden and not award.unlocked:
                    count += 1
            
            return count
        
        def check_new_awards(self):            
            if not self.notifications:                
                return
            
            notify = False
            for award in self.awards:
                if not award.unlocked:
                    unlocked = award.unlock()
                    
                    if unlocked:
                        notify = True
            
            if notify:                
                renpy.notify(_("Gallery Content Unlocked!"))
        
        
        def block_notify(self):
            self.notifications = False
        
        def enable_notify(self):
            self.notifications = True
            self.check_new_awards()

    award_manager = AwardManager()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
