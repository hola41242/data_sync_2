




init -1 python:

    import re

    def get_images_order():
        
        image_pattern = re.compile(r'(scene|show|hide)\s(?P<displayable>[ep\d]*\s*[\w]*)')
        episode_scenes = [file for file in renpy.list_files() if (file.startswith(('episode', 'free roams')))and not file.endswith('.rpyc')]
        
        images = {}
        for scene in sorted(episode_scenes):
            print(scene)
            with open(renpy.file(scene).name, 'r') as f:
                for line in f.readlines():
                    match = re.search(image_pattern, line)
                    if match:
                        displayable = match.groupdict()['displayable']
                        if displayable and displayable not in images:
                            images[displayable] = len(images) + 1
        
        for image in sorted(images, key=images.get):
            print(images[image],': ', image)
        
        return images
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
