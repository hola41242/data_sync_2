init offset = -5

default persistent.crowdin_active = None
default persistent.crowdin_proofread_data = {}
default crowdin_timer_seconds = 0.5
default crowdin_timer_finished = False
default have_crowdin_account = False


init 1 python:
    import os
    import json


    class CrowdinLink(NoRollback):
        singleton = None
        def __init__(self):
            
            self.proofread_json = None
            self.active_language = _preferences.language
            self.proofread_json = self.load_proofread_json()
        
        def load_proofread_json(self):
            benchmark_flag = 'load_proofread_json(self)'
            start_benchmark_clock(benchmark_flag)
            path_ending = os.path.join('crowdin', 'reverse_tl', '{}.json'.format(_preferences.language))
            path_ending = path_ending.replace('/', '_').replace('\\', '_')
            print('Looking for file that ends with: {}'.format(path_ending))
            for file_name in renpy.list_files():
                if file_name.replace('/', '_').replace('\\', '_').endswith(path_ending):
                    f = renpy.file(file_name)
                    report_benchmark_clock(benchmark_flag)
                    return json.load(f) 
        
        
        
        def get_proofread_data(self, what):
            if self.active_language != _preferences.language:
                self.active_language = _preferences.language
                self.proofread_json = self.load_proofread_json()
            
            if not what:
                return
            
            if not self.proofread_json:
                print('Error: self.proofread_json is not set.')
                return
            
            labl = store.crowdin_active_labl
            if labl in self.proofread_json:
                what_translated = self.proofread_json[labl]
                if what in what_translated:
                    return what_translated[what]
                else:
                    print('Error: what {} not set in what_translated'.format(what))
            else:
                print('Error: labl {} is not set in self.proofread_json'.format(labl))


    def enable_proofreader_mode():
        print('Enabling proofreader mode.')
        CrowdinLink.singleton = CrowdinLink()
        renpy.show_screen('crowdin_message_enable')

    def open_crowdin_forbidden_fantasy():
        webbrowser.open('https://crowdin.com/project/fantasy-project/invite?h=9fb49f99fdacc881361a4a03350d1b521902748') 

    def disable_proofreader_mode():
        CrowdinLink.singleton = None

    def crowdin_label_callback(labl_name, abnormal):
        
        filename, _ = renpy.get_filename_line()
        
        if not filename.startswith("renpy/common/") and filename:
            store.crowdin_active_labl = labl_name

    def crowdin_timer_start(seconds):
        crowdin_timer_seconds = seconds
        crowdin_timer_finished = False

    def crowdin_timer_out():
        crowdin_timer_finished = True

    def crowdin_suggest_better_translation(proofread_data):
        if proofread_data:
            url = proofread_data['url']
            if not have_crowdin_account:
                renpy.show_screen('crowdin_message_suggest', url)
            else:
                webbrowser.open(url)

    def replace_player_name_with_tags_2(string):
        
        string = string.replace(name, '[name]')
        
        string = string.replace(name.upper(), '[[name!u]')
        return string


    def create_crowdin_account():
        webbrowser.open(create_crowdin_account)

    def esc_tags(source):
        for old, new in [('{', '{{'), ('[', '[[')]:
            source = source.replace(old, new)
        return source


screen say(who, what):
    style_prefix "say"

    key "K_y" action Function(toggle_youtuber_mode)
    key "K_u" action Function(toggle_yt_shorts_mode)


    if yt_shorts_mode:
        window:
            id "window"
            ypos 930
            if who is not None:
                window:
                    id "namebox"
                    style "namebox"
                    text who id "who" ypos 60 size round(gui.name_text_size*0.65)


                text what:
                    id "what"
                    text_align 0.5
                    xsize round(600)
                    size 32

    else:

        window:
            id "window"

            if who is not None:
                window:
                    id "namebox"
                    style "namebox"
                    text who id "who" ypos 35 size gui.name_text_size

            if CrowdinLink.singleton is None or _preferences.language is None:
                text what id "what" text_align 0.5 size gui.text_size
            else:
                text what id "what" xsize 800 xpos 3200
                $ what_raw = replace_player_name_with_tags_2(what.replace('"','\\"'))
                $ left_side = what_raw

                timer crowdin_timer_seconds action Function(crowdin_timer_out)

                text esc_tags(left_side):
                    xalign 0

                    xsize 1700
                    outlines [ (2.5, "#000000", 1, 1) ]
                    pos (100,  gui.dialogue_ypos + 50)


                $ proofread_data = CrowdinLink.singleton.get_proofread_data(what_raw)
                if what_raw:
                    frame:
                        padding (15, 2)
                        pos (100, gui.dialogue_ypos)
                        if proofread_data:
                            text proofread_data['what_english'].replace('[', '[['):
                                xsize 1700
                                xalign 0




                        elif not crowdin_timer_finished:
                            text _("Loading translation..."):
                                xalign 0
                        else:
                            text _("Proofread system could not find string. Just skip this one."):
                                xalign 0


                    if proofread_data:
                        frame:
                            padding (50, 2)
                            pos (1900, 35)
                            yanchor 0.5
                            xanchor 0.99
                            textbutton _("Suggest better translation"):
                                action Function(crowdin_suggest_better_translation, proofread_data)
                                text_size 40


                frame:
                    padding (10, 2)
                    pos (1900, -30)
                    yanchor 0.5
                    xanchor 0.99
                    textbutton _("Join our translation community"):
                        action OpenURL(discord_translation_community)
                        text_size 30

        if not renpy.variant("small"):
            add SideImage() xalign 0.0 yalign 1.0


screen crowdin_message_enable():
    modal True
    zorder 200
    style_prefix "confirm"
    add "gui/overlay/confirm.webp"

    key "input_enter" action [Hide('crowdin_message_enable')]
    key "game_menu" action [Hide('crowdin_message_enable')]
    frame:
        background Solid("#000000FF")
        padding (10,10)
        minimum (800, 500)
        has vbox
        align (0.5, 0.5)
        spacing 5

        text _("Help us proofread the game to your language.") xalign 0.5
        text _("You'll now see the english text and a suggestion button.") xalign 0.5

        textbutton _("OK") action [Hide('crowdin_message_enable')] xalign 0.5


screen crowdin_message_suggest(url):

    modal True
    zorder 200
    style_prefix "confirm"

    key "input_enter" action [Hide('crowdin_message_suggest')]
    key "game_menu" action [Hide('crowdin_message_suggest')]
    frame:
        background Solid("#000000BF")
        padding (10,10)
        minimum (500, 200)
        has vbox
        align (0.5, 0.5)
        spacing 5

        text _("You must create a crowdin account to make a suggestion.")

        textbutton _("Create an account") action [Function(create_crowdin_account), Hide('crowdin_message_suggest')]
        textbutton _("I already have an account") action [OpenURL(url), SetVariable('have_crowdin_account', True), Hide('crowdin_message_suggest')]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
