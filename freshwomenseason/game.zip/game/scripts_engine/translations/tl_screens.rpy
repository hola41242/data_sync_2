screen choice(items):
    key "K_y" action Function(toggle_youtuber_mode)
    key "K_u" action Function(toggle_yt_shorts_mode)
    style_prefix "choice"

    if yt_shorts_mode:
        vbox:
            xalign 0.5
            for i in items:
                if i.args and i.args[0] and persistent.green_choice_mod:
                    textbutton '{color=#08CB2A}{b}' +  _t(i.caption) action i.action xalign 0.5
                else:
                    textbutton i.caption action i.action xalign 0.5 xsize 600
    else:
        vbox:

            for i in items:
                if i.args and i.args[0] and persistent.green_choice_mod:
                    textbutton '{color=#08CB2A}{b}' +  _t(i.caption) action i.action
                else:
                    textbutton i.caption action i.action
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
