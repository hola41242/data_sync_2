default persistent.try_load_user_lang = True

init python:
    def try_to_set_the_language():
        
        
        locale, region = renpy.translation.detect_user_locale()
        if locale is not None:
            lang_name = config.locale_to_language_function(locale, region)
            
            if lang_name is not None:
                config.default_language = lang_name
                if not persistent.try_load_user_lang:
                    return lang_name
                renpy.change_language(lang_name)
                persistent.try_load_user_lang = False
                return lang_name
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
