init python:

    import os

    def dont_open_walkthrough():
        pass

    def open_walkthrough_pdf():
        
        walkthrough_file = renpy.file('Walkthrough.pdf')
        
        
        
        
        if sys.platform == "win32":
            os.startfile(walkthrough_file.name)
        elif platform.mac_ver()[0]:
            subprocess.Popen([ "open", walkthrough_file.name ])
        else:
            subprocess.Popen([ "xdg-open", walkthrough_file.name ])
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
