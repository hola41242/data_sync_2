screen walkthrough_screen():
    tag menu
    use game_menu(_("Walkthrough Mod")):

        vbox:
            xfill True
            style_prefix "radio"
            label _("In-game Walkthrough")
            text _("Best choices are green")
            textbutton _("On"):
                action SetVariable('persistent.green_choice_mod', True)
            textbutton _("Off"):
                action SetVariable('persistent.green_choice_mod', False)


            null height (2 * gui.pref_spacing)

            if (renpy.variant("pc") 
                and not renpy.variant("steam_big_picture") 
                and not renpy.variant("steam_deck")
                and has_walkthrough_pdf):

                label _("Walkthrough PDF")
                if _preferences.language is not None:
                    text _("English only")
                textbutton _("Open Full Guide"):
                    action Confirm(_("Open Walkthrough PDF in another window?"), open_walkthrough_pdf, dont_open_walkthrough)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
