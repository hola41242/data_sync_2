
default persistent.green_choice_mod = False
define green = '{color=#08CB2A}{b}'

init python:
    def green_choice():
        return persistent.green_choice_mod
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
