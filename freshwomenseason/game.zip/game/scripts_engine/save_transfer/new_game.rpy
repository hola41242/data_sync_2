

screen new_game_screen():
    tag menu
    if config.name == 'FreshWomen':
        add "gui/save_generator/save_generator_background.png"
        $ new_game_screen_pos_x = 960
        $ new_game_screen_start_y = 540
        $ new_game_screen_spacing = 80
        if config.developer or enable_chapter_selector:
            textbutton "CHAPTER SELECTOR":
                pos new_game_screen_pos_x, (new_game_screen_start_y - new_game_screen_spacing)
                anchor 0.5, 0.5
                action Start('chapter_selector')
                text_style "main_menu_textbutton_text"


        if 1 in full_episodes:
            textbutton _("START SEASON 1"):
                pos new_game_screen_pos_x, new_game_screen_start_y
                anchor 0.5, 0.5
                action Start()
                text_style "main_menu_textbutton_text"

        if 6 in full_episodes:
            textbutton _("START SEASON 2"):
                pos new_game_screen_pos_x, (new_game_screen_start_y + new_game_screen_spacing)
                anchor 0.5, 0.5
                action Start('ep6_00_start')
                text_style "main_menu_textbutton_text_blue"

        textbutton _("BACK"):
            pos new_game_screen_pos_x, (new_game_screen_start_y + new_game_screen_spacing * 3)
            anchor 0.5, 0.5
            action Return()
            text_style "main_menu_textbutton_text"
    else:
        timer 0.001 action Start()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
