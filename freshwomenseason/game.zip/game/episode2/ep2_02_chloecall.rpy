label ep2_02_chloecall:
    show white as ep2 with long_dissolve

    play sound phone_vibrate volume 0.15
    "*Bzzzzt.*"
    hide white
    simon "Huh?"
    play sound phone_vibrate volume 0.15
    "*Bzzzzt.*"
    show ep2 thu_simonhome_phonering with long_dissolve
    play sound phone_vibrate volume 0.15
    simon "..." id ep2_02_chloecall_ba28090a
    show ep2 thu_simonhome_pickup_phone with long_dissolve
    simon "Hello..." id ep2_02_chloecall_6d63b44b
    play music early_morning volume 0.3 
    show ep2 thu_chloehome_chloe_excited with long_dissolve
    chloe "Hey, you!" id ep2_02_chloecall_a9a33ff8
    show ep2 thu_simonhome_simon_heychloe with d
    simon "Oh. Hey, Chloe." id ep2_02_chloecall_f9079516
    show ep2 thu_chloehome_chloe_worried with d

    chloe "This time, I'm sure I woke you." id ep2_02_chloecall_e360720f

    show ep2 thu_chloehome_chloe_silent with d
    simon "I cannot confirm nor deny that." (what_italic=True)
    show ep2 thu_chloehome_chloe_smiles with d
    chloe "Well, next time I promise not to call so early in the morning." id ep2_02_chloecall_8980a329
    show ep2 thu_chloehome_chloe_talks with d
    chloe "I have some information for you." id ep2_02_chloecall_07f4f5d7
    if not chose('ep1_chloe_susan'):
        chloe "I know you told me not to check on your boss, but I found something you might want to know." id ep2_02_chloecall_f1f960a0
        show ep2 thu_chloehome_chloe_silent with d
        simon "I'm not so sure about that." (what_italic=True)
        simon "But let's hear it." (what_italic=True)
    show ep2 thu_chloehome_chloe_proud with d
    chloe "This information was hard to come by." id ep2_02_chloecall_13af836f
    chloe "Maybe Dylan was right. I think I should become a private investigator." id ep2_02_chloecall_be967fce
    menu:
        "Compliment her"(True):
            show ep2 thu_chloehome_chloe_silent with d
            simon "You already sound like a pro." (what_italic=True)
            show ep2 thu_chloehome_chloe_laughs with d
            chloe "Hahaha!" id ep2_02_chloecall_0e7354b3
            $ points_chloe += 1
            $ ep2_chloe_gooddetective = True
        "Don't say anything":
            $ ep2_chloe_gooddetective = False
            pass
    show ep2 thu_chloehome_chloe_serious with d
    chloe "But, hey, before we continue..." id ep2_02_chloecall_a2a6e26e
    chloe "I had to do some digging on you and your family." id ep2_02_chloecall_fd75b30b
    show ep2 thu_chloehome_chloe_sad with d
    chloe "I know about the incident... and the coma." id ep2_02_chloecall_432c05a4
    chloe "I am so sorry." id ep2_02_chloecall_4f1ad6e7
    show ep2 thu_simonhome_simon_fine with fade
    simon "It's fine. It feels like it was ages ago." id ep2_02_chloecall_6bca1068
    show ep2 thu_chloehome_chloe_talks with fade
    chloe "But I have to ask..." id ep2_02_chloecall_e0f456c2
    show ep2 thu_chloehome_chloe_silent with d
    simon "Ask what?" (what_italic=True)
    show ep2 thu_chloehome_chloe_excited with d
    chloe "Did you get any superpowers?!" id ep2_02_chloecall_79dd33f8
    show ep2 thu_chloehome_chloe_silent with d
    simon "Are you serious?" (what_italic=True)
    show ep2 thu_chloehome_chloe_talks with d
    chloe "Well, people usually change after accidents." id ep2_02_chloecall_d29d1644
    chloe "There was this guy who had brain surgery and woke up with a different accent." id ep2_02_chloecall_2a5b2972
    show ep2 thu_simonhome_simon_strange with fade
    simon "That... doesn't sound like much of a superpower." id ep2_02_chloecall_681a976e
    simon "But as for me..." id ep2_02_chloecall_9a694af7
    menu:
        "Get mad":
            show ep2 thu_simonhome_simon_serious with d
            simon "It was quite the traumatic experience." id ep2_02_chloecall_1de8fb75
            simon "I don't remember much about my past or my father." id ep2_02_chloecall_a03a0bfb
            simon "And my mother refuses to tell me things." id ep2_02_chloecall_ecb5d3ef
            simon "Also, I had to go through a bunch of physical therapy." id ep2_02_chloecall_41146585
            simon "So, no. No superpowers or new accents for me." id ep2_02_chloecall_f0a5eb49
            show ep2 thu_chloehome_chloe_sad with fade
            chloe "I'm sorry. I didn't mean to pry." id ep2_02_chloecall_ecbc7871
            show ep2 thu_simonhome_simon_serious with fade
            simon "It's fine. It's just not the easiest thing for me to talk about." id ep2_02_chloecall_29393325
            show ep2 thu_chloehome_chloe_talks with fade
            chloe "I hope it gets easier with time." id ep2_02_chloecall_a5d13845
            $ ep2_dictionarygirl = False
        "Joke"(True):
            show ep2 thu_simonhome_simon_jokes with d
            simon "Even if I did get superpowers, I couldn't just tell you." id ep2_02_chloecall_0796e362
            simon "After all, you already know my secret identity." id ep2_02_chloecall_d2095645
            show ep2 thu_chloehome_chloe_excited with fade
            chloe "I could be your sidekick!" id ep2_02_chloecall_51cc6fcb
            show ep2 thu_chloehome_chloe_silent with d
            simon "What? Like Thunder Boy and Inspector Girl?" (what_italic=True)
            show ep2 thu_chloehome_chloe_explains with d
            chloe "Actually, thunder is just the sound lightning makes." id ep2_02_chloecall_93452cc6
            show ep2 thu_chloehome_chloe_silent with d
            simon "In that case, we should change the names, huh?" (what_italic=True)
            simon "How about Thunder Boy and Dictionary Girl?" (what_italic=True)
            show ep2 thu_chloehome_chloe_laughs with d
            chloe "Fair enough. Hahaha!" id ep2_02_chloecall_02f5f38a
            $ points_chloe += 1
            $ ep2_dictionarygirl = True
            show ep2 thu_chloehome_chloe_talks with d

    chloe "Moving on." id ep2_02_chloecall_6766b97a
    chloe "So... what do you want to hear first?" id ep2_02_chloecall_199f73ab
    show ep2 thu_chloehome_chloe_silent with d
    simon "Tell me about my father." (what_italic=True)
    show ep2 thu_chloehome_chloe_notebook with d
    chloe "It was really hard to find anything on your dad." id ep2_02_chloecall_f9d0be1f
    chloe "What do you remember about him?" id ep2_02_chloecall_917834da
    show ep2 thu_chloehome_chloe_n_silent with d
    simon "Not much, honestly." (what_italic=True)
    simon "I was really young when he went missing." (what_italic=True)
    show ep2 thu_chloehome_chloe_n_talks with d
    chloe "I see." id ep2_02_chloecall_3797ba9f
    show ep2 thu_chloehome_chloe_explains with d
    chloe "Well, he used to work right here in this very town." id ep2_02_chloecall_9f10b449
    chloe "He had an office at the mall." id ep2_02_chloecall_51ae1fe4
    chloe "An engineering office from what I gathered." id ep2_02_chloecall_50b9c9a9
    show ep2 thu_chloehome_chloe_n_closer with d
    play sound keyboard volume 0.5
    chloe "He used to work very closely with some guy called Mr. Alderson." id ep2_02_chloecall_33ebb432
    show ep2 thu_simonhome_simon_thinking with fade
    simon "That's Lily's last name..." id ep2_02_chloecall_3642d957
    show ep2 thu_chloehome_chloe_n_talks with fade
    chloe "Who's Lily?" id ep2_02_chloecall_f5c5c020
    show ep2 thu_simonhome_simon_thinking with fade
    simon "She's my landlady. Her husband would go by Mr. Alderson." id ep2_02_chloecall_1c2771ee
    show ep2 thu_chloehome_chloe_n_talks with fade
    chloe "Well, it's a common surname, but I can check him out." id ep2_02_chloecall_eb94c6f7
    stop music fadeout 4
    show ep2 thu_simonhome_simon_thinking with fade
    simon "There's one more thing." id ep2_02_chloecall_cf11fd5a
    simon "Lily and Susan know each other..." id ep2_02_chloecall_5ecc630e
    play music a_travelers_gloom fadein 2 volume 0.2
    show ep2 thu_chloehome_chloe_n_surprised with None

    chloe "Right!" id ep2_02_chloecall_4387ee0c
    chloe "All this is likely no coincidence then." id ep2_02_chloecall_4739f903
    show ep2 thu_simonhome_simon_talks with fade
    simon "And how about Susan?" id ep2_02_chloecall_09d16c35
    show ep2 thu_chloehome_chloe_n_odd with fade
    chloe "What an oddball, that one." id ep2_02_chloecall_c3386135
    chloe "It looks like Susan came out of nowhere." id ep2_02_chloecall_cb7dfee8
    chloe "She got married to some rich guy, and they started working together." id ep2_02_chloecall_f80856fa
    show ep2 thu_chloehome_chloe_explains with d
    chloe "Then the rich guy died, and since they never had any kids, all his money went to her." id ep2_02_chloecall_640bd0c4
    chloe "Sounds suspicious if you ask me." id ep2_02_chloecall_e06fad15
    show ep2 thu_simonhome_simon_question with fade
    simon "Do you think she had anything to do with his death?" id ep2_02_chloecall_ed6ac788
    show ep2 thu_chloehome_chloe_n_talks with fade
    chloe "It's hard to say." id ep2_02_chloecall_8bb8abf9
    show ep2 thu_chloehome_chloe_n_silent with d
    simon "I remember I had a picture of Susan with me on the night of my accident." (what_italic=True)
    simon "She has to have something to do with all this." (what_italic=True)
    show ep2 thu_chloehome_chloe_explains with d
    chloe "Honestly, she's like a ghost." id ep2_02_chloecall_7242f584
    chloe "Her digital footprint is almost nonexistent." id ep2_02_chloecall_9fefbe74
    chloe "Her clients from the store leave her nice reviews though." id ep2_02_chloecall_2a33b66a
    show ep2 thu_chloehome_chloe_n_closer with d
    chloe "Maybe she has some dark secret we don't know about." id ep2_02_chloecall_5e915f3b
    show ep2 thu_chloehome_chloe_n_silent with d
    simon "You're not the only one who thinks that." (what_italic=True)
    show ep2 thu_chloehome_chloe_s_excited with medium_dissolve
    chloe "You know something I don't?" id ep2_02_chloecall_481c8f4a
    chloe "Tell me everything!" id ep2_02_chloecall_7c88f664
    show ep2 thu_simonhome_simon_thinking with fade
    menu:
        "Tell her"(True):
            show ep2 thu_simonhome_simon_talks with d
            simon "Her niece also thinks she's hiding something." id ep2_02_chloecall_6c78c3b2
            simon "And, honestly, I do too." id ep2_02_chloecall_ea8f320d
            show ep2 thu_chloehome_chloe_s_talks with fade
            chloe "Her niece... The one who works at the clothes store, right?" id ep2_02_chloecall_73162afd
            show ep2 thu_chloehome_chloe_s_silent with d
            simon "Someone did her homework." (what_italic=True)
            if chose('ep1_chloe_sue'):
                show ep2 thu_chloehome_chloe_s_sad with medium_dissolve
                chloe "Yeah. You mentioned her before." id ep2_02_chloecall_68598b75
                simon "You're right. I did." (what_italic=True)
                show ep2 thu_chloehome_chloe_s_silent with medium_dissolve
            simon "We snooped around Susan's place, and it just looked too clean." (what_italic=True)
            show ep2 thu_chloehome_chloe_s_talks with d
            chloe "A façade." id ep2_02_chloecall_a1759511
            chloe "Classic mistake." id ep2_02_chloecall_9613ee4d
            show ep2 thu_simonhome_simon_question with fade
            simon "What do you mean?" id ep2_02_chloecall_181107cc
            show ep2 thu_chloehome_chloe_s_talks with fade
            chloe "You know, it's like in movies when the cops check on someone and find out the person doesn't have even a single traffic ticket on their record." id ep2_02_chloecall_81ce006b
            chloe "Too clean..." id ep2_02_chloecall_3883b6c6
            show ep2 thu_chloehome_chloe_s_silent with d
            simon "So, you agree that she could be hiding something?" (what_italic=True)
            show ep2 thu_chloehome_chloe_s_talks with d
            chloe "Now I'm sure of it." id ep2_02_chloecall_0f438583
            $ points_chloe += 1
            $ ep2_chlow_knowsabout_sue_search = True
        "Don't tell her":
            simon "Maybe you should forget I said that." id ep2_02_chloecall_25cea34c
            show ep2 thu_chloehome_chloe_s_talks with fade
            chloe "Oh, come on!" id ep2_02_chloecall_b1475b75
            show ep2 thu_chloehome_chloe_s_silent with d
            simon "Let's keep that under wraps until I find out a bit more, okay?" (what_italic=True)
            show ep2 thu_chloehome_chloe_s_talks with d
            chloe "Fine." id ep2_02_chloecall_b49843a0
            $ ep2_chlow_knowsabout_sue_search = False
    show ep2 thu_chloehome_chloe_sits with medium_dissolve
    chloe "There's one more thing I found out about Susan." id ep2_02_chloecall_1070b1ac
    chloe "She goes to these fundraiser things." id ep2_02_chloecall_9503fc25
    chloe "I didn't have much time to check out the specifics though." id ep2_02_chloecall_7fada8da
    show ep2 thu_chloehome_chloe_up with medium_dissolve
    chloe "There's one next week, so I'll try seeing what I can find out about it." id ep2_02_chloecall_f451e685
    show ep2 thu_chloehome_chloe_up_silent with d
    simon "Good. Thanks, Chloe." (what_italic=True)
    show ep2 thu_chloehome_chloe_up with d
    chloe "You're welcome. I'll keep you posted." id ep2_02_chloecall_6118c4fa
    chloe "How about we meet up later this week and discuss our findings?" id ep2_02_chloecall_e8563bbb
    stop music fadeout 4
    show ep2 thu_chloehome_chloe_up_silent with d
    simon "Sounds good." (what_italic=True)
    show ep2 thu_chloehome_chloe_up with d

    chloe "See you then!" id ep2_02_chloecall_9ca7e06d

    jump ep2_03_emily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
