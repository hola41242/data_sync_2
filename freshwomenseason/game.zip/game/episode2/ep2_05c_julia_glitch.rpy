

label ep2_05c_julia_glitch:

    show ep2 fri_game_simon_thinking with fade
    simon "(There's no way I can win if she keeps playing this well.)" id ep2_05c_julia_glitch_649321dc
    simon "(There's that controller glitch I can exploit though.)" id ep2_05c_julia_glitch_1941ff33
    simon "(It wouldn't be very fair, but at least it'll let me beat her.)" id ep2_05c_julia_glitch_aa06b1b1
    simon "(What should I do?)"
    menu:
        "Exploit the glitch in the controller"(True):
            $ ep2_julia_glitch = True
            jump ep2_05_the_game_glitch
        "Play fair":
            $ ep2_julia_glitch = False
            $ ep2_julia_glitch_2 = False
            jump ep2_05_the_game_noglitch


label ep2_05_the_game_glitch:
    show ep2 fri_game_glitch_bugged with d
    julia "This game's all bugged out!" id ep2_05_the_game_glitch_9ff4eae1
    show ep2 fri_game_glitch_bugged2 with d
    simon "Old games. You know how they go." id ep2_05_the_game_glitch_01218e70
    simon "Your turn to take something off." id ep2_05_the_game_glitch_d8c0309d
    show ep2 fri_game_glitch_youwon with wipeup
    julia "You only won because you took advantage of that bug... but I guess I'll give you one." id ep2_05_the_game_glitch_577dc49b
    show ep2 fri_game_glitch_dontstare with d
    julia "Don't stare!" id ep2_05_the_game_glitch_0e837a0d
    show ep2 fri_game_glitch_letsgo with wipedown
    julia "All right. Let's do this." id ep2_05_the_game_glitch_389e6966
    simon "(I do enjoy small, perky tits like hers.)" id ep2_05_the_game_glitch_890d1637
    simon "(I bet I could fit her entire boob in my mouth.)" id ep2_05_the_game_glitch_f93ac250
    show ep2 fri_game_glitch_boobs with d
    simon "(Nice!)" id ep2_05_the_game_glitch_c6e3bc56
    simon "(Damn it. If I get distracted, I'm going to lose again.)" id ep2_05_the_game_glitch_647592d4
    simon "(And I really want to see more!)" id ep2_05_the_game_glitch_ddbd5741
    show ep2 fri_game_glitch_letsgo with d
    julia "You won't win this next match!" id ep2_05_the_game_glitch_92205d89
    show ep2 fri_game_glitch2_focus with d
    simon "(I can use the controller glitch again, but that feels pretty risky.)" id ep2_05_the_game_glitch_ff3120f1
    simon "(What should I do?)"
    menu:
        "Use the glitch again":
            play sound lost volume 0.5
            $ ep2_julia_glitch_2 = True
            show ep2 fri_game_glitch2_notagain with d
            julia "Oh, no. Not again!" id ep2_05_the_game_glitch_5e12f663
            show ep2 fri_game_glitch2_wait with d
            julia "Wait a minute..." id ep2_05_the_game_glitch_fcf7a597
            julia "Are you the one making that happen?" id ep2_05_the_game_glitch_8e9f43b8
            simon "(Oh, shit!)" id ep2_05_the_game_glitch_013c45d3
            show ep2 fri_game_glitch2_cheating with None

            julia "YOU'RE CHEATING!" id ep2_05_the_game_glitch_11f83be4
            show ep2 fri_game_glitch2_onlyway with d
            julia "That's the only way you could beat me." id ep2_05_the_game_glitch_1c842b90
            julia "But you can't fool me."
            julia "It's time for you to go get us a snack." id ep2_05_the_game_glitch_155804a8
            show ep2 fri_game_glitch2_simon_youwin with d
            simon "Okay, you win." id ep2_05_the_game_glitch_83742da3
            show ep2 fri_game_glitch2_simon_youwin2 with d
            julia "Not so fast, Twinkle Toes." id ep2_05_the_game_glitch_081ae082
            julia "Aren't you forgetting something?" id ep2_05_the_game_glitch_97add1fa
            stop music fadeout 5
            show ep2 fri_game_glitch2_simon_youwin with d
            simon "What?" id ep2_05_the_game_glitch_708b4972
            show ep2 fri_game_glitch2_simon_happynow with d
            simon "All right, all right." id ep2_05_the_game_glitch_315b491c
            simon "Happy now?" id ep2_05_the_game_glitch_25fbf10e
            show ep2 fri_game_glitch2_julia_wego with d
            julia "Yep. Now we can go!" id ep2_05_the_game_glitch_be61c122

            jump ep2_05_simon_lost
        "Don't use it a second time"(True):


            $ ep2_julia_glitch_2 = False
            show ep2 fri_game_glitch2_focus with d
            simon "(I need to focus.)" id ep2_05_the_game_glitch_98c693e5
            simon "(I can't keep staring at her.)" id ep2_05_the_game_glitch_9d0c8539
            simon "(Even though she's sitting so close.)" id ep2_05_the_game_glitch_69e1701d
            simon "(And wearing practically nothing.)" id ep2_05_the_game_glitch_e49ca91f
            show ep2 fri_game_glitch2_shenoticed with None
            simon "(Damn, she noticed!)" id ep2_05_the_game_glitch_c5b9cd76
            show ep2 fri_game_glitch2_juia_obvious with d
            julia "Could you at least try not being so obvious about it?!" id ep2_05_the_game_glitch_0a3c020d
            play sound win volume 0.5
            show ep2 fri_game_glitch2_simon_wins with fade
            simon "Oh, I won!" id ep2_05_the_game_glitch_66368146
            show ep2 fri_game_glitch2_julia_guessso with d
            julia "I guess you did." id ep2_05_the_game_glitch_6098b510
            julia "All right. Let's go get that snack." id ep2_05_the_game_glitch_e193fe1d
            show ep2 fri_game_glitch2_forgetting with d
            simon "Aren't you forgetting something?" id ep2_05_the_game_glitch_dd0a7b31
            show ep2 fri_game_glitch2_julia_almostnaked with medium_dissolve
            julia "What? I'm already practically naked!" id ep2_05_the_game_glitch_8d3eba3c
            julia "You want me to take more off?" id ep2_05_the_game_glitch_c4258c04
            show ep2 fri_game_glitch2_alot with d
            simon "You've still got a lot to lose." id ep2_05_the_game_glitch_a4a0fd96
            show ep2 fri_game_glitch2_julia_almostnaked with d
            julia "Okay, but turn around." id ep2_05_the_game_glitch_b9db10ec
            show ep2 fri_game_glitch2_alot with d
            simon "That wasn't part of the deal." id ep2_05_the_game_glitch_2e61d7d1
            show ep2 fri_game_glitch2_julia_almostnaked with d
            julia "Just do it!" id ep2_05_the_game_glitch_ac481230
            show ep2 fri_game_glitch2_fine with medium_dissolve
            simon "Fine." id ep2_05_the_game_glitch_2eac89ff
            menu:
                "Sneak a peek"(True):
                    show ep2 fri_game_glitch2_service with d
                    pause
                "Don't look":
                    pass
            show ep2 fri_game_glitch2_julia_looknow with medium_dissolve
            julia "You can look now." id ep2_05_the_game_glitch_670e4b70
            show ep2 fri_game_glitch2_julia_looknow_s with d
            simon "(Whoa...)" id ep2_05_the_game_glitch_fe7c4f21
            show ep2 fri_game_glitch2_julia_looknow with d
            julia "Happy now?"
            julia "Lend me your shirt. I can't go out there like this." id ep2_05_the_game_glitch_9a47273f
            show ep2 fri_game_glitch2_julia_looknow_s with d
            simon "That wasn't part of the deal either." id ep2_05_the_game_glitch_a0bdc740
            show ep2 fri_game_glitch2_julia_looknow with d
            julia "Yes, but I'm a lady. I can't go outside looking like this." id ep2_05_the_game_glitch_5252d8bc
            show ep2 fri_game_glitch2_julia_looknow_s with d
            simon "Okay, fine!" id ep2_05_the_game_glitch_57580f8d
            stop music fadeout 10
            show ep2 fri_game_glitch2_julia_shallwe with d:
                yalign 1.0
                ease 8 yalign 0.0
            simon "Wow!" id ep2_05_the_game_glitch_fbac6252
            show ep2 fri_game_glitch2_julia_huge with d
            julia "It's huge on me! Yet quite comfortable." id ep2_05_the_game_glitch_fa974429
            julia "Shall we?" id ep2_05_the_game_glitch_b0d8ecd9
            $ points_julia += 1

            play music the_south fadein 3 volume 0.15
            jump ep2_05_simon_wins

    return

label ep2_05_the_game_noglitch:

    simon "(I can do this!)" id ep2_05_the_game_noglitch_d13ba9ed
    play sound lost volume 0.5
    show ep2 fri_game_julia_wins with d
    simon "How'd you beat me?!" id ep2_05_the_game_noglitch_64ce408e
    show ep2 fri_game_julia_badass with d
    julia "Years of training." id ep2_05_the_game_noglitch_65e27c63
    julia "You weren't half bad, but I remain undefeated." id ep2_05_the_game_noglitch_2a2ac949
    julia "Time to take something off!" id ep2_05_the_game_noglitch_a87fd9f1

    simon "Fine! Let's get this over with." id ep2_05_the_game_noglitch_4ae96bf4

    jump ep2_05_simon_lost
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
