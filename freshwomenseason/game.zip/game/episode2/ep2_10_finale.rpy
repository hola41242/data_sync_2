label ep2_10_finale:
    $ add_frame_to_finale = False
    show screen save_your_game(2, 1, 2, 0) with ending_fade
    scene ep2 finale_end_chloe

    $ set_finale_chars("Chloe")
    $ finale_color = "4FDB85"
    if chose_skip_debug('ep2_chloe_gooddetective'):
        $ finale_txt1 = _("You complimented Chloe on her good detective work.")
    else:
        $ finale_txt1 = _("You didn't say anything to Chloe about her detective work.")
    if chose_skip_debug('ep2_dictionarygirl'):
        $ finale_txt2 = _("You and Chloe shared a nice moment talking about superpowers.")
    else:
        $ finale_txt2 = _("You got mad at Chloe for joking about your accident.")
    if chose_skip_debug('ep2_chlow_knowsabout_sue_search'):
        $ finale_txt3 = _("Chloe now suspects that Susan had something to do with her husband's death.")
    else:
        $ finale_txt3 = _("You decided not to tell Chloe about your suspicions of Susan's involvement in Charlie's death.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You and Chloe decided to meet up later this week to talk more.")
    pause 
    hide screen save_your_game with long_fade

    $ award_manager.enable_notify()
    stop sound fadeout 2
    stop music fadeout 2


    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    $ set_finale_chars("Dylan")
    $ finale_color = "CF3F30"
    if chose_skip_debug('red_drink'):
        $ finale_txt1 = _("You took the red drink. Devilla will remember that.")
    else:
        $ finale_txt1 = _("You took the blue drink. Angela will remember that.")
    $ finale_txt2 = ""
    $ finale_txt3 = ""
    $ finale_txt4 = ""
    $ finale_txt5 = _("You don't know Dylan's whereabouts.")

    show ep2 finale_end_dylan with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Alyssa")
    $ finale_color = "A6F2F5"
    if chose_skip_debug('ep1_joindance'):
        $ finale_txt1 = _("Despite Tyler's injury, you saw how much Alyssa cares about her students and decided to join the team.")
    else:
        $ finale_txt1 = _("After taking part in a dance lesson with Alyssa, you decided you weren't ready to join up just yet.")
    if chose_skip_debug('ep2_alyssa_kiss'):
        $ finale_txt2 = _("You and Alyssa shared a nice improvised date at her favorite place. You two are closer now.")
    else:
        $ finale_txt2 = _("You decided a kiss would be taking things too fast with Alyssa and didn't go through with it.")
    $ finale_txt3 = ""
    $ finale_txt4 = ""
    $ finale_txt5 = _("You learned Alyssa has an important dance event next week.")

    show ep2 finale_end_alyssa with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    $ set_finale_chars("Julia")
    $ finale_color = "C161D4"

    if chose_skip_debug('ep2_julia_glitch'):
        $ finale_txt1 = _("You took advantage of the controller glitch when playing with Julia.")
    else:

        $ finale_txt1 = _("You didn't take advantage of the controller glitch when playing with Julia.")

    if chose_skip_debug('ep2_julia_glitch_2'):
        $ finale_txt2 = _("She ended up figuring out you were cheating.")
    else:
        $ finale_txt2 = ""

    if chose_skip_debug('ep2_julia_kiss'):
        $ finale_txt3 = _("You kissed Julia and shared a hot moment with her. Too bad it had to be cut short.")
    else:
        $ finale_txt3 = _("You decided not to take things too far with Julia. She seemed disappointed.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("Julia's mom seems very controlling. It might be awhile before the two of you can see each other again.")

    show ep2 finale_end_julia with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Sue")
    $ finale_color = "D6D6D6"
    if chose_skip_debug('ep2_sue_hug'):
        $ finale_txt1 = _("You helped keep Sue warm.")
    else:
        $ finale_txt1 = _("Sue asked you to hold her and keep her warm.")
    if chose_skip_debug('ep2_sue_stop'):
        $ finale_txt2 = _("You stopped Sue's advances.")
        $ finale_txt3 = ""
    else:
        $ finale_txt2 = _("You had sex with Sue.")
        if chose_skip_debug('ep2_sue_takeiteasy'):
            $ finale_txt3 = _("You told Sue to take it easy though.")
        else:
            $ finale_txt3 = _("Then, you showed her who's in control.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You learned that you've met Charlie before. You may have even had something to do with his accident.")

    show ep2 finale_end_sue with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    call end_game_if_rpy_is_not_installed ('ep3_01_the_ride.rpy')

    jump ep3_01_the_ride
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
