label ep2_03b_memories:
    play music different_kind_of_love volume 0.2 fadein 3
    show ep2 thu_photos_doing with medium_fade
    simon "(What am I doing?)" id ep2_03b_memories_b4036acb
    show ep2 thu_photos_dylan with d
    simon "(I must not have fully recovered after last night.)" id ep2_03b_memories_df0a3c97
    simon "(I wonder how Dylan's feeling right now.)" id ep2_03b_memories_b6e1293e
    show ep2 thu_photos_right with d
    simon "(Right... Dylan!)" id ep2_03b_memories_c1e88472
    play sound phone_ringing volume 0.5
    show ep2 thu_photos_pickup with medium_dissolve
    simon "(Come on. Pick up.)" id ep2_03b_memories_b1ebb350
    show ep2 thu_photos_weird with d
    simon "(Where's this weird feeling coming from all of a sudden?)" id ep2_03b_memories_87a29d30
    simon "(I remember getting there.)" id ep2_03b_memories_58923fc5
    simon "(Then everything's just a blur.)" id ep2_03b_memories_2210c966
    stop sound
    show ep2 thu_photos_nothing with d
    simon "(He's not answering.)" id ep2_03b_memories_1ff7ece2
    simon "(Should I be worried?)" id ep2_03b_memories_e1947b1d
    show ep2 thu_photos_notexts with d
    simon "(No texts from him either...)" id ep2_03b_memories_b1276d15
    show ep2 thu_photos_pictures with d
    simon "(Wait! Where'd these pictures come from?)" id ep2_03b_memories_ee0be000
    if not chose('red_drink'):
        show ep2 thu_photos_blue_pic1 with medium_dissolve
        simon "(This was right after I downed that weird drink.)" id ep2_03b_memories_c960c092
        simon "(I remember very little from then on.)" id ep2_03b_memories_1302bd55
        show ep2 thu_photos_blue_pic2 with None
        simon "(I certainly don't remember doing that.)" id ep2_03b_memories_d9e24d76
        show ep2 thu_photos_blue_pic3 with None
        simon "(Seems like I crossed the line there.)" id ep2_03b_memories_3a62bb30
        show ep2 thu_photos_blue_pic4 with None
        simon "(Or maybe not!)" id ep2_03b_memories_1fa35098
    else:
        show ep2 thu_photos_red_pic1 with d
        simon "(This was right after I had that drink.)" id ep2_03b_memories_c3956feb
        simon "(Hehe. Devilla has an awesome rack.)" id ep2_03b_memories_ecd8dd04
        show ep2 thu_photos_red_pic2 with None
        simon "(Oh, she saw me!)" id ep2_03b_memories_4033f72e
        show ep2 thu_photos_red_pic3 with None
        simon "(I figured she'd be okay with me looking.)" id ep2_03b_memories_fe118dd2
        show ep2 thu_photos_red_pic4 with None
        simon "(And she was!)" id ep2_03b_memories_3f0d84c5

    show ep2 thu_photos_pic5 with None
    simon "(Oh, no. And I was doing so well.)" id ep2_03b_memories_7a49dbd9
    simon "(That explains the headache.)" id ep2_03b_memories_f85c0b02
    show ep2 thu_photos_pic6 with None
    simon "(Oh...)" id ep2_03b_memories_adc41a60
    simon "(That explains it even more.)" id ep2_03b_memories_ba5834a9
    show ep2 thu_photos_pic7 with None
    simon "(I couldn't turn down an offer like that.)" id ep2_03b_memories_f283ce1b
    simon "(It looks like I just kept drinking until I blacked out.)" id ep2_03b_memories_ecf24994
    simon "(But Dylan looks fine.)" id ep2_03b_memories_30937604
    show ep2 thu_photos_pic8 with None
    simon "(Was he fine...?)" id ep2_03b_memories_17c9461e
    show ep2 thu_photos_pic9 with None
    simon "(Oh, okay. He's definitely fine.)" id ep2_03b_memories_447bb303
    simon "(He must have had a great night. Maybe that's why he isn't picking up.)" id ep2_03b_memories_f4839078
    stop music fadeout 3
    show ep2 thu_photos_sleep with medium_dissolve
    simon "(If only my memories from before the accident could come back so easily...)" id ep2_03b_memories_8703a47c
    jump ep2_04_the_dance
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
