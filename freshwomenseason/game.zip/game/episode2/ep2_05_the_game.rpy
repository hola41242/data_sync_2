label ep2_05_the_game:
    show black_screen with long_dissolve
    scene ep2 fri_simonhome_morning with long_fade
    simon "(What do we have in store for us today?)" id ep2_05_the_game_ccec1368
    play sound phone_pop volume 0.7
    show ep2 fri_simonhome_morning_phone with d
    simon "(I got a message from Julia!)" id ep2_05_the_game_af475f72
    if not_english():
        julia "Hey, Twinkle Toes. I found this place full of vintage games. Wanna go with me?" (what_italic=True)

    if not chose('ep1_hangout_julia'):
        simon "(Well, I guess it wouldn't be so bad to meet up with her and play some video games.)" id ep2_05_the_game_9587914e
    else:
        simon "(It's nice to have a friend I can play video games with.)" id ep2_05_the_game_77f215d6
        simon "(Maybe more than just friends?)" id ep2_05_the_game_dfadf4bf
        menu:
            "Best friends":
                $ ep2_more_than_friends = False
                simon "(Maybe more like... a best friend?)" id ep2_05_the_game_898a02db
            "Friends with benefits":
                $ ep2_more_than_friends = True
                simon "(Yeah, I could see that happening.)" id ep2_05_the_game_1d69fa58
                $ points_julia += 1
            "Maybe a long-term relationship"(True):
                $ ep2_more_than_friends = True
                simon "(Just maybe?)" id ep2_05_the_game_b268d9de
                $ points_julia += 2
    show ep2 fri_simonhome_morning_thinking with medium_dissolve
    simon "(Well, let's not rush things too much.)" id ep2_05_the_game_be93ac4d
    simon "(Let's see what sort of place we're going to first.)" id ep2_05_the_game_1f5bffdd
    show ep2 fri_simonhome_morning_looking with d
    simon "(It's not that far from here!)" id ep2_05_the_game_f8794104
    simon "(I've still got some time to get ready.)" id ep2_05_the_game_e687be0d

    show ep2 fri_arcade_bench with long_fade
    simon "(I don't think she's here yet.)" id ep2_05_the_game_2cf93ebf
    show ep2 fri_arcade_lookinside with d
    simon "(What a strange place...)" id ep2_05_the_game_9fd0e90a
    play music outgoing volume 0.15

    show ep2 fri_arcade_julia_fight with d
    julia "Hey, Twinkle Toes!" id ep2_05_the_game_4febce07
    show ep2 fri_arcade_julia_hi with d
    simon "Oh! Hi, Julia." id ep2_05_the_game_e6d024d2
    simon "I thought you were going to chicken out on me." id ep2_05_the_game_b21e50da
    show ep2 fri_arcade_julia_fight with d
    julia "I never back down from a fight." id ep2_05_the_game_00e62971
    show ep2 fri_arcade_theplace with d
    julia "So, is this the place?" id ep2_05_the_game_81e4d23d
    simon "I think so, yeah." id ep2_05_the_game_f38604c4
    show ep2 fri_arcade_julia_likethis with medium_dissolve
    julia "I didn't think it would be like this." id ep2_05_the_game_546b333c
    julia "I just looked up places with old games, and this one popped up on the map." id ep2_05_the_game_1484cad8
    show ep2 fri_arcade_julia_silent with d
    simon "It does look pretty vintage." id ep2_05_the_game_5dab74cd
    show ep2 fri_arcade_julia_oldpeople with d
    julia "Yeah, but it also looks like it's filled with a bunch of weirdos." id ep2_05_the_game_45a16408
    show ep2 fri_arcade_julia_goin with d
    julia "Well, we're already here. We can at least take a look inside." id ep2_05_the_game_d43d77b4
    show ep2 fri_arcade_simon_classic with d
    simon "You just want to play some classic games, right?" id ep2_05_the_game_ef679e6e
    show ep2 fri_arcade_julia_talks with d
    julia "Yeah. It's just, I didn't get to play video games very often when I was a kid." id ep2_05_the_game_38473271
    julia "So I haven't played a lot of the classics." id ep2_05_the_game_d445f1e7
    show ep2 fri_arcade_julia_thinks with d
    julia "But ever since I met you, I've been thinking a lot about gaming." id ep2_05_the_game_2ec6e756
    julia "It helps with the tension of being on a waitlist for college, you know...?" id ep2_05_the_game_cc0c425e
    show ep2 fri_arcade_simon_thinking with d
    simon "(Hmm. So she's on a waitlist...)" id ep2_05_the_game_2ec25593
    simon "(She could even be a classmate!)" id ep2_05_the_game_bdfafa80
    show ep2 fri_arcade_julia_silent with d
    simon "I have a vintage video game console back at my place." id ep2_05_the_game_370b093c
    show ep2 fri_arcade_julia_excited with d
    julia "Really? Does it still work?" id ep2_05_the_game_4f756ef9
    show ep2 fri_arcade_julia_silent with d
    simon "Yep. It's one of the few things from my childhood that I can remember." id ep2_05_the_game_4ed42409
    simon "So I had to bring it with me." id ep2_05_the_game_c2868f6d
    show ep2 fri_arcade_julia_talks with d
    julia "Can I see it?" id ep2_05_the_game_b6ffacc2
    show ep2 fri_arcade_simon_mess with d
    simon "My room is a mess right now..." id ep2_05_the_game_42bebe20
    show ep2 fri_arcade_julia_laughs with d
    julia "Haha, and you think I care about that?" id ep2_05_the_game_1c437405
    show ep2 fri_arcade_julia_talks with d
    julia "You should've seen my place in Tokyo." id ep2_05_the_game_76d11a0a
    julia "Anyway, what console is it?" id ep2_05_the_game_01eaddba
    show ep2 fri_arcade_julia_silent with d
    simon "It's a Super System 64." id ep2_05_the_game_75f736e6
    show ep2 fri_arcade_julia_excited with d
    julia "I CAN'T BELIEVE IT!" id ep2_05_the_game_ea3f5f0f
    julia "I just have to see it!" id ep2_05_the_game_3635c358
    show ep2 fri_arcade_julia_talks with d
    julia "Do you know how hard it is to find one of those nowadays?" id ep2_05_the_game_a83cb654
    show ep2 fri_arcade_simon_thinking with d
    simon "(She's really into this.)" id ep2_05_the_game_187930f6
    show ep2 fri_arcade_julia_talks with d
    julia "Do you have any roommates?" id ep2_05_the_game_073f307e
    show ep2 fri_arcade_julia_silent with d
    simon "No, I live by myself." id ep2_05_the_game_190f3906
    show ep2 fri_arcade_julia_okay with d
    julia "Okay... But we're only going there to play video games." id ep2_05_the_game_420ce323
    julia "No funny business." id ep2_05_the_game_107819e5
    show ep2 fri_arcade_simon_thinking with d
    simon "(She's sending a lot of mixed signals.)" id ep2_05_the_game_03089108
    simon "(I'm so confused!)" id ep2_05_the_game_7ed76db5
    show ep2 fri_arcade_simon_go with wipeleft
    simon "Want to get going?" id ep2_05_the_game_562c78da
    stop music fadeout 8
    jump ep2_05b_julia_play
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
