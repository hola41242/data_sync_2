label ep2_03_emily:
    show ep2 thu_emily_clean with long_fade
    play music skipping fadein 0.0 volume 0.35
    simon "(I'd better start thinking about cleaning up this mess.)" id ep2_03_emily_ffc2b9ec
    show ep2 thu_emily_whatthe with d
    simon "What the...?" id ep2_03_emily_2f7e4b1f
    show ep2 thu_emily_underwear with d
    simon "(Why am I not wearing any underwear?!)" id ep2_03_emily_0ca8996b
    show ep2 thu_emily_insane with d
    simon "(What an insane night.)" id ep2_03_emily_d93ca020
    play sound bath fadein 0.5
    show ep2 thu_emily_lose with fade

    simon "(How the hell did I lose my underwear?)" id ep2_03_emily_ef08d901
    show ep2 thu_emily_other with wipeleft
    stop sound fadeout 1
    simon "(Where's the other pair I like?)" id ep2_03_emily_5907391e
    simon "(These will do.)" id ep2_03_emily_ea86be9c
    show ep2 thu_emily_thedoor with wiperight
    simon "Huh?" id ep2_03_emily_196da51b
    simon "(Did I leave my door open when I got home last night?)" id ep2_03_emily_c5b4428f
    play sound door volume 0.7
    show ep2 thu_emily_hall with d
    simon "Hmmm." id ep2_03_emily_6171f5f6
    show ep2 thu_emily_hall2 with d
    pause
    stop music fadeout 5
    show ep2 thu_emily_outside with fade
    simon "(Hmm...)" id ep2_03_emily_b9c55da2
    simon "(Nothing unusual out here.)" id ep2_03_emily_bf5b7e0d
    simon "(I should just stay home, rest up, and forget all about it.)" id ep2_03_emily_45192ff0
    play music birthday fadein 2 volume 0.1
    show ep2 thu_emily_bags with long_dissolve
    simon "(Huh?)" id ep2_03_emily_b5a42478
    show ep2 thu_emily_past with d
    simon "Ummm... Emily, would you like some help?" id ep2_03_emily_d722f019
    show ep2 thu_emily_help with d
    emily "Oh! Thanks, neighbor." id ep2_03_emily_18916c26
    play sound paper_bag volume 0.75
    show ep2 thu_emily_thehelp with d
    emily "I appreciate it." id ep2_03_emily_afcc988f
    show ep2 thu_emily_towel with d
    emily "So, did you ever find yourself a towel?" id ep2_03_emily_7c694021
    show ep2 thu_emily_right with d
    simon "(Holy shit. That's right!)" id ep2_03_emily_bb591048
    simon "(Where did that towel come from?)" id ep2_03_emily_8068e29d
    show ep2 thu_emily_here with fade
    emily "Well, here we are." id ep2_03_emily_426abd5e
    show ep2 thu_emily_youok with d
    emily "Are you okay, [name]?" id ep2_03_emily_0cf95314
    show ep2 thu_emily_thinking with d
    simon "Yeah, I've just been thinking..." id ep2_03_emily_00270984
    show ep2 thu_emily_youok with d
    emily "About that night?" id ep2_03_emily_2a8e17ad

    show ep2 thu_emily_what with None
    simon "(What?! Did she have the same dream I did?!)" id ep2_03_emily_560dc897
    show ep2 thu_emily_whatnight with d
    simon "Night? What night are you talking about?" id ep2_03_emily_08e1b0ed
    show ep2 thu_emily_thatnight with d
    emily "The night you knocked on my door." id ep2_03_emily_f34986ca
    emily "Like, one of your first nights here." id ep2_03_emily_c629a189
    show ep2 thu_emily_meant with d
    emily "What did you think I meant?" id ep2_03_emily_cb4c1d27
    show ep2 thu_emily_confused with d
    simon "Sorry, I'm just a little confused is all." id ep2_03_emily_c28bba73
    stop music fadeout 4
    show ep2 thu_emily_thatnight with d
    emily "Either way, thanks for the help." id ep2_03_emily_640717c0
    show ep2 thu_emily_welcome with long_dissolve

    simon "You're welcome." id ep2_03_emily_937beae2
    jump ep2_03b_memories
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
