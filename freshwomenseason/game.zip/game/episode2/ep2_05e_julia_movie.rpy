label ep2_05_ending:
    show ep2 fri_game_ending_goodmovie with long_fade
    julia "This movie is so good!" id ep2_05_ending_f0740e0d
    show ep2 fri_game_ending_verygood with d
    simon "Yep, so good..." id ep2_05_ending_f171b215
    simon "(She's so pretty.)" id ep2_05_ending_3f126812
    show ep2 fri_game_ending_doingthis with medium_dissolve
    julia "Hmm?" id ep2_05_ending_16bd8b6c
    menu:
        "Kiss her"(True):
            $ ep2_julia_kiss = True
            $ player_choice("ep2_julia_kiss:true")
            $ points_julia += 1
            play music like_seasons_change fadein 4 volume 0.17
            show ep2 fri_game_ending_outfit with long_dissolve
            simon "I think I prefer this look to your work uniform." id ep2_05_ending_2e1d7b6d
            show ep2 fri_game_ending_doingit with long_dissolve
            julia "(Ahh... He actually did it!)" id ep2_05_ending_a4b6749d
            julia "(I wonder if I'm doing this right.)" id ep2_05_ending_ba45e777
            julia "(I just hope he likes it.)" id ep2_05_ending_464fbab3
            show ep2 fri_game_ending_julia_bitelips with d
            julia "(He's so gentle...)" id ep2_05_ending_e72dca4a
            julia "(He picked the absolute perfect time to kiss me!)" id ep2_05_ending_a0699da8
            show ep2 fri_game_ending_rightway with d
            julia "(I can barely control myself.)" id ep2_05_ending_b179748a
            julia "(My body's moving on its own!)" id ep2_05_ending_d09e174e
            show ep2 fri_game_ending_toofast with d
            julia "(I don't want this to go too fast, but...)" id ep2_05_ending_1c30f73a
            julia "I hope you're okay with this." id ep2_05_ending_ac7e5703
            show ep2 fri_game_ending_simon_good with d
            simon "I'm good with it if you are." id ep2_05_ending_f9dcbbb8
            show ep2 fri_game_ending_gentleman with d
            julia "(What a gentleman!)" id ep2_05_ending_3f3d0402
            julia "(Now that I have your permission...)" id ep2_05_ending_0e9b9fb2
            show ep2 fri_game_ending_happening with medium_dissolve
            julia "Ah..." id ep2_05_ending_5e76aabf
            julia "(I can't believe this is really happening...)" id ep2_05_ending_2620b7c2
            julia "[name]..." id ep2_05_ending_638653d2
            show ep2 fri_game_ending_barelytalk with d
            julia "(I can barely get the words out!)" id ep2_05_ending_392a3543
            show ep2 fri_game_ending_simoni with d
            julia "[name], I..."
            julia "(I'm getting so wet!)" id ep2_05_ending_709f538c
            julia "(I can't just blurt that out though!)" id ep2_05_ending_c5e8707a
            show ep2 fri_game_ending_whatswrong with d
            simon "What's wrong?" id ep2_05_ending_d2fd4fc6
            show ep2 fri_game_ending_canthelp with d
            simon "(I can't help myself...)" id ep2_05_ending_0b95a445
            simon "(My dick's throbbing!)" id ep2_05_ending_614555df
            julia "(What is this feeling?)" id ep2_05_ending_3b67febf
            show ep2 fri_game_ending_notice with d
            julia "(Will he notice how wet I am?)" id ep2_05_ending_d3e580c9
            show ep2 fri_game_ending_comingatme with d
            simon "(Wow, she's coming at me with everything she's got!)" id ep2_05_ending_4b3d3a66
            julia "(His kisses make me feel so good...)" id ep2_05_ending_0c149441
            julia "(But I'm not sure what I'm even doing.)" id ep2_05_ending_a91acc96
            show ep2 fri_game_ending_insideme with medium_dissolve
            julia "(What's this heat I've got raging inside me?)" id ep2_05_ending_3a713007
            julia "(I've never gone this far with a guy before.)" id ep2_05_ending_fcd76258
            julia "(It feels like I'm going to explode.)" id ep2_05_ending_f1e33927
            show ep2 fri_game_ending_explode with long_dissolve
            julia "(But it's an explosion I so want to happen!)" id ep2_05_ending_01ed5d72
            simon "(She's panting. Has she never had sex with a guy before?)" id ep2_05_ending_82448b38
            show ep2 fri_game_ending_allover with long_dissolve
            julia "(I want to feel his hands all over my body!)" id ep2_05_ending_35d40280
            show ep2 fri_game_ending_handling with medium_dissolve
            simon "(She seems nervous, but if that's true, she sure is handling the situation well!)" id ep2_05_ending_9cc2956d
            show ep2 fri_game_ending_ahand with medium_dissolve
            simon "(Let me give her a hand.)" id ep2_05_ending_7ba0bcf5
            show ep2 fri_game_ending_toofar with d
            julia "Aahhh..." id ep2_05_ending_fa010e88
            simon "(Am I taking things too far?)" id ep2_05_ending_00edddba
            show ep2 fri_game_ending_touched with d
            julia "(Mmmm... No one's ever touched me like this before!)" id ep2_05_ending_45c776b3
            show ep2 fri_game_ending_softlips with long_dissolve
            julia "(His lips are so soft...)" id ep2_05_ending_2b5f4d12
            julia "(I wonder what they'd feel like on my nipples.)" id ep2_05_ending_c749687d
            show ep2 fri_game_ending_experience with long_dissolve
            simon "(She's a great kisser for someone with seemingly so little experience.)" id ep2_05_ending_81ad310f
            julia "(Am I going too far?)" id ep2_05_ending_0c2dad8d
            simon "(Does she want me to go further?)" id ep2_05_ending_4a83732a
            show ep2 fri_game_ending_simon2 with d
            julia "[name], I..."
            stop music
            play sound phone_vibrate2 volume 0.1
            show ep2 fri_game_ending_allright with None
            "*Bzzzzt.*" id ep2_05_ending_3bd6e1e5
            simon "What's wrong?"
            show ep2 fri_game_ending_mymom with d
            julia "It's my mom!" id ep2_05_ending_7a302d96
            show ep2 fri_game_ending_behome with long_dissolve
            julia "My god, she's so controlling!" id ep2_05_ending_9cac6412
            show ep2 fri_game_ending_runhome with long_dissolve
            julia "I have to go home." id ep2_05_ending_be65b7e6
            menu:
                "Ask her to stay"(True):
                    play music midsummer_waltz volume 0.15 
                    show ep2 fri_game_ending_longer with d
                    simon "Why don't you stay a little longer?" id ep2_05_ending_1c2acba6
                    show ep2 fri_game_ending_could with d
                    julia "I so wish I could!" id ep2_05_ending_3e57f413
                    show ep2 fri_game_ending_icant with long_dissolve
                    julia "But I can't..." id ep2_05_ending_2722ea66
                    show ep2 fri_game_ending_imglad with d
                    julia "I'm glad to hear you say that though." id ep2_05_ending_bfe78cc1
                    show ep2 fri_game_ending_holdback with long_dissolve
                    julia "(I just barely peeled myself away from him!)"
                    julia "(I really wanted to stay!)" id ep2_05_ending_c15a3524
                    show ep2 fri_game_ending_yousure with d
                    simon "Are you sure?" id ep2_05_ending_01ccac2f
                    simon "Is there anything I could do to change your mind?" id ep2_05_ending_fa78ffbc
                    show ep2 fri_game_ending_noneed with d
                    julia "You don't need to do anything." id ep2_05_ending_8f64dfb6
                    julia "But if you want to see me again and spend more time together..." id ep2_05_ending_a34a3f1d
                    show ep2 fri_game_ending_letgo with medium_dissolve
                    julia "You have to let me go." id ep2_05_ending_789ea8af
                    julia "I mean, she can't ground me or anything." id ep2_05_ending_7dbc92f6
                    julia "But I really don't want to listen to another one of her speeches about some guy knocking me up." id ep2_05_ending_ca549934
                    play sound dress volume 0.5
                    show ep2 fri_game_ending_soclose with long_dissolve
                    simon "(Damn!)" id ep2_05_ending_0fb65e43
                    show ep2 fri_game_ending_moretime with long_dissolve
                    julia "But I'll definitely be back, and we'll have longer next time." id ep2_05_ending_b98fcf80
                    stop music fadeout 6
                    show ep2 fri_game_ending_begreat with wiperight
                    simon "That would be great!" id ep2_05_ending_d2f4107f
                    julia "See you, [name]!"
                    $ points_julia += 1
                "Let her go":
                    show ep2 fri_game_ending_shame with long_dissolve
                    simon "It's a shame you have to go." id ep2_05_ending_dfe8e90c
                    play sound dress volume 0.5
                    show ep2 fri_game_ending_behave with long_dissolve
                    julia "If you behave, I might be able to come back another day." id ep2_05_ending_73681fc1
                    stop music fadeout 3
                    show ep2 fri_game_ending_begreat with wipeleft
                    julia "See you, [name]!"
                    simon "See you, Julia!" id ep2_05_ending_4806190c
        "Don't kiss her":
            $ ep2_julia_kiss = False
            $ player_choice("ep2_julia_kiss:false")
            $ points_julia -= 1
            show ep2 fri_game_ending_badidea with d
            simon "(Right...)" id ep2_05_ending_95bf7d33
            simon "(That's not a great idea.)" id ep2_05_ending_9ab01e8e
            show ep2 fri_game_ending_focus with d
            simon "(Better to just focus on the movie.)" id ep2_05_ending_4f87b0c3
            show ep2 fri_game_ending_didntgo with long_dissolve
            julia "That didn't go how I expected." id ep2_05_ending_294e6b8e
            show ep2 fri_game_ending_themovie with d
            simon "You mean the movie?" id ep2_05_ending_6d4ced5d
            play sound dress2 volume 0.5
            show ep2 fri_game_ending_yesmovie with long_dissolve
            julia "Sure, the movie..." id ep2_05_ending_a0ee9a57
            julia "It's getting late. I'd better be going." id ep2_05_ending_5b2ad3b1
            play sound dress volume 0.5
            show ep2 fri_game_ending_youok with long_dissolve
            simon "Is everything all right?"
            show ep2 fri_game_ending_worry with d
            julia "Yeah, everything's fine!" id ep2_05_ending_e8619bae
            julia "I had a great time." id ep2_05_ending_4e7db528
            show ep2 fri_game_ending_seeyou with long_dissolve
            julia "See you, [name]!"
            simon "See you!" id ep2_05_ending_504fdea7


    jump ep2_06_night_job
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
