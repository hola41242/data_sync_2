label ep2_07_sue_conversation:
    show ep2 fri_storage_b_sue_college with fade
    sue "So, how's college life?" id ep2_07_sue_conversation_f2c85460
    show ep2 fri_storage_b_simon_smalltalk with medium_dissolve
    simon "(Is she really making small talk right now?)" id ep2_07_sue_conversation_3e23bc0b
    simon "(That's weird.)" id ep2_07_sue_conversation_866d5da3
    simon "(Is she trying to trick me into letting something slip?)" id ep2_07_sue_conversation_de9c4732
    show ep2 fri_storage_b_simon_talks with medium_dissolve
    simon "I guess you could say it's going well." id ep2_07_sue_conversation_7fba303b
    simon "But classes don't start till next week." id ep2_07_sue_conversation_bd3b390b
    show ep2 fri_storage_b_sue_talks with d
    sue "Oh, really?" id ep2_07_sue_conversation_3b3b4976
    sue "Auntie Susan said you had to go there this week." id ep2_07_sue_conversation_83095f01
    show ep2 fri_storage_b_sue_silent with d
    simon "I had to go sort some things out." id ep2_07_sue_conversation_4c4e9fba
    simon "A friend helped." id ep2_07_sue_conversation_778d9903
    show ep2 fri_storage_b_sue_talks with d
    sue "You're already making friends then?" id ep2_07_sue_conversation_d86a7b4c
    show ep2 fri_storage_b_sue_silent with d
    simon "Just two. They're both freshmen." id ep2_07_sue_conversation_a5e80672
    show ep2 fri_storage_b_sue_talks with d
    sue "What are these friends like?" id ep2_07_sue_conversation_7129a975
    simon "(She seems genuinely curious!)" id ep2_07_sue_conversation_dd9d77c7
    show ep2 fri_storage_b_simon_talks with d
    simon "They're nice. Their names are Chloe and Dylan..." id ep2_07_sue_conversation_48b0a733
    show ep2 fri_storage_b_simon_dylan with d
    simon "(Speaking of Dylan, I wonder where he even is...)" id ep2_07_sue_conversation_a95e5de6
    show ep2 fri_storage_b_sue_simon with d
    sue "Umm, Earth to [name]."
    show ep2 fri_storage_b_simon_right with d
    simon "Oh, right!" id ep2_07_sue_conversation_2543e950
    simon "I forgot to ask." id ep2_07_sue_conversation_eb39f216
    show ep2 fri_storage_b_simon_talks with d
    simon "Are you going to college too?" id ep2_07_sue_conversation_1a0b900c
    show ep2 fri_storage_b_sue_waiting with d
    sue "I'm still waiting to hear back from the colleges I applied to." id ep2_07_sue_conversation_b5618b60
    show ep2 fri_storage_b_simon_dylan with d
    simon "(Colleges? Plural?)" id ep2_07_sue_conversation_a08b3fa6
    simon "(She must be really smart if she applied to several.)" id ep2_07_sue_conversation_12ba5a4b
    show ep2 fri_storage_b_simon_talks with d
    simon "Did you also apply to Minerva Bay College?" id ep2_07_sue_conversation_694e2627
    show ep2 fri_storage_b_sue_mad with d
    sue "Not in your wildest dreams. I wouldn't be any classmate of yours!" id ep2_07_sue_conversation_60a2d14a
    show ep2 fri_storage_b_simon_sorry with d
    stop music fadeout 4

    simon "All right. Doesn't hurt to ask." id ep2_07_sue_conversation_a71f88fc

    show ep2 fri_storage_b_simon_all with medium_fade
    simon "I think that's everything." id ep2_07_sue_conversation_b81a6605
    show ep2 fri_storage_b_sue_seemsso with d
    sue "So it seems..." id ep2_07_sue_conversation_f7f373a4
    play sound door_heavy volume 0.5
    show ep2 fri_storage_b_simon_what with d
    simon "What was that?" id ep2_07_sue_conversation_78cb84f6

    play music the_fight volume 0.15
    show ep2 fri_storage_b_sue_auntie with d
    sue "I think that was auntie." id ep2_07_sue_conversation_61b93cbe
    show ep2 fri_storage_b_simon_auntie with d
    simon "(Auntie. That never gets old.)"
    show ep2 fri_storage_b_simon_lock with None
    simon "Wait, did she just lock us in here?" id ep2_07_sue_conversation_0bab3081
    show ep2 fri_storage_b_sue_not with medium_dissolve
    play sound lock2 volume 0.7
    sue "No way!" id ep2_07_sue_conversation_73ef9a8b
    show ep2 fri_storage_b_simon_yousaid with d
    simon "You were saying...?" id ep2_07_sue_conversation_88ee74c3
    show ep2 fri_storage_b_sue_forgot with d
    sue "I can't believe she forgot me back here again!" id ep2_07_sue_conversation_b200b96d
    show ep2 fri_storage_b_simon_again with d
    simon "Again?" id ep2_07_sue_conversation_c471f6b2
    show ep2 fri_storage_b_sue_forgot with d
    sue "Yes. It's happened before." id ep2_07_sue_conversation_74c66914
    show ep2 fri_storage_b_sue_minute with medium_dissolve
    sue "She'll be back in just a minute." id ep2_07_sue_conversation_57dd33a9
    sue "She'll remember before she gets to her car." id ep2_07_sue_conversation_9d6a06e0
    show ep2 fri_storage_b_simon_wait with medium_dissolve
    simon "We just have to wait..." id ep2_07_sue_conversation_a965b26d
    show ep2 fri_storage_b_sue_yes with d
    sue "I see." id ep2_07_sue_conversation_0fe0d54d
    play sound engine volume 0.5
    show ep2 fri_storage_b_simon_sue with d
    pause
    play sound car_pass_by_3 volume 0.5
    show ep2 fri_storage_b_simon_forgot with wipeleft
    simon "I think she actually forgot you this time." id ep2_07_sue_conversation_e35311c9
    show ep2 fri_storage_b_sue_cantbe with d
    sue "That can't be..." id ep2_07_sue_conversation_6a1e3cf9
    simon "What now?" id ep2_07_sue_conversation_a57f6d41
    show ep2 fri_storage_f_sue_beback with d
    sue "She'll be back for us. I'm sure of it." id ep2_07_sue_conversation_653ec3a7
    sue "She even left the AC on." id ep2_07_sue_conversation_eab9b1f0
    stop sound fadeout 2
    show ep2 fri_storage_f_simon_callher with d
    simon "Can't we — I don't know — call her?" id ep2_07_sue_conversation_ce5664f8
    show ep2 fri_storage_f_sue_talks with d
    sue "I get no signal in here." id ep2_07_sue_conversation_98b01ae9
    show ep2 fri_storage_f_sue_silent with d
    simon "What about Wi-Fi?" id ep2_07_sue_conversation_67756f3d
    show ep2 fri_storage_f_sue_talks with d
    sue "Nothing." id ep2_07_sue_conversation_fa4717f1
    sue "She always remembers to turn off the router before she leaves." id ep2_07_sue_conversation_e40a2871
    show ep2 fri_storage_f_sue_silent with d
    simon "Yet she forgets the air conditioning." id ep2_07_sue_conversation_2d676f1b
    show ep2 fri_storage_f_sue_talks with d
    sue "She only forgot the AC in here." id ep2_07_sue_conversation_867caef8
    sue "The one in the store is probably off." id ep2_07_sue_conversation_19283dbf
    show ep2 fri_storage_f_simon_tool with medium_dissolve
    simon "There must be something in one of these boxes that can help!" id ep2_07_sue_conversation_b91e9a15
    simon "I should be able to find something to get that door open..." id ep2_07_sue_conversation_1de59215

    show ep2 fri_storage_f_sue_cant with d
    sue "We can't open the boxes!" id ep2_07_sue_conversation_341685a9
    show ep2 fri_storage_f_sue_horrible with medium_dissolve
    simon "Okay then. I guess I'll find something else and improvise..." id ep2_07_sue_conversation_48ef5b9d
    sue "Is it really so horrible..." id ep2_07_sue_conversation_df388e75
    show ep2 fri_storage_f_sue_withme with d
    sue "... to be stuck here with me?" id ep2_07_sue_conversation_7ce7f512
    show ep2 fri_storage_f_simon_what with d
    simon "Huh?!" id ep2_07_sue_conversation_708b4972
    show ep2 fri_storage_f_sue_angry with d
    sue "Why don't you just break the door down if you're so desperate to get away?"
    show ep2 fri_storage_f_simon_what with d
    simon "It's not that. I just..." id ep2_07_sue_conversation_848f65d5
    show ep2 fri_storage_f_simon_fine with long_dissolve
    simon "All right. We'll wait for Susan to come back." id ep2_07_sue_conversation_4fc45654
    simon "She's bound to remember soon, right?" id ep2_07_sue_conversation_676a2981
    show ep2 fri_storage_f_sue_fine with d
    sue "That's better." id ep2_07_sue_conversation_21b32e53
    show ep2 fri_storage_f_simon_thinking with d
    simon "(Well that change came out of nowhere.)" id ep2_07_sue_conversation_057d0598
    show ep2 fri_storage_f_sue_so with d
    sue "So..." id ep2_07_sue_conversation_9edd8db8

    if chose('ep1_agree_help_sue'):

        sue "What did you find out?" id ep2_07_sue_conversation_d55c3bd8
        show ep2 fri_storage_f_night with fade
        simon "Well, I guess now's as good a time as any..." id ep2_07_sue_conversation_dde976ba

        show ep2 fri_storage_f_night_after with long_fade
        simon "... And that's all I heard." id ep2_07_sue_conversation_2fa877fd
        show ep2 fri_storage_n_sue_surprised with fade
        sue "Wow, so your friend thinks auntie might have had something to do with Uncle Charlie's death?" id ep2_07_sue_conversation_29aee4d4
        show ep2 fri_storage_f_simon_talks with d
        simon "It's not that simple." id ep2_07_sue_conversation_ae8e8c8e
        simon "But the whole thing is very odd." id ep2_07_sue_conversation_b56aaed2
        show ep2 fri_storage_n_sue_thinking with d
        sue "This is a lot to process..." id ep2_07_sue_conversation_30df3416
        show ep2 fri_storage_n_shaking with d
    else:

        sue "How can I convince you to help me?" id ep2_07_sue_conversation_f91f7475
        show ep2 fri_storage_f_simon_talks with d
        simon "I don't understand your obsession with your aunt." id ep2_07_sue_conversation_d033d3f2
        simon "She seems like a pretty normal person to me." id ep2_07_sue_conversation_a7374020
        show ep2 fri_storage_f_sue_intuition with d
        sue "Call it intuition." id ep2_07_sue_conversation_25dd7b0f
        show ep2 fri_storage_f_sue_talks with d
        sue "Haven't you ever been so curious about something that it just takes over?" id ep2_07_sue_conversation_bc47c43d
        sue "Something you need to know so badly that it pushes you to the extremes?" id ep2_07_sue_conversation_5bf39106
        show ep2 fri_storage_f_sue_silent with d
        simon "(I get you, Sue.)" id ep2_07_sue_conversation_8ee340da
        show ep2 fri_storage_f_night with fade
        simon "(More than you know.)" id ep2_07_sue_conversation_8a1b6150
        show ep2 fri_storage_f_night_after with long_dissolve
        pause 0.5
        show ep2 fri_storage_n_shaking with medium_fade

    simon "You're shivering." id ep2_07_sue_conversation_4f145cba
    show ep2 fri_storage_n_sue_acon with d
    sue "I told you, she left the AC on!" id ep2_07_sue_conversation_2ab9b7e0
    show ep2 fri_storage_f_sue_silent with d
    simon "And there's no way for us to turn it off?" id ep2_07_sue_conversation_f731187b
    show ep2 fri_storage_f_sue_talks with d
    sue "Not from in here." id ep2_07_sue_conversation_2b0a3b0a
    sue "Only from the store." id ep2_07_sue_conversation_9b9d931e
    show ep2 fri_storage_f_sue_silent with d
    simon "I don't think Susan's coming." id ep2_07_sue_conversation_85a92d02
    show ep2 fri_storage_n_simon_opendoor with medium_dissolve
    stop music fadeout 3
    simon "Time to get that door open!" id ep2_07_sue_conversation_cb82b566

    play music unto_thee fadein 3 volume 0.15

    show ep2 fri_storage_n_sue_dont with d

    sue "Don't!" id ep2_07_sue_conversation_a45d7336
    sue "Stay with me!" id ep2_07_sue_conversation_2c6784aa
    sue "I don't want to be cold." id ep2_07_sue_conversation_7e0ddb44
    sue "And you won't be able to get that door open anyway." id ep2_07_sue_conversation_e79a3409
    show ep2 fri_storage_n_simon_fine with medium_dissolve
    simon "All right." id ep2_07_sue_conversation_95e4699b
    simon "But it's only going to get colder." id ep2_07_sue_conversation_6c17012b
    show ep2 fri_storage_f_sue_talks with d
    sue "Aren't you cold too?"
    show ep2 fri_storage_n_simon_hot with d
    simon "Not a chance." id ep2_07_sue_conversation_ed0cdf1e
    simon "My body's always been on the warm side." id ep2_07_sue_conversation_9044d202
    show ep2 fri_storage_n_sue_heh with d
    sue "Hmm..." id ep2_07_sue_conversation_1a0c7a5d
    show ep2 fri_storage_n_simon_thinks with medium_dissolve
    simon "(Was that a grin I saw?)" id ep2_07_sue_conversation_4b1c9e3b
    show ep2 fri_storage_h_sue_hugs with d
    simon "(What's going on??)" id ep2_07_sue_conversation_354b8d36
    show ep2 fri_storage_h_sue_staywarm with d
    sue "No need to stare. Just huddling together for warmth." id ep2_07_sue_conversation_8527843f

    menu:
        "Hold her"(True):
            $ ep2_sue_hug = True
            show ep2 fri_storage_h_sue_what with medium_dissolve
            sue "What do you think you're doing?" id ep2_07_sue_conversation_19c57586
            show ep2 fri_storage_h_simon_warm with d
            simon "Huddling together for warmth?" id ep2_07_sue_conversation_3004bcee
            show ep2 fri_storage_h_simon_youreright with d
            simon "You're right though. I should have asked first." id ep2_07_sue_conversation_3a852e0b
            show ep2 fri_storage_h_sue_wait with long_dissolve
            sue "Wait!" id ep2_07_sue_conversation_e2a9fc27
            sue "It's okay..."
            show ep2 fri_storage_h_sue_notcold with long_dissolve
            sue "You really don't feel cold?" id ep2_07_sue_conversation_15cd912d
            show ep2 fri_storage_h_simon_mother with d
            simon "My mother told me the house I grew up in was always freezing, so I guess I just adapted to it." id ep2_07_sue_conversation_ff12072b
            $ points_sue += 1
        "Stay how you are":
            $ ep2_sue_hug = False

            sue "You shouldn't just sit there doing nothing either." id ep2_07_sue_conversation_a77b5111
            show ep2 fri_storage_h_sue_wait with d
            sue "Bring it in!" id ep2_07_sue_conversation_ac2482f9
            simon "You just said not to stare. How am I supposed to know what to do?"
            show ep2 fri_storage_h_sue_what with d
            sue "True, but it's freezing in here!" id ep2_07_sue_conversation_4b8aaa22


    jump ep2_08_sue_sexy
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
