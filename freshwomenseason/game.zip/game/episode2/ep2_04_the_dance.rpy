label ep2_04_the_dance:
    show ep2 thu_simonhome_phone with long_fade
    play sound phone_vibrate volume 0.15
    simon "(Right! Alyssa's dance thing is tonight!)" id ep2_04_the_dance_b627c04b
    simon "(I should get ready to go.)" id ep2_04_the_dance_25a58004
    show ep2 thu_simonhome_outside with fade
    simon "(I hope I won't be late.)" id ep2_04_the_dance_9ed46024


    play music crash fadein 8 volume 0.17
    show ep2 thu_dance_entrance with fade
    simon "(This looks like the place.)" id ep2_04_the_dance_b7133761
    show ep2 thu_dance_floor with wiperight
    simon "(I've never taken a dance lesson before...)" id ep2_04_the_dance_21b6705f
    show ep2 thu_dance_alyssa_hi with d
    alyssa "Hey, [name]!" id ep2_04_the_dance_f3962f89
    show ep2 thu_dance_alyssa_hug with d
    alyssa "I'm so glad you came!" id ep2_04_the_dance_90037f87
    alyssa "I thought you might have forgotten about me." id ep2_04_the_dance_18adffaa
    show ep2 thu_dance_simon_word with d
    simon "I'm a man of my word!" id ep2_04_the_dance_1ea49ebb
    show ep2 thu_dance_alyssa_worried with d
    alyssa "I've been thinking a lot about what you told me." id ep2_04_the_dance_2d0bee34
    alyssa "The accident and all." id ep2_04_the_dance_7ce3fb03
    show ep2 thu_dance_simon_word with d
    simon "No need to dwell on it. I'm fine. I swear." id ep2_04_the_dance_b708454b
    show ep2 thu_dance_alyssa_brave with d
    alyssa "You're so brave to push onward." id ep2_04_the_dance_fb92fc0b
    alyssa "Let's get right to it then!" id ep2_04_the_dance_21081a50

    show ep2 thu_dance_alyssa_start with wipedown
    alyssa "We'll start with some light stretching exercises." id ep2_04_the_dance_b5ba39ec
    alyssa "Are you ready?" id ep2_04_the_dance_b8c1824d
    simon "Born ready." id ep2_04_the_dance_b62a1411

    stop music
    play sound bone volume 0.7
    show ep2 thu_dance_simon_stretch with vpunch
    simon "!!!" id ep2_04_the_dance_ad7bf70d
    show ep2 thu_dance_simon_ribs with d
    simon "(I had no idea she was so strong!)" id ep2_04_the_dance_7ecf13e2
    simon "(I think I just broke a rib or two.)" id ep2_04_the_dance_583c75f5
    show ep2 thu_dance_simon_stretch with d
    alyssa "Wow. You're quite flexible!" id ep2_04_the_dance_c0f2ebee
    show ep2 thu_dance_alyssa_allset with d
    alyssa "Great! You're all set." id ep2_04_the_dance_d3aa7935

    play music a_big_adventure fadein 1.0 volume 0.15
    show ep2 thu_dance_alyssa_myturn with wipeup
    alyssa "My turn now." id ep2_04_the_dance_83ea9701
    simon "Wow." id ep2_04_the_dance_64ff62f1
    show ep2 thu_dance_alyssa_what with d
    alyssa "Did you say something?" id ep2_04_the_dance_bbcf800b
    simon "(Damn, I'm impressed.)" id ep2_04_the_dance_d28bd8ba
    alyssa "You all right?" id ep2_04_the_dance_30713b5f
    show ep2 thu_dance_simon_back with d
    simon "Yeah. Sure." id ep2_04_the_dance_7073e2d9
    show ep2 thu_dance_alyssa_nervous with wipeup
    alyssa "Feeling nervous?" id ep2_04_the_dance_14a1da73
    show ep2 thu_dance_simon_she with d
    simon "Just a little." id ep2_04_the_dance_e4e86bae
    show ep2 thu_dance_simon_looking with d
    simon "When is the instructor coming?" id ep2_04_the_dance_6404d45f
    simon "Is he running late?" id ep2_04_the_dance_130afc74
    show ep2 thu_dance_alyssa_he with None
    alyssa "He?" id ep2_04_the_dance_a4ae7519
    show ep2 thu_dance_simon_she with d
    simon "She...?" id ep2_04_the_dance_9b8b66af
    show ep2 thu_dance_alyssa_he with None
    alyssa "She?" id ep2_04_the_dance_5e2ce3e6
    show ep2 thu_dance_simon_she with d
    simon "... They?" id ep2_04_the_dance_0940f920
    show ep2 thu_dance_alyssa_laughs with d
    alyssa "No, the instructor isn't running late." id ep2_04_the_dance_35837fdd
    alyssa "She's already here." id ep2_04_the_dance_1e529ee4
    show ep2 thu_dance_alyssa_claire with d
    alyssa "Claire, your posture is all wrong." id ep2_04_the_dance_60e43763
    show ep2 thu_dance_alyssa_tyler with d
    alyssa "And, Tyler, I don't see you stretching." id ep2_04_the_dance_d01ea64b
    tyler "Sorry, Miss Alyssa." id ep2_04_the_dance_5c8f9a1b
    show ep2 thu_dance_simon_teacher with d
    simon "You're the teacher?" id ep2_04_the_dance_e0e4ec92
    show ep2 thu_dance_alyssa_gather with d
    alyssa "Gather 'round, class. We have a new student joining us today." id ep2_04_the_dance_a15ef3b7
    alyssa "His name is [name], and I want you all to make him feel welcome." id ep2_04_the_dance_5ecaff00
    show ep2 thu_dance_alyssa_students with wipedown
    claire "Welcome to the class, [name]." id ep2_04_the_dance_3bd70581
    tyler "What's up, man?" id ep2_04_the_dance_469c46e6

    stop music fadeout 6.0
    show ep2 thu_dance_alyssa_basic with medium_dissolve
    alyssa "Tonight, we're rehearsing our next performance." id ep2_04_the_dance_f99d60e6
    alyssa "It'd be best if you followed along as we practiced the basics, then just watched from the side." id ep2_04_the_dance_1fc509ba
    simon "I'm cool with that." id ep2_04_the_dance_bfd7d750

    play music oasis fadein 1 volume 0.17
    show ep2 thu_dance_alyssa_helps_claire with wipeleft

    simon "(She really pays attention to the needs of each of her students.)"
    show ep2 thu_dance_alyssa_helps_other with wiperight
    simon "(She seems to know their strengths and weaknesses.)"
    show ep2 thu_dance_alyssa_helps_simon with wipeleft
    alyssa "You're doing great, [name]!" id ep2_04_the_dance_abbb197f
    alyssa "Here. Let me help." id ep2_04_the_dance_db742141
    show ep2 thu_dance_alyssa_leg with d
    alyssa "This leg goes here." id ep2_04_the_dance_40c3b113
    show ep2 thu_dance_simon_shaking with d
    alyssa "Haha. You're trembling!" id ep2_04_the_dance_06d99bc4
    alyssa "It's okay to be nervous though." id ep2_04_the_dance_67bd378c
    show ep2 thu_dance_alyssa_watches with d
    alyssa "You have fantastic form." id ep2_04_the_dance_89d01ddd
    alyssa "I think that's it for the basics." id ep2_04_the_dance_77b77a9c
    show ep2 thu_dance_alyssa_class with d
    alyssa "I'll have a quick word with my students, then we'll start the rehearsal." id ep2_04_the_dance_bda0c88e
    alyssa "You're welcome to stay and watch of course." id ep2_04_the_dance_dbd66039
    show ep2 thu_dance_simon_see with d
    simon "Will I be able to see you dance?" id ep2_04_the_dance_df2dfb3a
    show ep2 thu_dance_alyssa_pose2 with d
    alyssa "Yes." id ep2_04_the_dance_e455da7a
    alyssa "And with permission this time." id ep2_04_the_dance_1743e228
    show ep2 thu_dance_alyssa_pose with d
    simon "I'm looking forward to it then." id ep2_04_the_dance_2ba4f0d8

    stop music fadeout 4
    show ep2 thu_dance_simon_bench with wiperight
    simon "(That was nice.)" id ep2_04_the_dance_da3bdd8f
    simon "(Helped me take my mind off my problems.)" id ep2_04_the_dance_4e46cf64

    play music boxes volume 0.2 fadein 2.0
    show ep2 thu_dance_students_dance1 with fade
    simon "(They're about to start.)" id ep2_04_the_dance_49cf5f74
    show ep2 thu_dance_students_dance2 with fade
    simon "(Oh.)" id ep2_04_the_dance_85a6baa7
    show ep2 thu_dance_students_dance3 with fade
    simon "(They're really good!)" id ep2_04_the_dance_e77aad25
    show ep2 thu_dance_students_dance4 with fade
    simon "(And she's fantastic!)" id ep2_04_the_dance_b04993be

    stop music
    play sound bone2 volume 0.4
    show ep2 thu_dance_tyler_ankle with vpunch
    tyler "OUCH!" (what_bold=True)
    show ep2 thu_dance_alyssa_ohno with d
    alyssa "Tyler, are you hurt?" id ep2_04_the_dance_09525a9a
    tyler "I think I sprained my ankle!" id ep2_04_the_dance_b46d478b
    alyssa "Oh, no!" id ep2_04_the_dance_d1c107ed
    tyler "It's not that bad." id ep2_04_the_dance_4395fc84
    alyssa "I think you should at least go to the hospital to get it checked!" id ep2_04_the_dance_caae9187
    show ep2 thu_dance_student_ido with d
    student_dance_male "I can take him." id ep2_04_the_dance_2d9772e5
    show ep2 thu_dance_simon_heok with medium_dissolve
    simon "Is he going to be okay?" id ep2_04_the_dance_743b9a07
    show ep2 thu_dance_alyssa_sure with d
    alyssa "I'm sure he'll be fine, but it's better to be safe than sorry." id ep2_04_the_dance_ee95f502
    show ep2 thu_dance_student_nextweek with d
    claire "But what are we going to do about next week?" id ep2_04_the_dance_31fb3f71
    show ep2 thu_dance_alyssa_recover with d
    alyssa "One thing at a time, right?" id ep2_04_the_dance_73b3c944
    alyssa "We should worry about Tyler first." id ep2_04_the_dance_37e50deb
    show ep2 thu_dance_alyssa_dismissed with d
    alyssa "Class dismissed." id ep2_04_the_dance_65f1eb4e
    alyssa "We can discuss how we're going to handle this over the weekend." id ep2_04_the_dance_7274d81f

    play music down_south_smile fadein 4 volume 0.1
    show ep2 thu_dance_simon_youok with wipeup
    simon "Are you all right?" id ep2_04_the_dance_9b2c87e1
    show ep2 thu_dance_alyssa_sorry with d
    alyssa "Yeah, I can't help but feel sorry though." id ep2_04_the_dance_c4fa0ac5
    alyssa "I should have been watching him more carefully." id ep2_04_the_dance_8597783b
    show ep2 thu_dance_simon_youok with d
    simon "You can't blame yourself for that." id ep2_04_the_dance_60fdb434
    simon "You warned him." id ep2_04_the_dance_89b72f90
    show ep2 thu_dance_alyssa_iguess with d
    alyssa "Yeah, I guess I did." id ep2_04_the_dance_9f66b245
    alyssa "But that doesn't make me any less responsible for him." id ep2_04_the_dance_d0c7c845
    show ep2 thu_dance_simon_goodhands with d
    simon "They're in good hands." id ep2_04_the_dance_d1fb89a2
    show ep2 thu_dance_simon_close with d
    simon "Do you need help closing up the place?" id ep2_04_the_dance_ca4f5052
    show ep2 thu_dance_alyssa_noneed with d
    alyssa "Oh, you really don't have to." id ep2_04_the_dance_cdec75fc
    simon "I'd like to though." id ep2_04_the_dance_86658503
    show ep2 thu_dance_alyssa_thankyou with wipedown
    alyssa "I'm thankful enough you came." id ep2_04_the_dance_f21ce65d
    alyssa "After tonight, I guess you're not too keen on signing up, huh?" id ep2_04_the_dance_7a5d6abe
    simon "Well..." id ep2_04_the_dance_bf4a2a91
    menu:
        "Join them"(True):
            show ep2 thu_dance_simon_yes with d
            simon "I liked what I saw today." id ep2_04_the_dance_b032c938
            simon "You obviously care a lot about your students." id ep2_04_the_dance_7da01e7c
            simon "I'd be honored to join you all." id ep2_04_the_dance_aabf6155
            show ep2 thu_dance_alyssa_really with d
            alyssa "Really?" id ep2_04_the_dance_1317a223
            alyssa "That's great!" id ep2_04_the_dance_ce497341
            $ points_alyssa += 1
            $ ep1_joindance = True
        "Not sure":
            show ep2 thu_dance_simon_wellsee with d
            simon "We'll see." id ep2_04_the_dance_83b015e1
            show ep2 thu_dance_alyssa_fair with d
            alyssa "That's fair. I won't force your hand." id ep2_04_the_dance_626af950
            $ ep1_joindance = False
    show ep2 thu_dance_clean with fade
    play sound clean volume 0.3
    pause
    show ep2 thu_dance_simon_everyday with medium_fade
    simon "Do you do this after every class?" id ep2_04_the_dance_743e07a0
    simon "It's so tiring!" id ep2_04_the_dance_4771541f
    show ep2 thu_dance_alyssa_getused with d
    alyssa "You get used to it." id ep2_04_the_dance_1ca3f919

    stop music fadeout 6

    alyssa "Thanks for the help tonight." id ep2_04_the_dance_6788b148
    show ep2 thu_dance_alyssa_place with medium_dissolve
    alyssa "As a way of saying thanks, I'd like to take you up to my favorite place." id ep2_04_the_dance_7224fd55
    show ep2 thu_dance_alyssa_follow with long_dissolve
    alyssa "Follow me." id ep2_04_the_dance_b05e6398
    jump ep2_04b_roof
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
