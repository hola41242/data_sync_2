label ep2_08_sue_sexy:
    $ award_manager.block_notify()
    show ep2 fri_sexy_simon_secret with d
    simon "The secret is to keep your hands warm." id ep2_08_sue_sexy_3c372163
    simon "You can use the insides of your thighs to warm them." id ep2_08_sue_sexy_0083ac79
    show ep2 fri_sexy_sue_howso with d
    sue "How so?" id ep2_08_sue_sexy_bc109a1a
    show ep2 fri_sexy_simon_likethis with d
    simon "Like this." id ep2_08_sue_sexy_15504b8c
    show ep2 fri_sexy_sue_sleepy with d
    sue "*Yawns.*" (what_italic=True)
    sue "Good to know..." id ep2_08_sue_sexy_78bbad5d
    show ep2 fri_sexy_simon_also with medium_dissolve
    simon "Uh..."
    simon "(Good night, Sue.)" id ep2_08_sue_sexy_d2f5790c
    show ep2 fri_sexy_simon_sleepy with d
    simon "(I don't feel as cold as she probably does.)" id ep2_08_sue_sexy_872452f2
    simon "(But the temperature is making me sleepy too.)" id ep2_08_sue_sexy_2f10a1ad
    show ep2 fri_sexy_simon_rest with long_dissolve
    simon "(Might as well get some rest.)" id ep2_08_sue_sexy_4da5b0bf
    show black as ep2 with longest_dissolve
    simon "Zzzzzzzz." id ep2_08_sue_sexy_ca8a5972
    show ep2 fri_sexy_sue_wakesup with long_fade

    sue "Hmm..." id ep2_08_sue_sexy_4cf21399
    sue "(It's absolutely freezing.)" id ep2_08_sue_sexy_b9b8517c
    show ep2 fri_sexy_sue_howhe with d
    sue "(How is he like this?)" id ep2_08_sue_sexy_d1e21752
    sue "(He's still so warm.)" id ep2_08_sue_sexy_c28e6982
    show ep2 fri_sexy_sue_wontmind with d
    sue "(I don't think he'll mind if I do this.)" id ep2_08_sue_sexy_8e4c6bf3
    show ep2 fri_sexy_simon_muchbetter with d
    sue "(Ahhhh...)" id ep2_08_sue_sexy_e713086b
    stop music fadeout 6

    show black as ep2 with longest_dissolve
    sue "(Much better...)" id ep2_08_sue_sexy_be77b441
    pause 1
    sue "Zzzzzzzz." id ep2_08_sue_sexy_36ff2d12
    pause 1
    simon "*Snores.*" id ep2_08_sue_sexy_3d2b8a83
    pause 1
    play sound power_off volume 0.8
    pause 0.5
    simon "Huh?" id ep2_08_sue_sexy_196da51b
    show ep2 fri_sexy_lightsout with longest_dissolve
label ep2_08_sue_sexy_replay:
    simon "(Did the power go out?)" id ep2_08_sue_sexy_replay_f523123c
    simon "(Or is this the mall saving energy or something?)" id ep2_08_sue_sexy_replay_52910468
    show ep2 fri_sexy_simon_acoff with d
    simon "(Well, at least this way the air conditioner is off.)" id ep2_08_sue_sexy_replay_355e8709
    simon "(And the cold air is slowly dissipating.)" id ep2_08_sue_sexy_replay_93df5cb3
    show ep2 fri_sexy_simon_suesleep with d
    simon "(Sue will be able to sleep better this way.)" id ep2_08_sue_sexy_replay_8e2ebd01

    show ep2 fri_sexy_simon_whatthe with d
    simon "(What the...?)" id ep2_08_sue_sexy_replay_b24719b1
    simon "(I guess she didn't quite understand what I meant.)" id ep2_08_sue_sexy_replay_057221f6
    show ep2 fri_sexy_simon_sheshot with d
    simon "(She's so mean to me that I haven't really stopped to appreciate how hot she is.)" id ep2_08_sue_sexy_replay_66c7b946
    show ep2 fri_sexy_simon_dangerous with d
    simon "(Being this close to her could prove to be quite dangerous...)" id ep2_08_sue_sexy_replay_5e2b5e8f
    show ep2 fri_sexy_simon_sweetperson with d
    simon "(I know underneath the tough girl mask she puts on, there's someone sweet and caring.)" id ep2_08_sue_sexy_replay_37409526
    simon "(She can be nice when she wants to be.)" id ep2_08_sue_sexy_replay_e205f2cd
    simon "(There was even that time she bought me a cup of coffee.)" id ep2_08_sue_sexy_replay_79f49dc7
    show ep2 fri_sexy_simon_benice with d
    simon "(That's right. She can be kind when she wants to be.)" id ep2_08_sue_sexy_replay_232a960e

    play music dont_mess_with_me volume 0.15
    show ep2 fri_sexy_simon_forgiving with None
    simon "(She's got such a hardcore resting bitch face, but she can be forgiving too.)" id ep2_08_sue_sexy_replay_4245e5b9
    simon "(Right?)" id ep2_08_sue_sexy_replay_f8a3e4b0
    show ep2 fri_sexy_sue_whatthefuck with d
    sue "WHAT THE FUCK DID YOU DO?!" id ep2_08_sue_sexy_replay_a6495f5f
    show ep2 fri_sexy_simon_forgiving with d
    simon "Hold on, it's just —" id ep2_08_sue_sexy_replay_b4d2c9a1
    show ep2 fri_sexy_simon_forgiving2 with d
    sue "It's just what?" id ep2_08_sue_sexy_replay_eccb33f4
    sue "Did you put my hand there?" id ep2_08_sue_sexy_replay_12734a25
    sue "You trying to take advantage of me while I sleep, pervert?" id ep2_08_sue_sexy_replay_00f6d07a
    show ep2 fri_sexy_sue_sodark with medium_dissolve
    sue "And why in the hell is it so dark in here?" id ep2_08_sue_sexy_replay_96163416
    show ep2 fri_sexy_simon_awoman with d
    simon "Wait, what?!" id ep2_08_sue_sexy_replay_bf5d5749
    simon "I was sleeping too." id ep2_08_sue_sexy_replay_fa7d8094
    simon "You're the one cradling my dick with your hand while I'm sleeping, getting me all hard." id ep2_08_sue_sexy_replay_0b822a29
    simon "But somehow this is my fault?" id ep2_08_sue_sexy_replay_0b819f12
    show ep2 fri_sexy_sue_blameme with d
    simon "Also, the power just went out!" id ep2_08_sue_sexy_replay_11a9947e
    simon "You going to blame that on me too?" id ep2_08_sue_sexy_replay_7c34044a
    show ep2 fri_sexy_sue_ididnt with d
    sue "I wasn't cradling your —" id ep2_08_sue_sexy_replay_1990d27a
    show ep2 fri_sexy_sue_theresmore with d
    simon "And what's more...!" id ep2_08_sue_sexy_replay_8ecc6ace
    simon "I risked my neck for you at Susan's house." id ep2_08_sue_sexy_replay_45e181cb
    simon "I've been nothing but nice to you, despite all the attitude." id ep2_08_sue_sexy_replay_f17aa16e
    show ep2 fri_sexy_simon_becauseyou with d
    simon "And you can't even thank me!" id ep2_08_sue_sexy_replay_71e4ac52
    simon "You just keep pushing me around, yelling, and calling me names. For what?!"
    show ep2 fri_sexy_sue_finally with d:
        yalign 0.0

    sue "Finally..." id ep2_08_sue_sexy_replay_0a5aafb8
    show ep2 fri_sexy_sue_realized with d
    sue "I just realized something..." id ep2_08_sue_sexy_replay_102030de
    show ep2 fri_sexy_sue_realized:
        yalign 0.0
        ease 6.0 yalign 1.0
    sue "... You do know how to talk like a man when you need to." id ep2_08_sue_sexy_replay_4bead815
    sue "I think that might deserve some sort of reward..." id ep2_08_sue_sexy_replay_8102c00a
    show ep2 fri_sexy_sue_rewarding with medium_dissolve
    sue "I might be able to do a little something for you..." id ep2_08_sue_sexy_replay_8436e115

    menu:
        "I want to see where this goes"(True):

            $ ep2_sue_stop = False
            $ player_choice("ep2_sue_stop:false")
            show ep2 fri_sexy_sue_rules with d
            sue "But first, let's set some ground rules..." id ep2_08_sue_sexy_replay_00fa4b2e
            show ep2 fri_sexy_simon_whatrules with d
            simon "(Rules?)" id ep2_08_sue_sexy_replay_e9a3c10c
            play sound body_thud volume 0.7
            show ep2 fri_sexy_simon_agh with hpunch
            simon "Agh!" id ep2_08_sue_sexy_replay_88240043
            show ep2 fri_sexy_sue_prettysimple2 with medium_dissolve
            sue "I'll keep it simple..." id ep2_08_sue_sexy_replay_6d309615
            show ep2 fri_sexy_sue_prettysimple with d
            sue "... You have two rules to follow." id ep2_08_sue_sexy_replay_29462729
            show ep2 fri_sexy_sue_ruleone with d
            sue "You can look..." id ep2_08_sue_sexy_replay_cce7ad10
            show ep2 fri_sexy_sue_canttouch with d
            sue "... But you can't touch!" id ep2_08_sue_sexy_replay_040039d7
            show ep2 fri_sexy_simon_stripclub with d
            simon "That's the rule they have at strip clubs." id ep2_08_sue_sexy_replay_15484da0
            show ep2 fri_sexy_simon_silence with d
            sue "It is." id ep2_08_sue_sexy_replay_966cafd6
            show ep2 fri_sexy_sue_ruletwo with d
            sue "But that's where the second rule comes in." id ep2_08_sue_sexy_replay_d2c5b46b
            show ep2 fri_sexy_sue_ruletwo2 with d
            simon "What's the second rule...?" id ep2_08_sue_sexy_replay_25905c70
            show ep2 fri_sexy_sue_icantouchyou with d
            sue "I can touch as much as I want." id ep2_08_sue_sexy_replay_b74bf6ec
            show ep2 fri_sexy_sue_generous with medium_dissolve
            sue "And I can be very generous when the mood strikes." id ep2_08_sue_sexy_replay_1e05691e
            simon "(Her tits are huge!)" id ep2_08_sue_sexy_replay_3fbda206
            simon "(Yet, they're so firm to the touch.)" id ep2_08_sue_sexy_replay_b1961439
            sue "Hmmm... I can already feel something growing down there." id ep2_08_sue_sexy_replay_332699d6
            show ep2 fri_sexy_sue_rubass with d
            sue "Do you like it when I grind my ass against your dick, [name]?" id ep2_08_sue_sexy_replay_de130611
            simon "So much!"
            show ep2 fri_sexy_sue_howmuch with d
            sue "And just how much is \"so much?\""
            simon "I absolutely love it!" id ep2_08_sue_sexy_replay_1ef00639
            simon "But it'd be even better without so many layers of clothes in the way." id ep2_08_sue_sexy_replay_f3199686
            show ep2 fri_sexy_sue_manyideas with d
            sue "Aren't you just full of ideas today...?" id ep2_08_sue_sexy_replay_25b742cf
            show ep2 fri_sexy_sue_gettinghot with medium_dissolve
            sue "But I must confess, it is getting hot in here..." id ep2_08_sue_sexy_replay_64435562
            show ep2 fri_sexy_sue_littleshow with d
            sue "Maybe I can put on a little show as a way of saying thanks." id ep2_08_sue_sexy_replay_ba7d8983
            show ep2 fri_sexy_sue_littleshow2 with d
            simon "Wow... Suddenly, helping you out feels very worth my time." id ep2_08_sue_sexy_replay_9e095c44
            show ep2 fri_sexy_sue_likeit with d
            sue "Do you like what you see?" id ep2_08_sue_sexy_replay_551d1945
            show ep2 fri_sexy_simon_doi with d
            simon "(Do I ever?)" id ep2_08_sue_sexy_replay_d5886f9d
            simon "(I've been waiting for this since the first time I saw you!)" id ep2_08_sue_sexy_replay_3318ec75
            show ep2 fri_sexy_simon_canti with d
            simon "Are you sure I can't sneak a feel?" id ep2_08_sue_sexy_replay_7d103ead
            show ep2 fri_sexy_sue_canttalk with d
            sue "No talking either." id ep2_08_sue_sexy_replay_53eb4452
            show ep2 fri_sexy_sue_enjoytheshow with d
            sue "Just enjoy the show." id ep2_08_sue_sexy_replay_e6d8582d
            sue "(I can tell he's enjoying himself.)" id ep2_08_sue_sexy_replay_7c39ecce
            show ep2 fri_sexy_simon_teasingme with d
            simon "Are you just going to tease me?" id ep2_08_sue_sexy_replay_552d083d
            sue "Easy does it... What's the rush?" id ep2_08_sue_sexy_replay_8c082738
            show ep2 fri_sexy_sue_alotmore with d
            sue "There's so much more to come." id ep2_08_sue_sexy_replay_a0b1e2f7
            show ep2 fri_sexy_simon_betterthings with d
            simon "You mean...?" id ep2_08_sue_sexy_replay_5d550884
            show ep2 fri_sexy_sue_whatyoulike with d
            sue "Maybe this is what you like?" id ep2_08_sue_sexy_replay_c9a3eb09
            show ep2 fri_sexy_simon_manytastes with d
            simon "I am a man of many tastes." id ep2_08_sue_sexy_replay_6ea345ff
            show ep2 fri_sexy_sue_manytalents with d
            sue "And I'm a woman of many talents." id ep2_08_sue_sexy_replay_0bb20dd1
            show ep2 fri_sexy_sue_letssee with d
            sue "Let's see what you've been hiding down here." id ep2_08_sue_sexy_replay_da8f8fe4
            simon "I like your style." id ep2_08_sue_sexy_replay_1029074b

            show ep2 fri_sexy_sue_damn2 with d
            stop music fadeout 6
            sue "DAMN!" id ep2_08_sue_sexy_replay_8b7ff02f
            sue "It's way bigger than I expected!" id ep2_08_sue_sexy_replay_fcaa4348
            show ep2 fri_sexy_sue_damn with d
            simon "Do you like it?" id ep2_08_sue_sexy_replay_ce26935a
            play music body_on_fire fadein 0.5 volume 0.15


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_simon_gottalent_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_simon_gottalent_var1_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_simon_gottalent with medium_dissolve
            sue "(Do I like it...?)"
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_simon_gottalent_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_simon_gottalent_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_simon_gottalent_var1 with d
            sue "(It's perfect!)" id ep2_08_sue_sexy_replay_b76735d9
            pause


            stop foley
            stop voicefx
            show ep2 fri_sexy_simon_takeyes with medium_dissolve
            simon "I'll take that as a yes." id ep2_08_sue_sexy_replay_d60f9e9c
            sue "(His dick is so warm!)" id ep2_08_sue_sexy_replay_f8ce94b5
            sue "(No way I could feel cold now.)" id ep2_08_sue_sexy_replay_272d3ca3
            sue "(He even tastes good!)" id ep2_08_sue_sexy_replay_71e868b9
            show ep2 fri_sexy_simon_gottalent with d
            simon "Ahhhh... You've got a talent for this." id ep2_08_sue_sexy_replay_4efcf738
            simon "(This is the best blowjob I've ever gotten!)" id ep2_08_sue_sexy_replay_cbfaf4c6
            simon "(And she's just getting started...)" id ep2_08_sue_sexy_replay_ad000b90
            show ep2 fri_sexy_simon_halfin with d
            sue "(I can't believe it's only halfway in!)" id ep2_08_sue_sexy_replay_74ea3f77
            simon "(Is she going to be able to take it all?)" id ep2_08_sue_sexy_replay_4684bbd6
            show ep2 fri_sexy_simon_almostthere with d
            sue "(Almost there!)" id ep2_08_sue_sexy_replay_173629d0
            show ep2 fri_sexy_simon_shedidit with d
            simon "(She did it!)" id ep2_08_sue_sexy_replay_d4367228
            sue "(I did it!)" id ep2_08_sue_sexy_replay_aeafab55
            show ep2 fri_sexy_sue_argh with d
            sue "*Gasp...*" id ep2_08_sue_sexy_replay_78c4fa2a
            simon "Wow, that was amazing." id ep2_08_sue_sexy_replay_08ce5fb7
            show ep2 fri_sexy_sue_icantake with d
            sue "Let's see just how deep I can take it." id ep2_08_sue_sexy_replay_8438ebfe
            show ep2 fri_sexy_sue_sucks with d
            simon "Ahhhh..." id ep2_08_sue_sexy_replay_3cb27ac9
            show ep2 fri_sexy_sue_yourhelp with d
            sue "I'm going to need your help with this next part." id ep2_08_sue_sexy_replay_29a6799c
            sue "So I'm going to let you touch me." id ep2_08_sue_sexy_replay_f9f5fe56
            show ep2 fri_sexy_simon_finally with d
            simon "Finally!" id ep2_08_sue_sexy_replay_88bd1158
            show ep2 fri_sexy_sue_onehand with d
            sue "Nope!" id ep2_08_sue_sexy_replay_865fc785
            sue "Just one hand." id ep2_08_sue_sexy_replay_0b071715
            show ep2 fri_sexy_sue_here with medium_dissolve
            sue "Here." id ep2_08_sue_sexy_replay_be1ad0f5
            simon "Oh, I think I get it." id ep2_08_sue_sexy_replay_dd79d86a
            show ep2 fri_sexy_simon_startslow with d
            simon "Let's start slow..." id ep2_08_sue_sexy_replay_f22a6214
            show ep2 fri_sexy_simon_thatsit with d
            simon "Just like that..." id ep2_08_sue_sexy_replay_747c03bd
            show ep2 fri_sexy_simon_startslow with d
            simon "... And back in again..." id ep2_08_sue_sexy_replay_59a2e3c6
            show ep2 fri_sexy_simon_thatsit with d
            simon "... Are you ready?" id ep2_08_sue_sexy_replay_aadeb651
            sue "Mmph." id ep2_08_sue_sexy_replay_cc0b0891
            simon "Let's do this." id ep2_08_sue_sexy_replay_8cc38a4d
            show ep2 fri_sexy_simon_youcantake with d
            simon "(Let's see just how far you can take it.)" id ep2_08_sue_sexy_replay_39751c2f
            show ep2 fri_sexy_simon_herself2 with d
            simon "AAHHHH..." id ep2_08_sue_sexy_replay_03a270e9
            simon "(She did it all by herself!)" id ep2_08_sue_sexy_replay_e410cd01
            show ep2 fri_sexy_simon_herself with d
            simon "(She wasn't kidding when she said she's a woman of many talents!)" id ep2_08_sue_sexy_replay_401f774b
            show ep2 fri_sexy_sue_thisbig with d
            sue "*Gasp...*" id ep2_08_sue_sexy_replay_c0dbda72
            sue "It's harder with a cock this big, but I like a challenge." id ep2_08_sue_sexy_replay_a94599e1





            show ep2 fri_sexy_simon_testlimits with medium_dissolve
            simon "I thought you said there's much more to come."
            show ep2 fri_sexy_sue_iwill with d
            sue "And there is." id ep2_08_sue_sexy_replay_b1bc1089
            sue "Warm-up's over. Time to really begin." id ep2_08_sue_sexy_replay_ea4babea
            show ep2 fri_sexy_sue_dontdisappoint with d
            sue "I hope you don't disappoint." id ep2_08_sue_sexy_replay_19857963
            show ep2 fri_sexy_sue_seriousgame with d
            sue "Because we're not playing games anymore. This just got serious." id ep2_08_sue_sexy_replay_d47e7eea
            simon "(I might be in trouble if she really is just getting started...)" id ep2_08_sue_sexy_replay_0d5fc5fc


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_simon_soflexible_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_simon_soflexible_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_simon_soflexible with medium_dissolve
            simon "Damn! I didn't know you were so athletic!"
            sue "I told you we're getting serious." id ep2_08_sue_sexy_replay_c3343d62
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_simon_soflexible_var2_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_simon_soflexible_var2_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_simon_soflexible_var2 with d
            simon "(Holy fucking shit!)" id ep2_08_sue_sexy_replay_f54f102f
            simon "(Can she really still suck me off like that?!)" id ep2_08_sue_sexy_replay_b3ee49a1
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_simon_soflexible_var3_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_simon_soflexible_var3_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_simon_soflexible_var3 with d
            simon "(I guess this technically counts as 69!)" id ep2_08_sue_sexy_replay_cd837213
            pause

            stop foley
            stop voicefx
            show ep2 fri_sexy_simon_thatcase with d
            simon "(Well, if that's the case...)" id ep2_08_sue_sexy_replay_745f16d2
            show ep2 fri_sexy_simon_goingforit with d
            simon "I'm going in." id ep2_08_sue_sexy_replay_d677411f
            show ep2 fri_sexy_sue_youcant with d
            sue "Hey. I said no touch —" id ep2_08_sue_sexy_replay_0831a7cd
            show ep2 fri_sexy_sue_ahh with d
            sue "Aaaannggg..." id ep2_08_sue_sexy_replay_4c919be8
            sue "Fuck..." id ep2_08_sue_sexy_replay_56ceed4f
            sue "... I'm going to make an exception to that rule." id ep2_08_sue_sexy_replay_6680ff0b
            sue "Aaaaahhhnnggg..." id ep2_08_sue_sexy_replay_4c9abb62
            show ep2 fri_sexy_sue_seduced with d
            simon "Fuck! You taste amazing..." id ep2_08_sue_sexy_replay_6e5c504e
            sue "(Ahhh... [name], if I'd known you'd be so good at that, I would have seduced you a long time ago!)" id ep2_08_sue_sexy_replay_c4538ce8


            show ep2 fri_sexy_sue_thatsit with d
            sue "Ahhhhh... Right there!" id ep2_08_sue_sexy_replay_0631f6c1
            show ep2 fri_sexy_sue_anidea with d
            sue "(That gives me an idea...)" id ep2_08_sue_sexy_replay_793f12c4
            show ep2 fri_sexy_simon_fucksue with d
            simon "Oh, fuck..."
            simon "Sue..."
            sue "I bet you didn't see this coming." id ep2_08_sue_sexy_replay_652c6ba9
            simon "Definitely a surprise." id ep2_08_sue_sexy_replay_f536709b
            show ep2 fri_sexy_simon_welcomeone with d
            simon "But a welcome one." id ep2_08_sue_sexy_replay_f0a0c3fa
            show ep2 fri_sexy_sue_fuckmytits with d
            sue "Hold tight, and I'll give you a titty fuck you won't forget, [name]!"

            simon "Fuck, Sue, you're driving me crazy!" id ep2_08_sue_sexy_replay_af507b58
            show ep2 fri_sexy_sue_driveyoucrazy with d
            sue "Oh, is that so?" id ep2_08_sue_sexy_replay_b06a5c90
            sue "Do I drive you crazy?" id ep2_08_sue_sexy_replay_b36c2b66
            sue "I want you to go crazy for me." id ep2_08_sue_sexy_replay_0e690791
            sue "I want you in the palm of my hand." id ep2_08_sue_sexy_replay_4833908b
            $ ep2_sue_sex = True
            $ points_sue += 1

            menu:
                "Take it easy, Sue":
                    $ ep2_sue_takeiteasy= True
                    $ player_choice("ep2_sue_takeiteasy:true")
                    show ep2 fri_sexy_a_simon_notmything with d
                    simon "That's not really a fetish of mine, but I'll leave all options on the table." id ep2_08_sue_sexy_replay_3668098c
                    show ep2 fri_sexy_a_sue_lasttalent with d
                    sue "I think it's time I showed you my final talent." id ep2_08_sue_sexy_replay_2d709fd8
                    show ep2 fri_sexy_a_simon_impressed with d
                    simon "I think you might impress me with this one too." id ep2_08_sue_sexy_replay_b7774f6f
                    show ep2 fri_sexy_a_sue_pre with d
                    sue "Ahhhh!" id ep2_08_sue_sexy_replay_bd5ea227
                    show ep2 fri_sexy_a_sue_sits with d
                    sue "Come on. Stick that big cock of yours inside me!" id ep2_08_sue_sexy_replay_7d8fdadf
                    show ep2 fri_sexy_a_simon_expecting with d
                    simon "(Oh, god. That feels so much better than I was expecting!)" id ep2_08_sue_sexy_replay_6163bac5
                    show ep2 fri_sexy_a_sue_impressedyet with d
                    sue "Impressed yet?" id ep2_08_sue_sexy_replay_77fd3e47
                    simon "(Impressed? You're pulling out all the stops, Sue!)" id ep2_08_sue_sexy_replay_f2dd481f
                    show ep2 fri_sexy_a_simon_lastlong with d
                    simon "(If she keeps this up, I might not last very long.)" id ep2_08_sue_sexy_replay_11cf5f96
                    show ep2 fri_sexy_a_sue_matter with d
                    sue "What's the matter? Is this too much for you?" id ep2_08_sue_sexy_replay_3e0b270e
                    show ep2 fri_sexy_a_simon_somethingelse with d
                    simon "I was actually thinking of trying something else." id ep2_08_sue_sexy_replay_798e0283
                    show ep2 fri_sexy_a_sue_newideas with medium_dissolve
                    sue "I'm open to new ideas." id ep2_08_sue_sexy_replay_3ccdde35
                    simon "Looks like you read my mind." id ep2_08_sue_sexy_replay_eacaab1b
                    show ep2 fri_sexy_a_sue_youreyes with d
                    sue "It's written in your eyes." id ep2_08_sue_sexy_replay_1bdb58b5
                    $ ep2_sue_dominated = False
                    $ points_sue += 1
                "How about you in the palm of my hand?"(True):

                    $ ep2_sue_takeiteasy= False
                    $ player_choice("ep2_sue_takeiteasy:false")
                    show ep2 fri_sexy_b_sue_oh with None
                    sue "Oh..." id ep2_08_sue_sexy_replay_d0bd8107
                    simon "I'd rather be in control." id ep2_08_sue_sexy_replay_7c6758de

                    sue "Then what do you want me to do?" id ep2_08_sue_sexy_replay_55e00c0d
                    show ep2 fri_sexy_b_simon_nothing with medium_dissolve
                    simon "You're not doing anything." id ep2_08_sue_sexy_replay_a5ddb72a
                    simon "It's my turn to set the rules." id ep2_08_sue_sexy_replay_2008a23a
                    sue "(Ahhh... That's exactly what I wanted.)" id ep2_08_sue_sexy_replay_87ffe1b9
                    show ep2 fri_sexy_b_simon_icantouch with d
                    simon "And now I can touch all I want." id ep2_08_sue_sexy_replay_39f0a808
                    sue "Oh, fuck... Use me, [name]!" id ep2_08_sue_sexy_replay_947ea058
                    show ep2 fri_sexy_b_sue_illserve with d
                    sue "I'm all yours."
                    show ep2 fri_sexy_b_simon_onetalent with d
                    simon "There's still one talent of yours I want to explore." id ep2_08_sue_sexy_replay_17386874
                    show ep2 fri_sexy_a_sue_youreyes with d
                    sue "You want to know if you can cram that big rod of yours in my pussy like you did with my mouth, huh?" id ep2_08_sue_sexy_replay_c40711c4
                    $ ep2_sue_dominated = True
                    $ points_sue += 2

            show ep2 fri_sexy_c_sue_tight with d
            sue "Aaaahhh!" id ep2_08_sue_sexy_replay_abd8a98e
            simon "(She's so tight!)" id ep2_08_sue_sexy_replay_1d7d2cc7
            simon "(And she's already soaking wet.)" id ep2_08_sue_sexy_replay_afe439e5
            show ep2 fri_sexy_c_sue_takemore with d
            sue "In this position, I can feel you so much deeper." id ep2_08_sue_sexy_replay_62828af1
            sue "Shove it all in!" id ep2_08_sue_sexy_replay_14349540
            simon "How's this...?" id ep2_08_sue_sexy_replay_7327c336
            show ep2 fri_sexy_c_simon_allin with d
            sue "Aaaahhhhh..." id ep2_08_sue_sexy_replay_e9e21593
            sue "That's perfect..." id ep2_08_sue_sexy_replay_b80f18d4
            show ep2 fri_sexy_c_simon_likethis with d
            simon "Do you like it like this?" id ep2_08_sue_sexy_replay_086e06bf
            sue "Mmmph... I do!" id ep2_08_sue_sexy_replay_3b0402b5
            sue "Fuck me, [name]!" id ep2_08_sue_sexy_replay_d726abb0
            sue "Yes... Stuff my wet pussy with that fat cock of yours, [name]..." id ep2_08_sue_sexy_replay_f65121e4
            show ep2 fri_sexy_c_sue_makemecum with d
            sue "Make me cum, [name]!" id ep2_08_sue_sexy_replay_028c77a1


            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_c_simon_metoo_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_c_simon_metoo_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_c_simon_metoo with medium_dissolve
            sue "Harder! Harder!" id ep2_08_sue_sexy_replay_96ce863b
            sue "Holy shit!" id ep2_08_sue_sexy_replay_878ac40f
            simon "Oh... Fuck..." id ep2_08_sue_sexy_replay_e0ebdc47
            simon "If you keep talking like that, you're going to make me cum too." id ep2_08_sue_sexy_replay_51dc96b8
            sue "Do it!" id ep2_08_sue_sexy_replay_80a55912
            sue "Cum for me!" id ep2_08_sue_sexy_replay_b4acc173
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep2_anim_fri_sexy_c_sue_cuminside_voicefx fadein 0.5 fadeout 0.5
                play foley ep2_anim_fri_sexy_c_sue_cuminside_foley fadein 0.5 fadeout 0.5
            show ep2 anim_fri_sexy_c_sue_cuminside with medium_dissolve
            sue "Paint my insides with your cum!" id ep2_08_sue_sexy_replay_c15057d3
            sue "I'm going to..." id ep2_08_sue_sexy_replay_e810394e
            pause

            stop foley
            stop voicefx
            show ep2 fri_sexy_c_sue_ah with hpunch
            pause 0.5
            show ep2 fri_sexy_c_sue_ah with hpunch
            pause 0.5
            show ep2 fri_sexy_c_sue_ah with hpunch
            pause 0.5
            sue "Aaaaaahhhh..." id ep2_08_sue_sexy_replay_5222d882
            show ep2 fri_sexy_c_sue_milk with d
            sue "Mmmmm... That man milk of yours is dripping from my pussy." id ep2_08_sue_sexy_replay_ca887135
            $ renpy.end_replay()
            stop music fadeout 10
            show ep2 fri_sexy_c_sue_impressed with medium_dissolve
            sue "I'm impressed..." id ep2_08_sue_sexy_replay_b7e172d8
            show ep2 fri_sexy_c_simon_emotions with fast_fade
            simon "(Wow!... Sue really knows how to bring the heat when it comes to emotions...)" id ep2_08_sue_sexy_replay_8bb61155
            show ep2 fri_sexy_c_simon_sue with fast_fade
            simon "(Will things change between us now?)" id ep2_08_sue_sexy_replay_efca29f5
            simon "(I wonder if...)" id ep2_08_sue_sexy_replay_6106b646
            show ep2 fri_sexy_c_sue_fuckface with d
            sue "Hey, fuck face!" id ep2_08_sue_sexy_replay_44f32b07
            sue "I'm talking to you!" id ep2_08_sue_sexy_replay_7570eee3
            show ep2 fri_sexy_c_simon_nothing with d
            simon "(Nope. I don't think things are going to change.)" id ep2_08_sue_sexy_replay_44bc9f8c
            show ep2 fri_sexy_c_sue_late with d
            sue "It's getting late." id ep2_08_sue_sexy_replay_8bf326b7
            sue "What time is it anyway?" id ep2_08_sue_sexy_replay_414603ff
            jump ep2_09_ending

        "Tell her to stop" if not _in_replay:
            $ ep2_sue_stop = True
            $ player_choice("ep2_sue_stop:true")
            stop music fadeout 4

            show ep2 fri_sexy_simon_stop with d
            simon "Stop." id ep2_08_sue_sexy_replay_c0825867
            simon "If you really want to pay me back for what I've done, it's your turn to do some research." id ep2_08_sue_sexy_replay_73401fab
            play music in_bloom volume 0.20

            show ep2 fri_sexy_sue_nobody with d
            sue "Nobody says no to me like that." id ep2_08_sue_sexy_replay_dd7122fb
            sue "But, fine, I'll play along." id ep2_08_sue_sexy_replay_c5b97e43
            sue "What should I research exactly?" id ep2_08_sue_sexy_replay_b4522bad
            show ep2 fri_sexy_simon_myfather with d
            simon "You can help me learn more about my father." id ep2_08_sue_sexy_replay_ab988f29
            simon "He and Susan knew each other." id ep2_08_sue_sexy_replay_4e0c6a97
            simon "Maybe you can find something out from her." id ep2_08_sue_sexy_replay_ddfd7128
            show ep2 fri_sexy_sue_youask with d
            sue "Why don't you ask her yourself?" id ep2_08_sue_sexy_replay_fa91c038
            show ep2 fri_sexy_simon_explaining with d
            simon "You saw how she reacted when I asked her about the photo." id ep2_08_sue_sexy_replay_07d42277
            simon "Besides, you know very well that your aunt isn't the talkative type around me." id ep2_08_sue_sexy_replay_cb5c1dfa
            simon "But maybe she could tell you a thing or two." id ep2_08_sue_sexy_replay_ce195c01
            show ep2 fri_sexy_sue_talks with d
            sue "What do you want me to find out?" id ep2_08_sue_sexy_replay_524384ee
            show ep2 fri_sexy_simon_myfather with d
            simon "My father disappeared when I was very young." id ep2_08_sue_sexy_replay_42ecaee8
            simon "He and Susan had some sort of partnership." id ep2_08_sue_sexy_replay_ffea034a
            simon "I want to know what it entailed." id ep2_08_sue_sexy_replay_afbb85db
            show ep2 fri_sexy_sue_surprised with d
            sue "Do you think him and auntie... were, uh...?" id ep2_08_sue_sexy_replay_0737f638
            show ep2 fri_sexy_simon_no with d
            simon "No! It was a business partnership!" id ep2_08_sue_sexy_replay_b0aa0e7e
            simon "That's it!" id ep2_08_sue_sexy_replay_29a3796f
            show ep2 fri_sexy_simon_myfather with d
            simon "So, are you going to help me or not?" id ep2_08_sue_sexy_replay_2c019dae
            show ep2 fri_sexy_sue_thinking with d
            sue "Auntie has an investor event next week." id ep2_08_sue_sexy_replay_53f63f6b
            sue "That'll give me a reason to talk business with her." id ep2_08_sue_sexy_replay_5bb744f9
            show ep2 fri_sexy_sue_talks with d
            sue "She might be able to tell me something about past business partners." id ep2_08_sue_sexy_replay_cfc03c0f
            show ep2 fri_sexy_simon_myfather with d
            simon "Doesn't seem like a bad plan." id ep2_08_sue_sexy_replay_fbe098ca
            show ep2 fri_sexy_sue_talks with d
            sue "But I do hope this means you'll continue to share with me what you learn."
            show ep2 fri_sexy_sue_nope with d
            simon "Nope!" id ep2_08_sue_sexy_replay_6c6031cc
            simon "This is payment for everything I've done up to now."

            simon "We'll discuss what happens going forward at a later date." id ep2_08_sue_sexy_replay_475c2e96
            show ep2 fri_sexy_sue_surprised with d
            sue "(Wow... he's really taking control.)" id ep2_08_sue_sexy_replay_2df0027f
            sue "(Who would have thought he could be like this?)" id ep2_08_sue_sexy_replay_f125515c
            show ep2 fri_sexy_sue_talks with d
            sue "Deal." id ep2_08_sue_sexy_replay_0d8679f7
            stop music fadeout 4
            show ep2 fri_sexy_sue_notsleepy with d
            sue "Well, I'm not sleepy anymore." id ep2_08_sue_sexy_replay_7d8921d3
            sue "What time is it?" id ep2_08_sue_sexy_replay_dfb0c736
            $ ep2_sue_sex = False
            jump ep2_09_ending
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
