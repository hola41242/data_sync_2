label ep2_06_night_job:
    show ep2 fri_night_simonhome_wondering with long_fade
    simon "(Another strange day in the life of [name].)" id ep2_06_night_job_5db9e1ab
    simon "(Between Julia, what happened with Lily, and my missing underwear, I barely had any time to catch my breath.)" id ep2_06_night_job_c7e790fd
    show ep2 fri_night_simonhome_susanjob with medium_dissolve
    simon "(Plus, Susan's got a job for me later.)" id ep2_06_night_job_0dd865ee
    simon "(As if I didn't have anything better to do on a Friday night.)" id ep2_06_night_job_acf727ea
    simon "(I've still got a bit of time to take a nap at least.)" id ep2_06_night_job_6a19ef7b
    show ep2 fri_night_simonhome_goodrest with medium_fade
    simon "Ahhhh." id ep2_06_night_job_5022dde8
    simon "(Finally, a bit of rest.)" id ep2_06_night_job_2748beb1
    show ep2 fri_night_simonhome_mall with d
    simon "(I've got to get going to the mall soon.)" id ep2_06_night_job_3eff84cc
    show ep2 fri_night_simonhome_underwear with d
    simon "(Whoa. My missing underwear!)" id ep2_06_night_job_9afefc60
    simon "(And it looks like someone washed them!)" id ep2_06_night_job_1bc6b845
    simon "(This is insane!)" id ep2_06_night_job_db8ba38b
    show ep2 fri_night_susans_bike with medium_fade
    simon "(How did they end up there?)" id ep2_06_night_job_4890eefa
    play music util_paisagem fadein 5 volume 0.15
    show ep2 fri_night_susans_sense with medium_fade
    simon "None of this makes any sense!"
    show ep2 fri_night_susans_susan_what with medium_dissolve
    susan "None of what doesn't make any sense, [name]?" id ep2_06_night_job_260b3a3f
    show ep2 fri_night_susans_susan_silent with d
    simon "Umm... I'm sorry, but what were we talking about again?" id ep2_06_night_job_449a61aa
    show ep2 fri_night_susans_susan_talks with d
    susan "I was explaining that you're going to stay here and help Sue organize our backstock." id ep2_06_night_job_de559734
    susan "Are you up for the task?" id ep2_06_night_job_2affb757
    show ep2 fri_night_susans_susan_silent with d
    simon "Yeah, sure." id ep2_06_night_job_01aca596
    show ep2 fri_night_susans_susan_what with d
    susan "Is everything all right, [name]?" id ep2_06_night_job_ab166a4d
    show ep2 fri_night_susans_susan_silent with d
    simon "(Susan's actually kind of sweet.)" id ep2_06_night_job_24998aad
    simon "(She seems to really care, despite the serious businesswoman look.)" id ep2_06_night_job_6a5a2bf8
    simon "Everything's fine." id ep2_06_night_job_22e86c52
    stop music fadeout 4
    show ep2 fri_night_susans_susan_back with d
    susan "Good, because Sue is waiting for you in the back." id ep2_06_night_job_58d8fb59
    susan "You can go ahead and get started." id ep2_06_night_job_bd9de5ff


    play music it_was_never_enough fadein 3 volume 0.15 
    play sound door volume 0.7
    show ep2 fri_storage_suethere with fade
    simon "Hey, Sue!" id ep2_06_night_job_7c01fcf6
    sue "I'm almost done back here." id ep2_06_night_job_980f0333
    show ep2 fri_storage_sue_helpme with d
    sue "Are you here to help?" id ep2_06_night_job_e1431167
    show ep2 fri_storage_simon_ahand with medium_dissolve
    simon "Yep. Susan asked me to lend you a hand." id ep2_06_night_job_ffccaa9f
    show ep2 fri_storage_sue_boxes with medium_dissolve
    sue "Well then, you can start by helping me with that box down there." id ep2_06_night_job_d484f1a4
    sue "I don't want to tweak my back." id ep2_06_night_job_fc6b707f
    show ep2 fri_storage_sue_breasts with d
    simon "(With melons as heavy as those, I bet she has all sorts of back pain.)" id ep2_06_night_job_3645aec5
    show ep2 fri_storage_sue_so with fade
    sue "So..." id ep2_06_night_job_9edd8db8
    play sound lock volume 0.8
    "*Click.*" id ep2_06_night_job_09d06ab8
    sue "Have you learned anything I might find of use?" id ep2_06_night_job_004b4419
    show ep2 fri_storage_simon_shelisten with d
    simon "Shhh... Isn't she going to overhear?" id ep2_06_night_job_7da5776b
    sue "No. This room is far enough away that she won't be able to hear us." id ep2_06_night_job_2d7d51c9

    if not chose('ep1_agree_help_sue'):
        show ep2 fri_storage_simon_nohelp with medium_dissolve
        simon "Look, I said I didn't want to get involved." id ep2_06_night_job_789b2d56
        show ep2 fri_storage_sue_yousure with d
        sue "Are you sure about that?" id ep2_06_night_job_197385ea
        menu:
            "Help Sue"(True):
                show ep2 fri_storage_simon_fine with d
                simon "All right, fine. I'll tell you."
                simon "But I don't think it's a good idea to talk about that here."
                simon "We'd better just finish the job and talk later."
                show ep2 fri_storage_sue_whatever with d
                sue "All right."
                $ points_sue += 1
                $ ep1_agree_help_sue = True
                pass
            "Yes, I'm sure":
                show ep2 fri_storage_simon_nohelp with d
                simon "We're better off keeping our heads down and finishing the job." id ep2_06_night_job_5986ec86
                simon "Plus, I wouldn't want to discuss that here." id ep2_06_night_job_f85d798c
                show ep2 fri_storage_simon_myjob with medium_dissolve
                simon "I don't feel like losing my job today!" id ep2_06_night_job_79adeee9
                show ep2 fri_storage_sue_whatever with medium_dissolve
                sue "Whatever you say." id ep2_06_night_job_0b503114
                show ep2 fri_storage_simon_friendship with medium_dissolve
                simon "(It's going to be hard to strike up a friendship with Sue.)" id ep2_06_night_job_34567ef5
                simon "(She's absolutely obsessed with Susan.)" id ep2_06_night_job_30fee411
                $ ep1_agree_help_sue = False
    else:
        show ep2 fri_storage_simon_fine with d
        simon "All right. I'll fill you in."
        simon "But I don't think it's a good idea to talk about it here."
        simon "We'd better just finish the job and talk later."
        show ep2 fri_storage_sue_whatever with d
        sue "Okay."

    jump ep2_07_sue_conversation
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
