label ep2_05_simon_lost:
    play music the_south fadein 3 volume 0.15
    show ep2 fri_game_lost_empty with fade
    simon "I'm so glad there's no one out here." id ep2_05_simon_lost_d7650d69
    julia "Where's the fun in that?!" id ep2_05_simon_lost_38c93e47
    show ep2 fri_game_lost_where with long_dissolve
    simon "Where was that vending machine again?" id ep2_05_simon_lost_292b133d
    julia "Lucky for you, it's downstairs." id ep2_05_simon_lost_377ecf53
    show ep2 fri_game_lost_shit with fade
    simon "(Oh, shit!)" id ep2_05_simon_lost_013c45d3
    show ep2 fri_game_lost_safe with None
    simon "Let me know when the coast is clear." id ep2_05_simon_lost_baf547f8
    show ep2 fri_game_lost_gone with long_dissolve
    julia "Okay, the girl's gone." id ep2_05_simon_lost_56c17649
    show ep2 fri_game_lost_have with fade
    simon "So, what do you want?" id ep2_05_simon_lost_7700250c
    show ep2 fri_game_lost_wonder with d
    julia "Hmm... I wonder what I'll have..." id ep2_05_simon_lost_fe606417
    show ep2 fri_game_lost_faster with d
    simon "Could you think any slower?" id ep2_05_simon_lost_fe5c3aaf
    simon "We've got to be quick getting back!" id ep2_05_simon_lost_3794d2b7
    show ep2 fri_game_lost_soda with d
    julia "All right! Just a soda then." id ep2_05_simon_lost_6c5fa092
    show ep2 fri_game_lost_comeon with d
    simon "Come on, come on!" id ep2_05_simon_lost_1853b2c9
    simon "Before Emily gets back!" id ep2_05_simon_lost_3e9c6e98
    play sound vending_machine volume 0.5
    show ep2 fri_game_lost_there with long_dissolve
    simon "Finally!" id ep2_05_simon_lost_88bd1158
    play sound photo volume 0.5
    show ep2 fri_game_lost_what with flash
    simon "What the...?" id ep2_05_simon_lost_2f7e4b1f
    stop music fadeout 4
    show ep2 fri_game_lost_moment with d
    julia "I want to remember this moment." id ep2_05_simon_lost_241f5d1b
    show ep2 fri_game_lost_deal with wiperight
    simon "That definitely wasn't part of our deal." id ep2_05_simon_lost_b352160d
    play music swamp_shack fadein 3 volume 0.15
    show ep2 fri_game_lost_no with d
    $ ep2_lily_no_pants = True
    lily "[name]? Is that you?" id ep2_05_simon_lost_a9506337

    show ep2 fri_game_lost_tense with d
    simon "(Oh, no. Oh, no. Oh, shit. Oh, no.)" id ep2_05_simon_lost_a2ac1e23
    show ep2 fri_game_lost_heylily with d
    simon "Hey, Lily." id ep2_05_simon_lost_dd0c8fcc
    simon "What are you doing here?" id ep2_05_simon_lost_30e5d247
    show ep2 fri_game_lost_here with d
    lily "I own this building. I'm here to check on my tenants." id ep2_05_simon_lost_a051958b
    lily "But, umm, why are you coming out into the halls like that?" id ep2_05_simon_lost_de4f43f1
    show ep2 fri_game_lost_justsoda with d
    simon "I just..." id ep2_05_simon_lost_294912cf
    simon "..." id ep2_05_simon_lost_ba28090a
    simon "I just ran out to grab a soda!"
    show ep2 fri_game_lost_simon_talks with d
    simon "Am I one of the tenants who needs checking in on?"
    show ep2 fri_game_lost_lily_talks with d
    lily "Why? Do you have a problem with your apartment?" id ep2_05_simon_lost_671161d6
    show ep2 fri_game_lost_simon_talks with d
    simon "Nope, no problems." id ep2_05_simon_lost_e26bff08
    show ep2 fri_game_lost_lily_talks with d
    lily "Then, no, we have nothing we need to discuss." id ep2_05_simon_lost_c93c9f87
    show ep2 fri_game_lost_dressed with wiperight
    lily "Oh, and please put on some clothes before leaving your apartment next time." id ep2_05_simon_lost_392e4855
    lily "Neighbors might start complaining if this becomes a habit." id ep2_05_simon_lost_54c93745



    show ep2 fri_game_lost_dontlike with d
    julia "Who was that woman?" id ep2_05_simon_lost_e8e04a94
    show ep2 fri_game_lost_landlady with d
    simon "She's my landlady."
    show ep2 fri_game_lost_dontlike with d
    julia "I don't like her."
    stop music fadeout 7
    show ep2 fri_game_lost_letsgo with None
    julia "Anyway, let's head back! I want to play more!" id ep2_05_simon_lost_b9cf588e
    show ep2 fri_game_lost_match with long_fade
    simon "You want to play another match?" id ep2_05_simon_lost_f8458844
    show ep2 fri_game_lost_okay with d
    julia "Sure, but are you going to be okay after all that?" id ep2_05_simon_lost_71c6b5b3
    show ep2 fri_game_lost_sure with d
    simon "I'll be fine. Don't worry about me." id ep2_05_simon_lost_414acd37
    show ep2 fri_game_lost_sithere with long_dissolve
    julia "Actually, I'm cool with the idea of hanging around and having a chat or watching a movie." id ep2_05_simon_lost_666fe7cb
    show ep2 fri_game_lost_movie with long_dissolve
    simon "A movie sounds fun." id ep2_05_simon_lost_df69e26a
    show ep2 fri_game_lost_corset with long_dissolve
    julia "This outfit sucks to wear after a while." id ep2_05_simon_lost_50c7329b
    julia "Do you have anything else I could wear?" id ep2_05_simon_lost_579c93c0
    simon "I might have something." id ep2_05_simon_lost_bbdfc9ba
    show ep2 fri_game_lost_huge with medium_fade:
        yalign 1.0
        ease 10.0 yalign 0.0

    julia "It looks huge on me!" id ep2_05_simon_lost_ac77d0de
    julia "Yet surprisingly comfortable." id ep2_05_simon_lost_9524d9db

    jump ep2_05_ending

label ep2_05_simon_wins:
    show ep2 fri_game_wins_machine with fade
    simon "So, where's that vending machine exactly?" id ep2_05_simon_wins_1b1d293d
    show ep2 fri_game_wins_downstairs with long_dissolve
    julia "It's right downstairs, thankfully." id ep2_05_simon_wins_b4d67e84
    show ep2 fri_game_wins_someone with fade
    julia "There's someone down there." id ep2_05_simon_wins_d94fab3d
    julia "Let's wait her out." id ep2_05_simon_wins_58b555c3
    show ep2 fri_game_wins_courage with fade
    simon "Where'd all that moxy you had before go?" id ep2_05_simon_wins_c0727ce0
    show ep2 fri_game_wins_flasher with d
    julia "I don't want people thinking I'm an exhibitionist!" id ep2_05_simon_wins_06e944bc

    julia "Come on. She's gone." id ep2_05_simon_wins_c5445c5e
    show ep2 fri_game_wins_way with d
    simon "Lead the way." id ep2_05_simon_wins_897757da
    stop music fadeout 4
    show ep2 fri_game_wins_worthit with d
    simon "(So worth it.)" id ep2_05_simon_wins_a62dc227
    show ep2 fri_game_wins_left with fade
    julia "What should I have...?" id ep2_05_simon_wins_8d134dd0
    simon "(Nice.)" id ep2_05_simon_wins_b84b8dac
    play music swamp_shack fadein 3 volume 0.15
    show ep2 fri_game_wins_lily with medium_fade
    $ ep2_lily_no_pants = False
    lily "[name], is that you?" id ep2_05_simon_wins_32e90079
    simon "(Shit...)" id ep2_05_simon_wins_2df71584
    show ep2 fri_game_wins_snack with d
    simon "Oh. Hi, Lily." id ep2_05_simon_wins_fe9f1e69
    simon "We just came down for a snack." id ep2_05_simon_wins_ee4e7ebe
    show ep2 fri_game_wins_isee with d
    lily "I can see that." id ep2_05_simon_wins_d3a4fff9
    show ep2 fri_game_wins_business with d
    lily "Not that it's any of my business." id ep2_05_simon_wins_f5389d1f
    show ep2 fri_game_wins_talk with d
    simon "Umm... Could we talk soon?" id ep2_05_simon_wins_9a637eb7
    show ep2 fri_game_wins_apartment with d
    lily "If you have a problem with your apartment, you can text me." id ep2_05_simon_wins_6c894db8
    show ep2 fri_game_wins_nothing with d
    lily "If not, we have nothing that needs talking about." id ep2_05_simon_wins_fe525a25
    show ep2 fri_game_wins_who with medium_dissolve
    julia "Jeez. Who was that?" id ep2_05_simon_wins_7fa14f41
    show ep2 fri_game_wins_who2 with d
    simon "She's my landlady."
    show ep2 fri_game_wins_dontlike with d
    julia "I don't like her."
    stop music fadeout 4
    show ep2 fri_game_wins_alright with long_dissolve
    julia "Is everything going to be all right with her?" id ep2_05_simon_wins_70bb451d
    show ep2 fri_game_wins_alright2 with d
    simon "Yeah. It'll be fine." id ep2_05_simon_wins_01aca596
    show ep2 fri_game_wins_letsgo with None
    julia "Anyway, let's get going." id ep2_05_simon_wins_d9b48a94
    julia "I want to keep playing!" id ep2_05_simon_wins_fa4d0181

    show ep2 fri_game_wins_movie with medium_fade
    stop music fadeout 4
    julia "Actually, we could just watch a movie if you'd like." id ep2_05_simon_wins_710535d0
    show ep2 fri_game_wins_good with d
    simon "A movie sounds like a great idea!" id ep2_05_simon_wins_ab103765

    jump ep2_05_ending
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
