label ep2_05b_julia_play:
    show ep2 fri_arcade_both_going with medium_fade
    simon "(Whatever happens, at least it's nice to have a friend who's also into video games.)" id ep2_05b_julia_play_faf56efb
    show ep2 fri_game_home_here with medium_fade
    simon "We're here." id ep2_05b_julia_play_27bdd67c
    show ep2 fri_game_home_organized with wiperight
    julia "Oh... You're more organized than I expected." id ep2_05b_julia_play_78f4dad3
    simon "Is that a compliment I hear?" id ep2_05b_julia_play_78530fa1

    julia "Not really." id ep2_05b_julia_play_4f05b38b
    show ep2 fri_game_home_underwear with d
    julia "After all, you did leave a pair of underwear out on your bed." id ep2_05b_julia_play_7dca700b
    show ep2 fri_game_home_simon_what with d
    simon "WHAT?!" id ep2_05b_julia_play_540f8c8c
    show ep2 fri_game_home_kidding with d
    julia "Haha! Just kidding." id ep2_05b_julia_play_580919be
    julia "Not too shabby of a place." id ep2_05b_julia_play_b53ab9ac

    play music deep_sky_blue fadein 2 volume 0.17
    show ep2 fri_game_home_julia_comfy with medium_dissolve
    julia "Your bed is nice and comfy." id ep2_05b_julia_play_6c858cf6
    show ep2 fri_game_home_julia_sleepy with d
    julia "It's making me sleepy..." id ep2_05b_julia_play_878c5500
    show ep2 fri_game_home_excuse with medium_dissolve
    simon "Is that going to be your excuse when you lose?" id ep2_05b_julia_play_71a40833
    show ep2 fri_game_home_julia_wow with d
    julia "Wow!" id ep2_05b_julia_play_97ad7a2f
    julia "The nerve!" id ep2_05b_julia_play_b5d5930e
    show ep2 fri_game_home_simon_justsay with d
    simon "Just saying." id ep2_05b_julia_play_90932926
    show ep2 fri_game_home_julia_wow with d
    julia "I like your fighting spirit though!" id ep2_05b_julia_play_5c24a70d
    show ep2 fri_game_home_simon_justsay with d
    simon "I thought you'd be too scared for a rematch." id ep2_05b_julia_play_4850bfcf
    show ep2 fri_game_home_julia_notscared with d
    julia "I'm not scared of anything." id ep2_05b_julia_play_de6eee18
    show ep2 fri_game_home_simon_really with d
    simon "Oh, really?" id ep2_05b_julia_play_c1761c50
    show ep2 fri_game_home_julia_notscared with d
    julia "What do you think I'm scared of? Ask away." id ep2_05b_julia_play_e6a0f114
    show ep2 fri_game_home_julia_listens with d
    simon "Okay. How about spiders?" id ep2_05b_julia_play_e93d61d7
    show ep2 fri_game_home_julia_cool1 with d
    julia "Spiders are cool. I wish I had a pet tarantula." id ep2_05b_julia_play_ecf01e9e
    show ep2 fri_game_home_julia_listens with d
    simon "Fair enough. Frogs then?" id ep2_05b_julia_play_3be19ba4
    show ep2 fri_game_home_julia_cool2 with d
    julia "I'm not scared of frogs, but they are kind of gross." id ep2_05b_julia_play_b1a9651d
    show ep2 fri_game_home_julia_listens with d
    simon "Ghosts?" id ep2_05b_julia_play_5285157b
    show ep2 fri_game_home_julia_ghosts with d
    julia "Do you believe in ghosts, Twinkle Toes?" id ep2_05b_julia_play_66dc01aa
    show ep2 fri_game_home_simon_neverknow with d
    simon "Well, you never know..." id ep2_05b_julia_play_01fbf633
    show ep2 fri_game_home_julia_cool1 with d
    julia "I'm not afraid of them either." id ep2_05b_julia_play_775dfa4d
    show ep2 fri_game_home_julia_cool2 with d
    julia "See? Nothing scares me." id ep2_05b_julia_play_7d588c65
    show ep2 fri_game_home_simon_justsay with d
    simon "I'll think of something else." id ep2_05b_julia_play_0a0bf3d0
    simon "I'm dying to find something that scares you." id ep2_05b_julia_play_8b0281cc
    show ep2 fri_game_home_julia_goodluck with d
    julia "Good luck!" id ep2_05b_julia_play_9aaa7d4e
    show ep2 fri_game_julia_play with medium_dissolve
    julia "Speaking of luck, weren't we going to play?" id ep2_05b_julia_play_81ae2c7e
    stop music fadeout 5
    show ep2 fri_game_julia_play2 with d
    simon "Right. I'll grab everything." id ep2_05b_julia_play_1801dd5d
    show ep2 fri_game_simon_tada with fade
    simon "Ta da!" id ep2_05b_julia_play_91c3f2cc

    play music you_seen_my_coat volume 0.18
    show ep2 fri_game_julia_neversaw with medium_dissolve
    julia "Wow! I've never seen one of these up close!" id ep2_05b_julia_play_7a49ae32
    julia "Does it actually work?" id ep2_05b_julia_play_251cf316
    show ep2 fri_game_julia_looking with d
    simon "Of course it does!" id ep2_05b_julia_play_c902855e
    show ep2 fri_game_julia_neversaw with d
    julia "And you even have Super Brothers 64!" id ep2_05b_julia_play_9f0e3f4e
    julia "I've never played the original." id ep2_05b_julia_play_721793f5
    show ep2 fri_game_julia_remaster with d
    julia "However, if it's anything like the remaster, there's no way you can beat me!" id ep2_05b_julia_play_fca4b4be
    show ep2 fri_game_julia_lookingcute with d
    simon "(She looks good in that outfit.)" id ep2_05b_julia_play_2de74af4
    simon "(It's like some sort of work uniform.)" id ep2_05b_julia_play_9bd0bd4a
    show ep2 fri_game_simon_skip with d
    simon "Hey, uh... Were you supposed to be at work the last time I saw you?"
    show ep2 fri_game_julia_lasttime with d
    julia "Well that day, you see, I wasn't exactly skipping work."
    julia "I was just a little late getting back."
    show ep2 fri_game_julia_nofun with d
    julia "Work is no fun." id ep2_05b_julia_play_2969d385
    show ep2 fri_game_simon_answer with d
    simon "You didn't exactly answer my question." id ep2_05b_julia_play_29c95345
    show ep2 fri_game_julia_nofun with d
    julia "I went to work, but it was boring there, so I left and then met you."
    julia "And now we're here, but you're bring up work again."
    show ep2 fri_game_simon_notask with d
    simon "All right. I won't ask anything else about it." id ep2_05b_julia_play_1362a6c4
    show ep2 fri_game_simon_skip with d
    simon "Actually, there's just one more thing." id ep2_05b_julia_play_68a9ef7d
    simon "Is that your work uniform?" id ep2_05b_julia_play_5dc46c41
    show ep2 fri_game_julia_custom with d
    julia "Sort of. This is my custom version of it. The original was so dull." id ep2_05b_julia_play_7d6a5abf
    julia "My re-envisioning of it should be the default skin." id ep2_05b_julia_play_1121becb
    show ep2 fri_game_julia_likeit with d
    julia "Do you like it?" id ep2_05b_julia_play_c32c894b
    show ep2 fri_game_julia_likeit2 with d
    simon "Of course. But they don't care that you do that?"
    show ep2 fri_game_julia_mandatory with d
    julia "The uniform is mandatory." id ep2_05b_julia_play_caf32f3b
    julia "And this is the uniform, just with a few changes." id ep2_05b_julia_play_fe38a219
    show ep2 fri_game_julia_custom with d
    julia "So, I'm not breaking any rules." id ep2_05b_julia_play_67b29b37
    show ep2 fri_game_julia_likeit with d
    julia "Even you could see it was a uniform, right?" id ep2_05b_julia_play_606d5b70
    show ep2 fri_game_julia_likeit2 with d
    simon "I guess so, yeah." id ep2_05b_julia_play_30a534c9
    show ep2 fri_game_julia_important with d
    julia "But if the rules are so important to you, sir, I have an idea." id ep2_05b_julia_play_a14ab2d5
    show ep2 fri_game_simon_whatsit with d
    simon "What might that be?" id ep2_05b_julia_play_cc6628db
    show ep2 fri_game_julia_normal with d
    julia "If you win today, I'll wear my normal uniform to work." id ep2_05b_julia_play_7b04b1c3
    show ep2 fri_game_simon_whatsit with d
    simon "Is that so?" id ep2_05b_julia_play_7ed60f99
    show ep2 fri_game_julia_normal with d
    julia "It is. And as a way for you to make sure I don't wear this one to work anymore..." id ep2_05b_julia_play_0e263776
    show ep2 fri_game_julia_leave with long_dissolve
    julia "I'll leave it here with you." id ep2_05b_julia_play_c83c1816
    julia "Every round you win, I take one part of it off." id ep2_05b_julia_play_75c6f826
    show ep2 fri_game_simon_poker with d
    simon "(That's basically strip poker.)" id ep2_05b_julia_play_0a40468e
    simon "(Just without the poker part.)" id ep2_05b_julia_play_cf544cf7
    show ep2 fri_game_simon_fine with None
    simon "I'M IN!" (what_bold=True)
    show ep2 fri_game_julia_fast with d
    julia "Not so fast, Twinkle Toes." id ep2_05b_julia_play_081ae082
    julia "Every round I win, you're the one who has to take off an item of clothing." id ep2_05b_julia_play_b1fbdefe
    show ep2 fri_game_simon_fine with d
    simon "Fine by me." id ep2_05b_julia_play_7862dbc0
    show ep2 fri_game_julia_fast with d
    julia "There's more." id ep2_05b_julia_play_b8032a32
    julia "I saw a vending machine outside." id ep2_05b_julia_play_52bde46b
    show ep2 fri_game_julia_machine with fade
    julia "Whoever loses in the end has to buy something out there." id ep2_05b_julia_play_ac98505a
    julia "Dressed in what little clothing they have on." id ep2_05b_julia_play_95688fa0
    show ep2 fri_game_julia_say with fade
    julia "So, what do you say?" id ep2_05b_julia_play_4422752d
    stop music fadeout 6
    show ep2 fri_game_simon_bringit with d
    simon "I say, bring it on!" id ep2_05b_julia_play_b338651e
    julia "I like your enthusiasm, Twinkle Toes."
    show ep2 fri_game_julia_say with d
    julia "But even though I hold player two's controller, I'll always be number one!" id ep2_05b_julia_play_e06d27b1
    show ep2 fri_game_both_playing with fade
    simon "(Oh my god. She really is good!)" id ep2_05b_julia_play_b3b43b18
    play sound lost volume 0.4

    play music get_gone fadein 5 volume 0.14
    show ep2 fri_game_julia_wins with d
    simon "(I can't believe it!)" id ep2_05b_julia_play_941e421e
    julia "I told you I was good!" id ep2_05b_julia_play_986b8db7
    show ep2 fri_game_julia_deal with d
    julia "A deal's a deal, Twinkle Toes." id ep2_05b_julia_play_91d96558
    julia "Time to lose something." id ep2_05b_julia_play_1408dd4c
    show ep2 fri_game_simon_shirtoff with long_dissolve
    simon "Should have seen that coming." id ep2_05b_julia_play_6d3f6adb
    simon "But you're going down next round." id ep2_05b_julia_play_acd2f8e2
    show ep2 fri_game_julia_whatsthat with long_dissolve
    julia "Wow, what's that?" id ep2_05b_julia_play_cfb43a03
    show ep2 fri_game_simon_lookback with d
    simon "Right, I always forget about those." id ep2_05b_julia_play_3f447575
    julia "Is that a tattoo?" id ep2_05b_julia_play_db439b0c
    show ep2 fri_game_julia_tattoo with d
    julia "I have one too!" id ep2_05b_julia_play_02c4f775
    show ep2 fri_game_simon_notattoo with d
    simon "That's no tattoo." id ep2_05b_julia_play_9d7cc673
    simon "There was just this incident that happened a few years back." id ep2_05b_julia_play_ea4c01d1
    simon "And it left me with that scar." id ep2_05b_julia_play_457686c7
    show ep2 fri_game_julia_holyshit with d
    julia "Holy shit! What kind of \"incident\" leaves a scar like that?" id ep2_05b_julia_play_0ed60923
    show ep2 fri_game_simon_lighting with d
    simon "One that involves lightning." id ep2_05b_julia_play_94a0f3cf
    show ep2 fri_game_julia_badass with d
    julia "Badass." id ep2_05b_julia_play_feeb2cad
    show ep2 fri_game_simon_seriously with d
    simon "Seriously?" id ep2_05b_julia_play_5ed5024e
    show ep2 fri_game_julia_badass with d
    julia "I mean, it's a mean-looking scar." id ep2_05b_julia_play_73efff4d
    julia "Respect." id ep2_05b_julia_play_c6f04981
    show ep2 fri_game_simon_lighting with d
    simon "Okay, enough of that. Let's play!" id ep2_05b_julia_play_c62b8bd7

    jump ep2_05c_julia_glitch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
