define episode_2_name = _("Episode 2 - Raw Encounters")

label ep2_01_the_station:
    hide ep1
    scene black with Fade(1,0,0)
    $ validate_mods()
    play music throbbing_anxiety volume 0.3 fadein 3
    pause 2

    show ep2 thu_road_simon_arrested with intro_dissolve
    simon "(I've never been arrested before.)" id ep2_01_the_station_b6159e6a
    simon "(To the best of my knowledge.)" id ep2_01_the_station_52869252
    show ep2 thu_road_simon_station with medium_dissolve
    simon "Didn't you say you were taking me to the station?" id ep2_01_the_station_c6dd37a3
    show ep2 thu_road_cop_doing with d
    cop "That's exactly what I'm doing." id ep2_01_the_station_6ee604de
    show ep2 thu_road_simon_another with d
    simon "(Is he taking me to a different police station?)" id ep2_01_the_station_fbd114e7
    simon "(Or maybe one in another town?)" id ep2_01_the_station_5e29ea3c
    simon "(What if he was actually sent by Lily's husband?)" id ep2_01_the_station_523e6bac
    show ep2 thu_road_simon_handcuff with d
    simon "(Well, at least he didn't handcuff me.)" id ep2_01_the_station_e0ab34af
    simon "(Is it actually possible to jump out of a moving car?)" id ep2_01_the_station_3d50eee8
    show ep2 thu_road_simon_thinking with d
    simon "(What am I thinking?)" id ep2_01_the_station_d2c132d6
    show ep2 thu_road_simon_out with d
    simon "(This guy's never going to let me go.)" id ep2_01_the_station_398ceaca
    simon "(What if he's a member of the mafia?)" id ep2_01_the_station_2ec0987c

    play sound hit_reverb_dark_1 volume 0.7
    show ep2 thu_road_simon_finger with d
    simon "(They're going to cut off my fingers!)" id ep2_01_the_station_3bdf277d
    simon "(I've seen it in the movies!)" id ep2_01_the_station_01544713
    play sound door_car2 volume 0.7
    show ep2 thu_road_simon_aaa with None
    simon "AAGGHH!" id ep2_01_the_station_19994ab3
    show ep2 thu_road_simon_illgo with d
    simon "All right, all right. I'm going." id ep2_01_the_station_228e3d6d
    show ep2 thu_road_simon_pinky with medium_dissolve
    simon "Could we settle for you just cutting off a pinky?" id ep2_01_the_station_ea3507d4
    show ep2 thu_road_cop_what with d
    cop "..." id ep2_01_the_station_7f3d54f7
    show ep2 thu_road_simon_mafia with d
    simon "You're not with the mafia, are you?" id ep2_01_the_station_a4b48aba
    show ep2 thu_road_simon_smellsbad with d
    simon "Something smells fishy here." id ep2_01_the_station_6fdb1eb1
    show ep2 thu_road_simon_nochoice with d
    simon "(I don't think I have a say in the matter.)" id ep2_01_the_station_083f9953
    stop music fadeout 5
    show ep2 thu_station_simon_thehell with fast_fade
    simon "(What the hell is going on?)" id ep2_01_the_station_0804adfa
    simon "(What is this place?)" id ep2_01_the_station_8f2b4251
    show ep2 thu_station_simon_here with d
    simon "(What am I doing here?!)" id ep2_01_the_station_6d6f096e
    play music game_changer volume 0.17
    show ep2 thu_station_dylan_long with None
    dy "Here at last!" id ep2_01_the_station_9a01c2ef

    dy "Took you long enough, bro." id ep2_01_the_station_9cde0366
    show ep2 thu_station_simon_dylan with d
    simon "Dylan! What are you...?" id ep2_01_the_station_2c72c35d
    show ep2 thu_station_simon_holdon with d
    simon "Wait a minute..." id ep2_01_the_station_ebed884e
    simon "... Was all of this your idea?" id ep2_01_the_station_be4d9f9b
    show ep2 thu_station_simon_pickup with d
    dylan "I couldn't find you anywhere, so I got worried." id ep2_01_the_station_1eb67046
    dylan "But then I remembered you sent me your location before and forgot to turn off the tracker." id ep2_01_the_station_4c6b587e
    dylan "So I asked them to pick you up." id ep2_01_the_station_10e8a91f
    show ep2 thu_station_dylan_preaching with d

    if chose('join_bookclub'):
        dylan "Since you decided to join the book club and help me with a certain Russian problem..." id ep2_01_the_station_9884b01a
        dylan "I decided I should do something for you." id ep2_01_the_station_03c86239
        dylan "My girls here will take care of you." id ep2_01_the_station_e906f4a4
    else:
        dylan "Maybe my girls here can convince you to join the book club." id ep2_01_the_station_51d9e96e
        dylan "That's sure to help me with a certain Russian problem." id ep2_01_the_station_79f02ff2
    show ep2 thu_station_dylan_ride with d
    dylan "But tell me... did you enjoy the ride here?" id ep2_01_the_station_2940465d
    show ep2 thu_station_dylan_thegirls with d
    dylan "And how about the chicks?" id ep2_01_the_station_08212346
    dylan "I did good, huh?" id ep2_01_the_station_f1ed4eff
    show ep2 thu_station_simon_cop with d
    simon "You thought it'd be a good idea to send a cop to arrest me?" id ep2_01_the_station_4b7eedae
    dylan "Yeah! That was dope, right?" id ep2_01_the_station_adcc6ebe
    show ep2 thu_station_dylan_what with d
    dylan "Wait. A cop?" id ep2_01_the_station_088700da
    show ep2 thu_station_simon_bigguy with d
    simon "The big guy out there you sent to pick me up." id ep2_01_the_station_ab6afaff
    show ep2 thu_station_dylan_alfredo with d
    dylan "Oh, you mean Alfredo!" id ep2_01_the_station_cff7f901
    dylan "He's the security guard here." id ep2_01_the_station_895a9ee9
    dylan "With him at the door, it guarantees only quality product goes in and out." id ep2_01_the_station_b685c869
    show ep2 thu_station_simon_products with d
    simon "What do you mean by product?" id ep2_01_the_station_00297d86
    show ep2 thu_station_dylan_thegoods with medium_dissolve
    dylan "Girls! Show him the goods!" id ep2_01_the_station_6c203f10
    show ep2 thu_station_simon_goods with d
    simon "The goods?" id ep2_01_the_station_69ef5659
    show ep2 thu_station_strippers with fast_fade
    simon "(I wonder if he means...)" id ep2_01_the_station_d480d3e8
    show ep2 thu_station_simon_notthat with fast_fade
    simon "(Of course that wasn't what he was talking about that.)" id ep2_01_the_station_b5b45dc3
    simon "(Honestly, I don't know how I can still be thinking about sex after everything with Lily.)" id ep2_01_the_station_f301d094
    show ep2 thu_station_simon_notknowing with d
    simon "(Dylan ended up helping me out without knowing he was doing it.)" id ep2_01_the_station_96fdfb02
    simon "(Sticking around Lily's would have been pushing my luck.)" id ep2_01_the_station_71761351
    play music lost_days fadeout 2 fadein 2 volume 0.17
    show ep2 thu_station_simon_whatsthis with d
    simon "So, what have we here?" id ep2_01_the_station_46bc80e8
    show ep2 thu_station_dylan_holdon with d
    dylan "Hold on, buddy." id ep2_01_the_station_de58883a
    dylan "Take it easy." id ep2_01_the_station_c2c74e23
    show ep2 thu_station_dylan_important with medium_dissolve
    dylan "This is an important choice." id ep2_01_the_station_719b2b24
    show ep2 thu_station_dylan_blue with d
    dylan "You can take the blue drink and relax, quietly enjoying your high." id ep2_01_the_station_141f2c22
    show ep2 thu_station_dylan_red with d
    dylan "Or you can go for the red drink, which will give you a more intense experience." id ep2_01_the_station_a7e0c3c9
    show ep2 thu_station_dylan_important with d
    dylan "The important thing is that, one way or another, you will make it to wonderland." id ep2_01_the_station_a8fdd2a3
    show ep2 thu_station_simon_whatdrinks with d
    simon "What's in each drink?" id ep2_01_the_station_2be10e40
    show ep2 thu_station_dylan_trustme with d
    dylan "Bro... just trust me." id ep2_01_the_station_f44d676e
    dylan "You pick one, and I'll have the other." id ep2_01_the_station_f2e9f933
    menu:
        "Blue"(True):
            show ep2 thu_station_angela_enjoy with d
            angela "Good choice!" id ep2_01_the_station_1c509574
            angela "Bottoms up!" id ep2_01_the_station_d0897df4
            show ep2 thu_station_dylan_blue_cheers with d

            play sound wineglass volume 0.7
            dylan "Cheers!"
            $ red_drink = False
        "Red"(True):
            show ep2 thu_station_devilla_enjoy with d
            devilla "Oh, someone likes to have fun!" id ep2_01_the_station_f239818b
            devilla "Enjoy!" id ep2_01_the_station_765f8220
            show ep2 thu_station_dylan_red_cheers with d
            play sound wineglass volume 0.7
            dylan "Cheers!"
            $ red_drink = True
    play sound human_drink_water volume 0.75
    show ep2 thu_station_dylan_bro with d


    dylan "Bro..." id ep2_01_the_station_8324bf67

    play sound whoosh_metallic_5 volume 0.7
    play music you_cant_stop_me fadeout 1 fadein 1
    show oppaiman_presents_white as ep2 with Fade(1,1.3,0.3, color= "#fff")
    pause 2
    show white as ep2 with white_fade
    scene white with None
    show ep2 titlecard with d
    $ on_screen_translation('{b}{color=#FFBA01}' + _t(episode_2_name), interact=False)
    pause 4
    $ on_screen_translation('{b}{color=#FFBA01}' + _t(episode_2_name), interact=False)
    stop music fadeout 4
    $ on_screen_translation('{b}{color=#FFBA01}' + _t(episode_2_name), interact=False)
    pause 4



    jump ep2_02_chloecall
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
