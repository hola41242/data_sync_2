label ep2_04b_roof:
    play music pasture_blues fadein 4 volume 0.15
    show ep2 thu_roof_simon_theroof with long_fade
    simon "The rooftop?" id ep2_04b_roof_3c9569cb
    show ep2 thu_roof_alyssa_night with medium_dissolve
    alyssa "Yep." id ep2_04b_roof_e455da7a
    alyssa "It's still a little early, but this place is just the best when night rolls around." id ep2_04b_roof_c711e513
    show ep2 thu_roof_alyssa_sit with wipeleft
    alyssa "I sometimes sit here after class just to clear my head." id ep2_04b_roof_31cf7804
    show ep2 thu_roof_simon_sit with medium_dissolve
    simon "You work two jobs. That must be so stressful." id ep2_04b_roof_d95cca03
    show ep2 thu_roof_alyssa_talks with d
    alyssa "Then I go home and take care of my two brothers."
    show ep2 thu_roof_alyssa_question with d
    alyssa "Do you have any siblings, [name]?" id ep2_04b_roof_633d91b8
    show ep2 thu_roof_simon_talks with d
    simon "No." id ep2_04b_roof_3f86a073
    simon "I don't think so." id ep2_04b_roof_55baa306
    show ep2 thu_roof_simon_silent with d
    alyssa "You don't think so?" id ep2_04b_roof_d1d7bc4f
    show ep2 thu_roof_simon_explain with d
    simon "I mean, I don't remember ever having siblings." id ep2_04b_roof_1b91781c
    simon "And my mother never mentioned a brother or a sister." id ep2_04b_roof_a3a9fb92
    simon "So I guess not." id ep2_04b_roof_1227c3b7
    show ep2 thu_roof_alyssa_happy with d
    alyssa "That doesn't seem like the sort of information she should keep from you." id ep2_04b_roof_20f9722e
    show ep2 thu_roof_simon_question with d
    simon "What's it like having two brothers?" id ep2_04b_roof_f08b8b93
    show ep2 thu_roof_alyssa_talks with d
    alyssa "It's hard being the only girl in the family." id ep2_04b_roof_05bf365f
    alyssa "But I'm the oldest, so they have to listen to me." id ep2_04b_roof_88d7750c
    show ep2 thu_roof_simon_talks with d
    simon "And I bet you kick their asses when they don't." id ep2_04b_roof_d394481f
    show ep2 thu_roof_alyssa_talks with d
    alyssa "It's happened more often than I'd care to admit. Hahaha." id ep2_04b_roof_8969685b
    alyssa "My mother lets them off the hook too easily." id ep2_04b_roof_bc6d79fc
    alyssa "Then I always have to be the mean one." id ep2_04b_roof_49141558
    show ep2 thu_roof_simon_question with d
    simon "What about your father?" id ep2_04b_roof_959a0fe8
    show ep2 thu_roof_alyssa_sad with d
    alyssa "He's...not around." id ep2_04b_roof_089b5c65
    show ep2 thu_roof_alyssa_silent with d
    simon "I see." id ep2_04b_roof_00a2964c
    show ep2 thu_roof_simon_sad with d
    simon "I'm with you there. My father's not around either." id ep2_04b_roof_876ce63b
    simon "He's been missing for a number of years now." id ep2_04b_roof_c67bf06c
    simon "I've been looking for him." id ep2_04b_roof_a911bbab
    show ep2 thu_roof_alyssa_sad with d
    alyssa "Sorry to hear that." id ep2_04b_roof_0a618d68
    show ep2 thu_roof_alyssa_silent with d
    simon "So am I."
    show ep2 thu_roof_both_sitting with long_dissolve
    pause
    show ep2 thu_roof_simon_happy with d
    simon "But, hey! New memories, right?" id ep2_04b_roof_c7180058
    simon "Wasn't that what you said?" id ep2_04b_roof_3bc74adb
    show ep2 thu_roof_alyssa_happy with d
    alyssa "Indeed. New memories!" id ep2_04b_roof_74267552
    show ep2 thu_roof_alyssa_looking with d
    alyssa "Speaking of memories, is she finally ready to show her face?" id ep2_04b_roof_075e5b06
    simon "She? Who?" id ep2_04b_roof_04e8be43
    show ep2 thu_roof_alyssa_moon with medium_dissolve
    alyssa "The moon! Isn't she pretty?" id ep2_04b_roof_57832ef7
    stop music fadeout 6
    show ep2 thu_roof_simon_pretty with medium_dissolve
    simon "Yep. She's gorgeous." id ep2_04b_roof_2341fc0c
    menu:
        "Lean in for a kiss"(True):
            play music can_i_be_forgiven fadein 1 volume 0.17
            show ep2 thu_roof_alyssa_ah with d
            alyssa "Ack." id ep2_04b_roof_b4367df3
            show ep2 thu_roof_simon_wrong with d
            simon "Did I read the situation wrong?" id ep2_04b_roof_705c32a5
            show ep2 thu_roof_alyssa_vibe with d
            alyssa "No... Not at all." id ep2_04b_roof_ebb53132
            alyssa "You just caught me off guard a little." id ep2_04b_roof_5132367d
            show ep2 thu_roof_kiss with medium_dissolve

            simon "(I'm glad she wanted this too.)" id ep2_04b_roof_206528e0
            show ep2 thu_roof_simon_thisplace with d
            simon "(And she's right. This place is nice.)" id ep2_04b_roof_b7e2a833
            simon "(I'm happy she trusts me enough to share it with me.)" id ep2_04b_roof_10378535
            show ep2 thu_roof_alyssa_well with d
            alyssa "Um, [name]?" id ep2_04b_roof_05eab46b

            show ep2 thu_roof_simon_second with d
            simon "Having second thoughts?" id ep2_04b_roof_276de040
            show ep2 thu_roof_alyssa_well with d
            alyssa "Yes..." id ep2_04b_roof_3224bbf2
            show ep2 thu_roof_alyssa_yesno with d
            alyssa "... And no." id ep2_04b_roof_6440aedf
            alyssa "It's not like I don't want this." id ep2_04b_roof_053e746b
            alyssa "It's just been a while since I was last with someone." id ep2_04b_roof_1be8262d
            show ep2 thu_roof_alyssa_hurt with d
            alyssa "And I've been hurt before..." id ep2_04b_roof_a3d9628b
            alyssa "... So I just want to take things slow." id ep2_04b_roof_3e6fbfc1
            alyssa "But I also don't want you to think I'm playing hard to get or something." id ep2_04b_roof_10d6c52c
            show ep2 thu_roof_simon_youresaying with d
            simon "So, what are you saying exactly?" id ep2_04b_roof_eae0afc4
            show ep2 thu_roof_alyssa_excited with d
            alyssa "I'm saying that I'm happy." id ep2_04b_roof_ecb0d603
            alyssa "And I want you to know that this is a big step for me." id ep2_04b_roof_9bfbf459
            alyssa "I'm glad you're here, taking it with me." id ep2_04b_roof_d85bc49b
            show ep2 thu_roof_simon_weregood with d
            simon "So, we're good?" id ep2_04b_roof_616636c7
            show ep2 thu_roof_alyssa_weregood with d
            alyssa "We're good." id ep2_04b_roof_1b72eefe
            alyssa "Shall we pick up where we left off?" id ep2_04b_roof_038a51e4
            show ep2 thu_roof_both_kiss with d
            simon "(It's good she got that off her chest.)" id ep2_04b_roof_d8eaea5b
            simon "(I can take things slow.)" id ep2_04b_roof_dc16bd38
            show ep2 thu_roof_alyssa_date with d
            alyssa "I didn't think tonight would turn into a date." id ep2_04b_roof_2d2bb56a
            alyssa "But I'm glad it did." id ep2_04b_roof_cfef3bef
            show ep2 thu_roof_alyssa_date2 with d
            simon "Me too."
            $ ep2_alyssa_kiss = True
            $ player_choice("ep2_alyssa_kiss:true")
            $ points_alyssa += 2
        "Don't do anything":
            $ player_choice("ep2_alyssa_kiss:false")
            $ ep2_alyssa_kiss = False
            pass
    show ep2 thu_roof_simon_thanks with medium_dissolve
    simon "Thank you for tonight." id ep2_04b_roof_47a5beb5
    simon "And you're right, by the way. This is a special place." id ep2_04b_roof_ce16109c
    simon "Thank you for sharing it with me." id ep2_04b_roof_04ebfa5d
    stop music fadeout 7
    show ep2 thu_roof_alyssa_go with medium_dissolve
    alyssa "Well, I think I should go now." id ep2_04b_roof_16c856f7
    alyssa "See you soon?" id ep2_04b_roof_91944167
    simon "Sure." id ep2_04b_roof_7d1120e8
    show ep2 thu_roof_alyssa_bye with long_fade
    alyssa "Bye, [name]." id ep2_04b_roof_899ec51e
    simon "Bye." id ep2_04b_roof_cd83eaef
    jump ep2_05_the_game
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
