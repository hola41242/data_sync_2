
label ep2_09_ending:
    play music please_let_me_know fadein 2 volume 0.3
    show ep2 fri_sexy_e_simon_bright with d
    simon "It's still so bright out there..." id ep2_09_ending_36e9df9f
    simon "Wait..." id ep2_09_ending_320b9734
    show ep2 fri_sexy_e_simon_outside with d
    simon "The power's on out there!" id ep2_09_ending_8fc0eb7f
    simon "Looks like the problem's in here!" id ep2_09_ending_4b38e12f
    show ep2 fri_sexy_e_sue_thatmeans with d
    sue "That means we can get the power back on!" id ep2_09_ending_03cb3348
    sue "We just have to find the fuse box!" id ep2_09_ending_2d4f1199
    show ep2 fri_sexy_e_simon_acback with d
    simon "So now you want the AC back on?" id ep2_09_ending_f519497e
    simon "Did you work up a sweat?" id ep2_09_ending_39f5ed36
    show ep2 fri_sexy_e_sue_funny with d
    sue "Oh, you're such a comedian..." id ep2_09_ending_1b4c33a2
    show ep2 fri_sexy_e_sue_router with d
    sue "If we find the fuse box, we should be able to reset the router." id ep2_09_ending_232032a6
    sue "That way, I can get a Wi-Fi signal on my phone again." id ep2_09_ending_4a440af8
    show ep2 fri_sexy_e_sue_foundit with d
    sue "Found it!" id ep2_09_ending_827a37c6
    show ep2 fri_sexy_e_sue_youdoit with d
    sue "I think you should do it." id ep2_09_ending_04541c35
    sue "I don't want to be close if it goes up in flames." id ep2_09_ending_0df790e4
    show ep2 fri_sexy_e_sue_flashlight with d
    sue "Here. Use this as a flashlight." id ep2_09_ending_66e06c72
    show ep2 fri_sexy_e_simon_flashlight with d
    simon "The flashlight function... Good idea!" id ep2_09_ending_ab529d61
    show ep2 fri_sexy_e_simon_screen with d
    simon "Could you unlock the screen for me please?" id ep2_09_ending_8dd160b1
    show ep2 fri_sexy_e_sue_password with medium_dissolve
    sue "The password is zero six twenty-two." id ep2_09_ending_5e4731fa
    show ep2 fri_sexy_e_simon_date with d
    simon "Six twenty-two. May twenty-second...?" id ep2_09_ending_baf6f095
    show ep2 fri_sexy_e_simon_uncle with d
    simon "That date..." id ep2_09_ending_29e448de
    stop music fadeout 3
    play sound unlock_phone volume 0.5
    show ep2 fri_sexy_e_simon_charlie with d
    simon "(Charlie!)" id ep2_09_ending_317e5029

    play sound vision_transition volume 0.7
    play music all_will_pass fadein 1 volume 0.15
    show ep2 fri_sexy_f_simon_where with white_fade
    play sound phone_ringing volume 0.5
    simon "(Where are you?)" id ep2_09_ending_d45eea20
    show ep2 fri_sexy_f_simon_rain with medium_dissolve
    simon "(It's about to rain.)" id ep2_09_ending_66fdc679
    show ep2 fri_sexy_f_simon_answers with medium_dissolve
    simon "(I need answers.)" id ep2_09_ending_569733a2
    stop sound
    show ep2 fri_sexy_f_simon_whereareyou with medium_dissolve
    simon "Hey! Where ARE you?" id ep2_09_ending_5fd07b72
    show ep2 fri_sexy_f_charlie_omw with medium_fade
    charlie "I'm on my way!" id ep2_09_ending_607a7c18
    show ep2 fri_sexy_f_charlie_rainsoon with medium_dissolve
    charlie "But it looks like it's about to rain." id ep2_09_ending_d7563a62
    charlie "Crazy weather today." id ep2_09_ending_3b361061
    show ep2 fri_sexy_f_simon_hurry with medium_fade
    simon "Hurry the fuck up!" id ep2_09_ending_9d6484aa
    show ep2 fri_sexy_f_charlie_bethere with medium_dissolve
    charlie "Relax, bud." (what_italic=True)
    charlie "I'll be there in a flash." (what_italic=True)
    show ep2 fri_sexy_f_simon_screw with medium_dissolve
    simon "Charlie, you really are a piece of shit!" id ep2_09_ending_7e006aef
    show ep2 fri_sexy_f_charlie_rainsoon with d
    charlie "Whoa. How about we calm down, champ?!" id ep2_09_ending_76b35484
    charlie "Let me just..." id ep2_09_ending_a09305fd
    charlie "Huh?" id ep2_09_ending_9426ad7b
    play sound riser_metallic volume 0.7
    show ep2 fri_sexy_f_charlie_acc with d
    pause 1.3
    show black as ep2 with None
    play sound crash_auto_4 volume 0.7
    stop music
    pause 3
    stop sound
    play sound hit_reverb_dark volume 0.7
    play music grim_reality volume 0.15

    show ep2 fri_sexy_f_simon_what with white_fade

    simon "What the...?" id ep2_09_ending_2f7e4b1f
    show ep2 fri_sexy_f_simon_charlie with medium_dissolve
    simon "Charlie? Charlie?!" id ep2_09_ending_7a8a352f
    play sound vision_transition volume 0.7

    show ep2 fri_sexy_e_simon_remember with white_fade
    simon "(I... I remember...)" id ep2_09_ending_71c096f8
    simon "(Susan...)" id ep2_09_ending_edb23d9d
    show ep2 fri_sexy_e_simon_thinking with d
    sue "If you're just going to stand there, I'll do it myself!" id ep2_09_ending_4159de7d
    show ep2 fri_sexy_e_sue_gotit with d
    simon "(I can hardly recognize myself in any of what I said.)" id ep2_09_ending_d4624ad8
    simon "(Charlie seemed like a very reserved guy.)" id ep2_09_ending_96526c01
    simon "(So why was I talking to him like that?)" id ep2_09_ending_84fea2ca
    simon "(And why was I so worked up?)" id ep2_09_ending_aaa2989b
    play sound power volume 0.75
    show ep2 fri_sexy_e_sue_click with d
    "*Click.*" (what_italic=True)
    sue "I got it!" id ep2_09_ending_0b0f3d65
    sue "Who says you need a man...?" id ep2_09_ending_f4344623
    show ep2 fri_sexy_e_sue_youok with d
    sue "Hey, [name]? Are you feeling all right?" id ep2_09_ending_a1865958
    show ep2 fri_sexy_e_sue_lights with d
    simon "Yeah... Just a headache." id ep2_09_ending_1dd41a04
    simon "It must be because of the light." id ep2_09_ending_fb9acb17
    simon "(Sue... Her uncle... Was it all my fault?)" id ep2_09_ending_c2f0c0f2
    show ep2 fri_sexy_e_simon_myfault with d
    sue "Shut your eyes for a bit." id ep2_09_ending_360566a9
    sue "I'll text auntie." id ep2_09_ending_809b2191
    show ep2 fri_sexy_e_sue_text with medium_dissolve
    sue "There! Auntie read my text!" id ep2_09_ending_65d7d3e2
    show ep2 fri_sexy_e_sue_shescoming with d
    sue "She says she's coming!" id ep2_09_ending_511520c2
    sue "She says she was so tired that she nearly forgot." id ep2_09_ending_1ad4122a
    sue "Luckily, she was still up, working on event stuff when she saw my text." id ep2_09_ending_31b74b06
    show ep2 fri_sexy_e_simon_coming with d
    simon "Is... Is she coming?" id ep2_09_ending_3f07fa3a
    show ep2 fri_sexy_e_simon_myfault with d
    sue "Yep. That's what I literally just said." id ep2_09_ending_2ba8925f

    show ep2 fri_sexy_e_susan_finally with medium_fade
    susan "(Finally...)" id ep2_09_ending_1e8da4a5
    play sound door_car volume 0.7
    show ep2 fri_sexy_e_ssusan_longer with d
    susan "(That took longer than I thought it would.)" id ep2_09_ending_a24d162d
    play sound door_car2 volume 0.8
    show ep2 fri_sexy_e_susan_itworked with d
    susan "(That was one of my better plans...)" id ep2_09_ending_0e2ef392
    play sound hit_reverb_dark_1 fadein 0.5
    show ep2 fri_sexy_e_susan_goodplan with d
    susan "(Let's hope it keeps working...)" id ep2_09_ending_d9e991bf
    jump ep2_10_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
