
label ep3_15_susankitchen2:
    play music late_at_night volume 0.15 fadeout 1 fadein 2
    show ep3 sat_susankitchen2_001 with d
    lily "(... So he confronted you about what happened to his father?)" (what_italic=True)
    show ep3 sat_susankitchen2_002 with d
    susan "That poor boy..." id ep3_15_susankitchen2_22edfd05
    susan "Can you believe he even said he remembered Charlie?" id ep3_15_susankitchen2_f9be4000
    show ep3 sat_susankitchen2_003 with d
    lily "I didn't know they ever met." id ep3_15_susankitchen2_dca2f707
    show ep3 sat_susankitchen2_004 with d
    susan "They couldn't have really known each other." id ep3_15_susankitchen2_413dca54
    susan "At least, Charlie never mentioned anything about him." id ep3_15_susankitchen2_d05d3cc7
    show ep3 sat_susankitchen2_005 with d
    lily "Charlie was a good husband." id ep3_15_susankitchen2_fdf98014
    lily "He wouldn't keep a secret like that." id ep3_15_susankitchen2_b7a9347f
    lily "Especially considering who [name]'s father is." id ep3_15_susankitchen2_1e9dc543
    show ep3 sat_susankitchen2_006 with d
    susan "[name]'s father... that poor man." id ep3_15_susankitchen2_73fc67ca
    susan "I don't know if the boy would ever forgive us if he found out what we did to his father." id ep3_15_susankitchen2_2ca66d86
    show ep3 sat_susankitchen2_007 with d
    lily "We? I carry no blame for anything that happened." id ep3_15_susankitchen2_07343228
    show ep3 sat_susankitchen2_008 with d
    lily "It was all Sam's fault." id ep3_15_susankitchen2_6e339ff0
    jump ep3_16_van4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
