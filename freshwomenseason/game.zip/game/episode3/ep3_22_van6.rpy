
label ep3_22_van6:
    play music magic_paper fadein 2.5 volume 0.7
    show ep3 sat_van6_053 with d
    simon "Okay, what's going on here?" id ep3_22_van6_fb5373b8

    show ep3 sat_van6_054 with vpunch
    chloe "Ack! You're still here?!" id ep3_22_van6_85d5835c

    if choice_made('ep3_sat_susanlily_close_the_lid'):
        show ep3 sat_van6_055 with d
        simon "I was taking a nap, but then I heard a noise and wanted to check it out." id ep3_22_van6_bc01dc86
        show ep3 sat_van6_056 with d
        simon "What's going on? Did you keep watching without me?" id ep3_22_van6_6c97b9a5
    else:

        show ep3 sat_van6_055 with d
        simon "I've been here this whole time." id ep3_22_van6_1056dc51
        show ep3 sat_van6_057 with d
        simon "And I saw everything." id ep3_22_van6_736c0e89

    show ep3 sat_van6_058 with d
    chloe "I... I..." id ep3_22_van6_1bf7343c
    show ep3 sat_van6_059 with d
    chloe "Well, can you blame me?" id ep3_22_van6_cd03f041
    chloe "Tell me you don't agree that they're both smoking hot?" id ep3_22_van6_a5d55ea7
    show ep3 sat_van6_060 with d
    simon "Uh... Didn't see that coming." id ep3_22_van6_f8d50e97
    show ep3 sat_van6_055 with d
    simon "I thought you just got off on watching people." id ep3_22_van6_463a6a50
    simon "I didn't know you were a lesbian." id ep3_22_van6_a45e4fd2
    show ep3 sat_van6_061 with d
    chloe "Well... I am into girls." id ep3_22_van6_dc36644d
    show ep3 sat_van6_062 with d
    chloe "I kept listening, hoping they might say something else that could be useful." id ep3_22_van6_89fe6752
    chloe "But that didn't happen." id ep3_22_van6_cf5e22ac
    show ep3 sat_van6_063 with d
    chloe "Anyway, it's getting late. We'd better find Dylan." id ep3_22_van6_a38a2908
    show ep3 sat_van6_064 with d
    chloe "Do you think he's all right?" id ep3_22_van6_7d94100c
    show ep3 sat_van6_065 with d
    simon "(She was being honest with me, but now she's trying her best to change the subject.)" id ep3_22_van6_b7f41801
    show ep3 sat_van6_066 with d
    dylan "Problem solved, dear fellows." (what_bold=True)

    show ep3 sat_van6_067 with d
    dylan "In my hometown, this would be any ol' Saturday." (what_bold=True)
    stop sound
    show ep3 sat_van6_068 with d
    dylan "Am I interrupting something?" (what_bold=True)
    show ep3 sat_van6_069 with d
    chloe "Dylan! Are you okay?" id ep3_22_van6_5e372cc3
    show ep3 sat_van6_067 with d
    dylan "Of course! A bear is no match for a real Russian." (what_bold=True)
    dylan "They've already come and taken away the bear." (what_bold=True)
    show ep3 sat_van6_070 with d
    dylan "So, are you ready?" (what_bold=True)
    show ep3 sat_van6_071 with d
    chloe "Take us away!"
    play sound slow_driving_interior fadein 1.5 volume 0.5
    show ep3 sat_van6_072 with d
    chloe "So, what's our plan?" id ep3_22_van6_bf1e5ab3
    show ep3 sat_van6_073 with d
    simon "I think I need to have a talk with Lily." id ep3_22_van6_35cdc773
    simon "She lied to me about my dad. She knows more than she let on." id ep3_22_van6_416047bb
    stop sound fadeout 3
    show ep3 sat_van6_074 with d
    chloe "What'll stop her from lying again?" id ep3_22_van6_eef41923
    show ep3 sat_van6_075 with d
    simon "Nothing." id ep3_22_van6_0cf14254
    show ep3 sat_van6_076 with d
    chloe "That's why we need a plan. A strategy, if you will." id ep3_22_van6_5bdfd84a
    chloe "We have to plan out what you're going to say." id ep3_22_van6_d8b3fcc7
    show ep3 sat_van6_073 with d
    simon "I don't even know when I'll be able to talk to her again." id ep3_22_van6_10912609
    simon "Last time we met, she didn't seem very open for a dialogue." id ep3_22_van6_c5e7143e
    simon "At least, not with me." id ep3_22_van6_e95822cc
    show ep3 sat_van6_076 with d
    chloe "It gives us a good place to start though." id ep3_22_van6_e0ba5048
    chloe "We can think about the when before thinking about the how." id ep3_22_van6_70d402cc
    show ep3 sat_van6_077 with d
    chloe "How about tomorrow?" id ep3_22_van6_5e9f8e9b
    chloe "That'll be Sunday, so she won't be expecting you." id ep3_22_van6_d11facf9
    show ep3 sat_van6_076 with d
    chloe "And that way, you can catch her by surprise while the subject is still fresh in her mind." id ep3_22_van6_3147b8cf
    show ep3 sat_van6_078 with d
    simon "Hmm... That might be a good idea." id ep3_22_van6_560615d0
    simon "If I go to her house and confront her, she won't be able to ignore me." id ep3_22_van6_817f0c16
    show ep3 sat_van6_079 with d
    chloe "Exactly!" id ep3_22_van6_8f8f78ff
    show ep3 sat_van6_076 with d
    chloe "Now we just have to think about what you should say." id ep3_22_van6_ddd4d953
    show ep3 sat_van6_080 with d
    chloe "Hey, Dylan, can we go straight past [name]'s house and head to mine instead?" id ep3_22_van6_42265a02
    chloe "We need to talk strategy." id ep3_22_van6_4e51f7c5
    show ep3 sat_van6_081 with d
    chloe "If that's all right with you of course." id ep3_22_van6_86f848f4
    show ep3 sat_van6_082 with d
    simon "Sounds fine to me." id ep3_22_van6_30dbedc9
    show ep3 sat_van6_081 with d
    chloe "Excellent!" id ep3_22_van6_49a1a08d
    show ep3 sat_van6_083 with d
    dylan "We're almost there. There's just one issue I've got." (what_bold=True)

    show ep3 sat_van6_084 with d
    dylan "*Yawn...* I'm so tired. I'm just going to drop you two off and head home, all right?" (what_bold=True)
    stop sound
    show ep3 sat_van6_085 with d
    chloe "Fine by me." id ep3_22_van6_6dcf5bcf
    show ep3 sat_van6_083 with d
    dylan "And even better for me!" (what_bold=True)
    jump ep3_23_chloehome1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
