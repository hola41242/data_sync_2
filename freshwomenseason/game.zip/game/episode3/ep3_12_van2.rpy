
label ep3_12_van2:
    show ep3 sat_van2_001 with d

    play sound cell_phone_vibrate volume 0.1
    chloe "Hmm..." id ep3_12_van2_c56309fb
    stop sound
    show ep3 sat_van2_002 with d
    chloe "Dylan, is that you? Why are you calling me from inside Susan's house? Isn't that risky?" id ep3_12_van2_e3736e64
    show ep3 sat_van2_003 with d
    simon "Is everything all right?" id ep3_12_van2_c0cd1ee2
    show ep3 sat_van2_002 with d
    chloe "What do you mean you're not inside her house?" id ep3_12_van2_2a97dadc
    jump ep3_13_susankitchen
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
