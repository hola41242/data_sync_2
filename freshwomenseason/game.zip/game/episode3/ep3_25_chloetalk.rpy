
label ep3_25_chloetalk:
    play sound door_closet_close volume 0.5
    stop music
    show ep3 sat_chloetalk_001 with long_fade
    play music late_at_night volume 0.5
    simon "(Better not dwell on everything that just happened...)" id ep3_25_chloetalk_4b6e2dc3
    show ep3 sat_chloetalk_002 with d
    simon "(I have to focus on what I'm going to say to Lily tomorrow.)" id ep3_25_chloetalk_c90b3210
    show ep3 sat_chloetalk_003 with d
    simon "(It's amazing how all it took for my thoughts to go straight back to Lily was being alone for one second.)" id ep3_25_chloetalk_ab86ea5a
    show ep3 sat_chloetalk_002 with d
    simon "(I have to find out what happened before this consumes me.)" id ep3_25_chloetalk_08d8d170
    chloe "I'm back!" id ep3_25_chloetalk_af5ddd9c
    play sound car_door_open volume 0.7
    show ep3 sat_chloetalk_004 with d
    simon "(Wow!)" id ep3_25_chloetalk_af0961e7
    play sound panties_off_1 volume 0.5
    show ep3 sat_chloetalk_005 with d
    chloe "So..." id ep3_25_chloetalk_9a6998c4
    show ep3 sat_chloetalk_006 with d
    chloe "Did you think about what you're going to say to Lily?" id ep3_25_chloetalk_d3f35f95
    show ep3 sat_chloetalk_007 with d
    simon "(She's acting like nothing crazy just had happened!)" id ep3_25_chloetalk_5f8cade8
    show ep3 sat_chloetalk_008 with d
    simon "Not yet..." id ep3_25_chloetalk_c7a984cd
    show ep3 sat_chloetalk_009 with d
    chloe "We'll think of something." id ep3_25_chloetalk_e54d6032
    chloe "The important thing is that you have to confront her." id ep3_25_chloetalk_2d8667b8
    show ep3 sat_chloetalk_010 with d
    simon "Confront her... That's right." id ep3_25_chloetalk_b6af1c65
    simon "I have to talk to her face-to-face about this." id ep3_25_chloetalk_016886db
    show ep3 sat_chloetalk_011 with d
    chloe "The difficult part now is explaining how you learned she had something to do with your father's disappearance'." id ep3_25_chloetalk_1591bfcd
    show ep3 sat_chloetalk_012 with d
    simon "I can always say that I remembered something." id ep3_25_chloetalk_e62a6007
    show ep3 sat_chloetalk_013 with d
    chloe "That might work, but she also might get a bit suspicious." id ep3_25_chloetalk_4eabd369
    show ep3 sat_chloetalk_014 with d
    simon "At this point, who cares what she thinks?" id ep3_25_chloetalk_6f3c8cbd
    show ep3 sat_chloetalk_013 with d
    chloe "True." id ep3_25_chloetalk_9ba22c0b
    show ep3 sat_chloetalk_015 with d
    chloe "See? You found your approach!" id ep3_25_chloetalk_4752410d
    show ep3 sat_chloetalk_016 with d
    simon "I did! Thanks, Chloe." id ep3_25_chloetalk_997ff898
    show ep3 sat_chloetalk_017 with d
    chloe "Now just follow your instincts..." id ep3_25_chloetalk_57711ff6
    show ep3 sat_chloetalk_018 with d
    chloe "... Then everything will turn out all right." id ep3_25_chloetalk_05b7abd6
    show ep3 sat_chloetalk_019 with d
    simon "(She must be pretty tired... I think we'd better get some sleep.)" id ep3_25_chloetalk_b917046f
    show ep3 sat_chloetalk_020 with d
    simon "Um, Chloe? It's getting late..." id ep3_25_chloetalk_530030d0
    show ep3 sat_chloetalk_021 with d
    chloe "It is. I think we'd better get some shut-eye." id ep3_25_chloetalk_7e14da6f

    if choice_made('ep3_sat_chloesex_remove_clothes'):
        play sound bed_movement_5 volume 0.3
        show ep3 sat_chloetalk_011 with d
        chloe "But before that..." id ep3_25_chloetalk_f5a93c7c
        chloe "Everything we did just a second ago..." id ep3_25_chloetalk_cf909309
        show ep3 sat_chloetalk_019 with d
        chloe "Thank you for not judging me." id ep3_25_chloetalk_7de57773
        show ep3 sat_chloetalk_028 with d
        chloe "I sometimes feel guilty for being like that." id ep3_25_chloetalk_4290c107
        chloe "But it felt so good." id ep3_25_chloetalk_e2d21a1a
        show ep3 sat_chloetalk_011 with d
        chloe "Should I feel bad about it?" id ep3_25_chloetalk_78c800e6

        menu:
            "I don't think so"(True):
                $ ep3_chloetalk_no = True
                $ player_choice("ep3_chloetalk_no:true")
                show ep3 sat_chloetalk_012 with d
                simon "I don't think so." id ep3_25_chloetalk_55baa306
                simon "If it makes you feel good and no one gets hurt, there's nothing to feel bad about." id ep3_25_chloetalk_ca2a8380
                show ep3 sat_chloetalk_022 with d
                chloe "Thanks, [name]! You're the best." id ep3_25_chloetalk_77987b20
                $ points_chloe += 1
            "A little":
                $ ep3_chloetalk_yes = True
                $ player_choice("ep3_chloetalk_yes:true")
                show ep3 sat_chloetalk_012 with d
                simon "I've never met anyone like you, so I can't really say for sure." id ep3_25_chloetalk_636e971a
                show ep3 sat_chloetalk_013 with d
                simon "It was... unusual." id ep3_25_chloetalk_36ce29c3
                simon "Even a little scary at times." id ep3_25_chloetalk_e381816a
                show ep3 sat_chloetalk_022 with d
                chloe "Well..." id ep3_25_chloetalk_cd34bbee
                chloe "You've got nothing to be scared of." id ep3_25_chloetalk_1e7f4263
            "Maybe about the lying part":
                $ ep3_chloetalk_maybe = True
                $ player_choice("ep3_chloetalk_maybe:true")
                show ep3 sat_chloetalk_006 with d
                simon "I don't think so, but you did lie to me about your parents." id ep3_25_chloetalk_be5156cb
                simon "Though it was part of the whole experience, I think you could've been more upfront about what was going on." id ep3_25_chloetalk_4f219877
                show ep3 sat_chloetalk_016 with d
                simon "No hard feelings though. And no regrets." id ep3_25_chloetalk_c29ffebe
                show ep3 sat_chloetalk_022 with d
                chloe "Thanks, [name]! I'll work on that part." id ep3_25_chloetalk_88c002fe

        show ep3 sat_chloetalk_022 with d
        chloe "Zzzzz." id ep3_25_chloetalk_dd908457
        show ep3 sat_chloetalk_023 with d
        simon "(She didn't get another word out! Must have really worn herself out.)" id ep3_25_chloetalk_1ed9499a
        show ep3 sat_chloetalk_024 with d
        simon "(Maybe I should hold off on sleep though.)" id ep3_25_chloetalk_b58b02ed
        simon "(Only now in this moment of silence am I really able to reflect on what's going on.)" id ep3_25_chloetalk_a3a9de86
        play sound bed_movement_1 volume 0.7
        show ep3 sat_chloetalk_025 with d
        simon "(Sorry, Chloe...)" id ep3_25_chloetalk_7466dc4d
        show ep3 sat_chloetalk_026 with d
        simon "(... But I'm not going to watch you sleep.)" id ep3_25_chloetalk_e51287d6
        show ep3 sat_chloetalk_027 with d
        simon "(I need to go over my plan.)" id ep3_25_chloetalk_2db27ea9
        play sound door_closing2 volume 0.7
        show black
    else:

        show ep3 sat_chloetalk_028 with d
        chloe "I mean, you must be tired too, right?" id ep3_25_chloetalk_af15da4e
        chloe "You can stay in my room if you'd like..." id ep3_25_chloetalk_f0ec2dc2
        play sound bed_movement_1 volume 0.7
        show ep3 sat_chloetalk_029 with d
        simon "That's not necessary. I'll take the sofa." id ep3_25_chloetalk_20db3204
        show ep3 sat_chloetalk_030 with d
        simon "It's not like I'm going to be able to sleep anyway." id ep3_25_chloetalk_b96725b6
        play sound door_closing2 volume 0.7
        show black

    jump ep3_26_decision
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
