
label ep3_05_dylan_bike:
    play music so_fine volume 0.3 fadein 2 fadeout 2
    show ep3 sat_dylan_bike_001 with long_fade
    simon "So... what will you do now that you're a free man?" id ep3_05_dylan_bike_81365efb
    show ep3 sat_dylan_bike_002 with d
    dylan "Let's see..." id ep3_05_dylan_bike_96b85207
    show ep3 sat_dylan_bike_003 with d
    dylan "Hmm..." id ep3_05_dylan_bike_3b57c19d
    show ep3 sat_dylan_bike_004 with d
    dylan "Ah-ha! Found it!" id ep3_05_dylan_bike_57140985
    show ep3 sat_dylan_bike_005 with d
    simon "Found... what?" id ep3_05_dylan_bike_558bd1fc
    simon "Is that your scooter?" id ep3_05_dylan_bike_d411f99f
    show ep3 sat_dylan_bike_006 with d
    dylan "She's my treasure!" id ep3_05_dylan_bike_382a9edb
    dylan "I love vintage wheels." id ep3_05_dylan_bike_6067887d
    show ep3 sat_dylan_bike_007 with d
    dylan "Bro..." id ep3_05_dylan_bike_8324bf67

    if choice_made('ep3_04_challenge_won'):
        show ep3 sat_dylan_bike_008 with d
        dylan "Thanks for helping back there." id ep3_05_dylan_bike_9774d2b7
        dylan "It's nice to have someone you can count on." id ep3_05_dylan_bike_e62d2744
        play sound brofist volume 0.5
        show ep3 sat_dylan_bike_009 with d
        simon "You can always count on me, bro." id ep3_05_dylan_bike_8e58dded
    else:
        show ep3 sat_dylan_bike_010 with d
        dylan "Thanks for trying, dude." id ep3_05_dylan_bike_14c66d84

    show ep3 sat_dylan_bike_011 with d
    dylan "As a token of my gratitude, I'd like to offer you a ride." id ep3_05_dylan_bike_bae0ff02
    show ep3 sat_dylan_bike_012 with d
    dylan "So, where can I take you?" id ep3_05_dylan_bike_9bcb349c
    show ep3 sat_dylan_bike_013 with d
    simon "Actually, I told Chloe I'd meet her at the mall later today..." id ep3_05_dylan_bike_b597ea97
    simon "But I can just take the bus..." id ep3_05_dylan_bike_2fcac70b
    show ep3 sat_dylan_bike_014 with d
    simon "Shit! I'm already running late!" id ep3_05_dylan_bike_5d86e6b2
    show ep3 sat_dylan_bike_015 with d
    dylan "Hmmm. Someone's got a date with Chloe..." id ep3_05_dylan_bike_620b7415

    if choice_made('let_dylan_help'):
        show ep3 sat_dylan_bike_016 with d
        dylan "Be honest with her." id ep3_05_dylan_bike_d2012646
        dylan "Explain why you were late, and she'll understand." id ep3_05_dylan_bike_b0e8a01d
        dylan "Lying to Chloe is always a bad idea." id ep3_05_dylan_bike_557125e7
        show ep3 sat_dylan_bike_017 with d
        simon "But isn't that what you do every day? Lie to her?" id ep3_05_dylan_bike_d068fa58
        show ep3 sat_dylan_bike_018 with d
        dylan "That's not exactly what I'm doing..." id ep3_05_dylan_bike_1aa97fa0
        show ep3 sat_dylan_bike_016 with d
        dylan "Anyway, remember that. You've got to be honest with her, always." id ep3_05_dylan_bike_cf6b95e3

    show ep3 sat_dylan_bike_019 with d
    dylan "Shall we?" id ep3_05_dylan_bike_ab2446c3
    show ep3 sat_dylan_bike_020 with d
    simon "Beats being late." id ep3_05_dylan_bike_934c1211
    show ep3 sat_dylan_bike_021 with d
    simon "Is this thing really safe?" id ep3_05_dylan_bike_01657907
    show ep3 sat_dylan_bike_022 with d
    dylan "Of course she is." id ep3_05_dylan_bike_9a570210
    play sound scooter_start volume 0.8
    show ep3 sat_dylan_bike_023 with vpunch
    simon "WHOA! TAKE IT EASY, DYLAN!" id ep3_05_dylan_bike_0b547242
    show ep3 sat_dylan_bike_024 with d
    simon "AAAGGHH! WE'RE GONNA DIE... We're..." id ep3_05_dylan_bike_d36e7d12
    show ep3 sat_dylan_bike_025 with d
    dylan "Hehehe." id ep3_05_dylan_bike_fa8ba835
    simon "Shut up." id ep3_05_dylan_bike_c61a05b7
    play sound scooter_end volume 0.5
    show ep3 sat_dylan_bike_026 with d
    dylan "We're here, partner!" id ep3_05_dylan_bike_61c33c9d
    show ep3 sat_dylan_bike_027 with d
    dylan "Where's Chloe?" id ep3_05_dylan_bike_4444b8a3
    show ep3 sat_dylan_bike_028 with d
    simon "She's inside, sitting at a café." id ep3_05_dylan_bike_1d2a1782
    play sound brofist volume 0.5
    show ep3 sat_dylan_bike_029 with d
    simon "Thanks, bro." id ep3_05_dylan_bike_fc12430a
    play sound scooter_start volume 0.5
    show ep3 sat_dylan_bike_030 with d
    dylan "(Go get her, tiger.)" id ep3_05_dylan_bike_dd3ec621
    stop music fadeout 7
    jump ep3_06_cafe
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
