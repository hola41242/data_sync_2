
label ep3_18_van5:
    stop music fadeout 2
    show ep3 sat_van5_001 with medium_fade
    chloe "Hey, [name]? Are you all right?" (what_italic=True)
    show ep3 sat_van5_002 with d
    play music late_at_night volume 0.3 fadein 3
    simon "Let's keep listening in." id ep3_18_van5_47558208
    jump ep3_19_susankitchen3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
