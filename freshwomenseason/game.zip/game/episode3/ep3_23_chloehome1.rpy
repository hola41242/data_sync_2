
label ep3_23_chloehome1:
    play music late_at_night fadeout 3 fadein 3 volume 0.5
    play sound engine volume 0.8
    show ep3 sat_chloehome1_001 with long_fade
    dylan "Hey, we're here." (what_bold=True)
    play sound car_door_open volume 0.7
    show ep3 sat_chloehome1_002 with d
    chloe "Thanks, Dylan! See you Monday." id ep3_23_chloehome1_040e20ff
    show ep3 sat_chloehome1_003 with d
    simon "Thanks, dude." id ep3_23_chloehome1_84bcfd05
    show ep3 sat_chloehome1_004 with d
    dylan "Not so fast, bro." id ep3_23_chloehome1_7c53e5b1
    show ep3 sat_chloehome1_005 with d
    dylan "I don't know what happened back there, but if Chloe is offering to help, it must have been heavy." id ep3_23_chloehome1_02b826b9
    dylan "Let me know if you need anything." id ep3_23_chloehome1_cb56b7c4
    show ep3 sat_chloehome1_006 with d
    dylan "And take good care of her." id ep3_23_chloehome1_92d8addf

    if choice_made('let_dylan_help'):
        dylan "This is your chance, bro!" id ep3_23_chloehome1_65346573

    show ep3 sat_chloehome1_007 with d
    chloe "Hey, [name]! Come on!" id ep3_23_chloehome1_055ad4d5
    show ep3 sat_chloehome1_008 with d
    dylan "Go get her, tiger." id ep3_23_chloehome1_554046f2
    play sound engine volume 0.6
    show ep3 sat_chloehome1_009 with d
    simon "(\"Go get her?\" He knows she's a lesbian, right?)"
    show ep3 sat_chloehome1_010 with d
    chloe "We're here!" id ep3_23_chloehome1_46580d9d
    show ep3 sat_chloehome1_011 with d
    simon "This is only just occurring to me, but won't your parents mind? It is quite late." id ep3_23_chloehome1_710df246
    show ep3 sat_chloehome1_012 with d
    chloe "Don't worry. They're out of town!" id ep3_23_chloehome1_d414f20a
    chloe "Come in. Make yourself at home!" id ep3_23_chloehome1_0669b6af

    jump ep3_24_chloesex
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
