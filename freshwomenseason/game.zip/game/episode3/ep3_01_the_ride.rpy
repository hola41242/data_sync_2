label ep3_01_the_ride:
    $ validate_mods()
    play music late_at_night fadein 5 volume 0.2

    scene ep3 fri_storage_sue_onherway with long_fade
    hide ep2
    sue "She says she's on her way." id ep3_01_the_ride_7789f164
    show ep3 fri_storage_sue_sleepy with d
    sue "I'm so sleepy." id ep3_01_the_ride_6d8dd471
    sue "I can hardly wait to cuddle up in my nice, warm bed." id ep3_01_the_ride_5b97ed99
    show ep3 fri_storage_sue_goodbed with d
    sue "Even though you're pretty squishy where it counts, nothing beats my own bed." id ep3_01_the_ride_15c4b4d2
    sue "Maybe one day you can drop by and —" id ep3_01_the_ride_bedb8a7f
    show ep3 fri_storage_simon_accident with d
    simon "What happened the night your uncle got in that accident?" id ep3_01_the_ride_1804c5bc
    show ep3 fri_storage_sue_night with d
    sue "Night? How did you know it happened at night?" id ep3_01_the_ride_7d8c2a5c
    show ep3 fri_storage_simon_i with d
    simon "I —" id ep3_01_the_ride_9bf3b23a
    play sound door_key volume 0.8
    show ep3 fri_storage_keys with d
    pause 1.9
    play sound door_opening volume 0.7
    show ep3 fri_storage_susan_enters with vpunch
    susan "Here I am!" id ep3_01_the_ride_5fcb86b4
    show ep3 fri_storage_susan_enters2 with d
    sue "Auntie!" id ep3_01_the_ride_174ec012
    show ep3 fri_storage_sue_hug with d
    sue "I'm so glad you came back for us, auntie!" id ep3_01_the_ride_2e698c8b
    show ep3 fri_storage_sue_hug2 with d
    pause
    show ep3 fri_storage_sue_aunt with d
    sue "I mean, Aunt Susan." id ep3_01_the_ride_a0da1c17
    show ep3 fri_storage_susan_youok with d
    susan "Are you two okay?" id ep3_01_the_ride_93ff28c3
    susan "I was so distracted with work, I didn't even realize I left you back here." id ep3_01_the_ride_a45dc647
    show ep3 fri_storage_sue_werefine with d
    sue "It's okay, auntie." id ep3_01_the_ride_1d7fa638
    sue "We're fine!" id ep3_01_the_ride_04da4f0c
    show ep3 fri_storage_simon_complaining with d
    simon "(She was complaining just a minute ago...)" id ep3_01_the_ride_e60095cd
    show ep3 fri_storage_simon_doesntmatter with d
    simon "(But who cares?)" id ep3_01_the_ride_6a698fdc
    play sound door_opening volume 0.7
    show ep3 fri_storage_simon_onlything with d
    simon "(The only thing that matters now is...)" id ep3_01_the_ride_78982158
    show ep3 fri_storage_susan_shallwe with d
    susan "Shall we, [name]?" id ep3_01_the_ride_47def1fd
    show ep3 fri_storage_simon_allthatmatters with d
    simon "(... Susan.)" id ep3_01_the_ride_4f23de7a

    play sound car_interior_1 volume 0.2 loop
    show ep3 fri_car_susan_first with medium_fade
    susan "So who should I drop off first?" id ep3_01_the_ride_4e80ab6e
    show ep3 fri_car_simon_sue with d
    simon "Sue." id ep3_01_the_ride_b6cb0dcb
    simon "My house is further away, so you should take Sue home first." id ep3_01_the_ride_c7faf921
    show ep3 fri_car_susan_notexactly with d
    susan "It's not all that far... but, okay, Sue first." id ep3_01_the_ride_b4a1e1d2
    show ep3 fri_car_susan_gettoknow with d

    susan "So..." id ep3_01_the_ride_11fb11ad
    susan "I hope my absent-mindedness gave you two a chance to get better acquainted at least." id ep3_01_the_ride_368670d7
    show ep3 fri_car_simon_nothing with d
    simon "Yeah, it was really nothing." id ep3_01_the_ride_6350208d

    show ep3 fri_car_susan_heresue with fade
    pause    
    play sound car_engine_off volume 0.3
    show ep3 fri_car_sue_thanksauntie2 with d
    susan "We're here, Sue." id ep3_01_the_ride_33051246
    play sound car_door_open volume 0.5
    show ep3 fri_car_sue_thanksauntie with fast_fade
    sue "Thank you, auntie." id ep3_01_the_ride_f58a3207
    show ep3 fri_car_sue_useful with d
    sue "You were a great help, [name]." id ep3_01_the_ride_a8609393
    sue "Thanks." id ep3_01_the_ride_37c9fba0
    show ep3 fri_car_susan_front with d
    susan "Why don't you take the front seat, [name]?" id ep3_01_the_ride_3e3dd808

    play sound car_interior_1 loop volume 0.2
    stop music fadeout 5
    show ep3 fri_car_susan_closer with fade
    susan "Looks like you and Sue worked a few things out." id ep3_01_the_ride_7e6fc8e2
    susan "Is there something you wanted to talk about?" id ep3_01_the_ride_b9d25337
    show ep3 fri_car_simon_youdo with d
    simon "I think there are a few things you need to open up about."
    show ep3 fri_car_susan_howso with d
    susan "What things?" id ep3_01_the_ride_3d695c47
    show ep3 fri_car_simon_charlie with d

    play music the_old_house volume 0.15
    simon "Charlie!" id ep3_01_the_ride_5572d149
    show ep3 fri_car_susan_isee with d
    susan "I see..." id ep3_01_the_ride_5039d9d1
    stop sound fadeout 1.5
    show ep3 fri_car_susan_youremember with d
    susan "Then you remember." id ep3_01_the_ride_c4f944ea
    susan "Your mother said this might happen." id ep3_01_the_ride_669bbea6
    show ep3 fri_car_simon_expected with d
    simon "(That's not the reaction I expected.)" id ep3_01_the_ride_5a6f0282
    show ep3 fri_car_susan_alright with d
    susan "All right. I promised your mother I'd look after you." id ep3_01_the_ride_8b468023
    show ep3 fri_car_susan_yourfather with d
    susan "I think telling you the truth is part of that." id ep3_01_the_ride_aad24c49
    show ep3 fri_car_simon_finally with d
    simon "Finally." id ep3_01_the_ride_f28d0b30
    show ep3 fri_car_susan_yourfather with d
    susan "Your father..." id ep3_01_the_ride_86d3a2c4

    show ep3 fri_office_architecture with white_fade
    susan "His architecture firm had their office in the mall near my store." id ep3_01_the_ride_529e1ce1
    show ep3 fri_office_advisor with d
    susan "I used to act as his fashion advisor." id ep3_01_the_ride_20b3a9b3
    susan "That's how he met Charlie." id ep3_01_the_ride_0768ba81
    show ep3 fri_office_along_well with d
    susan "They hit it off at once." id ep3_01_the_ride_dfe17168
    susan "Soon, they started working on projects together." id ep3_01_the_ride_bdfecfd5
    show ep3 fri_car_question with white_fade
    simon "What about Mr. Alderson?" id ep3_01_the_ride_6f12bf7a
    simon "Did he work with them too?" id ep3_01_the_ride_ceb6a3f8
    show ep3 fri_office_lilyshusband with white_fade
    susan "Ah, yes, Lily's husband." id ep3_01_the_ride_baa2e6b8
    show ep3 fri_office_worked_close with d
    susan "He worked very closely with your father." id ep3_01_the_ride_6a9a7ffc
    susan "But I don't know him very well." id ep3_01_the_ride_9bdf5495
    show ep3 fri_office_influence with d
    susan "All I know is that he seemed to have a great influence on your father." id ep3_01_the_ride_d608f144
    susan "Lily might be able to tell you more about that." id ep3_01_the_ride_8435e958
    simon "(I doubt Lily wants to open up about her husband.)" id ep3_01_the_ride_1147f05a
    show ep3 fri_car_question with white_fade
    simon "Tell me about the accident. What happened?" id ep3_01_the_ride_b9724611
    show ep3 fri_car_susan_whatsthis with d
    susan "What is this about, [name]?" id ep3_01_the_ride_912c1fa0
    show ep3 fri_car_explains with d
    simon "Well, if Charlie worked with my dad, that explains how I might have met him." id ep3_01_the_ride_a121c184
    show ep3 fri_car_husband with d
    susan "You met my husband?" id ep3_01_the_ride_8147f5b4
    show ep3 fri_car_simon_sheknew with d
    simon "(Shit. I thought she knew!)" id ep3_01_the_ride_8928d85a
    simon "(She should know.)" id ep3_01_the_ride_8b068497
    simon "(Unless our meeting was a secret...)" id ep3_01_the_ride_0d958993
    show ep3 fri_car_simon_remembered with d
    simon "I remembered something about him." id ep3_01_the_ride_fd4ef24a
    show ep3 fri_car_susan_whatsthis with d
    susan "What did you remember?" id ep3_01_the_ride_6eaa7238

    menu:
        "Tell her the truth"(True):
            $ ep3_the_ride_tell_her_the_truth = True
            $ player_choice("ep3_the_ride_tell_her_the_truth:true")
            show ep3 fri_car_night_accident with d
            simon "I remember talking to him the night of the accident." id ep3_01_the_ride_0a398997
            show ep3 fri_car_simon_sayless with d
            simon "(I'd better stop with that though.)" id ep3_01_the_ride_0140857a
            show ep3 fri_car_susan_thatnight with d
            susan "That night..." id ep3_01_the_ride_a452bc71
            susan "That was the night of your accident too, wasn't it?" id ep3_01_the_ride_a829f103
            show ep3 fri_car_susan_whatsthis with d
            susan "There's no way you could have known Charlie." id ep3_01_the_ride_550464a0
            susan "It's probably just your mind playing tricks on you." id ep3_01_the_ride_24380e5b
        "Lie":

            $ ep3_the_ride_tell_her_the_truth = False
            $ player_choice("ep3_the_ride_tell_her_the_truth:false")
            show ep3 fri_car_simon_flash with d
            simon "I just caught this flash of him." id ep3_01_the_ride_8e80c5c2
            simon "I didn't think much of it. He was just in this memory I recalled." id ep3_01_the_ride_9bfcb412
            show ep3 fri_car_susan_thatit with d



    susan "Is that it?" id ep3_01_the_ride_b2f67f41
    susan "Are you sure there was nothing else?" id ep3_01_the_ride_087fd24e
    show ep3 fri_car_simon_sayless with d
    simon "(I think I've shared enough information.)" id ep3_01_the_ride_5ae9c81b
    stop music fadeout 4
    play sound door_car volume 0.7
    show ep3 fri_car_simon_shouldgo with d
    simon "That was it." id ep3_01_the_ride_3ac0742b
    simon "And it's getting really late. I should go." id ep3_01_the_ride_daa19085
    play sound door_car2 volume 0.7
    show ep3 fri_car_susan_sure with d
    susan "Oh, right." id ep3_01_the_ride_e2d65352
    susan "Let me know if you remember anything else." id ep3_01_the_ride_22596ed8
    show ep3 fri_car_susan_night with d
    susan "Have a nice weekend, [name]." id ep3_01_the_ride_73d34eb1
    susan "See you Monday." id ep3_01_the_ride_1fc440c9
    play sound engine volume 0.5
    play music circularity volume 0.3 fadein 2 

    show ep3 fri_home_understand with fade
    simon "Damn. The more I find out, the less sense it all makes." id ep3_01_the_ride_40a44429
    show ep3 fri_home_huh with d
    simon "Huh?" id ep3_01_the_ride_196da51b
    simon "So many texts." id ep3_01_the_ride_5625cefa
    show ep3 fri_home_next with d
    if choice_made('ep2_dictionarygirl'):
        chloe "Hey, [name]! Can we meet up on Sunday? I have some news for you. XOXO, Dictionary Girl." (what_italic=True)
    else:
        chloe "Hey, [name]! Can we meet up on Sunday? I have some news for you." (what_italic=True)

    simon "(Meeting up with Chloe couldn't hurt.)" id ep3_01_the_ride_6a977e2c
    simon "(Besides all this investigation stuff, she might be able to give me a few tips about college life.)" id ep3_01_the_ride_568c1709
    simon "(Next text.)" id ep3_01_the_ride_1aa4861b
    alyssa "Hey, [name]! How are you? I'm just texting to let you know Tyler's okay. I thought you might like to know." (what_italic=True)

    if choice_made('ep2_alyssa_kiss'):
        alyssa "P.S. I hope to see you again soon." id ep3_01_the_ride_97283fea

    simon "(Tyler's the guy who rolled his ankle at dance practice.)" id ep3_01_the_ride_6978362c
    simon "(Good to know he's okay.)" id ep3_01_the_ride_988c980e
    simon "(Alyssa's not involved in any of this stuff regarding my past.)" id ep3_01_the_ride_7d578196
    simon "(It would be great to spend time with her and get away from all this.)" id ep3_01_the_ride_46da948a
    show ep3 fri_home_dylan with d
    simon "(The last text is from Dylan.)" id ep3_01_the_ride_73368750
    dylan "Bro! Where are you???" (what_italic=True)

    play sound dress volume 0.3 
    show ep3 fri_home_reply with d
    simon "I'll reply to you tomorrow, Dylan." id ep3_01_the_ride_dd59d45d
    show ep3 fri_home_tomorrow with d
    simon "I'm in no shape to deal with you right now." id ep3_01_the_ride_8b171ed0


    jump ep3_02_dylan_call
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
