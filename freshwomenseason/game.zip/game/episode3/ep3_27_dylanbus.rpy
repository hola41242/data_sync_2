
label ep3_27_dylanbus:
    show ep3 sun_dylanbus_001 with fade
    simon "(She's right...)" id ep3_27_dylanbus_6f713a9c
    play music swag_on fadein 3 volume 0.35
    show ep3 sun_dylanbus_002 with d
    simon "(I need to stay focused!)" id ep3_27_dylanbus_42538586
    dylan "Sup, bro!" id ep3_27_dylanbus_e35ff460
    show ep3 sun_dylanbus_003 with d
    simon "Dylan?!" id ep3_27_dylanbus_1ccb905b
    show ep3 sun_dylanbus_004 with d
    simon "(This is exactly what I don't need right now!)" id ep3_27_dylanbus_48905473
    show ep3 sun_dylanbus_005 with d
    dylan "You spent the night at Chloe's house, you dog!" id ep3_27_dylanbus_a9a3b5dc
    show ep3 sun_dylanbus_006 with d
    simon "You're the one who dropped me off there." id ep3_27_dylanbus_78262933
    show ep3 sun_dylanbus_007 with d
    simon "Wait, what are you doing here?" id ep3_27_dylanbus_5f0b606c
    simon "Did you sleep on her porch?" id ep3_27_dylanbus_31589588
    show ep3 sun_dylanbus_008 with d
    simon "You're wearing different clothes, so I guess that's not it..." id ep3_27_dylanbus_47a7a5f6
    show ep3 sun_dylanbus_009 with d
    dylan "Oh, I live right over there. I saw you waiting for the bus and decided to come lend a hand." id ep3_27_dylanbus_363ec9f0
    show ep3 sun_dylanbus_009_1 with d
    simon "(He lives right next to Chloe, yet she still doesn't suspect the fake accent?)" id ep3_27_dylanbus_3b5cb3ef
    simon "(I'm starting to doubt her intelligence...)" id ep3_27_dylanbus_e8ea99e1
    simon "(Hold up! I'm losing focus! Lily!)" id ep3_27_dylanbus_37a2931a
    show ep3 sun_dylanbus_010 with d
    simon "Gotcha." id ep3_27_dylanbus_35d28843
    simon "Anyway, I've got to be going." id ep3_27_dylanbus_3d16c031
    show ep3 sun_dylanbus_011 with d
    dylan "Umm... You sure are acting weird." id ep3_27_dylanbus_82b186a3
    dylan "So serious." id ep3_27_dylanbus_88d40663
    show ep3 sun_dylanbus_005 with d
    dylan "In that case, I'll skip asking you how your night went." id ep3_27_dylanbus_85fb804b
    show ep3 sun_dylanbus_012 with d
    pause 0.2
    show ep3 sun_dylanbus_013 with d
    pause 0.2
    show ep3 sun_dylanbus_012 with d
    dylan "But I imagine it was good..." id ep3_27_dylanbus_cf43a242
    show ep3 sun_dylanbus_013 with d
    dylan "Real good..." id ep3_27_dylanbus_672fa7a6
    show ep3 sun_dylanbus_014 with d
    simon "I don't have time for this, Dylan." id ep3_27_dylanbus_52b545e5
    show ep3 sun_dylanbus_015 with d
    dylan "My bad. If you're in a hurry, I can help." id ep3_27_dylanbus_409cd966
    dylan "I could always give you a lift." id ep3_27_dylanbus_6c1ddde5
    show ep3 sun_dylanbus_016 with d
    dylan "It'll be quicker than you waiting for the bus." id ep3_27_dylanbus_26aa9546
    show ep3 sun_dylanbus_017 with d
    simon "I know I'm going to regret this..." id ep3_27_dylanbus_4f748aba
    simon "But getting home early would help me focus." id ep3_27_dylanbus_90e8c71a
    show ep3 sun_dylanbus_018 with d
    dylan "You're in good hands, bro!" id ep3_27_dylanbus_cb9dc378
    play sound scooter_start volume 0.5
    show ep3 sun_dylanbus_019 with hpunch
    simon "NOT AGAIN!" id ep3_27_dylanbus_0a7006b0
    dylan "LOOK, MA! NO HANDS!" id ep3_27_dylanbus_6979f4b8
    show ep3 sun_dylanbus_020 with d
    dylan "You're the one who wants to get there faster!" id ep3_27_dylanbus_8443ccc3
    show ep3 sun_dylanbus_021 with d
    simon "(He's right.)" id ep3_27_dylanbus_645c31f6
    simon "(I have to get to Lily's house early and catch her by surprise.)" id ep3_27_dylanbus_c1d51322
    play sound scooter_end volume 0.7
    show ep3 sun_dylanbus_022 with fade
    dylan "Hey, bro. We're here." id ep3_27_dylanbus_f45d0787
    show ep3 sun_dylanbus_023 with d
    simon "Thanks, Dylan. Now, I've got time to get ready." id ep3_27_dylanbus_a036f471
    show ep3 sun_dylanbus_024 with d
    dylan "Any time, bro." id ep3_27_dylanbus_1269efae

    jump ep3_28_emily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
