
label ep3_19_susankitchen3:
    show ep3 sat_susankitchen3_001 with d
    susan "... Right. I agree that Sam is more to blame for what happened." id ep3_19_susankitchen3_71618ee9
    susan "But we were there too. We could have put an end to all of it." id ep3_19_susankitchen3_d7287bdd
    show ep3 sat_susankitchen3_002 with d
    lily "Yeah..." id ep3_19_susankitchen3_8ed395ca
    lily "I'm getting a divorce." id ep3_19_susankitchen3_814dfd6b
    show ep3 sat_susankitchen3_003 with d
    susan "Oh, Lily..." id ep3_19_susankitchen3_29f4ef5a
    show ep3 sat_susankitchen3_004 with d
    susan "It's for the best." id ep3_19_susankitchen3_c8805c83
    susan "Sam is... complicated." id ep3_19_susankitchen3_f6188865
    stop music fadeout 0.5
    simon "Cut the feed." (what_italic=True)
    stop music fadeout 3.0
    jump ep3_20a_vanbear
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
