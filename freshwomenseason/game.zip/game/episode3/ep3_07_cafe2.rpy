label ep3_07_cafe2:
    show ep3 sat_cafe2_001_2 with None
    stop music
    alyssa "Uh..." id ep3_07_cafe2_3f24e6fe
    show ep3 sat_cafe2_001 with d
    chloe "Anyway, I'll be at the bookstore." id ep3_07_cafe2_8d18ad12
    chloe "Come find me later." id ep3_07_cafe2_b05eecbd
    show ep3 sat_cafe2_002 with d
    chloe "See you around! The coffee was great." id ep3_07_cafe2_8c99c31c
    show ep3 sat_cafe2_003 with d
    play music camino_solo volume 0.3
    alyssa "Hey, [name], I didn't mean to eavesdrop." id ep3_07_cafe2_f2b8d62c
    alyssa "But your conversation seemed so intense." id ep3_07_cafe2_da8e7bd0
    show ep3 sat_cafe2_004 with d
    alyssa "Are you two all right?" id ep3_07_cafe2_0b99f6ed
    show ep3 sat_cafe2_005 with d
    simon "It's just some family stuff of mine." id ep3_07_cafe2_4bd133cb
    show ep3 sat_cafe2_004 with d
    alyssa "I know what that's like." id ep3_07_cafe2_e2162cd7
    show ep3 sat_cafe2_006 with d
    alyssa "Is there anything I can help you with?" id ep3_07_cafe2_d26fd61a
    show ep3 sat_cafe2_005 with d
    simon "I don't think so." id ep3_07_cafe2_55baa306
    simon "Besides, you already have enough on your plate." id ep3_07_cafe2_508f3192
    show ep3 sat_cafe2_007 with d
    simon "Speaking of which, how's Tyler doing?" id ep3_07_cafe2_09302236
    show ep3 sat_cafe2_008 with d
    alyssa "Oh, he's making a fast recovery!" id ep3_07_cafe2_ebff26b3
    show ep3 sat_cafe2_009 with d
    alyssa "It's a shame he won't be fully recovered for next week though." id ep3_07_cafe2_2547d371
    show ep3 sat_cafe2_010 with d
    alyssa "His role wasn't that big, and the choreography's simple enough. But we need each and every member up there." id ep3_07_cafe2_57afb437
    alyssa "He just had that one tricky move." id ep3_07_cafe2_e7b4a606
    show ep3 sat_cafe2_011 with d
    simon "What was the move?" id ep3_07_cafe2_8aeb4a45
    show ep3 sat_cafe2_012 with d
    stop music fadeout 10
    alyssa "You just want to see me dance again, don't you? Haha." id ep3_07_cafe2_7f837690
    show ep3 sat_cafe2_013 with d
    simon "Well, you are quite the dancer." id ep3_07_cafe2_fbc50481
    show ep3 sat_cafe2_014 with d
    alyssa "Haha! Fine. It went more or less like this..." id ep3_07_cafe2_9a16df4f
    play music a_touch_of_you volume 0.3
    show ep3 sat_cafe2_015 with wipeleft
    alyssa "One..." id ep3_07_cafe2_c5f733e1
    show ep3 sat_cafe2_016 with wiperight
    alyssa "Two..." id ep3_07_cafe2_a01e581c
    show ep3 sat_cafe2_017 with wipeup
    alyssa "Three..." id ep3_07_cafe2_8bbdfe8b
    show ep3 sat_cafe2_018 with d
    alyssa "Huh...?" id ep3_07_cafe2_3d17278d
    show ep3 sat_cafe2_019 with d
    alyssa "How did you know that came next?" id ep3_07_cafe2_e6309371
    show ep3 sat_cafe2_020 with d
    simon "It's one of the routines in Dance Dance Supreme. I know most of them by heart." id ep3_07_cafe2_00122bf6
    show ep3 sat_cafe2_021 with d
    alyssa "That's excellent!" id ep3_07_cafe2_3259b507
    show ep3 sat_cafe2_022 with d
    simon "Excellent? Why's that...?" id ep3_07_cafe2_5d9212b8
    show ep3 sat_cafe2_023 with d
    simon "You wouldn't want me to take Tyler's place in the dance, would you?" id ep3_07_cafe2_2b192d66
    show ep3 sat_cafe2_024 with d
    alyssa "Your form's not perfect..." id ep3_07_cafe2_0271d58e
    show ep3 sat_cafe2_025 with d
    alyssa "But with some training, you could get good enough to perform with us next week." id ep3_07_cafe2_bd8d82dd
    show ep3 sat_cafe2_026 with d
    simon "Perform?" id ep3_07_cafe2_bb5b848c
    show ep3 sat_cafe2_027 with d
    alyssa "Yeah! We can practice together in the meantime!" id ep3_07_cafe2_40df2fbe
    alyssa "I'm sure you can pull it off." id ep3_07_cafe2_aad4e3dd
    show ep3 sat_cafe2_028 with d
    alyssa "Pleeease?" id ep3_07_cafe2_089da3d6

    menu:
        "Agree to help"(True):
            $ ep3_07_cafe2_agree_to_help = True
            $ player_choice("ep3_07_cafe2_agree_to_help:true")
            $ points_alyssa += 1
            show ep3 sat_cafe2_029 with d
            simon "You know what? Your plan's so crazy, it just might work." id ep3_07_cafe2_fc0000a0
            simon "I'm in." id ep3_07_cafe2_a7833588
            show ep3 sat_cafe2_030 with d
            alyssa "Seriously?!" id ep3_07_cafe2_28abab4e
            show ep3 sat_cafe2_031 with d
            alyssa "Thank you! You're my savior!" id ep3_07_cafe2_2f8fcb62
            show ep3 sat_cafe2_032 with d
            simon "(She seems so happy and relieved at the same time.)" id ep3_07_cafe2_6d66e3ac
            simon "(This performance must be a big deal for her.)" id ep3_07_cafe2_58f6d21f

            if choice_made('ep2_alyssa_kiss'):

                menu:
                    "Hug her tighter"(True):
                        $ ep3_07_cafe2_hug_her_tighter = True
                        $ player_choice("ep3_07_cafe2_hug_her_tighter:true")
                        show ep3 sat_cafe2_033 with d
                        simon "Everything will be fine. You can count on me." id ep3_07_cafe2_7fa93bf4
                        show ep3 sat_cafe2_034 with d
                        alyssa "Thank you! This means so much to me." id ep3_07_cafe2_05bfce0a
                        alyssa "I won't forget it." id ep3_07_cafe2_f7bea438
                    "Leave it at that":

                        $ ep3_07_cafe2_leave_it_like_that = True
                        $ player_choice("ep3_07_cafe2_leave_it_like_that:true")
                        simon "I'll help in any way I can." id ep3_07_cafe2_b14a22f0
        "Don't help":

            $ ep3_07_cafe2_dont_help = True
            $ player_choice("ep3_07_cafe2_dont_help:true")
            show ep3 sat_cafe2_035 with d
            simon "I don't know... Dancing in public feels like a big thing." id ep3_07_cafe2_48dbd811
            show ep3 sat_cafe2_036 with d
            alyssa "Yeah, I get it. I didn't think you'd say yes anyway." id ep3_07_cafe2_fde1c840
            show ep3 sat_cafe2_037 with d
            alyssa "But it's all right! I'm sure we'll work something out." id ep3_07_cafe2_3178ff43

    show ep3 sat_cafe2_038 with d
    alyssa "This event is really important for us, just so you know." id ep3_07_cafe2_42cdf0b1
    alyssa "It could be our chance to save the studio. That's why I asked for your help." id ep3_07_cafe2_60ff809c
    show ep3 sat_cafe2_039 with d
    simon "How important?" id ep3_07_cafe2_58bb722e
    show ep3 sat_cafe2_040 with d
    alyssa "Ah, never mind that for now!" id ep3_07_cafe2_255ccced
    show ep3 sat_cafe2_041 with d
    stop music fadeout 3
    alyssa "Besides, I think there's someone waiting for you..." id ep3_07_cafe2_b639077a
    show ep3 sat_cafe2_042 with d
    alyssa "... Or that's just some weird guy who's been staring at you for a while..." id ep3_07_cafe2_2c95150d
    show ep3 sat_cafe2_043 with d
    play music april_fools_day volume 0.3
    simon "He can be both." id ep3_07_cafe2_55d0e62e
    show ep3 sat_cafe2_044 with d
    dylan "Dear friend." (what_bold=True)
    show ep3 sat_cafe2_045 with d
    dylan "My lady." (what_bold=True)
    show ep3 sat_cafe2_046 with d
    alyssa "Wow, your friend is such a gentleman..." id ep3_07_cafe2_a54756c0
    show ep3 sat_cafe2_047 with d
    simon "(It's amazing how he can still look so immaculate despite being away from home for so long.)" id ep3_07_cafe2_9a6434b5
    show ep3 sat_cafe2_048 with d
    simon "Uh, Dylan, have you been home yet?" id ep3_07_cafe2_6628c667
    show ep3 sat_cafe2_049 with d
    dylan "I was going to, but then I remembered there's that bear waiting for me..." (what_bold=True)
    show ep3 sat_cafe2_050 with d
    alyssa "A bear?" id ep3_07_cafe2_b2cd5332
    show ep3 sat_cafe2_051 with d
    simon "Uhh... That's not what he meant." id ep3_07_cafe2_f5503a21
    simon "Must be a language issue. He must have thought up the wrong word." id ep3_07_cafe2_22c17911
    simon "Haha. He probably meant to say beer." id ep3_07_cafe2_06fd843d
    show ep3 sat_cafe2_052 with d
    simon "That reminds me, we must be going. Right, Dylan?" id ep3_07_cafe2_051daba3
    show ep3 sat_cafe2_053 with d
    dylan "Yeah, but what about that bea —" (what_bold=True)
    show ep3 sat_cafe2_054 with d
    simon "(Let's go, Dylan!)" id ep3_07_cafe2_ed5b10bf
    show ep3 sat_cafe2_055 with d
    stop music fadeout 3
    simon "Wow, he's dying to have that beer! Come on, Dylan. Let's go!" id ep3_07_cafe2_bfdf8767
    show ep3 sat_cafe2_056 with d
    alyssa "See you later, [name]! Nice to meet you, [name]'s Russian friend!" id ep3_07_cafe2_8a6eadbb
    jump ep3_08_bookstore
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
