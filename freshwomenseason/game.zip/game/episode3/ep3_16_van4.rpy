
label ep3_16_van4:
    show ep3 sat_van4_001 with d
    simon "Sam? Who's Sam?" id ep3_16_van4_d38eb795
    stop music fadeout 5
    show ep3 sat_van4_002 with d
    chloe "Samuel Alderson. Lily's husband." id ep3_16_van4_4b9c3a64
    show ep3 sat_van4_003 with d
    simon "Sam..." id ep3_16_van4_735f566b
    jump ep3_17_flashback
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
