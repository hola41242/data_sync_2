label ep3_21_susanlily:

    play music es_halo fadeout 3.0 fadein 3.0 volume 0.5
    show ep3 sat_susanlily_001 with d
    simon "(Anyway, better get back to business.)" id ep3_21_susanlily_7ada39c8
    show ep3 sat_susanlily_002 with d
    chloe "Are you ready?" id ep3_21_susanlily_50b2b36a
    show ep3 sat_susanlily_003 with d
    simon "How can you be so calm after that?" id ep3_21_susanlily_23cd974f
    simon "I honestly can't tell you just survived a bear attack." id ep3_21_susanlily_6dc5427a
    show ep3 sat_susanlily_004 with d
    chloe "Well, you were with me, so..." id ep3_21_susanlily_5e3f2a6d
    show ep3 sat_susanlily_005 with d
    chloe "Umm..." id ep3_21_susanlily_c56309fb
    show ep3 sat_susanlily_006 with d
    chloe "Come to think of it, maybe you should get some rest. That was a hell of a scare on your end." id ep3_21_susanlily_a0eb0acd
    show ep3 sat_susanlily_007 with d
    simon "Are you sure? Isn't it better if we...?" id ep3_21_susanlily_ae13b7fd
    show ep3 sat_susanlily_006 with d
    chloe "No, no. It's all right. I'll call you if anything else comes up." id ep3_21_susanlily_af4416a5




    $ ep3_sat_susanlily_stay = True
    $ player_choice("ep3_sat_susanlily_stay:true")
    show ep3 sat_susanlily_012 with d
    simon "No, I want to see how this goes." id ep3_21_susanlily_12207e68
    simon "We've wasted too much time already." id ep3_21_susanlily_0abb43df
    show ep3 sat_susanlily_013 with d
    simon "What are they talking about now?" id ep3_21_susanlily_a5a9717b
    show ep3 sat_susanlily_014 with d
    lily "... While we're on the subject, did you get any more toys in?" (what_italic=True)
    show ep3 sat_susanlily_015 with d
    simon "(Toys... Hehe.)" id ep3_21_susanlily_6234396b
    show ep3 sat_susanlily_016 with d
    simon "(Urgh. I've got to get my mind out of the gutter.)" id ep3_21_susanlily_d93d5719
    simon "(It's just going places on its own today.)" id ep3_21_susanlily_b3f44e43
    show ep3 sat_susanlily_017 with d
    simon "(If they're really talking about sex toys, that's why Chloe was trying to get me out of here and the awkward situation that's bound to follow.)" id ep3_21_susanlily_fc82d345
    simon "(That's why she was acting weird.)" id ep3_21_susanlily_ea7d8cc6
    show ep3 sat_susanlily_018 with d
    simon "Well, this is a little embarrassing, but apparently Susan sells sex toys too." id ep3_21_susanlily_7ed3655b
    simon "They must be talking about that now." id ep3_21_susanlily_9e58707a
    simon "Not really our business though." id ep3_21_susanlily_997c9657
    show ep3 sat_susanlily_019 with d
    susan "... There's one I just got in. I know you prefer the feel of the real thing, so it would make a nice choice. Come to my room." (what_italic=True)
    show ep3 sat_susanlily_020 with d
    chloe "You're right. This really is none of our business." id ep3_21_susanlily_9b7e64fb
    show ep3 sat_susanlily_021 with d

    menu:
        "Open the lid"(True):
            $ ep3_sat_susanlily_open_the_lid = True
            $ player_choice("ep3_sat_susanlily_open_the_lid:true")
            show ep3 sat_susanlily_028 with d
            stop music fadeout 3.0
            simon "Hold on... Don't you want to see what happens next?" id ep3_21_susanlily_6592eacd
            show ep3 sat_susanlily_029 with d
            chloe "I do..." id ep3_21_susanlily_a5196002
            play music at_first_i_thought fadein 2.0 volume 0.5
            show ep3 sat_susanlily_030 with d
            simon "Then let's watch." (what_italic=True)
            show ep3 sat_susanlily_031 with d
            lily "Wow! It doesn't even remind you of a real penis. It's way too big!" id ep3_21_susanlily_355d657d
            show ep3 sat_susanlily_032 with d
            lily "Though it does remind me of..." id ep3_21_susanlily_be847373
            show ep3 sat_susanlily_033 with d
            susan "Reminds you of our college days, doesn't it?" id ep3_21_susanlily_955bee63
            susan "You had one just like it." id ep3_21_susanlily_400a62a4
            show ep3 sat_susanlily_034 with d
            lily "Hmm, that's true. I needed it back then." id ep3_21_susanlily_eb850c06
            show ep3 sat_susanlily_035 with d
            lily "I wasn't super busty like you." id ep3_21_susanlily_f047ec1b
            lily "Everybody wanted a piece of those." id ep3_21_susanlily_682ecf38
            show ep3 sat_susanlily_036 with d
            susan "They're more trouble than they're worth." id ep3_21_susanlily_bfd84e05
            susan "Every man I met just wanted to go out with me because of my boobs." id ep3_21_susanlily_53b2119f
            susan "Some women too." id ep3_21_susanlily_05d18d24
            show ep3 sat_susanlily_037 with d
            susan "I still think they're too big." id ep3_21_susanlily_62ddfc0f
            show ep3 sat_susanlily_038 with d
            lily "Are you kidding? They're perfect!" id ep3_21_susanlily_addd6e19
            show ep3 anim_sat_susanlily_039 with d
            lily "Plus, they feel so..." id ep3_21_susanlily_8f5ad1b6
            pause
            show ep3 anim_sat_susanlily_039_var1 with d
            lily "... Great." id ep3_21_susanlily_a22016b9
            chloe "Ahhh..." (what_italic=True)
            pause
            show ep3 sat_susanlily_040 with d
            simon "Huh...?" id ep3_21_susanlily_47faff62
            show ep3 sat_susanlily_041 with d
            simon "(She's enjoying this!)" id ep3_21_susanlily_3711c78a
            simon "(I had no idea Chloe was like that. What a...)" id ep3_21_susanlily_3f5ca86f
            susan "Pervert!" (what_italic=True)
            simon "(Did I say that out loud?)" id ep3_21_susanlily_9faf7229
            show ep3 sat_susanlily_042 with d
            susan "You were always such a perv, Lily." id ep3_21_susanlily_e875cc8d
            susan "Always groping me back in our college dorm." id ep3_21_susanlily_541185b4
            show ep3 sat_susanlily_043 with d
            lily "Maybe I miss our time as freshwomen." id ep3_21_susanlily_9882d1d8
            show ep3 sat_susanlily_044 with d
            susan "Hmm..." id ep3_21_susanlily_9840a7b4
            show ep3 sat_susanlily_045 with d
            lily "Relax. I'm just messing with you." id ep3_21_susanlily_effeaf21
            show ep3 sat_susanlily_046 with d
            lily "Anyway, I think it's about time I headed home." id ep3_21_susanlily_5dcb5863
            show ep3 sat_susanlily_047 with d
            lily "But I will take this. Tonight is going to be a long night." id ep3_21_susanlily_e2d7ab59
            show ep3 sat_susanlily_048 with d
            susan "Oh Lily, you're so fun." id ep3_21_susanlily_b36716ad
            chloe "Yes, she is..." (what_italic=True)
        "Close the lid":

            $ ep3_sat_susanlily_close_the_lid = True
            $ player_choice("ep3_sat_susanlily_close_the_lid:true")
            play sound laptop_close_lid volume 0.7
            show ep3 sat_susanlily_022 with d
            simon "Exactly. Plus, we've already learned what we came here to learn." id ep3_21_susanlily_e63968c4
            show ep3 sat_susanlily_023 with d
            simon "I think we'd better rest up and wait for Dylan to come back." id ep3_21_susanlily_633a0778
            simon "After that, we'll have to decide what to do with what we've found out today." id ep3_21_susanlily_32fd6474
            show ep3 sat_susanlily_024 with d
            chloe "..." id ep3_21_susanlily_0e36ad82
            show ep3 sat_susanlily_025 with d
            chloe "(Hmmm...)" id ep3_21_susanlily_0cd25b86
            show ep3 sat_susanlily_026 with d
            chloe "(Awesome.)" id ep3_21_susanlily_798d377d
            show ep3 sat_susanlily_027 with d
            pause 0.5
            show black as ep3 with longer_dissolve
            pause 1
            chloe "*Moans.*" id ep3_21_susanlily_7a5588dc

            simon "Huh?" id ep3_21_susanlily_196da51b

    stop music fadeout 3.0
    jump ep3_22_van6
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
