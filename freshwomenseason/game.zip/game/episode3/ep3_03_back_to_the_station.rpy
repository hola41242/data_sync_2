define episode_3_name = _("Episode 3 - Spy Novels")
label ep3_03_back_to_the_station:
    show ep3 sun_stationout_mess with wipeleft
    simon "What kind of mess did you get yourself into this time, Dylan?" id ep3_03_back_to_the_station_286ec3ae
    show ep3 sun_stationout_thatguy with d
    simon "(Oh, it's that guy from the other night.)" id ep3_03_back_to_the_station_e0276e34
    simon "Excuse me." id ep3_03_back_to_the_station_43302090
    simon "Do you know if my friend is here?" id ep3_03_back_to_the_station_a9e683a1
    show ep3 sun_stationout_badsign with d
    simon "(That's not a good sign...)" id ep3_03_back_to_the_station_3bb38d78
    play sound door volume 0.6
    show ep3 sun_stationout_mood with medium_dissolve
    stop music fadeout 7
    simon "Not in a talkative mood today, are we, Alfredo?" id ep3_03_back_to_the_station_98c2bd44
    simon "That's fine." id ep3_03_back_to_the_station_c9d16ee4
    show ep3 sun_station_simon_hello with fast_fade
    simon "Um... Hello?" id ep3_03_back_to_the_station_9d7673d4
    simon "Hmm... This is pretty weird." id ep3_03_back_to_the_station_418260e0
    simon "(I wonder if Dylan's actually here...)" id ep3_03_back_to_the_station_f617638a
    play music on_the_way volume 0.15
    show ep3 sun_station_simon_whatthe with d
    simon "What the...?" id ep3_03_back_to_the_station_2f7e4b1f
    show ep3 sun_station_dylan_brobail with d
    dylan "Bro!" id ep3_03_back_to_the_station_5d0c7ddb
    dylan "I knew I could count on you!" id ep3_03_back_to_the_station_f5bd38d5
    dylan "Post my bail, and let's get the hell out of here." id ep3_03_back_to_the_station_45d90e81
    show ep3 sun_station_simon_howitworks with d
    simon "Hold on." id ep3_03_back_to_the_station_4c0a7e56
    simon "How does this work?" id ep3_03_back_to_the_station_6aa5101a
    simon "I mean, this isn't an actual police station!" id ep3_03_back_to_the_station_f2143b53
    simon "You could just walk away if you wanted to." id ep3_03_back_to_the_station_ea74a5b0
    show ep3 sun_station_angela_questioning with d
    angela "He's questioning The Station's authority, Devilla!" id ep3_03_back_to_the_station_261b1f32
    show ep3 sun_station_dylan_howitis with d
    dylan "You can see how this is going, right?" id ep3_03_back_to_the_station_8bc2caab
    dylan "I can't leave." id ep3_03_back_to_the_station_d130f322
    dylan "And it's all kind of your fault..." id ep3_03_back_to_the_station_0a2e1cf2
    show ep3 sun_station_simon_confused with d
    simon "How is this my fault?" id ep3_03_back_to_the_station_4430ca71
    simon "I didn't do anything." id ep3_03_back_to_the_station_ab343d59
    simon "We just came here, had a few drinks, and had some fun. Then I left." id ep3_03_back_to_the_station_61d2bc91
    show ep3 sun_station_dylan_wenthome with d
    dylan "And how do you think you got home?" id ep3_03_back_to_the_station_033bb390
    show ep3 sun_station_simon_acab with d
    simon "I don't know. I must have taken a taxi or something." id ep3_03_back_to_the_station_33582a4e
    simon "I don't really remember." id ep3_03_back_to_the_station_d7705e58
    show ep3 sun_station_dylan_feelingcold with d
    dylan "Don't you remember feeling cold that night?" id ep3_03_back_to_the_station_0feb378a
    show ep3 sun_station_simon_thinking with d
    simon "No, I remember it being hot, and then..." id ep3_03_back_to_the_station_bf429308
    show ep3 sun_station_simon_nowait with medium_dissolve
    simon "... No, wait..." id ep3_03_back_to_the_station_71e06e51
    simon "Yeah, I did feel cold!" id ep3_03_back_to_the_station_ff060121
    simon "You said you'd let me wear your coat." id ep3_03_back_to_the_station_8b43f95a
    show ep3 sun_station_dylan_feelingcold with d
    dylan "And do you remember what you said after that?" id ep3_03_back_to_the_station_4256c280
    show ep3 sun_station_simon_thinking with d
    simon "I think I said something about Russians not feeling cold..." id ep3_03_back_to_the_station_f9452551
    show ep3 sun_station_devilla_audacity with vpunch
    devilla "YOU HAVE THE AUDACITY TO SPEAK OF THE MOTHERLAND AGAIN?!" (what_bold=True)
    show ep3 sun_station_devilla_audacity1 with d
    simon "The what?" id ep3_03_back_to_the_station_d1527625
    show ep3 sun_station_simon_whatnow with d
    angela "The nerve of this prick!" id ep3_03_back_to_the_station_8bcc54fc
    show ep3 sun_station_devilla_littlefriend with medium_dissolve
    devilla "I found out that your little friend here was pretending to be one of my countrymen." (what_bold=True)
    show ep3 sun_station_simon_actuallyrussian with d
    simon "(Oh, so she's actually Russian!)" id ep3_03_back_to_the_station_0be98298
    simon "(Dylan's accent sounds especially bad after hearing the real thing.)" id ep3_03_back_to_the_station_1c4034e5
    simon "(I honestly don't know how he managed to fool so many people.)" id ep3_03_back_to_the_station_7360ae2a
    show ep3 sun_station_simon_igetit with d
    simon "I think I understand what happened now." id ep3_03_back_to_the_station_594a46ff
    simon "I might have let it slip that Dylan pretends to be Russian, and now you're offended." id ep3_03_back_to_the_station_1bba9cf5

    menu:
        "Defend Dylan"(True):
            $ ep3_station_defend_dylan = True
            $ player_choice("ep3_station_defend_dylan:true")
            $ points_dylan += 1
            show ep3 sun_station_simon_heslikethat with d
            simon "He's sort of like that though." id ep3_03_back_to_the_station_fd77f7b9
            simon "I swear he means well." id ep3_03_back_to_the_station_fb9cffc9
            simon "He's got a good heart." id ep3_03_back_to_the_station_df10cf2d
            show ep3 sun_station_dylan_thanks with d
            dylan "Thanks, dude." id ep3_03_back_to_the_station_22c8265e
            dylan "You're a real bro." id ep3_03_back_to_the_station_b622d876
            show ep3 sun_station_simon_heslikethat with d
            simon "Please, just take it easy on him." id ep3_03_back_to_the_station_ce6e8081
            simon "It's not fair to leave the guy locked up over such a small offense." id ep3_03_back_to_the_station_5df46ca5
        "Blame Dylan":

            $ ep3_station_defend_dylan = False
            $ player_choice("ep3_station_defend_dylan:false")
            show ep3 sun_station_simon_him with d
            simon "This is more his fault than mine though." id ep3_03_back_to_the_station_995bee09
            simon "I had nothing to do with his decision to do that." id ep3_03_back_to_the_station_d1436147
            show ep3 sun_station_simon_nobro with d
            dylan "Bro..." id ep3_03_back_to_the_station_8324bf67
            show ep3 sun_station_simon_him with d
            simon "But, still, isn't this taking everything a bit far?" id ep3_03_back_to_the_station_2d35327f
            simon "It's not fair to detain him over such a small offense." id ep3_03_back_to_the_station_2bbcfb45

    show ep3 sun_station_devilla_notwhole with d
    devilla "Oh, but that's not all." (what_bold=True)
    show ep3 sun_station_devilla_accent with d
    devilla "You think I got mad just because some silly boy faked an accent?" (what_bold=True)
    show ep3 sun_station_simon_madforless with d
    simon "(She seems to be the kind of person who would get mad over a lot less.)" id ep3_03_back_to_the_station_0f825a89
    simon "(She reminds me of...)" id ep3_03_back_to_the_station_9313dd43
    show ep3 sun_station_simon_lily with d
    simon "... Lily." id ep3_03_back_to_the_station_7d16ceff
    play sound snap volume 0.7
    show ep3 sun_station_devilla_boy with d
    play sound snap volume 0.7
    devilla "Hey, kid." (what_bold=True)
    show ep3 sun_station_devilla_iwassaying with d
    devilla "As I was saying..." (what_bold=True)
    show ep3 sun_station_devilla_iwassaying_1 with d
    devilla "The problem is, the two of you gave our pet bear a drink." (what_bold=True)
    devilla "Then you let him loose." (what_bold=True)

    show ep3 sun_station_simon_weletloose with d
    simon "We let loose..." id ep3_03_back_to_the_station_b6171253
    show ep3 sun_station_simon_petbear with d
    simon "YOUR PET BEAR?!" id ep3_03_back_to_the_station_dae3f00e
    show ep3 sun_station_angela_hemattered with d
    angela "He means so much to us." id ep3_03_back_to_the_station_5c521868
    angela "Who knows where he is right now?" id ep3_03_back_to_the_station_2aa1d0b6
    angela "Out there on those cold, sad streets." id ep3_03_back_to_the_station_566c873b
    show ep3 sun_station_simon_theresabear with d
    simon "Are you saying there's a bear on the loose in the city?!" id ep3_03_back_to_the_station_cf339286
    show ep3 sun_station_simon_andyou with d
    simon "And your only concern is that it might feel cold?" id ep3_03_back_to_the_station_43cf05cd
    simon "Isn't that why bears have fur?" id ep3_03_back_to_the_station_bdcea6b7
    show ep3 sun_station_devilla_timetopay with d
    devilla "That's quite disrespectful." (what_bold=True)
    devilla "After all, I do believe this is all your fault." (what_bold=True)
    devilla "And it's time you paid up." (what_bold=True)
    show ep3 sun_station_dylan_youleft with d
    dylan "Since you bailed on me, I was left to take the fall." id ep3_03_back_to_the_station_de12842b
    show ep3 sun_station_simon_overwith with d
    simon "Fine, let's get this over with." id ep3_03_back_to_the_station_dde7c8f3
    simon "What do I have to do to set things right and get Dylan out of here?" id ep3_03_back_to_the_station_157f3538
    show ep3 sun_station_devilla_wdym with d
    devilla "What do you mean?" (what_bold=True)
    devilla "He told you already. Just post the bail." (what_bold=True)
    show ep3 sun_station_simon_comeon with d
    simon "Come now... This isn't even a real police station!" id ep3_03_back_to_the_station_3bb7a385
    show ep3 sun_station_angela_rules with d
    angela "Yes, but we still have rules to follow." id ep3_03_back_to_the_station_85ff9e39
    show ep3 sun_station_angela_here with d
    angela "Here. The amount you should pay." id ep3_03_back_to_the_station_71ec1df3
    show ep3 sun_station_simon_looking with d
    pause
    show ep3 sun_station_simon_allthis with vpunch
    simon "THIS IS OUTRAGEOUS!" id ep3_03_back_to_the_station_60afcf1f
    show ep3 sun_station_simon_ajoke with d
    simon "You must be joking!" id ep3_03_back_to_the_station_7efa72cb
    simon "I can't afford this." id ep3_03_back_to_the_station_2791eaf1
    simon "There must be some other way..." id ep3_03_back_to_the_station_d24f09be
    show ep3 sun_station_angela_hecant with d
    angela "Devilla! He said he can't afford it!" id ep3_03_back_to_the_station_8974cedb
    angela "In that case, we'll just have to make him do it..." id ep3_03_back_to_the_station_782c1c00
    show ep3 sun_station_simon_that with d
    simon "What do you mean by \"it\" exactly?" id ep3_03_back_to_the_station_c3d12213
    show ep3 sun_station_devilla_withouthbear with d
    devilla "You know we can't do The Test without our bear!" (what_bold=True)
    show ep3 sun_station_dylan_wow with None
    dylan "Wow." id ep3_03_back_to_the_station_56580de1
    dylan "Are they going to let you take The Test?" id ep3_03_back_to_the_station_fca2862e
    dylan "I've always wanted to take The Test!" id ep3_03_back_to_the_station_0ef2f02e
    show ep3 sun_station_devilla_quiet with hpunch
    devilla "Quiet, imposter!" (what_bold=True)
    show ep3 sun_station_simon_whattest with d
    simon "Wait. What is this test?" id ep3_03_back_to_the_station_d9ea3c1c
    show ep3 sun_station_dylan_triathlon with d
    dylan "The Test is like an erotic triathlon where only the strongest reach the end." id ep3_03_back_to_the_station_c58eb949
    show ep3 sun_station_simon_notbad with d
    simon "That doesn't seem too bad to me." id ep3_03_back_to_the_station_354692f6
    simon "But where does the bear fit into all of this?!" id ep3_03_back_to_the_station_3c8593f6
    show ep3 sun_station_dylan_iwannaknow with d
    dylan "I've always wanted to know that!" id ep3_03_back_to_the_station_40bbf569
    show ep3 sun_station_devilla_improvise with d
    devilla "I think we can improvise and leave out the bear part." (what_bold=True)
    devilla "But then The Test would be almost impossible." (what_bold=True)
    show ep3 sun_station_angela_doit with d
    angela "We can do it, Devilla!" id ep3_03_back_to_the_station_b6e1a30c
    angela "Let him take The Test. Please!" id ep3_03_back_to_the_station_b40dd1ce
    show ep3 sun_station_devilla_fine with d
    devilla "Fine." (what_bold=True)
    devilla "If you pass test, I'll release your friend." (what_bold=True)
    show ep3 sun_station_simon_neversaid with hpunch
    simon "Wait a minute!" id ep3_03_back_to_the_station_64ae215c
    show ep3 sun_station_devilla_shh1 with d
    simon "I didn't even say I agreed yet!" id ep3_03_back_to_the_station_c6a5c5ea
    play sound throw_bag volume 0.7
    show ep3 sun_station_devilla_shh with d
    pause 0.25
    show black_screen as ep3 with d
    stop music fadeout 1
    devilla "Shhh..." (what_bold=True)

    play music you_cant_stop_me fadein 4

    show oppaiman_presents with medium_fade
    pause 2


    scene black as ep3 with medium_fade

    show black_screen as ep3 with d

    show ep3 titlecard with None
    $ on_screen_translation(episode_3_name, interact=False)
    pause 4
    $ on_screen_translation(episode_3_name, interact=False)
    stop music fadeout 4
    $ on_screen_translation(episode_3_name, interact=False)
    pause 4

    simon "Come now, girls!" id ep3_03_back_to_the_station_67fc6905
    simon "You can't do this!" id ep3_03_back_to_the_station_2d717b9a
    simon "Dylan?!" id ep3_03_back_to_the_station_f28049f4
    simon "Somebody? Anybody?!" id ep3_03_back_to_the_station_fe076039
    jump ep3_04_challenge
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
