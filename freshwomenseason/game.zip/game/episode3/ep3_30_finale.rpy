


label ep3_30_finale:
    $ add_frame_to_finale = False

    stop sound_2 fadeout 5
    stop sound fadeout 5
    stop music fadeout 5
    show screen save_your_game(3, 1, 3, 0) with ending_fade
    show ep3 finale_end_dylan

    $ set_finale_chars("Dylan")
    $ finale_color = "CF3F30"
    if choice_made_skip_debug('ep3_station_defend_dylan'):
        $ finale_txt1 = _("You stood by Dylan and tried defending him.")
    else:
        $ finale_txt1 = _("You blamed Dylan for the whole situation with the bear.")
    if choice_made_skip_debug('ep3_04_challenge_surrender_to_devilla') or choice_made_skip_debug('ep3_04_challenge_surrender_to_angela'):
        $ finale_txt2 = _("You didn't complete Angela and Devilla's challenge.")
    else:
        if choice_made_skip_debug('ep3_04_challenge_fuck_both'):
            $ finale_txt2 = _("You completed Angela and Devilla's challenge and had a threesome with them.")
        else:
            $ finale_txt2 = _("You completed Angela and Devilla's challenge.")
    $ finale_txt3 = ""
    $ finale_txt4 = ""
    $ finale_txt5 = _("Dylan saved the day and returned the bear to Angela and Devilla.")

    pause 
    hide screen save_your_game with long_fade
    $ award_manager.enable_notify()

    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Alyssa")
    $ finale_color = "A6F2F5"
    if choice_made_skip_debug('ep3_06_cafe_accept'):
        $ finale_txt1 = _("You agreed to hang out with Chloe and Alyssa.")
    else:
        $ finale_txt1 = _("You're not sure if you like the idea of hanging out with Chloe and Alyssa at the same time.")
    if choice_made_skip_debug('ep3_07_cafe2_agree_to_help'):
        $ finale_txt2 = _("You agreed to take Tyler's place in Alyssa's dance performance.")
    else:
        $ finale_txt2 = _("You decided not to dance with Alyssa's group.")
    $ finale_txt3 = ""
    $ finale_txt4 = ""
    $ finale_txt5 = _("Alyssa's dance performance is set for next week.")

    show ep3 finale_end_alyssa with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d


    $ set_finale_chars("Chloe")
    $ finale_color = "4FDB85"
    if choice_made_skip_debug('ep3_06_cafe_tell_the_truth'):
        $ finale_txt1 = _("You told Chloe the truth about you being late to the café.")
    else:
        $ finale_txt1 = _("You did not tell Chloe the truth about you being late to the café.")
    if choice_made_skip_debug('ep3_08_bookstore_good_idea'):
        $ finale_txt2 = _("You told Chloe that she could become a great writer.")
    else:
        $ finale_txt2 = _("You told Chloe you don't think becoming a writer is such a good idea.")
    if choice_made_skip_debug('ep3_sat_susanlily_open_the_lid'):
        $ finale_txt3 = _("You and Chloe kept watching while Susan and Lily talked about dildos.")
    else:
        $ finale_txt3 = _("You told Chloe to leave Susan and Lily alone to talk about their personal preferences in dildos.")
    if choice_made_skip_debug('ep3_sat_chloesex_continue'):
        $ finale_txt4 = _("You and Chloe had sex for the first time.")
    else:
        $ finale_txt4 = _("You decided not to take things too far with Chloe.")
    $ finale_txt5 = _("You learned that Chloe is interested in men and women.")

    show ep3 finale_end_chloe with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    $ set_finale_chars("Susan", "Lily")
    $ finale_color = "8C91ED"
    if choice_made_skip_debug('ep3_the_ride_tell_her_the_truth'):
        $ finale_txt1 = _("You tried telling Susan that you know about Charlie, but she didn't seem to believe you.")
    else:
        $ finale_txt1 = _("You decided not to tell Susan that you met Charlie before.")
    if choice_made_skip_debug('ep3_sat_susanlily_open_the_lid'):
        $ finale_txt2 = _("You learned some details about Susan and Lily's private lives during their college days.")
    else:
        $ finale_txt2 = ""
    $ finale_txt3 = _("You decided to confront Lily about your father going missing.")
    $ finale_txt4 = ""
    $ finale_txt5 = _("You met Sam.")

    show ep3 finale_end_susan with long_fade
    show screen finale_scr with d
    pause
    hide screen finale_scr with d

    call end_game_if_rpy_is_not_installed ('ep4_01_lunch2.rpy')

    jump ep4_01_lunch2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
