label ep3_20a_vanbear:
    play music what_if_i volume 0.3 fadein 3.0
    show ep3 sat_vanbear_001 with d
    chloe "What? Right now?" id ep3_20a_vanbear_bbf467d5
    show ep3 sat_vanbear_002 with d
    chloe "I want to hear what comes next!" id ep3_20a_vanbear_910f724a
    chloe "The mystery is unraveling!" id ep3_20a_vanbear_26208161
    show ep3 sat_vanbear_003 with d
    simon "This isn't some mystery novel, Chloe!" id ep3_20a_vanbear_3f84b170
    show ep3 sat_vanbear_004 with d
    chloe "Oh... You're not taking this well, are you?" id ep3_20a_vanbear_8482f46e
    show ep3 sat_vanbear_005 with d
    simon "Of course I'm not! They're saying they did horrible things to my father!" id ep3_20a_vanbear_cd524c93
    simon "And then he went missing..." id ep3_20a_vanbear_fbeb15e0
    show ep3 sat_vanbear_006 with d
    simon "Or maybe..." id ep3_20a_vanbear_281656bf
    simon "... He's de —" id ep3_20a_vanbear_4509d4e6
    chloe "No!" id ep3_20a_vanbear_a694ed3d
    show ep3 sat_vanbear_007 with d
    chloe "I don't think that's right." id ep3_20a_vanbear_218bf7d4
    show ep3 sat_vanbear_008 with d
    chloe "If things turned out that bad, they would have said so." id ep3_20a_vanbear_20bd2adf
    chloe "I think your father is still out there somewhere." id ep3_20a_vanbear_e1c45ca7
    show ep3 sat_vanbear_009 with d
    simon "Do you really think so?" id ep3_20a_vanbear_92c638de
    show ep3 sat_vanbear_010 with d
    chloe "Of course! And we're going to find him!" id ep3_20a_vanbear_6c26ae90
    show ep3 sat_vanbear_011 with d
    chloe "I apologize for how excited I got before." id ep3_20a_vanbear_0fe4dba2
    chloe "I tend to view life like it's just one big book." id ep3_20a_vanbear_5797866b
    stop music fadeout 10
    show ep3 sat_vanbear_012 with d
    chloe "That makes me distance myself from others." id ep3_20a_vanbear_5a9a403d
    chloe "And it ends with me treating everyone like fictional characters." id ep3_20a_vanbear_203702bd

    show ep3 sat_vanbear_013 with d
    chloe "You know what? I couldn't tell you if that's necessarily a bad thing." id ep3_20a_vanbear_b3395151
    chloe "After all, we fall in love with fictional characters all the time." id ep3_20a_vanbear_8ea8cf69
    show ep3 sat_vanbear_014 with d
    chloe "Right?" id ep3_20a_vanbear_42885fd7
    show ep3 sat_vanbear_015 with d
    simon "Well, I..." id ep3_20a_vanbear_9bf3b23a
    show ep3 sat_vanbear_016 with d
    chloe "But I guess the two of us are flesh and blood, aren't we?" id ep3_20a_vanbear_42fed904
    show ep3 sat_vanbear_017 with d
    simon "I think..." id ep3_20a_vanbear_f8d1e41e
    play sound bush volume 0.8
    show ep3 sat_vanbear_018 with d
    pause 0.5
    chloe "[name]! What was that noise?" id ep3_20a_vanbear_084b5c90
    stop sound
    play music monster_from_the_deep volume 0.3
    show ep3 sat_vanbear_019 with d
    chloe "I think I saw something moving out there..." id ep3_20a_vanbear_32db4270

    show ep3 sat_vanbear2_001 with d
    simon "Do you think you can take a look with the drone?" id ep3_20a_vanbear_daa9b33d
    show ep3 sat_vanbear2_002 with d
    chloe "Oh, good idea!" id ep3_20a_vanbear_16eeb2c3
    show ep3 sat_vanbear2_003 with d
    chloe "Uh..."
    simon "What happened?" id ep3_20a_vanbear_9aa9ef74
    show ep3 sat_vanbear2_004 with d
    chloe "The drone went offline for a few seconds, but it's back up now." id ep3_20a_vanbear_f5b5571f
    show ep3 sat_vanbear2_005 with d
    simon "Did they spot us?" id ep3_20a_vanbear_43dcf997
    show ep3 sat_vanbear2_006 with d
    chloe "I don't know... But Susan and Lily are still where they were, so..." id ep3_20a_vanbear_bb618938
    show ep3 sat_vanbear2_007 with d
    chloe "... It must have been someone else..." id ep3_20a_vanbear_e55b1494
    show ep3 sat_vanbear2_008 with d
    simon "... Could it be...?" id ep3_20a_vanbear_f4c076d5
    play sound bush volume 0.7 
    show ep3 sat_vanbear2_009 with d
    chloe "Okay, I definitely heard that." id ep3_20a_vanbear_1ab3498e
    show ep3 sat_vanbear2_010 with d
    simon "I think I saw something moving too." id ep3_20a_vanbear_0d28b045
    show ep3 sat_vanbear2_011 with d
    simon "It might have been nothing..." id ep3_20a_vanbear_8c5b58cf
    show ep3 sat_vanbear2_012 with d
    simon "... But it could also be someone hiding in the bushes." id ep3_20a_vanbear_35ba9279

    play sound horror_ghostly volume 0.7
    show ep3 sat_vanbear2_013 with d
    simon "Did you hear that?" id ep3_20a_vanbear_b3cfc1a8
    stop sound fadeout 2
    show ep3 sat_vanbear2_014 with d
    chloe "What was it?" id ep3_20a_vanbear_12ce1f92
    show ep3 sat_vanbear2_015 with d
    simon "Might be nothing..." id ep3_20a_vanbear_65c0d169
    simon "... We should take a look though." id ep3_20a_vanbear_0f53de2f
    play sound_2 bear_angry volume 0.7
    play sound van_sidedoor_open volume 0.6
    show ep3 sat_vanbear_023_01 with vpunch









    pause 0.5
    show ep3 sat_vanbear2_020 with d
    simon "FUCK!"
    chloe "CLOSE THE DOOR!" id ep3_20a_vanbear_9026c73f
    play sound van_slidedoor_close_fast volume 0.7
    show ep3 sat_vanbear2_021 with d
    chloe "Will that stop a bear?!" id ep3_20a_vanbear_9adc092e
    show ep3 sat_vanbear2_022 with d
    simon "I sure hope s —" id ep3_20a_vanbear_5b3253f8
    play sound car_hit6 volume 0.6 
    show ep3 sat_vanbear2_023 with vpunch
    simon "Oh, shit!" id ep3_20a_vanbear_2ffe8669
    play sound_2 bear_angry volume 0.7
    show ep3 sat_vanbear2_024 with d
    simon "WE HAVE TO GET OUT OF HERE!" id ep3_20a_vanbear_33ad4359


    play sound engine_failing volume 0.4 
    show ep3 sat_vanbear2_026 with d
    simon "Start the van, Chloe!" id ep3_20a_vanbear_f14f3264
    stop sound fadeout 0.5
    play sound_2 engine_failing volume 0.4 
    show ep3 sat_vanbear2_027 with d
    chloe "This old ass engine won't start!" id ep3_20a_vanbear_1c56a247
    play sound car_hit4 volume 0.7
    show ep3 sat_vanbear2_028 with vpunch
    simon "Dammit! We're stuck here!" id ep3_20a_vanbear_a8c51cf9
    play sound car_hit5 volume 0.6 
    show ep3 sat_vanbear2_029 with vpunch
    simon "Shit!" id ep3_20a_vanbear_28fd9cf8
    play sound van_sidedoor_open2 volume 0.8
    show ep3 sat_vanbear2_030 with d
    simon "FUCK!"
    show ep3 sat_vanbear2_031 with d
    simon "Chloe! It's now or never!" id ep3_20a_vanbear_4a6a8cd9
    play sound engine_starts volume 0.5 
    show ep3 sat_vanbear2_032 with d
    chloe "Aaaaaaahhh!" id ep3_20a_vanbear_eeb05bd1

    play sound_2 bear_growling
    show ep3 sat_vanbear2_033 with d
    urso "Grrrr..." id ep3_20a_vanbear_233e4285
    $ renpy.music.set_volume(0.0, delay=3)
    show ep3 sat_vanbear2_034 with d
    simon "It started!" id ep3_20a_vanbear_5b76537a
    show ep3 sat_vanbear2_035 with d
    chloe "I think the bear's gone." id ep3_20a_vanbear_6885f182
    show ep3 sat_vanbear2_036 with d
    chloe "Bears are very easily distracted." id ep3_20a_vanbear_95a71a81
    chloe "It must have found something else to chase after." id ep3_20a_vanbear_5dd02c17
    show ep3 sat_vanbear2_037 with d
    chloe "We're safe now." id ep3_20a_vanbear_bf792934

    $ renpy.music.set_volume(0.2, delay=0.5)
    play sound bear_angry volume 0.7
    show ep3 sat_vanbear2_038 with vpunch
    simon "GET OUT OF THERE, CHLOE!" id ep3_20a_vanbear_a24e9dc0
    show ep3 sat_vanbear2_039 with d
    simon "Come back here!" id ep3_20a_vanbear_e515a2c7
    show ep3 sat_vanbear2_040 with d
    simon "We have to find another way out." id ep3_20a_vanbear_75a3fdc0
    play sound bear_snorting volume 0.7
    show ep3 sat_vanbear2_041 with d
    chloe "Umm... [name]?" id ep3_20a_vanbear_8ce73618
    play sound bear_angry volume 0.6
    show ep3 sat_vanbear2_042 with vpunch
    chloe "THE DOOR!" id ep3_20a_vanbear_9018dbe2
    show ep3 sat_vanbear2_043 with d
    simon "I'M CLOSING IT!" id ep3_20a_vanbear_21a2bc7a
    play sound_2 bear_growling volume 0.7
    show ep3 sat_vanbear2_044 with d
    simon "HOLY SHIT!" id ep3_20a_vanbear_30158a06
    show ep3 sat_vanbear2_045 with d
    chloe "Aaagghh!" id ep3_20a_vanbear_d8778bf9
    simon "Aaagggghhhh!" id ep3_20a_vanbear_66725167
    play sound bear_snorting volume 0.7
    show ep3 sat_vanbear2_046 with d
    simon "(Shit, it's gonna get in...)" id ep3_20a_vanbear_56717a0f
    show ep3 sat_vanbear2_047 with d
    simon "(I have to protect Chloe.)" id ep3_20a_vanbear_1fce1fef
    play sound bear_angry volume 0.75
    show ep3 sat_vanbear2_048 with vpunch
    simon "(At all costs.)" id ep3_20a_vanbear_acd4915f
    show ep3 sat_vanbear2_049 with d
    simon "Chloe, I —" id ep3_20a_vanbear_4af5487a


    show ep3 sat_vanbear_025 with d
    dylan "Hey, ugly! Devilla's looking for you!" (what_bold=True)
    simon "DYLAN, WHAT ARE YOU DOING?!" id ep3_20a_vanbear_5e69a6c0
    show ep3 sat_vanbear_026 with d
    dylan "Bears are nature's guardians." (what_bold=True)
    dylan "He'll think this a fire and charge me. Then you two can get out of here!" (what_bold=True)
    play sound bear_growling volume 0.7
    show ep3 sat_vanbear_027 with d
    dylan "See? I said it would work!" (what_bold=True)
    show ep3 sat_vanbear_028 with d
    dylan "Oh... I think this one is afraid of bright lights." (what_bold=True)
    show ep3 sat_vanbear_029 with d
    simon "(Bright lights?)" id ep3_20a_vanbear_c2483b1f
    show ep3 sat_vanbear_030 with d
    simon "(Makes sense for a bear that usually hangs out at a nightclub!)" id ep3_20a_vanbear_15bcdcaa
    simon "(The lights flashing all the time must have traumatized the thing!)" id ep3_20a_vanbear_ae830309
    play sound bear_angry volume 0.75
    show ep3 sat_vanbear_031 with vpunch
    simon "DYLAN!" id ep3_20a_vanbear_2a5cdbd9
    simon "THE SUN IN THE MIDDLE OF THE NIGHT!" id ep3_20a_vanbear_ca3f15c7
    play sound_2 riser_flashlight volume 0.8
    show ep3 sat_vanbear_033 with d
    stop music fadeout 8.0





    show ep3 sat_vanbear_035_1 with Fade(5.5, 0, 0.5, color="#faaadb")
    play sound bear_scared volume 0.7
    pause 1.5
    show ep3 sat_vanbear_035 with d
    dylan "It worked!" (what_bold=True)
    stop sound_2 fadeout 0.5
    dylan "Go back home! The girls are worried." (what_bold=True)
    show ep3 sat_vanbear_036 with d
    chloe "What the hell just happened?" id ep3_20a_vanbear_2d846cc5
    play music what_if_i fadein 2.5 volume 0.7
    show ep3 sat_vanbear_037 with d
    dylan "Oh, it's just the bear that ran away from the club." (what_bold=True)
    dylan "I think I should let Alfredo know where to find it." (what_bold=True)
    show ep3 sat_vanbear_038 with d
    dylan "After that we can..." (what_bold=True)
    show ep3 sat_vanbear_039 with d
    dylan "... continue to..." (what_bold=True)
    show ep3 sat_vanbear_040 with d
    dylan "... On second thought, I'll call Alfredo myself and tell him about the bear." (what_bold=True)
    dylan "You two can just wait here." (what_bold=True)
    show ep3 sat_vanbear_041 with d
    chloe "Oh..."
    simon "Oh, I..." id ep3_20a_vanbear_62abd843
    show ep3 sat_vanbear_042 with d
    chloe "Sorry, I didn't mean to..." id ep3_20a_vanbear_e4041462
    show ep3 sat_vanbear_043 with d
    simon "It's all right. That freaked me out a little too." id ep3_20a_vanbear_4b91fd9e
    show ep3 sat_vanbear_044 with d
    chloe "Dylan told me about the bear, but I thought it was a euphemism for something else." id ep3_20a_vanbear_d1586032
    show ep3 sat_vanbear_045 with d
    simon "Something else? Like what?" id ep3_20a_vanbear_763728ac

    show ep3 sat_vanbear_046 with d
    chloe "I don't know. A guy in a furry costume or something?" id ep3_20a_vanbear_a0d32007
    show ep3 sat_vanbear_044 with d
    chloe "I didn't think he'd be talking about an actual bear!" id ep3_20a_vanbear_4094d80d
    show ep3 sat_vanbear_045 with d
    simon "Don't they have to get permission to own an animal that size?" id ep3_20a_vanbear_901f3336
    show ep3 sat_vanbear_044 with d
    chloe "I sure hope so." id ep3_20a_vanbear_3efffa6d
    show ep3 sat_vanbear_047 with d
    chloe "The important thing is that we're fine." id ep3_20a_vanbear_bc27aefa
    show ep3 sat_vanbear_048 with d
    chloe "Oh..."
    show ep3 sat_vanbear_049 with d
    chloe "Well, we should continue where we left off." id ep3_20a_vanbear_7e0c4ccf
    show ep3 sat_vanbear_050 with d
    simon "Right. Of course." id ep3_20a_vanbear_29bd09ff
    show ep3 sat_vanbear_051 with d
    simon "(I almost forgot we were keeping an eye on Susan.)" id ep3_20a_vanbear_5f9a0da6
    show ep3 sat_vanbear_052 with d
    simon "(Did that hand-holding mean something more?)" id ep3_20a_vanbear_e09cc1d0

    menu:
        "I hope so."(True):
            $ ep3_sat_vanbear_i_hope_so = True
            $ player_choice("ep3_sat_vanbear_i_hope_so:true")

            simon "(It definitely felt like something more to me. I hope she shares the sentiment.)" id ep3_20a_vanbear_a8341d0d
        "Probably not.":

            $ ep3_sat_vanbear_probably_not = True
            $ player_choice("ep3_sat_vanbear_probably_not:true")

            simon "(It was probably nothing.)" id ep3_20a_vanbear_80014176


    jump ep3_21_susanlily
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
