
label ep3_14_van3:
    show ep3 sat_van3_001 with d
    simon "Shit. What's Lily doing here?" id ep3_14_van3_99c3825f
    simon "Can you hear what they're saying?" id ep3_14_van3_a1aef2c5
    show ep3 sat_van3_002 with d
    chloe "Let's see..." id ep3_14_van3_27f46b5a
    dylan "Guys, are you there?" (what_italic=True, what_bold=True)
    show ep3 sat_van3_003 with d
    chloe "Hold position for a bit, Dylan. I'll call you right back." id ep3_14_van3_6f269db5
    show ep3 sat_van3_004 with d
    chloe "Are you ready?" id ep3_14_van3_50b2b36a
    stop music fadeout 3
    jump ep3_15_susankitchen2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
