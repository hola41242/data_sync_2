
label ep3_28_emily:
    stop music fadeout 3
    show ep3 sun_emily_001 with d
    simon "(Now I can fully focus on what matters...)" id ep3_28_emily_d95c364d
    play music eye_candy fadein 7 volume 0.25
    show ep3 sun_emily_002 with fade
    simon "(... Talking to...)" id ep3_28_emily_bf3492fd
    play sound hallway_door_lock volume 0.5
    show ep3 sun_emily_003 with d
    simon "... Emily?!" id ep3_28_emily_834dba7d
    show ep3 sun_emily_004 with d
    emily "Oh. Hey, neighbor." id ep3_28_emily_7e32282c
    show ep3 sun_emily_005 with d
    simon "Wrong room?" id ep3_28_emily_374d608b
    show ep3 sun_emily_004 with d
    emily "No, I just figured you wouldn't be awake yet." id ep3_28_emily_6a37aba2
    emily "You usually wake up pretty late." id ep3_28_emily_c8e678ec
    show ep3 sun_emily_006 with d
    simon "(Huh? What is she even talking about?)" id ep3_28_emily_fc1451ba
    show ep3 sun_emily_007 with d
    simon "Look, I'm sort of in a rush right now." id ep3_28_emily_714ed17a
    show ep3 sun_emily_008 with d
    emily "I get it." id ep3_28_emily_ab762711
    show ep3 sun_emily_009 with d
    emily "In that case, I won't bother you." id ep3_28_emily_ffb6b865
    show ep3 sun_emily_010 with d
    emily "Oh, I almost forgot!" id ep3_28_emily_98b4d41e
    show ep3 sun_emily_011 with d
    emily "I came here to leave something with you." id ep3_28_emily_576a3447
    show ep3 sun_emily_012 with d
    simon "Leave what exactly?" id ep3_28_emily_69ee25e0
    show ep3 sun_emily_013 with d
    simon "(Why is she staring at me? Is she just going to stand there?)" id ep3_28_emily_c283e7a5
    play sound dress volume 0.4
    show ep3 sun_emily_014 with d:
        yalign 1.0
        ease 8 yalign 0.0
    emily "I just dropped by to give you these." id ep3_28_emily_93cfd8a3
    simon "Huh?" id ep3_28_emily_708b4972
    show ep3 sun_emily_015 with d
    simon "(What on earth is going on?!)" id ep3_28_emily_6c8940fa
    show ep3 sun_emily_016 with d
    simon "(Am I dreaming again?)" id ep3_28_emily_870e4662
    simon "(I've got to be!)" id ep3_28_emily_cb18f3b3
    show ep3 sun_emily_017 with d
    emily "They're to replace the pair you lost." id ep3_28_emily_4ad916dd
    show ep3 sun_emily_018 with d
    simon "The pair I lost..." id ep3_28_emily_9b9c35e8
    show ep3 sun_emily_019 with d
    simon "What do you mean the pair I — ?" id ep3_28_emily_d3f4c575
    play sound door_closing2 volume 0.5
    show ep3 sun_emily_020 with d
    simon "What in the...?" id ep3_28_emily_73c82f91
    show ep3 sun_emily_021 with d
    simon "I seriously don't have time for this!" id ep3_28_emily_4cdf7cdb
    play sound bath volume 0.7
    show ep3 sun_emily_022 with wipeup
    simon "(What is with the women in this town?)" id ep3_28_emily_2601d835
    play sound teeth_brush fadein 0.5 fadeout 0.5 volume 0.5
    show ep3 sun_emily_023 with wipedown
    simon "(Everyone in this town seems to have a few screws loose...)" id ep3_28_emily_7aaf4ace
    stop sound fadeout 2
    show ep3 sun_emily_024 with wipedown
    simon "(... Now all this with Emily...)" id ep3_28_emily_5480c9a3
    show ep3 sun_emily_025 with d
    simon "(... What did I lose exactly?)" id ep3_28_emily_3424e8bd
    show ep3 sun_emily_026 with d
    simon "(I lost... my underwear...)" id ep3_28_emily_a5e9f102
    simon "(How did she know about that...?)" id ep3_28_emily_9675929a
    show ep3 sun_emily_027 with d
    simon "Nope! I don't have time for this!" id ep3_28_emily_bb824ff7
    show ep3 sun_emily_028 with wipedown
    simon "(I have to focus on Lily. Appearances matter with her.)" id ep3_28_emily_3081fadd
    stop music fadeout 5
    show ep3 sun_emily_029 with fade
    simon "(She'll only take me seriously if I take myself seriously.)" id ep3_28_emily_5ec3f980

    jump ep3_29_ending
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
