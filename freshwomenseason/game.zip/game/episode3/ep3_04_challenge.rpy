
label ep3_04_challenge:

    play sound bed volume 0.8
    scene ep3 sat_challenge_001 with d
    simon "Ouch!" id ep3_04_challenge_2e4f777a
    play sound rope_tie volume 0.7
    simon "Hey, what are you two doing?" id ep3_04_challenge_91444265
    play sound girl_laughing volume 0.3
    simon "Whoa, whoa, whoa. Hold up..." id ep3_04_challenge_670c05a6
    play sound throw_bag volume 0.2
    show ep3 sat_challenge_002 with medium_dissolve
    simon "You girls are insane!" id ep3_04_challenge_9eff2516
    simon "Wait. Where's your friend?" id ep3_04_challenge_0516f043
    show ep3 sat_challenge_003 with medium_dissolve
    pause 0.8
    show ep3 sat_challenge_003_1 with medium_dissolve
    pause 0.3
    show ep3 sat_challenge_003_2 with medium_dissolve
    "..." id ep3_04_challenge_a20cefa7
    simon "Huh?"
    show ep3 sat_challenge_004 with d
    angela "She's getting ready for the test!" id ep3_04_challenge_92da39d0
    show ep3 sat_challenge_005 with d
    simon "Why exactly did you two tie me up?" id ep3_04_challenge_8be62acb
    simon "What in the hell is this test anyway?" id ep3_04_challenge_480a0837
    show ep3 sat_challenge_006 with medium_dissolve
    angela "It's a test of endurance!" id ep3_04_challenge_6b4a6985
    angela "And it's actually quite easy to comprehend." id ep3_04_challenge_7e720114
    show ep3 sat_challenge_007 with d
    simon "Endurance?" id ep3_04_challenge_a65701dd
    simon "Like resisting something?" id ep3_04_challenge_2879bc35
    play music on_the_trail volume 0.15
    show ep3 sat_challenge_008 with None
    play sound whip_crack volume 0.5
    devilla "Exactly." id ep3_04_challenge_441d076d
    devilla "You'll have to resist me." id ep3_04_challenge_84d67b81
    devilla "I'm the first part of the triathlon." id ep3_04_challenge_60c0052c
    simon "(I guess she can turn on and off her accent just like Dylan does.)" id ep3_04_challenge_ab029743
    show ep3 sat_challenge_009 with d
    devilla "You'll have three stages to make it through." id ep3_04_challenge_41d0483c
    show ep3 sat_challenge_010 with d
    devilla "Without losing." id ep3_04_challenge_e2e50626
    show ep3 sat_challenge_011 with d
    devilla "Without giving up." id ep3_04_challenge_6f7bcc26
    show ep3 sat_challenge_012 with d
    devilla "And most importantly..." id ep3_04_challenge_ddc5bb1c
    show ep3 sat_challenge_013 with d
    devilla "Without cumming." id ep3_04_challenge_4056ceb5
    show ep3 sat_challenge_014 with medium_dissolve
    simon "(She must think I'm just a boy.)" id ep3_04_challenge_9b2c42a6
    simon "(She won't beat me that easily.)" id ep3_04_challenge_01d19c99
    show ep3 sat_challenge_015 with d
    simon "(I mean, what's the worst she's got?)" id ep3_04_challenge_73409209
    play sound hitting_leather volume 0.7
    show ep3 sat_challenge_016_1 with hpunch
    pause 0.5
    show ep3 sat_challenge_016 with d

    simon "Holy fuck!" id ep3_04_challenge_f78add6d
    show ep3 sat_challenge_017 with d
    angela "Better not get too confident." id ep3_04_challenge_bee0fd83
    angela "This girl can be an absolute devil when she wants to be!" id ep3_04_challenge_97c61829
    show ep3 sat_challenge_018 with d
    angela "Enjoy yourself!" id ep3_04_challenge_6023e8e0
    play sound door_closing2 volume 0.7
    show ep3 sat_challenge_019 with None
    devilla "Focus on me now, darling." id ep3_04_challenge_8598d1d8
    show ep3 sat_challenge_020 with d
    devilla "Now we begin." id ep3_04_challenge_52284725
    show ep3 sat_challenge_021 with d
    devilla "Pay close attention." id ep3_04_challenge_3340dc0b
    show ep3 sat_challenge_022 with d
    devilla "And enjoy the show." id ep3_04_challenge_dd9afe16
    show ep3 sat_challenge_023 with d
    simon "(Well... pole dancing isn't all that impressive.)" id ep3_04_challenge_627133c3
    show ep3 sat_challenge_024 with d
    simon "(She is a stripper after all.)" id ep3_04_challenge_234560c4
    simon "(Let's see what else she can do.)" id ep3_04_challenge_dde3f3a6
    show ep3 sat_challenge_025 with d
    simon "(Not bad!)" id ep3_04_challenge_8bdf71f6
    show ep3 sat_challenge_026 with d
    devilla "Do you like what you're seeing so far?" id ep3_04_challenge_e9b75687
    show ep3 sat_challenge_027 with medium_dissolve
    devilla "I think I can give you a little more to look at." id ep3_04_challenge_86f8c7e6
    show ep3 sat_challenge_028 with d
    devilla "How's that sound?" id ep3_04_challenge_5e3545a5
    show ep3 sat_challenge_029 with medium_dissolve
    simon "I must admit." id ep3_04_challenge_0eda882b
    simon "You're good." id ep3_04_challenge_74ac1e59
    show ep3 sat_challenge_030 with d
    devilla "Do you want me to dance on your pole too?" id ep3_04_challenge_6d450b58
    show ep3 sat_challenge_031 with d
    simon "Well, if you insist!" id ep3_04_challenge_11885ee1
    show ep3 sat_challenge_032 with d
    devilla "That's right." id ep3_04_challenge_43dacc92
    devilla "Lust for me." id ep3_04_challenge_ceb2c17e
    show ep3 sat_challenge_033 with medium_dissolve
    simon "(Hmm... I'm beginning to understand their game.)" id ep3_04_challenge_77b1f368
    simon "(I can't fall for her tricks.)" id ep3_04_challenge_0b8202ac
    show ep3 sat_challenge_034 with d
    devilla "Hey..." id ep3_04_challenge_dfef6690
    devilla "What's on your mind?" id ep3_04_challenge_16a10af5
    devilla "Is it something other than me?" id ep3_04_challenge_3db5fa54
    show ep3 sat_challenge_035 with d
    devilla "Or are you thinking about how much you want me to keep dancing?" id ep3_04_challenge_fba4bb3e
    devilla "And about how much you want me?" id ep3_04_challenge_8e81511f
    show ep3 sat_challenge_036 with d
    simon "(I do want her to keep dancing...)" id ep3_04_challenge_11d95a6a
    simon "(And I want her to keep doing what she's doing...)" id ep3_04_challenge_8aa149c3
    show ep3 sat_challenge_037 with d
    devilla "You know what you want, don't you?" id ep3_04_challenge_3baa5ef9
    play sound rope_untie_knot volume 0.7
    show ep3 sat_challenge_037_1 with medium_dissolve
    pause 0.75
    show ep3 sat_challenge_037_2 with medium_dissolve
    pause 0.75
    play sound bed volume 0.7
    show ep3 sat_challenge_037_3 with hpunch
    pause 2
    show ep3 sat_challenge_038 with d
    simon "Goddamn, this is so nice..." id ep3_04_challenge_461e8d9d
    show ep3 sat_challenge_039 with d
    devilla "Yes, give yourself to me." id ep3_04_challenge_a7bfd504
    show ep3 sat_challenge_040 with d
    devilla "That's what you really desire, isn't it?" id ep3_04_challenge_fa9eb672
    show ep3 sat_challenge_041 with d
    simon "That's..." id ep3_04_challenge_a4dc2c2e
    show ep3 sat_challenge_042 with d
    simon "(Wait! She's playing me!)" id ep3_04_challenge_799588ce
    show ep3 sat_challenge_043 with d
    simon "(But it feels so good...)" id ep3_04_challenge_bcc5d90f
    simon "(I don't know what to do...)" id ep3_04_challenge_3ba429cd
    show ep3 sat_challenge_044 with d
    simon "I should resist... right?" id ep3_04_challenge_1c3b76ec

    menu:
        "Surrender to Devilla." if not _in_replay:
            $ ep3_04_challenge_surrender_to_devilla = True
            $ player_choice("ep3_04_challenge_surrender_to_devilla:true")
            show ep3 sat_challenge_045 with d
            simon "I'm sorry, Dylan..." id ep3_04_challenge_b81ced23
            simon "The temptation is just too much for me." id ep3_04_challenge_3dbf090a
            play sound jeans_off_1 volume 0.7
            show ep3 sat_challenge_046 with d
            devilla "Excellent!" id ep3_04_challenge_4eedcb82
            devilla "Just the way the devil likes it!" id ep3_04_challenge_0b2928cd
            show ep3 sat_challenge_047 with d
            simon "Hold on. You're not going to untie me?" id ep3_04_challenge_7e562608
            play sound jeans_off_2 volume 0.7
            show ep3 sat_challenge_048 with d
            devilla "Nope." id ep3_04_challenge_3f302db2
            show ep3 sat_challenge_049 with d
            devilla "Trust me." id ep3_04_challenge_04e20e62
            devilla "It'll be more fun this way." id ep3_04_challenge_03272065
            play sound panties_off_1 volume 0.5
            show ep3 sat_challenge_050 with d
            devilla "And besides..." id ep3_04_challenge_48099486
            show ep3 sat_challenge_051 with d
            devilla "You surrendered to me." id ep3_04_challenge_685e7352
            show ep3 sat_challenge_052 with d
            devilla "So now I can do whatever I want with you." id ep3_04_challenge_c5a464d5
            show ep3 sat_challenge_053 with d
            devilla "But don't worry..." id ep3_04_challenge_cadbf052
            devilla "I'll take good care of you." id ep3_04_challenge_e2ca5344
            devilla "And I'll give you what you really desire." id ep3_04_challenge_e33611e7
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_054_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_054_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_054 with d
            devilla "So?"
            devilla "What do you say, [name]?" id ep3_04_challenge_21efe71c
            pause
            stop foley
            stop voicefx
            show ep3 sat_challenge_055 with d
            simon "Ah... It's all so —" id ep3_04_challenge_3867c793
            show ep3 sat_challenge_056 with None
            devilla "Shhh..." id ep3_04_challenge_286fd6db
            devilla "I want you to answer me with your body." id ep3_04_challenge_a665ff17
            show ep3 sat_challenge_057 with d
            simon "(Ahhhh... I'm starting to think I really made a deal with the devil!)" id ep3_04_challenge_49e98490
            show ep3 sat_challenge_057_1 with d
            simon "What?"
            show ep3 sat_challenge_058 with d
            simon "I thought we were moving forward, not backward." id ep3_04_challenge_05133174
            show ep3 sat_challenge_059 with d
            devilla "What do you mean?" id ep3_04_challenge_9669acd5
            show ep3 sat_challenge_060 with d
            simon "I figured the next step would be..." id ep3_04_challenge_a433155e
            simon "... Different." id ep3_04_challenge_018e150e
            show ep3 sat_challenge_061 with d
            devilla "That's not going inside me." id ep3_04_challenge_eb798fb3
            show ep3 sat_challenge_062 with d
            devilla "But don't worry. You won't regret your decision." id ep3_04_challenge_3a4f76bb

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_063_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_063_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_063 with d
            simon "(Oh my god, this is so good...)" id ep3_04_challenge_09dc2407
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_063_var2_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_063_var2_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_063_var2 with d
            simon "(This might be somewhat wrong...)" id ep3_04_challenge_42fdfd31
            pause

            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_063_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_063_var1_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_063_var1 with d
            stop music fadeout 3
            simon "(And maybe I won't find out about the bear...)" id ep3_04_challenge_f7b4dfc8
            simon "(... or be able to help Dylan.)" id ep3_04_challenge_a71088ca
            simon "(However...)" id ep3_04_challenge_507486da
        "Resist."(True):

            $ ep3_04_challenge_resist_some_more = True
            $ player_choice("ep3_04_challenge_resist_some_more:true")
            stop foley
            stop voicefx
            show ep3 sat_challenge_044_1 with d
            simon "(Damn it, Dylan!)" id ep3_04_challenge_3c9d593d
            show ep3 sat_challenge_049 with d
            pause 0.6
            show ep3 sat_challenge_050 with d
            pause 0.6
            show ep3 sat_challenge_051 with d
            pause 0.6
            show ep3 sat_challenge_052 with d
            pause
            show ep3 sat_challenge_057_1 with d
            pause 0.6
            show ep3 sat_challenge_068 with d
            simon "As much as I want to give in..." id ep3_04_challenge_95af54ff
            show ep3 sat_challenge_069 with d
            simon "I can't!" id ep3_04_challenge_d6efda3e
            simon "I have to continue the test!" id ep3_04_challenge_8c31d016
            show ep3 sat_challenge_070 with d
            devilla "Hmmm... Smarter than I thought." id ep3_04_challenge_f456ddd6
            devilla "Congratulations." id ep3_04_challenge_689b21d4
            show ep3 sat_challenge_071 with d
            devilla "You deserve a reward..." id ep3_04_challenge_a4ea8c49
            show ep3 sat_challenge_072 with medium_dissolve
            devilla "... But rules are rules." id ep3_04_challenge_4a958fa4
            devilla "If we had gone any further, you would've failed the test for sure." id ep3_04_challenge_aee9a23b
            show ep3 sat_challenge_073 with d
            simon "(This is some sort of mind game!)" id ep3_04_challenge_1bd81ab8
            simon "(I have to stay strong if I want to continue!)" id ep3_04_challenge_d95e1ab3
            show ep3 sat_challenge_074 with d
            devilla "Congratulations on getting past the first trial." id ep3_04_challenge_4aee340a
            show ep3 sat_challenge_075 with d
            stop music fadeout 8
            devilla "Angela!" id ep3_04_challenge_bd4cbdb3
            devilla "Phase two!" id ep3_04_challenge_5a9772f9
            show ep3 sat_challenge_073 with d
            simon "(Phew! The worst is over!)" id ep3_04_challenge_7861f6b8
            show ep3 sat_challenge_076 with d
            simon "(Now I can relax.)" id ep3_04_challenge_b0b5d68b
            simon "(Angela is definitely going to be nicer than Devilla.)" id ep3_04_challenge_3521463c
            simon "(She seems more affectionate and caring.)" id ep3_04_challenge_5f81ef8e
            simon "(This will be a piece of cake.)" id ep3_04_challenge_eeeed22c
            play sound door_opening volume 0.7
            show ep3 sat_challenge_077 with d
            angela "I'm here!" id ep3_04_challenge_b1adbb67
            angela "Am I too late?" id ep3_04_challenge_e4abfc4e
            angela "I hope he's all right!" id ep3_04_challenge_a566240f
            devilla "It's your turn." id ep3_04_challenge_41c65a50
            devilla "Take good care of him." id ep3_04_challenge_1acbbe27

            play music dark_horse fadein 6 volume 0.15
            show ep3 sat_challenge_078 with d:
                yalign 1.0
                ease 8 yalign 0.0
            angela "Hi!" id ep3_04_challenge_c3f660de
            angela "Glad you made it to the second stage!" id ep3_04_challenge_a1d19959
            show ep3 sat_challenge_079 with d
            simon "(Wow...)" id ep3_04_challenge_943b1370
            show ep3 sat_challenge_080 with d
            simon "(Oh, wow...)" id ep3_04_challenge_fdc6fadf
            show ep3 sat_challenge_081 with d
            simon "(Maybe it won't be that easy after all...)" id ep3_04_challenge_716659d7
            show ep3 sat_challenge_082 with fast_fade
            angela "Ohhh... You poor thing!" id ep3_04_challenge_1834a150
            angela "She left you all tied up in here, didn't she?" id ep3_04_challenge_6c354e3c
            show ep3 sat_challenge_083 with d
            angela "Let's get you out of these." id ep3_04_challenge_3b329fbb
            angela "You don't deserve to be treated like this." id ep3_04_challenge_1dc29120
            show ep3 sat_challenge_084 with d
            simon "Wow, thanks!" id ep3_04_challenge_efa1ee8d
            simon "Finally, someone is being nice to me." id ep3_04_challenge_151dd4ce
            show ep3 sat_challenge_085 with d
            angela "Oh, no!" id ep3_04_challenge_c9cd2516
            angela "Was Devilla mean to you?" id ep3_04_challenge_abc4e960
            show ep3 sat_challenge_086 with d
            simon "Not exactly mean, but..." id ep3_04_challenge_4c956a1e
            show ep3 sat_challenge_087 with d
            angela "Ohh... Come here." id ep3_04_challenge_bc55edd6
            show ep3 sat_challenge_088 with d
            angela "Nobody is going to hurt you here, okay?" id ep3_04_challenge_990f2fde
            angela "You're our guest after all." id ep3_04_challenge_53808ee3
            show ep3 sat_challenge_089 with d
            angela "Looks like Devilla put you through the wringer." id ep3_04_challenge_3530221c
            show ep3 sat_challenge_090 with d
            angela "Look at what she did to you!" id ep3_04_challenge_32baf912
            angela "Was she mean to you down there too?" id ep3_04_challenge_e183c135
            show ep3 sat_challenge_091 with d
            simon "Not exactly..." id ep3_04_challenge_5a408d60
            simon "She just... got me in the mood." id ep3_04_challenge_06a2570f
            show ep3 sat_challenge_092 with d
            angela "Devilla is beyond redemption!" id ep3_04_challenge_ba7ed2fa
            angela "So, so cruel!" id ep3_04_challenge_9cbf23e2
            show ep3 sat_challenge_093 with d
            angela "Leave it to me." id ep3_04_challenge_332e3110
            angela "Let me fix it and make it all better." id ep3_04_challenge_bc96c622



            show ep3 sat_challenge_095 with d
            angela "How does it feel when I do this?" id ep3_04_challenge_edf96628
            show ep3 sat_challenge_096 with d
            simon "Ahhh... Much better. No doubt about it." id ep3_04_challenge_9ab89698
            show ep3 sat_challenge_097 with d
            angela "And it will get even more so." id ep3_04_challenge_fb1bddf0
            angela "I guarantee it." id ep3_04_challenge_9e9e98e3
            show ep3 sat_challenge_098 with d
            simon "Ahhh..." id ep3_04_challenge_ca6c5119
            show ep3 sat_challenge_099 with d
            simon "That's right... You really know how to treat a guest." id ep3_04_challenge_05a66a9c
            show ep3 sat_challenge_100 with d
            angela "But of course!" id ep3_04_challenge_8c52d665
            angela "We only want to give you our best." id ep3_04_challenge_405411fc
            show ep3 sat_challenge_101 with d
            simon "Who do you mean by \"we\" exactly?"
            simon "Is Devilla included?" id ep3_04_challenge_9d772a31
            simon "I don't think she likes me all that much." id ep3_04_challenge_b6b7b8c3
            show ep3 sat_challenge_102 with d
            angela "Oh, that's our Devilla! She can be like that." id ep3_04_challenge_64df1dfe
            angela "But we both want the same thing." id ep3_04_challenge_27f74d93
            show ep3 sat_challenge_103 with d
            simon "The same thing?" id ep3_04_challenge_5788d77d
            simon "(So she's trying to get me to give up too!)" id ep3_04_challenge_c39cf1d5
            simon "(Or is she really just being nice?)" id ep3_04_challenge_b4add758
            show ep3 sat_challenge_104 with d
            angela "No..." id ep3_04_challenge_8eed2392
            angela "Don't think any other thoughts." id ep3_04_challenge_214af4eb
            angela "Focus on me." id ep3_04_challenge_23ff5898
            show ep3 sat_challenge_105 with d
            angela "Focus on these." id ep3_04_challenge_8d2817f5
            show ep3 sat_challenge_106 with d
            angela "Doesn't it feel better?" id ep3_04_challenge_b7b0c158
            simon "(So much better.)" id ep3_04_challenge_d7a44231
            show ep3 sat_challenge_107 with d
            angela "Don't be shy." id ep3_04_challenge_340bbe44
            show ep3 sat_challenge_108 with d
            angela "You can play with them if you want." id ep3_04_challenge_100d03df
            angela "They're not just for show." id ep3_04_challenge_2357bf18
            $ renpy.music.set_volume(0.2, delay=1)
            play sound ooohh volume 0.5
            show ep3 sat_challenge_109 with fast_white_fade
            simon "(It's like caressing the clouds in the sky.)" id ep3_04_challenge_01430cd4
            simon "(It feels like dancing with the angels.)" id ep3_04_challenge_aec874bc
            simon "(This is so good I could... I could stay here all day...)" id ep3_04_challenge_d42b6887
            $ renpy.music.set_volume(0.4, delay=1)
            stop sound fadeout 2
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_110_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_110_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_110 with fast_white_fade
            angela "That's it. Now relax..." id ep3_04_challenge_e03381fe
            pause
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_110_var1_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_110_var1_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_110_var1 with d
            angela "You'll be all right." id ep3_04_challenge_babe56a9
            pause
            $ allow_voicefx = False
            if is_voice_installed:
                play voicefx ep3_anim_sat_challenge_110_var2_voicefx fadein 0.5 fadeout 0.5
                play foley ep3_anim_sat_challenge_110_var2_foley fadein 0.5 fadeout 0.5
            show ep3 anim_sat_challenge_110_var2 with d
            angela "Your friend is in good hands." id ep3_04_challenge_6feb16be
            pause     
            stop foley
            stop voicefx
            show ep3 sat_challenge_111 with d
            angela "You can spend the whole day here with me if you so desire." id ep3_04_challenge_78690409

            menu:
                "Surrender to Angela." if not _in_replay:
                    $ ep3_04_challenge_surrender_to_angela = True
                    $ player_choice("ep3_04_challenge_surrender_to_angela:true")
                    show ep3 sat_challenge_112 with d
                    simon "I would really like that." id ep3_04_challenge_cb5ff2df
                    show ep3 sat_challenge_113 with d
                    angela "(Gotcha!)" id ep3_04_challenge_05fa5347
                    show ep3 sat_challenge_114 with d
                    angela "Then let's have some fun!" id ep3_04_challenge_3298056e
                    show ep3 sat_challenge_115 with d
                    angela "I want you to release all that built-up tension." id ep3_04_challenge_add3977f
                    angela "Release it all onto my tits." id ep3_04_challenge_a5f5970b
                    show ep3 sat_challenge_116 with d
                    simon "Ahhh... You make me feel like I'm in heaven." id ep3_04_challenge_0c945ffb
                    show ep3 sat_challenge_117 with d
                    angela "You've made the right choice." id ep3_04_challenge_ebc7cbe7
                    angela "Leave the rest to me." id ep3_04_challenge_5214ae47
                    show ep3 sat_challenge_118 with d
                    angela "I think it's about time for your happy ending." id ep3_04_challenge_638f8232
                    show ep3 sat_challenge_117 with d
                    simon "Aaahh..." id ep3_04_challenge_f073064a
                    show ep3 sat_challenge_119 with d
                    pause 0.2
                    show ep3 sat_challenge_119_1 with d
                    pause 0.2
                    show ep3 sat_challenge_119 with d
                    pause 0.2
                    show ep3 sat_challenge_119_1 with d
                    pause 0.2
                    show ep3 sat_challenge_120 with thunder2
                    simon "Aaaaahhh!" id ep3_04_challenge_3ac127a4
                    show ep3 sat_challenge_121 with d
                    angela "Wow!" id ep3_04_challenge_c5892d27
                    angela "What a huge load!" id ep3_04_challenge_e802e0a3
                    show ep3 sat_challenge_122 with d
                    angela "Looks like you really needed that." id ep3_04_challenge_8c8d8f2d
                    angela "I'm glad I could help." id ep3_04_challenge_12f7fa25
                    stop music fadeout 5
                    show ep3 sat_challenge_123 with d
                    simon "(Wow, is she going to...?)" id ep3_04_challenge_98d4c3e8
                    show ep3 sat_challenge_124 with d
                    angela "*Gulp.*" (what_italic=True)
                    angela "Mmmm... You taste great!" id ep3_04_challenge_dd22f050
                "Hold on a little longer."(True):

                    $ ep3_04_challenge_survive_angela = True
                    $ ep3_04_challenge_won = True
                    $ player_choice("ep3_04_challenge_survive_angela:true")
                    show ep3 sat_challenge_126 with d
                    simon "(Dylan, I wish you could see what I'm not doing because of you!)" id ep3_04_challenge_ee0d97b6
                    show ep3 sat_challenge_127 with d
                    simon "As much as I'd like to..." id ep3_04_challenge_b7d9e25d
                    simon "I'm here on a mission." id ep3_04_challenge_a67d586d
                    show ep3 sat_challenge_128 with d
                    simon "So you can bring on the next challenge. I'm ready for it!" id ep3_04_challenge_a5baf321
                    show ep3 sat_challenge_129 with d
                    angela "Amazing!" id ep3_04_challenge_a40fb506
                    angela "What a man! You are truly worthy!" id ep3_04_challenge_ebf1699e
                    show ep3 sat_challenge_130 with d
                    pause
                    show ep3 sat_challenge_131 with d
                    angela "You might even deserve to conquer this triathlon." id ep3_04_challenge_11bc9bf1
                    show ep3 sat_challenge_132 with d
                    simon "Speaking of conquering, what's the third challenge?" id ep3_04_challenge_0fcd7e8e
                    simon "First there was Devilla, and now you... So who's next?" id ep3_04_challenge_f02a5e52
                    stop music fadeout 7
                    show ep3 sat_challenge_133 with d
                    simon "Oh..." id ep3_04_challenge_d3eabd74
                    simon "It's the bear's turn, isn't it?" id ep3_04_challenge_4b867d2b
                    simon "What kind of sick game do you two play with the people here?!" id ep3_04_challenge_3217a13f
                    show ep3 sat_challenge_134 with d
                    angela "What?! No! Of course it's not the bear!" id ep3_04_challenge_dbcf2b98
                    angela "The bear is just a distraction." id ep3_04_challenge_2029f154
                    show ep3 sat_challenge_132 with d
                    simon "What do you mean distraction?" id ep3_04_challenge_76cbac9f
                    show ep3 sat_challenge_135 with d
                    angela "To prevent people from thinking about... certain things." id ep3_04_challenge_60ed4fbe
                    angela "The bear's normally here to make The Test easier to pass." id ep3_04_challenge_7cd6b5fd
                    show ep3 sat_challenge_136 with d
                    simon "I didn't find it all that challenging." id ep3_04_challenge_4cafe6f9
                    show ep3 sat_challenge_137 with d
                    angela "That's because you haven't gotten to the final part yet." id ep3_04_challenge_d0567aef
                    show ep3 sat_challenge_138 with d
                    simon "Then what comes after the two of you?" id ep3_04_challenge_c525ed2c
                    play sound door_opening volume 0.7
                    show ep3 sat_challenge_139 with medium_dissolve


                    play music late_night_lady volume 0.15
                    devilla "Well, that's just it." id ep3_04_challenge_972c4b4b
                    devilla "It's the two of us..." id ep3_04_challenge_4c5a3229
                    show ep3 sat_challenge_140 with d
                    angela "... together." id ep3_04_challenge_4db5cd26
                    show ep3 sat_challenge_141 with d
                    devilla "If I were you..." id ep3_04_challenge_672de544
                    show ep3 sat_challenge_142 with d
                    angela "... I wouldn't be able to resist such a temptation." id ep3_04_challenge_3a8cf9db
                    show ep3 sat_challenge_143 with d
                    simon "Whoa..." id ep3_04_challenge_03389c79
                    show ep3 sat_challenge_144 with d
                    simon "(I think they're really committed to making me lose this challenge.)" id ep3_04_challenge_6bf4ab5f
                    simon "(Their strategy might even work!)" id ep3_04_challenge_7c2d62b1
                    show ep3 sat_challenge_145 with d
                    devilla "Angela may act all nice, but she's truly very naughty." id ep3_04_challenge_b4ac9db3
                    devilla "She needs to learn her place." id ep3_04_challenge_93560dce
                    play sound slap_ass2 volume 0.7
                    show ep3 sat_challenge_146 with hpunch

                    angela "Ahhhh..."
                    show ep3 sat_challenge_147 with d
                    angela "Mmmm... Devilla, you're so mean!" id ep3_04_challenge_01e91ea6
                    angela "But you shouldn't be wasting all that energy on me." id ep3_04_challenge_4ba39056

                    show ep3 sat_challenge_149 with d
                    angela "Isn't that right, Devilla?" id ep3_04_challenge_28439b41

                    show ep3 sat_challenge_148 with d

                    devilla "I think we know who our target is, Angela." id ep3_04_challenge_85f064ba
                    show ep3 sat_challenge_151 with d
                    simon "(Dylan, I think I might be in trouble...)" id ep3_04_challenge_8898d216
                    show ep3 sat_challenge_152 with d
                    angela "Unlike Devilla here, I'm always nice." id ep3_04_challenge_3e5971ac
                    angela "And I'll make sure you get what you really want." id ep3_04_challenge_c8303e7a
                    play sound placeholder volume 0.7
                    show ep3 sat_challenge_152_1 with d
                    devilla "Let me get more comfortable." id ep3_04_challenge_65e5f444
                    show ep3 sat_challenge_153 with d
                    angela "Are you ready for your final trial?" id ep3_04_challenge_62f8db16
                    show ep3 sat_challenge_154 with d
                    simon "I bet this last part is going to change things up, huh?" id ep3_04_challenge_17612405
                    show ep3 sat_challenge_155 with d
                    devilla "This time we won't just be teasing." id ep3_04_challenge_6b912af5
                    show ep3 sat_challenge_156 with d
                    angela "This time it's for real." id ep3_04_challenge_91c862c5
                    simon "(It's going to be hard to control myself.)" id ep3_04_challenge_84a72e04
                    simon "(But I can't miss my chance here either!)" id ep3_04_challenge_a01f6813
                    simon "(I want to know what happens next!)" id ep3_04_challenge_d56b72d6
                    show ep3 sat_challenge_157 with d
                    angela "Ahh..." id ep3_04_challenge_72b29d2a
                    angela "Please be gentle." id ep3_04_challenge_37fb8c3f
                    angela "They're so sensitive..." id ep3_04_challenge_feb29f1d
                    show ep3 sat_challenge_158 with d
                    devilla "Oh, so you think you can handle the both of us?" id ep3_04_challenge_7bb54bfe
                    devilla "If you're so brave, I'm willing to make you a proposal..." id ep3_04_challenge_206a71b7
                    show ep3 sat_challenge_159 with d
                    devilla "If you can make both of us cum, you pass The Test." id ep3_04_challenge_a0fcb2de
                    show ep3 sat_challenge_160 with d
                    angela "But it has to be both of us." id ep3_04_challenge_015666e5
                    show ep3 sat_challenge_161 with d
                    devilla "Can you handle that?" id ep3_04_challenge_d14bc040
                    show ep3 sat_challenge_162 with d
                    simon "Hmmmph..." id ep3_04_challenge_d7004f3b
                    show ep3 sat_challenge_163 with d
                    angela "He said yes, Devilla!" id ep3_04_challenge_cb9e23b4
                    angela "I trust him!" id ep3_04_challenge_451e59d7
                    show ep3 sat_challenge_164 with d
                    angela "But we could always help him out a little." id ep3_04_challenge_a6207445
                    show ep3 sat_challenge_165 with d
                    devilla "Ahh... Isn't that a great idea?" id ep3_04_challenge_6340d441
                    devilla "Who's the little devil now, Angela?" id ep3_04_challenge_494581db
                    show ep3 sat_challenge_166 with d
                    devilla "(Mmm... she's so turned on today.)" id ep3_04_challenge_578ecbac
                    devilla "(I think she really likes this boy.)" id ep3_04_challenge_f810a28f
                    show ep3 sat_challenge_167 with d
                    devilla "(I could help him out, but he did let our bear loose.)" id ep3_04_challenge_5e2d3608
                    show ep3 sat_challenge_168 with d
                    devilla "(He's not all bad though...)" id ep3_04_challenge_8c831efd
                    show ep3 sat_challenge_169 with d
                    devilla "(Maybe I could cut him a tiny bit of slack.)" id ep3_04_challenge_edf0e061
                    show ep3 sat_challenge_170 with d
                    devilla "(But our bear.)" id ep3_04_challenge_b5794c28
                    show ep3 sat_challenge_171 with d
                    devilla "Get up. Now." id ep3_04_challenge_2efceacd
                    show ep3 sat_challenge_172 with d
                    angela "Devilla, what is it?" id ep3_04_challenge_d20986a3
                    angela "Was he being mean to you?" id ep3_04_challenge_0e9bff45
                    show ep3 sat_challenge_173 with d
                    devilla "Not to me, Angela." id ep3_04_challenge_e4e3f4f3
                    devilla "But he mistreated our bear." id ep3_04_challenge_1e210f26
                    devilla "Or have you already forgotten about that?" id ep3_04_challenge_02b4b344
                    show ep3 sat_challenge_174 with d
                    angela "I thought I could forgive you for that..." id ep3_04_challenge_6abb3e5a
                    angela "But Devilla is right." id ep3_04_challenge_91d1a0c6
                    show ep3 sat_challenge_175 with d
                    angela "You'll just have to fail the test." id ep3_04_challenge_1b87ae13
                    show ep3 sat_challenge_176 with d
                    simon "What do you mean fail the test?" id ep3_04_challenge_643506df
                    show ep3 sat_challenge_177 with d
                    simon "Is it over already? I lost? That doesn't make sense!" id ep3_04_challenge_34a70d07
                    show ep3 sat_challenge_178 with d
                    devilla "You haven't lost yet..." id ep3_04_challenge_e60a940f
                    show ep3 sat_challenge_179 with d
                    angela "... But you will." id ep3_04_challenge_dbf1f478
                    show ep3 sat_challenge_180 with d
                    devilla "Nobody's going to help you now." id ep3_04_challenge_eee80a62
                    show ep3 sat_challenge_181 with d
                    simon "Wait a minute. Isn't this all sort of... wrong?" id ep3_04_challenge_3f640aed
                    show ep3 sat_challenge_182 with d
                    devilla "If you stop now, you won't be able to have fun with us..." id ep3_04_challenge_0db5be15
                    devilla "... And I know you want this." id ep3_04_challenge_8d02080c
                    show ep3 sat_challenge_183 with d
                    devilla "But, if you do want to stop..." id ep3_04_challenge_4d445eb1
                    devilla "I'll let you and your friend leave." id ep3_04_challenge_67e44957
                    stop music fadeout 5
                    show ep3 sat_challenge_184 with d
                    devilla "Or you can stay here and test your luck." id ep3_04_challenge_cde5708b
                    devilla "So, what's your choice?" id ep3_04_challenge_cf4b94b1

                    menu:
                        "Stay"(True):
                            play music talk_about_it volume 0.15

                            $ ep3_04_challenge_fuck_both = True
                            $ player_choice("ep3_04_challenge_fuck_both:true")
                            show ep3 sat_challenge_185 with d
                            simon "I'm going to fulfill my mission here." id ep3_04_challenge_d39e462c
                            simon "And I'm going to do it with style." id ep3_04_challenge_f6a24141
                            show ep3 sat_challenge_186 with d
                            devilla "Mmmm..." id ep3_04_challenge_7414c322
                            devilla "(What a player!)" id ep3_04_challenge_68bee018
                            show ep3 sat_challenge_187 with d
                            devilla "Are you in agreement with all this?" id ep3_04_challenge_c03e6ecb
                            show ep3 sat_challenge_188 with d
                            angela "Mmmm, yes!" id ep3_04_challenge_30504e33
                            show ep3 sat_challenge_189 with d
                            devilla "Well, Angela...if you're happy, I'm happy." id ep3_04_challenge_26dee96f
                            show ep3 sat_challenge_190 with d
                            devilla "So together, we'll make you even happier." id ep3_04_challenge_0eb550e0
                            $ allow_voicefx = False
                            if is_voice_installed:
                                play voicefx ep3_anim_sat_challenge_190_var5_voicefx fadein 0.5 fadeout 0.5
                                play foley ep3_anim_sat_challenge_190_var5_foley fadein 0.5 fadeout 0.5
                            show ep3 anim_sat_challenge_190_var5 with d
                            simon "(These two seem pretty close.)" id ep3_04_challenge_84e36a14
                            pause
                            $ allow_voicefx = False
                            if is_voice_installed:
                                play voicefx ep3_anim_sat_challenge_190_var7_voicefx fadein 0.5 fadeout 0.5
                                play foley ep3_anim_sat_challenge_190_var7_foley fadein 0.5 fadeout 0.5
                            show ep3 anim_sat_challenge_190_var7 with d
                            simon "(That makes it even hotter!)" id ep3_04_challenge_8492ec33
                            pause
                            stop foley
                            stop voicefx
                            show ep3 sat_challenge_192 with d
                            simon "Hey." id ep3_04_challenge_0917202c
                            $ allow_voicefx = False
                            if is_voice_installed:
                                play voicefx ep3_anim_sat_challenge_190_var6_voicefx fadein 0.5 fadeout 0.5
                                play foley ep3_anim_sat_challenge_190_var6_foley fadein 0.5 fadeout 0.5
                            show ep3 anim_sat_challenge_190_var6 with d
                            simon "I'm sorry about your bear." id ep3_04_challenge_4b2d0f49
                            simon "I shouldn't have given it drinks...or whatever it is I did exactly." id ep3_04_challenge_f3bd92c2
                            pause
                            $ allow_voicefx = False
                            if is_voice_installed:
                                play voicefx ep3_anim_sat_challenge_190_var4_voicefx fadein 0.5 fadeout 0.5
                                play foley ep3_anim_sat_challenge_190_var4_foley fadein 0.5 fadeout 0.5
                            show ep3 anim_sat_challenge_190_var4 with d
                            angela "Aww... That's all I needed to hear!" id ep3_04_challenge_4aa57226
                            pause
                            stop foley
                            stop voicefx
                            show ep3 sat_challenge_194 with d
                            angela "See, Devilla?" id ep3_04_challenge_ec63c050
                            show ep3 sat_challenge_195 with d
                            angela "I told you he was nice!" id ep3_04_challenge_17c365f9
                            show ep3 sat_challenge_196 with d
                            devilla "I don't usually reward the good guys..." id ep3_04_challenge_ea19ac7a
                            show ep3 sat_challenge_197 with d
                            devilla "... But I think I can make an exception today." id ep3_04_challenge_a6e7321d
                            show ep3 sat_challenge_198 with d
                            angela "You're so lucky!" id ep3_04_challenge_dfc3a201
                            angela "She's not like this with everyone!" id ep3_04_challenge_b1da3084
                            angela "If I were you, I would take advantage of this opportunity." id ep3_04_challenge_95ce9595
                            show ep3 sat_challenge_199 with d
                            angela "I'm definitely going to enjoy it!" id ep3_04_challenge_ddcbd0fc
                            show ep3 sat_challenge_200 with d
                            devilla "So?"
                            show ep3 sat_challenge_201 with d
                            simon "Well, I guess I'll enjoy it too." id ep3_04_challenge_d3c378db
                            show ep3 sat_challenge_202 with d
                            simon "And I'll enjoy a piece of you as well." id ep3_04_challenge_889110ff
                            angela "Ahhhh..."
                            show ep3 sat_challenge_203 with d
                            devilla "(He has such a big dick...)" id ep3_04_challenge_46bf57ba
                            devilla "(But I'll keep that to myself. He's already enjoying himself enough.)" id ep3_04_challenge_fa927433
                            show ep3 sat_challenge_204 with d
                            angela "(Wow, I've never seen Devilla like this!)" id ep3_04_challenge_8083b5f4
                            angela "(She must really be getting into it!)" id ep3_04_challenge_cff8f590
                            show ep3 sat_challenge_205 with d
                            angela "I want more!" id ep3_04_challenge_164a5a20
                            show ep3 sat_challenge_206 with d
                            devilla "Angela! Keep it down!" id ep3_04_challenge_2f03d8c9
                            devilla "If you're that hungry, I can help a girl out." id ep3_04_challenge_ef44533c
                            show ep3 sat_challenge_207 with d
                            devilla "Here... Let's do it like this." id ep3_04_challenge_dd426347
                            show ep3 sat_challenge_208 with d
                            angela "Aaaahhhhh! It's so wonderful!" id ep3_04_challenge_e4d58ac8
                            show ep3 sat_challenge_209 with d
                            simon "(Holy fuck!)" id ep3_04_challenge_acdc88f8
                            simon "(Now I get it when they said I would fail this test!)" id ep3_04_challenge_493b4e31
                            simon "(It's impossible not to get turned way on by the two of them!)" id ep3_04_challenge_b7439d0b
                            show ep3 sat_challenge_210 with d
                            devilla "What? Are you almost there already?" id ep3_04_challenge_b8fe6dbd
                            show ep3 sat_challenge_211 with d
                            devilla "You're not finishing yet!" id ep3_04_challenge_cbae2371
                            devilla "We didn't even get to the best part!" id ep3_04_challenge_06e0a675
                            show ep3 sat_challenge_212 with vpunch
                            angela "Aaghh!" id ep3_04_challenge_651aaaa5
                            devilla "Come on! Stand up." id ep3_04_challenge_16cc3236
                            play sound falling_body_floor volume 0.7
                            show ep3 sat_challenge_213 with vpunch
                            devilla "Over here." id ep3_04_challenge_4d968534
                            show ep3 sat_challenge_214 with d
                            simon "Here? Where?" id ep3_04_challenge_7a6578a4
                            show ep3 sat_challenge_215 with d
                            devilla "You stand right here, Angela." id ep3_04_challenge_c7aa9537
                            show ep3 sat_challenge_216 with d
                            devilla "Didn't you want more from him?" id ep3_04_challenge_32243fba
                            devilla "This is your chance." id ep3_04_challenge_2b4a9039
                            show ep3 sat_challenge_217 with d
                            devilla "She's all yours!" id ep3_04_challenge_a3080e6d
                            show ep3 sat_challenge_218 with d
                            simon "Are you okay with this, Angela?" id ep3_04_challenge_2079a722
                            show ep3 sat_challenge_219 with d
                            angela "Ahhh... Devilla knows me too well..." id ep3_04_challenge_783dfc15
                            angela "This is my favorite position." id ep3_04_challenge_03c512e1
                            show ep3 sat_challenge_220 with d
                            simon "If that's the case..." id ep3_04_challenge_f035d77d
                            show ep3 sat_challenge_221 with d
                            angela "Aaaaaahhhnngg..." id ep3_04_challenge_aa36a744
                            show ep3 sat_challenge_222 with d
                            angela "Devilla had the right idea!" id ep3_04_challenge_188d9711
                            angela "I knew you'd be good at this!" id ep3_04_challenge_eb716ad7
                            show ep3 sat_challenge_223 with d
                            simon "How about you? Don't you want to join in the fun?" id ep3_04_challenge_42e23ef6
                            show ep3 sat_challenge_224 with d
                            angela "Yeah, Devilla. Are you just going to stand there and watch?" id ep3_04_challenge_599c9269
                            show ep3 sat_challenge_225 with d
                            devilla "Does he think he can take on both of us at once?" id ep3_04_challenge_63803760
                            show ep3 sat_challenge_226 with d
                            angela "Ahhh... You really are so mean, Devilla!" id ep3_04_challenge_6aaae97c
                            show ep3 sat_challenge_227 with d
                            simon "What are you up to over there?" id ep3_04_challenge_3f91d8e7
                            show ep3 sat_challenge_228 with d
                            devilla "*Giggles.*" (what_italic=True)
                            show ep3 sat_challenge_229 with d
                            devilla "You look like you're strong enough." id ep3_04_challenge_9f142a8e
                            simon "(What is she planning on doing?)" id ep3_04_challenge_750e30f8
                            show ep3 sat_challenge_230 with d
                            devilla "Time for your final test of endurance." id ep3_04_challenge_9f201ed3
                            show ep3 sat_challenge_231 with vpunch
                            devilla "Hold on!" id ep3_04_challenge_60becd02
                            simon "Wait, what are you — ?" id ep3_04_challenge_e7e40a7c
                            show ep3 sat_challenge_232 with d
                            simon "(HOLY FUCK!)" id ep3_04_challenge_16b85236
                            show ep3 sat_challenge_233 with d
                            simon "(Is this even possible?!)" id ep3_04_challenge_039d9e4a
                            show ep3 sat_challenge_234 with d
                            simon "(Wow... We fit perfectly...)" id ep3_04_challenge_5b950f83
                            show ep3 sat_challenge_235 with d
                            simon "(... Our bodies in sync...)" id ep3_04_challenge_85f37664
                            show ep3 sat_challenge_236 with d
                            simon "(... The balance of good...)" id ep3_04_challenge_6fa04f7c
                            show ep3 sat_challenge_237 with d
                            simon "(... And evil...)" id ep3_04_challenge_db4e8bae
                            show ep3 sat_challenge_238 with d
                            simon "(... THIS IS NIRVANA!)" id ep3_04_challenge_e463cd08
                            show ep3 sat_challenge_239 with d
                            angela "Aaahhh. Devilla, I'm almost there!" id ep3_04_challenge_60730d09
                            show ep3 sat_challenge_240 with d
                            devilla "Me too!" id ep3_04_challenge_33535cfa
                            show ep3 sat_challenge_241 with d
                            angela "Mmmmm..." id ep3_04_challenge_879df90b
                            devilla "Mmm..." id ep3_04_challenge_b700dbb1
                            show ep3 sat_challenge_242 with d
                            angela "Aaaahhh!!" id ep3_04_challenge_87bef3fa
                            devilla "Aaaaaahh!" id ep3_04_challenge_3ee226c0
                            show ep3 sat_challenge_243 with d
                            simon "Mmmm..." id ep3_04_challenge_29542a38
                            show ep3 sat_challenge_244 with d
                            angela "Wait! Don't finish just yet!" id ep3_04_challenge_15efe01a
                            show ep3 sat_challenge_245 with d
                            angela "I want you to do it on my face." id ep3_04_challenge_ea6ee34a
                            show ep3 sat_challenge_246 with d
                            devilla "Angela, you dirty girl!" id ep3_04_challenge_2849763d
                            show ep3 sat_challenge_247 with d
                            devilla "In that case, I want some too!" id ep3_04_challenge_05de8582
                            show ep3 sat_challenge_248 with d
                            simon "Then get ready! I'm coming!" id ep3_04_challenge_665acb60
                            show ep3 sat_challenge_249 with d
                            simon "Aaaahhh..." id ep3_04_challenge_643c7c6f
                            show ep3 sat_challenge_250 with hpunch
                            pause 0.5
                            show ep3 sat_challenge_250 with hpunch
                            pause 0.5
                            show ep3 sat_challenge_250 with hpunch
                            pause 0.5                            
                            angela "Aaah!" id ep3_04_challenge_949e7c28
                            show ep3 sat_challenge_251 with d
                            angela "All mine!" id ep3_04_challenge_f38a2618
                            show ep3 sat_challenge_252 with d
                            devilla "I'll teach you how to share!" id ep3_04_challenge_bf0369fd
                            show ep3 sat_challenge_253 with d
                            simon "Wow... That's sexy." id ep3_04_challenge_d9f3fe9b
                            show ep3 sat_challenge_254 with d
                            devilla "Can't waste a drop, can I?" id ep3_04_challenge_9b5000d1
                            devilla "*Gulp.*" (what_italic=True)
                            show ep3 sat_challenge_255 with d
                            angela "Thank you." id ep3_04_challenge_d417acb3
                            angela "It was delicious." id ep3_04_challenge_40e7fc9a
                            stop music fadeout 5
                            show ep3 sat_challenge_256 with d
                            devilla "Theoretically, you failed the test..." id ep3_04_challenge_7dd3e182
                            show ep3 sat_challenge_257 with d
                            devilla "... But I'll make an exception this time." id ep3_04_challenge_9e005a27
                            show ep3 sat_challenge_258 with d
                            devilla "You can go now." id ep3_04_challenge_9d6c3d21

                        "Leave" if not _in_replay:
                            $ ep3_04_challenge_stop_here = True
                            $ player_choice("ep3_04_challenge_stop_here:true")
                            show ep3 sat_challenge_259 with d
                            simon "I think we'd better stop here." id ep3_04_challenge_772c8ae6
                            simon "It's getting a little weird, and I got what I wanted." id ep3_04_challenge_a185ddfa
                            show ep3 sat_challenge_260 with d
                            angela "I didn't imagine you'd be such a prude." id ep3_04_challenge_c68df9af
                            angela "But I'm happy enough to hear it." id ep3_04_challenge_971cfecb
                            show ep3 sat_challenge_261 with d
                            angela "Most who come here are perverts." id ep3_04_challenge_516f334c
                            angela "Glad you're not like them!" id ep3_04_challenge_13bd0dfc
                            show ep3 sat_challenge_262 with d
                            simon "(Yeah... That's not really why... Oh well.)" id ep3_04_challenge_988af261
                            show ep3 sat_challenge_263 with d
                            simon "So, do I just leave or...?" id ep3_04_challenge_0699256d
                            show ep3 sat_challenge_264 with d
                            angela "Yes, you're free to go." id ep3_04_challenge_06a6dedc
                            angela "Thank you for playing our game!" id ep3_04_challenge_9341dac3









label ep3_04_challenge_after:
    stop foley
    stop voicefx
    $ renpy.end_replay()

    if (chose ('ep3_04_challenge_surrender_to_angela') or
    chose('ep3_04_challenge_surrender_to_devilla')):
        if choice_made('ep3_04_challenge_surrender_to_devilla'):
            show ep3 sat_challenge_067 with vpunch
            simon "THAT WAS SO WORTH IT!" id ep3_04_challenge_after_7fc85e3f
        elif choice_made('ep3_04_challenge_surrender_to_angela'):
            show ep3 sat_challenge_265 with fade
        else:
            show ep3 sat_challenge_265 with d
        dylan "Come on, bro! You can do it!" id ep3_04_challenge_after_0698471e
        show ep3 sat_challenge_266 with d
        dylan "Bro..." id ep3_04_challenge_after_8324bf67
        show ep3 sat_challenge_267 with d
        dylan "It didn't go well, did it?" id ep3_04_challenge_after_6888a8c0

        if chose('points_dylan', 1):
            show ep3 sat_challenge_274 with d
            simon "I tried my best, bro... But it just wasn't enough." id ep3_04_challenge_after_20ed4160
            show ep3 sat_challenge_275 with d
            dylan "Man... you got pretty far! Not everyone passes the test." id ep3_04_challenge_after_26181602
            show ep3 sat_challenge_276 with d
            dylan "One day, I'll have the honor of giving it a go myself!" id ep3_04_challenge_after_bff01017
            show ep3 sat_challenge_277 with d
            dylan "I'm going to fix this." id ep3_04_challenge_after_d6290cd7
            show ep3 sat_challenge_271 with d
            dylan "Can you hang around a bit? I'll be right back." id ep3_04_challenge_after_cb3cf165
        else:

            show ep3 sat_challenge_268 with d
            simon "That's right, Dylan. Looks like you're going to have to work this out yourself." id ep3_04_challenge_after_3360c1c9
            show ep3 sat_challenge_269 with d
            dylan "Oh... Uh... Right... I thought you were my..." id ep3_04_challenge_after_b65fdfc3
            show ep3 sat_challenge_270 with d
            dylan "Whatever. Let me handle this." id ep3_04_challenge_after_ba61b818
            show ep3 sat_challenge_271 with d
            dylan "Girls... Let's talk business." id ep3_04_challenge_after_72dffce1
            show ep3 sat_challenge_272 with d
            dylan "Can you wait for me outside?" id ep3_04_challenge_after_d6172443


    elif choice_made('ep3_04_challenge_stop_here'):
        show ep3 sat_challenge_265 with fade
        dylan "Come on, bro! You can do this!" id ep3_04_challenge_after_ef24c06a
        show ep3 sat_challenge_285 with d
        simon "Phew..." id ep3_04_challenge_after_19d88932
        show ep3 sat_challenge_286 with d
        dylan "Bro...?" id ep3_04_challenge_after_5ebcd683
        show ep3 sat_challenge_287 with d
        dylan "YES!" id ep3_04_challenge_after_d691fa9a
        dylan "I knew I could count on you, bro!" id ep3_04_challenge_after_f8b25179
        show ep3 sat_challenge_288 with d
        simon "Come on, Dylan. We're done here."

    elif choice_made('ep3_04_challenge_fuck_both'):
        play music to_victory volume 0.2
        show ep3 sat_challenge_289 with white_fade
        dylan "BRO!" id ep3_04_challenge_after_575b061e
        dylan "You passed the test!" id ep3_04_challenge_after_c3c59a4b
        show ep3 sat_challenge_290 with d
        angela "With flying colors, I might add." id ep3_04_challenge_after_f78e47bc
        show ep3 sat_challenge_291 with d
        dylan "Wow! I can't believe it!" id ep3_04_challenge_after_e00f40d9
        show ep3 sat_challenge_292 with d
        dylan "Please teach me, master!" id ep3_04_challenge_after_f24167eb
        show ep3 sat_challenge_293 with d
        simon "Come on, Dylan. We're done here."
        dylan "Nice." id ep3_04_challenge_after_cae67c16

    jump ep3_05_dylan_bike
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
