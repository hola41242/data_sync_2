
label ep3_26_decision:
    show ep3 sat_decision_002 with wiperight
    simon "(Susan's words are stuck in my mind...)" id ep3_26_decision_8eeeed8e
    show ep3 sat_susankitchen2_006 as overlay:
        alpha 0
        ease 0.5 alpha 0.5
    susan "I don't know if the boy would ever forgive us if he found out what we did to his father." (what_italic=True)
    show ep3 sat_susankitchen2_006 as overlay:
        alpha 0.5
        ease 0.5 alpha 0
    show ep3 sat_decision_001 with d
    hide overlay with None
    simon "(And worst of all... they pointed out the biggest culprit in all of this...)" id ep3_26_decision_c5312f39

    show ep3 sat_decision_003 with fast_white_fade
    simon "(Mr. Alderson. Lily's husband.)" id ep3_26_decision_5225b48d
    show ep3 sat_decision_002 with fast_white_fade
    simon "(Lily knew everything. She could have told me.)" id ep3_26_decision_158e95f9
    show ep3 sat_decision_004 with d
    simon "(No. She will tell me.)" id ep3_26_decision_d9d10c71
    show ep3 sat_decision_005 with d
    simon "(She has to.)" id ep3_26_decision_466f87ea
    play sound wood_stairs_up volume 0.5
    show ep3 sat_decision_006 with long_fade
    chloe "[name]?" id ep3_26_decision_18c24156
    chloe "[name], the sun is up." id ep3_26_decision_50e76b94
    chloe "Didn't you get any sleep?" id ep3_26_decision_920c477f
    show ep3 sat_decision_007 with d
    simon "I didn't even notice the time pass!" id ep3_26_decision_53f98a93
    simon "I stayed here thinking about what I was going to do all night..." id ep3_26_decision_e515d79e
    show ep3 sat_decision_008 with d
    chloe "And have you reached a conclusion?" id ep3_26_decision_082a71dd
    show ep3 sat_decision_009 with d
    simon "Yes. I'm going to Lily's house right this second." id ep3_26_decision_4dd39716
    show ep3 sat_decision_010 with d
    chloe "Right now? Are you sure?" id ep3_26_decision_e436ab37


    show ep3 sat_decision_009 with d
    simon "I don't want to put this off one more day." id ep3_26_decision_24443227
    simon "Classes start tomorrow, and I want a fresh start — without all this drama." id ep3_26_decision_f85a6d85
    simon "Today's the last day for me to fix this." id ep3_26_decision_5777594d
    play sound open_drawer volume 0.7
    show ep3 sat_decision_012 with fast_fade
    chloe "Well, if that's the case..." id ep3_26_decision_0ec73194
    show ep3 sat_decision_013 with d
    chloe "I think you should take this." id ep3_26_decision_9bdeab45
    show ep3 sat_decision_014 with d
    chloe "I compiled all the information I've gathered about your father." id ep3_26_decision_8c597084
    chloe "There might be something useful in there that slipped past me." id ep3_26_decision_e6b25d39
    show ep3 sat_decision_015 with d
    simon "Thanks, Chloe."
    show ep3 sat_decision_016 with fade
    chloe "Good luck, [name]!" id ep3_26_decision_bc0edaa2
    play sound door_opening volume 0.7
    show ep3 sat_decision_017 with d
    simon "Oh..." id ep3_26_decision_d3eabd74
    show ep3 sat_decision_018 with d
    simon "How can I even get home from here?" id ep3_26_decision_94931696
    show ep3 sat_decision_019 with d
    chloe "Oh, you can take the bus right over there." id ep3_26_decision_80a089f5
    show ep3 sat_decision_020 with d
    simon "Thanks, Chloe."
    stop music fadeout 6
    show ep3 sat_decision_021 with d
    chloe "And don't forget, stay focused!" id ep3_26_decision_31e8840a

    jump ep3_27_dylanbus
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
