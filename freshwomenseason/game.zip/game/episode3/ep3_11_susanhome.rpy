
label ep3_11_susanhome:
    play music the_chase fadein 3 fadeout 3 volume 0.3
    play sound engine volume 0.7
    show ep3 sat_susanhome_001 with fade
    chloe "We know that Susan is getting ready for a big event next week." (what_italic=True)
    chloe "So she'll certainly be very busy." (what_italic=True)
    show ep3 sat_susanhome_002 with fade
    chloe "The idea is to distract her long enough for us to have a look inside." (what_italic=True)
    show ep3 sat_susanhome_003 with fade
    chloe "That's where Dylan comes in." (what_italic=True)
    chloe "He'll be our air-headed delivery boy, bringing with him a ton of papers for Susan to sign." (what_italic=True)
    show ep3 sat_susanhome_002 with fade
    chloe "Meanwhile, I'll investigate everything using my drone." (what_italic=True)
    simon "Again, are you sure this is legal?" (what_italic=True)
    chloe "If we don't get caught, sure it is." (what_italic=True)
    simon "What?" (what_italic=True)
    chloe "Shhh... Dylan should be getting there by now." (what_italic=True)
    play sound door_bell_ring volume 0.5
    show ep3 sat_susanhome_004 with d
    simon "Oh, he's fast." (what_italic=True)
    show ep3 sat_susanhome_005 with d
    simon "There! Follow her!" (what_italic=True)
    show ep3 sat_susanhome_006 with d
    chloe "What's she doing? Did she invite him in?" (what_italic=True)
    jump ep3_12_van2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
