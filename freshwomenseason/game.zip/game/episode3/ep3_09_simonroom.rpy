
label ep3_09_simonroom:
    play music space_monkeys volume 0.5 fadeout 1.5 fadein 1.5
    show ep3 sat_simonroom_001 with wipeleft
    simon "(Dylan said he'd drop by later.)" id ep3_09_simonroom_5b791a96
    simon "(The more I think about this idea, the less I like it.)" id ep3_09_simonroom_befd3b85
    simon "(But at the same time...)" id ep3_09_simonroom_a48ed412
    show ep3 sat_simonroom_002 with d
    simon "(... I'm not giving up!)" id ep3_09_simonroom_086a3a55
    play sound gloves_leather_on volume 0.5
    show ep3 sat_simonroom_003 with d
    simon "(I'm prepared!)" id ep3_09_simonroom_7a698b32
    play sound dress_shirt_wipe volume 0.5
    show ep3 sat_simonroom_004 with d
    simon "(I'm ready!)" id ep3_09_simonroom_ca16bdf9
    show ep3 sat_simonroom_005 with d
    simon "(I'm equipped! And I...)" id ep3_09_simonroom_11ca8264
    show ep3 sat_simonroom_006 with d
    simon "... I don't have any clean black t-shirts." id ep3_09_simonroom_9300afc7
    play sound cell_phone_vibrate volume 0.1
    show ep3 sat_simonroom_007 with d
    simon "(But such things matter not. Duty calls.)" id ep3_09_simonroom_0eae57da
    stop sound

    jump ep3_10_van
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
