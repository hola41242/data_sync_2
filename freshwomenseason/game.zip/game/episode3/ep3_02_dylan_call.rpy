label ep3_02_dylan_call:
    show black as ep3 with long_fade
    pause 1
    play sound phone_vibrate volume 0.15
    show ep3 sat_home_morning_phone_vibrating with d
    "*Bzzzzt.*"
    show ep3 sat_home_morning_simon_people with d
    simon "What's with people always calling me in the morning?" id ep3_02_dylan_call_7b27ddaa
    play sound phone_vibrate volume 0.15
    "*Bzzzzt.*"
    simon "(Is it Chloe again?)" id ep3_02_dylan_call_80940735
    show ep3 sat_home_morning_simon_hello with d
    simon "Hello?" id ep3_02_dylan_call_c2baa3e3
    show ep3 sat_home_morning_dylan_bro with d
    dylan "Bro! You finally picked up!" (what_italic=True)
    show ep3 sat_home_morning_simon_wokeup with d
    simon "Sorry, dude. I just woke up." id ep3_02_dylan_call_2a398426
    simon "I had a rough night last night." id ep3_02_dylan_call_a29859c3
    show ep3 sat_home_morning_simon_newinfo with d
    simon "How are you?" id ep3_02_dylan_call_ec58805a
    show ep3 sat_home_simon_mouthclosed with d

    dylan "Oh, it's great to hear you had it so rough." (what_italic=True)
    dylan "I'd be sooo happy to join you." (what_italic=True)
    dylan "If I weren't, you know..." (what_italic=True)
    show ep3 sat_home_morning_dylan_jail with fade
    dylan "In jail!" id ep3_02_dylan_call_653652aa
    show ep3 sat_home_morning_simon_whatmean with fade
    simon "What? What do you mean jail?" id ep3_02_dylan_call_f1d7b76d
    simon "What did you do?" id ep3_02_dylan_call_d65142f7
    show ep3 sat_home_morning_dylan_youdid with fade
    dylan "Actually, it's what you did." id ep3_02_dylan_call_10732f81
    dylan "Now you have to come to The Station to bail me out." id ep3_02_dylan_call_dcf7fc2f
    show ep3 sat_home_morning_simon_idid with fade
    simon "Huh?! What did I do?" id ep3_02_dylan_call_2d78eda7
    show ep3 sat_home_morning_simon_station with d
    simon "Hold up, the station?" id ep3_02_dylan_call_4be9b944
    simon "Are you talking about that station?" id ep3_02_dylan_call_9b8fb272
    show ep3 sat_home_morning_dylan_yeah with fade
    dylan "Yeah." id ep3_02_dylan_call_5fd556a0
    dylan "I thought you'd already have that part figured out." id ep3_02_dylan_call_1a64ef4b
    dylan "I'm waiting for you." id ep3_02_dylan_call_1df7f086
    stop music fadeout 2
    show ep3 sat_home_morning_simon_damnit with fade
    simon "Goddammit." id ep3_02_dylan_call_66f035a4

    jump ep3_03_back_to_the_station
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
