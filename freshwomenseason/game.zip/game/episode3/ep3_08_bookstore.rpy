
label ep3_08_bookstore:
    play music new_again fadein 2 volume 0.3
    show ep3 sat_bookstore_001 with fade
    simon "You can't go around telling everyone there's a bear on the loose!" id ep3_08_bookstore_718536b0
    show ep3 sat_bookstore_002 with d
    simon "But, uh, did you actually see the bear?" id ep3_08_bookstore_e8fb803c
    show ep3 sat_bookstore_003 with d
    dylan "Nope, no sign of it." id ep3_08_bookstore_daeb4ff6
    dylan "I actually just remembered that event going on at the bookstore today." id ep3_08_bookstore_a9df57d1
    dylan "I'm glad I remembered it before driving off." id ep3_08_bookstore_658cac36
    show ep3 sat_bookstore_004 with d
    dylan "Chloe should be there too if you haven't talked to her already." id ep3_08_bookstore_bc48e19b
    show ep3 sat_bookstore_005 with d
    dylan "Oh, speak of the devil." id ep3_08_bookstore_55ddf9cb
    show ep3 sat_bookstore_005_1 with d
    pause
    show ep3 sat_bookstore_006 with d
    simon "What's she doing all by herself over there?" id ep3_08_bookstore_079a601a
    show ep3 sat_bookstore_006_1 with d
    dylan "Did something bad happen?" id ep3_08_bookstore_90910810
    show ep3 sat_bookstore_007 with d
    simon "Let's head over." id ep3_08_bookstore_49e1f9e6
    show ep3 sat_bookstore_008 with wipeleft
    dylan "Hello, Chloe!" (what_bold=True)
    show ep3 sat_bookstore_009 with d
    chloe "Oh. Hi, guys." id ep3_08_bookstore_71b56923
    show ep3 sat_bookstore_010 with d
    simon "Is everything okay, Chloe?" id ep3_08_bookstore_5120e3fb
    show ep3 sat_bookstore_011 with d
    chloe "Yeah, yeah. Everything's fine." id ep3_08_bookstore_9c58dcfd
    show ep3 sat_bookstore_012 with d
    simon "What happened? Didn't get that autograph you wanted?" id ep3_08_bookstore_e475f8e8
    show ep3 sat_bookstore_013 with d
    chloe "I did. The problem is, it's going to be my last one." id ep3_08_bookstore_ced55fee
    show ep3 sat_bookstore_010 with d
    simon "How so?" id ep3_08_bookstore_58bb722e
    show ep3 sat_bookstore_013 with d
    chloe "The author used the event as his opportunity to announce that he's going to retire." id ep3_08_bookstore_b09189ec
    chloe "I really liked his mystery series. And now it's over." id ep3_08_bookstore_e01bc2a3
    show ep3 sat_bookstore_014 with d
    dylan "So your favorite mystery series is finished? How about you write your own mystery story?" (what_bold=True)
    show ep3 sat_bookstore_015 with d
    chloe "Me? A writer? Hmm..." id ep3_08_bookstore_79cfee66
    chloe "I can't say the thought has never crossed my mind, but..." id ep3_08_bookstore_165bde28
    show ep3 sat_bookstore_016 with d
    chloe "What do you think, [name]?" id ep3_08_bookstore_7060981b

    menu:
        "Sounds good to me"(True):
            $ ep3_08_bookstore_good_idea = True
            $ points_chloe += 1
            $ player_choice("ep3_08_bookstore_good_idea:true")
            show ep3 sat_bookstore_017 with d
            simon "I think that's a great idea!" id ep3_08_bookstore_91a40c52
            simon "You already have a huge passion for books, so I imagine you'd make a great writer!" id ep3_08_bookstore_61581dc6
            show ep3 sat_bookstore_018 with d
            dylan "I agree! You should write a thriller about a Russian spy!" (what_bold=True)
            show ep3 sat_bookstore_019 with d
            simon "Yeah... Or, you know, literally anything else..." id ep3_08_bookstore_28e13c97
            show ep3 sat_bookstore_020 with d
            chloe "Definitely something else!" id ep3_08_bookstore_dc126f93
            chloe "But I'll keep your idea in mind, Dylan." id ep3_08_bookstore_2b0decd8
        "Bad idea":

            $ ep3_08_bookstore_bad_ideia = True
            $ player_choice("ep3_08_bookstore_bad_ideia:true")
            show ep3 sat_bookstore_021 with d
            simon "That might not be the best idea." id ep3_08_bookstore_0a5f98a9
            simon "Becoming a writer is really difficult, and it doesn't pay well unless you get famous." id ep3_08_bookstore_6d790f9b
            show ep3 sat_bookstore_022 with d
            chloe "You're right. I don't think I'd do very well as a writer." id ep3_08_bookstore_e4f47a0d
            show ep3 sat_bookstore_023 with d
            dylan "(Bro...)" id ep3_08_bookstore_489409fc

    show ep3 sat_bookstore_024 with d
    dylan "Anyway, whether you decide to become a writer or not, you can always live out your own adventures." (what_bold=True)
    show ep3 sat_bookstore_025 with d
    simon "Mysteries are all around us." id ep3_08_bookstore_877d1600
    show ep3 sat_bookstore_026 with d
    chloe "I already know one mystery we can investigate." id ep3_08_bookstore_a34a6b6f
    show ep3 sat_bookstore_027 with d
    dylan "That's right! You went to your boss's house the other day, didn't you?" (what_bold=True)
    show ep3 sat_bookstore_028 with d
    simon "No way I'm heading back there!" id ep3_08_bookstore_484ab0da
    show ep3 sat_bookstore_029 with d
    dylan "Then how about surveilling the place from afar?" (what_bold=True)
    dylan "You wouldn't be opposed to that, would you?" (what_bold=True)
    show ep3 sat_bookstore_030 with d
    simon "I, uh... What?" id ep3_08_bookstore_88a06008
    show ep3 sat_bookstore_031 with d
    chloe "Are you talking about doing something like a police stakeout?" id ep3_08_bookstore_8d21a2b6
    chloe "I could bring my binoculars and notebook along!" id ep3_08_bookstore_9de57975
    show ep3 sat_bookstore_032 with d
    chloe "If we did it under the cover of night, we could use the shadows and be practically invisible." id ep3_08_bookstore_1183bfeb
    chloe "Of course, a black car would be ideal in that case." id ep3_08_bookstore_9874b743
    show ep3 sat_bookstore_033 with d
    pause
    show ep3 sat_bookstore_034 with d
    simon "How do you know all of that?" id ep3_08_bookstore_dd66e688
    show ep3 sat_bookstore_035 with d
    chloe "We could observe her from afar, watch her every move." id ep3_08_bookstore_3604deea
    chloe "Maybe throw on some black clothes like burglars and..." id ep3_08_bookstore_5700b659
    show ep3 sat_bookstore_036 with d
    dylan "Um... Chloe?" (what_bold=True)
    show ep3 sat_bookstore_037 with d
    chloe "Oh! Looks like I got carried away!" id ep3_08_bookstore_58e4dbff
    show ep3 sat_bookstore_038 with d
    simon "(Seemed like more than getting carried away...)" id ep3_08_bookstore_242ce97d
    show ep3 sat_bookstore_039 with d
    simon "(... That was beyond normal excitement.)" id ep3_08_bookstore_e0b2f4d2
    simon "(I thought Chloe, of all people, would be against the idea.)" id ep3_08_bookstore_8dac3a08
    show ep3 sat_bookstore_040 with d
    simon "Isn't that kind of... illegal?" id ep3_08_bookstore_01bbb1f7
    show ep3 sat_bookstore_041 with d
    chloe "Not necessarily. In theory, we'd just be hanging out near her house." id ep3_08_bookstore_9c77724a
    show ep3 sat_bookstore_040 with d
    simon "What are you hoping to find there anyway?" id ep3_08_bookstore_5573404c
    show ep3 sat_bookstore_041 with d
    chloe "I don't know..." id ep3_08_bookstore_a2ff9bd7
    show ep3 sat_bookstore_042 with d
    chloe "But I think I really need this." id ep3_08_bookstore_75598e2c
    show ep3 sat_bookstore_043 with d
    simon "(I think her excitement has a reason behind it.)" id ep3_08_bookstore_33341488
    simon "(It looks like she really gets into these mysteries.)" id ep3_08_bookstore_bf2120eb
    show ep3 sat_bookstore_044 with d
    simon "Fine. I'm in. But let's just have a quick look around and then get out of there." id ep3_08_bookstore_86303825
    show ep3 sat_bookstore_045 with d
    chloe "Deal!" id ep3_08_bookstore_d7fbf2fd
    show ep3 sat_bookstore_046 with d
    dylan "I told you hanging out with me would be an adventure." (what_bold=True)

    jump ep3_09_simonroom
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
