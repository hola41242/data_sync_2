
label ep3_24_chloesex:

play sound wood_stairs_up volume 0.7
show ep3 sat_chloesex_001_2 with fade
chloe "I'm just going to get a few things from my room and change into something more comfortable." id ep3_24_chloesex_2d854d02
simon "Right! Of course." id ep3_24_chloesex_39316206
show ep3 sat_chloesex_002 with d
stop sound
simon "Huh?"
show ep3 sat_chloesex_003 with d
simon "Oh! Did you record all that?" id ep3_24_chloesex_74200b30
simon "What a good idea. Now we can review the tape later." id ep3_24_chloesex_89ec2004
play sound door_closet_close volume 0.7

show ep3 sat_chloesex_004 with fade
simon "Oh..." id ep3_24_chloesex_d3eabd74
show ep3 sat_chloesex_005 with d
simon "(Focus, [name]. She's just a friend.)" id ep3_24_chloesex_9c59a862
show ep3 sat_chloesex_006 with d
simon "(Also, she's into women.)" id ep3_24_chloesex_c59fd676
show ep3 sat_chloesex_007 with d
chloe "[name]... I think there's something we need to talk about." id ep3_24_chloesex_98516979
play sound bed_movement_1 volume 0.7
show ep3 sat_chloesex_008 with d
chloe "Have a seat." id ep3_24_chloesex_02d07a6e
play sound bed_movement_5 volume 0.3
show ep3 sat_chloesex_009 with d
chloe "About the video..." id ep3_24_chloesex_e8b5d98b
show ep3 sat_chloesex_010 with d
chloe "I want to apologize." id ep3_24_chloesex_bb73d7b3
show ep3 sat_chloesex_011 with d
simon "Right, what was that all about?" id ep3_24_chloesex_a0be5ce3
show ep3 sat_chloesex_012 with d
chloe "It's a bit embarrassing to admit, but I like to watch people..." id ep3_24_chloesex_934b0232
show ep3 sat_chloesex_013 with d
chloe "... during their..." id ep3_24_chloesex_11d5fc7a
show ep3 sat_chloesex_014 with d
chloe "... most intimate moments." id ep3_24_chloesex_69249fb7
show ep3 sat_chloesex_015 with d
simon "Wow, Chloe, that's kind of —" id ep3_24_chloesex_51b70b0d
play sound chair_fabric_5 volume 0.3
show ep3 sat_chloesex_016 with d
chloe "I know! It's wrong! But I like watching people." id ep3_24_chloesex_f45c2a67
show ep3 sat_chloesex_017 with d
chloe "I try to control myself, but..." id ep3_24_chloesex_3f99c868
show ep3 sat_chloesex_018 with d
stop music fadeout 4
chloe "... I like to watch." id ep3_24_chloesex_c98e58ef
show ep3 sat_chloesex_019 with d
simon "(What?! What's going on? Is she hitting on me? Isn't she a lesbian?)" id ep3_24_chloesex_a812bfbc
simon "(What should I do?)" id ep3_24_chloesex_c5590488

menu:
    "Let her keep going"(True) if config.developer or _in_replay or chose('points_chloe', 8):
        label ep3_24_chloesex_keepgoing:
        $ ep3_sat_chloesex_continue = True
        $ player_choice("ep3_sat_chloesex_continue:true")
        show ep3 sat_chloesex_020 with d
        simon "Well..." id ep3_24_chloesex_keepgoing_9bf3b23a
        simon "... I like watching too." id ep3_24_chloesex_keepgoing_7f940943
        play music the_mirror fadein 1 volume 0.5
        show ep3 sat_chloesex_021 with d
        chloe "Oh! I knew you'd get me!" id ep3_24_chloesex_keepgoing_a259d3bd
        show ep3 sat_chloesex_022 with d
        simon "But, wait, didn't you say you're into women?" id ep3_24_chloesex_keepgoing_ce7ebdba
        show ep3 sat_chloesex_023 with d
        chloe "Of course I am! But I'm into men as well!" id ep3_24_chloesex_keepgoing_3926d2b4
        show ep3 sat_chloesex_024 with d
        chloe "I don't care too much about the equipment they're packing..."
        show ep3 sat_chloesex_025 with d
        chloe "As long as I can watch..." id ep3_24_chloesex_keepgoing_35690c2d
        show ep3 sat_chloesex_026 with d
        chloe "... and be watched." id ep3_24_chloesex_keepgoing_eee11f27
        show ep3 sat_chloesex_027 with d
        chloe "I saw the way you looked at me." id ep3_24_chloesex_keepgoing_a27e5195
        show ep3 sat_chloesex_028 with d
        chloe "I know I'm no Lily or Susan. But still..." id ep3_24_chloesex_keepgoing_572ea6bf
        show ep3 sat_chloesex_029 with d
        chloe "Will you watch me, [name]?" id ep3_24_chloesex_keepgoing_92d09ee4
        show ep3 sat_chloesex_030 with d
        simon "Of course I'll watch you, Chloe." id ep3_24_chloesex_keepgoing_9fd6282d
        simon "I've been watching this whole time." id ep3_24_chloesex_keepgoing_89c6f85a
        show ep3 sat_chloesex_029 with d
        chloe "Really? This isn't weird for you?" id ep3_24_chloesex_keepgoing_b1cf8123
        play sound bed_movement_1 volume 0.7
        show ep3 sat_chloesex_031 with d
        simon "You can show me everything." id ep3_24_chloesex_keepgoing_1455f166
        show ep3 sat_chloesex_032 with d
        simon "Show me your most intimate moments." id ep3_24_chloesex_keepgoing_cb45a358
        show ep3 sat_chloesex_033 with d
        chloe "You know how nice it is to feel..." id ep3_24_chloesex_keepgoing_5456f224
        play sound jeans_off_2 volume 0.5
        show ep3 sat_chloesex_034 with d
        chloe "... accepted." id ep3_24_chloesex_keepgoing_ef481666
        show ep3 sat_chloesex_035 with d
        simon "(Wow...)" id ep3_24_chloesex_keepgoing_943b1370
        play sound panties_off_1 volume 0.4
        show ep3 sat_chloesex_036 with d
        simon "(She's so...)" id ep3_24_chloesex_keepgoing_96bdd0dc
        show ep3 anim_sat_chloesex_037 with d




        simon "Gorgeous..." id ep3_24_chloesex_keepgoing_79bf3988
        show ep3 sat_chloesex_038 with d
        chloe "Do you really think so?" id ep3_24_chloesex_keepgoing_a7473209
        show ep3 sat_chloesex_039 with d
        simon "Of course I do." id ep3_24_chloesex_keepgoing_2b5e4b29
        simon "And I want to see more." id ep3_24_chloesex_keepgoing_48110ede
        show ep3 sat_chloesex_040 with d
        chloe "Yes! That's exactly what I was hoping for!" id ep3_24_chloesex_keepgoing_57f0e75b
        show ep3 sat_chloesex_041 with d
        chloe "And since that's the case, you won't mind if I do this..." id ep3_24_chloesex_keepgoing_dbaa14f3
        show ep3 sat_chloesex_042 with d
        chloe "Ahhh..." id ep3_24_chloesex_keepgoing_02e90411
        show ep3 sat_chloesex_043 with d
        chloe "I want you to watch me in my most intimate of moments..." id ep3_24_chloesex_keepgoing_fc1e55b7

        show ep3 sat_chloesex_044 with d
        chloe "Ahhhhhh!" id ep3_24_chloesex_keepgoing_d8b12cea
        show ep3 sat_chloesex_045 with d
        chloe "Mmmmm..." id ep3_24_chloesex_keepgoing_8e121a48
        show ep3 sat_chloesex_046 with d
        chloe "Ah... This is so inappropriate... I feel so... dirty!" id ep3_24_chloesex_keepgoing_de788a15
        play sound bed_sit_down volume 0.3
        show ep3 sat_chloesex_047 with d
        simon "So that's what you're into." id ep3_24_chloesex_keepgoing_e14f1e7f
        show ep3 sat_chloesex_048 with d
        chloe "It feels so good to be watched." id ep3_24_chloesex_keepgoing_9ae173fa
        chloe "Knowing that at any moment someone could catch us." id ep3_24_chloesex_keepgoing_dde0f31a
        chloe "By the way..." id ep3_24_chloesex_keepgoing_0310ee72
        show ep3 sat_chloesex_049 with d
        chloe "... I lied about my parents being out of town." id ep3_24_chloesex_keepgoing_91596bbe
        show ep3 sat_chloesex_050 with d
        chloe "They could be back any minute." id ep3_24_chloesex_keepgoing_1f490eb3
        simon "What?!" id ep3_24_chloesex_keepgoing_6c871165
        show ep3 sat_chloesex_049 with d
        chloe "Isn't it more exciting that way?" id ep3_24_chloesex_keepgoing_3f072934
        chloe "Knowing they might barge in with no warning at all?" id ep3_24_chloesex_keepgoing_7e36d7f5
        play sound panties_off_1 volume 0.5
        show ep3 sat_chloesex_051 with d
        chloe "You should take off your clothes too." id ep3_24_chloesex_keepgoing_3f5ceeac
        chloe "That way, the two of us are taking the risk together!" id ep3_24_chloesex_keepgoing_84e36722

        menu:
            "Remove clothes"(True):
                $ ep3_sat_chloesex_remove_clothes = True
                $ player_choice("ep3_sat_chloesex_remove_clothes:true")
                simon "It's risky, but okay." id ep3_24_chloesex_keepgoing_40e24b8e
                play sound jeans_off_2 volume 0.5
                show ep3 sat_chloesex_052 with d
                chloe "Excellent!" id ep3_24_chloesex_keepgoing_49a1a08d
                simon "What the...?!" id ep3_24_chloesex_keepgoing_1193c200
                play sound shirtoff3 volume 0.5
                show ep3 sat_chloesex_053 with d
                simon "(Wow! She's a completely different person when she's horny!)" id ep3_24_chloesex_keepgoing_5a693713
                simon "(Who would have thought that the girl from the library would be so kinky?!)" id ep3_24_chloesex_keepgoing_0b75b266
                show ep3 sat_chloesex_054 with d
                chloe "Wow! You have a gorgeous body to take in!" id ep3_24_chloesex_keepgoing_87350ec1
                show ep3 sat_chloesex_055 with d
                chloe "Ahhh... It makes me even more turned on!" id ep3_24_chloesex_keepgoing_f30b5fae
                show ep3 sat_chloesex_056 with d
                simon "I can help with that." id ep3_24_chloesex_keepgoing_caed9d4b
                show ep3 sat_chloesex_057 with d
                chloe "Not yet." id ep3_24_chloesex_keepgoing_038a440f
                chloe "I want to show you more." id ep3_24_chloesex_keepgoing_b845f068
                play sound chair_fabric_5 volume 0.3
                show ep3 sat_chloesex_058 with d
                simon "What are you doing?" id ep3_24_chloesex_keepgoing_b9cba79e
                show ep3 sat_chloesex_059 with d
                chloe "But like I said..." id ep3_24_chloesex_keepgoing_9ace6243
                play sound bed_sit_down volume 0.6
                show ep3 sat_chloesex_060 with hpunch
                chloe "... I like watching and being watched." id ep3_24_chloesex_keepgoing_da44a694
                show ep3 sat_chloesex_061 with d
                chloe "I want to see you in an intimate moment too." id ep3_24_chloesex_keepgoing_e5a198f8
                chloe "I want to watch you play with yourself." id ep3_24_chloesex_keepgoing_fefbf506

                show ep3 sat_chloesex_062 with d
                chloe "But don't worry, I'll be doing the same." id ep3_24_chloesex_keepgoing_b395790a
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_063_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_063_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_063 with d
                simon "Well, in that case..." id ep3_24_chloesex_keepgoing_b19bf3dc
                pause
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_064_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_064_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_064 with d
                chloe "Ahhh... It's better than I ever could have imagined." id ep3_24_chloesex_keepgoing_6e49c9be
                pause

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_063_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_063_var1_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_063_var1 with d
                simon "So this is the kind of thing you fantasize about?" id ep3_24_chloesex_keepgoing_760e9165
                pause
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_063_var2_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_063_var2_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_063_var2 with d
                chloe "Yes..." id ep3_24_chloesex_keepgoing_a5196002
                pause
                stop foley
                stop voicefx
                show ep3 sat_chloesex_066 with d
                chloe "It's so wrong, isn't it?" id ep3_24_chloesex_keepgoing_70aa040d
                show ep3 sat_chloesex_067 with d
                chloe "You must be thinking..." id ep3_24_chloesex_keepgoing_6783cb81


                show ep3 sat_chloesex_068 with d
                chloe "... I'm one hell of a..." id ep3_24_chloesex_keepgoing_8904de1b
                show ep3 sat_chloesex_069 with d
                chloe "... pervert." id ep3_24_chloesex_keepgoing_cdeba67e
                show ep3 sat_chloesex_070 with d
                simon "Sure do." id ep3_24_chloesex_keepgoing_30996514
                show ep3 sat_chloesex_071 with d
                chloe "Oh, yes..." id ep3_24_chloesex_keepgoing_0ee98705
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_064_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_064_var1_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_064_var1 with d
                chloe "Mmmmmmm... Yes!" id ep3_24_chloesex_keepgoing_27ae30d3
                pause
                stop foley
                stop voicefx
                show ep3 sat_chloesex_073 with hpunch
                chloe "Aaaaahhhhhhhh!" id ep3_24_chloesex_keepgoing_7ac7fee0

                show ep3 sat_chloesex_074 with d
                simon "Chloe? Are you okay?" id ep3_24_chloesex_keepgoing_ea426897
                show ep3 sat_chloesex_075 with hpunch
                simon "Huh?"
                chloe "Thanks for watching me!" id ep3_24_chloesex_keepgoing_a5c07541
                chloe "And for showing off at the same time." id ep3_24_chloesex_keepgoing_ccfa424e
                show ep3 sat_chloesex_076 with d
                simon "It was... a little out of the ordinary, but if you're happy..." id ep3_24_chloesex_keepgoing_980435fa
                show ep3 sat_chloesex_077 with d
                chloe "We're not done yet." id ep3_24_chloesex_keepgoing_18bb7a7d
                show ep3 sat_chloesex_078 with d
                simon "Oh... Now things are heating up." id ep3_24_chloesex_keepgoing_f46ab883
                show ep3 sat_chloesex_079 with d
                chloe "I'm so wet. Feel free to shove it all in at once." id ep3_24_chloesex_keepgoing_98c1ff49
                simon "Are you sure?" id ep3_24_chloesex_keepgoing_4b1d3f09
                show ep3 sat_chloesex_080 with d
                chloe "Trust me." id ep3_24_chloesex_keepgoing_6b781f10
                show ep3 sat_chloesex_079 with d
                simon "If you say so..." id ep3_24_chloesex_keepgoing_f2043623

                show ep3 sat_chloesex_081 with d
                chloe "Aaaaaahhh!"
                show ep3 sat_chloesex_082 with d
                chloe "That felt amazing..." id ep3_24_chloesex_keepgoing_aef33050
                show ep3 sat_chloesex_083 with d
                simon "Are you sure it's not too much?" id ep3_24_chloesex_keepgoing_ccdae144
                show ep3 sat_chloesex_084 with d
                chloe "It's great! Keep going!" id ep3_24_chloesex_keepgoing_108ed023
                show ep3 sat_chloesex_085 with d
                simon "(She really is dripping wet. My dick slid right in.)" id ep3_24_chloesex_keepgoing_4d7f3866

                show ep3 sat_chloesex_086 with d
                simon "(But still, I feel a certain amount of friction when I bury myself in her.)" id ep3_24_chloesex_keepgoing_01a887ef
                simon "(She's just so tight!)" id ep3_24_chloesex_keepgoing_463c104f
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_088_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_088_var1_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_088_var1 with d
                simon "(Yet so delicate... Who would have thought she'd be like this?)" id ep3_24_chloesex_keepgoing_662a88df
                pause
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_088_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_088_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_088 with d
                simon "(This petite body of hers hides secrets.)" id ep3_24_chloesex_keepgoing_8a81087b
                pause
                stop foley
                stop voicefx
                show ep3 sat_chloesex_089 with d
                simon "(Maybe I should get her into bed and start unraveling them.)" id ep3_24_chloesex_keepgoing_f41c536c
                play sound bed_sit_down volume 0.7
                show ep3 sat_chloesex_090 with d
                chloe "Ahh... What a good idea!" id ep3_24_chloesex_keepgoing_13aa9f7b
                chloe "But I think you'll like my ideas a bit more..." id ep3_24_chloesex_keepgoing_33f62642
                show ep3 sat_chloesex_091 with d

                show ep3 sat_chloesex_092_1 with d
                show ep3 sat_chloesex_092_2 with d
                show ep3 sat_chloesex_092 with d
                simon "Holy shit!" id ep3_24_chloesex_keepgoing_28fd9cf8
                show ep3 sat_chloesex_093 with d
                simon "How?!" id ep3_24_chloesex_keepgoing_35650580
                simon "(I was still inside her when she did that!)" id ep3_24_chloesex_keepgoing_b8a3fe98
                simon "(I could feel her pussy twisting around my cock!)" id ep3_24_chloesex_keepgoing_eacd0f07
                show ep3 sat_chloesex_092 with d
                simon "(What an amazing feeling!)" id ep3_24_chloesex_keepgoing_c8bb96df
                show ep3 sat_chloesex_094 with d
                chloe "So, is this better?" id ep3_24_chloesex_keepgoing_b5028156
                show ep3 sat_chloesex_095 with d
                simon "I didn't know that kind of move was even possible!" id ep3_24_chloesex_keepgoing_522d2460
                show ep3 sat_chloesex_094 with d
                chloe "Oh, that...?" id ep3_24_chloesex_keepgoing_754155eb
                show ep3 sat_chloesex_096 with d
                chloe "I was thinking about..." id ep3_24_chloesex_keepgoing_6ae6e29b
                show ep3 sat_chloesex_097 with d
                chloe "... how you're going to see me now." id ep3_24_chloesex_keepgoing_c8c0d50f

                show ep3 sat_chloesex_098 with vpunch
                simon "(MY GOD!)" id ep3_24_chloesex_keepgoing_1aa145d7
                simon "Aaaaahhh!" id ep3_24_chloesex_keepgoing_3ac127a4
                show ep3 sat_chloesex_099 with d
                chloe "Aaaaaahhh!"
                show ep3 sat_chloesex_100 with d
                chloe "(I think this time, it might have been too much...)" id ep3_24_chloesex_keepgoing_29130e8a
                chloe "(But it was worth it!)" id ep3_24_chloesex_keepgoing_f43932d4
                simon "Wow, you almost got me with that..." id ep3_24_chloesex_keepgoing_801315a9

                show ep3 sat_chloesex_101 with d

                show ep3 sat_chloesex_102_1 with d
                show ep3 sat_chloesex_102_2 with d
                show ep3 sat_chloesex_102 with d
                chloe "Really?!" id ep3_24_chloesex_keepgoing_4736f977
                simon "(She did it again!)" id ep3_24_chloesex_keepgoing_36c58883
                chloe "Are you almost there?" id ep3_24_chloesex_keepgoing_60a339e9
                show ep3 sat_chloesex_103 with d
                chloe "I think I can help you finish..." id ep3_24_chloesex_keepgoing_52cf9fe6
                show ep3 sat_chloesex_104 with d
                simon "Oh yeah? What do you have in mind?" id ep3_24_chloesex_keepgoing_ab6a0af8
                show ep3 sat_chloesex_103 with d
                chloe "Nothing..." id ep3_24_chloesex_keepgoing_e28111f4
                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_105_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_105_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_105 with d
                chloe "I just thought about staying here on top of you, wiggling my ass until you came." id ep3_24_chloesex_keepgoing_99a9cad6

                if choice_made('ep2_dictionarygirl'):
                    simon "Looks like Dictionary Girl has been looking up some adult words..." id ep3_24_chloesex_keepgoing_ddae87f9
                else:

                    simon "Good choice of words..." id ep3_24_chloesex_keepgoing_c0b76b2e
                pause
                stop foley
                stop voicefx
                show ep3 sat_chloesex_106 with d
                chloe "It's not something I would normally say..." id ep3_24_chloesex_keepgoing_713fcee5
                chloe "But you know how people are. They act differently when they're not being watched." id ep3_24_chloesex_keepgoing_ab5a8e87
                show ep3 sat_chloesex_107 with d
                simon "But I'm watching you." id ep3_24_chloesex_keepgoing_b1656db4
                show ep3 sat_chloesex_106 with d
                chloe "I'm letting you watch me! So I can act however I want." id ep3_24_chloesex_keepgoing_bc0f1508
                show ep3 sat_chloesex_108 with d
                chloe "Now... Back to business..." id ep3_24_chloesex_keepgoing_67530017
                show ep3 sat_chloesex_109 with d
                chloe "I want you to finish..." id ep3_24_chloesex_keepgoing_3a0d75d8
                show ep3 sat_chloesex_110 with vpunch
                chloe "... inside me!" id ep3_24_chloesex_keepgoing_9ceaae04
                show ep3 sat_chloesex_111 with d
                chloe "Please... It's the last thing I'm going to ask you to do tonight!" id ep3_24_chloesex_keepgoing_fff5784a

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_112_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_112_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_112 with d
                chloe "Cum inside me, [name]!" id ep3_24_chloesex_keepgoing_7820e40e
                pause

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_105_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_105_var1_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_105_var1 with d
                simon "(How could I say no to a request like that?!)" id ep3_24_chloesex_keepgoing_6f820d07
                pause

                stop foley
                stop voicefx
                show ep3 sat_chloesex_114 with d
                simon "Okay, Chloe, I'll give it to you..." id ep3_24_chloesex_keepgoing_3a66e10a
                show ep3 sat_chloesex_113 with vpunch
                simon "OH MY...!" id ep3_24_chloesex_keepgoing_6877cffd

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_112_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_112_var1_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_112_var1 with d
                simon "I'm going to..." id ep3_24_chloesex_keepgoing_7445a2e2
                pause

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_112_var1_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_112_var2_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_112_var2 with d
                simon "Chloe..." id ep3_24_chloesex_keepgoing_58d95bc8
                pause

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_112_var3_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_112_var3_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_112_var3 with d
                simon "I can't hold on..." id ep3_24_chloesex_keepgoing_27f455e1
                pause

                $ allow_voicefx = False
                if is_voice_installed:
                    play voicefx ep3_anim_sat_chloesex_112_var5_voicefx fadein 0.5 fadeout 0.5
                    play foley ep3_anim_sat_chloesex_112_var5_foley fadein 0.5 fadeout 0.5
                show ep3 anim_sat_chloesex_112_var5 with d
                chloe "Hmm?" id ep3_24_chloesex_keepgoing_e29dae51
                pause

                stop foley
                stop voicefx
                show ep3 sat_chloesex_115 with d
                simon "(My cock is throbbing! I can't hold back anymore!)" id ep3_24_chloesex_keepgoing_0291c612
                chloe "Time to give it to me." id ep3_24_chloesex_keepgoing_22f95929
                show ep3 sat_chloesex_116 with vpunch
                pause 0.5
                show ep3 sat_chloesex_116 with vpunch
                pause 0.5
                show ep3 sat_chloesex_116 with vpunch
                simon "AAAAAAHHH!" id ep3_24_chloesex_keepgoing_47affe5c

                show ep3 sat_chloesex_117 with d
                chloe "Mmmmmmm..." id ep3_24_chloesex_keepgoing_07cc3637
                simon "Ahhh... Wow..." id ep3_24_chloesex_keepgoing_70d7a6c3
                chloe "Whoa, you made quite the mess there..." id ep3_24_chloesex_keepgoing_a26a0dd3
                chloe "Delectable..." id ep3_24_chloesex_keepgoing_7d8c53e0
                play sound bed_movement_1 volume 0.5
                show ep3 sat_chloesex_118 with d
                simon "Phew..." id ep3_24_chloesex_keepgoing_5e67d213
                show ep3 sat_chloesex_119 with d
                simon "Glad we finished before your parents arrived." id ep3_24_chloesex_keepgoing_cddb9313
                show ep3 sat_chloesex_120 with d
                chloe "Oh, right... About that..." id ep3_24_chloesex_keepgoing_16d69a38
                show ep3 sat_chloesex_121 with d
                chloe "They really are out of town and not coming back tonight." id ep3_24_chloesex_keepgoing_bccccc6c
                chloe "I just said that to make things more interesting." id ep3_24_chloesex_keepgoing_0cb3dcb2
                show ep3 sat_chloesex_122 with d
                simon "So you lied?" id ep3_24_chloesex_keepgoing_a4a11500
                show ep3 sat_chloesex_121 with d
                chloe "I wouldn't say I lied exactly." id ep3_24_chloesex_keepgoing_0ad0ad9b
                show ep3 sat_chloesex_123 with d
                chloe "I just told a story to get us both into character." id ep3_24_chloesex_keepgoing_623c2d1d
                show ep3 sat_chloesex_124 with d
                simon "We got into character...?" id ep3_24_chloesex_keepgoing_9770902a
                simon "(I think she's still seeing things like they're happening in books.)" id ep3_24_chloesex_keepgoing_080229c3
                show ep3 sat_chloesex_125 with d
                chloe "Well, I'm going to take a shower and freshen up." id ep3_24_chloesex_keepgoing_1f04fcc7
                chloe "Make yourself comfortable until I get back." id ep3_24_chloesex_keepgoing_1eb06c7d
                $ renpy.end_replay()

            "Stop that" if not _in_replay:
                $ ep3_sat_chloesex_stop_that = True
                $ player_choice("ep3_sat_chloesex_stop_that:true")
                stop music fadeout 5
                show ep3 sat_chloesex_126 with d
                simon "Okay, Chloe, let's take it easy..." id ep3_24_chloesex_keepgoing_e4f08def
                simon "Are your parents really coming back?" id ep3_24_chloesex_keepgoing_33778069
                show ep3 sat_chloesex_127 with d
                chloe "Yes! Doesn't that make this so exciting?" id ep3_24_chloesex_keepgoing_62fbbfd3
                show ep3 sat_chloesex_128 with d
                simon "How's that exciting?! We can't do this if they are!" id ep3_24_chloesex_keepgoing_b6683357
                show ep3 sat_chloesex_129 with d
                simon "What if they catch you like this?" id ep3_24_chloesex_keepgoing_ef5402ee
                simon "Your father would kill me!" id ep3_24_chloesex_keepgoing_604c717b
                show ep3 sat_chloesex_130 with d
                simon "Come on. You have to get dressed and..." id ep3_24_chloesex_keepgoing_2034e201
                show ep3 sat_chloesex_131 with d
                simon "How are you so calm?" id ep3_24_chloesex_keepgoing_98d9577d
                show ep3 sat_chloesex_132 with d
                chloe "It wasn't true, [name]." id ep3_24_chloesex_keepgoing_e3e1dc38
                simon "What?" id ep3_24_chloesex_keepgoing_708b4972
                show ep3 sat_chloesex_133 with d
                chloe "My parents aren't coming back tonight." id ep3_24_chloesex_keepgoing_37b33920
                chloe "I only said that to make this more interesting." id ep3_24_chloesex_keepgoing_4c34ab82
                show ep3 sat_chloesex_134 with d
                chloe "But it looks like I was wrong about you." id ep3_24_chloesex_keepgoing_171b15c7
                show ep3 sat_chloesex_135 with d
                chloe "Let's pretend this never happened, okay?" id ep3_24_chloesex_keepgoing_c7950c2c
                show ep3 sat_chloesex_136 with d
                simon "(She lied...)" id ep3_24_chloesex_keepgoing_4b78844e
                simon "(I could have... Oh well.)" id ep3_24_chloesex_keepgoing_3035b734
                $ renpy.end_replay()



    "Stop her" if not _in_replay:
        $ ep3_sat_chloesex_stop_her = True
        $ player_choice("ep3_sat_chloesex_stop_her:true")
        show ep3 sat_chloesex_137 with d
        simon "Look, Chloe... I think you're amazing..." id ep3_24_chloesex_keepgoing_e9cce382
        show ep3 sat_chloesex_138 with d
        simon "... But I don't really know what's going on here..." id ep3_24_chloesex_keepgoing_42a07203
        simon "And honestly, I'm not in the right mood for any of it." id ep3_24_chloesex_keepgoing_cf24cbcf
        simon "I hope you understand." id ep3_24_chloesex_keepgoing_ec0826b8
        show ep3 sat_chloesex_139 with d
        chloe "Of course. I shouldn't have said those things." id ep3_24_chloesex_keepgoing_0ec3216b
        chloe "There must be a lot on your mind right now." id ep3_24_chloesex_keepgoing_7a7add62
        show ep3 sat_chloesex_140 with d
        simon "Thank you for understanding." id ep3_24_chloesex_keepgoing_29614714
        show ep3 sat_chloesex_141 with d
        chloe "I'll go freshen up and let you breathe for a minute." id ep3_24_chloesex_keepgoing_0267e761
        chloe "Be right back." id ep3_24_chloesex_keepgoing_6c66d926
        $ renpy.end_replay()


jump ep3_25_chloetalk
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
