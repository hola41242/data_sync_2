
label ep3_10_van:

    play sound cell_phone_ring volume 0.5
    show ep3 sat_van_001 with d
    dylan "Hurry up, bro..." (what_bold=True)
    stop sound
    show ep3 sat_van_002 with d
    dylan "Finally..." (what_bold=True)
    show ep3 sat_van_003 with d
    dylan "Hey, bro, we all agreed to wear black, and..." (what_bold=True)
    show ep3 sat_van_004 with d
    simon "Huh?" id ep3_10_van_196da51b
    show ep3 sat_van_005 with vpunch
    dylan "Aaaaggghh!" (what_bold=True)
    show ep3 sat_van_006 with d
    simon "Come on. It's not that bad." id ep3_10_van_43904247
    show ep3 sat_van_007 with d
    dylan "It's like catching a glimpse of the sun in the middle of the night!" (what_bold=True)
    dylan "All of your neighbors are probably up now because of you and your sparkly shirt." (what_bold=True)
    show ep3 sat_van_008 with d
    simon "For your sake, I hope not." id ep3_10_van_af3c6897
    simon "They'd call the police if they saw this suspicious van parked out here." id ep3_10_van_16bc2fc6
    show ep3 sat_van_009 with d
    simon "Anyway, aren't you going to let me in?" id ep3_10_van_e9ade252
    simon "And where's Chloe?" id ep3_10_van_ff547937
    show ep3 sat_van_010 with d
    dylan "She's in the back." (what_bold=True)
    show ep3 sat_van_011 with d
    simon "Is that where you keep the candy you hand out to the children?" id ep3_10_van_47a20e0e
    show ep3 sat_van_012 with d
    dylan "Ha ha. Very funny. I'm actually carting around much more precious cargo." id ep3_10_van_bf6f47c5
    show ep3 sat_van_013 with d
    simon "What might that be?" id ep3_10_van_132666f4
    play sound car_door_open volume 0.7
    show ep3 sat_van_014 with d
    chloe "Come with me if you want to live!" id ep3_10_van_fd743f1b
    show ep3 sat_van_015 with d
    simon "Huh?" id ep3_10_van_708b4972
    show ep3 sat_van_016 with d
    chloe "It's from Terminator!" id ep3_10_van_2d1f5383
    show ep3 sat_van_017 with d
    chloe "Shall we?" id ep3_10_van_77e3b23f
    show ep3 sat_van_018 with d
    chloe "So, here's the plan..." id ep3_10_van_3eb5841d
    stop music fadeout 2.0
    jump ep3_11_susanhome
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
