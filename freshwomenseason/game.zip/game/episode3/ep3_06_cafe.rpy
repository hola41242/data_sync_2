
label ep3_06_cafe:
    show ep3 sat_cafe_001 with long_fade
    simon "(She says she's at a café... Could it be that café...?)" id ep3_06_cafe_9f39d897
    show ep3 sat_cafe_002 with d
    simon "(Well, that answers my question.)" id ep3_06_cafe_b3774de7
    simon "(Whoa. The café looks so different now!)" id ep3_06_cafe_9fd2c97e
    simon "(I'm glad they changed things up. Maybe now they'll get more customers dropping by.)" id ep3_06_cafe_515aad06
    simon "(Did they make changes to the staff as well...?)" id ep3_06_cafe_aa6908f6
    show ep3 sat_cafe_003 with d

    play music hot_piece_for_sale volume 0.2
    simon "(Nope. She's there too...)" id ep3_06_cafe_091b69a1
    show ep3 sat_cafe_004 with d
    simon "Hello..." id ep3_06_cafe_6d63b44b
    show ep3 sat_cafe_005 with d
    chloe "Hey, [name]!" id ep3_06_cafe_3711c7ca
    alyssa "Hi!" id ep3_06_cafe_a094f6df
    show ep3 sat_cafe_006 with d
    simon "(Uh-oh.)" id ep3_06_cafe_dfcb636c
    show ep3 sat_cafe_007 with d
    alyssa "Do you two know each other?" id ep3_06_cafe_f2f46c0a
    show ep3 sat_cafe_008 with d
    chloe "Yep! He's the friend I was talking about!" id ep3_06_cafe_2c3d8589
    chloe "I had no idea the two of you knew each other." id ep3_06_cafe_32f760f1
    show ep3 sat_cafe_009 with d
    chloe "Although it makes sense." id ep3_06_cafe_6b0f2f3d
    chloe "A café is a great place to meet new people." id ep3_06_cafe_c2bba110
    chloe "Good choice for a newcomer." id ep3_06_cafe_f74b8a68
    show ep3 sat_cafe_010 with d
    chloe "He probably should have started with another café though. This one's usually empty." id ep3_06_cafe_821ffe2a
    show ep3 sat_cafe_011 with d
    simon "Always so insightful, Chloe!" id ep3_06_cafe_310cc5ca
    show ep3 sat_cafe_012 with d
    alyssa "Yes! She's very intelligent!" id ep3_06_cafe_a503d14d
    alyssa "Chloe always tells me such interesting facts when she comes by." id ep3_06_cafe_4016eb57
    show ep3 sat_cafe_013 with d
    simon "I didn't know you two were friends." id ep3_06_cafe_f3b27868
    show ep3 sat_cafe_014 with d
    alyssa "Oh, Chloe's a regular." id ep3_06_cafe_f0e9dae2
    show ep3 sat_cafe_015 with d
    chloe "Books and coffee go so well together!" id ep3_06_cafe_8896ae48
    chloe "I always come here after I go to the bookstore." id ep3_06_cafe_dd33f904
    show ep3 sat_cafe_016 with d
    chloe "Come to think of it, I don't think we've ever had a conversation outside of this place, have we?" id ep3_06_cafe_47d1c02d
    show ep3 sat_cafe_017 with d
    alyssa "Nope, but I think we should change that!" id ep3_06_cafe_39cefc61
    show ep3 sat_cafe_018 with d
    alyssa "And since you two are already friends, that makes it even easier! What do you say, [name]?" id ep3_06_cafe_a1609259

    menu:
        "Accept"(True):
            $ ep3_06_cafe_accept = True
            $ player_choice("ep3_06_cafe_accept:true")
            $ points_chloe += 1
            $ points_alyssa += 1
            show ep3 sat_cafe_019 with d
            simon "Oh... That sounds surprisingly nice." id ep3_06_cafe_30dbf5fa
            show ep3 sat_cafe_020 with d
            simon "The three of us hanging out together? I can't see why not." id ep3_06_cafe_a114e40d

            if choice_made('ep2_alyssa_kiss'):
                show ep3 sat_cafe_021 with d
                simon "(Would that complicate things with Alyssa though?)" id ep3_06_cafe_d1556d0f
                simon "(She doesn't seem to mind the idea.)" id ep3_06_cafe_4825afe5
                show ep3 sat_cafe_022 with d
                simon "(... Or is this some sort of test? Should I have said no?)" id ep3_06_cafe_81224ef0
                simon "(Or do they have different ideas?)" id ep3_06_cafe_e6e1adcf
                show ep3 sat_cafe_023 with white_fade
                simon "(Hehe. Nice.)"
            else:
                show ep3 sat_cafe_021 with d
                simon "(Or do they have different ideas?)" id ep3_06_cafe_d065d1c8
                show ep3 sat_cafe_023 with white_fade
                simon "(Hehe. Nice.)"
                show ep3 sat_cafe_024 with d
                simon "(Snap out of it, [name]. Focus on the here and now.)" id ep3_06_cafe_532fc5b4
                simon "(Later is still just possibilities...)" id ep3_06_cafe_18ccea32
        "Refuse":

            $ ep3_06_cafe_refuse = True
            $ player_choice("ep3_06_cafe_refuse:true")
            show ep3 sat_cafe_025 with d
            simon "Uh... We'll have to see about that..." id ep3_06_cafe_679a718b

            if choice_made('ep2_alyssa_kiss'):
                show ep3 sat_cafe_021 with d
                simon "(I think refraining would be for the best. After all, something could happen between me and Alyssa.)" id ep3_06_cafe_5359cef2
                simon "(Unless I can handle them both...)" id ep3_06_cafe_6ccc702e
                show ep3 sat_cafe_023 with white_fade
                simon "(Hehe. Nice.)"
                show ep3 sat_cafe_024 with d
                simon "(I shouldn't be imagining such things right now. I have more important things to focus on.)" id ep3_06_cafe_ad7bc472
            else:
                show ep3 sat_cafe_026 with d
                alyssa "Oh, that's all right! You'll probably be pretty busy with classes starting soon and all." id ep3_06_cafe_c73444c7


    show ep3 sat_cafe_027 with d
    stop music fadeout 3
    alyssa "Well, I'll let you two talk about what you came to discuss." id ep3_06_cafe_29ee3366
    alyssa "If you want to order anything, [name], just let me know!" id ep3_06_cafe_15f5982c
    show ep3 sat_cafe_028 with d
    simon "Thanks!" id ep3_06_cafe_a1e3e3ba
    show ep3 sat_cafe_029 with d

    play music not_afraid_to_stay volume 0.15
    chloe "Umm... I was beginning to worry." id ep3_06_cafe_692e2a2b
    show ep3 sat_cafe_030 with d
    chloe "You were supposed to be here an hour ago." id ep3_06_cafe_bc5215c2
    chloe "Did something happen?" id ep3_06_cafe_1d3cb45c

    if choice_made('let_dylan_help'):
        show ep3 sat_cafe_031 with d
        simon "(Hmm... Dylan said I was supposed to be honest with her. Let's see...)" id ep3_06_cafe_81f3b51d

    menu:
        "Tell the truth"(True):
            $ ep3_06_cafe_tell_the_truth = True
            $ player_choice("ep3_06_cafe_tell_the_truth:true")
            $ points_chloe += 1
            show ep3 sat_cafe_032 with d
            simon "Errr... Well... Dylan kind of got into some trouble, and I had to help him out of it." id ep3_06_cafe_fb851268
            show ep3 sat_cafe_033 with d
            simon "Although it was partially my fault." id ep3_06_cafe_d3d2b67d
            simon "Anyway, sorry for the delay." id ep3_06_cafe_ce252713
            show ep3 sat_cafe_034 with d
            chloe "Ah, so that's what held you up!" id ep3_06_cafe_1f2a5bd4
            chloe "He said something about being in a bind, but he said you would help him out this time." id ep3_06_cafe_b53819ec
            show ep3 sat_cafe_035 with d
            chloe "He says all sorts of things though, so I don't worry about him much." id ep3_06_cafe_31eab44f
            chloe "Besides, I figured he'd be fine with you at his side." id ep3_06_cafe_5156690e
            chloe "Don't worry about being late!" id ep3_06_cafe_a738e3c8
        "Make up a story":

            $ ep3_06_cafe_make_up_a_story = True
            $ player_choice("ep3_06_cafe_make_up_a_story:true")
            show ep3 sat_cafe_036 with d
            simon "Ah, what happened was that I..." id ep3_06_cafe_c59e27e6
            show ep3 sat_cafe_037 with d
            simon "I..." id ep3_06_cafe_9bf3b23a
            show ep3 sat_cafe_038 with d
            simon "... Got caught in traffic on the way?" id ep3_06_cafe_50d2886f
            show ep3 sat_cafe_039 with d
            chloe "Oh... You weren't with Dylan then?" id ep3_06_cafe_42e6ec1e
            show ep3 sat_cafe_040 with d
            simon "How did you know about that?!" id ep3_06_cafe_650774a3
            show ep3 sat_cafe_041 with d
            chloe "I'm a good detective. Remember?" id ep3_06_cafe_ab99fdf8
            show ep3 sat_cafe_042 with d
            chloe "What you and Dylan do is none of my business." id ep3_06_cafe_a87abe69
            chloe "But I don't want you to feel like you have to lie to me." id ep3_06_cafe_6760dc99
            show ep3 sat_cafe_043 with d
            simon "(Oh... Maybe I should have been more honest with her.)" id ep3_06_cafe_c6563ff7


    show ep3 sat_cafe_044 with d
    chloe "Anyway! Tell me, have you learned anything new?" id ep3_06_cafe_5c638bd2
    show ep3 sat_cafe_045 with d
    simon "Oh, right. That's what we're here to talk about." id ep3_06_cafe_35f73bfa
    show ep3 sat_cafe_046 with d
    simon "I remembered something that I honestly don't know what to think about." id ep3_06_cafe_c7421d46
    show ep3 sat_cafe_047 with d
    chloe "Are you okay, [name]?" id ep3_06_cafe_debd8f70
    show ep3 sat_cafe_046 with d
    simon "Yeah." id ep3_06_cafe_d44ae3cd
    simon "Well, I think I will be." id ep3_06_cafe_551a492d
    show ep3 sat_cafe_042 with d
    chloe "Whatever it is, you can share it with me." id ep3_06_cafe_cf05e5d6
    show ep3 sat_cafe_048 with d
    simon "Well... I remembered that I was talking on the phone with Charlie the night of the accident..." id ep3_06_cafe_776c5741
    show ep3 sat_cafe_044 with d
    chloe "Charlie was Susan's husband, right?" id ep3_06_cafe_07343175
    simon "The man himself." id ep3_06_cafe_51144d32
    show ep3 sat_cafe_049 with d
    chloe "It makes sense for you to remember the night of the accident." id ep3_06_cafe_ba96140e
    chloe "Did you know Charlie well then?" id ep3_06_cafe_2306ff8f
    show ep3 sat_cafe_048 with d
    simon "It seems like I did." id ep3_06_cafe_244aac85
    show ep3 sat_cafe_042 with d
    chloe "So what were you two talking about?" id ep3_06_cafe_6bca3514
    show ep3 sat_cafe_050 with d
    simon "I'm not sure." id ep3_06_cafe_a3a11ae1
    simon "But I was extremely rude to him." id ep3_06_cafe_aef1f071
    simon "And that made me think something." id ep3_06_cafe_b985ba6a
    show ep3 sat_cafe_051 with d
    simon "Was that me? Was I a bad person?" id ep3_06_cafe_fdf4eafc
    simon "I don't know much about myself after all." id ep3_06_cafe_ad49163f

    if chose('points_chloe', 7):
        show ep3 sat_cafe_052 with d
        chloe "I haven't known you for all that long..." id ep3_06_cafe_e5a8c04d
        chloe "But I know you're a good person." id ep3_06_cafe_08c1178b
        show ep3 sat_cafe_053 with d
        chloe "I'll even forget my rational side for a second and speak from my heart." id ep3_06_cafe_2d937eb6
        chloe "I can feel you're a good person." id ep3_06_cafe_a775ee0a
        show ep3 sat_cafe_054 with d
        chloe "Call it a detective's intuition!" id ep3_06_cafe_728b63a1
        show ep3 sat_cafe_055 with d
        simon "Thanks, Chloe. That does reassure me in a way." id ep3_06_cafe_509fe813
        show ep3 sat_cafe_053 with d
        chloe "Even if that were the case, who you were before doesn't matter!" id ep3_06_cafe_c00b8ac2
        chloe "You can forge your own path!" id ep3_06_cafe_d9f780e2
    else:

        show ep3 sat_cafe_053 with d
        chloe "I'm not sure what to tell you..." id ep3_06_cafe_4740f098
        chloe "But no matter who you were before, that doesn't define who you are today." id ep3_06_cafe_9c91835f

    show ep3 sat_cafe_056 with d
    chloe "Plus, maybe you're just remembering it wrong?" id ep3_06_cafe_88e37478
    chloe "Memories aren't that reliable in the first place." id ep3_06_cafe_b29d0e0c
    show ep3 sat_cafe_057 with d
    chloe "Did you find out if Susan had anything to do with the accident?" id ep3_06_cafe_ac853cc0
    show ep3 sat_cafe_058 with d
    simon "I honestly still have no idea." id ep3_06_cafe_02ad1129
    simon "When I asked her about it, she said there was no way I could have met her husband." id ep3_06_cafe_4f472da0
    show ep3 sat_cafe_059 with d
    alyssa "(Their conversation seems intense.)" id ep3_06_cafe_5848f8f0
    show ep3 sat_cafe_060 with d
    alyssa "(What are they talking about?)" id ep3_06_cafe_5971ac79
    show ep3 sat_cafe_061 with d
    simon "Anyway, that's all my latest news." id ep3_06_cafe_7020b715
    show ep3 sat_cafe_062 with d
    chloe "I think that'll do." id ep3_06_cafe_a5f67857
    chloe "I'll look into it a bit further." id ep3_06_cafe_c049b3d6
    show ep3 sat_cafe_063 with d
    simon "Oh, are you leaving already?" id ep3_06_cafe_a91e9542
    show ep3 sat_cafe_064 with d
    chloe "If a certain someone hadn't been late..." id ep3_06_cafe_b3e4501a
    show ep3 sat_cafe_065 with d
    chloe "I'm kidding. Don't worry about it." id ep3_06_cafe_c582e79f
    show ep3 sat_cafe_066 with d
    chloe "I just have to head to the bookstore." id ep3_06_cafe_6a40cb0c
    chloe "There's a reading starting soon." id ep3_06_cafe_ac6f842b
    chloe "And there's probably already a line for the book signing." id ep3_06_cafe_023c0790
    show ep3 sat_cafe_067 with d
    simon "Sorry I was late." id ep3_06_cafe_f6dad26a
    simon "We would have had more time to talk if it weren't for that." id ep3_06_cafe_68c22888
    show ep3 sat_cafe_068 with d
    chloe "I already said, don't worry about it." id ep3_06_cafe_e6ebcd14
    show ep3 sat_cafe_069 with d
    chloe "Besides, it looks like there's someone who needs to talk to you more than I do." id ep3_06_cafe_2b4277aa
    jump ep3_07_cafe2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
