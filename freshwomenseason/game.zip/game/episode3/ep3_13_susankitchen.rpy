
label ep3_13_susankitchen:
    show ep3 sat_susankitchen_001 with d
    chloe "Who's in there then?" (what_italic=True)
    show ep3 sat_susankitchen_002 with d
    dylan "That's what I'm trying to tell you..." (what_bold=True, what_italic=True)
    show ep3 sat_susankitchen_003 with d
    dylan "Someone got there before me." (what_bold=True, what_italic=True)
    jump ep3_14_van3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
