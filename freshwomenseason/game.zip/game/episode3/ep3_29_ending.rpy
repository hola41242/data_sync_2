
label ep3_29_ending:
    show ep3 sun_ending_001 with fade
    simon "(Finally. It's show time.)" id ep3_29_ending_87c6f797
    play music taurus volume 0.3 fadein 3
    show ep3 sun_ending_002 with fade
    play sound hit_reverb_dark_4 volume 0.33
    simon "(Hmm... How strange... The gate's not normally wide open.)" id ep3_29_ending_b169ab31
    show ep3 sun_ending_003 with fade
    simon "(Actually that might be a good thing. I'll skip the intercom and head straight for the door...)" id ep3_29_ending_2a55250b

    show ep3 sun_ending_004 with fade
    simon "(That way, she won't know what's coming.)" id ep3_29_ending_5ca57b83
    play sound hit_reverb_dark_4 volume 0.66
    show ep3 sun_ending_005 with fade
    simon "(The time has come.)" id ep3_29_ending_e9d25d31
    play sound knock_knock volume 0.7
    show ep3 sun_ending_006 with d
    simon "Lily?" id ep3_29_ending_d69575af

    show ep3 sun_ending_007 with fade
    play sound hit_reverb_dark_4 volume 0.7
    lily "Coming!" (what_italic=True)
    simon "(Excellent. She didn't even recognize it was me.)" id ep3_29_ending_89ab9af2
    show ep3 sun_ending_009 with d
    simon "(This is going to go better than I imagined it might.)" id ep3_29_ending_091af182
    play sound steps_wood volume 0.7
    lily "Just a second!" (what_italic=True)
    show ep3 sun_ending_008 with d
    simon "(Now's my chance!)" id ep3_29_ending_b3bd51ba
    stop music
    play sound door volume 0.7
    show ep3 sun_ending_010 with hpunch

    play sound_2 heartbeat_slow loop volume 0.3
    simon "Ack!" id ep3_29_ending_29293c70
    show ep3 sun_ending_011 with fade
    simon "(It can't be...)" id ep3_29_ending_328ed0af
    show black as ep3 with fade
    pause 0.9
    play sound horror_hit_dark volume 0.5

    show ep3 sun_ending_012 with Dissolve(0.3)
    mr_alderson "Yes? Can I help you?" id ep3_29_ending_4f475692
    show ep3 sun_ending_013 with Dissolve(0.5)
    pause 1.5
    jump ep3_30_finale
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
