
label ep3_17_flashback:
    scene black with medium_fade
    play music the_villain volume 0.3 fadein 3.0
    show ep3 sat_flashback_001 with medium_fade
    simon "Sam." id ep3_17_flashback_3ffbba3c
    simon "Where's Sam?" id ep3_17_flashback_9aa14a64
    show ep3 sat_flashback_002 with d
    clerk "Oh. Unfortunately, he just left and..." id ep3_17_flashback_f31a3d39
    play sound table_hit4 volume 0.7
    show ep3 sat_flashback_003 with vpunch
    simon "Bullshit! I know he's here!" id ep3_17_flashback_d07f2914
    play sound door volume 0.7
    show ep3 sat_flashback_004 with d
    sam "What's going on out here?" id ep3_17_flashback_aaa18825
    show ep3 sat_flashback_005 with d
    sam "Oh, it's you." id ep3_17_flashback_2d5f9406
    sam "Were you looking for me?" id ep3_17_flashback_448f65ad
    play sound jump_swish volume 0.5
    show ep3 sat_flashback_006 with d
    simon "You son of a bitch!" id ep3_17_flashback_1a5d3098
    scene black with d
    play sound punch_bodyhard1 volume 0.5
    pause 1.5
    play sound body_fall_mat8 volume 0.5
    show ep3 sat_flashback_007 with vpunch
    sam "Oops... Looks like you got a bit too excited there." id ep3_17_flashback_ff95c3e7
    show ep3 sat_flashback_008 with d
    simon "Fuck you, Sam." id ep3_17_flashback_03122ec2
    jump ep3_18_van5
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
