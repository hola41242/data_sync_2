define config.name = _("")
define gui.show_name = True

define config.version = "0.11"

define gui.about = _p("""
""")
define build.name = "SecretsandPromises"

define config.has_sound = True
define config.has_music = True
define config.has_voice = False
define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.intra_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = None
define config.window = "auto"
define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)
default preferences.text_cps = 0
default preferences.afm_time = 15
define config.save_directory = "SecretsandPromises-1750058512"
define config.window_icon = "gui/window_icon.png"
define config.window_title = _("Secrets And Promises [" + config.version + "]")

init python:
    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/~Chars', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)
    build.classify('**.psd', None)

    build.archive("scripts", "all")
    build.archive("e01", "all")
    build.archive("e02", "all")
    build.archive("e03", "all")
    build.archive("e04", "all")
    build.archive("e05", "all")
    build.archive("e06", "all")
    build.archive("e07", "all")
    build.archive("e08", "all")
    build.archive("e09", "all")
    build.archive("e10", "all")
    build.archive("e11", "all")
    build.archive("e12", "all")
    build.archive("e13", "all")
    build.archive("e14", "all")
    build.archive("e15", "all")
    build.archive("e16", "all")
    build.archive("e17", "all")
    build.archive("e18", "all")
    build.archive("e19", "all")
    build.archive("e20", "all")
    build.archive("e21", "all")
    build.archive("e22", "all")

    build.classify('game/images/e01/**.**', 'e01')
    build.classify('game/images/e02/**.**', 'e02')
    build.classify('game/images/e03/**.**', 'e03')
    build.classify('game/images/e04/**.**', 'e04')
    build.classify('game/images/e05/**.**', 'e05')
    build.classify('game/images/e06/**.**', 'e06')
    build.classify('game/images/e07/**.**', 'e07')
    build.classify('game/images/e08/**.**', 'e08')
    build.classify('game/images/e09/**.**', 'e09')
    build.classify('game/images/e10/**.**', 'e10')
    build.classify('game/images/e11/**.**', 'e11')
    build.classify('game/images/e12/**.**', 'e12')
    build.classify('game/images/e13/**.**', 'e13')
    build.classify('game/images/e14/**.**', 'e14')
    build.classify('game/images/e15/**.**', 'e15')
    build.classify('game/images/e16/**.**', 'e16')
    build.classify('game/images/e17/**.**', 'e17')
    build.classify('game/images/e18/**.**', 'e18')
    build.classify('game/images/e19/**.**', 'e19')
    build.classify('game/images/e20/**.**', 'e20')
    build.classify('game/images/e21/**.**', 'e21')
    build.classify('game/images/e22/**.**', 'e22')
    build.classify('game/**.png', 'archive')
    build.classify('game/**.jpg', 'archive')
    build.classify('game/**.webm', 'archive')
    build.classify('game/**.webp', 'archive')
    build.classify('game/**.mp3', 'archive')
    build.classify('game/**.rpy', 'scripts')
    build.classify('game/**.rpyc', 'scripts')

    build.documentation('*.html')
    build.documentation('*.txt')
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
