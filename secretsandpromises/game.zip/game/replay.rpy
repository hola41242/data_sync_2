init python:
    maxthumbx = config.screen_width / (4 + 1)
    maxthumby = config.screen_height / (4 + 1)
    replay_page = 0
    selected_location=None
    selected_charImg=None
    selected_charNm=""
    CurrentReplayItem=None
    def LockReplaysChar(chArr):
        for clip in chArr:
            renpy.mark_label_unseen(clip.replay)
    def LockReplays(): 
        LockReplaysChar(Sarah_Replay)
        LockReplaysChar(Mary_Replay)
        LockReplaysChar(Alison_Replay)
        LockReplaysChar(Cara_Replay)
        LockReplaysChar(Melanie_Replay)
        LockReplaysChar(Gabby_Replay)
        LockReplaysChar(Alex_Replay)
        LockReplaysChar(Dawn_Replay)
        LockReplaysChar(Sue_Replay)
        LockReplaysChar(Violet_Replay)
        LockReplaysChar(Millie_Replay)
        LockReplaysChar(Hannah_Replay)
        LockReplaysChar(Nettie_Replay)
        LockReplaysChar(Ruth_Replay)
        LockReplaysChar(Chloe_Replay)
        LockReplaysChar(Nicole_Replay)
    class ReplayItem:
        def __init__(self, thumb, thumbl,thumbh, replay):
            self.thumb = thumb
            self.thumbl = thumbl
            self.thumbh = thumbh
            self.replay = replay
        def num_replay(self):
            return len(self.thumb)
    def AddReplay(charR, thmb, lb):
        t= tpath + thmb; 
        charR.append(ReplayItem(t+".png",t+"n.png", t+"h.png", lb))

    Replay_items = None
    Sarah_Replay = []; Mary_Replay = []; Cara_Replay = [];  Alison_Replay = []; Alysha_Replay = []; Nicole_Replay = []
    Alex_Replay = []; Melanie_Replay = []; Gabby_Replay = []; Sue_Replay = []; Melissa_Replay = []; Dawn_Replay = []
    Nettie_Replay = []; Millie_Replay = []; Violet_Replay = []; Kiyomi_Replay = []; Christina_Replay=[]; Hannah_Replay=[]
    Ruth_Replay = []; Lucy_Replay=[]; Jane_Replay=[]; Jemma_Replay=[]; Miyuka_Replay=[]; Elizabeth_Replay=[]; Blaze_Replay=[]
    Lucy_Replay=[]; Helen_Replay=[]; Chloe_Replay=[]; Hayley_Replay=[]; Mitsui_Replay=[]; Amelia_Replay=[];  Priya_Replay=[]
    posX=[0, 100, 200]
    posY=[20, 170, 320, 470, 620, 770]
    tpath="images/gallery/"
    hover_name = ""
    ChDesc=""
    AddReplay(Sarah_Replay, "sph/rp_sar_001", "SaraReplay01"); AddReplay(Sarah_Replay, "sph/rp_sar_002", "SaraReplay02_Part02A")
    AddReplay(Sarah_Replay, "lks/rp_dawn_001", "SaraReplay02_Part03"); AddReplay(Sarah_Replay, "sph/rp_sar_003", "SaraReplay03")
    AddReplay(Sarah_Replay, "sph/rp_sar_004", "SaraReplay04")

    AddReplay(Mary_Replay, "sph/rp_mar_001", "MaryReplay01_Part02"); AddReplay(Mary_Replay, "sph/rp_mar_002", "MaryReplay02_Part02")
    AddReplay(Mary_Replay, "sph/rp_mar_003", "MaryReplay03"); AddReplay(Mary_Replay, "sph/rp_mar_004", "MaryReplay04")
    AddReplay(Mary_Replay, "sph/rp_mar_005", "MaryReplay05"); AddReplay(Mary_Replay, "sph/rp_mar_006", "MaryReplay06")

    AddReplay(Alison_Replay, "sph/rp_ali_001", "AlisonReplay01"); AddReplay(Alison_Replay, "sph/rp_ali_002", "AlisonReplay02")
    AddReplay(Alison_Replay, "sph/rp_ali_003", "AlisonReplay03")

    AddReplay(Cara_Replay, "sph/rp_car_001", "CaraReplay01_Part02"); AddReplay(Cara_Replay, "sph/rp_car_002", "CaraReplay02_Part02")
    AddReplay(Cara_Replay, "sph/rp_car_003", "CaraReplay03"); AddReplay(Cara_Replay, "sph/rp_car_004", "CaraReplay04")
    AddReplay(Cara_Replay, "sph/rp_car_005", "CaraReplay05"); AddReplay(Cara_Replay, "sph/rp_car_006", "CaraReplay06")
    AddReplay(Cara_Replay, "sph/rp_car_007", "MillieReplay08"); AddReplay(Cara_Replay, "sph/rp_car_008", "CaraReplay07")

    AddReplay(Melanie_Replay, "sph/rp_mel_001", "MelanieReplay01"); AddReplay(Melanie_Replay, "sph/rp_mel_002", "MelanieReplay02")
    AddReplay(Melanie_Replay, "sph/rp_mel_003", "MelanieReplay03")

    AddReplay(Gabby_Replay, "sph/rp_gab_001", "GabbyReplay01")

    AddReplay(Alex_Replay, "sph/rp_alex_001", "AlexReplay01"); AddReplay(Alex_Replay, "sph/rp_alex_002", "AlexReplay02")
    AddReplay(Alex_Replay, "sph/rp_alex_003", "AlexReplay03")

    AddReplay(Sue_Replay, "sph/rp_sue_001", "SueReplay01_Part02"); AddReplay(Sue_Replay, "sph/rp_sue_002", "SueReplay02")
    AddReplay(Sue_Replay, "sph/rp_sue_003", "SueReplay03")

    AddReplay(Dawn_Replay, "lks/rp_dawn_001", "DawnReplay01"); AddReplay(Dawn_Replay, "lks/rp_dawn_002", "DawnReplay02")
    AddReplay(Dawn_Replay, "lks/rp_dawn_003", "DawnReplay03"), AddReplay(Dawn_Replay, "lks/rp_dawn_004", "DawnReplay04")

    AddReplay(Melissa_Replay, "lks/rp_melissa_001", "MelissaReplay01")

    AddReplay(Blaze_Replay, "lks/rp_blaze_001", "BlazeReplay01")

    AddReplay(Ruth_Replay, "lks/rp_ruth_001", "RuthReplay01"); AddReplay(Ruth_Replay, "lks/rp_ruth_002", "RuthReplay02")
    AddReplay(Ruth_Replay, "lks/rp_ruth_003", "RuthReplay03")

    AddReplay(Violet_Replay, "okh/rp_vi_001", "VioletReplay01"); AddReplay(Violet_Replay, "okh/rp_vi_002", "VioletReplay02")
    AddReplay(Violet_Replay, "okh/rp_vi_003", "VioletReplay03"); AddReplay(Violet_Replay, "okh/rp_mil_006a", "MillieReplay06_01")
    AddReplay(Violet_Replay, "okh/rp_vi_004a", "VioletReplay04A"); AddReplay(Violet_Replay, "okh/rp_vi_004b", "VioletReplay04B")

    AddReplay(Millie_Replay, "okh/rp_mil_001", "MillieReplay01"); AddReplay(Millie_Replay, "okh/rp_mil_002", "MillieReplay02")
    AddReplay(Millie_Replay, "okh/rp_mil_003", "MillieReplay03"); AddReplay(Millie_Replay, "okh/rp_mil_004", "MillieReplay04")
    AddReplay(Millie_Replay, "okh/rp_mil_005", "MillieReplay05"); AddReplay(Millie_Replay, "okh/rp_mil_006a", "MillieReplay06_01")
    AddReplay(Millie_Replay, "okh/rp_mil_006b", "MillieReplay06_02"); AddReplay(Millie_Replay, "okh/rp_mil_007", "MillieReplay07")
    AddReplay(Millie_Replay, "okh/rp_vi_004a", "VioletReplay04A"); AddReplay(Millie_Replay, "okh/rp_mil_008", "MillieReplay08")
    AddReplay(Millie_Replay, "sph/rp_car_008", "CaraReplay07"); AddReplay(Millie_Replay, "okh/rp_mil_009", "MillieReplay09")

    AddReplay(Hannah_Replay, "okh/rp_han_001", "HannahReplay01"); AddReplay(Hannah_Replay, "okh/rp_han_002", "HannahReplay02")
    AddReplay(Hannah_Replay, "sph/rp_car_008", "CaraReplay07")

    AddReplay(Lucy_Replay, "okh/rp_luc_001", "LucyReplay01")

    AddReplay(Nettie_Replay, "cdg/rp_net_001", "NettieReplay01"); AddReplay(Nettie_Replay, "cdg/rp_net_002", "NettieReplay02")
    AddReplay(Nettie_Replay, "cdg/rp_net_003", "NettieReplay03"); AddReplay(Nettie_Replay, "cdg/rp_net_004", "NettieReplay04")

    AddReplay(Chloe_Replay, "cdg/rp_chlo_001", "ChloeReplay01"); AddReplay(Chloe_Replay, "cdg/rp_chlo_002", "ChloeReplay02")

    AddReplay(Nicole_Replay, "sph/rp_nic_001", "NicoleReplay01"); AddReplay(Nicole_Replay, "sph/rp_nic_002", "NicoleReplay02")

    AddReplay(Alysha_Replay, "sph/rp_aly_001", "AlyshaReplay01")

screen ReplayOptions():
    frame:
        background Frame("gui/pref_box.png", 10,10,10,10)
        xalign 0.975
        yalign 0.18
        xysize (300, 350)
        has frame
        xalign 0.5
        background None
        text "{size=*0.6}Soft Unlock" xalign 0.5
        textbutton "On":
            text_size 22
            xalign 0.25
            ypos 25
            action ToggleField(persistent, "UseSoftLock")
        imagebutton:
            ypos 30
            xalign 0.5
            if persistent.UseSoftLock:
                idle "gui/pref_on.png"
            else:
                idle "gui/pref_off.png"
            action ToggleField(persistent, "UseSoftLock")
        textbutton "Off":
            text_size 22
            xalign 0.8
            ypos 25
            action ToggleField(persistent, "UseSoftLock")
        text "{size=*0.5}{b}On{/b}: Unlocks clips only while unlock is active.\n{b}Off{/b}: Marks clips as seen. Any watched clips will remain unlocked even after turning off the unlocker.":
            xalign 0.5
            ypos 65
        textbutton "{size=*0.6}{b} RESET ALL ":
            text_align (0.5, 0.5)
            align ((0.5, 0.90))
            xysize (175, 50)
            background Frame("gui/pref_box.png", 10,10,10,10)
            text_color "#f00"
            text_hover_color "#ff0"
            action Function(LockReplays), ToggleField(persistent, "UnlockReplays"), Hide ("ReplayOptions")
        text "{size=*0.5}Resets all clips to locked.":
            xalign 0.5
            yalign 1.0


screen replaychars():
    tag menu
    add tpath+"galbg.jpg"
    frame:
        xpos 1770
        ypos 65
        background None
        if persistent.UnlockReplays:
            imagebutton:
                xpos 75
                ypos 20
                idle "thumbs/s_icon_i.png"
                hover "thumbs/s_icon_h.png"
                action ToggleScreen('ReplayOptions')
        imagebutton:
            if persistent.UnlockReplays:
                idle "images/thumbs/g_unl.png"
            else:
                idle "images/thumbs/g_lk.png"
            action ToggleField(persistent, "UnlockReplays"), Hide ("ReplayOptions")

    frame:
        xpos 267
        ypos 800
        xysize (295, 250)
        if hover_name!="":
            background Frame("gui/pref_box.png", 10,10,10,10)
            text hover_name align (0.5, 0.0) size 50 color "#e9f0b4" font "if.ttf"
            text ChDesc:
                size 20
                xalign 0.1
                ypos 70
        else:
            background None
    frame:
        xpos 42
        ypos 130
        xsize 201
        ysize 926
        background None
        imagebutton:
            xalign 0.5
            ypos 30
            if persistent.UnlockReplays or persistent.springhaven_active:
                idle tpath + "g_btn_sph_i.png"
                hover tpath + "g_btn_sph_h.png"
                action SetScreenVariable("selected_location","loc_sprhav"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 80
            if persistent.UnlockReplays or persistent.lakeshore_active:
                idle tpath + "g_btn_lks_i.png"
                hover tpath + "g_btn_lks_h.png"
                action SetScreenVariable("selected_location","loc_lakeshr"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 130
            if persistent.UnlockReplays or persistent.northcrest_active:
                idle tpath + "g_btn_nrc_i.png"
                hover tpath + "g_btn_nrc_h.png"
                action SetScreenVariable("selected_location","loc_nrthcrst"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 180
            if persistent.UnlockReplays or persistent.milfork_active:
                idle tpath + "g_btn_mif_i.png"
                hover tpath + "g_btn_mif_h.png"
                action SetScreenVariable("selected_location","loc_mlfrk"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 230
            if persistent.UnlockReplays or persistent.eastfield_active:
                idle tpath + "g_btn_efd_i.png"
                hover tpath + "g_btn_efd_h.png"
                action SetScreenVariable("selected_location","loc_efild"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 280
            if persistent.UnlockReplays or persistent.brookvale_active:
                idle tpath + "g_btn_brv_i.png"
                hover tpath + "g_btn_brv_h.png"
                action SetScreenVariable("selected_location","loc_brkvle"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 330
            if persistent.UnlockReplays or persistent.oakhill_active:
                idle tpath + "g_btn_okh_i.png"
                hover tpath + "g_btn_okh_h.png"
                action SetScreenVariable("selected_location","loc_oakhl"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 380
            if persistent.UnlockReplays or persistent.chestnut_active:
                idle tpath + "g_btn_cnc_i.png"
                hover tpath + "g_btn_cnc_h.png"
                action SetScreenVariable("selected_location","loc_chcreek"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 430
            if persistent.UnlockReplays or persistent.briarhollow_active:
                idle tpath + "g_btn_brh_i.png"
                hover tpath + "g_btn_brh_h.png"
                action SetScreenVariable("selected_location","loc_brihol"), SetScreenVariable("Replay_items", None), SetScreenVariable("selected_charImg", None)
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            xalign 0.5
            ypos 480
            if persistent.UnlockReplays or persistent.cedargrove_active:
                idle tpath + "g_btn_cdg_i.png"
                hover tpath + "g_btn_cdg_h.png"
                action [SetScreenVariable("selected_location","loc_cdrgrv"), SetScreenVariable("Replay_items", None), 
                SetScreenVariable("selected_charImg", None), SetScreenVariable("selected_charNm", "")]
            else:
                idle tpath + "g_btn_l.png"
        imagebutton:
            action Return(), Hide ("ReplayOptions")
            xalign 0.5
            yalign 0.99
            idle tpath + "g_btn_return_i.png"
            hover tpath + "g_btn_return_h.png"

    if selected_location=="loc_sprhav":
        use Springhaven_Replays
    elif selected_location=="loc_cdrgrv":
        use CedarGrove_Replays
    elif selected_location=="loc_oakhl":
        use OakHill_Replays
    elif selected_location=="loc_lakeshr":
        use Lakeshore_Replays
    elif selected_location=="loc_brkvle":
        use BrookVale_Replays
    elif selected_location=="loc_brkrdg":
        use BrookRidge_Replays
    elif selected_location=="loc_nrthcrst":
        use Northcrest_Replays
    elif selected_location=="loc_brihol":
        use BriarHollow_Replays
    elif selected_location=="loc_mlfrk":
        use Milfork_Replays

    if Replay_items==None:
        $ selected_charImg=None
        $ selected_charNm=""
    frame:
        background None
        xpos 615
        ypos 130
        xsize 1260
        ysize 926
        frame:
            background None
            add selected_charImg
            xpos -12
            xsize 435
            yalign 0.5

        frame:
            background None
            xalign 0.5
            yalign 1.0
            xsize 800
            text selected_charNm:
                size 125
                color "#e9f0b4"
                font "if.ttf"
                xalign 0.5
                yalign 1.0

        frame:
            background None
            xpos 450
            yalign 0.5
            xsize 800
            if Replay_items!=None:
                if len(Replay_items)>0:
                    $ start = replay_page * 12
                    $ end = min(start + 12 - 1, len(Replay_items) - 1)
                    grid 3 5:
                        xfill True
                        yfill True

                        for i in range(start, end + 1):
                            if persistent.UnlockReplays or renpy.seen_label(Replay_items[i].replay):
                                imagebutton idle Replay_items[i].thumb:
                                    style "replay_button"
                                    action SetVariable("persistent.SeenReplay", renpy.seen_label(Replay_items[i].replay)), Replay(Replay_items[i].replay, {}, False)
                                    xalign 0.5
                                    yalign 0.5
                                    hover Replay_items[i].thumbh

                            else:
                                vbox xalign 0.5 yalign 0.5:
                                    add Replay_items[i].thumbl
                        for i in range(end - start + 1, 12):
                            null
                    if replay_page > 0:
                        textbutton "{color=#fff}Previous{/color}":
                            action SetVariable("replay_page", replay_page - 1)
                            xalign 0.1
                            yalign 0.98
                            background "#000"
                    if (replay_page + 1) * 12 < len(Replay_items):
                        textbutton "{color=#fff}Next{/color}":
                            action SetVariable("replay_page", replay_page + 1)
                            xalign 0.9
                            yalign 0.98
                            background "#000"
                else:
                    add tpath+"g_none.png":
                        yalign 0.5
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
