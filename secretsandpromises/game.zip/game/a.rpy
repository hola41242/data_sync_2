init python:
    class Stats( renpy.python.RevertableObject ):
        def __init__( self ):
            self.sc=0 ; self.sx=0; self.act=False; self.data =set([]); self.L=0; self.C=0; self.lvr=None
        def incSex(self):
            if not _in_replay:
                self.sx+=1
                if self.L<4: self.L=4
                self.lvr=True
        def incCm( self ): 
            if not _in_replay: self.C += 1
        def getSex(self): 
            return self.sx
        def getCumIns(self): 
            return self.C
        def Score(self, val=0): 
            if not _in_replay: self.sc += val
        def hasScore(self, trigger):  
            return self.sc >= trigger
        def Add( self, dat ): 
            if not _in_replay: self.data.add( dat.lower() )
        def Del(self, dat):
            if not _in_replay and dat.lower() in self.data: self.data.remove( dat.lower() ) 
        def Has( self, dat ):  
            return dat.lower() in self.data
        def Close(self, nm, resetScr):
            self.act=False
            self.lvr=False
            if resetScr: self.sc = 0
            if nm!="": renpy.notify(nm + " path closed.")
        def Activate(self, cnm=""):
            self.act = True
            if cnm!="":
                renpy.notify("Character unlocked: "+ cnm)
        def isActive(self):  
            return self.act
        def isSexual(self, sxStat=None, Inc=False):
            if not hasattr(self, "lvr"):
                return False
            if sxStat==None:
                if not Inc:
                    return (self.act and self.lvr)
                else:
                    return (self.act and self.lvr and persistent.Incest)
            else:
                if not _in_replay: self.lvr=sxStat

    class PlrSt( renpy.python.RevertableObject ):
        def __init__( self ):
            self.data = set( [] )
        def Add( self, dat ):
            if not _in_replay:
                self.data.add( dat.lower() )
        def Del(self, dat):
            if not _in_replay and dat.lower() in self.data:
                self.data.remove( dat.lower() )  
        def Has( self, dat ):
            return dat.lower() in self.data

default persistent.WalkthroughEnabled = False
default persistent.WGuide = False
default persistent.UseSaveNames = False
default persistent.UseSideImage = True
default persistent.AutoHighlight = False
default persistent.UnlockReplays = False
default persistent.EditableName = False
default persistent.CmFx = True
default persistent.CmFlash = True
default persistent.CmShake = True
default persistent.UseFocus = True
default persistent.IconsOpacity = 1
default persistent.FootPlay = True
default persistent.Anal = True
default persistent.Incest = True
default persistent.GroupSex = True
default persistent.Lez = True
default persistent.Preg = True
default persistent.PregRnd = True
default persistent.McName = ""
default persistent.nvlOption_snd = 0
default persistent.nvlOption_rec = 0
default persistent.nvlOption_txt = 0
default persistent.UseAutoForward = True
default persistent.AFSize = 2
default persistent.AFTrans = 0.5
default curLOC = None
default GalleryUnlocked = False
default wk_y = ""
default wk_n = ""
default wk_c = ""
default pmcn = ""
default persistent.SeenReplay = False
default persistent.UseSoftLock = True
default SaveVers = 0
init python:
    renpy.music.register_channel("soundAlt", "sfx", False)
    def toggle_walkthrough():
        if persistent.WalkthroughEnabled:
            store.wk_y="{color=#00ff00}"
            store.wk_n="{color=#ff0000}"
            store.wk_c= "{color=#ff0000} [Close Path]"
        else:
            store.wk_y=""
            store.wk_n=""
            store.wk_c= "" 
    def apause(len=0.5, h=None):
        if persistent.UseAutoForward:
            if h==False: renpy.show_screen("AutoForward")
            renpy.pause(len)
            if h==True: renpy.hide_screen("AutoForward")
        else: renpy.pause()
    def aP(sh=True):
        if persistent.UseAutoForward:
            if sh: renpy.show_screen("AutoForward")
            else: renpy.hide_screen("AutoForward")
    def aPs(len=0.5, s=False, h=False):
        if len==0: len=0.5
        if persistent.UseAutoForward:
            if s: renpy.show_screen("AutoForward")
            if len>0: renpy.pause(len)
            if h: renpy.hide_screen("AutoForward")
        else: renpy.pause()
    def toggle_savenames():
        if persistent.UseSaveNames:
            store.save_name = ""
        else:
            store.save_name = "Save"
    def IncreaseXY(x,y):
        if x==2:
            x=0
            y+=1
        else:
            x+=1
        return x,y
    def upd(ch):
        if not hasattr(ch, 'L'): ch.L=0
        if ch.Has("L0"): ch.L=1; ch.Del("L0")
        if ch.Has("L1"): ch.L=2; ch.Del("L1")
        if ch.Has("L2"): ch.L=3; ch.Del("L2")
        if ch.getSex()>0: ch.L=4
        if not hasattr(ch, 'C'): ch.C=0
        if ch.act and ch.sx>0 and ch.L>0: ch.lvr=True
        elif ch.L==-1:  ch.lvr=False
        else: ch.lvr=None
        if ch.Has("CumIn"): ch.C+=1; ch.Del("CumIn")
    toggle_walkthrough()
    toggle_savenames()

default EzModeActive = False
default helpedMel = False
default SentDocs = False
default BillSick = False
default MiyukaDelivered = False
default MiyukaSpringhaven = False
default MiyukaEscaped = False
default JamesD = False
default SimonD = False
default TeddyD = False
default CraigD = False
default PrisonerD = False
default Pix_Hannah = False
default Pix_Chloe = False
default Pix_Millie = False
default ToldSue = False
define Blk = "#050505"
define Wht = "#ffffff"
define Pnk = "#f002f8"
define Prp = "#801e5a"
define Prpn = "#eda2f0"
define Yel = "#f8ee7b"
define Ora = "#ff7b00ff"
define Grn = "#04ff6dff"
define BruD = 1
define BlkO = [(2.5, Blk, 1.5, 1.5)]
define PrpO = [(2.5, Prp, 1.5, 1.5)]
define side = "thumbs/side "
define mc = Character("[persistent.McName]", what_color=Yel, what_outlines=BlkO, who_color=Ora, who_outlines=[(3, Blk)], image="mc")
define mct = Character("thinking...", what_italic=True, who_prefix='{size=*.7}{i}', what_prefix='{font=LailaL.ttf}', what_color=Grn, what_outlines=[(2, Blk, 1.5, 1)], who_color=Ora, who_outlines=[(3, Blk)])
image side mc cell = side+"mc_c.png"
image side mc h = side+"mc_hp.png"
image side mc s = side+"mc_sd.png"
image side mc a = side+"mc_an.png"
image side mc sh = side+"mc_sh.png"
image side mc su = side+"mc_su.png"

define mc_txt = Character("SENT MESSAGE", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="mc_t")
default Plr = PlrSt()
define unk = Character("", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define cellVoice = ""
define unk_cell = Character("{size=*.8}{font=LailaL.ttf}{i}[cellVoice]", what_color=Wht, what_outlines=BlkO, who_color="#ffffff", who_outlines=[(1, "#362a55")], image="cell")
define mc_nvl = Character("[persistent.McName]", kind=nvl)
define msg_nvl = Character("", kind=nvl)
define nvl_mode = "phone"
define config.adv_nvl_transition = None
define config.nvl_adv_transition = Dissolve(0.3)
define fadehold = Fade(0.5, 0.5, 0.5)
define fade1 = Fade(1, 1, 1)
define fade2 = Fade(2, 2, 2)
define fade3 = Fade(3, 3, 3)
define whi = "{font=LailaL.ttf}{size=*.8}"
define giggles = "{size=*1.2}{i}{font=HappyDay.otf}  Giggles  {/font}{/i}{/size}"
define lol = "{i}{font=Atma.ttf} Hahahah {/font}{/i}"
define lolz = "{i}{font=Atma.ttf} HAHAHAHAHAHAHA! {/font}{/i}"
define kiss = "{size=*.8}{font=Vanilla.ttf}*{i}Kiss{/i}*{/font}{/size}{w=0.5}{nw}"
define ss = "{font=Vanilla.ttf}{size=*.5}{i}"
define sss = "{font=Vanilla.ttf}{i}"
define mo = "{font=Lemon.ttf}"
define ReplayFade = Fade(2, 1, 0)
define dis1 = Dissolve(1)

image spyimg:
    "images/thumbs/ih01.png"
    alpha persistent.IconsOpacity
    0.5
    "images/thumbs/ih00.png"
    0.5
    repeat
image spyimg_wk_o:
    "images/thumbs/ih01.png"
    alpha persistent.IconsOpacity
image spyimg_wk_y:
    "images/thumbs/ih02.png"
    alpha persistent.IconsOpacity
image spyimg_wk_n:
    "images/thumbs/ih03.png"
    alpha persistent.IconsOpacity

screen ReplayItemBtn(nx, ny, loc_id, tmpch, tmpRp, tmpPers, desc=""):
    imagebutton:
        xpos posX[nx]
        ypos posY[ny]
        if not persistent.UnlockReplays and tmpPers:
            idle tpath + "/"+loc_id+"/"+tmpch+"_n.jpg"
            action SetScreenVariable("Replay_items",None)
        else:
            idle tpath + "/"+loc_id+"/"+tmpch+"_i.jpg"
            hover tpath + "/"+loc_id+"/"+tmpch+"_h.jpg"
            hovered SetScreenVariable("hover_name", tmpch.capitalize()), SetScreenVariable("ChDesc", desc)
            unhovered SetScreenVariable("hover_name", "")
            action [SetScreenVariable("Replay_items", tmpRp), SetScreenVariable("selected_charImg", tpath +"/"+loc_id+"/rp_"+tmpch+".png"),
                SetScreenVariable("selected_charNm", tmpch.capitalize()) ]

screen NvlOptions():
    frame:
        background Solid("#e90e0e00")
        add "thumbs/cell/opts_bk.png"
        xalign 0.75
        yalign 0.5
        xysize (300, 400)
        grid 3 1:
            spacing 15
            xpos 28
            ypos 80
            xysize (230, 65)
            imagebutton:
                if persistent.nvlOption_rec==0:
                    idle "thumbs/cell/rec0_1.jpg"
                else:
                    idle "thumbs/cell/rec0_0.jpg"
                action SetVariable("persistent.nvlOption_rec", 0)
            imagebutton:
                if persistent.nvlOption_rec==1:
                    idle "thumbs/cell/rec1_1.jpg"
                else:
                    idle "thumbs/cell/rec1_0.jpg"
                action SetVariable("persistent.nvlOption_rec", 1)
            imagebutton:
                if persistent.nvlOption_rec==2:
                    idle "thumbs/cell/rec2_1.jpg"
                else:
                    idle "thumbs/cell/rec2_0.jpg"
                action SetVariable("persistent.nvlOption_rec", 2)

        grid 3 1:
            spacing 15
            xpos 28
            ypos 184
            xysize (230, 65)
            imagebutton:
                if persistent.nvlOption_snd==0:
                    idle "thumbs/cell/snd0_1.jpg"
                else:
                    idle "thumbs/cell/snd0_0.jpg"
                action SetVariable("persistent.nvlOption_snd", 0)
            imagebutton:
                if persistent.nvlOption_snd==1:
                    idle "thumbs/cell/snd1_1.jpg"
                else:
                    idle "thumbs/cell/snd1_0.jpg"
                action SetVariable("persistent.nvlOption_snd", 1)
            imagebutton:
                if persistent.nvlOption_snd==2:
                    idle "thumbs/cell/snd2_1.jpg"
                else:
                    idle "thumbs/cell/snd2_0.jpg"
                action SetVariable("persistent.nvlOption_snd", 2)

        grid 3 1:
            spacing 15
            xpos 28
            ypos 287
            xysize (230, 65)
            imagebutton:
                if persistent.nvlOption_txt==0:
                    idle "thumbs/cell/txt0_1.jpg"
                else:
                    idle "thumbs/cell/txt0_0.jpg"
                action SetVariable("persistent.nvlOption_txt", 0)
            imagebutton:
                if persistent.nvlOption_txt==1:
                    idle "thumbs/cell/txt1_1.jpg"
                else:
                    idle "thumbs/cell/txt1_0.jpg"
                action SetVariable("persistent.nvlOption_txt", 1)
            imagebutton:
                if persistent.nvlOption_txt==2:
                    idle "thumbs/cell/txt2_1.jpg"
                else:
                    idle "thumbs/cell/txt2_0.jpg"
                action SetVariable("persistent.nvlOption_txt", 2)
screen CellPhone(char=None):
    $ phone_icon="thumbs/cell/th_[char].jpg"
    add "thumbs/cell/cell_bg.png":
        xalign 0.5
        yalign 0.5
        ysize 1028
        xsize 487
    add phone_icon:
        xpos 733
        ypos 95
    imagebutton:
        xpos 750
        ypos 960
        idle "thumbs/cell/s_icon_i.png"
        hover "thumbs/cell/s_icon_h.png"
        action ToggleScreen('NvlOptions')
screen PhoneDialogue(dialogue, items=None):
    style_prefix "phoneFrame"
    frame:
        xalign 0.5
        yalign 0.5
        has viewport
        draggable True
        mousewheel True
        yinitial 1.0
        vbox:
            use nvl_phonetext(dialogue)

            for i in items:
                textbutton i.caption:
                    action i.action
                    text_size 24
                    text_font "fonts/RobConLt.ttf"
                    text_color "#ffffff"
                    xsize 320
                    text_align 1.0
                    padding (10,10)
                    align (1.0, 0.5)
                    idle_background Frame("thumbs/cell/snd_frame_mnu.png", 23,23,23,23)
                    hover_background Frame("thumbs/cell/snd_frame_h.png", 23,23,23,23)
screen nvl_phonetext(dialogue):
    style_prefix None
    $ previous_d_who = None
    for id_d, d in enumerate(dialogue):

        if d.who == persistent.McName:
            if persistent.nvlOption_snd==1:
                $ message_frame = "thumbs/cell/snd_frame1.png"
            elif persistent.nvlOption_snd==2:
                $ message_frame = "thumbs/cell/snd_frame2.png"
            else:
                $ message_frame = "thumbs/cell/snd_frame.png"
        else:
            if persistent.nvlOption_rec==1:
                $ message_frame = "thumbs/cell/rec_frame1.png"
            elif persistent.nvlOption_rec==2:
                $ message_frame = "thumbs/cell/rec_frame2.png"
            else:
                $ message_frame = "thumbs/cell/rec_frame.png"


        hbox:
            spacing 10
            if d.who != persistent.McName:
                box_reverse True
            null width 95

            vbox:
                yalign 1.0
                frame:
                    padding (10,10)
                    background Frame(message_frame, 23,23,23,23)
                    xsize 320
                    has text d.what
                    pos (10,0)
                    xsize 340
                    slow_cps False
                    size 24
                    font "fonts/RobConLt.ttf"
                    if persistent.nvlOption_txt==1:
                        color "#6d6868"
                    elif persistent.nvlOption_txt==2:
                        color "#000000"
                    else:
                        color "#ffffff"
                    if d.who == persistent.McName:
                        text_align 1.00
                        xpos -590
                    id d.what_id
        $ previous_d_who = d.who

style phoneFrame is default
style phoneFrame_frame:
    background Solid("#ffffff00")
    ysize 680
    xsize 440
style phoneFrame_viewport:
    yfill True
    xfill True
    yoffset -20
style phoneFrame_vbox:
    spacing 10
    xfill True
style gallery_replays:
    xpos 268
    ypos 130
    xsize 305
    ysize 926
    background Solid("#ffffff00")

screen Tutorial():
    add "gui/inter.jpg"
    imagebutton:
        xpos 911
        ypos 368
        idle "spyimg"
return

screen imgMap(imagePath, posx, posy, wko, labelCall):
    add imagePath
    imagebutton:
        xpos posx
        ypos posy
        idle "spyimg"
        if persistent.WalkthroughEnabled:
            if wko:
                hover "spyimg_wk_y"
            else:
                hover "spyimg_wk_n"
        else:
            hover "spyimg_wk_o"
        action Call(labelCall)
return

screen AutoForward():
    zorder 10
    frame:
        background None
        xalign 1.0
        yalign 1.0
        if persistent.AFSize==1:
            add "images/thumbs/af01.png" alpha persistent.AFTrans
        elif persistent.AFSize==2:
            add "images/thumbs/af02.png" alpha persistent.AFTrans
        else:
            add "images/thumbs/af03.png" alpha persistent.AFTrans
return

label Unlocker(sceneName, hl=False):
    if hl:
        $ renpy.mark_label_unseen(sceneName)
    elif _in_replay:
        if persistent.UnlockReplays and not persistent.SeenReplay and persistent.UseSoftLock:
            $ renpy.mark_label_unseen(sceneName)
return

label CheckShOpen:
    if springhaven_ch==3:
        if not cedargrove_open and not oakhill_open:
            $ springhaven_open=True
    elif springhaven_ch==4:
        if not cedargrove_open and not oakhill_open and not lakeshore_open:
            $ springhaven_open=True
    elif springhaven_ch==6:
        if not cedargrove_open and not milfork_open and not lakeshore_open and not oakhill_open:
            $ springhaven_open=True
    elif springhaven_ch==7:
        if not milfork_open and not lakeshore_open:
            $ springhaven_open=True
    elif springhaven_ch==8:
        if not oakhill_open and not cedargrove_open:
            $ springhaven_open=True

return

label UpdateMapInfos:
    call UpdateBriarHollowData ()
    call UpdateBrookRidgeData ()
    call UpdateBrookValeData ()
    call UpdateCedarGroveData ()
    call UpdateChestnutData ()
    call UpdateEastFieldData ()
    call UpdateLakeshoreData ()
    call UpdateMilforkData ()
    call UpdateNorthcrestData ()
    call UpdateOakhillData ()
    call UpdateSpringhavenData ()
return

label CloseCell(ClearNvlScreen=True):
    hide screen CellPhone
    hide screen NvlOptions
    if ClearNvlScreen:
        nvl clear
return

label Emotion(Sayer, Emot, Text="", sml=False):
    $ sz="{size=*0.8}"
    if sml:
        $ sz="{size=*0.6}"
    Sayer "[sz]{font=Vanilla.ttf}*{i}[Emot]{/i}*{/font}{/size} [Text]"
return

label EmotionSml(Sayer, Emot, Text=""):
    Sayer "{size=*0.6}{font=Vanilla.ttf}*{i}[Emot]{/i}*{/font}{/size}{size=*0.8} [Text]"
return

label Gag(Sayer, cps=True, p=True):
    $ t="Gag"
    if cps:
        $ t="GAG"
    if p:
        Sayer "{font=Vanilla.ttf}*{i}[t]{/i}*{/font}" with vpunch
    else:
        Sayer "{font=Vanilla.ttf}*{i}[t]{/i}*{/font}"
return

label laugh(Sayer, Text="", cps=False):
    $ sz="{size=*0.8}{font=Vanilla.ttf}*{i}Laughs{/i}*{/font}{/size}"
    if cps:
        $ sz="{size=*0.8}{font=Vanilla.ttf}*{i}LAUGHS{/i}*{/font}{/size}"
    Sayer "[sz] [Text]"
return

label CenterText(Txt, Slow=False):
    if Slow:
        scene black with Fade(3, 1, 1)
    else:
        scene black with fade
    centered "{font=Vanilla.ttf}{color=#ffff}[Txt]"
return

label UpdateName(pr=False):
    python:
        if not pr:
            persistent.McName=renpy.input(prompt="Hi, I'm...", default=("John" if pmcn=="" else pmcn), length=12)
        else:
            persistent.McName=renpy.input(prompt="Update Name:", default=("John" if pmcn=="" else pmcn), length=12)
        persistent.McName=persistent.McName.strip()
        if not persistent.McName:
            persistent.McName="John"
return

label ScanImage(Img01, p=0):
    window hide
    scene expression Img01:
        subpixel True
        yalign 1.0
        pause 0.5
        linear 9.0 yalign 0.0
    if p>0:
        pause p
    else:
        pause
return

label Bruises(inc=False):
    if inc and BruD<7:
        $ BruD+=1
    if JamesD and BruD<7:
        $ Plr.Add("Bruises")
    else:
        $ Plr.Del("Bruises")
return

label CharCum(FlashImage, CumImage, Sayer, Say, i=0):
    if persistent.CmFx:
        if persistent.CmFlash:
            scene expression "images/"+FlashImage with Fade(.1, 0.0, .5, color="#fff")
        else:
            scene expression "images/"+FlashImage with dissolve
        if persistent.CmShake:
            scene expression "images/"+CumImage with Move((0, 15), (0, -15), .10, bounce=True, repeat=True, delay=1)
            Sayer "{font=Lemon.ttf}{size=*0.8}[Say]{w=1}{nw}" with Move((0, 15), (0, -15), .10, bounce=True, repeat=True, delay=1)
        else:
            scene expression "images/"+CumImage with dissolve
    else:
        scene expression "images/"+FlashImage with dissolve
        scene expression "images/"+CumImage with dissolve
    Sayer "{font=Lemon.ttf}{size=*0.8}[Say]"
return

label Loop_Punch(Count, PunchImg, Img, p=0.25):
    while Count>0:
        scene expression "images/"+PunchImg with hpunch
        scene expression "images/"+Img with dissolve
        if p>0:
            pause p
        $ Count-=1
return

label Loop_Dissolve(Count, Slow, Rev, Img01, Img02, Img03="", Img04=""):
    $ t=0.5
    if Slow:
        $ t=1.0
    while Count>0:
        scene expression Img01 with Dissolve(t)
        scene expression Img02 with Dissolve(t)
        if Img03!="":
            scene expression Img03 with Dissolve(t)
        if Img04!="":
            scene expression Img04 with Dissolve(t)
        if Rev:
            if Img03!="":
                scene expression Img03 with Dissolve(t)
            scene expression Img02 with Dissolve(t)
            if Count==1:
                scene expression Img01 with Dissolve(t)
        $ Count-=1
return

label Loop_Dissolve_Alt(Count, Img01, Img02, p=0.5):
    while Count>0:
        scene expression Img01 with dissolve
        pause p
        scene expression Img02 with dissolve
        pause p
        $ Count-=1
return

label Loop_FDissolve(Count, Img01, Img02, Img03="", Img04=""):
    while Count>0:
        scene expression Img01 with dissolve
        scene expression Img02 with dissolve
        if Img03!="":
            scene expression Img03 with dissolve
            if Img04!="":
                scene expression Img04 with dissolve
        $ Count-=1
return

label AutoA(sh=True):
    if persistent.UseAutoForward and sh:
        show screen AutoForward
    else:
        hide screen AutoForward
return

label Gulp(Swallower):
    play sound "gulp.mp3"
    Swallower "{size=*.8}{font=Vanilla.ttf}*GULP*{/font}{/size}{w=1}{nw}"
return

label UpdateSaveVersion:
    python:
        if SaveVers<1:
            upd(Alex); upd(Alison); upd(Alysha); upd(Cara); upd(Christina); upd(Gabby); upd(Kiyomi)
            upd(Mary); upd(Melanie); upd(Nicole); upd(Sarah); upd(Sue)
            upd(Blaze); upd(Dawn); upd(Melissa); upd(Ruth)
            upd(Mitsui); upd(Miyuka); upd(Helen); upd(Jane); upd(Jemma); upd(Amelia)
            upd(Hannah); upd(Lucy); upd(Millie); upd(Violet)
            upd(Chloe); upd(Elizabeth); upd(Hayley); upd(Nettie)
            if Alex.Has("Flash") and Alex.L<1: Alex.L=1
            if Alex.Has("DNC") and Alex.L<2: Alex.L=2
            if Alex.L==3: Alex.isSexual(True) 
            if Gabby.L==1: Gabby.isSexual(True)
            if Hannah.L==1: Hannah.isSexual(True)
            if Millie.L==4: Millie.isSexual(True)
            if Melanie.Has("TookBJ") and Melanie.L<1: Melanie.L=1
            if Melanie.L==1: Melanie.isSexual(True)
            if Melanie.Has("Help") or Plr.Has("Mel_Help"): helpedMel=True; Plr.Del("Mel_Help"); Melanie.Del("Help")
            if Alysha.Has("Docs"): SentDocs=True; Alysha.Del("Docs")
            if Plr.Has("P2"): MiyukaDelivered=True; MiyukaSpringhaven=True; Plr.Del("P2")
            if Plr.Has("Mi_Lost") or Plr.Add("P1"): MiyukaDelivered=False; MiyukaEscaped=True; Plr.Del("Mi_Lost"); Plr.Del("P1")
            if Miyuka.Has("SPR"):  MiyukaSpringhaven=True; Miyuka.Del("SPR")
            if Plr.Has("JD"): JamesD=True; Plr.Del("JD")
            if Plr.Has("SD"): SimonD=True; Plr.Del("SD")
            if Plr.Has("KillT"): TeddyD=True; Plr.Del("KillT")
            if Chloe.Has("PicsX"): Pix_Chloe=True; Chloe.Del("PicsX")
            if Millie.Has("PicsX"): Pix_Millie=True; Millie.Del("PicsX")
            if Hannah.Has("PicsX"): Pix_Hannah=True; Hannah.Del("PicsX")
            if Plr.Has("BillH"): BillSick=True; Plr.Del("BillH")
            if mAndV: persistent.MilandVi=True
            if mAndG: persistent.MelandGab=True
            Plr.Del("P0"); Plr.Del("KoT")
    $ SaveVers=1
    $ renpy.block_rollback()
return

label CloseCharacterPath(CharToClose, CharName="", ResetScore=False):
    if _in_replay:
        return
    if CharToClose.isActive():
        $ CharToClose.Close(CharName, ResetScore)
return

label Moan(ch, sz=5, caps=False):
    $ m="*Moans*"
    $ Sz=float(sz/10)
    if caps:
        $ m="*MOANS*"
    ch o "{font=Lemon.ttf}{size=*[Sz]}[m]"
return

label SendPhoto(PhotoId):
    $ imgpath="thumbs/gal/"+PhotoId+"_m.jpg"
    show screen photoBig("thumbs/gal/"+PhotoId+"_f.jpg")
    msg_nvl "{image=[imgpath]}"
    hide screen photoBig
    call AddGaleryItem (PhotoId)
    if not GalleryUnlocked:
        $ GalleryUnlocked=True
        centered "{font=Vanilla.ttf}{color=#ffff}You can access your phone's gallery from the quick menu at the bottom of the screen."
return

label CheckForP(Cins=0, hs=0, s=10):
    if not persistent.Preg or Cins<1:
        return False
    if persistent.PregRnd:
        return True
    if Cins==hs:
        $ s=int(s/2)
    if s<1:
        $ s=1
    $ res=renpy.random.randint(1, s)
    return (res==s)
return

screen Enc(Char01, Char02, Char03):
    modal True
    frame:
        xsize 600
        ysize 200
        xalign 0.5
        yalign 0.5
        background Frame("gui/pref_box.png", 10,10,10,10)
        text "{size=*.8}Encourage sexual interaction between":
            ypos 20
            xalign 0.5
        if not Char03:
            text "{size=*.8}{color=#ffc600}[Char01]{/color} and {color=#ffc600}[Char02]{/color}?":
                ypos 60
                xalign 0.5
        else:
            text "{size=*.8}{color=#ffc600}[Char01]{/color}, {color=#ffc600}[Char02]{/color}, and {color=#ffc600}[Char03]{/color}?":
                ypos 60
                xalign 0.5
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 110
            xpos 20
            idle_foreground Text("Yes", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("Yes", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(True)
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 110
            xpos 300
            idle_foreground Text("No", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("No", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(False)
return
label Encourage(Char01, Char02, Char03=None):
    if not persistent.GroupSex or not persistent.Lez:
        return False
    call screen Enc(Char01, Char02, Char03)
    return _return
return

screen EzModeScr(Char01):
    modal True
    frame:
        xsize 600
        ysize 200
        xalign 0.5
        yalign 0.5
        background Frame("gui/pref_box.png", 10,10,10,10)
        text "{color=#FFDE00}{b}{u}EZMode":
            ypos 0
            xalign 0.5
        text "{size=*.8}Pursue [Char01]?":
            ypos 60
            xalign 0.5
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 110
            xpos 20
            idle_foreground Text("Yes", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("Yes", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(True)
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 110
            xpos 300
            idle_foreground Text("No", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("No", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(False)
return
label EzModeAsk(Char01):
    call screen EzModeScr(Char01)
    return _return
return
screen EZModeOnOff():
    modal True
    frame:
        xsize 600
        ysize 300
        xalign 0.5
        yalign 0.5
        padding (10,5)
        background Frame("gui/pref_box.png", 10,10,10,10)
        text "{color=#FFDE00}{b}{u}EZMode":
            ypos 5
            xalign 0.5
        text "{size=*.6}EZMode lets you pursue the LI's you want without worrying about making, or missing, the right choices.":
            ypos 60
            xalign 0.5
        text "{size=*.6}You have a single decision - Pursue that character or not.":
            ypos 110
            xalign 0.5
        text "{size=*.6}{color=#FFDE00}{u}{b}Story-driven choices are still decided by you.":
            ypos 150
            xalign 0.5
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 210
            xpos 20
            idle_foreground Text("Enable", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("Enable", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(True)
        imagebutton:
            idle "gui/co_i.png"
            hover "gui/co_h.png"
            ypos 210
            xpos 300
            idle_foreground Text("Disable", xalign=0.5, yalign=0.40, size=25)
            hover_foreground Text("Disable", xalign=0.5, yalign=0.40, size=25, color='#f7c641')
            action Return(False)
return

screen CumOptions(Opp):
    modal True
    $ yp=50
    frame:
        xsize 275
        ysize (len(Opp)*60)+50
        xalign 0.995
        yalign 0.99
        background Frame("gui/pref_box.png", 10,10,10,10)
        text "{size=*.8}Cum Options" align (0.5, 0.0)
        for i in range(len(Opp)):
            imagebutton:
                idle "gui/co_i.png"
                hover "gui/co_h.png"
                idle_foreground Text(Opp[i], xalign=0.5, yalign=0.5, size=20)
                hover_foreground Text(Opp[i], xalign=0.5, yalign=0.5, size=20, color='#f7c641')
                ypos yp
                xalign 0.5
                xsize 250
                ysize 46
                action Return(i)
            $ yp+=50
return
label CmOpts(Copt):
    if len(Copt)>1:
        call screen CumOptions(Copt)
        return _return
    else:
        return None
return

screen photoBig(PhotoId):
    add PhotoId:
        xalign 0.1
        yalign 0.5
        zoom 0.75

screen GetNewMcName():
    modal True
    frame:
        style_prefix "popup"
        xalign 0.5
        yalign 0.5
        has vbox
        text "Enter MC Name:" size 28
        input value VariableInputValue("persistent.McName", True, True) length 12
        hbox:
            spacing 20
            textbutton "OK" action Hide("GetNewMcName")
            textbutton "Cancel" action Hide("GetNewMcName")
return
screen prefs_menu(yinitial=0.0, spacing=0):
    style_prefix "game_menu"
    add gui.game_menu_background
    $ title="Preferences"
    frame:
        style "game_menu_outer_frame"
        background None
        has hbox
        frame:
            style "pref_menu_content_frame"
            background None
            has viewport
            yinitial yinitial
            mousewheel True
            draggable True
            pagekeys True
            side_yfill True
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Display" align (0.5, 0.0)
                xpos 10
                ypos 0
                xsize 370
                ysize 100
                textbutton "Window":
                    text_size 22
                    xalign 0.1
                    ypos 40
                    action Preference("display", "window")
                imagebutton:
                    ypos 47
                    xalign 0.5
                    if preferences.fullscreen:
                        idle "gui/pref_off.png"
                        action Preference("display", "window")
                    else:
                        idle "gui/pref_on.png"
                        action Preference("display", "fullscreen")
                textbutton "Fullscreen":
                    text_size 22
                    xalign 0.95
                    ypos 40
                    action Preference("display", "fullscreen")
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Skip" align (0.5, 0.0)
                xpos 390
                ypos 0
                xsize 250
                ysize 250
                vbox:
                    xpos 10
                    ypos 50
                    style_prefix "check"
                    textbutton _(" {size=*.8}Unseen Text") action Preference("skip", "toggle")
                    textbutton _(" {size=*.8}After Choices") action Preference("after choices", "toggle")
                    textbutton _(" {size=*.8}Transitions") action InvertSelected(Preference("transitions", "toggle"))
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Options" align (0.5, 0.0)
                xpos 655
                ypos 0
                xsize 300
                ysize 560
                vbox:
                    xpos 10
                    ypos 50
                    style_prefix "check"
                    textbutton _(" {size=*.8}Use Save Names") tooltip "1" action ToggleField(persistent, "UseSaveNames"), Function(toggle_savenames)
                    textbutton _(" {size=*.8}Use Side Images") tooltip "2" action ToggleField(persistent, "UseSideImage")
                    textbutton _(" {size=*.8}Walkthrough") tooltip "3" action ToggleField(persistent, "WalkthroughEnabled"), Function(toggle_walkthrough)
                    if persistent.WalkthroughEnabled:
                        vbox:
                            xpos 0.2
                            style_prefix "check"
                            textbutton _(" {size=*.8}Full Guide") tooltip "4" action ToggleField(persistent, "WGuide")
                    textbutton _(" {size=*.8}Editable Name") tooltip "5" action ToggleField(persistent, "EditableName")
                    textbutton _(" {size=*.8}Use CumFX") tooltip "6" action ToggleField(persistent, "CmFx")
                    if persistent.CmFx:
                        vbox:
                            xpos 0.2
                            style_prefix "check"
                            textbutton _(" {size=*.8}Flash") action ToggleField(persistent, "CmFlash")
                            textbutton _(" {size=*.8}Shake") action ToggleField(persistent, "CmShake")
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Fetish Options" align (0.5, 0.0)
                xpos 970
                ypos 0
                xsize 350
                ysize 560
                vbox:
                    xpos 10
                    ypos 50
                    style_prefix "check"
                    textbutton _(" {size=*.8}Anal") tooltip "8" action ToggleField(persistent, "Anal")
                    textbutton _(" {size=*.8}Foot Play") tooltip "9" action ToggleField(persistent, "FootPlay")
                    textbutton _(" {size=*.8}Incest") tooltip "10" action ToggleField(persistent, "Incest")
                    textbutton _(" {size=*.8}Group Sex") tooltip "11" action ToggleField(persistent, "GroupSex")
                    if persistent.GroupSex:
                        vbox:
                            xpos 0.2
                            style_prefix "check"
                            textbutton _(" {size=*.8}Include Lesbian") action ToggleField(persistent, "Lez")

                    textbutton _(" {size=*.8}Pregnancy") tooltip "12" action ToggleField(persistent, "Preg")
                    if persistent.Preg:
                        vbox:
                            xpos 0.2
                            style_prefix "check"
                            textbutton _(" {size=*.8}Random") tooltip "13" action ToggleField(persistent, "PregRnd")
                            textbutton _(" {size=*.8}Always") tooltip "14" action InvertSelected(ToggleField(persistent, "PregRnd"))
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Focus" align (0.5, 0.0)
                xpos 390
                ypos 260
                xsize 250
                ysize 300

                frame:
                    xalign 0.5
                    ypos 0
                    xysize (300,50)
                    background None
                    textbutton "On":
                        text_size 22
                        xalign 0.25
                        ypos 40
                        action ToggleField(persistent, "UseFocus")
                    imagebutton:
                        tooltip "7"
                        ypos 47
                        xalign 0.5
                        if persistent.UseFocus:
                            idle "gui/pref_on.png"
                        else:
                            idle "gui/pref_off.png"
                        action ToggleField(persistent, "UseFocus")
                    textbutton "Off":
                        text_size 22
                        xalign 0.8
                        ypos 40
                        action ToggleField(persistent, "UseFocus")

                if persistent.UseFocus:
                    vbox:
                        xalign 0.5
                        yalign 1.1
                        xysize (100,100)
                        add "/thumbs/ih01_icn.png":
                            alpha persistent.IconsOpacity
                    vbox:
                        ypos 110
                        xpos 20
                        xsize 250
                        text "{size=*.8}Icon Opacity"
                        hbox:
                            ypos 10
                            xsize 200
                            bar value FieldValue(persistent, "IconsOpacity", range=1.0, style="slider")
                else:
                    vbox:
                        ypos 120
                        xpos 20
                        xsize 250
                        text "{size=*.6}Interactive focus deactivated.\nUsing regular menu choices instead."

            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "Auto Advance" align (0.5, 0.0)
                xpos 10
                ypos 570
                xsize 1310
                ysize 170

                frame:
                    background None
                    xsize 400
                    xpos 0
                    yalign 0.5
                    text "{size=*.5}[autotxt]"
                frame:
                    xalign 0.5
                    ypos -15
                    xysize (300,50)
                    background Solid("#ffffff00")
                    textbutton "On":
                        text_size 22
                        xalign 0.25
                        ypos 40
                        action ToggleField(persistent, "UseAutoForward")
                    imagebutton:
                        ypos 47
                        xalign 0.5
                        if persistent.UseAutoForward:
                            idle "gui/pref_on.png"
                        else:
                            idle "gui/pref_off.png"
                        action ToggleField(persistent, "UseAutoForward")
                    textbutton "Off":
                        text_size 22
                        xalign 0.8
                        ypos 40
                        action ToggleField(persistent, "UseAutoForward")
                if persistent.UseAutoForward:
                    vbox:
                        xpos 950
                        yalign 0.5
                        style_prefix "check"
                        textbutton _(" {size=*.8}Small") action SetVariable("persistent.AFSize", 3)
                        textbutton _(" {size=*.8}Medium") action SetVariable("persistent.AFSize", 2)
                        textbutton _(" {size=*.8}Large") action SetVariable("persistent.AFSize", 1)
                    vbox:
                        xalign 1.0
                        yalign 0.5
                        xysize (100,100)
                        if persistent.AFSize==1:
                            add "images/thumbs/af01.png" alpha persistent.AFTrans
                        elif persistent.AFSize==2:
                            add "images/thumbs/af02.png" alpha persistent.AFTrans
                        else:
                            add "images/thumbs/af03.png" alpha persistent.AFTrans
                    vbox:
                        xalign 0.5
                        xsize 500
                        yalign 1.0
                        text "{size=*.8}Icon Opacity"
                        hbox:
                            yalign 1.0
                            bar value FieldValue(persistent, "AFTrans", range=1.0, style="slider")
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "{size=*.8}Audio" align (0.5, 0.0)
                xpos 10
                ypos 110
                xsize 370
                ysize 220
                text "{size=*.6}Music Volume":
                    ypos 40
                hbox:
                    ypos 70
                    bar value Preference("music volume")

                text "{size=*.6}Sound Volume":
                    ypos 120
                hbox:
                    ypos 150
                    bar value Preference("sound volume")
            frame:
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "{size=*.8}Auto Text" align (0.5, 0.0)
                xpos 10
                ypos 340
                xsize 370
                ysize 220
                text "{size=*.6}Text Speed":
                    ypos 40
                hbox:
                    ypos 70
                    bar value Preference("text speed")

                text "{size=*.6}Auto-Forward Time":
                    ypos 120
                hbox:
                    ypos 150
                    bar value Preference("auto-forward time")
    $ tooltip = GetTooltip()
    if tooltip:
        frame:
            padding (20,20)
            xalign 0.5
            ypos 50
            xysize (600, 150)
            background Frame("gui/pref_box_sml.png", 10,10,10,10)
            if tooltip=="1":
                text "Allows you name your saves." size 20
            elif tooltip=="2":
                text "Turn on/off the side portraits that shows which character is speaking." size 20
            elif tooltip=="3":
                text "Toggles the basic walkthrough,\n{i}This guides you to the correct choices to make when pursuing characters only{/i}." size 20
            elif tooltip=="4":
                text "Toggles the fuller walkthrough - Some decisions are more important than others.\nWith this enabled you will be told of the possible consequences of these choices." size 20
            elif tooltip=="5":
                text "With this enabled, clicking on the MC's name will show you the rename prompt, allowing you to input a new name." size 20
            elif tooltip=="6":
                text "Toggle the screen shake and/or screen flash which happens when characters reach climax.\nSeperate options available when this is ON." size 20
            elif tooltip=="7":
                text "Enable/Disable the magnifying glass during Focus scenes.\nWhen turned off, regular menus will be shown instead." size 20
            elif tooltip=="8":
                text "MC will sometimes have anal sex with a character." size 20
            elif tooltip=="9":
                text "MC will sometimes partake in light foot play." size 20
            elif tooltip=="10":
                text "If OFF, MC will not have sexual content of any kind with family members." size 20
            elif tooltip=="11":
                text "When ON, MC will sometimes have more than one sexual partner during sex.\nThe other girls won't engage with each other sexually unless {i}include lesbian{/i} is ON." size 20
            elif tooltip=="12":
                text "Toggle the possibility for some sexual partners to get pregnant. Only possible if you ejaculate inside.\n{b}NOTE:{/b} {i}Some characters are on birth control so won't become pregnant regardless of this option{/i}." size 20
            elif tooltip=="13":
                text "Pregnancy will happen by chance." size 20
            elif tooltip=="14":
                text "Pregnancy WILL happen." size 20
    use navigation
    textbutton _("Return"):
        style "return_button"
        action Return()
    label title
    if main_menu:
        key "game_menu" action ShowMenu("main_menu")
return

screen WlkGuide(txt):
    if persistent.WGuide:
        frame:
            xysize (300,300)
            align (1.0, 1.0)
            padding (10,10)
            background Frame("gui/pref_box.png", 10,10,10,10)
            text "{size=*.6}{b}Walkthrough Guide" align (0.5, 0.0)
            text "\n{size=*.5}[txt]"
return

screen changelog():
    tag menu

    use game_menu(_("Changelog"), scroll="viewport"):
        style_prefix "about"
        $ szC="{size=*0.8}{color=#ffee00}\n{u}{b}"
        vbox:
            label "[config.name!t]"
            text _("{size=*1.2}Version [config.version!t]")
            text _("{size=*.5}Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n[renpy.license!t]")
        vbox:
            text "[szC]0.11:"
            text cl11 size 20
            text "[szC]0.10:"
            text cl10 size 20
            text "[szC]0.09:"
            text cl09 size 20
            text "[szC]0.08a:"
            text cl08a size 20
            text "[szC]0.08:"
            text cl08 size 20
            text "[szC]0.07:"
            text cl07 size 20
            text "[szC]0.06:"
            text cl06 size 20
            text "[szC]0.05:"
            text cl05 size 20
            text "[szC]0.04:"
            text cl04 size 20
            text "[szC]0.03:"
            text cl03 size 20
            text "[szC]0.02:"
            text cl02 size 20
            text "[szC]0.01:"
            text "Initial release." size 20
return

screen ShowLoc(cloc, alt):
    zorder 9999
    frame:
        background None
        xysize (1000,200)
        align (0.5, 0.1)
        text "[cloc]" style ("location_textAlt" if alt else "location_text") align (0.5, 0.0)
return
label ShowLocation(cloc="", alt=False):
    $ lc=""
    if cloc==brookvale_id:
        $ lc="Brookvale"
    elif cloc==springhaven_id:
        $ lc="Springhaven"
    elif cloc==oakhill_id:
        $ lc="Oakhill"
    elif cloc==cedargrove_id:
        $ lc="Cedar Grove"
    elif cloc==briarhollow_id:
        $ lc="Briar Hollow"

    if lc!="":
        $ curLOC=cloc
        show screen ShowLoc(lc, alt)
        pause 2.0
        hide screen ShowLoc
return

style pref_menu_content_frame:
    xpos 400
    ypos 30
    xsize 1434
    ysize 767
style location_text:
    size 175
    font "fonts/ldcall.ttf"
    color "#ffffff"
    outlines [(4, "#383838", 1.5, 2)]
style location_textAlt:
    size 175
    font "fonts/ldcall.ttf"
    color "#000000"
    outlines [(4, "#d8d8d8", 1.5, 2)]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
