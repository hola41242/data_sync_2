default chosen_character = None
default chosen_name = ""
default chosen_th = ""
default char_ShowAll = False
default NewFlagText = ""
default ShowPlr = True
init python:
    def GetTime():
        mn, sc = divmod(renpy.get_game_runtime(), 60)
        hr, mn = divmod(mn, 60)
        return '%d:%02d:%02d' % (hr, mn, sc)
    def AddnewPlrFlag(flg):
        if flg!="":
            Plr.Add(flg)
    def AddnewFlag(char, flg):
        if flg!="" and char!=None:
            char.Add(flg)
    def EditScore(char, v):
        char.sc+=v
    def EditSx(char, v):
        char.sx+=v
    def EditLevel(char, v):
        char.L+=v
    def EditCum(char, v):
        char.C+=v
    def ToggleActive(char):
        char.act=not char.act
    def RemoveFlag(char, v):
        char.Del(v)
    def ToggleLover(char):
        char.lvr=not char.lvr

screen AddCharBtn(char2add, ch_name, th=""):
    button:
        if char2add.isActive():
            if char2add.isSexual():
                style "btnLvr"
            else:
                style "btnAct"
        else:
            style "btnNact"
        text "{size=*.5}[ch_name]" align (0.5, 0.5)
        if chosen_character==char2add:
            action SetVariable("chosen_character", None)
        else:
            action SetVariable("chosen_character", char2add), SetVariable("chosen_name", ch_name), SetVariable("chosen_th", th)
return

screen GetNewFlag():
    modal True
    frame:
        style_prefix "popup"
        background Frame("gui/pref_box.png", 10,10,10,10)
        xalign 0.5
        yalign 0.5
        has vbox
        text "Enter Flag:" size 28
        input value VariableInputValue("NewFlagText", True, True) length 20
        hbox:
            spacing 20
            textbutton "OK" action [Function(AddnewFlag, chosen_character, NewFlagText), Hide("GetNewFlag")]
            textbutton "Cancel" action Hide("GetNewFlag")
return

screen GetNewPlrFlag():
    modal True
    frame:
        style_prefix "popup"
        background Frame("gui/pref_box.png", 10,10,10,10)
        xalign 0.5
        yalign 0.5
        has vbox
        text "Enter Flag:" size 28
        input value VariableInputValue("NewFlagText", True, True) length 20
        hbox:
            spacing 20
            textbutton "OK" action [Function(AddnewPlrFlag, NewFlagText), Hide("GetNewPlrFlag")]
            textbutton "Cancel" action Hide("GetNewPlrFlag")
return

screen ShowCharinfo():
    text "[chosen_name]":
        align (0.5, 0.0)
        xfill True
    frame:
        xysize (96, 130)
        xalign 0.98
        ypos 40
        background None
        if chosen_th!="":
            add "gallery/"+chosen_th+"_i.jpg"

    if chosen_character.isActive():
        frame:
            background Solid("#e90e0e00")
            xfill True
            ysize 30
            ypos 40
            imagebutton:
                idle "thumbs/plus.png"
                xpos 0
                yalign 0.5
                action Function(EditScore, chosen_character, 1)
            imagebutton:
                idle "thumbs/minus.png"
                xpos 30
                yalign 0.5
                action Function(EditScore, chosen_character, -1)
            text "{size=*.75}Score: [chosen_character.sc]":
                xpos 60
                yalign 0.5
        frame:
            background Solid("#e90e0e00")
            xfill True
            ysize 30
            ypos 70
            imagebutton:
                idle "thumbs/plus.png"
                xpos 0
                yalign 0.5
                action Function(EditSx, chosen_character, 1)
            imagebutton:
                idle "thumbs/minus.png"
                xpos 30
                yalign 0.5
                action Function(EditSx, chosen_character, -1)
            text "{size=*.75}Sex: [chosen_character.sx]":
                xpos 60
                yalign 0.5

        frame:
            background Solid("#e90e0e00")
            xfill True
            ysize 30
            ypos 100
            imagebutton:
                idle "thumbs/plus.png"
                xpos 0
                yalign 0.5
                action Function(EditLevel, chosen_character, 1)
            imagebutton:
                idle "thumbs/minus.png"
                xpos 30
                yalign 0.5
                action Function(EditLevel, chosen_character, -1)
            text "{size=*.75}Level: [chosen_character.L]":
                xpos 60
                yalign 0.5
        frame:
            background Solid("#e90e0e00")
            xfill True
            ysize 30
            ypos 130
            imagebutton:
                idle "thumbs/plus.png"
                xpos 0
                yalign 0.5
                action Function(EditCum, chosen_character, 1)
            imagebutton:
                idle "thumbs/minus.png"
                xpos 30
                yalign 0.5
                action Function(EditCum, chosen_character, -1)
            text "{size=*.75}CmIn: [chosen_character.C]":
                xpos 60
                yalign 0.5
        frame:
            background Solid("#ffffff00")
            ypos 160
            ysize 150
            grid 3 5:
                spacing 2
                for i in chosen_character.data:
                    frame:
                        background Solid("#4539ee75")
                        textbutton "{size=*.5}[i]":
                            text_color "#fff"
                            action Function(RemoveFlag, chosen_character, i)
            frame:
                background None
                align (0, 1.6)
                ysize 30
                text "{size=*.4}Click on a flag to remove it." align (0.5, 0.5)
        frame:
            background None
            xalign 0
            yalign 1.0
            has grid 1 1
            spacing 5
            button:
                style "btnFlag"
                text "{size=*.5}Add Flag" align (0.5, 0.5)
                action Show("GetNewFlag")
        frame:
            background None
            xalign 1.0
            yalign 1.0
            has grid 1 2
            spacing 5
            button:
                if chosen_character.lvr:
                    style "btnLvr"
                    text "{size=*.5}Sexual" align (0.5, 0.5)
                else:
                    style "btnAct"
                    text "{size=*.5}Friend" align (0.5, 0.5)
                action Function(ToggleLover, chosen_character)
            button:
                style "btnNact"
                text "{size=*.5}Deactivate" align (0.5, 0.5)
                action Function(ToggleActive, chosen_character)
    else:
        frame:
            background None
            xalign 1.0
            yalign 1.0
            has grid 1 1
            spacing 5
            button:
                xalign 1.0
                yalign 1.0
                style "btnAct"
                text "{size=*.5}Activate" align (0.5, 0.5)
                action Function(ToggleActive, chosen_character)
return

screen ShowPlrInfo():
    python:
        def RemFlag(v):
            Plr.Del(v)
    zorder 1000
    frame:
        style "minibg"
        ypos 800
        ysize 200
        xsize 320
        grid 3 5:
            spacing 5
            for i in Plr.data:
                frame:
                    background Solid("#4539eeff")
                    textbutton "{size=*.5}[i]":
                        text_color "#fff"
                        action Function(RemFlag, i)
        button:
            text "Add Flag" size 12 align (0.5, 0.5)
            style "btnFlag"
            align (0, 1.0)
            ysize 30
            action Show("GetNewPlrFlag")
        frame:
            background None
            align (1.0, 1.0)
            ysize 30
            text "{size=*.4}Click on a flag to remove it." align (0.5, 0.5)
return

screen GameConfig():
    python:
        def TogAliTruth():
            if Alison.Has("Knows") or Alison.Has("KnowsAlt"):
                Alison.Del("Knows")
                Alison.Del("KnowsAlt")
                chConfig_AliT=False
            else:
                Alison.Add("Knows")
                chConfig_AliT=True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        ysize 800
        background Frame("gui/pref_box.png", 10,10,10,10)
        padding (20, 20)
        if hasattr(Nettie, 'L') and Nettie.L==-1:
            $ chConfig_NetF = True
        else:
            $ chConfig_NetF = False
        if Alison.Has("Knows") or Alison.Has("KnowsAlt"):
            $ chConfig_AliT=True
        else:
            $ chConfig_AliT=False

        frame:
            style "minibg"
            xysize (470, 700)
            xalign 0.0
            text "{size=*.6}{b}Variables" align (0.5, 0.0)
            vbox:
                ypos 25
                style_prefix "check"
                textbutton _(" {size=*.6}Mary calls you Daddy") action ToggleField(persistent, "MaryDaddy")
                textbutton _(" {size=*.6}You agreed to call Ruth Mommy") action ToggleField(persistent, "RuthPet") xsize 400
                textbutton _(" {size=*.6}You helped Melanie reduce her payments") action ToggleVariable("helpedMel") xsize 450
                textbutton _(" {size=*.6}You sent the documents to Alysha") action ToggleVariable("SentDocs") xsize 450
                textbutton _(" {size=*.6}Miyuka was delivered to Sue") action ToggleVariable("MiyukaDelivered")
                textbutton _(" {size=*.6}Miyuka Ran") action ToggleVariable("MiyukaEscaped")
                textbutton _(" {size=*.6}Miyuka currently in Springhaven") action ToggleVariable("MiyukaSpringhaven") xsize 450
                textbutton _(" {size=*.6}Bill was hospitalized") action ToggleVariable("BillSick")
                textbutton _(" {size=*.6}Alison knows the truth about your job") action ToggleScreenVariable("chConfig_AliT"), Function(TogAliTruth) xsize 450
                textbutton _(" {size=*.6}You told Sue about Jemma's plan") action ToggleVariable("ToldSue") xsize 450

        frame:
            style "minibg"
            xysize (200, 300)
            xpos 505
            text "{size=*.6}{b}Deaths" align (0.5, 0.0)
            vbox:
                ypos 25
                style_prefix "check"
                textbutton _(" {size=*.6}James") action ToggleVariable("JamesD")
                textbutton _(" {size=*.6}Simon") action ToggleVariable("SimonD")
                textbutton _(" {size=*.6}Teddy") action ToggleVariable("TeddyD")
                textbutton _(" {size=*.6}Craig") action ToggleVariable("CraigD")
                textbutton _(" {size=*.6}Prisoner") action ToggleVariable("PrisonerD")

        frame:
            style "minibg"
            xysize (200, 300)
            xpos 740
            text "{size=*.6}{b}Send Noods" align (0.5, 0.0)
            vbox:
                ypos 25
                style_prefix "check"
                textbutton _(" {size=*.6}Hannah") action ToggleVariable("Pix_Hannah")
                textbutton _(" {size=*.6}Millie") action ToggleVariable("Pix_Millie")
                textbutton _(" {size=*.6}Chloe") action ToggleVariable("Pix_Chloe")

        frame:
            style "minibg"
            xysize (430, 300)
            xpos 505
            ypos 330
            text "{size=*.6}{b}Sexual Interaction" align (0.5, 0.0)
            vbox:
                ypos 25
                style_prefix "check"
                textbutton _(" {size=*.6}Violet and Millie") action ToggleField(persistent, "MilandVi")
                textbutton _(" {size=*.6}Melanie and Gabby") action ToggleField(persistent, "MelandGab")
                textbutton _(" {size=*.6}Millie and Cara") action ToggleField(persistent, "MilandCar")
return

screen Editor():
    zorder 10
    $ clr_o="#fbff00"
    $ clr_c="#ffffff"
    frame:
        xalign 1.0
        yalign 0
        xsize 180
        ysize 300
        background Frame("gui/pref_box.png", 10,10,10,10)
        padding (10, 10)
        has vbox
        text "{size=*.6}Briar Hollow: [briarhollow_ch]":
            color (clr_o if briarhollow_open else clr_c)
        text "{size=*.6}Brookridge: [brookridge_ch]":
            color (clr_o if brookridge_open else clr_c)
        text "{size=*.6}Brookvale: [brookvale_ch]":
            color (clr_o if brookvale_open else clr_c)
        text "{size=*.6}Cedar Grove: [cedargrove_ch]":
            color (clr_o if cedargrove_open else clr_c)
        text "{size=*.6}Chestnut: [chestnut_ch]":
            color (clr_o if chestnut_open else clr_c)
        text "{size=*.6}Eastfield: [eastfield_ch]":
            color (clr_o if eastfield_open else clr_c)
        text "{size=*.6}Lakeshore: [lakeshore_ch]":
            color (clr_o if lakeshore_open else clr_c)
        text "{size=*.6}Milfork: [milfork_ch]":
            color (clr_o if milfork_open else clr_c)
        text "{size=*.6}Northcrest: [northcrest_ch]":
            color (clr_o if northcrest_open else clr_c)
        text "{size=*.6}Oakhill: [oakhill_ch]":
            color (clr_o if oakhill_open else clr_c)
        text "{size=*.6}Springhaven: [springhaven_ch]":
            color (clr_o if springhaven_open else clr_c)
    $ y_POS=35
    if not hasattr(Sarah, "lvr"):
        frame:
            style "minibg"
            xysize (400, 150)
            text "{size=*.6}Old save detected. Editor disabled." align (0.5, 0)
            text "{size=*.5}[errorsave]" ypos 30
    else:
        frame:
            align (0, 0)
            xsize 330
            ysize 1080
            style "minibg"
            grid 3 1:
                ypos 10
                spacing 5
                xalign 0.5
                frame:
                    style "btnNact"
                    text "{size=*.5}Not Active" align (0.5, 0.5)
                frame:
                    style "btnAct"
                    text "{size=*.5}Active" align (0.5, 0.5)
                frame:
                    style "btnLvr"
                    text "{size=*.5}Sexual" align (0.5, 0.5)
            grid 3 11:
                ypos 60
                spacing 5
                xalign 0.5
                if curLOC==springhaven_id or char_ShowAll:
                    use AddCharBtn(Sarah, "Sarah", "sph/sarah")
                    use AddCharBtn(Mary, "Mary", "sph/mary")
                    use AddCharBtn(Cara, "Cara", "sph/cara")
                    use AddCharBtn(Alison, "Alison", "sph/alison")
                    use AddCharBtn(Alex, "Alex", "sph/alex")
                    use AddCharBtn(Alysha, "Alysha", "sph/alysha")
                    use AddCharBtn(Melanie, "Melanie", "sph/melanie")
                    use AddCharBtn(Gabby, "Gabby", "sph/gabrielle")
                    use AddCharBtn(Sue, "Sue", "sph/sue")
                    use AddCharBtn(Nicole, "Nicole", "sph/nicole")
                    use AddCharBtn(Kiyomi, "Kiyomi", "sph/kiyomi")
                    use AddCharBtn(Christina, "Christina", "sph/christina")
                if curLOC==cedargrove_id or char_ShowAll:
                    use AddCharBtn(Nettie, "Nettie", "cdg/nettie")
                    use AddCharBtn(Elizabeth, "Elizabeth", "cdg/elizabeth")
                    use AddCharBtn(Hayley, "Hayley", "cdg/hayley")
                    use AddCharBtn(Chloe, "Chloe", "cdg/chloe")
                if curLOC==oakhill_id or char_ShowAll:
                    use AddCharBtn(Violet, "Violet", "okh/violet")
                    use AddCharBtn(Millie, "Millie", "okh/millie")
                    use AddCharBtn(Lucy, "Lucy", "okh/lucy")
                    use AddCharBtn(Hannah, "Hannah", "okh/hannah")
                if curLOC==lakeshore_id or char_ShowAll:
                    use AddCharBtn(Ruth, "Ruth", "lks/ruth")
                    use AddCharBtn(Melissa, "Melissa", "lks/melissa")
                    use AddCharBtn(Dawn, "Dawn", "lks/dawn")
                    use AddCharBtn(Blaze, "Blaze", "lks/blaze")
                if curLOC==brookvale_id or char_ShowAll:
                    use AddCharBtn(Jemma, "Jemma", "brv/jemma")



                if curLOC==northcrest_id or char_ShowAll:
                    use AddCharBtn(Miyuka, "Miyuka", "ntc/miyuka")
                    use AddCharBtn(Mitsui, "Mitsui", "ntc/mitsui")
                if curLOC==briarhollow_id or char_ShowAll:
                    use AddCharBtn(Amelia, "Amelia", "brh/amelia")
                if curLOC==milfork_id or char_ShowAll:
                    use AddCharBtn(Priya, "Priya", "mlf/priya")
            frame:
                ypos 400
                xfill True
                ysize 400
                if chosen_character!=None:
                    style "minibg"
                    use ShowCharinfo()
                else:
                    background None
            button:
                text "Player Flags" size 12 align (0.5, 0.5)
                style "minibg"
                xalign 0
                yalign 0.97
                ysize 30
                if ShowPlr:
                    action Show("ShowPlrInfo"), SetScreenVariable("ShowPlr", False)
                else:
                    action Hide("ShowPlrInfo"), SetScreenVariable("ShowPlr", True)
            frame:
                background None
                align (1.0, 0.97)
                text "{size=*.5}Save Version: [SaveVers]" align (0.5, 0.5)

            frame:
                background None
                $ t= GetTime()
                align (1.0, 0.95)
                text "{size=*.5}Time Played: [t]" align (0.5, 0.5)
            button:
                style "minibg"
                xalign 0.5
                yalign 1.0
                xfill True
                ysize 30
                if char_ShowAll:
                    text "Showing All" size 16 align (0.5,0.5)
                    action SetScreenVariable("char_ShowAll", False)
                else:
                    text "Showing Current City" size 16 align (0.5,0.5)
                    action SetScreenVariable("char_ShowAll", True)

        frame:
            xalign 1.0
            yalign 1.0
            style "minibg"
            has vbox
            textbutton "{size=*.6}Variables":
                text_color "#FFFFFF"
                action ToggleScreen('GameConfig')
return

style minibg:
    background Frame("gui/pref_box_sml.png", 10,10,10,10)
    padding (5, 5)

style btnLvr:
    background Solid("#f36be1ff")
    xsize 100
    ysize 20

style btnAct:
    background Solid("#05b113f3")
    xsize 100
    ysize 20

style btnNact:
    background Solid("#505a58ff")
    xsize 100
    ysize 20

style btnFlag:
    background Solid("#db1710ff")
    xsize 100
    ysize 20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
