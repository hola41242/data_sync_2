default persistent.brookvale_active = False
default brookvale_id = "BV"
default brookvale_ch = 1
default brookvale_open = False
default brookvale_info = ["", "Sue sent me the address of the location she's {i}ordered{/i}  me to go before I return home."]

label UpdateBrookValeData:

return

default persistent.JemmaLocked = True
default Jemma_name = "Jemma"
define jem = Character("[Jemma_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="jemma")
image side jemma cell = side+"jemma_c.png"
default Jemma = Stats()


default Mathew_name = ""
define mat = Character("[Mathew_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="mathew")

default Butch_name = ""
define bu = Character("[Butch_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="butch")

default Dwayne_name = ""
define dwa = Character("[Dwayne_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="dwayne")

default Esteban_name = ""
define est = Character("[Esteban_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="est")

default Grant_name = ""
define gra = Character("[Grant_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="grant")

default Bruno_name = "Dog"
define dog = Character("[Bruno_name]", what_color=Wht, what_outlines=[(1.5, Blk, 1.5, 1)], who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="")
screen BrookVale_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "brv", "jemma", Jemma_Replay, persistent.JemmaLocked, "Local boss for the company.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
