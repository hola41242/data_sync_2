label Brookvale_Start1:
    $ persistent.brookvale_active=True
    scene 05_0080 with Fade(0, 3, 3)
    play sound "car3.mp3"
    scene 05_0081 with dis1
    scene 05_0082 with dis1
    scene 05_0083 with dis1
    scene 05_0084 with dissolve
    mct "What the hell am I supposed to do here??"
    scene 05_0085 with dissolve
    mct "Bang on some doors, see if anyone's around, I guess?"
    unk "You can't park there.\nThis is private property."
    scene 05_0086 with dissolve
    mc "Uhh... I'm looking for Jemma."
    mat "Why?"
    mc "I was sent here by Sue from Springhaven."
    scene 05_0087 with dissolve
    mat "What's your name?"
    mc "[mc]."
    scene 05_0088 with dissolve
    mat "He's here."
    scene 05_0089 with dissolve
    mat "Come on."
    scene 05_0090 with fade
    pause
    scene 05_0091 with fade
    mat "Boss."
    $ persistent.JemmaLocked=False
    $ Jemma_name="Jemma"
    $ Jemma.Activate("Jemma")
    scene 05_0092 with dissolve
    jem "I was told you'd be here {i}yesterday{/i}."
    mc "Then you were misinformed."
    scene 05_0093 with dissolve
    jem "Yeah, your weird-ass boss warned me you had an attitude problem."
    scene 05_0094 with dissolve
    jem "Makes no difference to me how late you are."
    scene 05_0095 with dissolve
    jem "Mathew."
    $ Mathew_name="Mathew"
    scene 05_0096 with dissolve
    jem "Your cargo, on the other hand..."
    mc "Cargo??"
    play sound "doorsopen.mp3"
    scene 05_0097 with dis1
    scene 05_0098 with dis1
    mc "What the fuck?"
    scene 05_0099 with dissolve
    mc "What the hell is this??"
    scene 05_0100 with dissolve
    mc "Who is she?"
    jem "Who gives a shit?\nJust deliver her to your boss as instructed."
    scene 05_0101 with dissolve
    mat "Come on!"
    scene 05_0102 with dissolve
    $ Miyuka_name=""
    $ Plr.Add("GotPackage")
    mi "Get off me!"
    scene 05_0103 with dissolve
    scene 05_0104 with dissolve
    play sound "fall.mp3"
    scene 05_0105 with hpunch
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Help her up":
                $ tCh=True
            "Ignore her":
                pass
    else:
        $ tCh=True
    if tCh:
        $ Miyuka.Score(1)
        mc "Jesus!"
        scene 05_0106 with dissolve
        mc "What the fuck is wrong with you?!"
        jem "Aww! We have a humanitarian with us![lol]"
        scene 05_0107 with dissolve
        mi "Leave me alone!"
        mc "It's okay, I just want to help you up."
        mi "{b}GET AWAY FROM ME!{/b}"
        scene 05_0108 with dissolve
        jem "[lol]"
    scene 05_0109 with dissolve
    jem "Put her in his vehicle."
    scene 05_0110 with dissolve
    mi "NO! LET ME GO!!"
    if Miyuka.hasScore(1):
        scene 05_0111 with dissolve
        mc "STOP!\nShe has legs, let her use them!"
        scene 05_0112 with dissolve
        mat "Take your fuckin' hand off me."
        menu:
            "Back down":
                scene 05_0113 with dissolve
                mc "Just take it easy on her, man."
                mat "Fuck off."
            "[wk_y]Don't back down":
                $ Miyuka.Score(1)
                $ Plr.Add("Mat_Hit")
                scene 05_0114 with dissolve
                play sound "hit01.mp3"
                scene 05_0115 with vpunch
                scene 05_0116 with dissolve
                call Emotion (mat, "Ugghh", "You motherfucker!")
                scene 05_0117 with dissolve
                jem "{b}ENOUGH!{/b}"
                scene 05_0118 with dissolve
                mc "Nobody's gonna hurt you, it's okay. Stand up."
                jem "Mathew, {i}escort{/i} her to his vehicle."
                scene 05_0119 with dissolve
                jem "An attitude problem {b}and{/b} a hero complex!"
                jem "Quite the combination!\nI like it! Hah!"
                scene 05_0120 with dissolve
                mc "I'm no hero.\nI'm just not an asshole, unlike your friend."
                scene 05_0121 with dissolve
                jem "Hmmm, modest, too![lol]"
                call Brookvale_NiceAss ()
    if not Miyuka.hasScore(1):
        scene 05_0138 with dissolve
        mc "You could've at least cleaned her up a bit first!"
        scene 05_0139 with dissolve
        jem "Keep a window open, you'll be fine."
        call Brookvale_NiceAss ("a")
    elif not Miyuka.hasScore(2):
        scene 05_0138 with dissolve
        mc "What's his fuckin' deal?"
        scene 05_0139 with dissolve
        jem "He doesn't like pussy."
        call Brookvale_NiceAss ("a")
    scene 05_0140 with fade1
    scene 05_0141 with dissolve
    pause 0.5
    scene 05_0142 with dissolve
    if Plr.Has("Mat_Hit"):
        mat "Pull a stunt like that again, and you're a dead man."
        mc "{i}Suuure{/i}, Buddy."
    elif Miyuka.hasScore(1):
        mat "See ya 'round, Pussy."
    else:
        mat "See ya 'round."
        mc "See ya."
    scene 05_0143 with dissolve
    mct "What the hell have I got myself into now??"
    $ persistent.MiyukaLocked=False
    $ Miyuka.Activate("Miyuka")
    scene 05_0144 with dissolve
    mct "Wonder how long she's been stuck in that cage?"
    $ tCh=None
    if EzModeActive:
        $ tCh=True
        call EzModeAsk ("Miyuka")
        if _return:
            $ Miyuka.Add("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Talk to her":
                $ tCh=True
            "Drive away":
                pass
    if tCh:
        $ Miyuka.Score(1)
        $ Miyuka.Add("Food")
        mc "Are you okay?"
        mi "..."
        scene 05_0145 with dissolve
        mc "My name's [mc]. What's yours?"
        mi "..."
        mc "Hungry?"
        scene 05_0146 with dissolve
        mi "..."
        mc "Okay. Let's go get you some food."
    scene 05_0147 with Fade(1, 0.5, 0.5)
    play sound "car_pull.mp3"
    scene 05_0148 with dis1
    scene 05_0149 with dis1
    pause 0.5
    if Miyuka.Has("Food"):
        call Brookvale_FeedMiyuka
    jump Brookvale_Leave
return

label Brookvale_FeedMiyuka:
    scene 05_0150 with Fade(3, 2, 2)
    mc "Here's the deal..."
    scene 05_0151 with dissolve
    mc "I'm going in there to get {b}you{/b} some food, and I can't bring you with me looking like... that."
    mc "I'm gonna trust you to stay in the truck.\nPlease don't make me regret it."
    scene 05_0152 with dissolve
    mc "I'll be watching you the whole time, and I'm a fast runner."
    scene 05_0153 with dissolve
    mct "Please, don't fuckin' run."
    call CenterText ("A few minutes later...", True)
    scene 05_0154 with Fade(1, 1, 2)
    mct "Okay..."
    scene 05_0155 with dissolve
    mct "... Still there."
    scene 05_0156 with Fade(1, 0.5, 0.5)
    mc "I didn't know what you liked.\nGot you a burger and a soda."
    mc "Grabbed you some cheap clothes. A pack of wipes, too."
    scene 05_0157 with dissolve
    mc "There's an old gas station just outside town; it's quiet and has a bathroom..."
    scene 05_0158 with dissolve
    mc "We'll stop there after you've eaten, and you can clean yourself up."
    scene 05_0159 with dissolve
    mi "[whi]Mmmm."
    scene 05_0160 with Fade(1, 0.5, 0.5)
    play sound "car.mp3"
    scene 05_0161 with dis1
    scene 05_0162 with dis1
    scene 05_0163 with dis1
    scene 05_0164 with dis1
    scene 05_0165 with fade3
    play sound "car3.mp3"
    scene 05_0166 with dis1
    scene 05_0167 with dis1
    scene 05_0168 with dis1
    scene 05_0169 with dissolve
    mc "Wait here a minute."
    scene 05_0170 with Fade(1, 0.5, 0.5)
    mc "HELLO?\nANYONE IN HERE?"
    scene 05_0171 with dissolve
    mc "Okay, we're good; it's empty."
    scene 05_0172 with dissolve
    mc "Be quick."
    scene 05_0173 with fade2
    pause
    scene 05_0174 with Fade(2, 2, 1)
    scene 05_0175 with dis1
    scene 05_0176 with dissolve
    mc "That's better!"
    scene 05_0177 with Fade(1, 0.5, 0.5)
    play sound "car_pull.mp3"
    scene 05_0178 with dis1
    scene 05_0179 with dis1
    scene 05_0180 with dis1
    scene 05_0181 with dis1
    scene black with Fade(3, 2, 2)
return

label Brookvale_NiceAss(aa=""):
    show expression "05_0122" + aa with dissolve
    jem "Daaamn! You have a {i}fiiine{/i} ass!"
    show expression "05_0123" + aa with dissolve
    jem "Wanna fuck?"
    if EzModeActive:
        call EzModeAsk ("Jemma")
        if _return:
            $ Jemma.Add("EZ")
    $ tCh=None
    if not EzModeActive:
        menu:
            "Hell yeah!":
                pass
            "[wk_y]Nope":
                $ tCh=True
    else:
        $ tCh=True
    if tCh:
        $ Jemma.Score(1)
        show expression "05_0129" + aa with dissolve
        show expression "05_0130" + aa with dissolve
        mc "No thanks."
        show expression "05_0131" + aa with dissolve
        jem "Oh! You're gay?"
        mc "You presume I'm gay because I don't wanna have sex with you?"
        jem "Well... yeah."
        mc "Sorry to burst your bubble, but no, I'm not."
        show expression "05_0132" + aa with dissolve
        jem "Prove it..."
        show expression "05_0133" + aa with dissolve
        jem "Eat my pussy!"
        show expression "05_0134" + aa with dissolve
        mc "I don't need to prove {i}shit{/i} to you, Sweetheart."
        show expression "05_0135" + aa with dissolve
        mc "And I'm not hungry."
        scene 05_0136 with dissolve
        jem "I ain't your fuckin' {i}sweetheart{/i}!"
        scene 05_0137 with dissolve
        jem "{b}Get the fuck out of my warehouse.{/b}"
    else:
        show expression "05_0124" + aa with dissolve
        jem "[lol]"
        show expression "05_0125" + aa with dissolve
        jem "That {i}tiny{/i} sliver of respect I had for you? It just vanished."
        show expression "05_0126" + aa with dissolve
        jem "Fuckin' guys!! You're all the same!"
        jem "You don't even like me, but mention pussy, and you {i}all{/i} fall to your knees![lol]"
        scene 05_0127 with dissolve
        jem "Get the fuck out of my warehouse."
        scene 05_0128 with dissolve
        pause
return

label Brookvale_Leave:
    scene black with Fade(1,0.5, 1)
    $ brookvale_open=False
    $ brookvale_ch+=1
    jump ShowMap
return

label Brookvale_Delivery:
    call CenterText ("Later that day...")
    $ curLOC=brookvale_id
    scene 09_0909 with Fade(1, 1, 2)
    pause 0.5
    if BillSick:
        scene 09_0910 with dis1
        scene 09_0911 with dis1
        scene 09_0912 with dis1
        mat "WHOA! STOP!"
        mat "YOU NEED TO REVERSE IT IN!!"
        if not Miyuka.Has("Truck"):
            mc "[whi]Goddamnit."
        else:
            scene 09_0913 with dissolve
            mc "[whi]Goddamnit."
            scene 09_0914 with dissolve
            call Emotion (mi, "Groan", "What's going on?")
            mc "Look who finally decided to wake up!"
            scene 09_0915 with dissolve
            mi "Wh... What are we doing here??\nYou said we were going to Springhaven!"
            mc "We are.\nThis is where I have to drop the trailer."
            scene 09_0916 with dissolve
            mi "I... I don't like it here!"
            mc "Don't worry.\nIt won't take long, and we'll be on our way."
        scene 09_0917 with fadehold
    else:
        scene 09_0917 with dis1
    pause 0.5
    scene 09_0918 with dis1
    pause 0.5
    scene 09_0919 with dis1
    pause 0.5
    scene 09_0920 with dis1
    pause 0.5
    scene 09_0921 with dissolve
    pause
    $ fm=False
    if BillSick:
        if not Jemma.isActive():
            $ Jemma_name=""
        scene 09_0922 with dissolve
        jem "About damn time!"
        scene 09_0923 with dissolve
        jem "Our driver had to leave!\nDo you know how much trouble this delay has caused us?!"
        if not Jemma.isActive():
            $ fm=True
            mc "You Jemma?\nI thought Sue was gonna call you?"
            jem "Yes, I am, and yes, she did.\nBut unless your weird-ass boss has a time machine, a phone call doesn't help much, does it?"
            $ Jemma_name="Jemma"
            $ persistent.JemmaLocked=False
            $ Jemma.Activate("Jemma")
        mc "Sorry. Nothing I can do about it."
        scene 09_0924 with dissolve
        if fm:
            jem "Yeah, she told me to expect an attitude problem."
        mc "Why do you need another driver?\nI was told to deliver it here?"
        jem "You drop it here, and {i}our{/i} driver takes it where it needs to go."
        jem "{i}He{/i} doesn't know where it came from, and {i}you{/i} don't know where it ends up."
        scene 09_0925 with dissolve
        jem "You need to take that one back with you."
        mc "Okay."
        scene 09_0926 with dissolve
        jem "Mathew, give him a hand."
        mat "Yes Boss."
        scene 09_0927 with fadehold
        pause
    else:
        if Miyuka.Has("Truck"):
            scene 09_0928 with dissolve
            mc "She still asleep?"
            bill "Yeah."
            scene 09_0929 with dissolve
            bill "Want me to wake her?"
            mc "Nah, leave her."
        scene 09_0930 with dissolve
        bill "Okay. Come on.\nLet's finish up here so we can get home."
        bill "Mary doesn't like me getting back late. She worries."
        scene 09_0931 with dissolve
        jem "About damn time, Bill!"
        scene 09_0932 with dissolve
        bill "Sorry, Jem."
        scene 09_0933 with dissolve
        jem "Our driver had to leave already!\nDo you know how much trouble this delay has caused us?!"
        bill "Yeah, I know.\nGot here as fast as I could!"
        bill "How about I take it the full way?"
        scene 09_0934 with dissolve
        jem "C'mon Bill, {i}you know{/i} it doesn't work that way."
        jem "{i}My guy{/i} doesn't know where it came from, and {i}you{/i} don't know where it ends up."
        scene 09_0935 with dissolve
        bill "Jemma, this is [mc]."
        scene 09_0936 with dissolve
        if not Jemma.isActive():
            mc "Hi."
            jem "Your name... Do I know you?"
            jem "Ohh, right!\nYou're the guy who was supposed to collect the girl from us!"
            scene 09_0937 with dissolve
            jem "Heard your weird-ass boss was pissed![lol]"
            mc "Uhh... yeah."
            $ Jemma_name="Jemma"
            $ persistent.JemmaLocked=False
            $ Jemma.Activate("Jemma")
        else:
            jem "We've already met."
            scene 09_0938 with dissolve
            jem "He didn't impress me."
            bill "Uhh... okay."
        scene 09_0939 with dissolve
        bill "C'mon, let's get to work."
        scene 09_0940 with dissolve
        jem "Don't forget to take the empty one back with you."
        bill "Got it."
        scene 09_0927 with fadehold
        pause
    scene 09_0941 with fadehold
    play sound "truck02.mp3"
    scene 09_0942 with dissolve
    scene 09_0943 with dissolve
    scene 09_0944 with dissolve
    scene 09_0945 with dissolve
    scene 09_0946 with dissolve
    scene 09_0947 with dissolve
return

label Brookvale_SecondDelivery:
    scene 14_0136 with Fade(0, 4, 3)
    scene 09_0919 with dis1
    scene 09_0920 with dis1
    scene 14_0137 with dis1
    jem "You're late!"
    scene 14_0138 with dissolve
    mc "Can't control the traffic, Sweetheart."
    scene 14_0139 with dissolve
    mc "Where's your guy?"
    jem "Mathew?"
    jem "Asshole bailed on me!"
    scene 14_0140 with dissolve
    jem "Went to Cedar Grove, didn't come back."
    jem "Works directly for Hank now."
    scene 14_0141 with dissolve
    jem "So, it just so happens I'm looking for a new right-hand man.\nInterested?"
    mc "No thanks."
    scene 14_0142 with dissolve
    jem "Don't tell me you {b}like{/b} working for that crazy bitch?!"
    scene 14_0143 with dissolve
    mc "Wouldn't I be just swapping one crazy bitch for another?"
    jem "[lol]"
    scene 14_0144 with dissolve
    jem "Oh, Honey... Only place I'm crazy is in the {i}bedroom{/i}!"
    scene 14_0145 with dissolve
    jem "Ten minutes alone with me and you wouldn't even remember {i}her{/i} name."
    scene 14_0146 with dissolve
    jem "Look at my lips. So soft and warm."
    jem "Imagine them gently, slowly, stroking your cock."
    scene 14_0147 with dissolve
    jem "My tongue dancing over every inch."
    scene 14_0148 with dissolve
    jem "Every drop of your cum sliding down my grateful throat."
    scene 14_0149 with dissolve
    jem "You {i}really{/i} want to turn that down?"
    $ tCh=False
    if not EzModeActive:
        menu:
            "Hell no!":
                pass
            "[wk_y]Yep":
                $ tCh=True
    else:
        $ tCh=True
        mc "Yep."
    if tCh:
        scene 14_0150 with dissolve
        $ Jemma.Score(1)
        jem "Your loss."
    else:
        scene 14_0150 with dissolve
        jem "[lol]"
        jem "Typical guy. Thinking with your dick!"
    scene 14_0151 with dissolve
    jem "Finish your damn work and get the fuck outta my warehouse."
    scene 14_0152 with fade1
    scene 14_0153 with dis1
    scene 14_0154 with dis1
    scene 14_0155 with dis1
    scene 14_0156 with dis1
    scene black with Fade(3, 0, 0)
return

label Brookvale_RightHandMan:
    call CenterText ("Some time later.")
    scene 17_0670 with Fade(0, 0, 2)
    call ShowLocation (brookvale_id)
    scene 17_0671 with dis1
    scene 17_0672 with dis1
    scene 17_0673 with dis1
    scene 17_0674 with dis1
    scene 17_0675 with dis1
    scene 17_0676 with dissolve
    mct "Hmm... What's goin' on in here?"
    scene 17_0677 with dissolve
    bu "Mother fucker!"
    bu "Who the fuck are you??"
    scene 17_0678 with dissolve
    mc "Easy there, tiger. I'm here to see Jemma."
    scene 17_0679 with dissolve
    dwa "How the hell did you get in here?"
    mc "Through the magic hole in the wall... You know, that thing some people call a door."
    scene 17_0680 with dissolve
    dwa "She told you to lock it, Butch!"
    $ Butch_name="Butch"
    scene 17_0681 with dissolve
    jem "Jesus fuckin' Christ!\nAre you kidding me?!"
    jem "How many times do I need to tell you to {b}SECURE.THE.BUILDING{/b} before unloading?!!"
    bu "Sorry Boss."
    scene 17_0682 with dissolve
    jem "BACK TO WORK!"
    bu "But... What about this guy?"
    scene 17_0683 with dissolve
    dwa "Goddamn, Butch! What the fuck is wrong with you??"
    scene 17_0684 with dissolve
    pause 0.5
    scene 17_0685 with dissolve
    pause 0.5
    scene 17_0686 with dissolve
    jem "Did you question me, mothafucka??"
    scene 17_0687 with dissolve
    jem "Do {b}I{/b} answer to {b}YOU{/b}, bitch?"
    bu "No, Boss! Sorry!"
    jem "Pussy."
    scene 17_0688 with dissolve
    jem "Go outside and guard that fuckin' door like your life depends on it."
    scene 17_0689 with dissolve
    jem "Dwayne! Don't make me repeat myself!"
    $ Dwayne_name="Dwayne"
    dwa "No Ma'am!"
    scene 17_0690 with dissolve
    jem "What the fuck are you doing here?"
    mc "I was wondering if the job offer was still on the table."
    scene 17_0691 with dissolve
    jem "Wow. You've got balls, I'll give you that."
    jem "No, it's not. So you can fuck off back to Springhaven."
    scene 17_0692 with dissolve
    mc "Jemma, c'mon!"
    scene 17_0693 with dissolve
    mc "Jemma!"
    scene 17_0694 with dissolve
    scene 17_0695 with dis1
    jem "How much longer's it gonna take?"
    dwa "We're almost done."
    scene 17_0696 with dissolve
    jem "We're behind schedule.\nI want these trucks on the move NOW!"
    dwa "Yes Boss."
    scene 17_0697 with dissolve
    dwa "Move it, guys!"
    mc "Hmm, I thought cisterns were used for shipping liquids, not boxes."
    scene 17_0698 with dissolve
    jem "That's the point."
    scene 17_0699 with dissolve
    jem "Hank believes it's less suspicious."
    scene 17_0700 with dissolve
    jem "He's always been a paranoid son of a bitch."
    scene 17_0701 with dissolve
    jem "He had a bunch of these trailers custom-made."
    jem "All identical, with a hidden compartment for the merchandise."
    scene 17_0702 with dissolve
    jem "The outer shell actually contains petroleum, should the authorities pull the driver over and request a sample."
    jem "We've yet to lose a single shipment, so guess I can't argue with his logic!"
    scene 17_0703 with dissolve
    mc "So what {i}are{/i} we shipping?"
    scene 17_0704 with dissolve
    jem "[lol]{w=0.5}{nw}"
    scene 17_0705 with dissolve
    jem "What are you doin' here, [mc]?"
    scene 17_0706 with dissolve
    mc "Applying for a job."
    scene 17_0707 with dis1
    pause 0.5
    scene 17_0708 with dissolve
    jem "Sorry. We have no vacancies."
    scene 17_0709 with dissolve
    mc "You want me to beg, is that it?"
    scene 17_0710 with dissolve
    jem "I want you to {b}apologize{/b}."
    scene 17_0711 with dissolve
    mc "Oh, your majesty, {b}please{/b} accept my most humble apology!"
    mc "I was a fool to turn down your generous offer of employment."
    scene 17_0712 with dissolve
    mc "I beg your forgiveness!"
    mc "And I pledge my fealty to our {b}one true queen{/b}!"
    scene 17_0713 with dissolve
    jem "[lol]You're a fuckin' asshole."
    scene 17_0714 with dissolve
    gra "Is that dude {i}proposing{/i}??"
    est "Crazy son of a bitch!"
    scene 17_0715 with dissolve
    est "Who is that guy?"
    dwa "Never seen him before."
    scene 17_0716 with dissolve
    jem "ARE YOU TAKIN' A DAMN BREAK??!"
    est "[whi]Shit!"
    scene 17_0717 with dissolve
    dwa "No, Boss!"
    gra "Fuck, Esteban! Move your ass!"
    $ Esteban_name="Esteban"
    scene 17_0718 with dissolve
    jem "Get the hell up."
    mc "Not until you've accepted my apology!"
    jem "Jesus, fine! It's accepted!\nNow get up!"
    scene 17_0719 with dissolve
    jem "You're serious about the job?"
    mc "Yeah."
    jem "Why?"
    scene 17_0720 with dissolve
    mc "Said it yourself - Sue's crazy."
    mc "I've reached my limit with her."
    scene 17_0721 with dissolve
    jem "She won't be happy with your disloyalty."
    mc "That makes it all the sweeter for you, right?"
    scene 17_0722 with dissolve
    jem "And what happens when you get tired of working for {b}me{/b}?\nI need someone I can count on."
    mc "You {b}can{/b} count on me."
    jem "I'm sure Sue would disagree with that statement."
    scene 17_0723 with dissolve
    dwa "Sorry to disturb you, Boss.\nWe're ready to move out."
    jem "Good."
    scene 17_0724 with dissolve
    jem "No stops along the way."
    dwa "Got it."
    scene 17_0725 with dissolve
    gra "Uhh... There's a truck blocking us in."
    mc "That's mine. I'll move it."
    scene 17_0726 with dissolve
    jem "Don't bother. You're leaving."
    scene 17_0727 with dissolve
    jem "Butch stays."
    jem "He guards that fuckin' door until I say otherwise."
    dwa "Yes Boss."
    scene 17_0728 with dissolve
    jem "Let's go."
    scene 17_0729 with dissolve
    pause 0.5
    scene 17_0730 with dis1
    pause 0.5
    scene 17_0731 with dissolve
    jem "Follow me."
    mc "Okay."
    scene 17_0732 with dis1
    pause 0.5
    scene 17_0733 with dis1
    pause 0.5
    scene 17_0734 with dis1
    pause 0.5
    scene 17_0735 with dis1
    pause 0.5
    call Brookvale_RightHandManP2
    jump Springhaven_06_ReturnFromBrookvale
return

label Brookvale_RightHandManP2:
    scene 17_0736 with fade2
    pause 0.5
    scene 17_0737 with dis1
    scene 17_0738 with dis1
    scene 17_0739 with dis1
    scene 17_0740 with dis1
    scene 17_0741 with dis1
    scene 17_0742 with dis1
    mc "Where are we?"
    jem "Home."
    scene 17_0743 with dissolve
    mc "{i}Yours{/i}??"
    jem "Yeah. Why?"
    scene 17_0744 with dissolve
    jem "What were you expecting?"
    mc "I dunno..."
    scene 17_0745 with dissolve
    mc "... A dungeon, maybe?"
    jem "[lol]"
    scene 17_0746 with dissolve
    mc "Why'd you bring me here?"
    jem "I needed to get home, and I haven't made up my mind about you yet."
    scene 17_0747 with dissolve
    jem "Come on in."
    mc "Thanks."
    scene 17_0748 with dissolve
    jem "Have you told Sue about your plan to jump ship?"
    mc "Not yet."
    scene 17_0749 with dissolve
    mc "Damn! That's one huge dog!"
    jem "Yeah. A huge pain in the ass, too."
    scene 17_0750 with dissolve
    jem "Take a seat."
    jem "Don't worry, he's friendly."
    scene 17_0751 with dis1
    scene 17_0752 with dis1
    call Emotion (dog, "Panting")
    mc "Hello!"
    mc "Heh... This guy gets any bigger, you'll need a bigger house!"
    scene 17_0753 with dissolve
    jem "Hell nah!\nHe isn't mine; I'm just looking after him for a friend."
    mc "Ahh, right."
    scene 17_0754 with dissolve
    jem "You okay with him for a few minutes?\nI need to get changed."
    mc "Yeah."
    scene 17_0755 with dissolve
    call Emotion (mc, "Baby Talk", "You a good boy? Yeah, you're a good boy!")
    jem "He likes it when you pull on his ears!"
    scene 17_0756 with dissolve
    call Emotion (mc, "Baby Talk", "Aww, you want me to pull your ear?")
    dog "[mo]WOOF!"
    scene 17_0757 with dissolve
    call Emotion (mc, "Baby Talk", "Yeah, you like that?")
    call Emotion (mc, "Baby Talk", "Yes you do! Such a good boy!")
    scene 17_0758 with dissolve
    mct "Weird... 'Pull on his ear'..."
    mct "... That's one of Priya's demands in the proof of life photo."
    scene 17_0759 with dissolve
    mct "You're shitting me!?"
    scene 17_0760 with dissolve
    pause
    $ Bruno_name="Bruno"
    scene 17_0761 with dissolve
    mc "[whi]So you're Bruno, huh?"
    scene 17_0762 with dis1
    scene 17_0763 with dis1
    mc "[whi]How about a quick photo, boy?"
    scene 17_0764 with dis1
    play sound "photo.mp3"
    pause 0.5
    scene 17_0765 with dis1
    play sound "photo.mp3"
    pause 0.5
    scene 17_0766 with dis1
    play sound "photo.mp3"
    pause 0.5
    scene 17_0767 with dis1
    mc "Good boy."
    scene 17_0768 with dis1
    call Emotion (dog, "Panting")
    scene 17_0769 with dissolve
    jem "I've had a brainwave."
    mc "Yeah?"
    scene 17_0770 with dissolve
    jem "C'mon boy, {b}down{/b}."
    scene 17_0771 with dissolve
    jem "That's it, come on."
    scene 17_0772 with dissolve
    jem "Go lie down. {b}Bed{/b}!"
    scene 17_0773 with dis1
    scene 17_0774 with dis1
    scene 17_0775 with dis1
    jem "I want you to work for me."
    mc "{i}That's{/i} your brainwave?"
    scene 17_0776 with dissolve
    jem "No..."
    jem "I don't want you to quit working for Sue."
    scene 17_0777 with dissolve
    mc "How the hell does that work??"
    jem "Well... I don't need you here full time..."
    scene 17_0778 with dissolve
    jem "And when you're not here, I want you to keep an eye on what {i}she's{/i} up to."
    mc "Why?"
    scene 17_0779 with dissolve
    jem "Because I don't fuckin' trust her... And neither does Hank."
    jem "She's forever scheming behind his back.\nI don't know why he even puts up with her."
    scene 17_0780 with dissolve
    jem "Having you on the inside could help me get rid of her - {b}For good{/b}."
    scene 17_0781 with dissolve
    mc "You don't trust her, I get it... Honestly, neither do I, but what benefit do you get from getting rid of her?"
    mc "Is this some kinda play to take over Springhaven?"
    scene 17_0782 with dissolve
    jem "Why the fuck would I want that shithole??"
    jem "She's always been {i}the golden girl{/i} in Hank's eyes.\nIt's pathetic! She ain't earned that!"
    scene 17_0783 with dissolve
    jem "Just because she was around at the beginning - That shouldn't earn you special privilege!"
    jem "It's bullshit! I want a seat at the top table - I've more than earnt it!"
    scene 17_0784 with dissolve
    mc "And with Sue out of the picture?"
    jem "A seat becomes available."
    mc "What do you expect {i}me{/i} to do?\nI'm not that close to her; she sees me as just another grunt."
    scene 17_0785 with dissolve
    jem "Don't you fuckin' lie to me, [mc]."
    jem "If you wanna work for me, we {b}need{/b} to trust each other."
    scene 17_0786 with dissolve
    jem "You know how many guys she's recommended to Hank? None!"
    jem "She sees something in you that she hasn't seen before.\nShe has plans for you, so she trusts you."
    scene 17_0787 with dissolve
    jem "Which means you're perfectly placed to help me take her down."
    scene 17_0788 with dissolve
    mc "What are you asking me to do? Set her up?"
    jem "No. Too many things could go wrong, and we'd both be screwed."
    mc "So... what?"
    scene 17_0789 with dissolve
    jem "We don't need to set her up. I {b}know{/b} she's already up to something!"
    jem "Your job will be to find out {b}what{/b}."
    scene 17_0790 with dissolve
    jem "And, who knows?..."
    jem "With her gone - and me sitting at the table, putting in a good word - maybe {b}you{/b} get to run things in Springhaven."
    scene 17_0791 with dissolve
    mc "Nah, I have no interest in that."
    jem "Which makes you the {i}perfect{/i} guy to do it."
    jem "And, in my opinion, you'd do great!"
    scene 17_0792 with dissolve
    mc "I'm gonna need to think about it..."
    mc "It's a {b}lot{/b} of traveling... or... I'd have to live in both cities."
    mc "Guess I could find a place somewhere closer."
    scene 17_0793 with dissolve
    jem "No need. You can stay here."
    jem "I have plenty of spare rooms."
    mc "Uhh, that's kind of you, but... I don't think that works for me."
    scene 17_0794 with dissolve
    jem "[lol]{w=0.5}{nw}"
    scene 17_0795 with dissolve
    jem "Worried I'll rape you while you sleep?"
    mc "... It did cross my mind."
    scene 17_0794 with dissolve
    jem "[lol]{w=0.5}{nw}"
    scene 17_0796 with dissolve
    jem "[mc], look at me!"
    scene 17_0797 with dissolve
    jem "You think I dressed like this to get your juices flowing??"
    scene 17_0798 with dissolve
    jem "It's all an act!"
    jem "The hard-ass, in-your-face, black bitch? Just a performance!"
    scene 17_0799 with dissolve
    jem "Do you think those guys back at the warehouse would show me the same respect if I wore a pretty dress and said please and thank you??"
    scene 17_0800 with dissolve
    jem "They're all terrified of me, and that's precisely how I need them to be."
    scene 17_0801 with dissolve
    jem "Mathew didn't stay in Cedar Grove out of choice. {b}I{/b} got rid of him."
    jem "I {b}told{/b} Hank to keep him."
    mc "Why?"
    scene 17_0802 with dissolve
    if Plr.Has("Mat_Hit"):
        jem "Your fault, actually."
        jem "He was upset that I hadn't backed him up when you hit him.\nDemanded retribution."
        jem "When I refused, he began to question my decisions."
    else:
        jem "He began to question my decisions."
    jem "Start down {i}that{/i} path, and there's only one outcome if nothing's done about it."
    jem "He left me no choice. It was time for him to move on."
    scene 17_0803 with dissolve
    jem "And now you're trying to figure out my motive for coming clean!"
    mc "You already told me - You said we need to trust each other."
    mc "By revealing this, you're counting on me to start thinking I {b}can{/b} trust you."
    scene 17_0784 with dissolve
    jem "Did it work?"
    mc "A little.\nI'm willing to give it a chance at least."
    mc "So... yeah, okay.\nI'll take one of your spare rooms if the offer stands."
    jem "It does."
    scene 17_0804 with dissolve
    mc "So the sexual advances? That's all just a part of the show?"
    scene 17_0805 with dissolve
    jem "Yeah."
    jem "Most guys find it a turn-off - which is exactly the point."
    jem "Psycho black bitch who's also a sex maniac? Yeah, they run for the hills! [lol]"
    if Jemma.hasScore(1):
        scene 17_0804 with dissolve
        mc "What would've happened had I {i}not{/i} declined your offer?"
        scene 17_0805 with dissolve
        jem "Same thing! I would've used it as a reason to kick you out of my warehouse."
    scene 17_0806 with dissolve
    jem "I have to admit, though... It {b}is{/b} fun watching you guys squirm!"
    jem "And the reactions tell me a lot about the person."
    if Jemma.hasScore(1):
        jem "Your nonchalance unsettled me. Threw me off balance."
    scene 17_0807 with dissolve
    jem "I know the whole point of wanting to work for me is so you can get {i}away{/i} from Sue..."
    jem "But stick it out for a few weeks. Help me take her down."
    mc "What if she {i}isn't{/i} up to anything? There {i}isn't{/i} anything for me to find?"
    scene 17_0805 with dissolve
    jem "Then you can tell her to stick her job where the sun don't shine, and move down here permanently."
    jem "But you {i}will{/i} find something; I just know it."
    scene 17_0808 with dissolve
    mc "Then I guess we have ourselves a deal... {i}Boss{/i}."
    jem "Excellent."
    scene 17_0809 with dissolve
    jem "Do you want to stay tonight?\nIt'll be no trouble to prepare you a room."
    mc "No, I have to get back. Got an early start in the morning."
    mc "In fact, I should probably get going. It's a long drive."
    scene 17_0810 with fade1
    jem "I'll be in touch."
    mc "Okay. See ya."
    scene 17_0811 with dis1
    scene 17_0812 with dis1
    scene 17_0813 with dis1
    scene 17_0814 with dissolve
    mct "All this... for a damn dog!"
    mct "At least staying here will give me access to it."
    scene 17_0815 with dissolve
    mct "Just need to figure out how to get it back to Priya... without Jemma figuring out what I'm up to!"
    if Nicole.Has("Uniform2"):
        play sound "msg.mp3" volume 0.5
        scene 17_0816
        pause
        scene 17_0815
        call Msg_Nicole02 (Nicole.isSexual())
        scene 17_0817 with dissolve
        pause
    scene 17_0818 with dissolve
    scene 17_0819 with dis1
    scene 17_0820 with dis1
    scene 17_0821 with dis1
    scene 17_0822 with dis1
    scene 17_0823 with dis1
    scene 17_0824 with dis1
    scene black with Fade(3, 1, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
