default persistent.northcrest_active = False
default northcrest_id = "NC"
default northcrest_ch = 1
default northcrest_open = False
default northcrest_info = [""]


default persistent.MiyukaLocked = True
default Miyuka_name = "Miyuka"
define mi = Character("[Miyuka_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="miyuka")
image side miyuka cell = side+"miyuka_c.png"
image side miyuka h = side+"miyuka_hp.png"
image side miyuka s = side+"miyuka_sd.png"
image side miyuka a = side+"miyuka_an.png"
image side miyuka sh = side+"miyuka_sh.png"
image side miyuka su = side+"miyuka_su.png"
default Miyuka = Stats()

default persistent.MitsuiLocked = True
default Mitsui_name = ""
define mits = Character("[Mitsui_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="mitsui")
image side mitsui cell = side+"mitsui_c.png"
image side mitsui h = side+"mitsui_hp.png"
image side mitsui s = side+"mitsui_sd.png"
image side mitsui a = side+"mitsui_an.png"
image side mitsui sh = side+"mitsui_sh.png"
image side mitsui su = side+"mitsui_su.png"
default Mitsui = Stats()


label UpdateNorthcrestData:

return

screen Northcrest_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "ntc", "mitsui", Mitsui_Replay, persistent.MitsuiLocked, "Mom to Miyuka and Kiyomi (Sue's maid).")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "ntc", "miyuka", Miyuka_Replay, persistent.MiyukaLocked, "Mitsui's daughter. Kiyomi's sister.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
