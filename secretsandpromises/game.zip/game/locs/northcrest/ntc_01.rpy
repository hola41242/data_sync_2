label Northcrest_Pickup:
    $ persistent.northcrest_active=True
    $ curLOC=northcrest_id
    play soundAlt "truck04.mp3" volume 1.0 fadein 3 loop
    scene 09_0789 with Fade(1, 2, 2)
    $ Mitsui_name=""
    if BillSick:
        mct "This has to be the place..."
        scene 09_0790 with dis1
        scene 09_0791 with dis1
        mct "Hope someone's around!"
        scene 09_0792 with dissolve
        mct "Shit. Gate's locked."
        mct "See if this works..."
        play sound "truckhorn.mp3"
        pause 2.0
        scene 09_0793 with dissolve
        mct "Okay, we have movement."
    else:
        bill "This is our stop."
        scene 09_0790 with dissolve
        play sound "truckhorn.mp3"
        scene 09_0791 with dis1
        mc "Place looks empty."
    scene 09_0794 with dissolve
    scene 09_0795 with dis1
    scene 09_0796 with dis1
    scene 09_0797 with dis1
    scene 09_0798 with dis1
    play sound "truck02.mp3"
    scene 09_0799 with dis1
    scene 09_0800 with dis1
    scene 09_0801 with dis1
    if BillSick:
        stop soundAlt
        scene 09_0802 with dissolve
        mits "What the hell, Bill?\nYou were supposed to be here {b}yesterday{/b}!"
        scene 09_0803 with dissolve
        mc "Hi."
        scene 09_0804 with dissolve
        mits "Who are you?? Where's Bill??"
        mc "Bill couldn't make it. I'm [mc].\nI'm filling in for him."
        scene 09_0805 with dissolve
        mits "No one told me you were coming today!"
        mits "You were supposed to be here yesterday.\nThere's nobody here now, everyone's left!"
        mits "We were told it was a tight schedule!"
        mc "It was a last-minute change. Couldn't be helped."
        scene 09_0806 with dissolve
        mits "Get back in your truck, I'll open the doors."
        mc "Any chance of a coffee first? It's been a long journey."
        scene 09_0807 with dissolve
        mits "No!\nThis isn't a truck stop."
        if MiyukaEscaped:
            scene 09_0808 with dissolve
            mct "Hmm..."
            scene 09_0809 with dissolve
            pause 0.5
            scene 09_0810 with dissolve
            scene 09_0811 with dissolve
            mct "Was that...?"
            scene 09_0812 with dissolve
            mits "What are you waiting for??"
        play soundAlt "truck04.mp3" volume 1.0 fadein 2 loop
    scene 09_0813 with Fade(0.5, 1, 0.5)
    scene 09_0814 with dis1
    scene 09_0815 with dis1
    stop soundAlt fadeout 1.0
    scene 09_0816 with Fade(0.5, 1, 0.5)
    pause
    if BillSick:
        scene 09_0817 with fade
        mct "Empty...\nGuess this is just a drop-off point for whatever the hell it is I'm haulin'."
        scene 09_0818 with dissolve
        mits "Is Bill okay?"
        mc "Yeah.\nHe just needs to rest for a few days."
        scene 09_0819 with dissolve
        mits "Please give him my regards."
        mc "Sure.\n{i}Who{/i} should I say gives them?"
        mits "Oh, sorry. I'm Mitsui."
        $ Mitsui_name="Mitsui"
        $ Mitsui.Activate("Mitsui")
        $ persistent.MitsuiLocked=False
        mits "I keep telling him he works too hard.\nIt's good he has another driver now."
        mc "Oh, uh, no... This is a one-time deal for me."
        scene 09_0820 with dissolve
        mc "Once I've delivered this to Broo-"
        scene 09_0821 with dissolve
        mits "Stop!"
        mits "You shouldn't tell me where it goes!"
        scene 09_0822 with dissolve
        mc "Uhh... right. Sorry."
        mc "They don't trust you enough to tell you the destination?"
        scene 09_0823 with dissolve
        mits "They trust me as much as I trust them, so - no."
        mc "So why you workin' for them?"
        mits "Probably for the same reason as you and everyone else."
        mits "No choice."
        scene 09_0824 with dissolve
        mc "Yeah."
        mc "Guessing you can't tell me what it is you do here?"
        mits "You're new, aren't you?"
        scene 09_0825 with dissolve
        mits "Let me give you some advice, [mc]."
        mits "Don't ask questions.\nDo the job they've assigned you and nothing more."
        mits "You can't beat them.\nYou'll only make life more difficult for yourself... and put your family at risk."
        mc "They're threatening your family?"
        mc "Wait... Are you...?\nKiyomi said she was from Northcrest... and her mother-"
        scene 09_0826 with dissolve
        call Emotion (mits, "Gasp", "You know Kiyomi??")
        mc "I've met her, yeah."
        if MiyukaDelivered:
            mc "Her sister, Miyuka, too."
            mits "Miyuka?!\nIS SHE OKAY??"
            mc "Yeah.\nThey're both fine."
        elif MiyukaEscaped:
            mc "I met her sister briefly, too."
            mits "Kiyomi...How is she?? Is she okay??"
            mc "Yeah, she's fine."
        else:
            mits "How is she?? Is she okay??"
            mc "Yeah, she's fine."
        scene 09_0827 with dissolve
        mits "Okay... Thank you.\nWe... We shouldn't talk..."
        mits "You'd better get back to work."
        scene 09_0828 with dissolve
        pause 0.5
        scene 09_0829 with dissolve
        mct "Hmm... Not the type of door you'd usually find in a warehouse."
        scene 09_0830 with dis1
        scene 09_0831 with dis1
        pause 0.5
        scene 09_0832 with dis1
        pause 0.5
        scene 09_0833 with dissolve
        mct "Clear."
        scene 09_0834 with dissolve
        pause 0.5
        scene 09_0835 with dissolve
        mct "Locked."
        scene 09_0836 with dissolve
        pause 0.5
        scene 09_0837 with dissolve
        mct "Why the hell would they have a lab tucked away in a warehouse?"
        scene 09_0838 with dissolve
        mits "GET AWAY FROM THERE!!"
        scene 09_0839 with dissolve
        mits "ARE YOU CRAZY?!"
        scene 09_0840 with dissolve
        mits "ARE YOU TRYING TO GET US INTO TROUBLE?!"
        scene 09_0841 with dissolve
        mits "There's a security camera pointing directly at that door!"
        scene 09_0842 with dissolve
        mits "If they catch you snooping..."
        scene 09_0843 with dissolve
        mc "Shit, sorry.\nI didn't see it."
        mits "Please finish your work and leave."
        mits "DO YOUR JOB AND NOTHING MORE!"
        call CenterText ("A few minutes later.")
        scene 09_0844 with dissolve
        mc "Okay, I'm done."
        mits "Good."
        if MiyukaEscaped:
            mc "There's just one more thing I need to check before I leave..."
            scene 09_0845 with dissolve
            mits "Where are you going?\nWAIT!"
            scene 09_0846 with dissolve
            mits "STOP!"
            scene 09_0847 with dissolve
            mits "You can't go in there!!"
            mc "It {b}was{/b} her I saw, wasn't it?"
            call Northcrest_FoundMiyuka
    else:
        stop soundAlt
        scene 09_0849 with dissolve
        mits "What the hell, Bill?\nYou were supposed to be here {b}yesterday{/b}!"
        mits "We're on a tight schedule! You can't just turn up a day late!"
        scene 09_0850 with dissolve
        bill "I know, I know! I'm sorry.\nWe got held up."
        mits "No one told me you'd be coming today instead!\nYou're lucky I'm still here! Everyone else has left!"
        scene 09_0851 with dissolve
        mits "Who's this?\nYou finally took my advice and hired some help?"
        bill "Hah!\nThis is [mc]."
        scene 09_0852 with dissolve
        bill "[mc], this is Mitsui."
        bill "Don't let her grumpiness fool you; she's usually nice!"
        scene 09_0853 with dissolve
        mc "Hi, pleased to meet you."
        bill "C'mon, Son! We ain't got time to chit-chat!\nWe gotta get movin'."
        $ Mitsui_name="Mitsui"
        $ Mitsui.Activate("Mitsui")
        $ persistent.MitsuiLocked=False
        scene 09_0854 with dissolve
        bill "Make yourself useful and lift the landing gear on this side, will ya?"
        scene 09_0855 with dissolve
        mc "Sure."
        scene 09_0818 with dissolve
        mits "Is Bill okay?"
        mc "Yeah, why?"
        scene 09_0819 with dissolve
        mits "He's never been late before.\nOur boss won't be happy. She isn't someone you want to upset."
        mc "You talkin' about Sue?\nDon't worry, she's already aware of the situation."
        mits "Ohh, okay."
        mits "It's good he's hired some help now. I keep telling him he works too hard."
        mc "Oh, uh, no... This is a one-time deal for me."
        scene 09_0820 with dissolve
        mc "Accompany Bill here to pick this up and deliver it to Broo-"
        scene 09_0821 with dissolve
        mits "Stop!"
        mits "You shouldn't tell me where it goes!"
        scene 09_0822 with dissolve
        mc "Uhh... right. Sorry."
        mc "They don't trust you enough to tell you the destination?"
        scene 09_0823 with dissolve
        mits "They trust me as much as I trust them, so - no."
        mc "So why you workin' for them?"
        mits "Probably for the same reason as you and everyone else."
        mits "No choice."
        scene 09_0824 with dissolve
        mc "Yeah."
        mc "Guessing you can't tell me what it is you do here?"
        mits "You're new, aren't you?"
        scene 09_0825 with dissolve
        mits "Let me give you some advice, [mc]."
        mits "Don't ask questions.\nDo the job they've assigned you and nothing more."
        mits "You can't beat them.\nYou'll only make life more difficult for yourself... and put your family at risk."
        mc "They're threatening your family?"
        mc "Wait... Are you...?\nKiyomi said she was from Northcrest... and her mother-"
        scene 09_0826 with dissolve
        call Emotion (mits, "Gasp", "You know Kiyomi??")
        mc "I've met her, yeah."
        if MiyukaDelivered:
            mc "Her sister, Miyuka, too."
            mits "Miyuka?!\nIS SHE OKAY??"
            mc "Yeah.\nThey're both fine."
        elif MiyukaEscaped:
            mc "I met her sister briefly, too."
            mits "Kiyomi...How is she?? Is she okay??"
            mc "Yeah, she's fine."
        else:
            mits "How is she?? Is she okay??"
            mc "Yeah, she's fine."
        scene 09_0827 with dissolve
        mits "Okay... Thank you.\nWe... We shouldn't talk..."
        mits "You'd better get back to work."
        scene 09_0828 with dissolve
        pause 0.5
        scene 09_0829 with dissolve
        mct "Hmm... Not the type of door you'd usually find in a warehouse."
        scene 09_0830 with dis1
        scene 09_0831 with dis1
        pause 0.5
        scene 09_0832 with dis1
        pause 0.5
        scene 09_0833 with dissolve
        mct "Clear."
        scene 09_0834 with dissolve
        pause 0.5
        scene 09_0835 with dissolve
        mct "Locked."
        scene 09_0836 with dissolve
        pause 0.5
        scene 09_0837 with dissolve
        mct "Why the hell would they have a lab tucked away in a warehouse?"
        scene 09_0838 with dissolve
        mits "GET AWAY FROM THERE!!"
        scene 09_0839 with dissolve
        mits "ARE YOU CRAZY?!"
        scene 09_0840 with dissolve
        mits "ARE YOU TRYING TO GET US INTO TROUBLE?!"
        scene 09_0841 with dissolve
        mits "There's a security camera pointing directly at that door!"
        scene 09_0842 with dissolve
        mits "If they catch you snooping..."
        scene 09_0856 with dissolve
        mc "Shit, sorry.\nI didn't see it."
        mits "{i}DO YOUR JOB AND NOTHING MORE!"
        bill "What's with all the yellin'?"
        scene 09_0857 with dissolve
        mits "You both need to leave!\nFinish your work and go."
        bill "We're leavin' right now.\nC'mon, [mc]."
        scene 09_0858 with Fade(1, 0.5, 1)
        bill "What the hell was that all about?"
        mc "Just a misunderstanding."
        scene 09_0859 with Fade(1, 0.5, 1)
        play sound "truck02.mp3"
        scene 09_0860 with dis1
        scene 09_0861 with dis1
        if MiyukaEscaped:
            scene 09_0862 with dissolve
            pause 0.5
            scene 09_0863 with dissolve
            mct "Whoa... was that...??"
            scene 09_0864 with dissolve
            mc "STOP THE TRUCK!"
            scene 09_0865 with dissolve
            bill "What's wrong??"
            mc "Stay here. I'll be right back..."
            scene 09_0866 with dissolve
            pause 0.5
            scene 09_0867 with dissolve
            mits "Where are you going?\nWAIT!"
            scene 09_0868 with dissolve
            mits "STOP!"
            mc "It {b}was{/b} her I saw, wasn't it?"
            call Northcrest_FoundMiyuka
    scene 09_0904 with dissolve
    scene 09_0905 with dis1
    scene 09_0906 with dis1
    scene 09_0907 with dis1
    scene 09_0908 with dis1
    scene black with fade2
return

label Northcrest_FoundMiyuka:
    scene 09_0848 with dissolve
    mits "There's nobody in there! I live on my own!"
    scene 09_0869 with dissolve
    mits "No! Please, just go away!"
    scene 09_0870 with dissolve
    mc "I know you're in here!"
    scene 09_0871 with dissolve
    mits "Get out!"
    scene 09_0872 with dissolve
    mc "Where'd she go?"
    mits "Who??"
    scene 09_0873 with dissolve
    mits "You're crazy!"
    scene 09_0874 with dissolve
    mits "GET OUT!!"
    scene 09_0875 with dissolve
    pause 0.5
    scene 09_0876 with dissolve
    mc "Oh no you don't! Come on..."
    scene 09_0877 with dissolve
    mc "Go sit down."
    scene 09_0878 with dissolve
    mits "Leave her alone!"
    mc "I just wanna talk to her."
    scene 09_0879 with dissolve
    mc "I'm glad to see you're okay.\nBelieve me or not, I've been worried about you."
    scene 09_0880 with dissolve
    mc "You caused me a lot of trouble when you decided to run."
    mc "But I want you to know, I'm not angry with you.\nI probably would've done the same thing."
    scene 09_0881 with dissolve
    mc "It was my own fault. I shouldn't have made the extra stop.\nI should've taken you straight to Springhaven."
    scene 09_0882 with dissolve
    $ Miyuka_name="Miyuka"
    mi "You were taking me to Springhaven?"
    mc "Yeah."
    scene 09_0883 with dissolve
    mits "She was locked in a cage and frightened!\nShe thought you were taking her somewhere quiet to kill her!"
    mc "Kill her?!"
    scene 09_0884 with dissolve
    mc "I was taking you to my boss' house.\nThat's where your sister's staying."
    mi "You were taking me to see Kiyomi?"
    if Miyuka.Has("Food"):
        mc "I tried talking to you.\nI didn't know if you understood me, or even spoke English."
    mc "I didn't know you were her sister.\nI only found out later."
    scene 09_0883 with dissolve
    mc "What does Sue want with your daughters?"
    mits "Leverage!\nShe threatens to harm them if I don't do what she wants!"
    if not BillSick:
        play sound "truckhorn.mp3" volume 0.5
    scene 09_0885 with dissolve
    mits "Miyuka turned up here a few days ago. She has nowhere else to go!"
    mits "I've been trying to hide her.\nWe weren't expecting anyone to show up today."
    scene 09_0886 with dissolve
    mits "[mc], Please, I beg you.\nDon't tell anyone she's here!"
    scene 09_0887 with dissolve
    pause 1.0
    menu:
        "Take Miyuka with you back to Springhaven":
            $ Plr.Add("GotPackage2")
            scene 09_0888 with dissolve
            mc "I'm sorry, Mitsui. I can't do that.\nShe needs to come back with me."
            call Emotion (mits, "Gasp", "NO!")
            mc "They're searching for her, and if they were to find her here... it'd be bad - for both of you."
            scene 09_0889 with dissolve
            mi "Mom, it's okay.\nI'll go with him. I'll be with Kiyomi."
            scene 09_0890 with dissolve
            mc "I'll let you say goodbye."
        "Leave Miyuka here":
            $ Miyuka.Add("NTC")
            $ Mitsui.Score(1)
            scene 09_0888 with dissolve
            mc "Find her somewhere better to stay, Mitsui."
            call Emotion (mits, "Gasp", "Thank you!")
            scene 09_0890 with dissolve
            mc "They're searching for her. She isn't safe here."
    if BillSick:
        scene 09_0891 with fade
        pause 0.5
        if Miyuka.Has("NTC"):
            scene 09_0897 with dis1
            scene 09_0900 with dis1
        else:
            scene 09_0898 with dis1
            scene 09_0899 with dis1
            scene 09_0901 with dissolve
            mc "Listen, I have no choice but to drop this trailer off first.\nI don't wanna have to tie you up."
            mc "I know it's hard to believe, but I'm actually trying to help you and your sister.\nDon't make things more difficult."
            mi "If you swear you're taking me to see Kiyomi, I won't try to run."
            mc "I swear."
            scene 09_0902 with dissolve
            mi "Okay. Let's go."
            scene 09_0859 with Fade(1, 0.5, 1)
            play sound "truck02.mp3"
            scene 09_0860 with dis1
            scene 09_0861 with dis1
    else:
        scene 09_0892 with fade
        pause 0.5
        if Miyuka.Has("NTC"):
            scene 09_0895 with dis1
            scene 09_0896 with dis1
        else:
            scene 09_0893 with dis1
            scene 09_0894 with dis1
            scene 09_0903 with dissolve
            bill "Who the hell's this? What's goin' on??"
            mc "She's comin' with us to Springhaven."
            bill "Why?"
            mc "Just drive, Bill."
return

label Northcrest_SecondPickup:
    scene black with Fade(2, 4, 1)
    call CenterText ("Some time later.")
    scene 14_0085 with Fade(0,0,2)
    scene 14_0086 with dis1
    scene 14_0087 with dis1
    scene 14_0088 with dissolve
    mc "Hey."
    mc "{b}Kiyomi{/b}."
    scene 14_0089 with dissolve
    ki "[whi]Mhh?"
    mc "We're almost there."
    scene 14_0090 with dissolve
    ki "[whi]Sorry... I must've fallen asleep."
    mc "Yeah... It happens!"
    scene 14_0091 with dissolve
    call Emotion (ki, "Groan", "", True)
    if Kiyomi.L==10:
        mc "You said you'd do anything I ask of you.\nDid you mean that?"
        scene 14_0092 with dissolve
        ki "Yes."
    else:
        mc "Sue asked me to help you and your sister, but to do that, I'm gonna need you to do something."
        scene 14_0092 with dissolve
        ki "Do what?"
    mc "I need you to talk to your mom and find out exactly what it is she's doing for Sue."
    ki "Why?"
    mc "I need all the information I can get if I'm gonna help you and your family."
    if Kiyomi.L==10:
        scene 14_0093 with dissolve
        ki "Okay."
        ki "When I said I belong to you now, I meant it."
    else:
        mc "Please, you need to trust me."
        scene 14_0093 with dissolve
        ki "I {b}do{/b} trust you."
    ki "I'll talk to her."
    scene 14_0094 with fade1
    scene 14_0095 with dis1
    scene 14_0096 with dis1
    scene 14_0097 with dis1
    scene 14_0098 with dis1
    scene 14_0099 with dis1
    secgrd "Whoa, whoa!"
    secgrd "What are you doing, my friend??"
    secgrd "You stay in the truck!"
    scene 14_0100 with dissolve
    secgrd "You {b}never{/b} leave the cabin!\nI'll hook it up, and you'll be on your way."
    mc "Can't do that, {i}my friend{/i}."
    mc "Kiyomi has come all this way to see her mom.\nShe's getting out."
    scene 14_0101 with dissolve
    secgrd "Who authorized this?"
    mc "Sue."
    secgrd "I need to confirm.\nPlease, get back in the truck, and I'll make the call."
    scene 14_0102 with fade
    ki "Why won't they let us see her??"
    ki "Is she okay??"
    scene 14_0103 with dissolve
    mc "I'm sure she's fine."
    mc "But we're not leaving until we've seen her."
    scene 14_0104 with dis1
    scene 14_0105 with dissolve
    secgrd "Approved, my friend!"
    secgrd "She can see her mother, but {b}you{/b} must remain in the cabin at all times."
    scene 14_0106 with dissolve
    secgrd "I'll inform Mitsui of her visitor."
    scene 14_0107 with dissolve
    ki "That was strange."
    mc "Mh-mhh."
    $ aP(True)
    scene 14_0108 with dissolve
    $ apause()
    scene 14_0109 with dis1
    $ apause()
    scene 14_0110 with dis1
    $ apause()
    scene 14_0111 with dis1
    $ apause()
    scene 14_0112 with dis1
    $ apause()
    scene 14_0113 with dis1
    $ apause()
    scene 14_0114 with dis1
    $ apause(0.5, True)
    scene 14_0115 with dis1
    mc "Alright, here she comes."
    scene 14_0116 with dissolve
    mc "You can get out now. Go see your mom."
    mc "I'll be right here."
    ki "Thanks, [mc]."
    scene 14_0117 with fade
    ki "MOM!"
    mits "Kiyomi!"
    scene 14_0118 with dissolve
    ki "Are you okay?"
    mits "I'm fine."
    scene 14_0119 with dissolve
    secgrd "Sorry about the confusion, my friend, but you know the rules..."
    secgrd "Protocol has to be followed at all times!"
    scene 14_0120 with dissolve
    secgrd "A one-hour visit has been permitted."
    secgrd "But you must--"
    mc "Stay in the cab. Yeah, I get it."
    scene 14_0121 with dissolve
    pause
    scene 14_0122 with Fade(3, 4, 3)
    ki "[mc]?"
    scene 14_0123 with dissolve
    mits "Is he alright?"
    ki "Yeah. He's sleeping."
    secgrd "Need to get this thing moving, and you need to get back to work, Mitsui!"
    secgrd "Your hour was up seven minutes ago."
    mits "Oh, shut up, Derek!"
    scene 14_0124 with dissolve
    ki "[mc], it's time to leave."
    call Emotion (mc, "Groan", "", True)
    scene 14_0125 with fade1
    mc "Your mom okay?"
    ki "Yeah. Thank you for bringing me."
    scene 14_0126 with dissolve
    mc "I was thinking, I can take you back to Springhaven before dropping this load off."
    mc "No point dragging you all the way down there with me."
    ki "Okay, if it's not too much trouble."
    scene 14_0127 with dissolve
    mc "Nah, it's not much of a detour."
    mc "Did you ask your mom about her job here?"
    ki "Yes."
    scene 14_0128 with dissolve
    ki "I didn't understand most of it, but I'll tell you on the way back."
    mc "Great."
    scene 14_0129 with dissolve
    mc "Let's get outta here."
    scene 14_0130 with dis1
    scene 14_0131 with dis1
    scene 14_0132 with dis1
    scene 14_0133 with dis1
    scene 14_0134 with dis1
    scene 14_0135 with dis1
    scene black with Fade(3, 0, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
