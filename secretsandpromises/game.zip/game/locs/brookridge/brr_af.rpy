label BrookRidge_AF01:

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
