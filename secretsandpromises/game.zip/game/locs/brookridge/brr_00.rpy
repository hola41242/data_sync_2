default persistent.brookridge_active = False
default brookridge_id = "BR"
default brookridge_ch = 1
default brookridge_open = False
default brookridge_info = ["", 
"""Lucy sent me the last known address of our father.
I don't think any good will come from me knocking at his door, but she's never begged me for anything before. It's important to her.
Is it important to me? No, not any more. There was a time I was desperate to find him, but I'm way past it. If I do this, I'm doing it for her."""
]

label UpdateBrookRidgeData:

return

default persistent.HelenLocked = True
default Helen_name = "Helen"
define hel = Character("[Helen_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="helen")
default Helen = Stats()

default persistent.JaneLocked = True
default Jane_name = "Jane"
define jane = Character("[Jane_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="jane")
default Jane = Stats()

default Michelle_name = ""
define mich = Character("[Michelle_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="mich")


label BrookRidge_Retcon:
    scene 05_0009 with fade
    play sound "knock.mp3"
    pause 0.5
    scene 05_0010 with dissolve
    pause
    scene 05_0011 with dissolve
    unk "Hello, can I help you?"
    mc "Umm... Hi, does Mr Johnson still live here? Err... Richard Johnson?"
    scene 05_0012 with dissolve
    mich "I'm sorry, you're a few years too late!\nHe passed away long ago."
    mich "I'm his wife, Michelle. Is there anything I can help you with?"
    $ Michelle_name="Michelle"
    scene 05_0013 with dissolve
    mc "Uhh, no.\nSorry for disturbing you."
    scene 05_0014 with dissolve
    mct "Probably for the best."
    scene 05_0015 with dissolve
    mich "Wait."
    scene 05_0016 with dissolve
    mich "Would you like to come in?"
    mc "Why?"
    scene 05_0017 with dissolve
    mich "Call it a woman's intuition."
    mich "I think you have questions, and I may have answers."
    mc "I'm sorry, Ma'am. I made a mistake."
    scene 05_0018 with dissolve
    mich "I can see him in you, you know."
    scene 05_0019 with dissolve
    mich "Coffee?"
    scene 05_0020 with Fade(2,1,2)
    mct "This is awkward."
    scene 05_0021 with Fade(1,0.5,1)
    mich "Five minutes later, and you would've missed me.\nI was on my way out."
    mc "Oh, sorry."
    scene 05_0022 with dissolve
    mich "It's fine."
    mich "I have some errands to run, nothing that can't wait."
    scene 05_0023 with dissolve
    mich "So, Richard's your father?"
    scene 05_0024 with dissolve
    mc "Apparently, yeah. Sorry."
    scene 05_0025 with dissolve
    mich "I'm not doubting your claim, but..."
    scene 05_0026 with dissolve
    mc "He wrote my mother letters asking about us, his children. Sent money to help with our upbringing."
    mich "{b}Us{/b}? You have siblings?"
    mc "Yeah. A younger sister, Lucy."
    scene 05_0027 with dissolve
    mc "I'm sorry, Michelle.\nI shouldn't have come."
    mich "Why {i}did{/i} you come?"
    mich "I mean, why now, after all this time?"
    scene 05_0028 with dissolve
    mc "Honestly? I didn't want to."
    mc "Lucy persuaded me."
    mc "Our mom passed away last year.\nLucy found the letters when she was clearing out the house."
    mich "Oh, I'm sorry, err.."
    mc "[mc]."
    scene 05_0029 with dissolve
    mich "You have my condolences, [mc]."
    if persistent.Incest:
        mich "Your mother. May I ask her name?"
        mc "Margaret. Margaret Freeman."
        call BrookRidge_CousinsChat_p1
    else:
        mc "Thanks."
    scene 05_0040 with dissolve
    mc "Does... Richard... have, uh, other children?"
    mich "We tried - for a long time, but, no, we were never blessed in that way."
    scene 05_0041 with dissolve
    mc "Oh, I'm sorry. I shouldn't have asked."
    mc "Forgive me, I'm not good at this kind of stuff."
    scene 05_0042 with dissolve
    mich "Nonsense. There's nothing to forgive!\nIt's only natural that you have questions."
    mich "It would've been nice to have children, but we had a beautiful life together. We never had any regrets."
    scene 05_0043 with dissolve
    mc "I'm sorry, Michelle. I should go. This was a mistake."
    mc "Apologies for showing up out of the blue, but thank you for seeing me."
    scene 05_0044 with fade
    mich "It was a pleasure to meet you, [mc]."
    mich "It may be a shock, but I wouldn't call it a mistake.\nPlease consider visiting again sometime."
    mc "Uh, I... don't know.\nThis is my sister's thing, not mine."
    mich "Well, if you change your mind, you're welcome anytime."
    scene 05_0182 with Fade(1, 0.5, 1)
    mct "Wonder how Lucy will take the news that our father's dead?"
return

screen BrookRidge_Replays():
    $ next_x=0
    $ next_y=0

    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "brr", "helen", Helen_Replay, persistent.HelenLocked)
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "brr", "jane", Jane_Replay, persistent.JaneLocked)
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
