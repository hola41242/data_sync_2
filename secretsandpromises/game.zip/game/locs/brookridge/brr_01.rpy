label BrookRidge_Start1:
    $ persistent.brookridge_active=True
    scene 05_0001 with Fade(0, 3, 3)
    play sound "car.mp3"
    scene 05_0002 with dis1
    scene 05_0003 with dis1
    scene 05_0004 with dis1
    scene 05_0005 with dis1
    scene 05_0006 with dissolve
    mct "This is stupid... What the hell am I doing here?"
    mct "What the fuck do I even say to him??"
    scene 05_0007 with dissolve
    mct "Doesn't matter what bullshit excuse he tries to come up with, I'm not gonna believe him."
    mct "Damn you, Lucy! You owe me for this."
    if Plr.Has("GotPackage"):
        $ aa=""
        if Miyuka.Has("Food"):
            $ aa="a"
        show expression "05_0079" + aa with dissolve
        mc "I need to go see someone."
        mc "Stay in the truck. I'll be as quick as I can."
    scene 05_0008 with fade
    pause 1.0
    scene 05_0009 with fade
    play sound "knock.mp3"
    pause 0.5
    scene 05_0010 with dissolve
    pause
    scene 05_0011 with dissolve
    unk "Hello, can I help you?"
    mc "Umm... Hi, does Mr Johnson still live here? Err... Richard Johnson?"
    scene 05_0012 with dissolve
    mich "I'm sorry, you're a few years too late!\nHe passed away long ago."
    mich "I'm his wife, Michelle. Is there anything I can help you with?"
    $ Michelle_name="Michelle"
    scene 05_0013 with dissolve
    mc "Uhh, no.\nSorry for disturbing you."
    scene 05_0014 with dissolve
    mct "Probably for the best."
    scene 05_0015 with dissolve
    mich "Wait."
    scene 05_0016 with dissolve
    mich "Would you like to come in?"
    mc "Why?"
    scene 05_0017 with dissolve
    mich "Call it a woman's intuition."
    mich "I think you have questions, and I may have answers."
    mc "I'm sorry, Ma'am. I made a mistake."
    scene 05_0018 with dissolve
    mich "I can see him in you, you know."
    scene 05_0019 with dissolve
    mich "Coffee?"
    scene 05_0020 with Fade(2,1,2)
    mct "This is awkward."
    scene 05_0021 with Fade(1,0.5,1)
    mich "Five minutes later, and you would've missed me.\nI was on my way out."
    mc "Oh, sorry."
    scene 05_0022 with dissolve
    mich "It's fine."
    mich "I have some errands to run, nothing that can't wait."
    scene 05_0023 with dissolve
    mich "So, Richard's your father?"
    scene 05_0024 with dissolve
    mc "Apparently, yeah. Sorry."
    scene 05_0025 with dissolve
    mich "I'm not doubting your claim, but..."
    scene 05_0026 with dissolve
    mc "He wrote my mother letters asking about us, his children. Sent money to help with our upbringing."
    mich "{b}Us{/b}? You have siblings?"
    mc "Yeah. A younger sister, Lucy."
    scene 05_0027 with dissolve
    mc "I'm sorry, Michelle.\nI shouldn't have come."
    mich "Why {i}did{/i} you come?"
    mich "I mean, why now, after all this time?"
    scene 05_0028 with dissolve
    mc "Honestly? I didn't want to."
    mc "Lucy persuaded me."
    mc "Our mom passed away last year.\nLucy found the letters when she was clearing out the house."
    mich "Oh, I'm sorry, err.."
    mc "[mc]."
    scene 05_0029 with dissolve
    mich "You have my condolences, [mc]."
    if persistent.Incest:
        mich "Your mother. May I ask her name?"
        mc "Margaret. Margaret Freeman."
        call BrookRidge_CousinsChat_p1
    else:
        mc "Thanks."
    scene 05_0040 with dissolve
    mc "Does... Richard... have, uh, other children?"
    mich "We tried - for a long time, but, no, we were never blessed in that way."
    scene 05_0041 with dissolve
    mc "Oh, I'm sorry. I shouldn't have asked."
    mc "Forgive me, I'm not good at this kind of stuff."
    scene 05_0042 with dissolve
    mich "Nonsense. There's nothing to forgive!\nIt's only natural that you have questions."
    mich "It would've been nice to have children, but we had a beautiful life together. We never had any regrets."
    scene 05_0043 with dissolve
    mc "I'm sorry, Michelle. I should go. This was a mistake."
    mc "Apologies for showing up out of the blue, but thank you for seeing me."
    scene 05_0044 with fade
    mich "It was a pleasure to meet you, [mc]."
    mich "It may be a shock, but I wouldn't call it a mistake.\nPlease consider visiting again sometime."
    mc "Uh, I... don't know.\nThis is my sister's thing, not mine."
    mich "Well, if you change your mind, you're welcome anytime."
    scene 05_0182 with Fade(1, 0.5, 1)
    mct "Wonder how Lucy will take the news that our father's dead?"
    if Plr.Has("GotPackage"):
        call BrookRidge_Miyuka
    else:
        scene 05_0184 with dissolve
        mct "Hopefully she can just accept it and move on from this whole thing."
        scene 05_0188 with Fade(1, 0.5, 1)
        scene 05_0189 with dis1
        scene 05_0190 with dis1
        scene 05_0191 with dis1
        scene 05_0192 with dis1
        scene black with Fade(2, 2, 1)
    jump BrookRidge_Leave
return

label BrookRidge_CousinsChat_p1:
    scene 05_0030 with dissolve
    mich "[whi]Margaret Freeman... Hmmm... I {i}know{/i} that name."
    scene 05_0031 with dissolve
    mich "Oh, of course! Mags!"
    scene 05_0032 with dissolve
    mc "You... knew my mom??"
    mich "Yes. Belive it or not, we're cousins!"
    mc "{b}Cousins{/b}??!"
    scene 05_0033 with dissolve
    mich "We weren't close.\nWe barely knew each other."
    mich "Her family moved to another town when we were still young."
    scene 05_0034 with dissolve
    mc "Hold on..."
    mc "What are the chances of your husband having a random affair with another woman, in another city, who turns out to be your cousin??"
    scene 05_0035 with dissolve
    mich "Oh, I very much doubt it was random."
    mich "Richard liked to... how do I put this?\nHe liked to keep it in the family."
    scene 05_0036 with dissolve
    mc "Huh?"
    mich "Richard - Your father... {i}He{/i} was our cousin, too."
    mc "You married your own cousin??"
    mich "Yes.\nIt's complicated, and I won't bore you with the details."
    scene 05_0037 with dissolve
    mc "He married one cousin and had an affair with another?"
    mc "Jeez! Sounds like a real swell guy."
    scene 05_0038 with dissolve
    mich "It's true, we had an {i}unconventional{/i} relationship, but we were happy."
    scene 05_0039 with dissolve
    mc "You don't care that he did this?"
    mich "I don't expect you to understand, but no.\nAs I said, our marriage was different to most."
return

label BrookRidge_Miyuka:
    $ Plr.Del("GotPackage")
    $ MiyukaEscaped=True
    scene 05_0183 with dissolve
    mc "FUCK!"
    scene 05_0185 with dissolve
    pause
    scene 05_0186 with dissolve
    mc "Goddamn it!!"
    scene 05_0187 with dissolve
    mc "FUUUUUUCK!!"
    scene black with Fade(1, 2, 1)
    call CenterText ("You drive around searching the area for a while, but there's no sign of her.")
return

label BrookRidge_Leave:
    scene black with Fade(3, 2, 1)
    $ brookridge_open=False
    $ brookridge_ch+=1
    jump ShowMap
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
