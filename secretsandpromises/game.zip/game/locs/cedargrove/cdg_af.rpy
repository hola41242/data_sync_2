label CedarGrove_AF01:
    scene 04_0564
    hide screen imgMap 
    $ _skipping = True
    scene 04_0565 with dissolve
    pause 0.5
    scene 04_0566 with dis1
    scene 04_0567 with dis1
    scene 04_0568 with dis1
    scene 04_0569 with dis1
    mct "Damn! Wasn't expecting to see a G-String! Heh."
    scene 04_0570 with dissolve
    mct "She's always had a GREAT ass!"
    if Nettie.Has("Alc"):
        $ Nettie.Add("Z1")
        scene 04_0571 with dissolve
        net "Mmmmh... What are you doing?"
        scene 04_0578 with dissolve
        mc "I'm tryin' to help you into bed."
    else:
        scene 04_0572 with dissolve
        net "WHAT ARE YOU DOING?"
        scene 04_0573 with dissolve
        mc "Err... Helping you into bed!"
        scene 04_0574 with dissolve
        net "BULLCRAP!"
        scene 04_0575 with dissolve
        mc "Nettie!"
        net "I was wrong about you!\nYou {b}are{/b} the same as {i}him{/i}!"
        mc "Where you going??"
        scene 04_0576 with dissolve
        net "Away from you!"
        net "Don't {b}ever{/b} come back here, [mc]! I never want to see you again!"
        call CloseCharacterPath (Nettie, "Nettie")
        scene 04_0577 with dissolve
        mc "Fuck."
return

label CedarGrove_AF02:
    $ Chloe.Score(1)
    scene 07_0958
    hide screen imgMap
    $ _skipping = True
    scene 07_0959 with dissolve
    pause 0.5
    scene 07_0960 with dissolve
    mc "Seriously, it {i}is{/i} a cute ass!"
    scene 07_0961 with dissolve
    chlo "Oh my God!"
    scene 07_0962 with dissolve
    chlo "Behave yourself!"
return

label CedarGrove_AF03:
    scene 07_1024
    hide screen imgMap
    $ _skipping = True
    if not Chloe.hasScore(2):
        scene 07_1025 with dissolve
        mc "I'm gonna miss {i}this{/i}! Heh."
        if not Chloe.hasScore(1):
            $ Chloe.Score(-1)
            scene 07_1026 with vpunch
            scene 07_1027 with dissolve
            chlo "What the hell are you doing??"
            chlo "I take it back... I'm not gonna miss you at all!"
            mc "[lol] C'mon!\nI was only messin'!"
            scene 07_1028 with dissolve
            chlo "Out!"
            mc "Seriously?!"
            scene 07_1029 with dissolve
            mc "Damn!\nIt was just a joke!"
            return
        $ Chloe.Score(1)
        scene 07_1030 with dissolve
        chlo "What the hell?"
        scene 07_1031 with dissolve
        scene 07_1032 with dissolve
        chlo "Behave yourself!"
        mc "Heh. Sorry."
        scene 07_1033 with dissolve
        mc "I'll let you settle in."
        chlo "'kay."
        scene 07_1034 with dissolve
        mc "It's a GREAT room!"
        chlo "I know![lol]"
        return
    $ Chloe.L=1
    scene 07_1035 with dissolve
    mc "I'm gonna miss {i}this{/i}! Heh."
    chlo "[giggles]"
    scene 07_1036 with dissolve
    chlo "I think you'll manage; you have a picture of it!"
    chlo "If I, uhh, were to take more, would you like me to send you them?"
    menu:
        "Absolutely!":
            scene 07_1038 with dissolve
            chlo "[whi]Okay."
        "No thanks":
            $ Pix_Chloe=False
            scene 07_1037 with dissolve
            chlo "[whi]Oh... okay."
    scene 07_1039 with dissolve
    chlo "You gonna let go now?[giggles]"
    mc "Awww... Do I {i}have{/i} to?"
    scene 07_1040 with dissolve
    chlo "[whi]No."
    scene 07_1041 with dissolve
    mc "Maybe just a couple more seconds then!"
    scene 07_1042 with dissolve
    chlo "[lol]"
    scene 07_1043 with dissolve
    chlo "[whi]Take all the time you need."
return

label CedarGrove_AF04:
    scene 11_0618
    hide screen imgMap
    $ _skipping = True
    scene 11_0619 with dissolve
    scene 11_0620 with dissolve
    if Chloe.L==1:
        mc "Stop sticking your cute butt in the air."
        scene 11_0621 with dissolve
        mc "Try to keep it straight with your back."
        scene 11_0623 with dissolve
        chlo "Was that just an excuse to touch it again?"
        mc "Were {i}you{/i} doing it on purpose just so I'd touch it again?"
        scene 11_0624 with dissolve
        chlo "Don't know what you're talking about."
    else:
        mc "Stop sticking your butt in the air."
        scene 11_0621 with dissolve
        mc "Try to keep it straight with your back."
        chlo "Sorry."
        scene 11_0622 with dissolve
        chlo "Wait... Was that just an excuse to... touch it?"
        mc "Nope."
        scene 11_0623 with dissolve
        pause 0.5
        $ Chloe.L=1
return

label CedarGrove_AF05:
    scene 11_0699
    hide screen imgMap
    $ _skipping = True
    mc "My pleasure."
    scene 11_0700 with dissolve
    play sound "smack.mp3"
    scene 11_0701 with dissolve
    scene 11_0702 with dissolve
    pause 0.5
    $ Hayley.Score(1)
    hay "You cheeky...!"
    mc "[lol]"
return

label CedarGrove_AF06:
    scene 11_0721
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e11/11_0722.webp", 6)
    mct "Damn."
return

label CedarGrove_AF07:
    scene 15_1229
    hide screen imgMap
    $ _skipping = True
    $ Chloe.Add("Ext")
return

label CedarGrove_AF08:
    scene 15_1409
    hide screen imgMap
    $ _skipping = True
    scene 15_1410 with dis1
    pause 0.5
    scene 15_1411 with dissolve
    pause
    if Hayley.hasScore(1):
        scene 15_1415 with dissolve
        pause 0.5
        scene 15_1416 with dis1
        hay "[whi]Mmhhh."
        scene 15_1417 with dissolve
        hay "[whi]..Mmmmh.."
        scene 15_1418 with dissolve
        hay "[whi]Damn."
        hay "[whi]You'd better go have that talk with Nettie before I rip off all your clothes and tie you to my bed."
        mc "[whi]I kinda like the sound of that."
        scene 15_1419 with dissolve
        hay "[whi]So do I... Which is why I'm asking you to leave."
        mc "[whi]Okay."
        $ Hayley.Score(1)
        scene 15_1414 with dissolve
        hay "[whi]Sorry. It's just--"
        mc "[whi]Hey, it's fine.\nYou don't owe me an explanation."
        mc "[whi]But until you tell me to stop, I'm gonna keep trying!"
        hay "[whi]I don't want you to stop, just... slow down."
        mc "[whi]I can do that."
    else:
        scene 15_1412 with dissolve
        hay "Whoa there, cowboy..."
        scene 15_1413 with dissolve
        hay "I said yes to a kiss, that's all."
        mc "Sorry."
        scene 15_1414 with dissolve
        hay "No, it's my fault.\nI shouldn't have encouraged you."
        $ Hayley.Score(-1)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
