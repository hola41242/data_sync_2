label CedarGrove_Start1:
    $ persistent.cedargrove_active=True
    call CenterText ("An uncomfortable bus journey later...", True)
    scene 02_0612 with Fade(0,0,2)
    mct "As good a place as any to start."
    scene 02_0613 with dissolve
    mct "Seems like a small town.\nHopefully, it'll make it easier to find her."
    scene 02_0614 with dissolve
    mct "Would be great if I walked in, and she was just... there! Heh."
    scene 02_0615 with dissolve
    pause 0.5
    scene 02_0616 with dissolve
    pause 1.0
    scene 02_0617 with Fade(1, 3, 1)
    mct "Yeah, that was too much to ask."
    mct "Oh, well.\nAt least now I know there are only two more around here."
    scene 02_0618 with dissolve
    mct "On to the next one..."
    scene 02_0619 with Fade(3,1,2)
    mct "Yeah, that's not creepy at all."
    scene 02_0620 with dissolve
    mct "Who builds a church in the middle of nowhere??"
    scene 02_0621 with dissolve
    mct "Hmm, this one doesn't look promising."
    scene 02_0622 with dissolve
    pause 1.0
    scene 02_0623 with Fade(1, 3, 1)
    pause 1.0
    scene 02_0624 with dissolve
    pause 1.0
    scene 02_0625 with dissolve
    mct "Okay!\nHe seemed confident that I'd find her at the church in the next town."
    scene 02_0626 with Fade(3,1,2)
    mct "It's getting late. I could find a place to crash and come back tomorrow?"
    scene 02_0627 with dissolve
    mct "Maybe they'll let me sleep on one of their pews! Heh."
    scene 02_0628 with dissolve
    mct "Might as well have a quick look, since I'm already here."
    scene 02_0629 with dissolve
    mct "Ah, crap.\nThey're in the middle of a service."
    scene 02_0630 with dissolve
    pause 0.5
    scene 02_0631 with dissolve
    pause 0.5
    scene 02_0632 with dissolve
    mc "[whi]Excuse me, Sister."
    mc "[whi]I'm hoping you can help me. I'm trying to find..."
    scene 02_0633 with dissolve
    mc "Nettie?"
    net nun "Yes? I'm Net..."
    scene 02_0634 with dissolve
    net nun "[mc!u]??"
    net nun "Oh, my goodness!"
    scene 02_0635 with dissolve
    net nun "It's been so long, I barely recognized you!"
    net nun "What on earth are you doing here?"
    scene 02_0636 with dissolve
    mc "Looking for you!"
    net nun "Me?! Why?"
    mc "Can we talk? I have..."
    scene 02_0637 with dissolve
    net nun "No!"
    net nun "I'm sorry, but it's impossible right now!\nI have to get back..."
    mc "Nettie, please. It's important."
    net nun "[mc]!"
    scene 02_0638 with dissolve
    net nun "[whi]Damn it."
    scene 02_0639 with dissolve
    net nun "Where are you staying?"
    mc "I, uh..."
    net nun "Umm... There's a motel on the outskirts of town. It's the only one for miles.\nI'll come by when I've finished here!"
    scene 02_0640 with dissolve
    net nun "But, please, you must leave!\nWe're not allowed personal visitors here."
    mc "Okay.\nSee you later."
    scene 02_0641 with dissolve
    pause 1.0
    jump CedarGrove_MeetNettie
return

label CedarGrove_MeetNettie:
    $ Nettie.Activate("Nettie")
    $ persistent.NettieLocked=False
    scene 02_0642 with Fade(3,1,2)
    mct "Great. Juuust great."
    scene 02_0643 with dissolve
    mct "Think I've found it, Pete!\nA place {b}worse{/b} than our desert barracks!"
    scene 02_0644 with Fade(1,1,1)
    pause 2.0
    scene black with Fade(3, 3, 0)
    pause 2.0
    play sound "knock.mp3" volume 0.5
    pause 0.5
    scene 02_0645 with hpunch
    pause 2.5
    play sound "knock.mp3" volume 2.0
    pause 0.5
    scene 02_0646 with dissolve
    mc "I'm coming!"
    scene 02_0647 with dissolve
    pause 0.5
    scene 02_0648 with dissolve
    mc "[whi]Whoa."
    net "What's wrong? Expecting someone else?"
    mc "Yeah, I was expecting a nun."
    scene 02_0649 with dissolve
    net "It was easier to sneak out wearing these."
    net "And I didn't want to be spotted coming to a place like this."
    scene 02_0650 with dissolve
    net "How did you know where to find me?"
    mc "Alison."
    scene 02_0651 with dissolve
    net "Of course.\nHow is she? I haven't seen her since the funeral."
    net "I was surprised not to see you there."
    mc "She's fine.\nI was, err... busy."
    net "Right."
    scene 02_0652 with dissolve
    net "Okay, I'm here. What did you want to talk about?"
    net "I can't stay long; I have to get back."
    scene 02_0653 with dissolve
    mc "I have something for you..."
    mc "A letter... from Pete."
    scene 02_0654 with dissolve
    net "He's been dead for two years. How's he writing letters?"
    mc "I promised to deliver it if anything happened to him."
    mc "Sorry it took so long."
    scene 02_0655 with dissolve
    net "I don't want it."
    mc "Huh? Why??"
    net "Because I don't care what it says.\nIt's probably all {b}bullshit{/b} anyway."
    mc "Wow... don't think I've heard you swear before."
    scene 02_0656 with dissolve
    net "I'm sorry, [mc].\nBut you've come all this way for nothing."
    mc "What the hell happened between you two?!\nYou used to be {i}so{/i} close!"
    net "You should've asked {b}him{/b}!"
    mc "I did! A few times.\nHe always deflected the question."
    scene 02_0657 with dissolve
    net "Of course he did!\nHe was too ashamed of himself!!"
    mc "So {b}you{/b} tell me!\nI've been carrying this goddamn letter around for years!"
    mc "If you're not gonna read it, at least tell me {i}why{/i}!?"
    scene 02_0658 with dissolve
    net "{b}I don't need to read it!{/b}\nI already know what it says!"
    net "He'll be apologizing, {b}begging{/b} for my forgiveness."
    net "Making excuses for what he did!\nI've heard it all before!"
    scene 02_0659 with dissolve
    mc "WHAT DID HE DO, NETTIE?!"
    scene 02_0660 with dissolve
    net "{b}HE TRIED TO RAPE ME, [mc!u]!"
    scene 02_0661 with dissolve
    mc "{b}Bullshit!!"
    scene 02_0662 with dissolve
    mc "He's your brother! Why would he... do that?!"
    net "I don't know! Because he was drunk? High? Horny?\nWhat difference does it make?"
    mc "You got the wrong end of the stick! He was jokin' around, like he always did!"
    scene 02_0663 with dissolve
    net "Really?\nHe wasn't laughing when he was trying to shove his fingers inside me!"
    net "I didn't find it funny when he tried to forcefully ram his dick into my mouth while threatening to strangle me if I bit down!"
    scene 02_0664 with dissolve
    net "You never knew it, but... you're the one who saved me that night."
    net "You turned up banging at his door.\nYour leave was canceled, and you were getting shipped out to... wherever."
    scene 02_0665 with dissolve
    mc "I'm sorry, Nettie, but it... it doesn't make sense.\nHe wouldn't..."
    scene 02_0666 with dissolve
    mc "There {b}has{/b} to be another explanation!"
    scene 02_0667 with dissolve
    call Emotion (net, "Sigh", "Whatever.")
    scene 02_0668 with dissolve
    net "If it makes you feel better, I'll take his goddamn letter and burn it."
    scene 02_0669 with dissolve
    net "You've honored your promise. Go home."
    scene 02_0670 with fade
    mc "Nettie! Come on! Wait..."
    net "I have to get back.\nBye, [mc]."
    scene 02_0671 with fade
    mct "Way to go, [mc]! That went great!"
    scene 02_0672 with fade2
    mct "Why would she think that, Pete?\nI know you sometimes went too far when joking around, but..."
    mct "... The way she told it didn't sound funny."
    scene 02_0673 with dissolve
    mct "I remember that night, we were getting deployed to the desert.\nYour face was all scratched up."
    mct "Thinking about it, you never did give me an explanation.\nWe were so busy prepping, we didn't have time to talk."
    play sound "text.mp3"
    pause 1.0
    scene 02_0674 with dissolve
    pause 0.5
    show screen CellPhone("Sue")
    msg_nvl "You're in luck. There are currently no issues in Cedar Grove that require your attention."
    mc_nvl "Okay, good.\nI'll be back in a day or two."
    if oakhill_ch==1:
        mc_nvl "Thought James would be dealing with stuff like this, not you."
        msg_nvl "Yes, typically, he would."
        msg_nvl "But I've decided to take a personal interest in you."
        msg_nvl "James has enough on his plate, having to deal with all our other idiots."
        msg_nvl "You will be dealing with me directly."
        mc_nvl "Fine."
    call CloseCell ()
    scene 02_0675 with dissolve
    mct "At least I don't need to hang around this shit-hole of a town."
    mct "Get some sleep and leave at first light."
    scene 02_0676 with Fade(1,1,1)
    mc "[whi]...Zzzzz..."
    scene 02_0677 with Fade(3,3,2)
    pause 2.0
    if oakhill_ch==2:
        $ springhaven_open=True
    jump CedarGrove_Leave
return

label CedarGrove_Start2:
    if oakhill_ch==2:
        call CenterText ("A long, but incredibly smooth ride later...", True)
    else:
        call CenterText ("A relaxing drive later...", True)
    scene 04_0469 with Fade(0, 2, 3)
    pause 1.0
    scene 04_0470 with dis1
    scene 04_0471 with dis1
    scene 04_0472 with dis1
    pause 0.5
    scene 04_0473 with dis1
    pause 0.5
    scene 04_0474 with dis1
    pause 0.5
    scene 04_0475 with dissolve
    mct "Not disturbing a service this time, at least!"
    scene 04_0476 with dissolve
    mct "Is there anyone here??"
    scene 04_0477 with dis1
    pause 0.5
    scene 04_0478 with dis1
    pause 0.5
    scene 04_0479 with dissolve
    mct "There's... someone.."
    scene 04_0480 with dissolve
    mct "Crap. She's praying.\nBetter not disturb her..."
    scene 04_0481 with dissolve
    pause 1.0
    scene black with Fade(2, 2, 0)
    call CenterText ("A few minutes pass...")
    scene 04_0482 with dissolve
    mct "What do I even say to her??"
    mct "Wish I wasn't so bad at giving apologies."
    scene 04_0483 with dissolve
    mct "Doubt she'll even let me get that far."
    scene 04_0484 with dissolve
    "[mc]?"
    scene 04_0485 with dis1
    scene 04_0486 with dis1
    mc "Nettie."
    net nun "Why are you here?!"
    scene 04_0487 with dissolve
    mc "Can we talk?"
    net nun "We have nothing left to say.\nI destroyed the letter without reading it."
    scene 04_0488 with dissolve
    net nun "Please leave.\nI've already told you, we're not allowed personal visitors here."
    scene 04_0489 with dissolve
    mc "Nettie, please wait."
    mc "I'm not here to annoy you or get you into trouble."
    scene 04_0490 with dissolve
    mc "I came to apologize."
    scene 04_0491 with dissolve
    net nun "Apologize?\nFor what, exactly?"
    mc "For the way I behaved after you told me... what you told me at the motel."
    net nun "So, {i}you{/i} believe me?"
    net nun "{i}{b}YOU{/b}{/i}?"
    mc "Every word."
    scene 04_0492 with dissolve
    net nun "When I prayed for a miracle, {i}this{/i} wasn't what I had in mind."
    scene 04_0493 with dissolve
    net nun "Regardless, you still need to leave."
    mc "Nettie! C'mon!"
    scene 04_0494 with dissolve
    mc "Meet me at the motel again. {i}Please{/i}!"
    mc "Nettie!"
    net nun "I'll think about it."
    scene 04_0495 with Fade(3, 2, 3)
    pause 1.5
    scene 04_0496 with Fade(1, 2, 1)
    pause 1.0
    scene 04_0497 with Fade(1, 2, 1)
    pause 1.0
    scene 04_0498 with Fade(1, 2, 1)
    pause 1.0
    scene 04_0499 with Fade(1, 2, 1)
    pause 1.0
    scene 04_0500 with Fade(1, 2, 1)
    mct "Damn it."
    scene 04_0501 with dissolve
    mct "Guess she decided not to come."
    mct "May as well head home."
    play sound "text.mp3"
    pause 0.5
    scene 04_0502 with dissolve
    pause 1.0
    show screen CellPhone("Sue")
    msg_nvl "Why have you returned to Cedar Grove?"
    mc_nvl "None of your business."
    msg_nvl "We will discuss your attitude when you return."
    msg_nvl "When will that be exactly?"
    mc_nvl "Soon."
    msg_nvl "Fine."
    msg_nvl "Your service is required. You'll need to make a detour."
    mc_nvl "To where?"
    msg_nvl "Brookvale.\nI'll forward you the exact location."
    mc_nvl "What do you expect me to do when I get there?"
    msg_nvl "As you're told."
    mc_nvl "What the hell does that mean??"
    mc_nvl "Sue?"
    call CloseCell ()
    scene 04_0503 with dissolve
    mct "Need to get rid of the tracking device in this damn phone."
    scene 04_0504 with Fade(1, 2, 1)
    pause 0.5
    scene 04_0505 with dis1
    pause 0.5
    scene 04_0506 with dis1
    pause 0.5
    scene 04_0507 with dissolve
    net "Are you leaving?"
    mc "I didn't think you were coming."
    net "I almost didn't."
    scene 04_0508 with dissolve
    net "So?"
    mc "You, uhh, wanna go up to the room?"
    net "No, it stinks in there.\nJust say what you have to say."
    scene 04_0509 with dissolve
    mc "Damn, Nettie!\nI know I upset you, but, jeez!"
    mc "Give me a chance, please."
    scene 04_0510 with dissolve
    pause 2.0
    scene 04_0511 with dissolve
    net "Okay."
    if EzModeActive:
        call EzModeAsk ("Nettie")
        if _return:
            $ Nettie.Add("EZ")
    scene 04_0512 with dissolve
    net "Is this yours?"
    mc "Uhh, yeah."
    scene 04_0513 with dissolve
    net "Great.\nLet's go."
    mc "Go?\nWhere??"
    scene 04_0514 with dissolve
    net "You can buy me a drink."
    jump CedarGrove_NettieBar
return

label CedarGrove_NettieBar:
    scene 04_0515 with Fade(2, 3, 1)
    mc "Nettie! Wait!"
    scene 04_0516 with dissolve
    mc "When you said you wanted a drink, I thought you meant a coffee... or... a smoothie!"
    mc "Are you even allowed alcohol??"
    scene 04_0517 with dissolve
    net "I'm not a child, [mc]."
    mc "You know what I mean!"
    net "Are you going to buy me a drink or {i}not{/i}?"
    mc "Uhh... okay.\nWhat do you want?"
    net "I don't know. I've never tried it."
    scene 04_0518 with dissolve
    barm "Hi."
    scene 04_0519 with dissolve
    barm "What'll it be?"
    if not EzModeActive:
        menu:
            "Order an alcoholic drink":
                $ Nettie.Add("Alc")
                mc "I'll have a beer and any cocktail, please."
            "[wk_y]Order a non-alcoholic drink":
                mc "I'll have a beer, and can you make a no-alcohol cocktail, please?"
    elif Nettie.Has("EZ"):
        mc "I'll have a beer, and can you make a no-alcohol cocktail, please?"
    else:
        $ Nettie.Add("Alc")
        mc "I'll have a beer and any cocktail, please."
    barm "Sure thing."
    scene 04_0520 with fade
    pause
    scene 04_0521 with dissolve
    net "Mmm! Delicious!"
    mc "What's goin' on with you, Nettie?"
    scene 04_0522 with dissolve
    net "Hah! No!\nWe're not here to talk about me."
    net "You can begin. Let me hear your apology."
    scene 04_0523 with dissolve
    mc "Damn! You wanna make this tough for me, huh?"
    mc "Fair enough, I deserve it."
    scene 04_0524 with dissolve
    mc "Nettie, I'm {b}truly{/b} sorry for the way I reacted.\nIt was inappropriate and wrong."
    mc "I should've considered what you had told me before attempting to defend... {i}him{/i}."
    mc "I should've been supportive of you. Please, I {b}beg{/b} for your forgiveness."
    scene 04_0525 with dissolve
    net "Wow!\nThat was actually pretty good... for {i}you{/i}!"
    scene 04_0526 with dissolve
    pause 1.0
    scene 04_0525 with dissolve
    net "I wasn't surprised by the way you acted, if I'm honest."
    net "It's what you've always done, isn't it?\nAlways stood up for him. Always fought for him."
    net "He didn't deserve you, [mc].\nAnd {i}you{/i} deserved better."
    scene 04_0527 with dissolve
    net "I never understood why you were even his friend."
    net "You were {i}so{/i} different."
    net "Since your last visit, you've been on my mind a lot."
    scene 04_0528 with dissolve
    net "I wanted to hate you as much as I hate him."
    net "I tried to remember all the times he was horrible to me, and you did nothing."
    net "But the only memories I have of you... you were always so sweet to me."
    net "And for the first time, I realized something..."
    scene 04_0529 with dissolve
    net "In those dark moments of his... you were {i}never{/i} there."
    net "I started remembering the times you {i}were{/i} together, and he was always on his best behavior!"
    net "He {b}knew{/b}!\nHe knew you wouldn't have stood for his bullshit!"
    net "He was scared of losing his only friend."
    scene 04_0530 with dissolve
    mc "I wish it were that simple, Nettie."
    mc "The truth is, I {b}should've{/b} seen it, but I refused to open my eyes."
    scene 04_0531 with dissolve
    net "No, [mc].\nWhether you like it or not, I think you're just like the rest of us - one of his victims."
    scene 04_0532 with dissolve
    net "So, with that in mind, apology accepted.\nAnd thank you for making the effort."
    scene 04_0533 with dissolve
    mc "Thanks, Nettie."
    scene 04_0534 with dissolve
    net "You can thank me by getting me another one of these!"
    scene 04_0535 with Fade(2, 3, 2)
    mc "Are you ready to tell me what this is all about?"
    scene 04_0536 with dissolve
    if not Nettie.Has("Alc"):
        net "Why does it have to be about {i}anything{/i}?"
        net "Maybe I simply wanted to try alcohol for once in my life?"
    else:
        net "It's not about anything!"
        net "I just wanted to try something new for once in my life!"
    mc "C'mon, Nettie. This {i}isn't{/i} you."
    scene 04_0537 with dissolve
    net "Ughh... Maybe I'm just tired of pretending."
    mc "Pretending?"
    net "I... I don't think I'm cut out for this life anymore."
    net "At the church earlier, when you walked in, what did you see?"
    mc "I saw you. You were praying."
    scene 04_0538 with dissolve
    net "No. You saw me {i}pretending{/i} to pray.\nIn my mind, I was doing anything but."
    net "I'm not sure I even believe anymore."
    net "There's so much pain, and horror, and suffering in this world."
    scene 04_0539 with dissolve
    mc "I'm pretty sure you're not the first nun to have a crisis of faith, Nettie!"
    scene 04_0540 with dissolve
    net "When you heard I'd run away and joined the church, what did you think?"
    mc "Uhh... I... I don't remember."
    scene 04_0541 with dissolve
    net "Come on, yes you do. Be honest, [mc]."
    mc "I thought it was a stupid joke, or something."
    scene 04_0542 with dissolve
    net "[lol]"
    scene 04_0543 with dissolve
    mc "You weren't {i}that{/i} religious!"
    mc "I thought... if you had run away, we'd more likely find you at a circus!"
    net "[lol]"
    scene 04_0544 with dissolve
    net "That kinda proves my point, though."
    net "It wasn't the destination that was important to me; it was the escape."
    net "I wanted to find somewhere I could feel safe. Protected."
    scene 04_0545 with dissolve
    mc "You joined the church to get away from Pete??"
    net "I knew things would only get worse once he'd return from duty."
    net "He only failed that night because you disturbed him.\nNext time I wouldn't be so lucky."
    mc "Damn, Nettie. I had no idea."
    scene 04_0546 with dissolve
    net "He did.\nHe tracked me down a few months later and tried to get me to come home."
    net "I started moving around the country, never staying in one church for too long."
    net "I was in this town when I heard he'd died. Been here ever since. No need to keep running anymore."
    scene 04_0545 with dissolve
    mc "I wish I'd have known. I would've helped!"
    scene 04_0547 with dissolve
    net "You can help me now by getting me another one of these!"
    scene 04_0548 with dissolve
    mc "Haven't you had enough?"
    net "Nope!"
    scene 04_0549 with Fade(2, 3, 2)
    net "Mmmm."
    if Nettie.Has("Alc"):
        net "I love thish drink!"
    else:
        net "I can't get enough of this drink!"
    scene 04_0550 with dissolve
    mc "Are you drunk? Heh."
    if Nettie.Has("Alc"):
        net "Nooope![giggles]"
    else:
        net "Not as much as I thought I'd be by now!"
    scene 04_0551 with dissolve
    if Nettie.Has("Alc"):
        net "Oh no!!\nYour drink's gone!\nWhersh your drink??"
    else:
        net "You're not having another?"
    mc "No, I'm driving, remember!"
    scene 04_0552 with dissolve
    mc "Do you need to get back soon?"
    scene 04_0553 with dissolve
    if Nettie.Has("Alc"):
        net "Are youuu crazy?! I can't go home like thiis!!"
        net "I'll shtay with you!"
    else:
        net "Oh dear! [mc], I can't go back to the convent in this state!!"
        net "I'll have to stay with you!"
    scene 04_0554 with dissolve
    mc "What?!"
    net "You don't mind, do you?"
    mc "Uhh... No."
    scene 04_0555 with dissolve
    if Nettie.Has("Alc"):
        call Emotion (net, "hic", "You're a good friend, I lovvvve you!")
    else:
        net "I knew you'd say yes!\nYou're a good friend, [mc]."
    scene 04_0556 with dissolve
    net "Mmmm."
    mc "Err... It's empty."
    scene 04_0557 with dissolve
    net "Awww!"
    mc "Come on, let's go. I think you've had more than enough.[lol]"
    scene 04_0558 with Fade(2, 3, 2)
    mc "Almost there, you can make it..."
    net "[giggles]"
    scene 04_0559 with dissolve
    if Nettie.Has("Alc"):
        mct "I probably should've cut her off after two!"
    else:
        mct "Maybe it was a mistake putting a little alcohol in that last drink..."
        mct "I wanted her to feel the buzz... but she's behaving like she's smashed!"
    scene 04_0560 with fade2
    net "Woo! We made it!"
    scene 04_0561 with dissolve
    pause 0.5
    scene 04_0562 with dissolve
    call Emotion (net, "SIGH", "I loooove this bed.")
    scene 04_0563 with dissolve
    if Nettie.Has("Alc"):
        mct "She's wasted! Heh."
    else:
        mct "She HAS to be faking it!\nOkay... I'll play along. Heh."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e04/04_0564.webp", 710, 730, Nettie.Has("Alc"), "CedarGrove_AF01") with dissolve
        mc "Do you need help getting into bed?"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 04_0564
            hide screen imgMap 
    else:
        scene 04_0564 with dissolve
        mc "Do you need help getting into bed?"
        if not EzModeActive:
            menu:
                "Lift up her dress":
                    call CedarGrove_AF01
                "Don't":
                    pass
    if not Nettie.isActive():
        scene black with Fade(2, 3, 0)
        call CedarGrove_NettieNextMorning (0)
        jump CedarGrove_End02
    $ aa=""
    if Nettie.Has("Z1"):
        $ aa="a"
        $ Nettie.Del("Z1")
    show expression "04_0579" + aa with dissolve
    net "I'm {i}already{/i} in bed, silly goose![giggles]"
    mc "Err... No, you're not!"
    call Emotion (net, "Mumbles")
    show expression "04_0580" + aa with dissolve
    net "Are youuu sure?"
    mc "Pretty sure! Heh."
    scene 04_0581 with dissolve
    call Emotion (net, "Ughhhh", "Okayyyyy.")
    scene 04_0582 with dissolve
    net "Awww! You're great, [mc]. You know that?"
    mc "I am?"
    net "Yes, you are.\nYou are. You're great."
    scene 04_0583 with dissolve
    net "Know why?"
    net "You're the {b}only{/b} guy to ever take me out on a date!"
    mc "Uh... a date??"
    net "Yep!\nNever been on one before tonight!"
    scene 04_0585 with dissolve
    net "Ooohhh.... You know {i}what else{/i} I've never done???!"
    mc "Gotten drunk? [lol]"
    scene 04_0584 with dissolve
    net "[lol]"
    net "I'm not drunk!"
    if not Nettie.Has("Alc"):
        mct "I know."
    else:
        mc "Hah! If you say so."
    scene 04_0585 with dissolve
    net "[giggles]"
    net "I've never..."
    net "Kissed anyone!"
    net "Like a {b}proper{/b}, real kiss!"
    scene 04_0586 with dissolve
    net "OHH! I have an idea!"
    net "{i}You{/i} want to be my first kiss, [persistent.McName]?"
    $ nextDay = 0
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Sure":
                $ tCh=True
            "Nope, you're drunk":
                pass
    elif Nettie.Has("EZ"):
        $ tCh=True
    if tCh:
        if not Nettie.Has("Alc"):
            mc "Sure."
            scene 04_0593 with dissolve
            net h "What?!"
            net "I didn't think you'd agree!![lol]"
            mc "[lol] I didn't think you were serious."
            scene 04_0594 with dissolve
            net "I was!"
            net "You can't back out now, Mister!"
            scene 04_0595 with dissolve
            net "So kiss me... before I wuss out."
            $ nextDay = 1
        else:
            scene 04_0593 with dissolve
            net "Okay!"
            scene 04_0594 with dissolve
            net "I don't know how to do it, though!"
            mc "I'll show you."
            $ nextDay = 2
        call NettieReplay01
    else:
        if Nettie.Has("Alc"):
            $ Nettie.Score(1)
            scene 04_0587 with dissolve
            mc "Nettie, I can't kiss you while you're drunk. It wouldn't be right."
            mc "If you want us to kiss, ask me when you're sober."
            net "Oh, okay."
            scene 04_0588 with dissolve
            net "You're soooo cute with your serious face."
            scene 04_0589 with dissolve
            call Emotion (net, "UGGHHH", "I'm sooo tired!")
            scene 04_0590 with dissolve
            mc "Nettie?"
            net "[whi]..Zzzz.."
            mct "Great."
            scene 04_0591 with dissolve
            mct "Guess I'll take the couch then."
            scene 04_0592 with Fade(2, 1, 1)
            mc "[whi]..Zzzz.."
            scene black with Fade(2, 3, 0)
            $ nextDay = 3
    call CedarGrove_NettieNextMorning (nextDay)
    jump CedarGrove_End02
return

label CedarGrove_NettieNextMorning(s):
    if s==0:
        scene 04_0721 with Fade(1, 2, 3)
        mc "[whi]..Zzzz.."
        scene 04_0723 with fade1
        mct "I couldn't have fucked things up more with Nettie last night if I'd tried!"
        mct "There's no way back from this.\nI'll respect her wishes and leave her alone."
        mct "Time to go home."
        scene 04_0724 with fade1
        mct "At least I'll never have to come back here, to this shithole."
    elif s == 1:
        $ Nettie.Add("L1")
        scene 04_0720 with Fade(1, 2, 3)
        mc "[whi]..Zzzz.."
        scene 04_0758 with fade1
        pause
        scene 04_0759 with dissolve
        net "[kiss]"
        scene 04_0758 with dissolve
        pause 0.5
        scene 04_0760 with dissolve
        net "[whi][mc]?"
        net "[whi]Wake up. I need to leave soon."
        mc "[whi]..Nnhhh.."
        scene 04_0761 with dissolve
        net "Good morning."
        scene 04_0762 with dissolve
        net "Last night was so much fun!\nSorry for getting drunk, but thanks for looking after me!"
        mc "Err, sure. Anytime."
        scene 04_0763 with dissolve
        net "I'd better get dressed.\nI need to get back."
        mc "Okay."
        call CedarGrove_NettieNextMorning_Ride (True)
    elif s == 2:
        call CedarGrove_NettieNextMorning_convo
        call Emotion (net, "GASP", "OHH NO!!!")
        scene 04_0732 with dissolve
        net "I CAN'T BELIEVE YOU DID THAT TO ME, [mc!u]!"
        net "WHAT THE HELL WERE YOU THINKING?!"
        scene 04_0733 with dissolve
        mc "Whoa! Hold on!"
        mc "I didn't do {b}anything{/b}!"
        scene 04_0734 with dissolve
        mc "{b}You're{/b} the one who wanted to do it!"
        scene 04_0735 with dissolve
        net "I WAS DRUNK, [mc!u]!"
        scene 04_0736 with dissolve
        net "You were supposed to look after me, not take advantage of me!!"
        net "I can't believe you did that! Oh my god!!"
        scene 04_0737 with dissolve
        net "You're {b}worse{/b} than my damn brother!"
        scene 04_0738 with dissolve
        net "You {b}disgust{/b} me!"
        scene 04_0739 with dissolve
        net "I NEVER WANT TO SEE YOU AGAIN, UNDERSTAND??"
        scene 04_0740 with dissolve
        mc "Nettie!"
        scene 04_0741 with dissolve
        net "I mean it!\nDon't {b}ever{/b} come back here!"
        net "I TRUSTED YOU, [mc!u]!!"
        scene 04_0742 with dissolve
        mct "FUCK!"
        call CloseCharacterPath (Nettie, "Nettie", True)
        scene 04_0743 with dissolve
        mct "How's it MY fault?? SHE asked to do it, damn!"
        mct "Fuck it, I'm outta here!"
        scene 04_0724 with fade1
        mct "I'm never coming back to this shithole town."
    else:
        call CedarGrove_NettieNextMorning_convo
        $ Nettie.Add("L0")
        if Nettie.Has("Alc"):
            call Emotion (net, "GASP", "OHH GOD!")
            scene 04_0744 with dissolve
            net "[whi]Did I try to kiss you??"
            mc "You asked me to be your first kiss.[lol]"
            scene 04_0745 with dissolve
            mc "Don't worry, nothing happened."
            scene 04_0746 with dissolve
            net "I know."
            net "Thank you, [mc]."
            net "I shouldn't have gotten drunk, but I knew I could trust you to look after me."
            call CedarGrove_NettieNextMorning_Ride
        else:
            call Emotion (net, "GASP", "Uhhh...")
            scene 04_0747 with dissolve
            net "You refused to kiss me last night."
            mc "Yeah."
            net "The drinks you bought me... They were non-alcoholic, weren't they?"
            mc "Uhh, yeah. Apart from the last one."
            scene 04_0748 with dissolve
            net "You're a true gentleman, [mc]. Thank you."
            call CedarGrove_NettieNextMorning_Ride
return

label CedarGrove_NettieNextMorning_convo:
    scene 04_0722 with Fade(1, 2, 3)
    mc "[whi]..Zzzz.."
    scene 04_0725 with fade1
    call Emotion (mc, "Groan")
    scene 04_0726 with fade
    mc "[whi]Nettie..."
    call Emotion (net, "Mumbles")
    mc "Nettie, time to wake up."
    scene 04_0727 with dissolve
    call Emotion (net, "Groan", "Nnhh...okay...")
    mc "How you feelin'?"
    if not Nettie.Has("Alc"):
        return
    scene 04_0728 with dissolve
    net "[whi]Ugghh... My head...."
    net "[whi]What... what happened last night??"
    scene 04_0729 with dissolve
    mc "You had a few too many! Heh."
    scene 04_0730 with dissolve
    net "Uggh... [whi]If {b}this{/b} is how alcohol makes you feel, why do people drink it??!"
    mc "Good question!"
    net "[whi]Last night... It's all fuzzy... What happ..."
    scene 04_0731 with dissolve
return

label CedarGrove_NettieNextMorning_Ride(s=False):
    scene 04_0749 with fade1
    mc "Let me drive you back!"
    net "I told you, my friend's on her way to pick me up!"
    net "It'll be easier for me to sneak back in.\nShe helped me sneak out!"
    scene 04_0750 with dissolve
    $ Nettie.Add("Cell")
    net "I hope you don't mind; I saw your cell on the table, so I added my number."
    mc "Great! Next time I owe you an apology, I can do it by text![lol]"
    net "[lol]"
    play sound "car3.mp3"
    scene 04_0751 with dissolve
    pause 0.5
    scene 04_0752 with dis1
    mc "What the hell is that??"
    play sound "car_idle.mp3"
    scene 04_0753 with dissolve
    net "[lol]That's my ride!"
    scene 04_0754 with dissolve
    net "I'm glad you came, [mc]."
    mc "Me too."
    net "Will you come back to see me again sometime?"
    mc "Of course!"
    if s:
        scene 04_0755 with dissolve
        net "Good. I'd {b}really{/b} like to get drunk with you again."
    scene 04_0756 with Fade(1, 0.5, 1)
    play sound "car_pull.mp3"
    pause 0.5
    scene 04_0757 with dis1
    pause 0.5
    scene 04_0724 with fade1
    mct "Made the right call coming back here.\nSo happy we're friends again!"
return

label CedarGrove_End02:
    pause 2.0    
    $ brookridge_open=True
    $ brookvale_open=True
    jump CedarGrove_Leave
return

label CedarGrove_Start3:
    scene 07_0541 with Fade(0, 3, 3)
    mct "I messaged her hours ago to let her know I was coming... still no reply."
    scene 07_0542 with dissolve
    mct "Guess I'll just have to wait until I hear from her."
    scene 07_0543 with Fade(1, 2, 1)
    mct "Jeez... I'm getting used to the smell in here... That ain't good..."
    scene 07_0544 with dissolve
    mct "Could jump in the shower..."
    scene 07_0545 with dissolve
    mct "...Need one after that drive..."
    scene 07_0546 with Fade(3, 4, 3)
    scene 07_0547 with dis1
    call Emotion (mc, "Groan")
    scene 07_0548 with fadehold
    mct "Still no reply?!"
    scene 07_0549 with dissolve
    mct "Fuck it..."
    scene 07_0550 with Fade(1, 2, 2)
    pause
    scene 07_0551 with dissolve
    pause 0.5
    scene 07_0552 with dis1
    priest "Good day to you, sir."
    scene 07_0553 with dissolve
    priest "May I be of service?"
    mc "Err, hi... Yeah... I-"
    scene 07_0554 with dissolve
    mc "... Actually, I think I'd be more comfortable talking to a nun, if you don't mind."
    call Emotion (priest, "Grumbles")
    scene 07_0555 with dissolve
    priest "{size=*1.5}SISTER."
    scene 07_0556 with dissolve
    priest "You're required."
    scene 07_0557 with dissolve
    priest "I'll leave you to it."
    scene 07_0558 with dissolve
    mc "Thanks."
    scene 07_0559 with dissolve
    mct "Damn it... not Nettie."
    scene 07_0560 with dissolve
    liz nun "Hello.\nHow may I help you?"
    scene 07_0561 with dissolve
    mc "I'm sorry, Sister. I thought you were someone else.\nI'm looking for-"
    scene 07_0562 with dissolve
    liz nun "OH! You're Nettie's friend!\n... Umm... [mc], right?"
    mc "Yeah."
    scene 07_0563 with dissolve
    liz nun "Pleased to meet you!"
    liz nun "I'm Sister Elizabeth."
    $ Elizabeth_name="Elizabeth"
    $ persistent.ElizabethLocked = False
    $ Elizabeth.Activate("Elizabeth")
    scene 07_0564 with dissolve
    liz nun "[whi]I'm the one who helps her escape to visit you!"
    mc "[whi]Escape??"
    scene 07_0565 with dissolve
    liz nun "Father David is a stickler for rules, and he runs a tight ship."
    liz nun "Anyway, how can I help you today?"
    mc "I'm looking for Nettie.\nI sent her a text message hours ago, but she hasn't replied."
    scene 07_0566 with dissolve
    liz nun "Like I said - a stickler for rules!\nWe're not allowed cellphones while here."
    scene 07_0567 with dissolve
    liz nun "But don't worry, she's fine!\nShe left earlier to visit a member of our flock."
    liz nun "She'll return soon."
    scene 07_0568 with dissolve
    mc "Oh, okay.\nThanks, that puts my mind at ease."
    mc "Can you let her know I'm in town when she gets back?"
    mc "Tell her I'm at the usual place."
    liz nun "Sure."
    scene 07_0569 with dissolve
    mc "It was nice meeting you, Sister. Thanks for your help."
    liz nun "Goodbye."
    scene 07_0570 with fade1
    mct "Should grab some food before heading back to the Motel from Hell... still need that shower too!"
    call CenterText ("Some time later...")
    call Bruises ()
    $ aaa=""
    if Plr.Has("Bruises"):
        $ a="a"
    play sound "shower.mp3" fadein 1.0 loop
    scene 07_0571 with Fade(0, 1, 2)
    pause
    play soundAlt "knock.mp3" 
    pause
    play soundAlt "doorbang.mp3" volume 0.5
    pause
    scene 07_0572 with dissolve
    pause
    play soundAlt "doorbang.mp3" volume 0.5
    pause 0.5
    mc "[whi]Crap."
    mc "HOLD ON."
    scene 07_0571 with dissolve
    pause 0.5
    stop sound
    pause 0.5
    show expression "07_0573" + aaa with dissolve
    play soundAlt "doorbang.mp3" volume 0.5
    mc "I'M COMING! JEEZ!"
    scene 07_0574 with dissolve
    mc "Sister!\nSorry, I thought you were Nettie."
    mc "Sister?"
    liz nun "[whi]Yes?"
    scene 07_0575 with dissolve
    liz nun "Yes!"
    liz nun "Umm... Nettie!\nIs Nettie here?"
    mc "No. Why?"
    liz nun "She didn't come back, and she isn't at the convent."
    liz nun "I thought she might have come here."
    mc "No.\nCome in."
    show expression "07_0576" + aaa with dissolve
    mc "You said earlier that she went to visit someone... Do you know where?"
    liz nun "Yes."
    show expression "07_0577" + aaa with dissolve
    mc "Good. That's where we'll start."
    liz nun "Do you think something has happened to her??"
    show expression "07_0578" + aaa with dissolve
    mc "I don't know, but {b}you're{/b} worried enough to come here looking for her."
    mc "... So let's go find out."
    $ tCh=None
    if EzModeActive:
        call EzModeAsk ("Elizabeth")
        if _return:
            $ Elizabeth.Add("EZ")
            $ tCh=True
    if not EzModeActive:
        menu:
            "Ask her to turn around while you get dressed":
                pass
            "[wk_y]Get dressed":
                $ tCh=True
    if tCh:
        $ Elizabeth.Score(1)
        $ Elizabeth.Add("Saw")
        show expression "07_0581" + aaa with dissolve
        mc "Have you called any of her friends?"
        liz nun "She doesn't really have any friends outside the convent.\nWe keep ourselves to ourselves, and socializing is forbidden."
        show expression "07_0582" + aaa with dissolve
        mc "That narrows things down at least."
        liz nun "I can see why she likes visiting you."
        mc "Nettie and I are just friends."
        show expression "07_0583" + aaa with dissolve
        mc "You know, you're free to turn around."
        show expression "07_0584" + aaa with dissolve
        liz nun "Does it make you uncomfortable that {i}I'm{/i} not uncomfortable seeing you naked?"
        mc "Not at all."
        mc "Quite the opposite, in fact."
        show expression "07_0585" + aaa with dissolve
        liz nun "Yes, so I see."
        liz nun "Is that why you chose to put your t-shirt on first?"
        scene 07_0586 with dissolve
        mc "Nah, you seem to be enjoying looking at it; figured I'd give you a little more time."
        scene 07_0587 with dissolve
        liz nun "You clearly find me looking at it arousing.\nAre you sure you weren't giving {i}yourself{/i} a little more time?"
        scene 07_0588 with dissolve
        mc "Hah!\nAre you {i}really{/i} a nun?"
        scene 07_0589 with dissolve
        liz nun "[lol]"
        scene 07_0590 with dissolve
        liz nun "A nun? Yes.\nA prude? No."
        scene 07_0591 with dissolve
        mc "This was fun, Sister.\nLet me know if you ever want to see it again, heh."
        liz nun "And if you ever want me to look at it again, you can let {i}me{/i} know."
        scene 07_0592 with dissolve
        mc "Touché."
    else:
        show expression "07_0579" + aaa with dissolve
        mc "Uhh... Would you mind?"
        liz nun "Hmm?"
        liz nun "Ohh! Yes!..."
        show expression "07_0580" + aaa with dissolve
        liz nun "... Sorry!"
        scene black with Fade(2, 2, 0)
    scene 07_0593 with fade
    mc "Does she go off on her own to visit people often?"
    liz nun "Occasionally. It's part of the job."
    scene 07_0594 with dissolve
    mc "Oh hell no!\nI ain't getting in {i}that{/i}."
    mc "We'll take the truck."
    scene 07_0595 with dissolve
    liz nun "Why??"
    mc "Well, for a start, I doubt I'll fit in it!\nCome on."
    scene 07_0596 with fade2
    liz nun "We're almost there."
    scene 07_0597 with dissolve
    liz nun "Take the next left."
    scene 07_0598 with dissolve
    pause 0.5
    scene 07_0599 with dis1
    scene 07_0600 with dis1
    scene 07_0601 with fadehold
    liz nun "That's the place."
    scene 07_0602 with dissolve
    liz nun "It'd be better if I went alone.\nThe woman who's staying there has been having a rough time..."
    liz nun "The last thing she needs is a strange man knocking on her door."
    mc "Okay."
    scene 07_0603 with fade
    pause 0.5
    scene 07_0604 with dissolve
    pause 0.5
    scene 07_0605 with dissolve
    pause 0.5
    scene 07_0606 with dissolve
    pause 1.5
    scene 07_0607 with dissolve
    scene 07_0608 with dissolve
    scene 07_0609 with dissolve
    mc "[whi]What the fuck?"
    scene 07_0610 with fade
    scene 07_0611 with dissolve
    scene 07_0612 with dissolve
    play sound "doorslam.mp3" volume 0.25
    scene 07_0613 with hpunch
    scene 07_0614 with dissolve
    scene 07_0615 with dissolve
    net nun "GET OFF HER!!"
    scene 07_0616 with dissolve
    play sound "punch03.mp3" volume 0.5
    scene 07_0617 with dissolve
    scene 07_0618 with dissolve
    ted "You fuckin' people!"
    scene 07_0619 with dissolve
    play sound "punch04.mp3"
    scene 07_0620 with dissolve
    scene 07_0621 with dissolve
    pause 0.5
    scene 07_0622 with dissolve
    mc "Nettie! Are you okay??"
    net nun "[mc]??"
    scene 07_0623 with dissolve
    mc "Sister?"
    liz nun "{size=*0.8}{font=Vanilla.ttf}*{i}Coughing{/i}*{/font}{/size} I'm okay."
    scene 07_0624 with dissolve
    mc "What the fuck's goin' on?"
    net nun "Hayley needed my help."
    scene 07_0625 with dissolve
    net nun "We didn't expect {i}him{/i} to turn up here!"
    net nun "He... he must've followed me from the church!"
    mc "Who the hell is he??"
    scene 07_0626 with dissolve
    hay "My whackjob ex."
    net nun "C'mon, Hayley, we need to get you out of here."
    scene 07_0627 with dissolve
    hay "What's the point?\nHe'll only find us again! He won't stop until we're dead!"
    scene 07_0628 with dissolve
    net nun "If you can't do it for you, then do it for Chloe. Now get up."
    hay "[whi]Fine."
    scene 07_0629 with dissolve
    mc "Who's Chloe?"
    liz nun "Her daughter."
    scene 07_0630 with dissolve
    call Emotion (ted, "Groan")
    net nun "We need to leave. NOW."
    hay "Sister! Chloe's hiding in the bedroom..."
    liz nun "On it..."
    scene 07_0631 with dissolve
    mc "Relax!\nHe ain't gonna do shit while I'm here!"
    scene 07_0632 with dissolve
    net nun "You don't understand, [mc] - He's a psychopath!\nLET'S GO!"
    scene 07_0633 with dissolve
    hay "[whi]FASTER!"
    scene 07_0634 with dissolve
    mc "{b}GUN!!"
    scene 07_0635 with dissolve
    pause 0.5
    scene 07_0636 with dissolve
    mc "Get the hell outta here!"
    scene 07_0637 with dissolve
    ted "AAGGHH!!"
    ted "GET THE FUCK OFF ME!"
    scene 07_0638 with dissolve
    ted "AFTER I'VE KILLED THAT BITCH AND HER DAUGHTER... YOU'RE NEXT!..."
    scene 07_0639 with dissolve
    ted "THEM NUNS TOO!"
    play sound "hit02.mp3"
    scene 07_0640 with hpunch
    call Emotion (mc, "Groan")
    scene 07_0641 with dissolve
    ted "I'M GONNA RAPE THEM IN THEIR FUCKIN' CHURCH!\nSTRING 'EM UP AND GUT THEM!"
    ted "I'LL FIND YOU AND EVERYONE YOU LOVE..."
    play sound "punch04.mp3"
    scene 07_0642 with hpunch
    scene 07_0643 with dissolve
    ted "I'M GONNA MAKE YOU WATCH WHILE I FUCK THEM AND SLICE OPEN THEIR THROATS...EVERY FUCKIN' ONE!"
    show screen WlkGuide(wkg005)           
    menu:
        "Knock him out":
            hide screen WlkGuide 
            $ TeddyD=False
            scene 07_0644 with dissolve
            mc "You talk too much."
            scene 07_0646 with dissolve
            play sound "punch03.mp3"
            scene 07_0647 with hpunch
            scene 07_0648 with dissolve
            pause 0.5
            scene 07_0649 with dissolve
        "Kill him":
            hide screen WlkGuide 
            $ TeddyD=True
            scene 07_0644 with dissolve
            mc "Nettie called you a psycho... I believe her."
            scene 07_0645 with dissolve
            mc "... and I believe you."
            scene 07_0653 with vpunch
            call Emotion (ted, "Gasping for air")
            scene 07_0654 with vpunch
            mc "So you'll never get the chance."
            call Emotion (ted, "Choking", "", True)
            scene 07_0656 with dissolve
            pause
            scene 07_0654 with vpunch
            pause 0.5
            scene 07_0655 with dissolve
    mc "[whi]Asshole."
    scene 07_0650 with dissolve
    pause 0.5
    scene 07_0651 with dissolve
    pause 0.5
    scene 07_0652 with dissolve
    pause 0.5
    scene 07_0657 with dissolve
    mct "Fuck... why does trouble always find me?"
    scene 07_0658 with dissolve
    pause 0.5
    scene 07_0659 with fade
    mc "Where are we going?"
    net nun "Just take us to the motel for now."
    call Emotion (hay, "Sobbing", "", True)
    jump CedarGrove_BackToMotel
return

label CedarGrove_BackToMotel:
    scene 07_0675 with fade2
    pause 0.5
    scene 07_0676 with dissolve
    scene 07_0677 with dissolve
    scene 07_0678 with dissolve
    scene 07_0679 with dissolve
    mc "I'll get them a room."
    scene 07_0680 with dis1
    pause 0.5
    scene 07_0681 with Fade(1, 2, 1)
    net nun "Get one?"
    mc "Yeah. Directly below mine."
    scene 07_0682 with fade
    net nun "Come on, guys. Quickly."
    scene 07_0683 with dissolve
    hay "Thank you for helping us back there."
    mc "You're welcome."
    $ persistent.HayleyLocked=False
    $ Hayley.Activate("Hayley")
    scene 07_0684 with dissolve
    net nun "What {i}are{/i} you doing here, [mc]?"
    mc "I came to see you. We need to talk."
    scene 07_0685 with dissolve
    chlo "Ewww... What's that smell??"
    $ persistent.ChloeLocked=False
    $ Chloe.Activate("Chloe")
    mc "Don't worry, kid... You'll get used to it."
    scene 07_0686 with dissolve
    chlo "I'm {i}not{/i} a kid."
    scene 07_0687 with dissolve
    mc "I'll, err... leave you to it then."
    net nun "I'll come up and see you in a few minutes."
    mc "Okay."
    scene 07_0688 with Fade(1, 2, 1)
    mct "Dread to think what might've happened to them had I not been here."
    if not TeddyD:
        mct "Asshole had a lot to say...\nProbably just empty threats."
        mct "He already knows where Nettie works.\nThat's gonna be the first place he'll go to look for the woman."
        mct "Nah... just full of shit. All mouth."
    else:
        mct "What the fuck do I do now?"
        mct "..."
        mct "... Need to get rid of the body."
        scene 07_0689 with dissolve
        mct "There's got to be..."
        mct "... There... An old quarry. Should be perfect."
        mct "About twenty minutes away."
        scene 07_0690 with dissolve
        mct "I'll do it tonight. Hopefully, no one finds him before then."
    call CenterText ("15 minutes later.")
    scene 07_0691 with fade
    play sound "knock.mp3"
    pause 1.0
    mc "It's open."
    scene 07_0692 with dissolve
    mc "How are they doing?"
    net nun "Shaken up, but I think they'll be okay."
    scene 07_0693 with dissolve
    mc "What the hell were you thinking, Nettie? Going there by yourself!?"
    net nun "It's my job, [mc]!"
    scene 07_0694 with dissolve
    net nun "He had no idea where she was. It was supposed to be safe!"
    net nun "I led him right to them!"
    scene 07_0695 with dissolve
    net nun "He wanted to... he said... he was going to kill us."
    net nun "I could see the hate in his eyes. He meant it."
    scene 07_0696 with dissolve
    net nun "... If you hadn't shown up..."
    scene 07_0697 with dissolve
    mc "I'm sorry. I didn't mean to snap at you."
    scene 07_0698 with dissolve
    net nun "I was so scared, [mc]."
    mc "It's okay. {b}{i}You're{/i}{/b} okay."
    net nun "I have to go. We need to report back to the convent."
    mc "Want me to come with you?"
    scene 07_0699 with dissolve
    net nun "No.\nI need you to stay here and keep them safe."
    net nun "I won't be long. I just need to warn Father David."
    net nun "We can talk when I get back."
    mc "Okay."
    scene 07_0700 with dissolve
    net nun "Thanks [mc]."
    scene 07_0701 with Fade(1, 2, 1)
    if TeddyD:
        mct "... I killed him..."
        mct "Fuck."
        mct "Why did I do that??"
        mct "... I... He would've gone after Nettie..."
        mct "... The tone of his voice... Those weren't empty threats he made..."
        mct "... I had to... He gave me no choice."
    else:
        mct "Warn Father David??"
        mct "Is she that worried?... or just being overly cautious?"
        mct "... She called him a psychopath..."
        mct "... He pulled out a gun... Why the fuck did he have a gun?"
        mct "Damn it. I don't think this is over."
    call CenterText ("An hour or so later.")
    scene 07_0702 with Fade(1, 2, 1)
    mct "Maybe I shouldn't tell Nettie about the whole Cara thing."
    mct "She has enough on her plate right now."
    mct "I can always come back another time."
    play sound "knock.mp3"
    pause 1.0
    scene 07_0703 with dissolve
    mc "It's still open."
    scene 07_0704 with dissolve
    hay "Is Chloe in here? Have you seen her?"
    mc "No. Why would she be in here?"
    scene 07_0705 with dissolve
    hay "Shit... Sorry... I.. I can't find her!"
    hay "I've looked everywhere! She's gone!"
    scene 07_0706 with dissolve
    mc "I'm sure she's fine. We'll find her."
    mc "When did you see her last?"
    scene 07_0707 with dissolve
    hay "About fifteen minutes ago!\nShe was watching the TV. I took a shower. When I got out, she was gone!"
    scene 07_0708 with dissolve
    mc "Okay. She couldn't have got very far."
    scene 07_0709 with dissolve
    mc "I'll drive around. You stay here in case she turns up."
    hay "Right... okay. Thank you."
    scene 07_0710 with Fade(1, 2, 1)
    play sound "car2.mp3"
    scene 07_0711 with dissolve
    scene 07_0712 with dissolve
    scene 07_0713 with dissolve
    scene 07_0710 with dissolve
    pause 0.5
    play sound "driving.mp3"
    scene 07_0714 with dissolve
    mct "One goddamn thing after another today."
    scene 07_0715 with dissolve
    mct "That has to be her... Who else would be walking out here?"
    scene 07_0716 with dissolve
    mct "Yeah, it's her."
    scene 07_0717 with dissolve
    pause 0.5
    scene 07_0718 with dissolve
    play sound "car_idle.mp3"
    mc "Hey, Kid! Where ya going?"
    chlo "I'M NOT A FUCKIN' KID!"
    scene 07_0719 with dissolve
    play sound "car_pull.mp3"
    scene 07_0720 with dis1
    scene 07_0721 with dis1
    scene 07_0722 with dis1
    scene 07_0723 with dissolve
    mc "You're right, I'm sorry."
    mc "Where you going, {i}Chloe{/i}?"
    chlo "I'm leaving!\nI hate this place! This town!"
    chlo "YOU CAN'T STOP ME!"
    scene 07_0724 with dissolve
    mc "Okay... But you know you're walking in the wrong direction, right?"
    mc "You're heading {b}towards{/b} town!"
    chlo "I have to get my phone first."
    scene 07_0725 with dissolve
    mc "Your phone?? Why?"
    chlo "BECAUSE!"
    scene 07_0726 with dissolve
    mc "It's getting dark. It gets real cold out here at night."
    mc "You'll freeze to death before you're even close to town!"
    chlo "I'll take my chances."
    scene 07_0727 with dissolve
    mc "C'mon Ki... {i}Chloe{/i}!\nAre you seriously willing to risk your life over a phone?!"
    mc "It's just a cell phone! We can get you a new one!"
    scene 07_0728 with dissolve
    chlo "It's... It's not about the phone."
    chlo "It's about what's {i}on{/i} it."
    scene 07_0729 with dissolve
    mc "CHLOE, ENOUGH!\nSTOP."
    scene 07_0730 with dissolve
    mc "What's goin' on?"
    scene 07_0731 with dissolve
    chlo "I have... {i}things{/i}... on my phone. I {b}have{/b} to get it back."
    mc "{i}Things{/i}? What sort of things?"
    scene 07_0732 with dissolve
    chlo "{b}Private{/b} things."
    chlo "[whi]... Pictures."
    scene 07_0733 with dissolve
    mc "Pictures?!"
    mc "You're doing all this for some pictures? Are you nuts??"
    chlo "You don't understand!"
    scene 07_0734 with dissolve
    mc "So help me out here!\nDon't you have them saved in that, uhh... cloud thing?"
    mc "Isn't that the whole point of it?? Backups?"
    scene 07_0735 with dissolve
    chlo "OH MY GOD!\nWHAT ARE YOU TALKING ABOUT?!"
    mc "I'm tryin' to help you! But you're not telling me anything!"
    chlo "OKAY... FINE!"
    scene 07_0736 with dissolve
    chlo "I have some nudes on my phone! Happy now??"
    scene 07_0737 with dissolve
    mc "Nudes??"
    mc "Like... photos... of {i}you{/i}?"
    chlo "Yes! There are naked photos of me on my cell!\nEveryone does it these days, get over it!"
    mc "Okay...\nSo, if everyone does it... what's the problem?"
    scene 07_0738 with dissolve
    chlo "Teddy has my phone!\nHe took it off me so I couldn't call the cops!"
    mc "Teddy? The guy who was at the house?"
    chlo "Yeah."
    scene 07_0739 with dissolve
    chlo "I {b}have{/b} to get it back before he finds them!"
    mc "Why?"
    mc "I mean... I know it could be a bit embarrassing for you if he sees them... but is it really {i}that{/i} big of a deal?"
    scene 07_0740 with dissolve
    chlo "{b}AAAGGH!{/b} IT'S NOT ABOUT ME!!"
    scene 07_0741 with dissolve
    chlo "I KNEW YOU WOULDN'T UNDERSTAND!!"
    scene 07_0742 with dissolve
    mc "Chloe, wait. You're right, I {i}don't{/i} understand."
    mc "Just tell me, what are you so worried about?"
    scene 07_0743 with dissolve
    chlo "If Teddy finds those pictures, he'll try and use them against my mom..."
    chlo "He'll blackmail her into going back to him.\nHe'll threaten to send them to {b}everyone{/b} if she refuses."
    scene 07_0744 with dissolve
    chlo "And he {b}would{/b} send them."
    chlo "I don't want her to have to go back to him because of me."
    scene 07_0745 with dissolve
    chlo "He's a horrible, evil bastard.\nHe's put her through hell already. She can't take much more."
    chlo "I {b}hate{/b} him!"
    scene 07_0746 with dissolve
    mc "Okay, I get it.\nYou're trying to protect your mom."
    mc "But think about what you're doing for a second..."
    mc "Even if you made it to town, do you think Teddy will still be at the house?\nYou have no idea where he is."
    mc "And even if you did find him, is he just gonna hand over your phone and let you leave?"
    mc "Or will he lock you up in a room somewhere and use {b}you{/b} to blackmail your mom?"
    scene 07_0747 with dissolve
    chlo "[whi]Fuck.\nI... I... didn't think that far ahead."
    mc "Your phone... It's locked, right? Password protected?"
    chlo "Yeah."
    mc "Does he know your password?"
    scene 07_0748 with dissolve
    chlo "Hell no."
    mc "So he can't get in. Can't look through your photos."
    chlo "But he knows people. Bad people. They could hack it for him."
    scene 07_0749 with dissolve
    mc "C'mon, Chloe... Think about it.\nIs he {i}really{/i} gonna go through all that effort to {b}maybe{/b} find a few compromising photos of you?"
    chlo "Uhh... No... I... I guess not."
    scene 07_0750 with dissolve
    mc "Don't worry, you and your mom will get through this."
    chlo "No, we won't.\nYou don't know him!"
    scene 07_0751 with dissolve
    chlo " He won't stop looking for us.\nIf {b}he{/b} can't have my mom, no one can."
    chlo "He'll kill her. Me too, probably.\nHe's done it before."
    $ tCh=None
    if EzModeActive:
        call EzModeAsk ("Chloe")
        if _return:
            $ Chloe.Add("EZ")
            $ tCh=True
    if TeddyD:
        if not EzModeActive:
            menu:
                "[wk_y]Tell her Teddy's dead":
                    $ tCh=True
                "Say nothing":
                    pass
        if tCh:
            $ Chloe.Add("Knows")
            $ Chloe.Score(1)
            scene 07_0752 with dissolve
            mc "I shouldn't tell you this...\nBut you shouldn't have to live in fear..."
            mc "I'm trusting you to keep a secret. Can you do that?"
            chlo "Yeah."
            mc "Teddy's... dead."
            scene 07_0753 with dissolve
            chlo "What?!"
            chlo "How do you..."
            mc "He had a gun. He tried to shoot at your mom."
            mc "... I killed him. I had to."
            scene 07_0754 with dissolve
            chlo "Holy shit!\n{b}You{/b} killed him?!"
            chlo "{b}For real{/b}??"
            mc "Yeah."
            scene 07_0755 with dissolve
            chlo "I don't believe it!"
            chlo "I know it sounds horrible, but... I'm so glad!"
            scene 07_0756 with dissolve
            chlo "Wait... Does this mean you're gonna be in trouble??"
            chlo "Will you have to go to prison?!"
            scene 07_0757 with dissolve
            mc "I hope not... I'm workin' on it."
            scene 07_0758 with dissolve
            chlo "I was there; I'll be your witness.\nIt was self-defense!"
            mc "Thanks, Chloe, but don't worry about me.\nI'll deal with whatever comes my way."
            mc "For now, just keep it to yourself."
            chlo "I will, I swear."
        else:
            mc "I'll talk to Sister Nettie. We'll find you both somewhere safe."
    mc "Let's get back to the motel. Your mom's worried about you."
    scene 07_0759 with Fade(1, 2, 1)
    play sound "car_pull.mp3"
    scene 07_0760 with dis1
    scene 07_0761 with dis1
    scene 07_0762 with dis1
    scene 07_0763 with dis1
    hay "CHLOE!"
    scene 07_0764 with dissolve
    hay "You had me so worried!"
    chlo "Sorry Mom.\nI just went for a walk to clear my head."
    scene 07_0765 with dissolve
    net "Of all the days you could've chosen to visit, I'm incredibly grateful you chose today!"
    mc "Heh.\nYou think {i}The Big Guy{/i} sent me to help you out?"
    scene 07_0766 with dissolve
    net "He {i}does{/i} work in mysterious ways, so who knows?[lol]"
    scene 07_0767 with dissolve
    net "Seriously though, I can't thank you enough for what you did."
    net "I don't even dare think about what would've happened if you hadn't shown up."
    scene 07_0768 with dissolve
    mc "You would've kicked his ass, Nettie - That's what would've happened."
    mc "You're a bad-ass nun! So's your sidekick!"
    scene 07_0769 with dissolve
    net "Hear that, Lizzie?\nHe thinks we're bad-ass nuns![lol]"
    scene 07_0770 with dissolve
    liz "Damn straight we are!"
    scene 07_0771 with dissolve
    liz "We should still get them inside though."
    scene 07_0772 with dissolve
    net "Lizzie's right, come on guys."
    scene 07_0773 with dissolve
    mc "I'm just up the stairs if you need me."
    net "I know.\nI'll come up in a little while."
    scene 07_0774 with dissolve
    net "Come on, Sweetheart. Let's watch TV."
    scene 07_0775 with dissolve
    hay "Thank you for finding her."
    scene 07_0776 with dissolve
    hay "We were never properly introduced.\nI'm Hayley. It's nice to meet you, [mc]."
    scene 07_0777 with dissolve
    mc "You too."
    hay "I'm sorry you've been dragged into this... but selfishly, I'm so glad you were."
    mc "Heh, story of my life."
    jump CedarGrove_NettieTalk
return

label CedarGrove_NettieTalk:
    call CenterText ("Later that evening.", True)
    scene 07_0778 with fade
    pause
    play sound "knock.mp3"
    pause 1.0
    scene 07_0779 with dissolve
    mc "Come in."
    scene 07_0780 with dissolve
    chlo "Uh... hi."
    mc "Oh, Chloe. Everything okay?"
    scene 07_0781 with dissolve
    chlo "Yeah."
    scene 07_0782 with dissolve
    chlo "I just wanted to apologize for leaving earlier, and to say thank you for coming to get me."
    mc "It's all good. Forget about it."
    scene 07_0783 with dissolve
    chlo "It was such a stupid idea.\nI would've made everything even worse!"
    mc "Hey, don't be so hard on yourself.\nI've done plenty of stupid shit thinking I'm doing the right thing."
    mc "We all have."
    scene 07_0784 with dissolve
    mc "You were just tryin' to help your mom."
    mc "That's not a bad thing. It was brave."
    scene 07_0785 with dissolve
    chlo "You won't tell them, will you?\nAbout the... you know..."
    mc "What's there to tell?"
    mc "You went for a walk, and I gave you a ride back.\nThat's all that happened, right?"
    scene 07_0786 with dissolve
    chlo "Right."
    scene 07_0787 with dissolve
    chlo "You're a cool guy, [mc].\nWhy can't my mom find someone like you instead of assholes like Teddy?"
    chlo "It must be true - all the good ones {i}are{/i} taken!"
    chlo "And I bet you don't beat up on your wife!"
    scene 07_0788 with dissolve
    mc "Nah, never.\nThough I'm no longer married, so can't say I'm perfect, heh."
    chlo "Oh... sorry. Girlfriend then."
    mc "Nope."
    scene 07_0789 with dissolve
    chlo "Ohh... Maybe there's hope for my mom after all![lol]"
    play sound "knock.mp3"
    pause 1.0
    scene 07_0790 with dissolve
    mc "It's open."
    scene 07_0791 with dissolve
    net "Your mom's asking for you, Chloe."
    chlo "Okay."
    scene 07_0792 with dissolve
    chlo "It doesn't smell so bad in this room."
    net "Don't worry. It's only for one night."
    scene 07_0793 with dissolve
    net "You okay?\nI never got the chance to ask you what happened back at the house."
    net "He pulled out a gun??"
    scene 07_0794 with dissolve
    mc "Yeah. I managed to disarm him before he could use it."
    net "Jeez. That's so scary.\nI had no idea he was armed."
    mc "How did you get involved in all this?"
    scene 07_0795 with dissolve
    net "Hayley's a member of our church.\nNow and then, she'd show up with a black eye or a thick lip."
    net "Teddy beat her for years.\nShe finally found the courage to leave him."
    net "She asked for our help.\nThe church has a few properties, refuges, for situations just like this."
    net "Places where we can shelter abused families.\nWe try to keep the locations secret."
    scene 07_0796 with dissolve
    net "The only way he could've found her was if he'd followed me from the church."
    net "I was only there a few minutes before he knocked on the door and pushed his way in."
    net "He even brought a bag full of bottles of beer.\nClearly, he was planning on staying a while."
    scene 07_0797 with dissolve
    net "We tried to get him to leave, but he became more and more aggressive."
    net "We were trapped in there with him for hours before Lizzy knocked."
    net "Kept threatening to kill us. Describing exactly what he was gonna do to each of us."
    scene 07_0798 with dissolve
    net "I was terrified, [mc]."
    net "I truly believe he would've done {i}exactly{/i} what he had said if you hadn't stopped him."
    scene 07_0799 with dissolve
    mc "So what happens next?\nYou told Chloe {i}this{/i} is just for one night..."
    net "We have another place they can stay. We'll take them there tomorrow."
    net "Lizzie and I will stay there, too.\nFather David insisted we {b}all{/b} remain hidden until everything quietens down."
    mc "Makes sense.\nI'll come with you. Make sure everything goes smoothly."
    scene 07_0800 with dissolve
    net "Thanks. I kinda had a feeling you'd say that."
    net "We have one little problem left to solve..."
    mc "Okay...?"
    net "There's not enough room for everyone downstairs.\nMind if I stay up here with you?"
    scene 07_0801 with dissolve
    mc "Yeah, of course."
    if Nettie.hasScore(2):
        mc "I was thinking about sleeping on the couch again anyway.\nIt's way more comfortable than this bed![lol]"
        scene 07_0802 with dissolve
        net "You've already proved you're a gentleman, [mc].\nI trust you enough to share the bed with you!"
    elif Nettie.isSexual():
        mc "Need to borrow my t-shirt again?"
        net "No, I have my own this time.[lol]"
        mc "Heh, okay.\nI'll take the couch. I'll ask reception for an extra blanket."
        scene 07_0802 with dissolve
        net "Why?\nWe've already shared this bed once!"
    else:
        mc "I'll take the couch. I'll ask reception for an extra blanket."
        scene 07_0802 with dissolve
        net "There's no need for that. I trust you enough to share the bed."
    mc "Oh, okay. If you're sure."
    scene 07_0803 with dissolve
    net "It's settled then.\nI'll let the others know and get my stuff."
    scene 07_0804 with fade2
    mc "... and that's when I knew I was done.\nIt was time to quit and come home for good."
    net "Just like that??"
    mc "Yeah.\nWalking away was easy once I'd made the decision."
    scene 07_0805 with dissolve
    net "And you have no regrets about leaving? After giving all those years?"
    mc "Damn!\nDoes the church issue you with nightwear as part of the uniform, too?? Heh."
    scene 07_0806 with dissolve
    net "What?"
    net "Ohh![lol]"
    scene 07_0807 with dissolve
    net "They don't!"
    net "I just like wearing black and white, I guess![lol]"
    scene 07_0808 with Fade(2, 1, 1)
    net "You still haven't told me why you're here."
    scene 07_0809 with dissolve
    mc "Uhh... yeah..."
    mc "I think maybe now isn't... the right time...\nYou've got enough crap going on already."
    mc "It can wait."
    scene 07_0810 with dissolve
    net "Now you {i}have{/i} to tell me!\nYou can keep me in suspense!"
    net "Has something happened? Is everyone okay??"
    mc "[whi]Damn it."
    scene 07_0811 with dissolve
    mc "Okay, there's something I need you to know..."
    scene 07_0812 with Fade(2, 4, 1)
    net "Wow."
    mc "Wow?\nIs that it?"
    net "Let's be honest, [mc].\nI know I'm Cara's aunt... or was?..."
    net "Anyway, apart from the funeral, I haven't seen her or Alison for a very long time."
    net "She was still a little kid when I left."
    scene 07_0813 with dissolve
    mc "You're {i}still{/i} her aunt, Nettie."
    mc "I'm not trying to take that away from you."
    net "I know."
    scene 07_0814 with dissolve
    net "All I'm trying to say is, we aren't close."
    net "I can't be upset over something I have no right to a say in."
    net "And I'm damn well sure you're a better father than {i}he{/i} ever was."
    scene 07_0815 with dissolve
    net "So, if you're happy, and Cara's happy, then {i}I'm{/i} happy for you both, too."
    mc "Thanks, Nettie. It means a lot to me coming from you."
    scene 07_0816 with dissolve
    net "Lucky I'm still a nun...\nOtherwise, I might've been disappointed you didn't take her off him while he was still alive to feel the pain."
    mc "Damn, that's cold!"
    scene 07_0817 with dissolve
    net "Yeah, I'm sorry. I didn't mean it. Not {i}really{/i}."
    scene 07_0818 with dissolve
    mc "Hold on..."
    mc "What do you mean, {i}still{/i} a nun?"
    mc "Is that why you were questioning me about leaving my job?"
    scene 07_0819 with dissolve
    net "Yes... I'm leaving the church. I've already made up my mind."
    net "Hayley and Chloe will be my last assignment."
    net "My heart's just not in it anymore."
    mc "Wow..."
    scene 07_0820 with dissolve
    $ tCh=None
    if not EzModeActive:
        menu:
            "I'm gonna miss seeing you in your uniform, it was kinda hot!"(friend="Sexual", color="#1acc03"):
                $ tCh=True
            "Whatever you decide to do, I'll be here for you."(friend="Friendship", color="#1acc03"):
                pass
    elif Nettie.Has("EZ"):
        mc "I'm gonna miss seeing you in your uniform, it was kinda hot!"
        $ tCh=True
    else:
        mc "Whatever you decide to do, I'll be here for you."
    if tCh:
        call NettieReplay02
        scene 07_0899 with Fade(0,0,2)
        net "We need to share the bed more often!"
        net "But you know you're going to Hell, right?\nYou just took a nun's virginity!"
        mc "Worth it."
        scene 07_0900 with dissolve
        net "[lol]"
        scene 07_0901 with dissolve
        if Nettie.getCumIns()>0:
            net "I was a little surprised you ejaculated while you were still in me!"
            scene 07_0902 with dissolve
            mc "Uhh... sorry, I should've asked first... got carried away."
            scene 07_0903 with dissolve
            net "No, it's fine! I'm glad you did!"
            net "I want to be a mom, [mc]. Before it's too late."
            scene 07_0902 with dissolve
            mc "You're not on birth control?"
            scene 07_0904 with dissolve
            net "No, why would I be??"
            net "If you're against impregnating me... Isn't this something you should ask {i}before{/i} taking that chance?"
            scene 07_0905 with dissolve
            mc "Yeah, you're right. Sorry."
            net "If we ever have sex again, think about it first because I don't plan on protecting against it."
        else:
            net "I was a tiny bit sad you didn't ejaculate inside me."
            scene 07_0902 with dissolve
            mc "I wasn't sure if you were protected or not."
            scene 07_0903 with dissolve
            net "No, I'm not. Why would I be?"
            net "But I want to be a mom, [mc]. Before it's too late."
            net "If we ever have sex again, maybe think about it."
            scene 07_0905 with dissolve
            mc "Uhh... okay."
        net "We'd better get some sleep.\nWe need to leave early in the morning."
        mc "Yeah."
    else:
        $ Nettie.isSexual(False)
        net "I know, and I appreciate it, [mc]. Thank you."
        net "We'd better get some sleep.\nWe need to leave early in the morning."
        mc "Yeah."
    scene 07_0821 with Fade(2, 2, 1)
    mc "[whi]..Zzzz.."
    scene black with Fade(2, 3, 0)
    if TeddyD:
        call CedarGrove_DumpBody
    jump CedarGrove_RelocateHayley
return

label CedarGrove_DumpBody:
    scene 07_0822 with Fade(0, 2, 1)
    pause 0.5
    scene 07_0823 with dissolve
    net "[whi]Zzz."
    mct "She's sound asleep... Better get to work..."
    scene 07_0660 with fade2
    scene 07_0661 with dis1
    scene 07_0662 with dis1
    scene 07_0663 with dis1
    scene 07_0664 with dis1
    pause 0.5
    scene 07_0665 with dissolve
    mct "Okay..."
    mct "... This rug should work."
    scene 07_0666 with fade1
    pause 0.5
    scene 07_0667 with dissolve
    call Emotion (mc, "Breathing heavily")
    scene 07_0668 with dissolve
    mct "I'm too old for this shit."
    scene 07_0669 with fade
    pause 0.5
    scene 07_0670 with dis1
    pause 0.5
    scene 07_0671 with dis1
    pause 0.5
    scene 07_0672 with dis1
    pause 0.5
    scene 07_0673 with dis1
    pause 0.5
    scene 07_0674 with dissolve
    pause 0.5
    scene black with Fade(2, 3, 0)
return

label CedarGrove_RelocateHayley:
    scene 07_0906 with Fade(0, 2, 4)
    mc "[whi]..Zzzz.."
    scene 07_0907 with dissolve
    net "[mc], wake up!\nWe're leaving soon."
    scene 07_0908 with dissolve
    mc "[whi]... Okay... I heard you the first time..."
    net "That was the fourth time!"
    scene 07_0909 with dissolve
    net "Don't go back to sleep, or we'll leave without you!"
    net "I'll be downstairs."
    scene 07_0910 with dissolve
    call Emotion (mc, "Groan", "{size=*0.8}Okay, okay...", True)
    scene 07_0911 with fade2
    pause
    play sound "knock.mp3"
    pause 1.0
    mc "[whi]Jeez, gimme a chance to get dressed!"
    scene 07_0912 with dissolve
    mc "Come in."
    scene 07_0913 with dissolve
    chlo "Uhh... Hey.\nSister Nettie asked me to check that you were out of bed."
    mc "I'll be down in a second."
    if Nettie.isSexual():
        scene 07_0914 with dissolve
        chlo "Sounded like you two had fun last night."
        scene 07_0915 with dissolve
        mc "What?"
        chlo "{i}Ohhh [mc], yes, yes, ohhhh, ohhhh!"
        scene 07_0916 with dissolve
        mc "Ahh crap... you heard that?"
        chlo "Yeah, I don't know if you noticed, but this place is a shit hole.\nThe walls are paper-thin.[lol]"
        scene 07_0917 with dissolve
        chlo "Sister Elizabeth found it entertaining!\nShe couldn't stop giggling."
        chlo "I thought nuns didn't have sex?"
        scene 07_0918 with dissolve
        mc "Whoa! Okay... We're not talking about this."
        chlo "[lol]"
        scene 07_0919 with dissolve
        chlo "Can't lie though... It sounded hot!"
        scene 07_0920 with dissolve
        mc "Yeah, yeah. Get outta here. Heh."
    else:
        scene 07_0915 with dissolve
        chlo "Do you think this new place will be nice?"
        mc "I have no idea. Can't be any worse than here though, right?"
        scene 07_0917 with dissolve
        chlo "Yeah, true!"
        chlo "I never want to smell this place again!"
        scene 07_0920 with dissolve
        chlo "I'm glad you're coming with us."
        mc "Why?\nDon't wanna be seen in that little green toy car?"
        chlo "[lol] It's cute!"
        mc "Yeah, yeah. Get outta here. Heh."
    scene 07_0921 with dissolve
    chlo "We're leaving in five minutes."
    mc "Okay."
    if Chloe.hasScore(1):
        call CedarGrove_GiveChloeCell
    scene 07_0963 with dissolve
    net "C'mon guys, we need to move!"
    mc "We're comin'..."
    scene 07_0964 with dissolve
    if Nettie.isSexual():
        liz "Morning, [mc]. Sleep well? [lol]"
        net "[whi]{i}Oh my God{/i}... So embarrassing!"
    else:
        liz "Just follow me, it's not too far."
        mc "Okay."
    scene 07_0965 with dissolve
    chlo "Can I ride with [mc]?"
    net "Sure!"
    scene 07_0966 with dissolve
    net "Wow! She's really taken to you!\nTook me months to even get a smile from her!"
    mc "Nah, she just doesn't want to be seen in that {i}thing{/i}.[lol]"
    scene black with Fade(3, 2, 0)
    call CenterText ("A fairly short drive later...")
    scene 07_0967 with Fade(0, 1, 3)
    scene 07_0968 with dis1
    scene 07_0969 with dis1
    scene 07_0970 with dissolve
    chlo "Holy shit! {b}This{/b} is the place??"
    mc "Guess so."
    scene 07_0971 with dissolve
    chlo "It's sooo much bigger than the last house!\nWe only had one bedroom between us!"
    scene 07_0972 with dissolve
    pause
    scene 07_0973 with Fade(1, 2, 1)
    chlo "How great is this place?!"
    mc "Heh. Pretty great."
    scene 07_0974 with dissolve
    chlo "Think they'll let us stay here forever?[lol]"
    mc "Hah. Not sure about that!\nCould be here for a while, though."
    scene 07_0975 with dissolve
    chlo "I'm gonna check out upstairs.\nIt's gonna be awesome to have my own room again!"
    mc "[lol] Okay."
    scene 07_0976 with dissolve
    mct "Wonder how many places like this the church has?!"
    scene 07_0977 with dissolve
    net "Hey."
    scene 07_0978 with dissolve
    net "You okay to hang out here with Hayley and Chloe for a while?"
    mc "Yeah."
    scene 07_0979 with dissolve
    net "Lizzie and I need to go back to the convent to pick up some of our belongings."
    scene 07_0980 with dissolve
    net "We'll get some groceries on our way back."
    mc "Okay."
    if Nettie.isSexual():
        scene 07_0981 with dissolve
        net "Last night..."
        scene 07_0982 with dissolve
        net "... was so great."
        scene 07_0983 with dissolve
        mc "Good.\nI was concerned you may be regretting it today."
        net "Absolutely not."
        scene 07_0984 with dissolve
        net "Well... Maybe one regret."
        scene 07_0985 with dissolve
        net "I wish we'd done it sooner."
        scene 07_0986 with dissolve
        net "But I'm sure we'll make up for lost time."
        scene 07_0987 with dissolve
        liz "Oops! Should I come back later?"
        scene 07_0988 with dissolve
        net "Oh jeez... Sorry. I didn't tell her..."
        mc "[lol] Yeah, I know."
        scene 07_0989 with dissolve
        net "You're never gonna let me live this down, are you?"
        liz "Not a chance![lol]"
    else:
        scene 07_0987 with dissolve
        liz "Ready?"
        scene 07_0988 with dissolve
        net "We shouldn't be long."
        mc "No rush, take your time."
        scene 07_0989 with dissolve
        mc "See ya."
    scene 07_0990 with dissolve
    mct "She seems serious about leaving the church."
    mct "Not that surprising, I guess. Still, it's a big step for her."
    if Nettie.isSexual():
        mct "And she wants a baby??"
        mct "She'd be a great mom, though!"
    scene 07_0991 with fade2
    hay "Mind if I sit?"
    scene 07_0992 with dissolve
    mc "I don't think you need permission to sit down in your own home."
    scene 07_0993 with dissolve
    hay "Well... It's not exactly {i}my{/i} home."
    mc "It is for now!"
    scene 07_0994 with dissolve
    hay "Yeah, guess so."
    hay "It's definitely an upgrade on the last one."
    scene 07_0995 with dissolve
    hay "I pray to God Teddy doesn't find us again."
    scene 07_0996 with dissolve
    mc "I think most guys have trouble accepting rejection from the one they love."
    mc "Don't worry, He'll get over it, eventually."
    scene 07_0997 with dissolve
    hay "Pffft. He {i}never{/i} loved me!\nI was just another one of his possessions, a punching bag to relieve stress."
    hay "When I told him I was leaving, he laughed in my face."
    hay "When I threatened to go to the cops and tell them everything..."
    scene 07_0998 with dissolve
    hay "... he gave me this."
    scene 07_0999 with dissolve
    hay "Then he locked both Chloe and me in the cellar for three days."
    hay "When we made it out, we ran like hell and didn't look back."
    hay "Now, he'd rather have me dead."
    scene 07_1000 with dissolve
    hay "Would've done it himself yesterday had you not been there."
    hay "And he would've made sure there were no witnesses left, too."
    scene 07_1001 with dissolve
    hay "He had hours to do it, but he enjoyed watching me suffer."
    hay "He wanted to savor every damn moment."
    scene 07_1002 with dissolve
    hay "Sorry...\nDon't know why I told you all that."
    hay "I just want you to know how grateful I am for what you did."
    scene 07_1003 with dissolve
    hay "You could've been hurt, or killed even, but you didn't hesitate when you saw the gun!"
    hay "You're a brave man."
    scene 07_1004 with dissolve
    hay "Sister Nettie must mean a great deal to you."
    scene 07_1005 with dissolve
    mc "Yeah, she does."
    hay "She's lucky to have a friend like you."
    if Nettie.isSexual():
        scene 07_1006 with dissolve
        hay "Well... from what we heard last night, maybe it's more than friendship.[lol]"
        mc "Uhh, yeah... Sorry about that. [lol] "
    scene 07_1007 with dissolve
    chlo "I LOVE THIS HOUSE!"
    scene 07_1008 with dissolve
    chlo "I've chosen my room, and it's awesome!!"
    scene 07_1009 with dissolve
    chlo "Come on, [mc]! Come see it!"
    mc "[lol] Okay."
    scene 07_1010 with dissolve
    hay h "You've made a friend for life there!"
    jump CedarGrove_SeeChloeBedroom
return

label CedarGrove_GiveChloeCell:
    mc "Oh hey... Chloe..."
    scene 07_0922 with dissolve
    chlo "Yeah?"
    scene 07_0923 with dissolve
    mc "I think this belongs to you..."
    scene 07_0924 with dissolve
    chlo "OHH SHIT!\nIS THAT MY CELL??"
    mc "Yeah."
    scene 07_0925 with dissolve
    chlo "Oh my God! ...How?!"
    mc "I went back to the house in the night.\nNeeded to, uhh... clean the place a bit."
    scene 07_0926 with dissolve
    chlo "OHH THANK YOU!!"
    scene 07_0927 with dissolve
    chlo "I can't believe I have it back!"
    scene 07_0928 with dissolve
    chlo "You umm... You didn't look at my photos, did you?"
    mc "How could I? It's locked, isn't it?"
    scene 07_0929 with dissolve
    chlo "Oh, yeah."
    $ tCh=None
    if not EzModeActive:
        menu:
            "You should probably delete them!":
                $ tCh=True
            "[wk_y]You could send me one though!":
                pass
    elif not Chloe.Has("EZ"):
        $ tCh=True
    else:
        mc "You could send me one though!"
    if tCh:
        scene 07_0930 with dissolve
        chlo "Yeah, I'm going to."
        chlo "Thank you."
        mc "You're welcome."
        play sound "horn.mp3" volume 0.5
        pause 1.0
        scene 07_0931 with dissolve
        mc "Come on, let's get outta here."
        chlo "Gladly!"
        return
    scene 07_0932 with dissolve
    chlo "What?!"
    mc "I mean, you don't {i}have{/i} to..."
    mc "Just thought... it could be a nice reward for returning your phone!"
    scene 07_0933 with dissolve
    chlo "But... if I don't want to?"
    mc "Heh, it's fine.\nLike I said, you don't have to."
    scene 07_0934 with dissolve
    chlo "So... I can say no?"
    mc "Of course you can!"
    scene 07_0935 with dissolve
    mc "Thought I'd ask, that's all."
    mc "When a beauty like you tells me they have naked pictures... Well, can't blame me for tryin', right?"
    scene 07_0936 with dissolve
    chlo "Yeah... but I'm not... beautiful, though."
    scene 07_0937 with dissolve
    chlo "I'm just... [whi]me."
    scene 07_0938 with dissolve
    mc "You're kidding me, right?"
    mc "Chloe, you're stunning!"
    scene 07_0939 with dissolve
    chlo "You're just saying that so I'll send you the photo."
    mc "Why would I {i}want{/i} your picture if I didn't think you were hot??"
    chlo "..."
    scene 07_0940 with dissolve
    chlo "You really think I'm pretty?"
    mc "Pretty is an understatement!"
    chlo "Why do you even want it?"
    mc "Why do you think? Heh."
    scene 07_0941 with dissolve
    call Emotion (chlo, "Gasp", "OH!")
    scene 07_0942 with dissolve
    chlo "... Looking at a photo of {b}ME{/b}??"
    mc "Yeah! [lol]"
    scene 07_0943 with dissolve
    chlo "Oh my God!"
    scene 07_0944 with dissolve
    chlo "[whi]What's your cell number?"
    scene 07_0945 with Fade(1,1,1)
    chlo "You won't share it with anyone, will you?"
    mc "Of course not!"
    chlo "Okay.\nYou trusted me with your secret, so I'll trust you..."
    play sound "text.mp3"
    pause 1.0
    scene 07_0946 with dissolve
    pause 0.5
    show screen CellPhone("Chloe")
    call SendPhoto ("chlo_01")
    call CloseCell (False)
    scene 07_0947 with dissolve
    mc "[whi]Wow."
    chlo "That work for you?[giggles]"
    if not EzModeActive:
        menu:
            "Yeah, perfect!":
                play sound "horn.mp3" volume 0.5
                pause 1.0
                scene 07_0948 with dissolve
                mc "Come on, let's get outta here."
                return
            "[wk_y]You don't have a better one?":
                pass
    else:
        mc "You don't have a better one?"
    scene 07_0948 with dissolve
    chlo "A better one??"
    mc "Yeah... It's just, you know... can't really see anything in this one!"
    scene 07_0949 with dissolve
    chlo "[whi]It's a nude, not porn!"
    play sound "text.mp3"
    pause 1.0
    scene 07_0950 with dissolve
    pause 0.5
    show screen CellPhone("Chloe")
    call SendPhoto ("chlo_02")
    call CloseCell (False)
    chlo "Better?"
    mc "Now you're just teasing me!"
    scene 07_0951 with dissolve
    chlo "[lol] Okay... I think you'll like this one."
    play sound "text.mp3"
    pause 1.0
    scene 07_0946 with dissolve
    pause 0.5
    show screen CellPhone("Chloe")
    call SendPhoto ("chlo_03")
    call CloseCell (False)
    scene 07_0952 with dissolve
    mc "Damn! You have a cute ass! Heh."
    chlo "Yeah?[giggles]"
    chlo "Would you... umm..."
    chlo "... like another one?"
    if not EzModeActive:
        menu:
            "[wk_y]Hell yeah":
                pass
            "Nah, you've given me enough":
                play sound "horn.mp3" volume 0.5
                pause 1.0
                scene 07_0948 with dissolve
                mc "Come on, let's get outta here."
                return
    else:
        mc "Hell yeah!"
    $ Pix_Chloe=True
    scene 07_0953 with dissolve
    chlo "This one's a bit cringe... but I think I look kinda cute..."
    play sound "text.mp3"
    pause 1.0
    scene 07_0946 with dissolve
    pause 0.5
    show screen CellPhone("Chloe")
    call SendPhoto ("chlo_04")
    call CloseCell (False)
    scene 07_0954 with dissolve
    mc "{i}Kinda cute{/i}?\nThink you mean cute as hell! Heh."
    chlo "[giggles]"
    scene 07_0955 with dissolve
    chlo "Okay ...Last one.\nI wasn't gonna send this one... but you can have it."
    play sound "text.mp3"
    pause 1.0
    scene 07_0946 with dissolve
    pause 0.5
    show screen CellPhone("Chloe")
    call SendPhoto ("chlo_05")
    call CloseCell ()
    scene 07_0956 with dissolve
    mc "Oh hell yeah! That's the one![lol]"
    play sound "horn.mp3" volume 0.5
    pause 1.0
    scene 07_0957 with dissolve
    mc "Crap... Come on, we need to go."
    chlo "[whi]Yeah."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e07/07_0958.webp", 1174, 461, True, "CedarGrove_AF02") with dissolve
        pause
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 07_0958
            hide screen imgMap  
    else:
        scene 07_0958 with dissolve
        pause 1.0
        if not EzModeActive:
            menu:
                "[wk_y]Grab her butt":
                    call CedarGrove_AF02
                "Don't":
                    pass
        else:
            call CedarGrove_AF02
return

label CedarGrove_SeeChloeBedroom:
    scene 07_1011 with Fade(1, 2, 2)
    pause 1.0
    scene 07_1012 with dissolve
    chlo "This is it!"
    scene 07_1013 with dissolve
    chlo "I think it's bigger than the entire other house![lol]"
    scene 07_1014 with dissolve
    chlo "It's great, right?"
    mc "Yeah!"
    scene 07_1015 with dissolve
    chlo "But who owns all these things?\nIt looks like someone already lives here."
    mc "The church, I suppose.\nProbably stuff that's been donated to them."
    mc "We can pack them up if you don't want them in here."
    scene 07_1016 with dissolve
    chlo "No, I like them.\nI don't have anything of my own to put in here anyway.\nAll my things... we had to leave them behind when we left."
    mc "They're only {i}things{/i}.\nYou can replace them."
    chlo "Yeah."
    scene 07_1017 with dissolve
    if Chloe.hasScore(1):
        chlo "I wish we could tell my mom the truth about Teddy.\nShe's so frightened he'll find us."
        mc "Yeah, I know."
        scene 07_1018 with dissolve
        mc "I wish we could, too, but we can't."
        mc "I shouldn't have told you, really."
        scene 07_1019 with dissolve
        chlo "Why?\nI won't tell anyone."
        mc "No, I know."
    else:
        chlo "You don't think he'll find us, do you?"
        scene 07_1018 with dissolve
        mc "If you all keep your heads down, then no."
        scene 07_1019 with dissolve
        chlo "I hope you're right."
    scene 07_1020 with dissolve
    chlo "Want some help choosing {b}your{/b} room?\nThe one next to mine is pretty nice!"
    if Nettie.isSexual():
        chlo "... Or will you be sharing with Sister Nettie again?"
    mc "I don't need a room. I'm not staying."
    scene 07_1021 with dissolve
    chlo "Ohh. I was hoping you'd stay with us for a while."
    mc "Sorry, I can't."
    scene 07_1022 with dissolve
    mc "But hey, don't worry. I'll be back to check in on you guys."
    if Chloe.hasScore(1):
        mc "And you know Teddy's no longer a threat."
        chlo "[whi]Yeah..."
    scene 07_1023 with dissolve
    chlo "... Okay."
    $ a=True
    if not Chloe.hasScore(1):
        $ a=False
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e07/07_1024.webp", 1021, 690, a, "CedarGrove_AF03") with dissolve
        chlo "I think I'm actually gonna miss you!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 07_1024
            hide screen imgMap 
            $ Pix_Chloe=False
            scene 07_1033 with dissolve
            mc "I'll let you settle in."
            chlo "'kay."
            scene 07_1034 with dissolve
            mc "It's a GREAT room!"
            chlo "I know![lol]"
    else:
        scene 07_1024 with dissolve
        chlo "I think I'm actually gonna miss you!"
        if a:
            $ aa=wk_y
        else:
            $ aa =""
        $ tCh=None
        if not EzModeActive:
            menu:
                "[aa]Slide your hand down":
                    $ tCh=True
                "Don't":
                    pass
        elif Chloe.Has("EZ"):
            $ tCh=True
        if tCh:
            call CedarGrove_AF03
        else:
            $ Pix_Chloe=False
            scene 07_1033 with dissolve
            mc "I'll let you settle in."
            chlo "'kay."
            scene 07_1034 with dissolve
            mc "It's a GREAT room!"
            chlo "I know![lol]"
    scene black with Fade(2, 2, 0)
    call CenterText ("A little while later.")
    scene 07_1044 with Fade(0, 1, 2)
    pause
    scene 07_1045 with dissolve
    net "We're back."
    scene 07_1046 with dissolve
    mc "Great.\nI'd better get going."
    net "So soon?"
    scene 07_1047 with dissolve
    mc "Yeah, sorry.\nGot stuff to do."
    net "Okay."
    scene 07_1048 with dissolve
    net "Thank you, [mc]. For everything."
    mc "Anytime."
    scene 07_1049 with dissolve
    if Nettie.isSexual():
        liz "Oops! Have I done it again?[lol]"
        scene 07_1050 with dissolve
        net "[whi]Oh, jeez... Take me with you!"
    else:
        liz "Aww! Look at you two!"
        scene 07_1050 with dissolve
        liz "So lovely to see!"
    scene 07_1051 with dissolve
    net "[mc]'s leaving now.\nWe were just saying goodbye."
    scene 07_1052 with dissolve
    liz "Bye, [mc]!\nThanks for helping... We would've been screwed without you![lol]"
    if Pix_Chloe:
        scene 07_1054 with dissolve
    else:
        scene 07_1053 with dissolve
    hay "I'll never be able to repay you for saving us. Thank you."
    mc "You're welcome."
    scene 07_1055 with dissolve
    chlo "Bye, [mc]."
    if Pix_Chloe:
        play sound "text.mp3"
        pause 0.5
        scene 07_1056 with dissolve
        chlo "[whi]That's from me.\nDon't open it till you're in the car."
    scene 07_1057 with Fade(2, 2, 1)
    scene 07_1058 with dis1
    scene 07_1059 with dis1
    if Pix_Chloe:
        scene 07_1060 with dissolve
        pause
        show screen CellPhone("Chloe")
        msg_nvl "So, there was one more photo I wanted you to have, but it was too cringe to send while you were standing next to me!{nw}"
        msg_nvl "Let me know when you're in the car and I'll send it."
        mc_nvl "I'm here."
        msg_nvl "OK.."
        msg_nvl "If you're really going to do what you said with my pictures, you should use this one...{image=/thumbs/cell/emoji/smile shy.png}"
        call SendPhoto ("chlo_06")
        mc_nvl "Damn! Think you're right!"
        msg_nvl "See you soon! {image=/thumbs/cell/emoji/halo.png}"
        msg_nvl "Bye x"
        call CloseCell ()
        scene 07_1061 with dissolve
        pause 0.5
        scene 07_1059 with dissolve
    scene 07_1062 with dis1
    play sound "car_rev.mp3"
    scene 07_1063 with dis1
    scene 07_1064 with dis1
    scene 07_1065 with dis1
    call UpdateSpringhavenData (4)
    jump CedarGrove_Leave
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
