screen ChloeCell(i, p=1):
    if p==2:
        $ pt="e21/21_0"
    else:
        $ pt="e15/15_"
    frame:
        xpos 45
        yalign 0.5
        background None
        add "[pt][i].webp"
return

label ChloeReplay01:
    call Unlocker ("ChloeReplay01")
    $ Chloe.isSexual(True)
    if not persistent.ChloeRP01Dat:
        call ChloeReplay01_Alt
    else:
        if _in_replay:
            scene 15_1229 with Fade(0,0,2)
            mc "You know I'm gonna, right?"
            scene 15_1232 with dissolve
            chlo "Are you asking for permission?"
            mc "Well... I just showed you how to kick my ass, so... Yeah."
            scene 15_1233 with dissolve
            chlo "[lol]"
            scene 15_1234 with dissolve
            chlo "Go ahead."
            scene 15_1235 with dissolve
            mc "[whi]Thanks."
            scene 15_1236 with dis1
            scene 15_1237 with dis1
            mc "[whi]Damn."
            scene 15_1238 with dissolve
            pause
            scene 15_1239 with dissolve
            chlo "[whi]God, I love your visits."
            mc "[whi]Me too."
            scene 15_1240 with dissolve
            $ aPs(0, True)
            scene 15_1241 with dis1
            mc "[whi][kiss]"
            scene 15_1242 with dis1
            $ aPs()
            scene 15_1243 with dis1
            mc "[whi][kiss]"
            scene 15_1244 with dis1
            $ aPs()
            scene 15_1245 with dis1
            mc "[whi][kiss]"
            scene 15_1246 with dis1
            $ aPs()
            scene 15_1247 with dissolve
            mc "[whi][kiss]"
            scene 15_1248 with dis1
            $ aPs(0, False, True)
            scene 15_1249 with dis1
            mc "[whi][kiss]"
            scene 15_1250 with dis1
            mc "[whi]Sorry.\nI know I shouldn't do that."
            chlo "[whi]What if I like you doing it?"
            chlo "[whi]What if I want you to carry on?"
            scene 15_1251 with dis1
            mc "[whi][kiss]"
            scene 15_1252 with dis1
            $ aPs()
            scene 15_1253 with dis1
            chlo "[whi]Mmhhh."
            scene 15_1254 with dissolve
            chlo "[whi]Mhhh."
            scene 15_1255 with dissolve
            chlo "[whi]Mmhhh."
            scene 15_1256 with dissolve
            chlo "[whi]Mhhh."
        scene 15_1257 with dissolve
        chlo "Do you still look at my photos?"
        mc "Yeah, all the time."
        scene 15_1258 with dissolve
        mc "Why? You offering to take more for me?"
        chlo "I already have."
        mc "Yeah? Why haven't you sent them?"
        scene 15_1259 with dissolve
        chlo "Because... Uhh..."
        chlo "I want to see you... {i}using{/i} them."
        mc "See me?"
        scene 15_1260 with dissolve
        mc "Wait... You want to {b}watch{/b}? While I--"
        chlo "I know it's weird."
        chlo "But it's weird that you like using {b}my{/b} pictures."
        scene 15_1261 with dissolve
        chlo "It's weird that I like you using them."
        chlo "And it's weird that I think about it all the time!"
        chlo "So... can I?"
        mc "Are you actually serious?"
        scene 15_1262 with dissolve
        chlo "Yes!\nNo one comes in here... and if they do, they always knock first."
        mc "In here? Now?!"
        chlo "Yeah!"
        scene 15_1263 with dissolve
        chlo "Ever since you told me... I keep trying to imagine it...\nBut it's hard to imagine something you've never seen!"
        chlo "So I want to {b}see{/b} you doing it!\nThen, next time, I won't have to imagine it; I can remember it instead!"
        chlo "Come on, [mc]! It'll be fun!"
        chlo "I took some new photos just for this!"
        chlo "I'll show you them while you... do it."
        scene 15_1264 with dissolve
        mc "Damn... You're gonna get me into {b}so{/b} much trouble!"
        scene 15_1265 with dissolve
        chlo "Are you saying yes?!"
        mc "Yeah."
        chlo "YES!"
    scene 15_1266 with fade2
    mc "You're {b}sure{/b} about this?"
    chlo "Yep."
    mc "[whi]Okay..."
    scene 15_1267 with dis1
    scene 15_1268 with dis1
    scene 15_1269 with dis1
    scene 15_1270 with dis1
    chlo "Holy shit!"
    scene 15_1271 with dissolve
    chlo "It's bigger than I was imagining it to be!"
    call laugh (mc)
    scene 15_1272 with dissolve
    chlo "'kay... I'm ready... You?"
    mc "Yeah."
    scene 15_1273 with dissolve
    chlo "This is so exciting!"
    scene 15_1274 with dissolve
    chlo "Tell me if I'm scrolling too fast."
    scene 15_1275 with dissolve
    image ChloeR01_01 = Movie(play="images/e15/15_1276.webm")
    show ChloeR01_01
    $ x=1277
    while x<1284:
        show screen ChloeCell(x) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 15_1294 with dissolve
    mc "You're gonna send me some of these, right?"
    chlo "[whi]Yeah."
    scene 15_1295 with dissolve
    image ChloeR01_02 = Movie(play="images/e15/15_1296.webm")
    show ChloeR01_02
    while x<1289:
        show screen ChloeCell(x) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 15_1297 with dissolve
    mc "[whi]Yes... Now we're talkin'."
    scene 15_1298 with dissolve
    chlo "You liking them so far?"
    scene 15_1299 with dissolve
    mc "Love them."
    scene 15_1300 with dis1
    pause 0.5
    scene 15_1301 with dis1
    image ChloeR01_03 = Movie(play="images/e15/15_1302.webm")
    show ChloeR01_03
    pause
    scene 15_1303 with dissolve
    chlo "[whi][ss]Mmhh."
    scene 15_1304 with dissolve
    image ChloeR01_04 = Movie(play="images/e15/15_1305.webm")
    show ChloeR01_04
    pause
    scene 15_1306 with dissolve
    call Moan (chlo)
    mc "You've, uh, stopped scrolling."
    scene 15_1307 with dissolve
    chlo "[whi]Oh... sorry."
    mc "You like that?"
    chlo "[whi]... Yeah."
    call Loop_Dissolve (4, True, False, "e15/15_1308.webp", "e15/15_1304.webp")
    scene 15_1309 with dis1
    pause 0.5
    scene 15_1310 with dis1
    pause 0.5
    scene 15_1311 with dis1
    pause 0.5
    scene 15_1312 with dis1
    image ChloeR01_05 = Movie(play="images/e15/15_1313.webm")
    show ChloeR01_05
    pause
    scene 15_1314 with dissolve
    chlo "[whi][ss]Fuck..."
    chlo "[ss]..Ohhh..."
    scene 15_1315 with dis1
    image ChloeR01_06 = Movie(play="images/e15/15_1316.webm")
    show ChloeR01_06
    while x<1294:
        show screen ChloeCell(x) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 15_1317 with dissolve
    mc "[whi]Yeah... You definitely need to send me those last two!"
    chlo "[ss]..Mhhhh.."
    scene 15_1318 with dis1
    chlo "[ss]...God.."
    mc "[whi]Want me to stop?"
    scene 15_1319 with dis1
    call Moan (chlo)
    chlo "[whi]No."
    image ChloeR01_07 = Movie(play="images/e15/15_1321.webm", loop=False, keep_last_frame=True)
    image ChloeR01_08 = Movie(play="images/e15/15_1322.webm")
    scene 15_1320 with dis1
    show ChloeR01_07
    pause 11.1
    show ChloeR01_08
    pause
    scene 15_1323 with dissolve
    call Moan (chlo)
    scene 15_1324 with dis1
    pause 0.5
    scene 15_1325 with dis1
    chlo "[ss]..Ohhh..."
    scene 15_1326 with dissolve
    call Moan (chlo, 7)
    scene 15_1327 with dissolve
    image ChloeR01_09 = Movie(play="images/e15/15_1328.webm")
    show ChloeR01_09
    chlo "[ss]...Mmmmmhhh...."
    scene 15_1329 with dissolve
    call Moan (chlo, 7)
    scene 15_1330 with dissolve
    image ChloeR01_10 = Movie(play="images/e15/15_1331.webm")
    show ChloeR01_10
    chlo "[ss]...Fuck...."
    scene 15_1332 with dis1
    image ChloeR01_11 = Movie(play="images/e15/15_1333.webm")
    show ChloeR01_11
    call Moan (chlo, 8)
    scene 15_1334 with dissolve
    chlo "[ss]...Ohhhh............Mhhhh....."
    chlo "[ss].....God.........Don't stop....."
    scene 15_1335 with dissolve
    image ChloeR01_12 = Movie(play="images/e15/15_1336.webm")
    show ChloeR01_12
    call Moan (chlo, 8)
    call Loop_Dissolve (5, False, False, "e15/15_1337.webp", "e15/15_1338.webp")
    call CharCum ("e15/15_1338.webp", "e15/15_1339.webp", chlo, "....OHHHHHHHH...")
    call CharCum ("e15/15_1339.webp", "e15/15_1340.webp", chlo, "..Ohhhhhh..")
    scene 15_1342 with dissolve
    chlo "[ss]Mmmhhh..."
    call Loop_Dissolve (6, False, False, "e15/15_1341.webp", "e15/15_1342.webp")
    call CharCum ("e15/15_1341.webp", "e15/15_1343.webp", mc, "...Nnnnngggghhhh...")
    call CharCum ("e15/15_1343.webp", "e15/15_1344.webp", mc, "..nnnhhhh..")
    scene 15_1345 with dissolve
    chlo "[whi]Damn!"
    scene 15_1346 with dissolve
    chlo "That's {b}not{/b} how I was expecting this to go, like... {i}at all{/i}!"
    scene 15_1347 with dissolve
    chlo "It was so much... better."
    chlo "I didn't--"
    scene 15_1348 with dissolve
    mc "You err... have some on your face..."
    chlo "I do?"
    scene 15_1349 with dis1
    scene 15_1350 with dis1
    mc "Got it."
    mc "Wanna try a little?"
    scene 15_1351 with dis1
    scene 15_1352 with dis1
    scene 15_1353 with dis1
    scene 15_1354 with dis1
    mc "That's my girl."
    scene 15_1355 with dis1
    chlo "[whi]Wow. That's really... salty."
    scene 15_1356 with dis1
    mc "Don't worry, Sweetie."
    scene 15_1357 with dis1
    scene 15_1358 with dis1
    mc "You'll get used to it."
    scene 15_1359 with dis1
    pause
    scene 15_1360 with dissolve
    mc "I'd better get cleaned up!"
    scene black with ReplayFade
return

label ChloeReplay01_Alt:
    if _in_replay:
        scene 21_0091 with dissolve
    chlo "Can I ask you something?"
    mc "Sure."
    chlo "Do you still look at my photos?"
    mc "Yeah, all the time."
    scene 21_0092 with dissolve
    mc "Why? You offering to take more for me?"
    chlo "I already have."
    mc "Yeah? Why haven't you sent them?"
    scene 21_0093 with dissolve
    chlo "Because... Uhh..."
    chlo "I want to see you... {i}using{/i} them."
    mc "See me?"
    mc "Wait... You want to {b}watch{/b}? While I--"
    scene 21_0094 with dissolve
    chlo "I know it's weird."
    chlo "But it's weird that you like using {b}my{/b} pictures."
    chlo "It's weird that I like you using them."
    chlo "And it's weird that I think about it all the time!"
    scene 21_0095 with dissolve
    chlo "So... can I?"
    mc "Are you actually serious?"
    scene 21_0096 with dissolve
    chlo "Yes!\nNo one comes in here... and if they do, they always knock first."
    mc "In here? Now?!"
    chlo "Yeah!"
    scene 21_0097 with dissolve
    chlo "Ever since you told me... I keep trying to imagine it...\nBut it's hard to imagine something you've never seen!"
    chlo "So I want to {b}see{/b} you doing it!\nThen, next time, I won't have to imagine it; I can remember it instead!"
    scene 21_0098 with dissolve
    chlo "Come on, [mc]! It'll be fun!"
    chlo "I took some new photos just for this!"
    chlo "I'll show you them while you... do it."
    mc "Damn... You're gonna get me into {b}so{/b} much trouble!"
    scene 21_0099 with dissolve
    chlo "Are you saying yes?!"
    mc "Yeah."
    chlo "YES!"
return

label ChloeReplay02:
    call Unlocker ("ChloeReplay02")
    if persistent.ChloeRP02Dat:
        if _in_replay:
            scene 21_0092 with dissolve
        chlo "... Can we, uhh... do it again?"
        mc "The exercise?"
        scene 21_0093 with dissolve
        chlo "No!"
        chlo "You know... {i}the thing{/i} we did last time."
        scene 21_0094 with dissolve
        chlo "I took some more photos for it."
        mc "You did?"
        scene 21_0096 with dissolve
        chlo "Yeah!"
        chlo "I think you're gonna like them!\nI took them just for you."
        mc "Hell! What we waitin' for?!"
        scene 21_0099 with dissolve
        chlo "[lol]"
    else:
        pass
    scene 21_0100 with fade2
    chlo "[whi]Okay.... and... ready!"
    scene 21_0101 with dissolve
    chlo "Here you go.\nYou'll have to hold the phone."
    mc "Why?"
    scene 21_0102 with dissolve
    chlo "You said {i}I{/i} could do it this time."
    mc "... I figured you'd have changed your mind by now."
    scene 21_0103 with dissolve
    chlo "No way!\nI haven't stopped thinking about it since you said I could!"
    scene 21_0104 with dis1
    pause 0.5
    scene 21_0105 with dissolve
    chlo "... Did {i}you{/i} change your mind?"
    mc "No."
    scene 21_0106 with dis1
    image ChloeR02_01 = Movie(play="images/e21/21_0107.webm", loop=False, keep_last_frame=True)
    image ChloeR02_02 = Movie(play="images/e21/21_0108.webm")
    show ChloeR02_01
    pause 2.0
    show ChloeR02_02
    pause
    scene 21_0109 with dissolve
    chlo "I thought it'd feel weird, but I like it!"
    scene 21_0110 with dissolve
    chlo "I'm not going too fast?"
    mc "Nah, perfect."
    chlo "..."
    chlo "You're not looking at my photos!"
    scene 21_0111 with dissolve
    mc "Oh, yeah... Sorry."
    image ChloeR02_03 = Movie(play="images/e21/21_0112.webm")
    show ChloeR02_03
    $ x=113
    while x<121:
        show screen ChloeCell(x, 2) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 21_0121 with dissolve
    mc "Damn, you're beautiful.\nAnd sexy as hell!"
    chlo "[whi]You really think so?"
    scene 21_0122 with dissolve
    image ChloeR02_04 = Movie(play="images/e21/21_0123.webm")
    show ChloeR02_04
    $ x=124
    while x<128:
        show screen ChloeCell(x, 2) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 21_0134 with dissolve
    chlo "I was thinking about you when I took those.\nI imagined they were {i}your{/i} fingers."
    scene 21_0135 with dissolve
    mc "Well, Sweetie..."
    scene 21_0136 with dis1
    scene 21_0137 with dis1
    mc "There'll be no imagining today."
    scene 21_0138 with dissolve
    pause
    scene 21_0139 with dissolve
    chlo "[ss]Mmhhh."
    scene 21_0140 with dissolve
    image ChloeR02_05 = Movie(play="images/e21/21_0141.webm")
    show ChloeR02_05
    $ x=128
    while x<134:
        show screen ChloeCell(x, 2) with dissolve
        pause 5.0
        $ x+=1
    hide screen ChloeCell
    scene 21_0142 with dissolve
    mc "[whi]Damn!"
    chlo "I'd never done that before."
    scene 21_0143 with dissolve
    chlo "I wanted to do it for you, though."
    scene 21_0144 with dissolve
    pause 0.5
    scene 21_0145 with dis1
    pause 0.5
    scene 21_0146 with dissolve
    chlo "[ss]Mmhhh."
    scene 21_0147 with dissolve
    image ChloeR02_06 = Movie(play="images/e21/21_0148.webm")
    show ChloeR02_06
    pause
    scene 21_0149 with dissolve
    image ChloeR02_07 = Movie(play="images/e21/21_0150.webm")
    show ChloeR02_07
    call Moan (chlo)
    scene 21_0151 with dis1
    scene 21_0152 with dis1
    scene 21_0153 with dis1
    scene 21_0154 with dis1
    image ChloeR02_08 = Movie(play="images/e21/21_0155.webm")
    show ChloeR02_08
    chlo "[ss]..Mmmhh.."
    scene 21_0156 with dissolve
    chlo "[ss]Mmh."
    scene 21_0157 with dissolve
    chlo "It's the same for guys, right?\nYou know when you're about to... uhh..."
    mc "Cum? Yeah."
    scene 21_0158 with dissolve
    chlo "Can you tell me?"
    chlo "My eyes were closed last time, so I didn't really see it."
    mc "Okay."
    scene 21_0156 with dissolve
    chlo "[ss]..Mmmhh.."
    scene 21_0159 with dissolve
    image ChloeR02_09 = Movie(play="images/e21/21_0160.webm")
    show ChloeR02_09
    chlo "[ss]Mmhhhh."
    scene 21_0161 with dissolve
    image ChloeR02_10 = Movie(play="images/e21/21_0162.webm")
    show ChloeR02_10
    pause
    scene 21_0163 with dissolve
    image ChloeR02_11 = Movie(play="images/e21/21_0164.webm")
    show ChloeR02_11
    pause
    scene 21_0165 with dissolve
    image ChloeR02_12 = Movie(play="images/e21/21_0166.webm")
    show ChloeR02_12
    chlo "[ss]..Ohhh.."
    scene 21_0167 with dissolve
    chlo "[ss]..God, [persistent.McName].... I love when it IS your fingers..."
    scene 21_0168 with dis1
    call Moan (chlo)
    scene 21_0169 with dis1
    scene 21_0170 with dis1
    image ChloeR02_13 = Movie(play="images/e21/21_0171.webm")
    show ChloeR02_13
    pause
    scene 21_0172 with dissolve
    image ChloeR02_14 = Movie(play="images/e21/21_0173.webm")
    show ChloeR02_14
    call Moan (chlo)
    scene 21_0174 with dissolve
    chlo "[ss]..Ohhh, [persistent.McName]... I'm gonna cum..."
    call Moan (chlo)
    chlo "[ss]....Ohhhh...."
    scene 21_0175 with dissolve
    image ChloeR02_15 = Movie(play="images/e21/21_0176.webm")
    show ChloeR02_15
    call Moan (chlo)
    call CharCum ("e21/21_0175.webp", "e21/21_0177.webp", chlo, "....OHHHHHHHH...")
    call CharCum ("e21/21_0177.webp", "e21/21_0178.webp", chlo, "..Ohhhhhh..")
    scene 21_0179 with dis1
    image ChloeR02_16 = Movie(play="images/e21/21_0180.webm")
    show ChloeR02_16
    chlo "[ss]Mmmhhh..."
    pause
    mc "[whi]Chloe... Mhhh... I'm gettin' there...."
    scene 21_0181 with dis1
    image ChloeR02_17 = Movie(play="images/e21/21_0182.webm", loop=False, keep_last_frame=True)
    image ChloeR02_18 = Movie(play="images/e21/21_0183.webm")
    show ChloeR02_17
    pause 18.7
    call CharCum ("e21/21_0184.webp", "e21/21_0185.webp", mc, "...Nnnnngggghhhh...")
    call CharCum ("e21/21_0185.webp", "e21/21_0186.webp", mc, "..nnnhhhh..")
    scene 21_0187 with dis1
    pause 0.5
    scene 21_0188 with dissolve
    call Gulp (chlo)
    scene 21_0189 with dis1
    image ChloeR02_19 = Movie(play="images/e21/21_0190.webm", loop=False, keep_last_frame=True)
    show ChloeR02_19
    pause
    scene 21_0191 with dissolve
    mc "Damn... I didn't expect {i}that{/i}!"
    chlo "Didn't want you making another mess."
    scene 21_0192 with dissolve
    chlo "And I need to get used to the taste, {i}right{/i}?"
    scene 21_0193 with dissolve
    chlo "...'Cause, honestly, it's kinda gross!"
    scene 21_0194 with dissolve
    chlo "So guess I'll need to keep doing it!"
    scene 21_0195 with dissolve
    chlo "[whi]Mmhh."
    scene 21_0196 with dissolve
    pause
    net "[whi]Food's ready, everyone!"
    scene 21_0197 with dissolve
    chlo "[whi]Awww."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
