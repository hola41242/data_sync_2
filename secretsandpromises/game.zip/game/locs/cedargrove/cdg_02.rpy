label CedarGrove_Leave:
    $ cedargrove_open=False
    $ cedargrove_ch+=1
    call CheckShOpen
    jump ShowMap
return

label CedarGrove_JoinSue:
    $ curLOC=cedargrove_id
    call CenterText ("A long drive later.", True)
    play music "barbgm.mp3" loop fadein 2.0 volume .75
    scene 11_0466 with Fade(0,0,2)
    mct "This seems to be the place..."
    scene 11_0467 with dissolve
    mct "Was expecting somewhere with a bit more class!"
    scene 11_0468 with dissolve
    mct "At least she's here already."
    if JamesD:
        scene 11_0469 with dissolve
        sue "You took your time."
        mc "Got here as fast as I could."
    else:
        scene 11_0470 with dissolve
        sue "You took your time."
        mc "Got here as fast as I could."
        scene 11_0471 with dissolve
        sue "James, you may go and continue with your search."
        scene 11_0472 with dissolve
        jam "Happy to if it means getting away from this clown."
        mc "Aww, and I was gonna buy you a beer!"
    scene 11_0473 with dissolve
    mc "Can I get you another?"
    sue "Thank you, but no."
    scene 11_0474 with dissolve
    $ Amelia_name="Barmaid"
    rud "C'mon, Sweetheart!\nYou know you want to!"
    ame "For the thousandth time, not interested!"
    scene 11_0475 with dissolve
    $ Craig_name=""
    cra "Get over here and suck his dick, Bitch!"
    ame "Excuse me!?"
    rud "[lol]"
    scene 11_0476 with dissolve
    rud "Da' fuck do {i}you{/i} want?"
    mc "Beer, since you're offering."
    scene 11_0477 with dissolve
    sue "Rudy, he's with me."
    $ Rudy_name = "Rudy"
    rud "Oh, okay. Sorry Sue."
    scene 11_0478 with dissolve
    rud "My bad, dude."
    rud "I didn't realize you were one of us."
    mc "I'm not."
    scene 11_0479 with dissolve
    ame "I'll bring one over."
    mc "Thanks."
    scene 11_0480 with dissolve
    rud "C'mon Craig, your round."
    $ Craig_name="Craig"
    cra "But I got the last round!"
    rud "Just get the fuckin' drinks!"
    scene 11_0481 with dissolve
    sue "You purposely annoy people. Why?"
    mc "I'm not here to make friends."
    mc "Actually, why {i}am{/i} I here?"
    scene 11_0482 with dissolve
    sue "The boss wishes to meet you."
    mc "Why?"
    sue "Because you're his employee."
    scene 11_0483 with dissolve
    mc "No, I work for {b}you{/b}."
    sue "Yes, and I work for him.\nTherefore, so do you."
    scene 11_0484 with dissolve
    ame "Here you go."
    mc "Thanks."
    scene 11_0485 with dissolve
    rud "Come over here, Sweetheart!"
    scene 11_0486 with dissolve
    ame "AHHH!"
    scene 11_0487 with dissolve
    rud "Sit on my dick!"
    ame "Let go!"
    sue "[mc], leave it!"
    scene 11_0488 with dissolve
    mc "Take your grubby little fuckin' hands off her!"
    scene 11_0489 with dissolve
    rud "Chill, dude! I was only playin'!"
    ame "Whoa! {b}Guys{/b}! You know the rules!"
    scene 11_0490 with dissolve
    $ Anton_name=""
    ame "No fighting in the bar! Everyone, just relax!"
    ant "I don't give a rat's ass about your brother, Hank!\nI gotta get home!"
    scene 11_0491 with dissolve
    $ Anton_name="Anton"
    hank "Anton, wait!\nLet's talk! I need your guys here!"
    ant "Fuck that!\nWe're leavin' right now!"
    scene 11_0492 with dissolve
    sue "[whi][mc]! Sit down."
    scene 11_0493 with dissolve
    ant "I wonder, was this {b}your{/b} doing?"
    hank "Anton, she's been here with us! C'mon!"
    scene 11_0494 with dissolve
    ant "You wouldn't be stupid enough to try it again, would you?"
    scene 11_0495 with dissolve
    pause 0.5
    scene 11_0496 with dissolve
    hank "Stay down, boy."
    ant "Listen to your fuckin' boss."
    scene 11_0497 with dissolve
    sue "If you truly thought I was involved in {i}whatever{/i} your problem, my head would be detached already."
    scene 11_0498 with dissolve
    ant "I pray for our daughter's sake that you're not."
    scene 11_0499 with dissolve
    ant "Craig, did you call our guys?"
    scene 11_0500 with dissolve
    cra "Yes, Boss!\nThey're all already on the way home."
    ant "Good."
    scene 11_0501 with dissolve
    ant "So are we. Let's go."
    scene 11_0502 with dissolve
    hank "What the fuck are you guys still doin' here??"
    rud "We're just havin' a break, Boss."
    if TeddyD:
        hank "GO FIND MY GODDAMN BROTHER!"
    else:
        hank "GET OUT THERE AND FIND THOSE GODDAMN ASSHOLES!"
    scene 11_0503 with dissolve
    hank "This your guy?"
    sue "Yes. His name is [mc]."
    scene 11_0504 with dissolve
    hank "Give us a minute, will you?"
    sue "Certainly."
    scene 11_0505 with dissolve
    hank "You not gonna thank me?"
    mc "For what?"
    scene 11_0508 with dissolve
    hank "I just saved your life, boy."
    mc "{i}My{/i} life? Think you mean {i}his{/i} life."
    scene 11_0507 with dissolve
    hank "[lol] {w=0.5}{nw}"
    scene 11_0508 with dissolve
    hank "Sue warned me you were an arrogant son of a bitch!"
    scene 11_0509 with dissolve
    hank "She speaks highly of you."
    hank "That already puts you in a strange spot, but makes me think you're worth a look."
    scene 11_0506 with dissolve
    hank "That woman don't like anyone."
    hank "That's why you're here.\nI wanted to see the man who managed to earn her approval."
    scene 11_0510 with dissolve
    hank "Because Sue doesn't recommend anyone. Ever."
    hank "So go on. Tell me - why you?"
    scene 11_0511 with dissolve
    mc "Why don't you ask her?"
    scene 11_0512 with dissolve
    hank "I did."
    hank "She started ramblin' in that strange way of hers. You know how she gets."
    scene 11_0511 with dissolve
    mc "She liked my military background. Thought I'd be useful."
    scene 11_0513 with dissolve
    hank "Your record {b}is{/b} impressive... But it's not the whole story."
    hank "I don't trust coincidences, [mc] - and I don't trust you. Not yet."
    hank "There's something about you that doesn't sit right. I just haven't worked out what."
    scene 11_0514 with dissolve
    hank "I've been doin' this a long time, and I can usually tell what a man wants."
    hank "Money. Power. A way out.\nI don't see it on you, and I don't like it."
    mc "I have my reasons for being here, just like everyone else."
    hank "And what are they?"
    mc "..."
    scene 11_0515 with dissolve
    hank "Don't worry, you'll get your chance to prove yourself."
    hank "When you do, make it count."
    scene 11_0516 with dissolve
    hank "Until then, I'll be keeping an eye on you.\nTrust's {b}earned{/b} around here. Respect comes later."
    if not TeddyD and Nettie.isActive():
        call CedarGrove_MeetTeddy
    else:
        if not helpedMel:
            if Nettie.isActive():
                scene 11_0548 with dissolve
                ah1 "Boss! We found one!"
                scene 11_0551 with dissolve
                hank "About damn time!\nWhere is he?"
                ah1 "They're takin' him to the warehouse right now."
            else:
                scene 11_0548 with dissolve
                ah1 "Boss! We found him!"
                scene 11_0551 with dissolve
                hank "About damn time!\nWhere is he? Is he okay??"
                ah1 "He's fine. Drunk, but fine.\nThey're takin' him home."
            scene 11_0552 with dissolve
        else:
            if Nettie.isActive():
                scene 11_0549 with dissolve
                mat "Boss! We found one!"
                scene 11_0550 with dissolve
                hank "About damn time!\nWhere is he?"
                mat "They're takin' him to the warehouse right now."
            else:
                scene 11_0549 with dissolve
                mat "Boss! We found him!"
                scene 11_0550 with dissolve
                hank "About damn time!\nWhere is he? Is he okay??"
                mat "He's fine. Drunk, but fine.\nThey're takin' him home."
            scene 11_0553 with dissolve
        hank "Good. Let's go."
        scene 11_0554 with dis1
        scene 11_0555 with dis1
        sue "So?\nHe was eager to meet you. Why?"
        scene 11_0556 with dissolve
        mc "Think you caught him off guard by recommending me."
        mc "Don't think he trusts you very much, and he sure as hell doesn't trust me."
        sue "Good."
        mc "Good?"
        scene 11_0557 with dissolve
        sue "I surmise that whatever has Anton upset is {i}your{/i} doing."
        mc "Yeah, I imagine so."
        scene 11_0558 with dissolve
        sue "Excellent."
        sue "We can discuss it further back in Springhaven."
        scene 11_0559 with dissolve
        sue "Hank left rather abruptly. Why?"
        mc "Not sure. They found someone they've been looking for."
        scene 11_0560 with dissolve
        if Nettie.isActive():
            sue "He believes his brother has been murdered by a group of men encroaching upon his territory."
            sue "Apparently, Teddy was visiting his girlfriend when the group attacked him."
            sue "Neither of them has been seen since, but there was blood found in her home."
            scene 11_0561 with dissolve
            mc "Did you say... {b}Teddy{/b}?"
            scene 11_0562 with dissolve
            sue "Yes."
            sue "A witness said they saw a large man carrying what looked like a body out of the premises late at night."
            sue "Hank suggests the group hired a cleaner, but he missed a few spots of blood, so hardly a professional."
            scene 11_0563 with dissolve
            mct "Fuck. Fuck. FUUUUCK!"
            scene 11_0564 with dissolve
            sue "I only pray it's true."
            sue "The odious little man was always a menace."
        else:
            sue "His brother, Teddy."
            sue "He disappeared after killing his partner, her friends, and her daughter."
            sue "He apparently made quite the mess."
            scene 11_0564 with dissolve
            sue "The odious little man is a menace."
        scene 11_0565 with dissolve
        sue "Regardless, it's no concern of ours.\nWe are free to return home."
        scene 11_0566 with dissolve
        sue "Thank you for coming. And good work, [mc].\nI knew my instinct would prove right about you."
        scene 11_0567 with dis1
        scene 11_0568 with dis1
        scene 11_0569 with dis1
        scene 11_0570 with dis1
        pause 0.5
    scene 11_0539 with dissolve
    mc "What do I owe you?"
    ame "I had it under control, you know!"
    mc "Sorry?"
    scene 11_0540 with dissolve
    ame "Rudy! I was in control of the situation.\nI didn't need your help."
    mc "Err, right... I'm sorry."
    scene 11_0541 with dissolve
    ame "This place is the same for everyone. You can't show any weakness."
    ame "If they see me as a pushover, it'll just encourage them."
    scene 11_0542 with dissolve
    mc "Okay, you're right. And again, I'm sorry."
    mc "I find it difficult {i}not{/i} to step in when I see something like that, but it won't happen again."
    mc "So, how much do I owe you?"
    scene 11_0543 with dissolve
    ame "It's on me."
    ame "I didn't need your help, but still, I appreciate the effort."
    scene 11_0544 with dissolve
    mc "Thanks."
    ame "Not seen you in here before.\nYou new?"
    scene 11_0545 with dissolve
    mc "Yeah. Not from around here, though."
    mc "Your boss wanted to meet me."
    ame "{i}My{/i} boss? Don't you mean {b}our{/b} boss?"
    ame "You're here with Sue, right?"
    mc "Uh, yeah."
    scene 11_0546 with dissolve
    ame "Do yourself a favor..."
    ame "Stay in Springhaven and away from here; it's not a good place to be."
    scene 11_0547 with dissolve
    mc "Believe me, I'll be more than happy never to set foot in this place again."
    mc "See ya."
    ame "Bye."
    stop music fadeout 1.0
    scene black with fade1
    call UpdateOakhillData (4)
    call UpdateSpringhavenData (5)
    $ springhaven_ch+=1
    $ springhaven_open=False
    $ cedargrove_open=False
    $ oakhill_open=True
    scene 11_0571 with Fade(0,1,2)
    if Nettie.isActive():
        mct "What a goddamn shitshow."
        mct "I'd better go see Nettie."
        scene black with fade1
        jump CedarGrove_VisitNettieAndHayley
    else:
        mct "Dragging me all the way down here... just for that!"
        mct "Wasting my goddamn time! I fuckin' hate this town!"
        scene black with fade1
        jump ShowMap
return

label CedarGrove_MeetTeddy:
    scene 11_0517 with dissolve
    call Emotion (hank, "Sigh", "What the hell are you doin' here??")
    scene 11_0518 with dissolve
    ted "I need a fuckin' drink. Now."
    scene 11_0519 with dissolve
    hank "You should be at home, resting, Teddy!"
    $ Teddy_name="Teddy"
    ted "I've rested enough. I want blood."
    mct "Fuck!"
    scene 11_0520 with dissolve
    mct "That's him. The asshole who hit Nettie."
    scene 11_0521 with dissolve
    ted "Beer. Don't make me ask twice."
    ame "You got it, Teddy."
    ted "And bring one for my brother!"
    hank "You shouldn't even be drinking with the meds--"
    scene 11_0522 with dissolve
    ted "Quit ya damn whining!"
    ted "Who the hell's this?"
    hank "One of Sue's guys."
    scene 11_0523 with dissolve
    ted "Then why's he sittin' here on his ass?"
    scene 11_0524 with dissolve
    hank "He's the new guy. Not his lane."
    mc "What happened?"
    scene 11_0525 with dissolve
    ted "What happened is some pricks thought they could do this to me!"
    scene 11_0526 with dissolve
    hank "We've been havin' trouble with a group of assholes who think they can operate in our town."
    hank "They caught him at his girlfriend's place. Beat him bad."
    hank "Dragged the woman and her kid away while he was out cold."
    scene 11_0527 with dissolve
    hank "Nobody's seen them since. No calls. No ransom."
    hank "Might already be dead."
    scene 11_0528 with dissolve
    ted "Fuck those bitches!\nGood riddance if you ask me!"
    ted "But the fuckers will pay for what they did to me!\nI wanna watch 'em beg, Hank! Right before I kill 'em."
    hank "Easy, Ted. We'll find 'em."
    scene 11_0529 with dissolve
    mct "I'm sitting right here, idiot."
    mct "Nettie said he'd been drinking all day...\nThat's the only reason he doesn't recognize me."
    mct "Sounds like he's made up some bullshit story about the whole thing. Saving his pride."
    scene 11_0530 with dissolve
    mct "Clearly doesn't give a damn about Hayley or Chloe."
    mct "Good. If he doesn't care, he won't look."
    scene 11_0531 with dissolve
    hank "Everyone's out there lookin' right now."
    ted "Then why ain't they found anyone yet?"
    hank "Because they're hidin', they knew they crossed a line."
    hank "Relax. We'll get 'em."
    ted "I want 'em dead - every last one."
    scene 11_0532 with dissolve
    ted "Why the hell's the new guy still here??"
    hank "Fuck off, [mc]."
    scene 11_0533 with dissolve
    pause 0.5
    scene 11_0534 with dissolve
    sue "So?\nHe was eager to meet you. Why?"
    mc "Think you caught him off guard by recommending me."
    scene 11_0535 with dissolve
    mc "Don't think he trusts you very much, and he sure as hell doesn't trust me."
    sue "Good."
    mc "Good?"
    scene 11_0536 with dissolve
    sue "I surmise that whatever has Anton upset is {i}your{/i} doing."
    mc "Yeah, I imagine so."
    scene 11_0537 with dissolve
    sue "Excellent."
    sue "I'm returning to Springhaven. We shall discuss it further there."
    mc "Am I done here?"
    sue "You are."
    scene 11_0538 with dissolve
    sue "Thank you for coming. And good work, [mc].\nI knew my instinct would prove right about you."
return

label CedarGrove_VisitNettieAndHayley:
    scene 11_0572 with Fade(0,1,2)
    mct "Man, I'm so done with driving today."
    scene 11_0573 with dissolve
    mct "Sure Nettie won't mind me stayin' over."
    scene 11_0574 with fade1
    net "Of course you can!"
    mc "Thanks."
    scene 11_0575 with dissolve
    net "[mc]'s staying the night."
    hay "Great!\nI'm sure Chloe will be happy to have someone else to ignore!"
    scene 11_0576 with dissolve
    mc "Chloe's ignoring you?"
    hay "Not just me. Everyone.\nShe's fed up with being stuck in here all the time."
    scene 11_0577 with dissolve
    net "She's bored, that's all it is, I'm sure."
    net "To be fair, we all are.\nBut most importantly, we're all safe."
    scene 11_0578 with dissolve
    mc "She's been through a lot recently.\nIf you think it'll help, maybe I can talk to her?"
    hay "It can't hurt. Thanks."
    scene 11_0579 with dissolve
    hay "Well, I'll leave you two alone to catch up."
    net "You don't need to leave!"
    hay "It's fine. I'm gonna go read {i}another{/i} book."
    scene 11_0580 with dissolve
    mc "Actually, Hayley, there's something I want to talk to you about later."
    hay "Oh, okay.\nI'll be in my room."
    scene 11_0581 with fade
    mc "So you're all goin' stir crazy, huh?"
    net "Yeah. It's a small price to pay, though."
    scene 11_0582 with dissolve
    mc "Any news about the guy?"
    net "Surprisingly, no."
    net "Lizzie called Father David, and even he didn't get the visit he was dreading."
    scene 11_0583 with dissolve
    net "Teddy knows where our church is."
    net "We all expected that's where he'd begin searching for Hayley."
    scene 11_0584 with dissolve
    mc "Could be just layin' low.\nWatching from a distance to see if you or Sister Elizabeth show up."
    net "Yes, it's possible."
    net "From what I gather, not really his style, though."
    mc "What do you know about him?"
    scene 11_0585 with dissolve
    net "Only what Hayley's told me."
    net "He's a nasty piece of work.\nA troublemaker with a bad temper."
    net "Not a law-abiding citizen. He has a brother who's the same."
    scene 11_0586 with dissolve
    net "To put it bluntly, he's a psychotic, drunken, woman-beating bastard that everyone should avoid like the plague."
    scene 11_0587 with dissolve
    mc "Makes you wonder... Why would Hayley - or {b}any{/b} woman - enter into a relationship with a guy like that??"
    net "Low self-esteem."
    net "When they first met, she was vulnerable - and he took full advantage."
    scene 11_0588 with dissolve
    net "It was all happiness and love to begin with.\nDidn't take long for jealousy to set in, though."
    net "That's when the mental abuse started."
    net "As you can guess, the physical abuse followed pretty soon after."
    scene 11_0589 with dissolve
    net "He made her feel trapped and alone. Isolated her and Chloe."
    net "All she had was the church.\nTook her a long time to trust me enough to confide."
    net "Took even longer to convince her to leave."
    scene 11_0590 with dissolve
    net "She's been through a lot.\nShe's a tough, brave woman who deserves our help."
    net "And if that means I have to put my life on hold for a while to support them through this, then that's what I'll do."
    net "And Teddy? He got what he deserved!\nSo I hope you don't feel bad for the beating you gave him."
    scene 11_0591 with dissolve
    mc "Sounds like he got what was comin' to him."
    net "My thoughts exactly."
    scene 11_0592 with dissolve
    net "You hungry? I was about to make us all something to eat when you knocked."
    mc "Yeah, I could eat."
    scene 11_0593 with dissolve
    mc "I'll go and have that chat with Hayley."
    net "Okay.\nSay hello to Chloe while you're up there.\nDespite what Hayley said, I'm sure she'll be pleased to see you!"
    call CedarGrove_VisitNettieAndHayleySeeChloe
    call CedarGrove_VisitNettieAndHayleySeeElizabeth
    call CedarGrove_VisitNettieAndHayleySeeHayley
    scene 11_0704 with Fade(0,0,2)
    mc "Damn, Nettie! You can {b}cook{/b}!"
    mc "Don't think I'm gonna need to eat for another week!"
    scene 11_0705 with dissolve
    liz "See!\nIt's not only us who think your portion sizes are too big!"
    net "No they're not!"
    liz "Do you know how much weight I've gained since we moved in here?"
    scene 11_0706 with dissolve
    hay "We have this conversation every time it's Nettie's turn to cook."
    scene 11_0707 with dissolve
    hay "And Lizzie's right, your portions are huge!\nWe could feed half the street when you're on kitchen duty!"
    liz "Thank you!"
    net "[lol]"
    scene 11_0708 with dissolve
    chlo "Kitchen's clean again."
    hay "Thanks, Sweetheart.\nCome, sit down with us."
    if Chloe.isActive():
        chlo "Okay, just gonna get into my PJs."
        call CedarGrove_VisitNettieAndHayleyChloeSit
    else:
        chlo "Nah, I'm gonna lie on my bed for a bit.\nThink I ate too much."
        scene 11_0709 with dissolve
        net "Try not to worry, Hayley. She'll come around."
        hay "I hope you're right."
        scene 11_0710 with dissolve
        liz "We should try to find her a hobby.\nSomething to keep her occupied."
        scene 11_0711 with dissolve
        hay "Yeah. [mc] said she was exercising earlier.\nMaybe we can get her some equipment?"
        scene 11_0712 with dissolve
        liz "{size=*0.7}I bet the church will have some!\nPeople donate all kinds of stuff."
        scene 11_0713 with dissolve
        net "{size=*0.4}We can call Father David and ask. Maybe he can get someone to deliver it."
        scene 11_0714 with dissolve
        mc "[whi]...Zzzz..."
    scene black with Fade(3, 4, 0)
    "[whi][mc]?"
    scene 11_0751 with dissolve
    net "[mc], wake up."
    scene 11_0752 with dissolve
    mc "[whi]Hmmm?"
    net "You still do that, huh?"
    scene 11_0753 with dissolve
    call Emotion (mc, "Groan", "Do what?")
    net "Fall asleep mid-conversation!"
    scene 11_0754 with dissolve
    mc "Where'd everyone go?"
    net "Bed. It's late."
    scene 11_0755 with dissolve
    net "I didn't want to leave you down here.\nWe have a spare room with a comfortable bed."
    $ a=False
    if Nettie.L>3:
        net "... Or, we could share mine."
        if not EzModeActive:
            menu:
                "[wk_y]Hmm, tough choice":
                    $ a=True
                    scene 11_0756 with dissolve
                    pause 0.5
                "Thanks, but no. I need to get some sleep":
                    $ Nettie.Add("Refused")
        else:
            $ a=True
            scene 11_0756 with dissolve
            pause 0.5
    scene 11_0757 with dissolve
    $ dia = "Come on" + ("." if a else ", I'll show you where it is.")
    net "[dia]"
    if not a:
        net "Wouldn't want you accidentally walking in on Lizzie again!"
        mc "Oh... She told you about that, huh?"
        net "[lol]"
    scene black with Fade(2, 1, 0)
    if a:
        call NettieReplay03
    jump CedarGrove_VisitNettieAndHayleyNextDay
return

label CedarGrove_VisitNettieAndHayleySeeChloe:
    scene 11_0594 with fade1
    play sound "knock.mp3"
    scene 11_0595 with dis1
    scene 11_0596 with dis1
    call Emotion (chlo, "Grunt", "Yeah?")
    scene 11_0597 with dissolve
    mc "Hey."
    chlo "[mc]! You're back!"
    mc "Said I would be, didn't I?"
    mc "What you doin'?"
    scene 11_0598 with dissolve
    chlo "What does it look like?! Exercising!"
    scene 11_0599 with dissolve
    chlo "I refuse to be like Mom."
    chlo "I'm training myself, I won't let any guy beat on me like she's had to suffer!"
    scene 11_0600 with dissolve
    mc "Good for you!"
    $ tCh=Chloe.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Offer to help":
                $ tCh=True
            "Leave her to it[wk_c]":
                $ tCh=False
    if not tCh:
        call CloseCharacterPath (Chloe, "Chloe")
        $ Pix_Chloe=False
        mc "Okay, I'll leave you to it.\nJust wanted to pop in and say hi."
        chlo "'k. See you later."
        scene 11_0601 with dissolve
        call Emotion (chlo, "Grunt")
        return
    scene 11_0602 with dissolve
    mc "... But, you're doing it wrong."
    chlo "Huh?"
    scene 11_0603 with dissolve
    mc "Your legs - keep them together."
    scene 11_0604 with dissolve
    mc "There you go, like that."
    mc "Now try it. I'll spot you."
    call Loop_Dissolve (4, True, False, "e11/11_0605.webp", "e11/11_0606.webp")
    scene 11_0607 with dissolve
    chlo "Damn! It's a lot harder!"
    mc "Yeah, but it works the muscles more, which means better results."
    if Pix_Chloe:
        mc "Oh, thanks for the new photo, by the way."
        scene 11_0609 with dissolve
        chlo "Oh my god! Shut up!"
        scene 11_0610 with dissolve
        chlo "It's too cringe! We don't talk about it. Ever!"
        call Loop_Dissolve (4, True, False, "e11/11_0607.webp", "e11/11_0608.webp")
        scene 11_0611 with dissolve
        chlo "But, since you brought it up... Did you, umm... you know..."
        mc "Hell yeah I did!"
        scene 11_0612 with dissolve
        chlo "It's so embarrassing!"
        mc "That I do it? Or because I used your photo?"
        scene 11_0613 with dissolve
        chlo "That I get a kick out of knowing you're looking at {b}me{/b} when you're doing it!"
        mc "[lol]"
    else:
        mc "Keep going!"
        call Loop_Dissolve (4, True, False, "e11/11_0607.webp", "e11/11_0608.webp")
    scene 11_0614 with dissolve
    chlo "This is cool! What else can you teach me?"
    mc "Uh... Okay... Flip over, let's see you do some press-ups."
    scene 11_0615 with fade1
    mc "Good. Keep your back as straight as you can."
    call Loop_Dissolve (3, True, False, "e11/11_0616.webp", "e11/11_0617.webp")
    $ bp=False
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e11/11_0618.webp", 1201, 502, True, "CedarGrove_AF04") with dissolve
        pause
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 11_0618
            hide screen imgMap
        else:
            $ bp=True
    else:
        scene 11_0618 with dissolve
        pause 0.5
        if not EzModeActive:
            menu:
                "[wk_y]Adjust her butt position":
                    call CedarGrove_AF04
                    $ bp=True
                "Don't":
                    pass
        else:
            call CedarGrove_AF04
            $ bp=True
    if bp:
        mc "Come on... Give me three more."
        call Loop_Dissolve (3, True, False, "e11/11_0625.webp", "e11/11_0626.webp")
    else:
        mc "Great. Give me three more."
        call Loop_Dissolve (3, True, False, "e11/11_0616.webp", "e11/11_0617.webp")
    mc "Great work!"
    scene 11_0627 with fade1
    chlo "OHHHH!"
    chlo "This one hurts!"
    scene 11_0628 with dissolve
    mc "You've heard the expression - {i}no pain, no gain{/i}!\nKeep going."
    if bp:
        call Loop_Dissolve (3, True, False, "e11/11_0630.webp", "e11/11_0628.webp")
        scene 11_0630 with dissolve
        mc "Nice!"
        scene 11_0631 with dissolve
        chlo "What is?"
        chlo "My form, or my ass?"
        mc "Both!"
        scene 11_0632 with dissolve
        mc "But if I had to choose just one..."
        mc "Definitely your ass. Think I'm in love with it."
        scene 11_0633 with dissolve
        chlo "[lol]"
    else:
        call Loop_Dissolve (3, True, False, "e11/11_0629.webp", "e11/11_0628.webp")
        mc "Excellent!"
    scene 11_0634 with dissolve
    mc "Think that's enough for one day. Good job."
    chlo "Thanks, [mc].\nAnd thanks for the tips!"
    mc "Anytime."
    scene 11_0635 with dissolve
    chlo "Jeez! You've worn me out!"
    scene 11_0636 with dissolve
    call Emotion (chlo, "UGGHHHH")
    scene 11_0637 with dissolve
    mc "How you doin', Chloe? Settling in here okay?"
    chlo "I guess."
    chlo "I wish it weren't so boring all the time.\nThere's nothing to do here, and the day just seems to drag on and on!"
    scene 11_0638 with dissolve
    chlo "Being stuck indoors 24 hours a day sucks!"
    mc "Yeah, I know."
    scene 11_0639 with dissolve
    mc "Which is why, tomorrow, I'm gonna take you out for a while."
    scene 11_0640 with dissolve
    chlo "FOR REAL?!"
    scene 11_0641 with dissolve
    mc "Yeah!"
    mc "Don't know where yet, but we can find somewhere low-key to hang out a while."
    scene 11_0642 with dissolve
    chlo "Oh my god! You're the best!"
    mc "There is {i}one{/i} condition..."
    if Chloe.L>0:
        scene 11_0644 with dissolve
        chlo "You want to grab my ass again, don't you?"
        scene 11_0648 with dissolve
        mc "No!"
        scene 11_0649 with dissolve
        mc "... Well, {i}yeah{/i}... but that's not it."
        scene 11_0643 with dissolve
        chlo "Then what?"
    else:
        scene 11_0643 with dissolve
        chlo "What is it?"
    scene 11_0648 with dissolve
    mc "Please stop ignoring the others.\nThey're just as fed up with being stuck here as you are. You need to support each other."
    scene 11_0645 with dissolve
    chlo "I don't ignore them!\nI just..."
    scene 11_0646 with dissolve
    chlo "..."
    scene 11_0647 with dissolve
    chlo "Okay."
    if Chloe.L>0:
        scene 11_0650 with dissolve
        pause 0.5
        scene 11_0651 with dissolve
        chlo "Go ahead. Grab it."
        scene 11_0649 with dissolve
        mc "Yeah?"
        chlo "[whi]Mm-hmm."
        scene 11_0652 with dissolve
        mc "Awesome."
        scene 11_0650 with dissolve
        chlo "[whi]This is nice."
        scene 11_0651 with dissolve
        chlo "Sorry for being all sweaty."
        scene 11_0655 with dissolve
        mc "Oh Sweetie, I'm using every ounce of willpower I have to stop myself from licking every drop off your body!"
        scene 11_0654 with dissolve
        chlo "That's {i}soooo{/i} gross!"
        scene 11_0653 with dissolve
        chlo "[lol]"
    scene 11_0656 with dissolve
    pause 0.5
    scene black with Fade(3, 2, 0)
return

label CedarGrove_VisitNettieAndHayleySeeElizabeth:
    play sound "knock.mp3"
    scene 11_0657 with Fade(0,0,1)
    scene 11_0658 with dissolve
    mc "Hayley?"
    mc "Hello?"
    mct "Not this room."
    scene 11_0659 with fade1
    mct "Let's try this one..."
    play sound "knock.mp3"
    scene 11_0660 with dissolve
    mc "Hayley?"
    scene 11_0661 with dissolve
    liz "[mc]! I didn't know you were in town!"
    mc "Crap, sorry, Sister!\nI'm looking for Hayley's room."
    scene 11_0662 with dissolve
    liz "You'll find it down the hall."
    mc "Thanks. Sorry for disturbing you."
    if not Elizabeth.Has("Saw"):
        return
    scene 11_0663 with dissolve
    liz "Nettie never said you were visiting!"
    mc "It wasn't--"
    scene 11_0664 with dissolve
    mc "...planned."
    scene 11_0665 with dissolve
    mc "Uh... It was a last-minute kinda thing."
    scene 11_0666 with dissolve
    liz "Staying long?"
    scene 11_0667 with dissolve
    scene 11_0668 with dissolve
    mc "No. Leavin' tomorrow."
    scene 11_0669 with dissolve
    liz "Oh, that's a shame.\nI'd like to get to know you better, but you never hang around long enough!"
    scene 11_0670 with dissolve
    mc "Yeah, sorry."
    scene 11_0671 with dissolve
    mc "Maybe next time I'll stay a bit longer."
    scene 11_0672 with dissolve
    liz "Seen enough?"
    mc "This payback for me dressing in front of you?"
    scene 11_0673 with dissolve
    liz "It was to begin with!"
    scene 11_0674 with dissolve
    liz "But turns out I like you looking at my naked body just as much as you enjoyed me looking at yours."
    scene 11_0675 with dissolve
    mc "If you ever want me to look at it again, you just let me know."
    liz "And {i}you{/i} can let me know if you ever want to see it again!"
    scene black with Fade(2, 1, 0)
return

label CedarGrove_VisitNettieAndHayleySeeHayley:
    play sound "knock.mp3"
    scene 11_0676 with Fade(0,0,1)
    scene 11_0677 with dissolve
    mc "Hayley?"
    scene 11_0678 with dissolve
    hay "You can come in."
    scene 11_0679 with dissolve
    mc "How's the book?"
    call Emotion (hay, "Sigh", "Not very good at all, but it's better than nothing.")
    scene 11_0680 with dissolve
    mc "How you holding up?"
    scene 11_0682 with dissolve
    hay "I'm good!"
    hay "It's not much fun for any of us being tucked away in this house, especially Chloe, but given the circumstances..."
    hay "Did you get the chance to talk to her?"
    if Chloe.isActive():
        mc "Yeah."
        mc "Hope you don't mind, I told her I'd take her out for a little while tomorrow."
        scene 11_0681 with dissolve
        hay "That's a nice gesture!\nThank you!"
        hay "It'll do her the world of good to get away from here for a bit."
    else:
        mc "No, she was exercising. Didn't want to disturb her."
    scene 11_0683 with dissolve
    mc "Nettie told me it's been all quiet on the Teddy front."
    mc "That's good, I guess."
    scene 11_0684 with dissolve
    hay "I don't like it."
    hay "He's up to something; I'm sure of it."
    scene 11_0683 with dissolve
    mc "When I was driving you back to the motel, you begged me not to call the cops."
    mc "Said it'd make things worse. What did you mean by that?"
    scene 11_0685 with dissolve
    hay "You want to know what would've happened if you'd called the cops?"
    hay "Chloe and I would be back in Teddy's locked basement.\nYou'd be in jail, or dead."
    scene 11_0686 with dissolve
    hay "And Teddy?\nTeddy would be at his brother's bar, drinking champagne."
    hay "Celebrating - with those cops you'd called."
    hay "Teddy and Hank own everyone who wears a badge in this town."
    scene 11_0687 with dissolve
    hay "I know you wanted to do the right thing by us, [mc]."
    hay "Believe me, by {b}not{/b} calling the police, you did."
    scene 11_0688 with dissolve
    mc "But didn't he take Chloe's cell to prevent her from calling the police?\nIf he owned the cops, as you say, why bother?"
    scene 11_0687 with dissolve
    hay "It's not the cops he was worried about!\nHe didn't want his brother to find out he was there."
    scene 11_0688 with dissolve
    mc "So they're like part of a big criminal organization or something?"
    scene 11_0689 with dissolve
    hay "Hah!\nThey're not a {i}part{/i} of anything - they {b}are{/b} the organization!"
    hay "You wouldn't believe some of the things I've witnessed!\nMakes my stomach churn just thinking about it."
    scene 11_0690 with dissolve
    mc "Is that why he wouldn't let you leave? Too much of a risk to have you talking?"
    hay "Yeah, I suppose. But they own every damn cop!\nWho the hell am I gonna tell?! My hairdresser??"
    scene 11_0691 with dissolve
    mc "You and Chloe have been through a lot."
    mc "If there's anything I can do to help you both move forward, please let me know."
    scene 11_0692 with dissolve
    hay "[mc], you've already done more than I could've hoped."
    hay "I'll always be thankful for what you did."
    scene 11_0693 with dissolve
    mc "You thought about what happens next? Once this is all over?"
    scene 11_0694 with dissolve
    hay "It doesn't feel like it'll ever be over, but yeah, I find my mind wandering sometimes."
    scene 11_0695 with dissolve
    hay "I want to take Chloe as far away from here as possible."
    hay "Start afresh, somewhere new.\nSome place where nobody knows us, and Teddy can't ever find us."
    if EzModeActive:
        call EzModeAsk ("Hayley")
        if _return:
            $ Hayley.Add("EZ")
    scene 11_0696 with dissolve
    mc "Sounds nice."
    net "[whi]GUYS?"
    scene 11_0697 with dissolve
    net "[whi]FOOD'S READY!"
    scene 11_0698 with fade
    mc "After you, Madam."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e11/11_0699.webp", 822, 686, True, "CedarGrove_AF05") with dissolve
        hay "Why, thank you, Good Sir."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 11_0699
            hide screen imgMap
    else:
        scene 11_0699 with dissolve
        hay "Why, thank you, Good Sir."
        if not EzModeActive:
            menu:
                "[wk_y]Playfully slap her butt":
                    call CedarGrove_AF05
                "Don't":
                    pass
        elif Hayley.Has("EZ"):
            call CedarGrove_AF05
    scene 11_0703 with dissolve
    pause 0.5
    scene black with Fade(3, 2, 0)
return

label CedarGrove_VisitNettieAndHayleyChloeSit:
    scene 11_0715 with dissolve
    net "One visit from [mc] and she's like a different person!"
    net "She was so chatty at the table!\nIt's nice to see her happy."
    scene 11_0716 with dissolve
    liz "You did a nice thing by offering to take her out tomorrow."
    mc "I still remember the times when I was confined to barracks, so I know what you're all going through."
    liz "Isn't it a little risky, though? What if someone recognizes her?"
    mc "Nah. I'm gonna take her a couple of towns away."
    scene 11_0717 with dissolve
    hay "I hope you know what you're letting yourself in for!"
    hay "She already has a list as long as your arm of all the things she wants to do!"
    scene 11_0718 with dissolve
    mc "As long as it doesn't involve me having to eat any more food, I'll be fine."
    net "[lol]"
    scene 11_0719 with fade1
    hay "We're running low on toiletries, too."
    scene 11_0720 with dissolve
    net "Father David's sending some over tomorrow, along with more donated clothes."
    hay "Great."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e11/11_0721.webp", 880, 410, True, "CedarGrove_AF06") with dissolve
        pause
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 11_0721
            hide screen imgMap
    else:
        scene 11_0721 with dissolve
        pause
        call CedarGrove_AF06
    scene 11_0723 with dissolve
    hay "Uh, Chloe... We have a guest.\nCan't you wear something a little more appropriate?"
    chlo "This is all I have! My other PJs are in the laundry."
    scene 11_0724 with dissolve
    net "Oh, I'm sure [mc] isn't bothered, Hayley.\nHe has daughters of his own; he's seen it all before."
    scene 11_0725 with dissolve
    hay "If it makes you uncomfortable, I can lend her something of mine."
    mc "Nah, it's fine.\nLike Nettie said, I'm used to it."
    scene 11_0726 with dissolve
    hay "I'm sorry, Sweetheart. I wasn't trying to embarrass you."
    scene 11_0727 with dissolve
    hay "Where you going?"
    chlo "I like sitting in the corner."
    scene 11_0728 with dissolve
    chlo "I can't wait for tomorrow!"
    mc "Decided what you'd like to do?"
    scene 11_0729 with dissolve
    chlo "No. I keep changing my mind!"
    chlo "To be honest, I don't care {i}what{/i} we do.\nIt's the getting out part I'm the most excited for."
    scene 11_0730 with dissolve
    mc "Great!\nI've been meaning to renew my license, so we can go to the DMV and sit around for a few hours while it gets sorted!"
    scene 11_0731 with dissolve
    chlo "[lol]"
    scene 11_0732 with dissolve
    hay "Damn, it's so nice to hear you laugh again. I've missed that."
    chlo "It's not my fault your jokes are {i}terrible{/i}!"
    scene 11_0733 with dissolve
    hay "Ouch! [lol]"
    scene 11_0734 with dissolve
    liz "If you'll excuse me, ladies... and gentlemen, it's past my bedtime!"
    scene 11_0735 with dissolve
    liz "Night, all."
    net "Night, Lizzie."
    scene 11_0736 with dissolve
    net "She's right.\nI'm going to jump in the shower before it gets too late."
    mc "Okay."
    scene 11_0737 with dissolve
    hay "Hold on, I'll walk up with you.\nI need to get changed; my belly can't handle these jeans a second longer after that banquet!"
    net "[lol]"
    scene 11_0738 with dissolve
    hay "I'll just be a minute, Sweetheart."
    chlo "Okay."
    scene 11_0739 with dissolve
    chlo "She asks me to sit with her, then abandons me!"
    mc "She went to get changed. I don't think you can call that abandonment!"
    scene 11_0740 with dissolve
    chlo "It's fine, I still have you.\nYou won't abandon me, will you?"
    mc "Never in a million years!"
    scene 11_0741 with dissolve
    chlo "Good."
    scene 11_0742 with dis1
    scene 11_0743 with dis1
    chlo "Otherwise, I'd have to hunt you down and kill you."
    scene 11_0744 with dissolve
    mc "{i}Never abandon Chloe{/i} - Noted!"
    chlo "[giggles]"
    scene 11_0745 with dissolve
    mc "And I, for one, am happy your other PJs are in the laundry. You look beautiful."
    scene 11_0746 with dissolve
    chlo "Thank you."
    if Pix_Chloe:
        scene 11_0747 with dissolve
        chlo "I can, uhh, take a photo later, if you'd like to... umm... add it to your collection."
        mc "Absolutely."
        scene 11_0748 with dissolve
        chlo "Okay."
    scene 11_0749 with dissolve
    chlo "Oh my god! {i}What{/i} are you wearing?!"
    hay "What's wrong with it?"
    chlo "You look like Sister Elizabeth!"
    scene 11_0750 with dissolve
    hay "I'm running out of clothes, too!"
    hay "Be grateful I'm not making {b}you{/b} wear it!"
    chlo "[lol]"
return

label CedarGrove_VisitNettieAndHayleyNextDay:
    if Chloe.isActive():
        call CedarGrove_VisitNettieAndHayleyTakeChloeOut
    else:
        scene 11_0865 with Fade(0, 3, 2)
        scene 11_0866 with dissolve
        mc "Good morning."
        net "Morning, [mc]."
        scene 11_0867 with dissolve
        chlo "Whatever, Mom.\nI'm going to my room."
        call Emotion (hay, "Sigh", "Chloe!")
        scene 11_0868 with dissolve
        mc "You okay?"
        chlo "Fine."
        scene 11_0869 with dissolve
        hay "She's mad at me because I won't let her go out."
        scene 11_0870 with dissolve
        mc "Give her time. She'll eventually get used to it."
        hay "You really think so?"
        mc "Yeah."
        scene 11_0871 with dissolve
        net "What time are you planning on leaving?"
        mc "Now, actually."
        net "So soon?"
        scene 11_0872 with dissolve
        mc "Yeah, sorry.\nI've got a lot going on right now, need to get back."
        scene 11_0873 with dissolve
        net "Okay, but you're not going anywhere until I've cooked you breakfast!"
        net "Come on."
    scene 11_0983 with Fade(2, 2, 1)
    scene 11_0984 with dis1
    scene 11_0985 with dis1
    scene 11_0986 with dis1
    scene black with Fade(2, 1, 0)
    jump ShowMap
return

label CedarGrove_VisitNettieAndHayleyTakeChloeOut:
    scene 11_0864 with Fade(0, 3, 3)
    scene 11_0874 with dissolve
    mc "Morning."
    net "Good morning, [mc]."
    scene 11_0875 with dissolve
    chlo "Can we go now?"
    hay "Chloe! The poor man's just got out of bed!"
    scene 11_0876 with dissolve
    hay "I'm sorry, [mc]!\nShe's been sitting here, ready, for ages."
    net "You didn't hear her {i}accidentally{/i} slamming doors earlier, in an attempt to wake you?"
    scene 11_0877 with dissolve
    mc "That was you? Heh."
    chlo "[whi]No."
    mc "Well, a promise is a promise."
    scene 11_0878 with dissolve
    mc "Let's go!"
    scene 11_0879 with dissolve
    net "I'm sure she won't mind waiting a little longer; have some breakfast first!"
    mc "It's fine. We can eat while we're out."
    scene 11_0880 with fade1
    mc "So, where we goin'?"
    chlo "Uh, I don't know."
    mc "Couldn't make up your mind?"
    scene 11_0881 with dissolve
    chlo "No... It's just..."
    chlo "Anywhere. I don't care where we go."
    scene 11_0882 with dissolve
    mc "What's wrong?"
    chlo "Nothing!"
    mc "Chloe?\nIt's okay. You can tell me."
    scene 11_0883 with dissolve
    call Emotion (chlo, "Sigh", "I...")
    chlo "I was hoping Mom would give me some money, so that I could buy some new clothes... but she doesn't have any."
    chlo "Most of the stuff that's been given to us is {i}old people's{/i} clothes."
    chlo "I know I sound ungrateful, but honestly, I'm not. It's just..."
    scene 11_0882 with dissolve
    mc "Hey, it's fine!"
    mc "Here's the deal."
    scene 11_0884 with dissolve
    mc "I've got a wallet full of cash right now.\nWhatever's left in it by the end of the day, I'm gonna burn!"
    mc "So if I were you, I'd spend it first!"
    scene 11_0885 with dissolve
    chlo "[mc]... that's {b}so{/b} kind, but I can't let you spend {i}your{/i} money."
    mc "You're not the boss of me!\nDon't wanna spend it? Okay, you can help me set it on fire later."
    scene 11_0886 with dissolve
    chlo "You wouldn't {i}really{/i} burn it!"
    mc "Try me!"
    scene 11_0887 with dissolve
    chlo "Okay! I'll spend your money! Jeez![lol]"
    scene 11_0884 with dissolve
    if not Chloe.Has("Knows"):
        mc "There we go!"
        mc "Oh, and didn't I promise we'd replace your phone, too?"
        chlo "No, [mc]! That's too much! I couldn't accept it."
        menu:
            "[wk_y]Send me a photo and we'll call it even":
                scene 11_0889 with dissolve
                chlo "A photo? Of what?"
                mc "You, in those cute PJs you wore last night."
                scene 11_0890 with dissolve
                chlo "Why??"
                mc "Because you looked beautiful and hot!"
                scene 11_0891 with dissolve
                chlo "[whi]No I didn't. You're teasing me."
                mc "Do we have a deal?"
                scene 11_0892 with dissolve
                chlo "You... really want the picture?"
                chlo "Why??"
                mc "Why do {i}you{/i} think? Heh."
                scene 11_0893 with dissolve
                call Emotion (chlo, "Gasp", "OH!")
                chlo "Looking at a photo of... {b}ME{/b}??"
                mc "Hell yeah!"
                scene 11_0894 with dissolve
                chlo "Oh my god!"
                scene 11_0895 with dissolve
                chlo "[whi]Deal."
                mc "Great!"
                $ Pix_Chloe=True
            "Not taking no for an answer":
                scene 11_0885 with dissolve
                chlo "I don't know what I did to deserve you!\nThanks, [mc]."
    else:
        mc "There we go!\nNow..."
    scene 11_0896 with dissolve
    mc "Let's go shopping!"
    scene 11_0897 with dissolve
    call AutoA
    $ renpy.music.set_volume(0.5)
    play music "bgm01.mp3" fadein 2.0
    scene 11_0898 with dis1
    scene 11_0899 with dis1
    scene 11_0900 with dis1
    scene 11_0901 with dis1
    scene 11_0902 with dissolve
    scene black with Fade(2, 3, 0)
    scene 11_0903 with Fade(0, 0, 2)
    $ apause(1)
    scene 11_0904 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0905 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0906 with Fade(2, 3, 3)
    $ apause()
    scene 11_0907 with dis1
    $ apause()
    scene 11_0908 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0909 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0910 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0911 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0912 with dis1
    scene 11_0913 with dis1
    $ apause()
    scene 11_0914 with dissolve
    $ apause(1)
    scene 11_0915 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0916 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0917 with dissolve
    $ apause(1)
    scene 11_0918 with dissolve
    $ apause()
    scene 11_0919 with hpunch
    $ apause()
    scene 11_0920 with dissolve
    $ apause()
    scene 11_0921 with dissolve
    $ apause()
    scene 11_0922 with dissolve
    $ apause()
    if not Chloe.Has("Knows"):
        scene 11_0923 with Fade(2, 3, 3)
        $ apause(1)
    scene 11_0924 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0925 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0926 with Fade(2, 3, 3)
    $ apause(1)
    scene 11_0927 with dis1
    $ apause(1)
    scene 11_0928 with dis1
    $ renpy.music.set_volume(0.4)
    $ apause(1)
    $ renpy.music.set_volume(0.3)
    call AutoA (False)
    scene 11_0929 with dis1
    $ renpy.music.set_volume(0.2)
    chlo "Thank you so much for today, [mc].\nIt's been a lot of fun!"
    mc "My pleasure.\nI've had fun, too!"
    scene 11_0930 with dissolve
    mc "Listen, I know things are tough for you right now, but it's not forever."
    mc "Things will get better for you and your mom."
    scene 11_0931 with dissolve
    chlo "I don't mind it so much when you're in town.\nWill you keep visiting us?"
    mc "Of course."
    chlo "You promise?"
    mc "Didn't I {i}already{/i} swear I'd never abandon you?"
    scene 11_0932 with dissolve
    chlo "Yeah, you did."
    scene 11_0933 with dissolve
    chlo "Can I ask you something kinda personal?"
    mc "Sure."
    scene 11_0934 with dissolve
    chlo "How many men have you killed?"
    scene 11_0935 with dissolve
    mc "What?"
    chlo "Sister Nettie told my mom you were a soldier."
    mc "Right.\nUh, I don't really know."
    scene 11_0936 with dissolve
    chlo "Shit! {i}That{/i} many?!"
    scene 11_0935 with dissolve
    mc "What? I didn't say that."
    scene 11_0937 with dissolve
    chlo "You didn't have to!"
    chlo "If it were a low number, you'd know it {b}exactly{/b}. But do something {i}a lot{/i}, and you lose count!"
    mc "That's not..."
    scene 11_0938 with dissolve
    chlo "How many times have you been shot?"
    mc "Uh, twice."
    scene 11_0939 with dissolve
    chlo "See! {b}Low{/b} number!"
    scene 11_0940 with dissolve
    chlo "How many women have you kissed?"
    scene 11_0941 with dissolve
    mc "I don't know!"
    chlo "A lot though, right? {i}High{/i} number."
    scene 11_0942 with dissolve
    chlo "I've kissed two guys - {i}low{/i} number, easy to remember."
    scene 11_0943 with dissolve
    chlo "Number of times you've married?"
    mc "Once."
    chlo "{i}Low{/i} number."
    scene 11_0944 with dissolve
    chlo "What about sex?"
    mc "WHAT?!"
    chlo "I'm not talking body count, but the {b}actual{/b} number of times you've performed the deed."
    scene 11_0945 with dissolve
    mc "Yeah, I'm not talking to you about..."
    chlo "Just answer the question!"
    scene 11_0946 with dissolve
    mc "... Jeez... I have no idea!"
    chlo "Exactly! {i}High{/i} number!"
    mc "C'mon, nobody could answer that."
    scene 11_0947 with dissolve
    chlo "I can!"
    chlo "Zero!\nI've {b}never{/b} had sex, so again, a {i}low{/i} number."
    scene 11_0948 with dissolve
    mc "Okay! You've made your point!"
    mc "Yes - I've killed a few men.\nCan we change the subject now?!"
    scene 11_0949 with dissolve
    chlo "Can you teach me how to shoot a gun?"
    mc "What the hell?!"
    scene 11_0950 with dissolve
    mc "No!"
    chlo "Please!"
    mc "Why do you want to learn how to shoot??"
    scene 11_0951 with dissolve
    chlo "I already told you!"
    chlo "I don't ever want to be a victim like my mom."
    chlo "I want to be able to look after myself. Defend myself. Fight back."
    mc "I'm sorry, Chloe. I can't teach you how to shoot someone."
    scene 11_0952 with dissolve
    chlo "[whi]Okay."
    mc "But I'd be happy to teach you some self-defense techniques sometime, if that'll help?"
    scene 11_0953 with dissolve
    chlo "Yeah? Okay!"
    mc "Great."
    scene 11_0954 with dissolve
    mc "Now eat up; we need to get you home before your mom starts to worry."
    stop music fadeout 3.0
    scene black with Fade(3, 2, 0)
    $ renpy.music.set_volume(1.0)
    scene 11_0955 with Fade(0,2,3)
    pause 0.5
    scene 11_0956 with fade
    net "How was it?"
    mc "Fun, but exhausting!"
    scene 11_0957 with dissolve
    liz "Can I get you a coffee?"
    mc "Thanks, but no.\nI need to get going. I only came in to say goodbye."
    scene 11_0958 with dissolve
    net "Chloe will be sad to see you leave!"
    mc "She knows I'll be back."
    liz "We'll all miss you!"
    scene 11_0959 with dissolve
    net "I know I will..."
    scene 11_0960 with dissolve
    net "... so come back {b}soon{/b}."
    scene 11_0961 with dissolve
    hay "Damn, [mc]! Who's the girl you brought back with you??"
    scene 11_0962 with dissolve
    hay "She looks a lot like my daughter, but she has a huge smile on her face - so it can't be Chloe!"
    net "Where is she?"
    hay "In her room. Putting away all the things Mister Soft-Touch here bought her."
    mc "I'll go up and say bye to her."
    scene black with fade1
    play sound "knock.mp3"
    scene 11_0963 with fade
    pause 0.5
    chlo "Come in."
    scene 11_0964 with dissolve
    chlo "[mc], I feel terrible!\nHow did we buy so much stuff?!"
    scene 11_0965 with dissolve
    mc "You rescued my cash from a bonfire! It was the humane thing to do!"
    scene 11_0966 with dissolve
    chlo "Oh, yeah![lol]"
    scene 11_0967 with dissolve
    chlo "Are you leaving now?"
    mc "Yeah, came to say goodbye."
    scene 11_0968 with dissolve
    chlo "You'd better be back soon, Mister!"
    scene 11_0969 with dissolve
    mc "Yes, Ma'am!"
    if Chloe.L==1:
        scene 11_0970 with dissolve
        chlo "I knew you were gonna do that."
        scene 11_0971 with dissolve
        mc "I only do it 'cause I know {i}you{/i} want me to!"
        chlo "HAH! As if!"
    else:
        $ Chloe.L=-1
        $ Pix_Chloe=False
    scene 11_0972 with dissolve
    chlo "I'm going to miss our hugs."
    mc "Me too."
    if Chloe.L==1:
        if Pix_Chloe:
            $ Chloe.Add("SndPic")
            scene 11_0973 with dissolve
            chlo "And I won't forget about the photo you wanted of me in my PJs. I'll send it later."
            mc "I'll look forward to it."
            scene 11_0974 with dissolve
            mc "Damn... Wish you were wearing them right now!"
            scene 11_0975 with dissolve
            chlo "[giggles]"
            scene 11_0976 with dissolve
            chlo "You bought me some cute ones today, so maybe on your next visit..."
            scene 11_0977 with dissolve
            mc "Something else for me to look forward to."
            chlo "[whi]Me too."
        else:
            scene 11_0977 with dissolve
        mc "I'll see you soon."
        scene 11_0978 with dissolve
        mc "[kiss]"
        scene 11_0979 with dissolve
        mc "Bye, Chloe."
        scene 11_0980 with dissolve
        chlo "[kiss]"
        scene 11_0981 with dissolve
        chlo "Bye, [mc]."
    scene 11_0982 with dissolve
    mc "And remember - no ignoring the others!"
    chlo "{i}Yeah, yeah{/i}![lol]"
return

label CedarGrove_Start4:
    play music "barbgm.mp3" loop fadein 2.0 volume .3
    scene 15_0998 with Fade(2,2,3)
    pause
    scene 15_0999 with dissolve
    mct "She doesn't look too happy to see me - what a surprise."
    scene 15_1000 with dissolve
    ame "Why are you here?"
    mc "Come to visit my stalker."
    scene 15_1001 with dissolve
    pause 0.5
    scene 15_1002 with dissolve
    mc "Something wrong?"
    scene 15_1003 with dissolve
    ame "Uhh, no..."
    ame "Umm... It was beer... right?"
    scene 15_1004 with dissolve
    mc "Yeah..."
    scene 15_1005 with dissolve
    rud "Well, look who's back!\nCome and join us, dude!"
    mc "Thanks, but I'm busy."
    scene 15_1006 with dissolve
    rud "See what I mean??\nTry to be nice, and it just gets thrown straight back at ya!"
    scene 15_1007 with dissolve
    ame "Seriously, what are you doing here?"
    ame "I've already apologized for my mistake; what more do you want?"
    scene 15_1008 with dissolve
    mc "Your {i}mistake{/i}?"
    mc "What was the mistake exactly?\nFollowing me around Springhaven, or getting caught?"
    scene 15_1009 with dissolve
    pause 0.5
    scene 15_1010 with dissolve
    ame "Shh!"
    scene 15_1011 with dissolve
    ame "Keep your voice down, you'll get me into trouble!"
    scene 15_1012 with dissolve
    mc "If Hank really sent you to tail me, he would've known there'd be a good chance I'd see you."
    mc "He should know you failed. How else are you to learn from your mistakes?"
    mc "So, if you won't tell him... Maybe I should..."
    scene 15_1013 with dissolve
    ame "NO! WAIT!"
    scene 15_1014 with dissolve
    ame "You can't say anything! {b}Please{/b}!"
    mc "Why?"
    scene 15_1015 with dissolve
    ame "I... can't tell you."
    scene 15_1016 with dissolve
    hank "Sue's guy, right?"
    hank "What you doin' back here?"
    scene 15_1017 with dissolve
    mc "Just passing through. Thought I'd take a break from driving."
    hank "Long way from home. Where you been to be passing through?"
    mc "Visiting family."
    hank "Where?"
    mc "..."
    scene 15_1018 with dissolve
    hank "Like to keep your cards close to your chest, huh?"
    mc "Something like that."
    hank "You know I could find out if I wanted."
    scene 15_1019 with dissolve
    hank "You wanna tell me why you're hassling my barmaid?"
    ame "He wasn't.\nI was giving him an earful for starting a fight with Rudy the last time he was here."
    scene 15_1020 with dissolve
    hank "Oh, yeah... I heard about that."
    hank "Tryin' to be the hero and save the girl?\nQuickest way to her pussy, am I right?"
    scene 15_1021 with dissolve
    hank "She's off-limits."
    hank "Amelia hasn't been here long, but she's a valued member of our staff."
    hank "We don't allow relationships between employees. Understood?"
    mc "Yeah."
    scene 15_1022 with dissolve
    hank "[lol]"
    scene 15_1023 with dissolve
    hank "Jesus! Lighten up will ya?"
    hank "Why would I give a damn if you wanna fuck each other?"
    hank "Just don't do it on my bar!"
    scene 15_1024 with dissolve
    hank "Give us a minute, Sweetheart. I need a word with this guy."
    $ Amelia_name="Amelia"
    $ Amelia.Activate("Amelia")
    $ persistent.AmeliaLocked=False
    ame "Uh... sure."
    scene 15_1025 with dissolve
    hank "Since you're here, there's summat you may be able to help me with."
    scene 15_1026 with dissolve
    hank "If I'm remembering correctly, didn't your military records say you were trained in torture?"
    mc "Trained as much as someone can be, I guess."
    scene 15_1027 with dissolve
    hank "Good! Good!\nI wanna put your skills to use."
    hank "I need answers, and you're just the guy to be askin' the questions."
    scene 15_1028 with dissolve
    mc "Wait... Hold on."
    mc "I was trained to {i}resist{/i} torture techniques, not to {b}administer{/b} them."
    hank "Same thing, right?\nJust givin' instead of takin'."
    scene 15_1029 with dissolve
    hank "I was bein' polite, asking."
    hank "But let me be clear, I'm giving you a fuckin' order."
    scene 15_1030 with dissolve
    hank "You get me the goddamn answers I need, or we're gonna have a problem."
    scene 15_1031 with dissolve
    hank "We're leavin' in ten minutes - plenty of time to finish your drink."
    hank "Are we good?"
    mc "... Yeah."
    scene 15_1032 with dissolve
    hank "Good."
    scene 15_1033 with dissolve
    mct "Fuck."
    scene 15_1034 with dissolve
    ame "You look troubled. What's wrong?"
    mc "Uhh... nothing."
    scene 15_1035 with dissolve
    ame "Thank you for not saying anything to him."
    mc "How'd you know I didn't?"
    ame "I... just know."
    scene 15_1036 with dissolve
    mc "So why don't you return the favor and tell me what you were {i}really{/i} up to?"
    ame "I can't do that, I'm sorry."
    ame "I swear, though, I wasn't there for {b}you{/b}."
    mc "Then... who?"
    scene 15_1037 with dissolve
    ame "You knew I was following you the whole time..."
    $ dia="Why did you still go to those places you visited?\nThe apartment blocks, the cafe"+(", the farm?" if BillSick else "?")
    ame "[dia]"
    scene 15_1038 with dissolve
    mc "It was obvious that {i}whoever{/i} you were, you had something to do with Hank or Sue."
    mc "Nobody else would have a reason to tail me."
    mc "I waited in the entrance of the first apartment block, wanted to see if you'd follow me in."
    mc "You didn't."
    mc "Lots of people living there, no way you'd know which door I was knocking if you're staying in the car."
    if BillSick:
        mc "And the farm?\nHe's one of our truckers. I was just checkin' that everything was ready for the next pick-up."
    scene 15_1039 with dissolve
    mc "Nothing Sue wouldn't already have known.\nI had nothing to hide and wanted to see how long you were planning on tagging along."
    mc "I was a little surprised to see you behind me again a couple of days later, so figured it was time to put an end to your game."
    scene 15_1040 with dissolve
    ame "I wasn't actually following you that morning... Not to begin with."
    ame "I'd already lost track of you on the first day.\nI was leaving town when I saw your truck pull out in front of me."
    scene 15_1041 with dissolve
    mc "You lost me because I needed to go home and had no intention of showing you where I lived."
    ame "Why?\nSounds like you {i}did{/i} have something to hide after all."
    mc "I've answered enough of your questions, so answer mine.\n{b}Who{/b} were you in Springhaven for?"
    scene 15_1042 with dissolve
    ame "I can't tell you."
    ame "I wish you would trust me enough to leave it at that."
    mc "You're asking me to trust you, but you're not willing to trust me?"
    scene 15_1043 with dissolve
    ame "I'm the one taking all the risk here."
    ame "If you can trust me, nothing changes for you."
    ame "But if I trust you and I'm wrong? I'll lose {b}everything{/b}."
    scene 15_1044 with dissolve
    tom "Can we get another round, Amelia?"
    ame "Sure, Tom."
    $ Tom_name="Tom"
    scene 15_1045 with dissolve
    tom "Uhh... Get you another, buddy?"
    hank "He ain't got time."
    scene 15_1046 with dissolve
    hank "C'mon, we're leavin'."
    scene 15_1047 with dis1
    pause 0.5
    stop music fadeout 2.0
    scene 15_1048 with fade2
    if not Nettie.isActive():
        hank "There's a crew tryin' to muscle its way into our territory."
    else:
        hank "You heard about what happened to Teddy, right?"
        mc "Your brother? ...Yeah."
    scene 15_1049 with dissolve
    hank "We caught one of the bastards responsible, but he ain't talkin'."
    hank "I get the feelin'he'll talk to {b}you{/b}."
    scene 15_1050 with dissolve
    mc "What if he doesn't?"
    hank "Then, seems to me, you're not as useful as Sue suggested."
    scene 15_1051 with dissolve
    hank "And if you're useless to us, not much point in keepin' you around, is there?"
    hank "Get in."
    scene 15_1052 with dissolve
    pause 0.5
    scene 15_1053 with dis1
    scene 15_1054 with dis1
    scene black with Fade(2, 2, 0)
    jump CedarGrove_04_Prisoner
return

label CedarGrove_04_Prisoner:
    call CenterText ("A short drive later.")
    scene 15_1055 with Fade(0,0,2)
    scene 15_1056 with dis1
    scene 15_1057 with dis1
    scene 15_1058 with dis1
    scene 15_1059 with dis1
    scene 15_1060 with dissolve
    hank "C'mon."
    scene 15_1061 with fade2
    hank "I want this done fast.\nAsshole's been in here for long enough."
    scene 15_1062 with dissolve
    unk "Boss.\nThe doc's in there with him."
    hank "Why?"
    if TeddyD:
        unk "He stopped breathin' again."
    else:
        unk "Teddy... went too far again. He stopped breathin'."
    hank "Damn it.\nGo take a break, D."
    scene 15_1063 with dis1
    scene 15_1064 with dis1
    scene 15_1065 with dissolve
    mct "Jesus."
    hank "He alive?"
    doc "For now."
    scene 15_1066 with dissolve
    doc "His body can't take much more. He needs rest."
    hank "He can rest when we're done with him."
    scene 15_1067 with dissolve
    doc "I've given him another shot of adrenaline."
    if TeddyD:
        doc "I can't keep doing this.\nHe'll stop responding, and there'll be nothing I can do."
    else:
        doc "Your brother is going to kill him. He doesn't know when to stop."
    hank "Doc, your {b}only{/b} job is to keep him alive."
    hank "You fail me, and you'll be failing your family too. Remember that."
    scene 15_1068 with dissolve
    doc "I am not a God. I cannot perform miracles."
    doc "If you don't want this man to die today, my recommendation is to get him to a hospital as soon as possible."
    hank "Only place he's going is Hell... But not 'til I permit him."
    scene 15_1069 with dissolve
    doc "Then my hands are tied as much as his."
    doc "I've given you my professional opinion.\nIf you choose to ignore it, his fate is already sealed."
    scene 15_1070 with dissolve
    doc "I need a drink. Excuse me."
    hank "Don't go far, Doc. We'll probably be needing you again soon."
    scene 15_1071 with dissolve
    if TeddyD:
        hank "I want answers."
        scene 15_1072 with dissolve
        hank "One of these fuckers murdered my brother.\nI wanna know {b}who{/b}, and {b}where{/b}."
        hank "And goddamnit, I want his body back!"
        hank "Teddy deserves a proper burial."
    else:
        hank "Fuckin' Teddy. Never knows when to quit."
        scene 15_1072 with dissolve
        if not Nettie.isActive():
            hank "These motherfuckers need to learn that I own this town!"
            hank "I want to know who's in charge, and I want to know where they're hiding."
        else:
            hank "These motherfuckers almost killed my brother."
            hank "I want to know {b}exactly{/b} who was responsible for the attack, and where they're hiding."
    scene 15_1073 with dissolve
    hank "You {b}do not{/b} leave this place until he talks."
    hank "I don't care what you need to do, or how far you need to go."
    hank "We have plenty of tools layin' around here if you need 'em."
    scene 15_1074 with dissolve
    mc "You're not staying?"
    hank "Nah. It stinks of piss and shit in here."
    scene 15_1075 with dissolve
    mct "Great."
    scene 15_1076 with dissolve
    mc "Hey."
    mc "Can you hear me?"
    call Emotion (pri, "Groan", "", True)
    scene 15_1077 with dissolve
    pri "[whi]I've already told you everything I know.... Leave me alone.... please."
    mc "Sorry. Can't do that."
    mc "If they believed what you'd already told them... Well, I wouldn't be here right now."
    scene 15_1078 with dissolve
    pri "[whi]Why? Who the fuck are you?"
    mc "I'm the guy you never want to meet.\nI'm who they call when they want your pain to last for hours at a time."
    mc "Vacation's over, Buddy.\nShit's about to get real for you."
    scene 15_1079 with dissolve
    pri "[whi]W-Wait..."
    pri "I-I...I can't take any more!\nPlease! I'm beggin' you!"
    mc "This is your only chance to talk before I get my toolkit.\nIf I were you, I'd make it count."
    if TeddyD:
        pri "I don't know who killed your fuckin' guy!!"
        pri "If it was one of us, no one's sayin' anything! They're keepin' it quiet!"
        pri "If I knew, I'd tell you! You gotta believe me!"
    else:
        pri "That fuckin' guy... He don't listen!... He didn't care!"
        if Nettie.isActive():
            pri "It wasn't us, man! I don't know who attacked your guy!"
    scene 15_1080 with dissolve
    mc "All you've told me so far is what you {i}don't{/i} know.\nTell me the things you {b}do{/b} know."
    pri "[whi]W-What things?"
    mc "Let's start with your group."
    mc "I want to know everything..."
    scene black with Fade(3, 2, 0)
    call CenterText ("30 minutes later.")
    scene 15_1081 with Fade(0,0,2)
    mc "That's it? You sure?"
    pri "Yeah man. I swear, that's everything."
    mc "So, let me get this straight..."
    mc "You move into a town and stay a few weeks, seeking out vulnerable girls to turn into... sex slaves?"
    call Emotion (pri, "Coughing", "Yeah.")
    mc "Then you pack up and move on to the next town..."
    mc "What happens to the girls when you're on the move?"
    scene 15_1082 with dissolve
    pri "Most of them have already been sold by then."
    pri "Sometimes we take a few with us. To keep us entertained."
    pri "The bad ones... We just overdose 'em. Dump them in an alley somewhere."
    scene 15_1083 with dissolve
    mc "The {i}bad{/i} ones?"
    pri "The ones no one wanted."
    pri "Not pretty enough. Not young enough."
    pri "Some end up being more trouble than they're worth. They try to fight back."
    pri "Can't sell something that might bite off your dick."
    scene 15_1084 with dissolve
    mc "Some{b}thing{/b}?"
    scene 15_1085 with dissolve
    mc "She's someone's {b}daughter{/b}, asshole!"
    scene 15_1086 with dissolve
    play sound "punch01.mp3"
    scene 15_1087 with vpunch
    scene 15_1088 with dissolve
    scene 15_1089 with dissolve
    mc "You're a piece of fuckin' shit."
    scene 15_1090 with dissolve
    mc "You deserve everything these guys are gonna do to you."
    scene 15_1091 with dissolve
    mc "Hey!"
    mc "Damn it..."
    scene 15_1092 with dissolve
    mct "Pulse is weak... but he's still alive."
    scene 15_1093 with dissolve
    if Nettie.isActive():
        mct "... Maybe there's a way to turn this clusterfuck around."
        mct "Okay..."
        scene 15_1094 with dissolve
        mct "These assholes go to the house to get Hayley and Chloe...\nDon't know Teddy's there..."
        if TeddyD:
            mct "They have no choice but to kill him. Then they take the girls..."
            mct "Could even say {b}this{/b} was the guy who killed him."
            mct "Tell Hank where I dumped the body... That'll convince him it's the truth."
        else:
            mct "They attack him, leave him for dead and take the girls..."
        scene 15_1095 with dissolve
        mct "Risky."
        mct "If this guy tells them different... Fingers will be pointed at me..."
        mct "Unless... he can't."
        mct "Fuck."
        menu:
            "Kill him":
                $ PrisonerD=True
                scene 15_1096 with dissolve
                mct "They're gonna kill him anyway.\nAt least I can make it quick."
                scene 15_1097 with dissolve
                call Emotion (mc, "Takes a deep breath")
                play sound "neckb.mp3" volume 0.5
                scene 15_1098 with vpunch
                scene 15_1099 with dissolve
                pause 0.5
            "Leave him":
                $ PrisonerD=False
                mct "He's halfway dead already. Let them finish the job.\nGot enough blood on my hands as it is."
    else:
        mct "Got everything I need from him."
    scene 15_1100 with dissolve
    pause 0.5
    scene 15_1101 with dissolve
    mc "Where's Hank?"
    dman "You done already?"
    mc "Yeah."
    scene 15_1102 with dissolve
    dman "Wait here, I'll go get him."
    scene 15_1103 with fade1
    if not Nettie.isActive():
        mct "I hate this fuckin' town."
    else:
        mct "Hope this fuckin' works."
    scene 15_1104 with dissolve
    hank "Maybe Sue {b}was{/b} right about you after all!"
    scene 15_1105 with dissolve
    hank "You wasted no time gettin' me what I needed. I like that."
    scene 15_1106 with dissolve
    hank "You {i}did{/i} get me what I needed, right?"
    mc "Yeah."
    scene 15_1107 with dissolve
    if TeddyD:
        hank "So, where's Teddy?"
        mc "There's a quarry a few miles outside of town.\nThat's where they..."
        hank "They dumped him... like a goddamn animal?"
        mc "Yeah. Sorry."
        scene 15_1108 with dissolve
        hank "Why'd they kill him?"
        mc "The house they went to... They were there for the women, not Teddy."
        scene 15_1109 with dissolve
        mc "They didn't know he was inside.\nJust in the wrong place at the wrong time."
        mc "This group... They're sex traffickers."
        mc "They snatch girls up from the streets, drug them, turn 'em into addicts - if they weren't already - then sell them on as sex slaves."
        scene 15_1110 with dissolve
        hank "Nah. Sounds like bullshit."
        hank "He fed you a line, and you took it.\nI expected more from you."
        mc "He described to me exactly the place you'll find your brother."
        mc "Go look for yourself."
        mc "And when you find him, get your doctor to confirm that Teddy was strangled to death."
        mc "He said the girls are dead."
        hank "Which girls?"
        mc "The ones they took from the house. They tried to escape."
        hank "Good.\nThat's one less problem we need to deal with."
        mc "The asshole tied up in there, {b}HE{/b} was the one who did it."
        scene 15_1111 with dissolve
        hank "You tellin' me {b}this{/b} fuckin' guy is the one who killed my brother??"
        scene 15_1112 with dissolve
        mc "No way he'd confess if it weren't true, that's for sure."
        scene 15_1113 with dissolve
        hank "{b}MOTHERFUCKER{/b}!"
    elif Nettie.isActive():
        hank "Why'd they go after Teddy?"
        mc "They didn't."
        mc "They were there for the women, not Teddy."
        mc "He was just in the wrong place at the wrong time."
        scene 15_1108 with dissolve
        hank "What the fuck you on about?"
        mc "They didn't know Teddy was in the house."
        scene 15_1109 with dissolve
        mc "This group... They're sex traffickers."
        mc "They snatch girls up from the streets, drug them, turn 'em into addicts - if they weren't already - then sell them on as sex slaves."
        scene 15_1110 with dissolve
        hank "Nah. Sounds like bullshit."
        hank "He fed you a line, and you took it.\nI expected more from you."
        mc "Why else would they take the girls but leave Teddy?\nThey left him because they weren't interested in him."
        mc "The asshole tied up in there, {b}HE'S{/b} the one who attacked your brother."
        mc "He said the girls are dead."
        scene 15_1112 with dissolve
        hank "Which girls?"
        mc "The ones they took from the house. They tried to escape."
        hank "That's actually good news.\nOne less problem we'd need to deal with."
        scene 15_1110 with dissolve
        hank "So you tellin' me {b}this{/b} fuckin' guy's the one we've been out there lookin' for this whole goddamn time?!"
        hank "Teddy's gonna love this!"
        scene 15_1113 with dissolve
        hank "Asshole's gonna pay big time!"
    else:
        hank "So?"
        mc "They're sex traffickers."
        scene 15_1109 with dissolve
        mc "They snatch girls up from the streets, drug them, turn 'em into addicts - if they weren't already - then sell them on as sex slaves."
        scene 15_1112 with dissolve
        hank "Motherfuckers!\nThose street girls are our goddamn customers!"
        scene 15_1113 with dissolve
        hank "Assholes are gonna pay!"
    scene 15_1114 with dissolve
    scene 15_1115 with dissolve
    scene 15_1116 with dissolve
    pause 0.5
    hank "[whi]Goddamnit."
    hank "D! Go get the doc, quick!"
    scene 15_1117 with dissolve
    dman "Yes Boss!"
    scene 15_1118 with dissolve
    mc "Something wrong?"
    hank "He ain't breathin'."
    scene 15_1119 with dissolve
    hank "Looks like the doc's got his work cut out."
    hank "C'mon, we're going back to the bar."
    scene 15_1120 with dissolve
    pause 0.5
    scene 15_1121 with Fade(2, 3, 2)
    hank "That's all??\nOnly seven of 'em?"
    mc "That's what he said."
    hank "No wonder we had a hard time tryin' to find 'em!"
    scene 15_1122 with dissolve
    hank "All hidin' out under one roof."
    hank "But now we know where that is... they ain't gonna know what fuckin' hit 'em!"
    if TeddyD:
        hank "First things first though."
        mc "Yeah... Teddy."
    scene 15_1123 with fade1
    if not Nettie.isActive():
        hank "I'm gonna round up the boys.\nSure you don't wanna join us?"
        mc "Nah. I'm already running late."
        hank "Fair enough."
        hank "I'm gonna give the doc a call... make sure our boy's still alive."
        scene 15_1124 with dissolve
        hank "You still here?"
        ame "I've just finished up and was about to leave."
        hank "Okay. See you tomorrow."
    else:
        if TeddyD:
            hank "And you're {b}certain{/b} that's the spot we'll find him?"
            mc "Yeah."
        else:
            hank "I'm gonna call Teddy. Don't disappear."
        scene 15_1124 with dissolve
        hank "Keep [mc] company for a minute, Amelia."
        ame "Sure."
    scene 15_1125 with dissolve
    ame "You okay?"
    mc "Yeah."
    if EzModeActive:
        call EzModeAsk ("Amelia")
        if _return:
            $ Amelia.Add("EZ")
    scene 15_1126 with dis1
    scene 15_1127 with dis1
    ame "Where did he take you?"
    mc "Why?"
    ame "Just making conversation."
    scene 15_1128 with dissolve
    mc "Want a conversation? Cool... Let's talk about {i}you{/i}."
    mc "How long you worked here?"
    ame "Okay... Uhh, about three months."
    mc "What were you doing in Springhaven?"
    scene 15_1129 with dissolve
    ame "You just won't let it go, will you? Fine..."
    ame "Hank asked me to keep an eye on Sue.\nHe was worried Anton would do something stupid."
    ame "With everything going on down here, he had no one else to send, so I was the last resort."
    scene 15_1130 with dissolve
    ame "Within a couple of hours of me being there, Anton arrived."
    ame "I called Hank to let him know. While he was trying to figure out what to do next, you turned up."
    ame "He told me to sit tight and let it play out."
    scene 15_1131 with dissolve
    ame "And you were right... He {i}didn't{/i} ask me to follow you."
    ame "That was me."
    mc "Why?"
    ame "I don't know... Curiosity?"
    scene 15_1132 with dissolve
    ame "If you want the truth..."
    ame "It's slightly embarrassing, but... I think you're kinda cute.\nI wanted to learn more about you."
    scene 15_1133 with dissolve
    mc "Okay... Nice try."
    mc "You're still lying to me."
    mc "Confessing you think I'm {i}kinda cute{/i} to stroke my ego was a nice touch though."
    scene 15_1134 with dissolve
    mc "You didn't expect me to corner you in Springhaven, so didn't have time to come up with a decent lie - and it showed."
    mc "Same as earlier when I first walked in here - You weren't expecting me to show up - Although you should've been prepared for that."
    scene 15_1135 with dissolve
    mc "But you knew I'd be back today and want answers."
    mc "That's given you time to come up with a better story, and you have."
    mc "It's still bad, but at least it's more believable."
    scene 15_1136 with dissolve
    mc "Listen... You said this wasn't about me."
    mc "I'm gonna take you at your word.\nI'm willing to trust you {i}that{/i} much."
    mc " And if it doesn't involve me, then I'll mind my own business."
    mc "But one piece of advice, Amelia.\nThe way you're going about things - You {b}ARE{/b} going to get yourself killed."
    mc "These people are dangerous. It's not a game.\nJust do your job. Nothing more."
    scene 15_1137 with dissolve
    ame "Yeah... I know.\nIt was a stupid thing to do. It won't happen again."
    ame "I'm sorry, and thank you for keeping it between us."
    if not Nettie.isActive():
        scene 15_1138 with dissolve
        ame "My shift's over. I need to go."
        ame "Nice to see you again, [mc]."
        mc "Yeah, you too."
        scene 15_1139 with dissolve
        ame "Bye."
        mc "See ya."
        scene 15_1140 with dissolve
        mct "She's so full of shit."
        scene 15_1141 with dis1
        mct "Fuck it... Let's see how {b}she{/b} likes being followed..."
        scene 15_1142 with dis1
        scene 15_1143 with dis1
        scene 15_1144 with dis1
        jump CedarGrove_04_FollowAmelia
    scene 15_1145 with dissolve
    if TeddyD:
        hank "It's gonna take a while searchin' that whole area."
        scene 15_1146 with dissolve
        hank "I don't want you leavin' town yet."
        hank "If they don't find Teddy, you're gonna need to talk to our friend some more."
    else:
        hank "The boys are gettin' ready."
        scene 15_1146 with dissolve
        hank "Don't know why you don't wanna come with us, but I'll respect it."
        hank "You ain't leavin' town yet though."
        hank "If they're not where you said, you're gonna need to talk to our friend some more."
    scene 15_1147 with dissolve
    if PrisonerD:
        mc "Uhh...Yeah... Sure."
    mc "You think the doctor managed to revive him?"
    hank "For his sake, he'd better have."
    scene 15_1148 with dissolve
    hank "Sure you got better things to do than hang around here.\nI'll call you when it's done."
    mc "Okay."
    scene 15_1149 with dis1
    scene 15_1150 with dis1
    ame "Doctor?"
    mc "Yeah. Why?"
    ame "Uhh... no reason... You look healthy... Is everything okay?"
    mc "I wasn't the patient."
    scene 15_1151 with dissolve
    ame "Who was?"
    mc "Jesus. Stop asking questions that don't concern you, Amelia."
    scene 15_1152 with dissolve
    mc "You're gonna find yourself in a whole world of trouble if you keep it up."
    mc "Hank's right. I {b}do{/b} have better things to do than hang out here."
    scene 15_1153 with dissolve
    mc "Guess I'll see you later."
    ame "Yeah."
    scene 15_1154 with dissolve
    mct "What the hell is her game?"
    scene 15_1155 with dissolve
    mct "Wanted to call in on Nettie while I'm here... Now's as good a time as any."
    mct "Just make sure Amelia ain't following me again first."
    jump CedarGrove_04_VisitNettie
return

label CedarGrove_04_VisitNettie:
    scene 15_1156 with Fade(2,3,2)
    pause
    scene 15_1157 with fade1
    mc "You look... nice!"
    liz "The word you're looking for is {i}ridiculous{/i}."
    scene 15_1158 with dissolve
    liz "I look like I should be standing on a street corner!\nBut what can I say? Beggars can't be choosers."
    mc "Stop it. You look great!"
    scene 15_1159 with dissolve
    liz "Hah! Now we're {b}both{/b} exaggerating!"
    liz "Let's just say I'm not used to wearing these types of clothes."
    scene 15_1160 with dissolve
    mc "Believe what you want, but {b}I{/b} wasn't exaggerating!"
    scene 15_1161 with dissolve
    mc "Nettie not around?"
    liz "Yeah, she's upstairs with Hayley."
    scene 15_1162 with dissolve
    mc "Everything okay?"
    liz "Yeah..."
    scene 15_1163 with dissolve
    liz "Hayley tried to leave this morning, but Nettie wouldn't let her out."
    mc "Where did she want to go?"
    liz "I'm not sure. Probably nowhere in particular.\nWe're all just going stir-crazy being stuck in here."
    scene 15_1164 with dissolve
    liz "Every day here is harder than the last."
    liz "We're all at breaking point, so it doesn't take a lot for something to tip us over the edge."
    scene 15_1165 with dissolve
    mc "I don't think you'll need to worry about it for much longer."
    liz "Why? Have you heard something?"
    mc "Maybe... I need to talk to Nettie; is it okay if I go up?"
    liz "Yeah, they're in Hayley's room."
    scene 15_1166 with dissolve
    chlo "[mc]!"
    scene 15_1167 with dissolve
    scene 15_1168 with dissolve
    chlo "Hi! When did you get here?!"
    mc "Hey! About two minutes ago."
    scene 15_1169 with dissolve
    liz "Jeez, Chloe! He {b}just{/b} got here!\nGive him a chance to say hello to everyone before you demand all his attention!"
    scene 15_1170 with dissolve
    chlo "What's got your panties in a bunch?!"
    scene 15_1171 with dissolve
    mc "Okay... Take it easy. She was just sayin' hello."
    scene 15_1172 with dissolve
    liz "She's always so miserable and grumpy! Refuses to even talk to us most of the time!"
    liz "But as soon as {b}you{/b} walk in... it's all happiness and hugs!"
    chlo "Because he's the only one that doesn't yell at me!!"
    scene 15_1173 with dissolve
    liz "I've {b}never{/b} yelled at you!!"
    mc "You're yelling at her {i}now{/i}, Elizabeth."
    liz "No! I'm..."
    scene 15_1174 with dissolve
    call Emotion (liz, "Sigh", "", True)
    mc "At breaking point.\nAs you said, you {b}all{/b} are."
    liz "[whi]Damn it."
    scene 15_1175 with dissolve
    liz "Chloe, I'm so sorry."
    liz "I didn't mean to snap at you.\nI don't know how much more of this I can take."
    scene 15_1176 with dissolve
    mc "Chloe?"
    scene 15_1177 with dissolve
    pause 0.5
    scene 15_1178 with dissolve
    chlo "I'm sorry, too.\nI'm trying my best not to be grumpy, but this place is driving me nuts."
    scene 15_1179 with dissolve
    liz "I know. We're all feeling it, Honey."
    scene 15_1180 with dissolve
    liz "We're going to get through this. All of us, together."
    chlo "[whi]Okay."
    scene 15_1181 with dissolve
    mc "Damn... Can I get in on this too?"
    scene 15_1182 with dissolve
    mc "Niiiice."
    scene 15_1183 with dissolve
    liz "Excuse me, I need to go lie down for a while."
    mc "You okay?"
    liz "Yes. Just a migraine."
    scene 15_1184 with dissolve
    chlo "[whi]She gets them all the time."
    scene 15_1185 with dissolve
    chlo "I'm so happy you're here!"
    chlo "Are you staying over again?"
    mc "Nah. This is just a quick visit to check in with you guys."
    scene 15_1186 with dissolve
    chlo "Seriously?\nThat sucks."
    mc "Yeah, I know. Sorry."
    if Chloe.isActive():
        mc "Keeping up with your exercise routine?"
        scene 15_1187 with dissolve
        chlo "Yeah!\nOnly because there's literally nothing else to do here."
        chlo "You still going to teach me how to beat someone up?"
        mc "That's {i}not{/i} what I said!"
        scene 15_1188 with dissolve
        chlo "Fine... {i}Self-defense{/i}!"
        mc "Better.\nAnd yes, if you still want me to."
        chlo "Of course I do!"
        mc "Okay. If you're up for it, I can show you one or two techniques before I leave today."
        scene 15_1189 with dissolve
        chlo "Hell yeah!"
        scene 15_1190 with dissolve
        mc "I need to talk with Nettie first, and you should probably get changed."
        chlo "Good call.\nDon't want to get your blood all over my awesome new clothes!"
        call laugh (mc, "Right.")
        scene 15_1191 with dissolve
        mc "You {b}do{/b} look fantastic, by the way!"
        chlo "Thanks to you!"
        scene 15_1192 with dissolve
        mc "I'll go find Nettie.\nI'll meet you in your room when I'm done."
        chlo "Cool. Looking forward to it."
    else:
        scene 15_1192 with dissolve
        mc "Need to have a chat with Nettie.\nShe still in your mom's room?"
        chlo "I have no idea."
    call CedarGrove_04_HayleyTalk
    call CedarGrove_04_NettieTalk
    if Chloe.isActive():
        call CedarGrove_04_ChloeTraining
    call CenterText ("A short time later.")
    scene 15_1452 with Fade(0,0,2)
    mct "Hope we can find a better way to do this."
    play sound "vib.mp3"
    mct "Even if she agrees, having Hayley be a witness {b}has{/b} to be our last resort."
    stop sound
    scene 15_1453 with dissolve
    mc cell "Hello?"
    ame cell "Hi [mc], it's Amelia."
    ame cell "Hank asked me to call you. He wants you back here."
    if PrisonerD:
        ame cell "He's not happy about something."
    mc cell "Okay. I'm on my way."
    if Chloe.isSexual():
        scene 15_1454 with dissolve
        pause 0.5
        scene 15_1455 with dis1
        chlo "Cool, you're still here."
        play sound "text.mp3"
        mc "I was just leaving."
        scene 15_1456 with dissolve
        chlo "That message you just got, it's from me.\nI sent you some of those photos."
        $ i=10
        call AddGaleryItem ("chlo_09")
        while i<15:
            call AddGaleryItem ("chlo_"+str(i))
            $ i+=1
        $ renpy.notify("Pictures have been added to your gallery.")
        mc "Great! Thanks.\nLooking forward to seeing them again."
        scene 15_1457 with dissolve
        chlo "{i}Seeing{/i} them?"
        mc "{b}Using{/b} them."
        chlo "That's better."
        scene 15_1458 with dissolve
        chlo "I love that you're looking at {b}me{/b} when you masturbate."
        chlo "It makes me feel so special that I don't even care that it's weird anymore."
        scene 15_1459 with dissolve
        chlo "And if you want to know a secret... I think of you when I do it, too."
        chlo "But it was {b}so{/b} much nicer when {i}you{/i} did it to me."
        scene 15_1460 with dissolve
        chlo "I've been thinking..."
        chlo "Maybe, next time... We can do each other?"
        scene 15_1461 with dissolve
        mc "I'd like that."
        chlo "Me too."
        mc "[whi]Is everyone still upstairs?"
        chlo "[whi]Yeah. In their rooms."
        scene 15_1462 with dissolve
        mc "[whi]Good.\nI didn't want to leave before kissing you again."
        scene 15_1463 with dis1
        chlo "[whi]Mmhh."
        scene 15_1464 with dissolve
        pause
        scene 15_1465 with dissolve
        chlo "[whi]Mmhhhh."
        scene 15_1466 with dissolve
        mc "I'll see you in a few days."
        chlo "Yeah, okay."
    jump CedarGrove_04_BacktoBar
return

label CedarGrove_04_HayleyTalk:
    scene 15_1361 with fade1
    hay "[whi]You're just repeating the same thing over and over!"
    net "[whi]If you listened, I wouldn't need to keep repeating myself!"
    scene 15_1362 with dissolve
    play sound "knock.mp3"
    mct "Damn. Chose the wrong day to visit!"
    scene 15_1363 with dissolve
    scene 15_1364 with dissolve
    net "We're trying to keep you safe!\nThis isn't a punishment, Hayley!"
    hay "Really? Because it damn well feels like it!"
    mc "Hey."
    scene 15_1365 with dissolve
    net "[mc]! What are you doing here?"
    scene 15_1366 with dissolve
    mc "What's goin' on?"
    hay "I'm being held here against my will!"
    scene 15_1367 with dissolve
    net "ARE YOU KIDDING ME?!"
    scene 15_1368 with dissolve
    net "I can't deal with this!"
    scene 15_1369 with dissolve
    mc "Nettie..."
    hay "Just let her go!"
    hay "Probably wants to put more padlocks on the doors!"
    scene 15_1370 with dissolve
    call Emotion (hay, "Sigh", "Goddamnit.")
    mc "You okay?"
    scene 15_1371 with dissolve
    hay "I know she's just trying to help..."
    hay "... And she's doing the best she can."
    mc "But she's driving you crazy?"
    scene 15_1372 with dissolve
    hay "Yes!"
    hay "She's meant to be my friend, not my prison guard!"
    mc "Where did you want to go this morning?"
    scene 15_1373 with dissolve
    hay "Nowhere. {i}Anywhere{/i}."
    hay "Just a walk. To clear my head."
    scene 15_1374 with dissolve
    hay "These damn walls... I feel like they're constantly closing in on me."
    hay "I just wanted to go outside and breathe some fresh air!"
    scene 15_1375 with dissolve
    mc "Yeah... I get it, I do."
    mc "But... I get the feeling it's more than that."
    scene 15_1376 with dissolve
    mc "C'mon, what's {i}really{/i} bothering you?"
    hay "There's nothing--"
    scene 15_1377 with dissolve
    call Emotion (hay, "Sigh", "", True)
    scene 15_1378 with dissolve
    hay "Why hasn't he done anything yet??"
    hay "He hasn't even been to the church!\nWhat the hell is he waiting for??"
    hay "He's up to something, [mc], and it's scaring the shit out of me!"
    scene 15_1379 with dissolve
    mc "Okay..."
    mc "Teddy... He hasn't done anything because...\nHe isn't looking for you."
    mc "They believe you're both already dead."
    hay "[whi]What?"
    scene 15_1380 with dissolve
    hay "Dead?? Why would they think {i}that{/i}?"
    hay "... And, how... How can you know that??"
    scene 15_1381 with dissolve
    mc "Hank heard about a group of sex traffickers who are operating around here."
    mc "He thinks {b}they're{/b} responsible for the attack on Teddy that night - and they took you and Chloe."
    mc "All they care about is revenge."
    scene 15_1382 with dissolve
    hay "I don't...\nWhy? Why would they think that??"
    hay "Teddy knows what happened! He tried to shoot us as we ran out!"
    if TeddyD:
        menu:
            "Tell her the truth about Teddy":
                $ Hayley.Add("Knows")
                scene 15_1383 with dissolve
                mc "Hayley, Teddy's dead."
                mc "That night... He left me no choice. I had to."
                scene 15_1384 with dissolve
                call Emotion (hay, "GASP")
                scene 15_1385 with dissolve
                hay "He... ... {i}You{/i} killed him?"
                mc "Yeah... [whi]Sorry."
                scene 15_1386 with dissolve
                hay "Oh my god, [mc]! I don't think you realize what you've done!\nIf Hank ever finds out..."
                scene 15_1387 with dissolve
                mc "Relax.\nHank already has the guy he believes killed his brother."
                mc "Everything's gonna be okay."
                scene 15_1388 with dissolve
                hay "How can you say that??\nYou don't know him! You have no idea!"
            "Don't say anything":
                scene 15_1383 with dissolve
                mc "The day I got you out of that house - Teddy went missing.\nNobody's seen him."
                mc "Hank put two and two together and came up with the sex ring theory."
                hay "Went missing??"
    else:
        scene 15_1383 with dissolve
        mc "He was drunk.\n{i}So drunk{/i} that he probably couldn't remember what happened to him."
        mc "He made up some bullshit story about being attacked to his brother."
        mc "Hank put two and two together and assumed it was the sex ring guys."
    scene 15_1389 with dissolve
    hay "Wait..."
    hay "How the hell do you know so much??"
    scene 15_1390 with dissolve
    mc "It's... complicated."
    mc "I need to explain it all to Nettie first.\nShe can fill you all in later."
    scene 15_1391 with dissolve
    hay "Okay.\nYou've done more than enough to earn my trust, so I'm not gonna start doubting you now."
    scene 15_1392 with dissolve
    hay "So... Does this mean we're {b}free{/b}?! We can leave?"
    scene 15_1381 with dissolve
    mc "No.\nThis means there's light at the end of the tunnel."
    mc "I know things are difficult, but I need you to hang in there for a little while longer."
    scene 15_1393 with dissolve
    mc "You still need to keep a low profile. If they find out you're alive..."
    hay "Yes, you're right.\nWe can't let that happen."
    hay "We'll stay here - for as long as it takes."
    mc "And you'll be okay with that?"
    scene 15_1394 with dissolve
    hay "Why? Because I just had a mini breakdown for the same reason?"
    mc "Well... Yeah."
    scene 15_1395 with dissolve
    hay "Yeah, I'll be fine.\nIt wasn't being trapped in here that got to me. It was the {i}not knowing{/i}."
    hay "I'd convinced myself Teddy was planning something awful, and I've been waiting for it to happen."
    scene 15_1396 with dissolve
    hay "The fear just kept growing the more I sat around waiting."
    hay "It's all I could think about. All day, every day."
    scene 15_1397 with dissolve
    hay "But what you're saying... I... I can stop being afraid."
    hay "I don't need to worry that he's going to burst through the door at any second."
    scene 15_1398 with dissolve
    hay "For the first time, I {i}really believe{/i} we're gonna make it through this!"
    scene 15_1399 with dissolve
    hay "Come on, you deserve the biggest hug!"
    mc "Uhh... okay."
    scene 15_1400 with dissolve
    hay "God, I can't believe it's almost over!"
    hay "I'm so happy and relieved!!"
    scene 15_1401 with dissolve
    hay "And if I wasn't in my underwear right now... I'd kiss you!"
    $ tCh=Hayley.Has("EZ")
    if not EzModeActive:
        menu:
            "Yeah, don't do that [wk_c]":
                $ tCh=False
            "[wk_y]Don't let that stop you":
                $ tCh=True
    if tCh:
        mc "Don't let that stop you!"
        scene 15_1402 with dissolve
        hay "[lol]"
        scene 15_1403 with dissolve
        hay "You know I was joking, right?\nIsn't a hug reward enough?"
        mc "Yeah, of course."
        mc "But a kiss would be {i}even{/i} better."
        scene 15_1404 with dissolve
        hay "{i}Oh really{/i}?"
        mc "Yep."
        scene 15_1405 with dis1
        hay "Well, you {i}are{/i} my hero.."
        scene 15_1406 with dis1
        hay "..and it'd be rude of me not to kiss my hero if that's what he wants..."
        scene 15_1407 with dis1
        hay "[whi][kiss]"
        scene 15_1406 with dis1
        pause 0.5
        scene 15_1408 with dis1
        hay "[whi]Mmh."
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e15/15_1409.webp", 1005, 627, Hayley.hasScore(1), "CedarGrove_AF08") with dissolve
            pause
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 15_1409
                hide screen imgMap
                scene 15_1414 with dissolve
                mc "Yeah, much better than a hug!"
                hay "Agreed!"
        else:
            scene 15_1409 with dissolve
            pause 0.5
            $ t=(wk_y if Hayley.hasScore(1) else wk_n)+"Slide your hand down"
            if not EzModeActive:
                menu:
                    "[t]":
                        call CedarGrove_AF08
                    "Don't":
                        scene 15_1414 with dissolve
                        mc "Yeah, much better than a hug!"
                        hay "Agreed!"
            elif Hayley.Has("EZ"):
                call CedarGrove_AF08
    else:
        mc "Yeah, don't do that."
        call CloseCharacterPath (Hayley, "Hayley")
        scene 15_1402 with dissolve
        hay "[lol]"
        scene 15_1414 with dissolve
        hay "You know I was teasing, right?"
        mc "Heh, yeah."
    scene 15_1420 with dissolve
    mc "Okay... Nettie should've calmed down a little by now."
    hay "Good luck.\nI owe her an apology. I'm hoping you can soften her up a bit first."
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
