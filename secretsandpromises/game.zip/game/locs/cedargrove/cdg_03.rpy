label CedarGrove_04_NettieTalk:
    scene 15_1421 with fade1
    play sound "knock.mp3"
    pause 0.5
    scene 15_1422 with dis1
    mc "Nettie?"
    scene 15_1423 with dissolve
    mc "Can I come in?"
    net "[whi]Yeah."
    scene 15_1424 with dis1
    scene 15_1425 with dis1
    mc "If it's any consolation, you made the right call not letting her leave."
    net "Yeah.\nDoesn't make me feel any better, though."
    scene 15_1426 with dissolve
    net "And she has a point, [mc]!"
    net "Who the hell am I to tell her what she can or can't do?!"
    scene 15_1427 with dissolve
    mc "You're the one who's trying her damn best to keep everyone safe."
    mc "And you're doing a great job.\nWithout you... who knows what would've happened to them by now."
    scene 15_1428 with dissolve
    net "Keeping them safe from what exactly?"
    net "The way she always spoke about Teddy...\nHe sounded like a monster. Someone people {b}should{/b} be afraid of."
    scene 15_1429 with dissolve
    net "But Father David hasn't heard or seen a thing!\nCommon sense says that the church is the {b}first{/b} place Teddy would go to look for us!"
    net "So, I don't know... maybe... he isn't the threat she's made him out to be?"
    scene 15_1430 with dissolve
    mc "Nettie, you know that's not true."
    mc "You saw it for yourself.\nWhy do you think he had a gun that day?"
    scene 15_1431 with dissolve
    net "He could've just moved on?\nFound himself another girlfriend to abuse!"
    net "Men like that... They seem to have a built-in radar to detect vulnerable women!"
    net "Maybe there's no reason to keep hiding."
    scene 15_1432 with dissolve
    mc "There is."
    mc "Nettie, it's time I told you the truth about what's been going on with me."
    mc "When I delivered Pete's letter to Alison..."
    scene black with Fade(4, 2, 2)
    call CenterText ("You tell Nettie the whole story...")
    scene 15_1433 with Fade(0,0,3)
    if TeddyD:
        net "If you say you had no choice but to kill Teddy, then I believe you."
        net "I wish you'd trusted me enough to tell me straight away.\nThat's a lot for one person to carry."
        scene 15_1434 with dissolve
        mc "That wasn't the reason I didn't tell you, Nettie.\nI didn't want to implicate you... and, well... your faith..."
        mc "To be honest, I was scared that you'd think differently of me."
        net "That would never happen, [mc]."
        net "I know you. You're a good man."
        net "I don't believe for a single moment that you would take a life without good reason."
        scene 15_1433 with dissolve
    net "My brother's been dead all this time, and yet he continues to wreck people's lives."
    mc "You can't blame Pete for this, Nettie. Not all of it."
    scene 15_1435 with dissolve
    mc "When Alison told me about the threats to her and Cara, it made my blood boil."
    mc "It was my choice, no one else's."
    net "I wouldn't expect you {b}not{/b} to react that way!\nOf course you would; they threatened your daughter!"
    net "But if Pete hadn't borrowed money from them to begin with..."
    scene 15_1436 with dissolve
    mc "I know what you're saying; if he hadn't taken it, none of this would've happened."
    mc "But, I have money.\nThe cash from selling my mom's house would've covered the debt."
    mc "I should've just paid it off and walked away.\nAnd if it meant keeping Cara safe, I would've given them every damn cent I had."
    scene 15_1437 with dissolve
    net "So why didn't you?"
    mc "I didn't want them to win."
    mc "And I didn't {i}really{/i} believe everything that Alison was telling me about Pete."
    mc "I couldn't wrap my head around it.\nCouldn't see how he would do that."
    mc "There had to be another reason for it, and I wanted to find out what."
    scene 15_1438 with dissolve
    mc "But then I came here, to find you."
    mc "When you told me... my world came crashing down."
    mc "I was the only person who hadn't seen it.\nThe only one who didn't see Pete for what he really was."
    mc "I felt like a goddamn idiot."
    scene 15_1439 with dissolve
    mc "I should've believed you {b}straight away{/b}. I should've believed Alison straight away."
    mc "This mess is my own doing."
    mc "But it's already gone too far; there's no backing out now. I have to see it through."
    scene 15_1440 with dissolve
    net "And the police officer..."
    mc "Alysha."
    net "Do you really think she can bring them to justice?"
    mc "With the right help, yeah."
    net "The right help?"
    scene 15_1437 with dissolve
    mc "She's just a city cop.\nWe need someone with more authority."
    mc "She's looking. Just has to be careful about it.\nI trust her. She {b}will{/b} find the person we need."
    mc "And when she does..."
    scene 15_1441 with dissolve
    mc "That's where Hayley could help us."
    net "Hayley? How?"
    mc "She told me herself how she's seen them do some horrible things."
    mc "She'd make the perfect witness."
    scene 15_1442 with dissolve
    net "You want her to testify??\nGiven everything you've just told me..."
    mc "Yeah, I know."
    net "Wait.. Does she know all this? Has she agreed??"
    mc "No, I haven't asked her yet.\nI thought it might be better coming from you."
    scene 15_1443 with dissolve
    net "Why me??"
    mc "Because you're right - it {b}is{/b} dangerous.\nIt has to be {b}her{/b} decision."
    mc "If I ask her, she might feel pressured into it, and I don't want that."
    mc "I'm not asking you to convince her, Nettie."
    scene 15_1441 with dissolve
    mc "Just talk to her, see how she'd feel about it."
    mc "If she refuses, I won't hold it against her.\nHell, I wouldn't even blame her. It's a big ask."
    mc "In the meantime, if we can find another way, we will."
    scene 15_1444 with dissolve
    net "I can talk to her about it, [mc], but I need to be honest with you..."
    net "If she asks for my opinion, I'll have to advise her {b}against{/b} it."
    net "She's trying to escape from all this.\nIf they think she's dead, she should keep it that way."
    scene 15_1445 with dissolve
    mc "Honestly, it's hard to argue with that, because you're absolutely right."
    mc "If I were in your shoes, I'd be telling her the same thing, and if that's what she decides, I'll respect it."
    scene 15_1446 with dissolve
    net "Damn, this is a lot to take in."
    mc "Yeah, I know."
    net "I need to lie down for a while. I need to process everything you just told me."
    mc "Okay."
    scene 15_1447 with dissolve
    net "Maybe we can talk more later?"
    mc "I'm not staying over. I'll need to get back soon."
    mc "Just wanted to come by and make sure you guys were doin' okay while I was in town."
    net "Oh, okay."
    scene 15_1448 with dissolve
    mc "I'll come back in a few days. We can talk then."
    net "Yeah."
    scene 15_1449 with dissolve
    net "Please be careful, [mc].\nThe things Hayley's told me about Teddy and his brother truly are awful."
    mc "Don't worry, I'll be fine."
    scene 15_1450 with fadehold
    pause 0.5
    scene 15_1451 with dis1
    pause 0.5
    scene black with Fade(3,2,0)
return

label CedarGrove_04_ChloeTraining:
    $ ExtChl=False
    python:
        for pic in Gallery_items:
            if pic.thumb=="thumbs/gal/chlo_01_t.jpg" and TeddyD and Chloe.Has("Knows"): ExtChl=True
    play sound "knock.mp3"
    scene 15_1193 with Fade(0,0,1)
    pause 0.5
    chlo "[whi]Come in."
    scene 15_1194 with dissolve
    pause 0.5
    scene 15_1195 with dissolve
    chlo "I was starting to think you'd changed your mind."
    mc "C'mon, you know me better than that!"
    scene 15_1196 with dissolve
    mc "Ready?"
    chlo "To beat you up? Yep!"
    scene 15_1197 with dissolve
    chlo "[mc], I just wanted to say... Thanks."
    mc "For what?"
    chlo "You know, everything."
    scene 15_1198 with dissolve
    mc "My pleasure."
    $ tCh=Chloe.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Compliment her outfit":
                $ tCh=True
            "Say nothing":
                $ tCh=False
    if tCh:
        scene 15_1199 with dissolve
        mc "Love the outfit choice!"
        scene 15_1200 with dissolve
        chlo "You do?"
        scene 15_1201 with dissolve
        if ExtChl:
            chlo "I thought you might."
        else:
            chlo "Thanks. You paid for it!"
            mc "Worth every cent!"
    if Chloe.Has("Knows"):
        scene 15_1467 with dissolve
        mc "Listen... Before we begin..."
        $ dia= "I just told Nettie"+(" and your mom" if Hayley.Has("Knows") else "")+" about Teddy."
        mc "[dia]"
        chlo "Oh my god! You did??"
        $ dia= ("They" if Hayley.Has("Knows") else "She")+" might talk to you about it later. If "+("they do" if Hayley.Has("Knows") else "she does")
        mc "[dia]... act surprised. Don't let on that you already knew."
        chlo "Uhh, yeah, of course."
    scene 15_1202 with dissolve
    mc "Okay, Let's get started!"
    chlo "Cool."
    scene 15_1203 with Fade(1,2,1)
    chlo "GRRRR!"
    mc "Good!\nGet right under the chin."
    scene 15_1204 with dissolve
    mc "That's it. Push me back {b}hard{/b}."
    scene 15_1205 with Fade(1,2,1)
    chlo "{b}NNGGGGGHHH!{/b}"
    mc "HARDER!"
    scene 15_1206 with dissolve
    mc "If I can talk... I can breathe!"
    mc "Give me more!"
    scene 15_1207 with dissolve
    chlo "{b}AAAAHHHHHHGG!{/b}"
    scene 15_1208 with dissolve
    mc "[whi]Okay... okay."
    scene 15_1209 with dissolve
    chlo "God, I'm sorry! Was that too much?"
    mc "No! You did great!"
    scene 15_1210 with dissolve
    call Emotion (mc, "Phew")
    chlo "You okay?"
    scene 15_1211 with dissolve
    mc "Yeah!\nJust getting warm in here."
    mc "Right... This next one is--"
    scene 15_1212 with dissolve
    chlo "Take your T-shirt off if you're hot!"
    mc "Nah, it's fine."
    scene 15_1213 with dissolve
    chlo "[mc], you're sweating! Just take it off!"
    scene 15_1214 with dis1
    scene 15_1215 with dis1
    scene 15_1216 with dis1
    chlo "Admit it... That's better, right?"
    mc "It is, yeah."
    scene 15_1217 with dissolve
    chlo "[whi]Daaamn."
    mc "Hey..."
    scene 15_1218 with dissolve
    mc "Eyes up here young lady."
    chlo "[lol]"
    scene 15_1219 with dissolve
    mc "Okay... C'mon, back to work."
    scene 15_1220 with Fade(1,2,1)
    mc "YES! GOOD!"
    scene 15_1221 with dissolve
    mc "If you find yourself in this position, you push those thumbs into the eyeballs - as hard and deep as you can."
    mc "You DO NOT hesitate, got it?"
    chlo "Got it."
    scene 15_1222 with Fade(1,2,1)
    mc "Perfect!"
    scene 15_1223 with dissolve
    mc "And remember, speed is just as important as power here.\nBring your knee up as fast as you can."
    chlo "Okay."
    chlo "Quick question..."
    scene 15_1224 with dissolve
    chlo "Will my attacker always be holding on to my ass like that?"
    scene 15_1225 with dissolve
    mc "Well... You should always expect the unexpected!"
    mc "But, yeah... It's a {b}damn fine{/b} ass, so they'll probably want to!"
    scene 15_1226 with dissolve
    chlo "[lol]"
    scene 15_1227 with dissolve
    mc "Alright, let's call it a day before you put me in the hospital."
    chlo "This has been great.\nI've had a lot of fun, thank you."
    scene 15_1228 with dissolve
    chlo "Will you keep teaching me this stuff?\nIt makes me feel so much better!"
    mc "Be happy to."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e15/15_1229.webp", 880, 513, True, "CedarGrove_AF07") with dissolve
        chlo "Thanks again, [mc]. You're the best."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 15_1229
            hide screen imgMap 
    else:
        scene 15_1229 with dissolve
        chlo "Thanks again, [mc]. You're the best."
        if not EzModeActive:
            menu:
                "[wk_y]Grab her butt":
                    call CedarGrove_AF07
                "Don't":
                    pass
        elif Chloe.Has("EZ"):
            call CedarGrove_AF07
    if not Chloe.Has("Ext"):
        scene 15_1230 with dissolve
        mc "Okay, I'm outta here.\nKeep practicing those moves."
        chlo "I will!"
        scene 15_1231 with dissolve
        mc "Just, please... {b}NOT{/b} on Sister Elizabeth!"
        chlo "[lol]"
        return
    $ Chloe.Del("Ext")
    mc "You know I'm gonna, right?"
    scene 15_1232 with dissolve
    chlo "Are you asking for permission?"
    mc "Well... I just showed you how to kick my ass, so... Yeah."
    scene 15_1233 with dissolve
    chlo "[lol]"
    scene 15_1234 with dissolve
    chlo "Go ahead."
    scene 15_1235 with dissolve
    mc "[whi]Thanks."
    scene 15_1236 with dis1
    scene 15_1237 with dis1
    mc "[whi]Damn."
    scene 15_1238 with dissolve
    pause
    scene 15_1239 with dissolve
    if ExtChl:
        chlo "[whi]God, I love your visits."
        mc "[whi]Me too."
    else:
        chlo "[whi]This is nice."
        mc "[whi]Yeah."
    scene 15_1240 with dissolve
    $ aPs(0, True)
    scene 15_1241 with dis1
    mc "[whi][kiss]"
    scene 15_1242 with dis1
    $ aPs()
    scene 15_1243 with dis1
    mc "[whi][kiss]"
    scene 15_1244 with dis1
    $ aPs()
    scene 15_1245 with dis1
    mc "[whi][kiss]"
    scene 15_1246 with dis1
    $ aPs()
    scene 15_1247 with dissolve
    mc "[whi][kiss]"
    scene 15_1248 with dis1
    $ aPs(0, False, True)
    scene 15_1249 with dis1
    mc "[whi][kiss]"
    scene 15_1250 with dis1
    mc "[whi]Sorry.\nI know I shouldn't do that."
    chlo "[whi]What if I like you doing it?"
    chlo "[whi]What if I want you to carry on?"
    scene 15_1251 with dis1
    mc "[whi][kiss]"
    scene 15_1252 with dis1
    $ aPs()
    scene 15_1253 with dis1
    chlo "[whi]Mmhhh."
    scene 15_1254 with dissolve
    chlo "[whi]Mhhh."
    scene 15_1255 with dissolve
    chlo "[whi]Mmhhh."
    scene 15_1256 with dissolve
    chlo "[whi]Mhhh."
    if not ExtChl:
        scene 15_1257 with dissolve
        chlo "Sorry, I really need to go and take a shower."
        mc "Yeah... I need to get going soon too."
        chlo "I'm already looking forward to our next lesson."
        mc "Me too."
        mc "[whi]Okay..."
        scene 15_1230 with dissolve
        mc "I'm outta here.\nKeep practicing those moves."
        chlo "I will!"
        scene 15_1231 with dissolve
        mc "Just, please... {b}NOT{/b} on Sister Elizabeth!"
        chlo "[lol]"
        return
    $ persistent.ChloeRP01Dat=True
    call ChloeReplay01
return

label CedarGrove_04_BacktoBar:
    scene black with Fade(2,3,0)
    play music "barbgm.mp3" loop fadein 2.0 volume .3
    if not TeddyD:
        scene 15_1469 with Fade(0,0,2)
        mct "This doesn't look good..."
        scene 15_1470 with dissolve
        hank "All I'm sayin' is, you didn't need to turn it into a bloodbath, Teddy!"
        ted "They got what was comin'! Fuck 'em!"
        scene 15_1471 with dissolve
        hank "You're here, good."
        scene 15_1472 with dissolve
        hank "Everythin' he told us checked out."
        hank "It's done. We've got guys over there right now cleaning up the mess."
        scene 15_1473 with dissolve
        hank "Boys, give us a minute."
        scene 15_1474 with dissolve
        hank "You too, Teddy."
        ted "What?! Why??"
        scene 15_1475 with dissolve
        ted "This is bullshit!"
        hank "Teddy, c'mon."
        scene 15_1476 with dissolve
        ted "Fuck you, Hank! I'm outta here!"
        scene 15_1477 with dissolve
        hank "Take a seat."
    else:
        scene 15_1468 with Fade(0,0,2)
        mct "This doesn't look good..."
        scene 15_1479 with dissolve
        rud "He's here, Boss."
        hank "'Bout damn time."
        scene 15_1480 with dissolve
        hank "We found him."
        hank "Right where you said he'd be."
        scene 15_1481 with dissolve
        hank "At least now... I know, with certainty."
        hank "And we can bury him.\nGive him the send-off he deserves."
        scene 15_1482 with dissolve
        hank "Boys, give us a minute."
        scene 15_1483 with dis1
        scene 15_1484 with dis1
        hank "Take a seat."
    scene 15_1478 with dissolve
    hank "You done good today."
    hank "I take notice when one of my guys steps up."
    scene 15_1485 with dissolve
    hank "It was impressive how you got him to tell you everything."
    hank "D told me the guy didn't even scream once, so how did you do it?"
    mc "You'd already broken him."
    scene 15_1486 with dissolve
    mc "I didn't need to inflict any more pain."
    mc "I just needed him to think he was about to go through the worst pain imaginable."
    mc "The fear of something like that is more frightening than the reality."
    scene 15_1487 with dissolve
    hank "Nah, I call bullshit."
    hank "I find that hard to believe."
    mc "Think about it!\nHe would've blacked out within two minutes if I'd started hurting him."
    scene 15_1488 with dissolve
    mc "And I bet he didn't piss in his pants when your guys were workin' him."
    mc "He pissed himself when he was alone, thinking about what's gonna happen to him next."
    mc "Dread filled him."
    scene 15_1489 with dissolve
    hank "Well, whatever you did - it worked, so can't argue with ya, can I?"
    hank "Still think it's bullshit though."
    scene 15_1490 with dissolve
    hank "Not like we can ask him either since the fucker's dead."
    mc "... The doctor couldn't revive him?"
    if PrisonerD:
        scene 15_1491 with dissolve
        hank "Useless prick."
        hank "Said the asshole's heart just gave up. Nothin' he could do about it."
        hank "Maybe I'll tell the good doctor what we plan on doin' to his family."
        scene 15_1492 with dissolve
        hank "Let him stew on it a while. See if your theory about fear is right."
        if not TeddyD:
            hank "I ain't told Teddy yet.\nHe won't be too pleased, I can tell ya!"
            hank "He's already made enough goddamn mess for one day. He can have the doc some other time."
    else:
        hank "No, he did."
        scene 15_1491 with dissolve
        if not TeddyD:
            hank "Until I told Teddy that {b}he{/b} was the guy we've been lookin' for."
            scene 15_1492 with dissolve
            hank "Teddy stormed in, blew his damn head clean off while the doc was workin' on him."
        else:
            hank "Wanted my pound of flesh.\nFucker killed my brother, what else was I gonna do?"
    scene 15_1493 with dissolve
    ame "Okay, I'm done for the day, Hank.\nIf it's okay with you, I'll get out of here."
    hank "Yeah, fine."
    scene 15_1494 with dissolve
    hank "I need to do the same."
    if TeddyD:
        hank "Got a funeral to arrange."
        mc "Yeah.\nSorry for your loss, Hank."
        scene 15_1495 with dissolve
        hank "Thanks.\nIt's because of you I'm able to bury him; I won't forget."
    else:
        hank "Better go check on Teddy before he does summat else stupid."
        scene 15_1495 with dissolve
        hank "He's lucky he's my damn brother, 'cause the man's a fuckin' liability."
    scene 15_1496 with dissolve
    hank "Hope to see you here again, [mc].\nYou're welcome any time."
    mc "Thanks."
    scene 15_1497 with dissolve
    hank "See you tomorrow, Sweetheart."
    ame "Bye."
    if PrisonerD:
        mct "Makes no sense...\nNo way a doctor wouldn't see that I snapped the guy's neck."
    scene 15_1498 with dissolve
    mc "Take care, Amelia."
    ame "Yeah, you too."
    scene 15_1499 with dissolve
    if PrisonerD:
        mct "Either he didn't examine the body... or he straight-up lied to Hank about it... But why?"
    else:
        pause 0.5
    scene 15_1500 with dis1
    scene 15_1501 with dis1
    scene 15_1502 with dis1
    mct "Okay... Let's see how {b}she{/b} likes being followed..."
    scene 15_1503 with dis1
    scene 15_1504 with dis1
    scene 15_1505 with dis1
    jump CedarGrove_04_FollowAmelia
return

label CedarGrove_04_FollowAmelia:
    scene black with Fade(3, 0, 0)
    stop music fadeout 2.0
    $ cedargrove_open=False
    jump BriarHollow_Start1
return

label CedarGrove_Start5:
    if Elizabeth.Has("Saw"):
        $ Elizabeth.Del("Saw")
        $ Elizabeth.Add("A00")
    if Hayley.Has("Knows"):
        $ Hayley.Del("Knows")
        $ Hayley.Add("A00")
    if Chloe.Has("Knows"):
        $ Chloe.Del("Knows")
        $ Chloe.Add("A00")
    scene 15_1156 with Fade(1, 2, 4)
    pause
    scene 21_0001 with fade1
    liz "See!\nI told you he'd make it! Worrying over nothing!"
    net "I wasn't worried!"
    scene 21_0002 with dissolve
    net "I just thought he'd be here earlier, that's all!"
    liz "If you say so!"
    scene 21_0003 with dissolve
    mc "Sorry.\nI left later than planned, and traffic was a nightmare."
    net "We're just glad you're here.\nWe've all been looking forward to your visit."
    mc "Wow... I feel so special!"
    scene 21_0004 with dissolve
    liz "You shouldn't. {b}Any{/b} new face around here is like an early Christmas to us!"
    mc "Damn! Couldn't let me bask in my glory for even a minute?"
    liz "[lol] Sorry!"
    scene 21_0005 with dissolve
    net "Don't listen to her, [mc]; she's been in a funny mood all day!"
    net "And you {i}are{/i} special - to {b}all{/b} of us!"
    scene 21_0006 with dissolve
    net "I'll make you a coffee; I'm sure you'll be desperate for one!"
    mc "Yeah! Thanks, Nettie."
    scene 21_0007 with dissolve
    liz "She's right - I was only teasing you!"
    liz "It's always nice to see you here. Your visits put a smile on everyone's face."
    if Elizabeth.Has("A00"):
        mc "Even yours?"
        liz "Especially mine!"
        mc "Yeah?"
        scene 21_0008 with dissolve
        mc "Must say, seeing you has put a smile on my face, too!"
        mc "You're lookin' great!"
        scene 21_0009 with dissolve
        liz "You like it? Thanks!"
        scene 21_0010 with dissolve
        liz "I had you in mind when I decided to wear it."
        scene 21_0011 with dissolve
        liz "Thought I'd treat you to a bit more skin, since you seemed to enjoy it so much last time."
        scene 21_0012 with dissolve
        mc "Very thoughtful of you! And much appreciated!"
        scene 21_0013 with dissolve
        mc "But... are you {i}sure{/i} you're a nun?"
        liz "[lol]"
    scene 21_0014 with dissolve
    mc "Where's Hayley and Chloe?"
    liz "Upstairs."
    liz "Hayley's taking a shower.\nWe only see Chloe when she's hungry."
    mc "She still struggling with being stuck here?"
    scene 21_0015 with dissolve
    liz "We all are to a certain degree, but I think she feels it the most."
    liz "You know what it's like at that age. Freedom is everything, right?"
    mc "Yeah, guess so."
    scene 21_0016 with dissolve
    net "You still planning on staying over?"
    mc "Yeah, if everyone's good with it."
    net "Of course!"
    scene 21_0017 with dissolve
    liz "If you'll excuse me, [mc], I'll leave you both to catch up."
    mc "No need to leave!"
    scene 21_0018 with dissolve
    liz "I was trying to be polite!"
    liz "Now that you're here to entertain Nettie, I can take a nap in peace! [lol]"
    scene 21_0019 with dissolve
    if Elizabeth.Has("A00"):
        liz "Think I'll say a quick prayer first, though."
        net "Again?[lol]"
    else:
        liz "Have fun! Don't do anything I wouldn't do!"
        net "[lol]"
    scene 21_0020 with dissolve
    liz "See you later, guys."
    mc "See ya."
    scene 21_0021 with dissolve
    if Elizabeth.Has("A00"):
        mc "What was that about?"
        mc "It was code, right? Is She not going to pray?"
        net "[lol]"
        net "Yeah, she's definitely not {i}praying{/i}!"
    scene 21_0022 with dissolve
    net "Thanks for coming so quickly to talk with Hayley."
    net "I have to tell you though, [mc], I still think it's a terrible idea."
    scene 21_0023 with dissolve
    mc "I know you're worried about them, but this could be the best way to help them."
    net "I find that hard to believe."
    mc "Nettie... We have the FBI on our side now."
    scene 21_0024 with dissolve
    net "The FBI?!"
    net "How can you trust them??\nHayley told me Teddy and his brother control all kinds of people in authority - including the FBI!"
    call CenterText ("You bring Nettie up to speed with the latest developments.")
    scene 21_0025 with fade
    net "If that was supposed to put my mind at ease... it didn't work."
    net "This Emily--"
    mc "{i}Amelia{/i}."
    net "Whatever. She's already lied to you once... How do you know she isn't lying again??"
    scene 21_0026 with dissolve
    mc "I had the same doubts.\nBut my gut tells me we're on the {b}same{/b} side."
    mc "Even when I doubted the whole private investigator story, I still felt the same about her."
    scene 21_0027 with dissolve
    net "Jesus, [mc]!"
    net "Are you willing to risk their lives on a {i}feeling{/i}??"
    scene 21_0028 with dissolve
    mc "No, I'm not."
    mc "But I {b}am{/b} willing to put {i}mine{/i} on the line."
    mc "Amelia won't get anywhere near Hayley until I'm {b}absolutely certain{/b} it's the right way forward."
    scene 21_0029 with dissolve
    net "That doesn't make me feel any better."
    net "Hayley and Chloe aren't the only ones I'm worried about!\nI don't want anything to happen to you, either!"
    scene 21_0030 with dissolve
    mc "Nettie..."
    net "Don't tell me you can take care of yourself, [mc]!\nI know that, but this is--"
    mc "A dangerous situation. Yeah."
    mc "One that I'm working to get us out of. {b}All{/b} of us.\nI need you to trust that I can do that."
    scene 21_0031 with dissolve
    net "Of course I trust you. Don't {i}ever{/i} question that."
    net "But don't tell me not to worry about you. It's not gonna happen."
    net "I care for you - a lot.\nSo it's something you're gonna have to put up with!"
    mc "I can live with that."
    scene 21_0032 with dissolve
    mc "Is everyone here on the same page now?\nYou told them everything?"
    net "Yeah."
    net "Should I keep this FBI stuff from them, for now?"
    mc "Nah, no point. Keep them up to date.\nMaybe skip the undercover bit for now, though."
    if TeddyD:
        scene 21_0033 with dissolve
        if not Hayley.Has("A00"):
            mc "How did Hayley take the news about Teddy?"
            net "I wouldn't say she was happy, but most certainly relieved!\nWorried about retribution from his brother."
            net "She was annoyed that you lied to her about him going missing, though.\nYou should've just told her the truth."
            mc "I wasn't sure how she'd react. Didn't want to make things worse for her."
            net "Yeah, I get it."
        else:
            net "Things have been a lot easier here with Hayley since you told her about Teddy."
            mc "No more arguing?"
            net "[lol]I wouldn't say that... but definitely less!"
        if Chloe.Has("A00"):
            scene 21_0034 with dissolve
            net "Chloe's reaction to being told about Teddy was... unusual."
            mc "Why?"
            net "She tried her best to act shocked, but I'm pretty sure she already knew."
            scene 21_0035 with dissolve
            net "... I wonder who could've told her?"
            call laugh (mc, "Okay, you got me.")
            scene 21_0036 with dissolve
            mc "It was the day she took off from the motel.\nShe was really frightened."
            mc "I felt bad for her. Didn't want to feel that way; so, yeah, I told her."
            mc "She really wanted to tell you guys, but I made her promise to keep it to herself."
    scene 21_0037 with dissolve
    mc "Sister Elizabeth told me Chloe's still struggling with being stuck here."
    mc "On my last visit, she jumped on me before I'd even sat down, but she hasn't even said hello today!\nThings getting worse?"
    scene 21_0038 with dissolve
    net "We didn't tell her you were coming.\nHayley thought it'd be a nice little surprise for her when you arrived."
    net "She's doing okay. She hates it here, of course, but things are settling down."
    scene 21_0039 with dissolve
    net "So, how are {i}you{/i} doing, [mc]?\nStill living with Alison?"
    net "Cara still happy you're her dad, or are you driving her crazy now?[lol]"
    call laugh (mc, "I'm good!")
    mc "Alison sends her regards!"
    scene black with Fade(3, 1, 0)
    call CenterText ("You both enjoy a cozy little chat about nothing in particular for a while...")
    if not Nettie.isSexual():
        scene 21_0040 with fade1
        net "I imagine Cara and Millie have loved being back together again!"
        net "I still remember when they used to get together as little kids!"
        net "Always behaved like they were sisters; I wonder if - somehow, deep down - they just knew they were?"
        net "Bet it was tough for you back then, knowing the truth."
        scene 21_0041 with dissolve
        mc "Yeah. I always hoped the day would come when I could tell Cara the truth."
        mc "Never expected it to happen in reality."
        net "I'm glad it did.\nIf anyone deserves a slice of happiness - it's you!"
        mc "Thanks, Nettie."
        scene 21_0042 with dissolve
        net "I'd better make a start on dinner."
        mc "Your turn in the kitchen again?"
        net "Yep. So I hope you're hungry![lol]"
        scene 21_0043 with dissolve
        mc "Want some help?"
    else:
        scene 21_0050 with fade1
        net "[whi]Mmhh."
        scene 21_0051 with dissolve
        scene 21_0052 with dis1
        call EmotionSml (net, "Sigh", "I want us to go upstairs right now more than anything.")
        mc "[whi]But...?"
        scene 21_0053 with dissolve
        net "[whi]It's my turn to make dinner, and I need to make a start."
        mc "[whi]Okay."
        mc "[whi]Do me one favor, though... Don't put too much food on our plates."
        mc "[whi]I kinda plan on being balls deep in you tonight, and I'm gonna struggle if I'm in a food coma!"
        scene 21_0054 with dissolve
        net "[lol]"
        net "[whi]Balls deep, huh? I like the sound of that."
        scene 21_0051 with dissolve
        net "[whi]Mmhh."
        scene 21_0043 with fade
        mc "Want some help in the kitchen?"
    net "Thanks, but I can handle it."
    scene 21_0044 with dissolve
    net "Hayley will be finished with her shower by now.\nIf you don't want to sit here by yourself, go up and have that chat with her."
    net "And don't forget to say hello to Chloe!"
    mc "Okay."
    scene 21_0045 with dissolve
    pause 0.5
    scene 21_0046 with dis1
    scene 21_0047 with dis1
    scene 21_0048 with dis1
    scene 21_0049 with dis1
    call CedarGrove_05_SeeHayley
    if Chloe.isActive():
        call CedarGrove_05_TrainChloe
    else:
        scene black with Fade(2, 1, 0)
        play sound "knock.mp3" volume 0.5
        scene 21_0069 with Fade(0,1,1)
        chlo "[whi]Come in, [mc]."
        scene 21_0070 with dissolve
        mc "Wanna hang out for a bit?"
        chlo "[whi]Sure do!"
    scene black with fade2
    call CenterText ("Later that evening.")
    scene 21_0392 with fade
    net "I was hoping he'd change your mind somehow, but it's your decision, Hayley, and I'll support you no matter what."
    hay "He tried!"
    scene 21_0393 with dissolve
    net "{i}You{/i} tried to talk her out of it?\nSo you think it's a bad idea, too??"
    mc "I wanted to make sure she's doing it for the right reasons."
    scene 21_0394 with dissolve
    mc "I believe you are."
    mc "But you know that we won't hold it against you if you decide against it. You still have time."
    scene 21_0395 with dissolve
    hay "I won't.\nWith you guys by my side, this victim's gonna become a fighter."
    scene 21_0396 with dissolve
    mc "You're {b}already{/b} a fighter, Hayley. You just don't see it yet."
    mc "We're right by your side no matter what."
    scene 21_0397 with dissolve
    net "He's right, you know?\nYou don't realize how strong you are!"
    net "You're {b}not{/b} a victim - not anymore!"
    scene 21_0398 with dissolve
    hay "Wow! I like the votes of confidence! Thanks!"
    hay "Think I'd better go to bed before all this praise goes to my head!"
    net "[lol]"
    scene 21_0399 with dissolve
    hay "Night, guys."
    mc "Night."
    call CheckForP (Nettie.getCumIns(), Nettie.getSex(), 1)
    $ NettiePreg=_return
    if NettiePreg:
        scene 21_0400 with dissolve
        mc "I know you're against it, but she'll be okay.\nI'll make sure of it."
        net "Yeah, I know."
        call CedarGrove_05_NettieConvo
    else:
        scene 21_0401 with dissolve
        mc "I know you're against it, but she'll be okay.\nI'll make sure of it."
        net "Yeah, I know."
    scene 21_0409 with dissolve
    chlo "Hey."
    net "Perfect timing, Sweetheart!"
    scene 21_0410 with dissolve
    net "Mind keeping [mc] company for a while? I'm gonna jump in the shower before bed."
    chlo "Okay."
    scene 21_0411 with dissolve
    net "Don't let him fall asleep down here!\nHe's a pain in the butt to wake up!"
    chlo "[lol]"
    scene 21_0412 with dissolve
    if Nettie.isSexual():
        net "Give me thirty minutes, then come up; I have something to show you."
        mc "Okay."
    else:
        net "You remember where the spare room is, right?"
        mc "Yeah. Thanks."
    scene 21_0413 with dissolve
    chlo "Night, Sister Nettie."
    net "Night."
    scene 21_0414 with dissolve
    mc "Hey, what's wrong?"
    chlo "My mom told me what she's planning to do."
    chlo "Is she gonna be okay?"
    mc "Chloe, look at me."
    scene 21_0415 with dissolve
    mc "I swear, I won't let anything bad happen to her or you."
    mc "I'll keep you both safe; You have my word."
    chlo "[whi]Okay."
    scene 21_0416 with dissolve
    if Chloe.isSexual():
        chlo "And you won't abandon me?"
        mc "You're stuck with me forever."
        scene 21_0417 with dissolve
        chlo "Promise?"
        scene 21_0418 with dissolve
        mc "Come here."
        scene 21_0419 with dis1
        scene 21_0420 with dissolve
        mc "Do you remember my reply the last time you asked me?"
        chlo "Yeah. You said never in a million years."
        mc "I meant every word."
        scene 21_0421 with dissolve
        chlo "[whi]Okay."
        scene 21_0422 with dissolve
        chlo "[whi]I love you, [mc]."
        scene 21_0423 with dissolve
        mc "[whi]I love you, too."
        scene 21_0424 with dissolve
        chlo "And you'll still be able to visit us when we have to live somewhere else?"
        mc "Yeah."
        chlo "Good."
        scene black with Fade(2, 2, 0)
        call CenterText ("You hangout with Chloe for a little while, putting her mind at ease for what's to come, before heading to bed.")
    else:
        chlo "And you won't abandon us?"
        mc "You're stuck with me forever."
        scene 21_0417 with dissolve
        chlo "Promise?"
        mc "Absolutely."
        scene black with Fade(2, 2, 0)
        call CenterText ("You hangout with Chloe for a little while, putting her mind at ease for what's to come, before heading to bed.")
    if Nettie.isSexual():
        call NettieReplay04
    scene 21_0425 with Fade(0, 2, 5)
    pause
    scene 21_0426 with dis1
    scene 21_0427 with dis1
    mct "Not picking up.\nProbably still in bed. I'll leave a message."
    mc cell "Hey, Ali. Leaving Cedar Grove now. I'll see you soon."
    scene 21_0428 with dis1
    if Chloe.isSexual():
        mct "Hmm... Text from Chloe."
        if Chloe.Has("A01"):
            $ i=16
            while i<24:
                call AddGaleryItem ("chlo_"+str(i), False)
                $ i+=1
        else:
            $ i=10
            call AddGaleryItem ("chlo_09", False)
            while i<15:
                call AddGaleryItem ("chlo_"+str(i), False)
                $ i+=1
        $ renpy.notify("Pictures have been added to your gallery.")
        mct "Heh, right. The photos she took. Nice."
    scene 21_0429 with dis1
    scene 21_0430 with dis1
    scene 21_0431 with dis1
    $ oakhill_open=True
    jump CedarGrove_Leave
return

label CedarGrove_05_NettieConvo:
    net "..."
    scene 21_0401 with dissolve
    net "... I'm late."
    mc "Late? For wh--"
    mc "OH! You're {i}late{/i}?"
    net "Yeah."
    scene 21_0402 with dissolve
    net "Don't panic. It probably doesn't mean anything."
    net "I've been under a lot of stress lately, so it's more than likely that."
    scene 21_0403 with dissolve
    mc "Have you done a test?"
    net "No, not yet."
    mc "Want me to go and buy one?"
    net "No. I think it's too early?\nI'm not sure how far along I'd need to be."
    scene 21_0404 with dissolve
    net "[mc]... I'm probably {b}not{/b} pregnant, I know that."
    net "But a little part of me is going '{i}Yay!{/i}', and I like that feeling."
    net "If I take the test and it comes back negative, I'll be sad, even though I know it'll be the most likely outcome."
    scene 21_0405 with dissolve
    net "So, for now, I'd like to enjoy that little '{i}Yay!{/i}' a bit longer, you know?"
    mc "Yeah."
    net "I was going to wait until we were in bed to tell you, but I couldn't wait any longer."
    scene 21_0406 with dissolve
    net "Nothing needs to change between us."
    net "I'm not asking anything of you. I wanted you to know; that's all."
    scene 21_0407 with dissolve
    mc "Okay."
    mc "But, for the record - I didn't panic, and I'm one hundred percent on the side of that little '{i}Yay!{/i}'."
    scene 21_0408 with dissolve
    net "Really?"
    mc "Hell yeah!"
return

label CedarGrove_05_SeeHayley:
    scene 21_0055 with fade2
    chlo "[whi]It is! Can you get out now?"
    hay "[whi]Chloe! How can you say this room's tidy?!\nThere are clothes everywhere!?"
    scene 21_0056 with dissolve
    chlo "[whi]God! Okay! I'll pick them up in a minute!\nJust stop nagging!"
    mct "Damn!"
    scene 21_0057 with dissolve
    hay "I'm not nagging!\nI'm just asking you to treat this place with a bit of respect!"
    hay "It's not {b}our{/b} home, Chloe!"
    mc "Hey."
    scene 21_0058 with dissolve
    chlo "{b}[mc!u]{/b}!"
    scene 21_0059 with dis1
    scene 21_0060 with dissolve
    chlo "What are you doing here??"
    scene 21_0061 with dissolve
    mc "Damn, with welcomes like this, I might start coming here every day!"
    chlo "That would be so {b}awesome{/b}!"
    hay "[lol]"
    scene 21_0062 with dissolve
    hay "{i}Now{/i} do you see why I wanted your room tidied, young lady?"
    chlo "Yeah. Sorry, Mom."
    scene 21_0063 with dissolve
    chlo "You should've told me he was coming!\nI would've cleaned up straight away!"
    hay "We wanted it to be a surprise, Sweetheart."
    if Chloe.isActive():
        hay "We know how happy you get when he's here."
    scene 21_0064 with dissolve
    mc "Don't worry, I'm stayin' over, so we have plenty of time to hang out."
    mc "...{i}After{/i} you've tidied your room!"
    scene 21_0065 with dissolve
    if Chloe.isActive():
        chlo "Can we train some more?"
        mc "Sure!"
    else:
        chlo "Promise?"
        mc "Of course."
    scene 21_0066 with dissolve
    mc "But for now... I'll do you another favor and get your mom outta here so you can clean in peace."
    chlo "Please do! She's all yours!"
    scene 21_0067 with dissolve
    chlo "I'll have it cleaned up in no time!"
    hay "Yeah, I bet you will. [lol]"
    scene 21_0068 with dissolve
    hay "Come on, we can talk in my room."
    mc "Okay."
    scene 21_0338 with fade1
    hay "I appreciate you coming all this way to see me."
    scene 21_0339 with dissolve
    mc "It's the least I can do."
    scene 21_0340 with dissolve
    mc "To be honest, I expected you to say no."
    hay "Why?"
    scene 21_0341 with dissolve
    mc "Haven't you already been through enough?"
    mc "Figured you'd want to turn the page and begin a new chapter in your life. Put all this behind you."
    scene 21_0342 with dissolve
    hay "You sound like Nettie.\nWhy are {b}you{/b} trying to talk me out of it?"
    hay "You're the one who asked me to do it!\nI thought you'd be on my side?"
    scene 21_0343 with dissolve
    mc "I {i}am{/i} on your side.\nWhich is why I need to know you'll be going in with your eyes wide open."
    mc "This could go on for years! Are you prepared for that??"
    scene 21_0344 with dissolve
    hay "I've seen terrible things, [mc].\nIf I don't stand up and do the right thing, aren't I just as bad as them?"
    hay "I couldn't do anything then... but I can {b}now{/b}."
    scene 21_0345 with dissolve
    mc "Hayley..."
    scene 21_0346 with dissolve
    mc "You aren't responsible for what Teddy and Hank did."
    mc "There's a difference between witnessing and participating.\nYou have nothing to feel guilty about."
    scene 21_0347 with dissolve
    hay "It's not about guilt.\nThe truth is, I'm... ashamed."
    hay "Chloe sees me as a victim, and she's right - I am."
    hay "I've always been afraid to stand up for myself."
    scene 21_0348 with dissolve
    hay "I want to break the cycle. I want to fight back - not just for me, but for all those people they hurt."
    hay "I want my daughter to be proud of her mother for once."
    scene 21_0349 with dissolve
    mc "You've obviously put a lot of thought into this.\nAnd it sounds like I couldn't talk you out of it even if I wanted to."
    mc "So, why am I here?"
    hay "I have conditions."
    scene 21_0350 with dissolve
    hay "When it's all over, they set us up with a new life. A new identity. Away from here."
    mc "You're talking about a witness protection program?"
    hay "Yes. For Chloe and me.\nWe need a fresh start."
    hay "I don't know if your cop friend can offer that, but I won't do it without that guarantee."
    scene 21_0351 with dissolve
    mc "Alysha couldn't give you that... but the FBI can."
    hay "The FBI?"
    mc "Yeah, I just told Nettie about it.\nShe'll fill you in with the details later."
    scene 21_0352 with dissolve
    hay "Be careful who you trust, [mc].\nHank owns people everywhere - including the FBI."
    mc "I trust {i}her{/i}, but until I can trust the team {i}behind{/i} her, I won't reveal your identity."
    hay "The only people I trust are all in this house right now."
    scene 21_0353 with dissolve
    hay "Reaching out to the FBI is a big risk. Are you sure it was the right thing to do?"
    mc "Actually, they reached out to me.\nShe's working for Hank, undercover."
    hay "Holy shit! Does she have a death wish?\nWho is it??"
    scene 21_0354 with dissolve
    menu:
        "[wk_y]Tell her":
            $ Hayley.Add("A01")
            $ Hayley.Score(1)
            mc "This information stays between you, me, and Nettie.\nThe fewer people who know, the safer she stays."
            mc "She's a barmaid at Hank's bar."
            scene 21_0355 with dissolve
            hay "AMELIA?!"
            mc "You know her?"
            scene 21_0356 with dissolve
            hay "I mean, we're not friends or anything... but yeah, she's a nice girl."
            hay "She once jumped between Teddy and me as he took a swing."
            hay "He caught her on the side of her head."
            scene 21_0357 with dissolve
            hay "Brave woman. She actually threw him out of the bar!"
            hay "He was livid!\nBut Hank backed her up, so he had no choice but to leave."
            scene 21_0358 with dissolve
            hay "Of course, I paid for it when we got home. He beat the shit out of me that evening."
            scene 21_0359 with dissolve
            hay "Wow! She's FBI?"
            hay "Like I said - Brave!"
        "Don't tell her":
            mc "C'mon, you know I can't tell you that."
            hay "You don't trust me??"
            mc "Of course I do!\nThe more people that know about her - even friendly people - the more danger she's in."
            hay "Yeah, I suppose."
    scene 21_0360 with dissolve
    mc "You said condition{b}s{/b}... what else?"
    hay "I'll need guarantees for Sister Nettie and Sister Elizabeth's safety."
    hay "Ideally, I'd like to keep in touch with them after this is over."
    mc "I don't think that's how witness protection usually works.\nYou enter that program, and your old life is done."
    scene 21_0361 with dissolve
    hay "I'll give up my old life, but not them... and not you.\nI want {i}us{/i} to remain friends, too."
    hay "Let's be honest... It's the only way I'll get Chloe on board!\nShe'd never forgive me if she lost you!"
    scene 21_0362 with dissolve
    mc "Going down this path is a last resort, and I hope we won't have to take it."
    mc "But if the time comes, I'll do my best to get them to agree to your terms."
    scene 21_0363 with dissolve
    hay "Then we have ourselves a deal."
    scene 21_0364 with dissolve
    mc "Okay."
    if Hayley.isActive() and not Hayley.hasScore(2):
        call CloseCharacterPath (Hayley)
    if Hayley.isActive():
        if not EzModeActive:
            menu:
                "[wk_y]Ask if Chloe's the only reason she wants to be friends":
                    hay "[lol]"
                "Say nothing [wk_c]":
                    call CloseCharacterPath (Hayley, "Hayley")
        else:
            mc "Is Chloe's the only reason you want to be friends?"
    if not Hayley.isActive():
        scene 21_0365 with dissolve
        hay "Now go and spend some time with Chloe before she blames me for hogging you!"
        mc "Heh, right."
        return
    scene 21_0366 with dissolve
    hay "I {i}could{/i} say yes, but you know I'd be lying!"
    scene 21_0367 with dissolve
    mc "You want us to be {i}friends{/i}?"
    scene 21_0368 with dissolve
    hay "For now, yes. But eventually?..."
    scene 21_0369 with dis1
    pause 0.5
    scene 21_0370 with dissolve
    hay "[whi]Mhh."
    scene 21_0371 with dissolve
    pause 0.5
    scene 21_0372 with dis1
    pause 0.5
    scene 21_0373 with dissolve
    hay "[whi]Mmhh."
    scene 21_0374 with dis1
    scene 21_0375 with dis1
    scene 21_0376 with dis1
    scene 21_0377 with dis1
    hay "You don't give up, do you?"
    scene 21_0378 with dis1
    mc "Never."
    hay "Yeah, Nettie did warn me."
    scene 21_0379 with dis1
    mc "You talked to Nettie about me?"
    hay "About {i}us{/i}, like this - yeah."
    scene 21_0380 with dissolve
    if not Nettie.isSexual():
        hay "I owe her a lot.\nI wanted to be sure she'd be okay with it."
        mc "And?"
        hay "She said you're a good man. A kind man."
        scene 21_0381 with dissolve
        hay "She told me she didn't think you wanted to be tied down again, which sounds good to me."
        hay "The last thing I need right now is a serious relationship."
        scene 21_0384 with dissolve
    else:
        hay "I owe her a lot. I could never go behind her back!"
        scene 21_0381 with dissolve
        hay "I wasn't prepared to jeopardize my friendship with her, so I told her how I felt about you."
        hay "Don't worry, you're not in trouble!\nI made it clear nothing has happened between us."
        hay "I told her I wasn't sure what you two were, but if she says no, then that's the end of it."
        mc "And what did she say?"
        scene 21_0382 with dissolve
        hay "[mc], look where your hand is - what do you think she said?"
        scene 21_0383 with dissolve
        hay "She's in love with you."
        hay "But she knows that you don't want to be tied down again, and she's good with it."
        if Alison.isSexual():
            hay "She's convinced you're sleeping with the friend you live with."
            if Violet.isSexual():
                hay "She's pretty sure you're still fucking your ex-wife, too."
        elif Violet.isSexual():
            hay "She's convinced you're sleeping with your ex-wife."
        scene 21_0384 with dissolve
        hay "As long as she's getting {i}her{/i} piece of you, she doesn't mind.\nShe wants you to be happy."
        hay "Very liberal for a nun!"
        hay "I get where she's coming from, though.\nRushing into a serious relationship is the last thing I need right now."
    mc "So what {b}do{/b} you need right now?"
    scene 21_0385 with dissolve
    hay "Patience.\nFrom {i}both{/i} of us."
    hay "I'm fighting the urge for us to get naked right now."
    hay "But I have to take this slow, [mc].\nI know you understand."
    scene 21_0386 with dissolve
    mc "Yeah..."
    scene 21_0387 with dis1
    scene 21_0388 with dis1
    mc "I do."
    scene 21_0389 with dis1
    hay "[whi]Mmhh."
    scene 21_0390 with dissolve
    hay "[whi]..Mhhh.."
    scene 21_0391 with dis1
    hay "Now go and spend some time with Chloe before she blames me for hogging you!"
    mc "Heh, okay."
return

label CedarGrove_05_TrainChloe:
    python:
        if TeddyD and Chloe.Has("A00") and Chloe.isSexual():
            for pic in Gallery_items: 
                if pic.thumb=="thumbs/gal/chlo_01_t.jpg": Chloe.Add("A01")
    scene black with Fade(2, 2, 0)
    play sound "knock.mp3" volume 0.5
    scene 21_0069 with Fade(0,1,1)
    chlo "[whi]Come in, [mc]."
    scene 21_0070 with dissolve
    mc "Ready?"
    chlo "[whi]Yep!"
    scene 21_0071 with dissolve
    mc "Finish your warm-up stretches?"
    chlo "I was waiting on you."
    scene 21_0072 with dissolve
    mc "Hoping I wasn't gonna ask?"
    chlo "No! [lol]"
    scene 21_0073 with fade1
    mc "Good."
    mc "Hold it."
    scene 21_0074 with dissolve
    mc "You {i}have{/i} been practicing!\nWell done!"
    chlo "Told you!"
    scene 21_0075 with fade2
    mc "Perfect!"
    scene 21_0076 with dissolve
    mc "Keep those knees locked."
    chlo "They are!"
    scene 21_0077 with dissolve
    mc "Five more seconds."
    scene 21_0078 with dissolve
    chlo "Five more seconds for you to gawp at my ass?"
    scene 21_0079 with dissolve
    mc "Yep."
    scene 21_0080 with dissolve
    mc "[kiss]"
    scene 21_0081 with dissolve
    chlo "[lol]"
    scene 21_0082 with fade2
    chlo "{b}Grrr{/b}!"
    mc "Yes! Excellent!"
    scene 21_0083 with dissolve
    mc "Let's do that again, but this time I'm gonna attack a little faster so you'll have less reaction time."
    chlo "'Kay."
    scene black with fade2
    scene 21_0084 with vpunch
    chlo "{b}AAARRRR{/b}!"
    scene 21_0085 with dissolve
    chlo "COME ON THEN! WHAT YOU GONNA DO, BITCH??" with vpunch
    scene 21_0086 with dissolve
    chlo "Oh, god!\nSorry, [mc]! Did I hurt you?"
    call laugh (mc, "That was awesome! Great job!")
    mc "We {i}really{/i} need to work on your smack talk, though!"
    scene 21_0087 with dissolve
    chlo "Don't be dissin' my trash talk!\nI just dropped you; don't make me do it again!"
    scene 21_0088 with dissolve
    chlo "[kiss]"
    scene 21_0089 with dissolve
    chlo "C'mon, tough guy. Back to work!"
    call laugh (mc, "Yes, Ma'am!")
    scene black with fade2
    call CenterText ("An hour or so later...")
    scene 21_0090 with Fade(0,1,1)
    mc "Nice!"
    mc "You'll want to push and lean in with all your weight to the windpipe... but never let go of the arm."
    chlo "Got it."
    scene 21_0091 with dissolve
    call Emotion (mc, "Breathing heavily", "Okay... That's enough for today.")
    chlo "Yeah, I'm beat, too!"
    if Chloe.Has("A01"):
        $ persistent.ChloeRP01Dat=True
        $ persistent.ChloeRP02Dat=True
        chlo "Shame though."
        chlo "I was kinda enjoying {i}this{/i} one! [lol]"
        scene 21_0092 with dissolve
        call laugh (mc, "Me, too!")
        call ChloeReplay02
    else:
        $ persistent.ChloeRP01Dat=False
        chlo "..."
        call ChloeReplay01
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
