default persistent.cedargrove_active = False
default cedargrove_id = "CG"
default cedargrove_ch = 1
default cedargrove_open = False
default cedargrove_info = ["", 
"I still have to find Pete's sister, Nettie, and deliver the letter as promised. Alison told me she could be located here.",
"""I owe Nettie a huge apology.
I very much doubt she'll be happy to see me again, and she has every right to tell me to go fuck myself.
I have to at least try, through.""",
]

label UpdateCedarGroveData(id=0):
    if len(cedargrove_info)<=3:
        $ cedargrove_info.insert(3, "I should inform Nettie that her brother Pete isn't Cara's father, better to do it face-to-face.")
    if len(cedargrove_info)<=4:
        $ cedargrove_info.insert(4, "I need to find out why the barmaid was following me. The bullshit answer she gave doesn't make a bit of sense.")
    if len(cedargrove_info)<=5:
        $ cedargrove_info.insert(5, "Hayley wants to talk about helping us take down Hank and his mob. Not sure I even know how that'd work at this point.")
return

default persistent.NettieLocked = True
default persistent.NettieDr = False
default Nettie_name = "Nettie"
default NettiePreg = False
define net = Character("[Nettie_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="nettie")
image side nettie nun = side+"nettie_alt.png"
image side nettie cell = side+"nettie_c.png"
image side nettie h = side+"nettie_hp.png"
image side nettie s = side+"nettie_sd.png"
image side nettie a = side+"nettie_an.png"
image side nettie sh = side+"nettie_sh.png"
image side nettie su = side+"nettie_su.png"
default Nettie = Stats()

default persistent.ElizabethLocked = True
default Elizabeth_name = ""
define liz = Character("[Elizabeth_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="elizabeth")
image side elizabeth nun = side+"elizabeth_alt.png"
image side elizabeth cell = side+"elizabeth_c.png"
image side elizabeth h = side+"elizabeth_hp.png"
image side elizabeth s = side+"elizabeth_sd.png"
image side elizabeth a = side+"elizabeth_an.png"
image side elizabeth sh = side+"elizabeth_sh.png"
image side elizabeth su = side+"elizabeth_su.png"
default Elizabeth = Stats()

default persistent.HayleyLocked = True
default Hayley_name = "Hayley"
define hay = Character("[Hayley_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="hayley")
image side hayley cell = side+"hayley_c.png"
image side hayley h = side+"hayley_hp.png"
image side hayley s = side+"hayley_sd.png"
image side hayley a = side+"hayley_an.png"
image side hayley sh = side+"hayley_sh.png"
image side hayley su = side+"hayley_su.png"
default Hayley = Stats()

default persistent.ChloeLocked = True
default Chloe_name = "Chloe"
define chlo = Character("[Chloe_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="chloe")
image side chloe cell = side+"chloe_c.png"
image side chloe h = side+"chloe_hp.png"
image side chloe s = side+"chloe_sd.png"
image side chloe a = side+"chloe_an.png"
image side chloe sh = side+"chloe_sh.png"
image side chloe su = side+"chloe_su.png"
default Chloe = Stats()
default persistent.ChloeRP01Dat = True
default persistent.ChloeRP02Dat = True


define barm = Character("Barman", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define priest = Character("Priest", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
default Teddy_name = ""
define ted = Character("[Teddy_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="teddy")

default Rudy_name = ""
define rud = Character("[Rudy_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="rudy")
default Tom_name = ""
define tom = Character("[Tom_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="jason")
define hank = Character("Hank", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="hank")
define pri = Character("Prisoner", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define doc = Character("Doctor", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="doc")
define dman = Character("D", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])


screen CedarGrove_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "cdg", "chloe", Chloe_Replay, persistent.ChloeLocked, "Hayley's daughter.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "cdg", "elizabeth", Elizabeth_Replay, persistent.ElizabethLocked, "Nun.\nNettie's friend and work collegue.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "cdg", "hayley", Hayley_Replay, persistent.HayleyLocked, "Chloe's mother.\nWas in an abusive relationship.\nNettie is trying to help her.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "cdg", "nettie", Nettie_Replay, persistent.NettieLocked, "Nun.\nPete's sister.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
