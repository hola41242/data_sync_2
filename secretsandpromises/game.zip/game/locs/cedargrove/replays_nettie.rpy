label NettieReplay01:
    call Unlocker ("NettieReplay01")
    scene 04_0596 with dissolve
    pause 0.5
    scene 04_0597 with dis1
    mc "[kiss]"
    scene 04_0598 with dissolve
    pause 1.0
    scene 04_0599 with dissolve
    net "[ss]Mmhhh."
    scene 04_0600 with dis1
    pause 0.5
    scene 04_0601 with dis1
    net "[ss]...Mmhhh..."
    scene 04_0602 with dissolve
    net "[ss]...Mmmmmhhh..."
    scene 04_0603 with dissolve
    net "[ss]..Mmhhhh.."
    scene 04_0604 with dissolve
    pause 1.0
    scene 04_0605 with dissolve
    pause 1.0
    if not _in_replay:
        $ persistent.NettieDr=Nettie.Has("Alc")
    if not persistent.NettieDr:
        scene 04_0606 with dissolve
        net "[whi]Wow."
        net "That was even better than I'd imagined."
        net "Do it again."
    else:
        scene 04_0607 with dissolve
        net "Why'd you stop??"
        net "Don't stop!"
    scene 04_0608 with dissolve
    net "[ss]..Mmhhhh.."
    scene 04_0609 with dissolve
    net "[ss]..Mmhh..{w=1}{nw}"
    scene 04_0610 with dis1
    pause 0.5
    scene 04_0611 with dis1
    net "[ss]..Ohhhh..{w=0.5}{nw}"
    scene 04_0612 with dis1
    pause 0.5
    scene 04_0613 with dis1
    net "[ss]..Mmhh..{w=1}{nw}"
    scene 04_0614 with dis1
    pause 0.5
    scene 04_0615 with dis1
    net "[ss]..Mmmmhh..{w=0.5}{nw}"
    scene 04_0616 with dis1
    if persistent.NettieDr:
        call NettieReplay01_Drunk
    else:
        call NettieReplay01_Merry
return

label NettieReplay01_Drunk:
    scene 04_0619 with dissolve
    net "[ss]Something else I've never done..."
    scene 04_0620 with dissolve
    scene 04_0621 with dis1
    pause 0.5
    scene 04_0622 with dissolve
    net "[ss]I've never sucked a dick."
    scene 04_0623 with dissolve
    net "[ss]Can I suck yours, [persistent.McName]?"
    scene 04_0624 with fade1
    pause
    scene 04_0625 with dissolve
    scene 04_0626 with dis1
    image r_nettie_01 = Movie(play="images/e04/04_0627.webm")
    show r_nettie_01 with dissolve
    pause
    scene 04_0628 with dissolve
    mct "Things I never thought I'd see happen... This definitely tops the list!"
    image r_nettie_02 = Movie(play="images/e04/04_0629.webm", keep_last_frame=True, loop=False)
    show r_nettie_02 with dissolve
    pause 4.0
    scene 04_0630
    image r_nettie_03 = Movie(play="images/e04/04_0631.webm")
    show r_nettie_03 with dissolve
    net "[ss]..Mmhh.."
    scene 04_0632 with dissolve
    image r_nettie_04 = Movie(play="images/e04/04_0633.webm")
    show r_nettie_04 with dissolve
    mct "...Nettie's suckin' my dick.....Fuuck..."
    scene 04_0634 with dissolve
    image r_nettie_05 = Movie(play="images/e04/04_0635.webm")
    show r_nettie_05 with dissolve
    net "[ss]..Mmmmmhhh.."
    scene 04_0636 with dissolve
    mct "Pretty good for a first time!"
    scene 04_0637 with dissolve
    image r_nettie_06 = Movie(play="images/e04/04_0638.webm")
    show r_nettie_06 with dissolve
    net "[ss]..Mmmhh.."
    mc "[whi]..Nnnhhh.....Slow down, Nettie..."
    scene 04_0636 with dissolve
    mct "Fuck...does she want me to cum in her mouth??"
    scene 04_0639 with dissolve
    image r_nettie_07 = Movie(play="images/e04/04_0640.webm")
    show r_nettie_07 with dissolve
    net "[ss]...Mmmmmm...."
    scene 04_0636 with dissolve
    mct "Guess so.."
    scene 04_0641 with dissolve
    image r_nettie_08 = Movie(play="images/e04/04_0642.webm")
    show r_nettie_08 with dissolve
    net "[ss]..Mmmhh.."
    call CharCum ("e04/04_0641.webp", "e04/04_0643.webp", mc, "....NNNGGGGGHHHH!!...")
    call CharCum ("e04/04_0643.webp", "e04/04_0644.webp", mc, "...FUUUUCK..")
    scene 04_0645 with hpunch
    call Gag (net)
    scene 04_0646 with dissolve
    net "I... I... don't feel so good..."
    scene 04_0647 with dissolve
    pause 0.5
    scene 04_0648 with dissolve
    pause 0.5
    scene 04_0649 with dissolve
    call Emotion (net, "Vomits", "BLLLARRRRGGGHH!!")
    mc "[whi]Ahh, jeez..."
    scene 04_0650 with fade
    mc "Are you okay?"
    scene 04_0651 with dissolve
    call Emotion (net, "groans")
    scene 04_0652 with vpunch
    call Emotion (net, "Vomits", "BLLLARRRRGGGHH!!")
    scene black with Fade(2, 1, 0)
    call CenterText ("20 minutes later...")
    scene 04_0592 with fade
    mc "[whi]..Zzzz.."
    scene black with Fade(2, 3, 0)
return

label NettieReplay01_Merry:
    $ Nettie.isSexual(True)
    net "[whi][persistent.McName]... you know we can't."
    scene 04_0617 with dissolve
    net "[whi]I'm sorry.\nWe can kiss, but that's all."
    scene 04_0618 with dissolve
    net "[whi]Can you just hold me? And kiss me?"
    scene 04_0653 with dissolve
    pause 1.0
    scene 04_0654 with dissolve
    mc "[whi]Sure I can."
    scene 04_0655 with fade1
    pause 1.0
    scene 04_0656 with dissolve
    net "[ss]...Mmhh..."
    scene 04_0657 with dissolve
    pause 1.0
    scene 04_0658 with dis1
    net "[ss]..Mmmmhh.."
    scene 04_0659 with dis1
    pause 0.5
    scene 04_0660 with dis1
    net "[ss]...Mmhh..."
    scene 04_0661 with dissolve
    net "[ss]..Mmmmhh.."
    scene 04_0662 with dissolve
    net "If we were to sleep in the same bed tonight, could I trust you?"
    mc "Could I trust {i}you{/i}?"
    net "[lol]"
    scene 04_0663 with dissolve
    net "Can I borrow your shirt? I have nothing to wear."
    mc "Uhh, sure."
    scene 04_0664 with fade1
    mct "Best behavior, [persistent.McName]! Heh."
    mct "I do enjoy kissing her, though!"
    scene 04_0665 with dissolve
    mct "Is that why she's faking being drunk?\nNo way she'd ever usually kiss me!"
    net "You're not naked under there, are you?"
    scene 04_0666 with dissolve
    mc "[lol]\nNo!"
    scene 04_0667 with fade1
    net "Thanks for tonight, [persistent.McName]. I had a lot of fun."
    scene 04_0668 with dissolve
    net "I'm, uhh, still drunk if you want to kiss me some more."
    scene 04_0669 with dissolve
    mc "That's right, you are..."
    net "[giggles]"
    scene 04_0670 with dissolve
    pause 1.0
    scene 04_0671 with dissolve
    net "[ss]...Mmhh..."
    scene 04_0672 with dissolve
    pause 1.0
    scene 04_0673 with dissolve
    net "[ss]..Mmmmhh.."
    scene 04_0674 with dissolve
    net "[ss]....MMMMMMHHHHHH....."
    scene 04_0675 with dissolve
    net "[ss]...Mmhh..."
    scene 04_0676 with dis1
    net "[ss]....MMMHH....."
    call Loop_Dissolve_Alt (4, "e04/04_0677.webp", "e04/04_0678.webp")
    net "[ss]..Mmmhh.."
    scene 04_0679 with dissolve
    pause 1.0
    scene 04_0680 with fade1
    pause 1.0
    scene 04_0681 with fade1
    net "[ss]..Mmmhh.."
    scene 04_0682 with dissolve
    pause 1.0
    scene 04_0683 with dis1
    pause 0.5
    scene 04_0684 with dis1
    pause 0.5
    scene 04_0685 with dis1
    net "[whi][persistent.McName], we can't."
    mc "[whi]{i}I{/i} can't... But {i}YOU{/i} can."
    net "[whi]Huh?"
    mc "[whi]{b}You{/b} can touch yourself."
    scene 04_0686 with dissolve
    net "[whi]Uhh..."
    mc "[whi]It's okay! You're drunk, aren't you?"
    scene 04_0687 with dissolve
    net "[whi]Yeah, I am."
    scene 04_0688 with dissolve
    mc "[whi]So touch yourself for me, Nettie."
    net "[whi]Uhh, [persistent.McName]... I... I don't know..."
    mc "[whi]I want you to orgasm while we kiss."
    scene 04_0689 with dissolve
    scene 04_0690 with dis1
    scene 04_0691 with dis1
    scene 04_0692 with dis1
    net "[ss]....MMMHH....."
    scene 04_0693 with dissolve
    net "[ss]..Mmmhh.."
    scene 04_0694 with dissolve
    image r_nettie_09 = Movie(play="images/e04/04_0695.webm")
    show r_nettie_09 with dissolve
    call Moan (net, 4)
    scene 04_0696 with dissolve
    pause 1.0
    scene 04_0697 with dis1
    scene 04_0698 with dis1
    scene 04_0699 with dis1
    scene 04_0700 with dis1
    scene 04_0701 with dis1
    call Moan (net)
    scene 04_0702 with dissolve
    net "[ss]....MMMMMMHHHHHH....."
    scene 04_0703 with dissolve
    pause 1.0
    scene 04_0704 with dis1
    pause 0.5
    scene 04_0705 with dis1
    call Moan (net, 7)
    scene 04_0706 with dissolve
    net "[ss]....MMMHH....."
    scene 04_0707 with dissolve
    pause 0.5
    call Loop_Dissolve (6, False, False, "e04/04_0708.webp", "e04/04_0709.webp")
    scene 04_0710 with dissolve
    call Moan (net, 6)
    call CharCum ("e04/04_0710.webp", "e04/04_0711.webp", net, "....!!OHHHHHHHH!!....")
    call CharCum ("e04/04_0711.webp", "e04/04_0712.webp", net, "..MHHHHHHHH..")
    scene 04_0713 with dissolve
    net "[ss]....MMMHH....."
    scene 04_0714 with dissolve
    net "[whi]Excuse my language, but..."
    scene 04_0715 with dissolve
    net "[whi]{b}Holy shit{/b}! That was fantastic!"
    mc "[whi][lol]"
    scene 04_0714 with dissolve
    net "[whi]You, uhh... can move your hand away now."
    scene 04_0716 with dissolve
    mc "[whi]Oh, yeah...."
    scene 04_0717 with dissolve
    mc "[whi]Better?"
    scene 04_0718 with dissolve
    net "[lol]"
    scene black with Fade(2, 3, 0)
    scene 04_0719 with fade
    mc "[whi]..Zzzz.."
    scene black with Fade(3, 1, 1)
return

label NettieReplay02:
    call Unlocker ("NettieReplay02")
    $ Nettie.incSex()
    if _in_replay:
        scene 07_0820 with fade
        mc "I'm gonna miss seeing you in uniform; I found it quite the turn-on! Heh."
    net "[lol]"
    scene 07_0824 with dissolve
    net "You know, this could be your last chance to kiss me as a nun, so maybe you should take it."
    scene 07_0825 with dissolve
    mc "Damn... You're right, maybe I should!"
    mc "Fancy putting your habit back on first?"
    scene 07_0826 with dissolve
    net "[lol]"
    scene 07_0827 with dissolve
    mc "[whi]I'll just use my imagination."
    net "[whi]I bet you will."
    scene 07_0828 with dissolve
    net "[kiss]"
    scene 07_0829 with dissolve
    pause 0.5
    scene 07_0830 with dissolve
    net "[ss]Mhh.."
    scene 07_0831 with dissolve
    net "[ss]...Mmmhh..."
    scene 07_0832 with dissolve
    net "[ss]..Mmhhhhh.."
    scene 07_0833 with dissolve
    net "[ss]Mhh.."
    scene 07_0834 with dissolve
    net "[ss]...Mmmhh..."
    scene 07_0835 with dissolve
    pause
    scene 07_0836 with dissolve
    net "[ss]..Mmhhhhh.."
    scene 07_0837 with dissolve
    pause 0.5
    scene 07_0838 with dis1
    pause 0.5
    scene 07_0839 with dis1
    net "[ss]...Mmmhh..."
    scene 07_0840 with dissolve
    mc "[whi]You're not wearing underwear?"
    net "[whi]Hmmm... Silly me... I must've taken them off by mistake."
    scene 07_0841 with dissolve
    net "[ss]Mhh.."
    scene 07_0842 with dissolve
    pause
    scene 07_0843 with dissolve
    image r_nettie_10 = Movie(play="images/e07/07_0844.webm")
    show r_nettie_10
    net "[ss]...Mmmhh..."
    scene 07_0845 with dissolve
    net "[ss]..Mmhhhhh.."
    scene 07_0846 with dissolve
    image r_nettie_11 = Movie(play="images/e07/07_0847.webm")
    show r_nettie_11
    call Moan (net, 4)
    scene 07_0848 with dissolve
    net "[ss]Mhh.."
    scene 07_0849 with dissolve
    image r_nettie_12 = Movie(play="images/e07/07_0850.webm")
    show r_nettie_12
    net "[ss]..Ohh.."
    scene 07_0851 with dissolve
    call Moan (net, 4)
    net "[ss]Mmhh....I'm so horny, [persistent.McName]...."
    net "[ss]... What if it just accidentally went in?...... Mhhh..."
    scene 07_0852 with dissolve
    image r_nettie_13 = Movie(play="images/e07/07_0853.webm")
    show r_nettie_13
    mc "[whi]Then... we'd {i}accidentally{/i} fuck."
    call Moan (net, 4)
    scene 07_0854 with dissolve
    image r_nettie_14 = Movie(play="images/e07/07_0855.webm", loop=False, keep_last_frame=True)
    show r_nettie_14
    pause 9.0
    scene 07_0856 with dissolve
    net "[ss]..Ohhh.."
    scene 07_0857 with dissolve
    image r_nettie_15 = Movie(play="images/e07/07_0858.webm")
    show r_nettie_15
    net "[ss]....OHHHH...."
    net "[ss]..Mmhhhhh.......It feels so good....."
    scene 07_0859 with dissolve
    image r_nettie_16 = Movie(play="images/e07/07_0860.webm")
    show r_nettie_16
    call Moan (net)
    scene 07_0861 with dissolve
    net "[ss]..Ohhh.."
    scene 07_0862 with dissolve
    scene 07_0863 with dis1
    scene 07_0864 with dis1
    scene 07_0865 with dis1
    image r_nettie_17 = Movie(play="images/e07/07_0866.webm")
    show r_nettie_17
    net "[ss]..Mmhhhhh.."
    scene 07_0867 with dissolve
    call Moan (net)
    scene 07_0868 with dissolve
    image r_nettie_18 = Movie(play="images/e07/07_0869.webm")
    show r_nettie_18
    net "[ss]..OHHHHH.."
    scene 07_0870 with dissolve
    image r_nettie_19 = Movie(play="images/e07/07_0871.webm")
    show r_nettie_19
    call Moan (net)
    scene 07_0872 with dissolve
    net "[ss]...MMMHHHH...."
    scene 07_0873 with dissolve
    net "[ss]....OHHH...."
    scene 07_0874 with dissolve
    call Moan (net)
    scene 07_0875 with dissolve
    net "[ss]....Mmhhhh... That feels nice....."
    scene 07_0876 with dissolve
    call Moan (net, 4)
    scene 07_0877 with dissolve
    image r_nettie_20 = Movie(play="images/e07/07_0878.webm")
    show r_nettie_20
    net "[ss]..Mmhhhhh.."
    scene 07_0879 with dissolve
    net "[ss][persistent.McName]..."
    net "[ss]... Fuck me."
    scene 07_0880 with fade1
    image r_nettie_21 = Movie(play="images/e07/07_0881.webm")
    show r_nettie_21
    net "[ss]..Mmhhhhh.."
    scene 07_0882 with dissolve
    image r_nettie_22 = Movie(play="images/e07/07_0883.webm")
    show r_nettie_22
    net "[ss]....OHHHHH...."
    net "[ss].....YESSS....OHHHHHHHHH......"
    scene 07_0884 with dissolve
    net "[ss]...YESS......."
    scene 07_0885 with dissolve
    image r_nettie_23 = Movie(play="images/e07/07_0886.webm")
    show r_nettie_23
    net "[sss]....OHHHHH...."
    scene 07_0887 with dissolve
    net "[ss]....OHHH, [persistent.McName!u]......YES......"
    scene 07_0888 with dissolve
    net "[sss]....OHHHHH..YES...YES...YES......."
    call Loop_Punch (4, "e07/07_0889.webp", "e07/07_0888.webp")
    call CharCum ("e07/07_0889.webp", "e07/07_0890.webp", net, "....!!OHHHHHHHH!!....")
    call CharCum ("e07/07_0890.webp", "e07/07_0891.webp", net, "..MHHHHHHHH..")
    show r_nettie_22 with dissolve
    pause
    call CmOpts (["Cum inside Nettie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        call CharCum ("e07/07_0882.webp", "e07/07_0892.webp", mc, "NNNNNGGGGHHHHH!!")
        $ Nettie.incCm()
        scene 07_0893 with dissolve
        pause
        scene 07_0894 with dissolve
        pause
        scene 07_0895 with dissolve
    else:
        call CharCum ("e07/07_0882.webp", "e07/07_0897.webp", mc, "NNNNNGGGGHHHHH!!")
        call CharCum ("e07/07_0897.webp", "e07/07_0898.webp", mc, "..NNNGGGHHH..")
        scene 07_0896 with dissolve
    pause
    call Emotion (net, "Panting", "Holy shit, that was awesome!")
    scene black with Fade(3, 1, 0)
return

label NettieReplay03:
    call Unlocker ("NettieReplay03")
    $ Nettie.incSex()
    scene 11_0758 with Fade(0, 0, 3)
    net "[ss]Mmhh."
    scene 11_0759 with dissolve
    net "[ss]..Mmmmhh.."
    scene 11_0760 with dis1
    scene 11_0761 with dis1
    scene 11_0762 with dis1
    scene 11_0763 with dis1
    scene 11_0764 with dissolve
    image NettieR03_01 = Movie(play="images/e11/11_0765.webm")
    show NettieR03_01
    net "[ss]..Mmmmhh.."
    scene 11_0766 with dissolve
    net "[ss]...Mmmhh..."
    scene 11_0767 with dis1
    pause 0.5
    scene 11_0768 with dis1
    pause 0.5
    scene 11_0769 with dis1
    pause 0.5
    scene 11_0770 with dis1
    pause 0.5
    scene 11_0771 with dissolve
    image NettieR03_02 = Movie(play="images/e11/11_0772.webm")
    show NettieR03_02
    net "[ss]..Mmmmhh.."
    scene 11_0773 with dissolve
    net "[ss]..Ohhhhhh.."
    scene 11_0774 with dis1
    pause 0.5
    scene 11_0775 with dis1
    pause 0.5
    scene 11_0776 with dis1
    pause 0.5
    scene 11_0777 with dis1
    pause 0.5
    scene 11_0778 with dis1
    pause 0.5
    scene 11_0779 with dis1
    pause 0.5
    scene 11_0780 with dis1
    pause 0.5
    scene 11_0781 with dis1
    pause 0.5
    scene 11_0782 with dissolve
    net "[ss]..Ohhhhhh.."
    scene 11_0783 with dissolve
    image NettieR03_03 = Movie(play="images/e11/11_0784.webm")
    show NettieR03_03
    call Moan (net)
    scene 11_0785 with dissolve
    image NettieR03_04 = Movie(play="images/e11/11_0786.webm")
    show NettieR03_04
    net "[ss]....Ohhhh...."
    scene 11_0787 with dissolve
    net "[ss]..OHHHHH.."
    scene 11_0788 with dissolve
    call Moan (net)
    scene 11_0789 with dis1
    pause 0.5
    scene 11_0790 with dis1
    net "[ss]..Mmmmhh.."
    scene 11_0791 with dis1
    net "[ss]....Mmhh...."
    scene 11_0792 with dissolve
    net "[whi]Wait."
    scene 11_0793 with dissolve
    net "[whi]Let me suck it first."
    mc "[whi]Oh, Nettie, no, you don't have to do that."
    scene 11_0794 with dissolve
    net "[whi]But I want to, Baby."
    scene 11_0795 with fade1
    net "[whi]I've never done this before, so if I'm doing it wrong... please tell me."
    scene 11_0796 with dissolve
    pause 0.5
    scene 11_0797 with dis1
    pause 0.5
    scene 11_0798 with dis1
    pause 0.5
    scene 11_0799 with dis1
    pause 0.5
    scene 11_0800 with dis1
    pause 0.5
    scene 11_0801 with dis1
    pause 0.5
    scene 11_0802 with dis1
    pause 0.5
    scene 11_0803 with dis1
    net "[ss]..Mmmmhh.."
    scene 11_0804 with dissolve
    pause
    scene 11_0805 with dissolve
    net "[ss]....Mmhh...."
    scene 11_0806 with dissolve
    net "[ss]..Mmmmhh.."
    scene 11_0807 with dissolve
    image NettieR03_05 = Movie(play="images/e11/11_0808.webm")
    show NettieR03_05
    net "[ss]...Mmhh."
    scene 11_0809 with dissolve
    image NettieR03_06 = Movie(play="images/e11/11_0810.webm")
    show NettieR03_06
    net "[ss]..Mmmmhhh..."
    scene 11_0811 with dissolve
    pause 0.5
    scene 11_0812 with dis1
    pause 0.5
    scene 11_0813 with dis1
    net "[whi]What's wrong?"
    mc "[whi]Ever heard of a sixty-nine?"
    scene 11_0814 with dissolve
    net "[whi]I'm a nun, not a moron."
    scene 11_0815 with dissolve
    image NettieR03_07 = Movie(play="images/e11/11_0816.webm")
    show NettieR03_07
    net "[ss]..Mmmmhhh..."
    scene 11_0817 with dissolve
    call Moan (net, 4)
    scene 11_0818 with dissolve
    image NettieR03_08 = Movie(play="images/e11/11_0819.webm")
    show NettieR03_08
    net "[ss]..Mmmmhhh..."
    scene 11_0820 with dissolve
    net "[ss]...Mmhh."
    scene 11_0821 with dissolve
    scene 11_0822 with dis1
    call Moan (net, 6)
    scene 11_0823 with dissolve
    net "[ss]..Ohhh...That feels amazing....."
    scene 11_0824 with dissolve
    net "[ss]..Mmmmhhh..."
    scene 11_0825 with dissolve
    net "[ss]...Ohhhhhhhh...."
    scene 11_0826 with dissolve
    call Moan (net, 6)
    scene 11_0827 with fade1
    pause
    scene 11_0828 with dissolve
    image NettieR03_09 = Movie(play="images/e11/11_0829.webm", loop=False, keep_last_frame=True)
    show NettieR03_09
    pause 1.0
    net "[ss]..Mmmmhhh...{w=1.5}{nw}"
    pause 0.5
    net "[ss]Ohhhhh."
    scene 11_0830 with dissolve
    image NettieR03_10 = Movie(play="images/e11/11_0831.webm")
    show NettieR03_10
    net "[ss]..Mmmmhhh..."
    scene 11_0832 with dissolve
    image NettieR03_11 = Movie(play="images/e11/11_0833.webm")
    show NettieR03_11
    net "[ss]..Mmhh.."
    scene 11_0834 with dissolve
    net "[ss]....Mmmmhhh....."
    scene 11_0835 with fade1
    image NettieR03_12 = Movie(play="images/e11/11_0836.webm")
    show NettieR03_12
    net "[ss]..OHHHH, [persistent.McName!u].."
    scene 11_0837 with dissolve
    image NettieR03_13 = Movie(play="images/e11/11_0838.webm")
    show NettieR03_13
    call Moan (net, 6)
    scene 11_0839 with dissolve
    net "[ss]OHHH."
    scene 11_0840 with dissolve
    image NettieR03_14 = Movie(play="images/e11/11_0841.webm")
    show NettieR03_14
    call Moan (net, 6)
    net "[ss].....OHHHHH, BABY, YES......."
    scene 11_0842 with dissolve
    image NettieR03_15 = Movie(play="images/e11/11_0843.webm")
    show NettieR03_15
    call Moan (net, 6)
    scene 11_0844 with dissolve
    image NettieR03_16 = Movie(play="images/e11/11_0845.webm")
    show NettieR03_16
    call Moan (net, 6)
    scene 11_0846 with dissolve
    net "[ss]..Ohhh, [persistent.McName]......Baby, yes....."
    scene 11_0847 with dissolve
    image NettieR03_17 = Movie(play="images/e11/11_0848.webm")
    show NettieR03_17
    call Moan (net, 6)
    scene 11_0849 with dissolve
    image NettieR03_18 = Movie(play="images/e11/11_0850.webm")
    show NettieR03_18
    call Moan (net, 6)
    net "[ss]....OHHHHH, BABY...."
    net "[ss]....YES.........OHHHHHH......."
    net "[ss]..[persistent.McName!u]......YES......YES......"
    call CharCum ("e11/11_0849.webp", "e11/11_0851.webp", net, "...OHHHHHHHH...")
    call CharCum ("e11/11_0851.webp", "e11/11_0852.webp", net, "..Mmmmhhhhh..")
    scene 11_0853 with dissolve
    image NettieR03_19 = Movie(play="images/e11/11_0854.webm")
    show NettieR03_19
    net "[ss]....Mmhhhh...."
    call CmOpts (["Cum inside Nettie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Nettie.incCm()
        call CharCum ("e11/11_0853.webp", "e11/11_0855.webp", mc, "..Nnnnggghhhhh..")
        call CharCum ("e11/11_0855.webp", "e11/11_0856.webp", mc, "....Nnhhh....")
        scene 11_0857 with dissolve
        pause
        scene 11_0858 with dissolve
        net "[ss]Mmhh."
    else:
        call CharCum ("e11/11_0853.webp", "e11/11_0859.webp", mc, "..Nnnnggghhhhh..")
        call CharCum ("e11/11_0859.webp", "e11/11_0860.webp", mc, "....Nnhhh....")
        scene 11_0861 with dissolve
        pause
        scene 11_0862 with dissolve
        net "[ss]Mmhh."
    scene 11_0863 with fade1
    net "[whi]..Zzz.."
    scene black with ReplayFade
return

label NettieReplay04:
    call Unlocker ("NettieReplay04")
    $ Nettie.incSex()
    scene 21_0198 with fade1
    mc "Are you coming to bed??\nWhat you doin' in there?"
    scene 21_0199 with dissolve
    net "[whi]Yes! One second..."
    mc "..."
    net "[whi]Remember how you said you were gonna miss seeing me in my habit?"
    mc "Err... Yeah... not sure that's {i}exactly{/i} what I said, though. Heh."
    scene 21_0200 with dissolve
    net "[lol] I know.\nYou said you'd miss seeing me in it because it was kinda hot."
    net "So..."
    scene 21_0201 with dis1
    net "Like it?"
    net "It was the best I could find under the circumstances."
    call ScanImage ("images/e21/21_0202.webp", 9)
    mc "{i}Daaaamn{/i}!"
    call laugh (mc, "Yep, you were right... I'm going to Hell.")
    scene 21_0203 with dissolve
    mc "You got dressed up for me?"
    scene 21_0204 with dissolve
    net "I want to be sexy for you."
    scene 21_0205 with dissolve
    mc "Nettie..."
    scene 21_0206 with dissolve
    scene 21_0207 with dissolve
    scene 21_0208 with dissolve
    mc "You've {b}always{/b} been sexy to me!"
    scene 21_0209 with dissolve
    net "I have?"
    scene 21_0210 with dissolve
    net "I've always been attracted to you, too."
    scene 21_0211 with dissolve
    net "I never imagined we'd end up in bed together, though!"
    scene 21_0212 with dissolve
    net "And who knew I'd love sucking {i}that{/i} so much?!"
    image NettieR04_01 = Movie(play="images/e21/21_0213.webm", loop=False, keep_last_frame=True)
    show NettieR04_01
    pause 2.0
    scene 21_0214 with dissolve
    image NettieR04_02 = Movie(play="images/e21/21_0215.webm", loop=False, keep_last_frame=True)
    image NettieR04_03 = Movie(play="images/e21/21_0216.webm")
    show NettieR04_02
    pause 2.0
    show NettieR04_03
    net "[ss]Mhhh."
    scene 21_0217 with dissolve
    image NettieR04_04 = Movie(play="images/e21/21_0218.webm")
    show NettieR04_04
    net "[ss]..Mmmhhh.."
    scene 21_0219 with dissolve
    pause 0.5
    scene 21_0220 with dis1
    mc "[whi]..Fuuck.."
    scene 21_0221 with dissolve
    image NettieR04_05 = Movie(play="images/e21/21_0222.webm")
    show NettieR04_05
    net "[ss]Mmmhh."
    scene 21_0223 with dissolve
    image NettieR04_06 = Movie(play="images/e21/21_0224.webm")
    show NettieR04_06
    pause
    scene 21_0225 with dis1
    net "[whi]What was the expression you used?... Balls deep?"
    net "[whi]You ever been balls deep in a nun's mouth?"
    scene 21_0226 with dis1
    mc "[whi]No, Sister, I have not."
    scene 21_0227 with dissolve
    call Gag (net)
    scene 21_0228 with dissolve
    image NettieR04_07 = Movie(play="images/e21/21_0229.webm")
    show NettieR04_07
    net "[ss]Mmmhh."
    scene 21_0230 with dissolve
    image NettieR04_08 = Movie(play="images/e21/21_0231.webm")
    show NettieR04_08
    pause
    scene 21_0232 with dissolve
    mc "[whi]Damn..."
    scene 21_0233 with dissolve
    mc "[whi]I need you to do me a favor..."
    scene 21_0234 with dissolve
    mc "[whi]Don't move an inch!"
    scene 21_0235 with dis1
    scene 21_0236 with dis1
    scene 21_0237 with dis1
    pause 0.5
    scene 21_0238 with dissolve
    pause 0.5
    scene 21_0239 with dis1
    scene 21_0240 with dis1
    scene 21_0241 with dis1
    mc "Praise the Lord!"
    net "[lol]"
    scene 21_0242 with dis1
    pause 0.5
    scene 21_0243 with dissolve
    mc "And now to eat the forbidden fruit!"
    scene 21_0242 with dissolve
    net "Oh, jeez! Maybe less talking and more eating. [lol]"
    call laugh (mc, "Yes, ma'am!")
    scene 21_0244 with dis1
    net "[ss]Mmmhhh."
    scene 21_0245 with dissolve
    net "[ss]..Ohhh.."
    scene 21_0246 with dissolve
    image NettieR04_09 = Movie(play="images/e21/21_0247.webm")
    show NettieR04_09
    pause
    scene 21_0248 with dissolve
    net "[ss]..Ohhhh.."
    scene 21_0249 with dissolve
    image NettieR04_10 = Movie(play="images/e21/21_0250.webm")
    show NettieR04_10
    call Moan (net)
    scene 21_0251 with dis1
    scene 21_0252 with dis1
    pause 0.5
    scene 21_0253 with dissolve
    image NettieR04_11 = Movie(play="images/e21/21_0254.webm", loop=False, keep_last_frame=True)
    show NettieR04_11
    pause 2.0
    net "[ss]..Ohhhhh.."
    scene 21_0255 with dissolve
    image NettieR04_12 = Movie(play="images/e21/21_0256.webm")
    show NettieR04_12
    net "[ss]Ohhh."
    scene 21_0257 with dissolve
    image NettieR04_13 = Movie(play="images/e21/21_0258.webm")
    show NettieR04_13
    call Moan (net)
    scene 21_0259 with dissolve
    net "[ss]..Ohhhhh.."
    scene 21_0260 with dissolve
    image NettieR04_14 = Movie(play="images/e21/21_0261.webm")
    show NettieR04_14
    pause
    scene 21_0262 with dissolve
    net "[ss]...Ohhh, [persistent.McName]..."
    scene 21_0263 with dissolve
    image NettieR04_15 = Movie(play="images/e21/21_0264.webm")
    show NettieR04_15
    call Moan (net)
    scene 21_0265 with dissolve
    image NettieR04_16 = Movie(play="images/e21/21_0266.webm")
    show NettieR04_16
    pause
    scene 21_0267 with dissolve
    image NettieR04_17 = Movie(play="images/e21/21_0268.webm")
    show NettieR04_17
    net "[ss]..OHH, [persistent.McName!u].........OHHHHHH....."
    scene 21_0269 with dissolve
    image NettieR04_18 = Movie(play="images/e21/21_0270.webm")
    show NettieR04_18
    net "[ss]...OHHHH..."
    scene 21_0271 with dissolve
    image NettieR04_19 = Movie(play="images/e21/21_0272.webm")
    show NettieR04_19
    call Moan (net)
    scene 21_0273 with dissolve
    image NettieR04_20 = Movie(play="images/e21/21_0274.webm")
    show NettieR04_20
    net "[ss]......OHHHH........YES, BABY......"
    net "[ss].....OHHHHHHHH....."
    scene 21_0275 with dissolve
    net "[ss]..OHHHH, [persistent.McName!u]........YES......"
    scene 21_0276 with dissolve
    image NettieR04_21 = Movie(play="images/e21/21_0277.webm")
    show NettieR04_21
    call Moan (net)
    call CharCum ("e21/21_0278.webp", "e21/21_0279.webp", net, "...OHHHHHHHH...")
    call CharCum ("e21/21_0279.webp", "e21/21_0280.webp", net, "..Mmmmhhhhh..")
    scene 21_0281 with dissolve
    image NettieR04_22 = Movie(play="images/e21/21_0282.webm")
    show NettieR04_22
    net "[ss]Mmhhh."
    scene 21_0283 with dissolve
    net "[whi]Would you like to cum in my mouth?\nI know it's something that couples do."
    mc "[whi]Err.. Do {b}you{/b} want me to?\nI'm not sure you'd like it, Nettie."
    scene 21_0284 with dissolve
    net "[whi]We'll never know if I don't try it! But it's up to you, Baby."
    show NettieR04_22 with dis1
    net "[ss]..Mmhhh.."
    call CmOpts (["Cum in Nettie's mouth", "Keep fucking"])
    $ Copt=_return
    if Copt==0:
        call NettieReplay04_BJ
    else:
        call NettieReplay04_KeepGoing
    scene 21_0305 with Fade(2, 2, 1)
    net "[whi]..Zzzzz.."
    scene black with ReplayFade
return

label NettieReplay04_BJ:
    scene 21_0285 with dissolve
    mc "[whi]Tell me, Sister... do nun's swallow?"
    net "[whi]Hmmm... I don't know.\nLet's find out."
    scene 21_0286 with fade1
    image NettieR04_23 = Movie(play="images/e21/21_0287.webm")
    show NettieR04_23
    net "[ss]Mmhhh."
    scene 21_0288 with dissolve
    image NettieR04_24 = Movie(play="images/e21/21_0289.webm")
    show NettieR04_24
    pause
    scene 21_0290 with dissolve
    pause 0.5
    scene 21_0291 with dis1
    image NettieR04_25 = Movie(play="images/e21/21_0292.webm")
    show NettieR04_25
    mc "[whi]Fuuck...That's good..."
    scene 21_0293 with dissolve
    image NettieR04_26 = Movie(play="images/e21/21_0294.webm")
    show NettieR04_26
    net "[ss]Mmhhh."
    scene 21_0295 with dissolve
    image NettieR04_27 = Movie(play="images/e21/21_0296.webm")
    show NettieR04_27
    net "[ss]..Mmmhhh.."
    call CharCum ("e21/21_0295.webp", "e21/21_0297.webp", mc, "..Nnnnggghhhhh..")
    call CharCum ("e21/21_0297.webp", "e21/21_0298.webp", mc, "....Nnhhh....")
    scene 21_0299 with dissolve
    net "Mmmh mhh mm?!"
    mc "Huh? You can spit it out."
    scene 21_0300 with dissolve
    pause 0.5
    scene 21_0301 with dissolve
    call Gulp (net)
    scene 21_0302 with dis1
    scene 21_0303 with dis1
    pause 0.5
    scene 21_0304 with dis1
    net "Yes. {i}This{/i} nun swallows!"
return

label NettieReplay04_KeepGoing:
    scene 21_0306 with dissolve
    mc "[whi]My dick loves your pussy and has voted to stay, but how about you turn over so I can slip my tongue into your mouth instead?"
    scene 21_0307 with fade1
    net "[ss]..Mmhhh.."
    scene 21_0308 with dissolve
    image NettieR04_28 = Movie(play="images/e21/21_0309.webm")
    show NettieR04_28
    call Moan (net)
    scene 21_0310 with dissolve
    image NettieR04_29 = Movie(play="images/e21/21_0311.webm")
    show NettieR04_29
    pause
    scene 21_0312 with dissolve
    image NettieR04_30 = Movie(play="images/e21/21_0313.webm")
    show NettieR04_30
    call Moan (net)
    scene 21_0314 with dissolve
    image NettieR04_31 = Movie(play="images/e21/21_0315.webm")
    show NettieR04_31
    pause
    scene 21_0316 with dissolve
    net "[ss]..Mmhhh.."
    scene 21_0317 with fadehold
    image NettieR04_32 = Movie(play="images/e21/21_0318.webm")
    show NettieR04_32
    net "[ss]...OHHHH..."
    scene 21_0319 with dissolve
    net "[ss]..OHH, [persistent.McName!u]...YES........THAT'S SO GOOD...."
    net "[ss]...You're going to make me climax again......OHHH......"
    scene 21_0320 with dissolve
    image NettieR04_33 = Movie(play="images/e21/21_0321.webm")
    show NettieR04_33
    call Moan (net)
    scene 21_0322 with dissolve
    image NettieR04_34 = Movie(play="images/e21/21_0323.webm")
    show NettieR04_34
    net "[ss]...OHHHH, YES......"
    call Moan (net, 6)
    net "[ss]..OHHHHHHH, [persistent.McName!u].....OHHHH.."
    call CharCum ("e21/21_0322.webp", "e21/21_0324.webp", net, "...Ohhhhhhh...")
    scene 21_0325 with dissolve
    net "[ss]..Mmhhh.."
    scene 21_0326 with dissolve
    image NettieR04_35 = Movie(play="images/e21/21_0327.webm")
    show NettieR04_35
    pause
    call CmOpts (["Cum inside Nettie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Nettie.incCm()
        call CharCum ("e21/21_0326.webp", "e21/21_0328.webp", mc, "..Nnnnggghhhhh..")
        call CharCum ("e21/21_0328.webp", "e21/21_0329.webp", mc, "....Nnhhh....")
        scene 21_0330 with dissolve
        net "[ss]...Wow..."
        scene 21_0331 with dissolve
        net "[whi]I might have to dress-up for you more often!"
        scene 21_0332 with dissolve
        mc "[whi]I wouldn't complain!"
        mc "[whi]But c'mon, let's be honest - You'd make even a garbage bag look sexy if {b}you{/b} wore it!"
    else:
        call CharCum ("e21/21_0326.webp", "e21/21_0333.webp", mc, "..Nnnnggghhhhh..")
        call CharCum ("e21/21_0333.webp", "e21/21_0334.webp", mc, "....Nnhhh....")
        scene 21_0335 with dissolve
        net "[ss]...Wow..."
        scene 21_0336 with dissolve
        net "[whi]I might have to dress-up for you more often!"
        scene 21_0337 with dissolve
        mc "[whi]I wouldn't complain!"
        mc "[whi]But c'mon, let's be honest - You'd make even a garbage bag look sexy if {b}you{/b} wore it!"
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
