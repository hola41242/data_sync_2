label MelissaReplay01:
    call Unlocker ("MelissaReplay01")
    if _in_replay:
        scene 19_0700 with Fade(0,1,2)
    else:
        scene 19_0700 with dissolve
    mc "Hey.\nDawn said you wanted to see me?"
    meli "Hi... Yes."
    meli "Are you busy?"
    mc "Not right now. What's up?"
    meli "I was hoping... Umm..."
    scene 19_0701 with dissolve
    meli "... Can I kiss you again?"
    mc "Why?"
    scene 19_0702 with dissolve
    meli "I'd like to keep practicing."
    mc "You don't need to. You did fine!"
    scene 19_0703 with dissolve
    meli "I don't think I got my tongue movement right the last time... I'd like to try again."
    meli "Please?"
    scene 19_0704 with dis1
    scene 19_0705 with dis1
    mc "How can I say no when you ask so nicely?"
    scene 19_0706 with dis1
    scene 19_0707 with dis1
    mc "[kiss]"
    scene 19_0708 with dis1
    scene 19_0709 with dis1
    pause 0.5
    scene 19_0710 with dis1
    meli "[whi]Mmhhhh."
    scene 19_0711 with dissolve
    pause
    scene 19_0712 with dissolve
    meli "[whi]..Mmmhhhh.."
    scene 19_0713 with dis1
    mc "[whi]Tongue placement seems fine to me."
    scene 19_0714 with dissolve
    meli "[whi]I'm still not sure..."
    meli "[whi]I think we should try one more time."
    scene 19_0715 with dissolve
    meli "[whi]Mmmhhhh."
    scene 19_0716 with dissolve
    pause
    scene 19_0717 with dissolve
    meli "[whi]..Mmhhh.."
    $ aPs(-1, True)
    scene 19_0718 with dis1
    $ aPs()
    scene 19_0719 with dis1
    $ aPs()
    scene 19_0720 with dis1
    $ aPs()
    scene 19_0721 with dis1
    $ aPs()
    scene 19_0722 with dis1
    $ aPs(0, False, True)
    scene 19_0723 with dis1
    mc "[whi]Okay... What are you doing?"
    meli "[whi]Being passionate."
    scene 19_0724 with dissolve
    meli "[whi]... Am I doing it wrong?"
    mc "[whi]I thought you wanted to practice kissing?"
    meli "[whi]You said passion was a part of kissing."
    mc "[whi]Yeah... it is, but..."
    scene 19_0725 with dissolve
    meli "[whi]So shouldn't you be passionate with me, too?"
    mc "[whi]I thought I was!"
    mc "[whi]Do you want more?"
    meli "[whi]If you're asking me if I'd like you to hold my butt... or maybe even touch my breast..."
    scene 19_0726 with dissolve
    meli "[whi]Hell yeah!"
    scene 19_0727 with dissolve
    meli "[ss]Mmmhhhh."
    scene 19_0728 with dissolve
    pause
    scene 19_0729 with dissolve
    mct "Guess Dawn was right about her being horny!"
    scene 19_0730 with dis1
    pause 0.5
    scene 19_0731 with dis1
    meli "[ss]Mmmhhhh."
    scene 19_0732 with dissolve
    meli "[ss]..Mmhhh.."
    scene 19_0733 with dissolve
    $ aPs(0, True)
    scene 19_0734 with dis1
    $ aPs()
    scene 19_0735 with dis1
    $ aPs(0, False, True)
    scene 19_0736 with dis1
    meli "[ss]..Mmmhhhh.."
    scene 19_0737 with dissolve
    meli "[ss]..Mmhhh.."
    scene 19_0738 with dissolve
    pause
    scene 19_0739 with dissolve
    pause 0.5
    scene 19_0740 with dis1
    mc "[whi]Was that passionate enough for you?"
    meli "[ss]God, you're getting there..."
    scene 19_0739 with hpunch
    meli "[ss]..Mmmhhhh.."
    scene 19_0741 with dissolve
    pause 0.5
    scene 19_0742 with dis1
    scene 19_0743 with dis1
    scene 19_0744 with dis1
    pause
    scene 19_0745 with dissolve
    meli "[ss]..Mmhhh.."
    scene 19_0746 with dis1
    scene 19_0747 with dis1
    scene 19_0748 with dis1
    scene 19_0749 with dis1
    meli "[ss]..Mmmhhhh.."
    scene 19_0750 with dissolve
    pause 0.5
    scene 19_0751 with dis1
    scene 19_0752 with dis1
    scene 19_0753 with dis1
    pause 0.5
    scene 19_0754 with dissolve
    meli "[ss]..Mmhhh.."
    $ aPs(-1, True)
    scene 19_0755 with dis1
    $ aPs()
    scene 19_0756 with dis1
    $ aPs()
    scene 19_0757 with dis1
    $ aPs()
    scene 19_0758 with dis1
    $ aPs()
    scene 19_0759 with dis1
    $ aPs(0, False, True)
    scene 19_0780 with dis1
    pause
    scene 19_0781 with dissolve
    pause
    scene 19_0782 with dis1
    pause
    scene 19_0783 with dissolve
    meli "[ss]Mmhhh."
    scene 19_0784 with dissolve
    pause
    scene 19_0785 with dissolve
    $ aPs(0, True)
    scene 19_0786 with dis1
    $ aPs(1)
    scene 19_0787 with dis1
    $ aPs(1)
    scene 19_0788 with dis1
    $ aPs(1)
    scene 19_0789 with dis1
    $ aPs(1, False, True)
    scene 19_0790 with dis1
    meli "[ss]Ohhhhhh!"
    scene 19_0791 with dissolve
    image MelissaR01_01 = Movie(play="images/e19/19_0792.webm")
    show MelissaR01_01
    pause
    scene 19_0793 with dissolve
    call Moan (meli)
    scene 19_0794 with dis1
    scene 19_0795 with dis1
    image MelissaR01_02 = Movie(play="images/e19/19_0796.webm")
    show MelissaR01_02
    meli "[ss]Mmmhhh."
    scene 19_0797 with dissolve
    meli "[ss]Mmhhh."
    scene 19_0798 with dissolve
    image MelissaR01_03 = Movie(play="images/e19/19_0799.webm")
    show MelissaR01_03
    call Moan (meli)
    scene 19_0800 with dissolve
    call Moan (meli)
    mc "[whi]Was {b}this{/b} the kinda passion you wanted?"
    meli "[ss]Mmhhh....Fuck yes...."
    scene 19_0801 with dissolve
    meli "[ss]Mhhhh.... Don't stop yet, [persistent.McName]....Mhhhh..."
    call Moan (meli)
    scene 19_0802 with dissolve
    image MelissaR01_04 = Movie(play="images/e19/19_0803.webm")
    show MelissaR01_04
    meli "[ss]Ohhhh."
    mc "[whi]I'm not gonna stop until you orgasm."
    meli "[ss]...Okay..."
    scene 19_0804 with dissolve
    call Moan (meli)
    scene 19_0805 with dissolve
    image MelissaR01_05 = Movie(play="images/e19/19_0806.webm")
    show MelissaR01_05
    meli "[ss]...Ohhhhhh..."
    call Moan (meli, 6)
    image MelissaR01_06 = Movie(play="images/e19/19_0807.webm")
    show MelissaR01_06 with dis1
    meli "[ss]OHHHHH.."
    call Moan (meli, 8)
    meli "[ss]..Ohhh god....Yes...."
    meli "[ss]Ohhh, [persistent.McName]....Yes...."
    call CharCum ("e19/19_0808.webp", "e19/19_0809.webp", meli, "...Ohhhhhhhh my god...")
    call CharCum ("e19/19_0809.webp", "e19/19_0810.webp", meli, "....Ohhhhh.....")
    meli "[ss]...Wow..."
    scene 19_0811 with dissolve
    meli "[whi]You're a {b}really{/b} good kisser."
    call laugh (mc, "Thanks.")
    if _in_replay:
        scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
