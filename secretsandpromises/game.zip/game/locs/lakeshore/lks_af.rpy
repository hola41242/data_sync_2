label Lakeshore_AF01:
    scene 03_0896a
    hide screen imgMap
    $ _skipping = True
    $ Dawn.Score(1)
    scene 03_0897 with dissolve
    mc "You too."
    scene 03_0898 with dissolve
    pause
    scene 03_0899 with dissolve
    dawn "And if Sarah doesn't mind, you can stay here whenever you're in Lakeshore!"
    scene 03_0900 with dissolve
    sar "You're my best friend! Of course I don't mind!"
return

label Lakeshore_AF02:
    scene 11_0139
    hide screen imgMap
    $ _skipping = True
    $ Blaze.Score(1)
    $ Blaze.Add("Look")
    call ScanImage ("images/e11/11_0140.webp", 9)
    blz "Enjoying the view, Sir?"
return

label Lakeshore_AF03:
    scene 11_0449
    hide screen imgMap
    $ _skipping = True
    $ Blaze.Score(1)
    mc "Was just an excuse to do this..."
    scene 11_0450 with dissolve
    blz h "Ohh, I see."
    blz "Hmmm... Don't think I've ever knee'd you in the balls before..."
    scene 11_0451 with dissolve
    mc "You know what?..."
    mc "I think it'd be worth it! You have a fiiine butt!"
    scene 11_0452 with dissolve
    blz "[lol]"
    scene 11_0453 with dissolve
    blz "Get outta here before I kick your ass!"
    mc "Yes, Ma'am."
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
