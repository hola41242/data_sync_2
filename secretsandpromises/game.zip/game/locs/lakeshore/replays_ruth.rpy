label RuthReplay01:
    call Unlocker ("RuthReplay01")
    $ Ruth.isSexual(True)
    if _in_replay:
        scene 08_0071 with Fade(0, 1, 2)
        ruth "Do you know how many {b}decades{/b} have passed since I last had my vagina eaten?"
        scene 08_0072 with dissolve
        ruth "You asked what I wanted..."
        ruth "I want {i}you{/i} to get on your knees and devour me."
    scene 08_0073 with dissolve
    ruth "{b}That's{/b} my price."
    mc "Then that's what I'll pay."
    ruth "Good boy."
    scene 08_0074 with dissolve
    if not _in_replay:
        ruth "Come, Mommy's waiting."
        menu:
            "Don't call yourself that!":
                $ persistent.RuthPet=False
            "Yes Mom":
                $ persistent.RuthPet=True
    else:
        if persistent.RuthPet:
            ruth "Come, Mommy's waiting."
        else:
            ruth "On your knees."
    scene 08_0080 with dissolve
    ruth "Be gentle..."
    scene 08_0081 with dissolve
    ruth "She hasn't felt the touch of a man in a very long time."
    scene 08_0082 with dis1
    scene 08_0083 with dis1
    call Loop_Dissolve (4, False, False, "e08/08_0084.webp", "e08/08_0083.webp")
    scene 08_0085 with dissolve
    ruth "[ss]OHH, goodness!"
    scene 08_0086 with dissolve
    image r_ruth_01 = Movie(play="images/e08/08_0087.webm")
    show r_ruth_01
    call Moan (ruth)
    scene 08_0088 with dissolve
    $ dia = "Stop teasing " + ("Mommy. You know what she wants." if persistent.RuthPet else "me. You know what I want.")
    ruth "[dia]"
    scene 08_0089 with dis1
    scene 08_0090 with dis1
    ruth "[ss]OHHHHH!"
    scene 08_0091 with dissolve
    image r_ruth_02 = Movie(play="images/e08/08_0092.webm")
    show r_ruth_02
    call Moan (ruth)
    scene 08_0093 with dissolve
    ruth "[ss]OHHHHH...."
    scene 08_0094 with dissolve
    $ dia = "Yes..." + ("... Eat Mommy's pussy, my good boy!..." if persistent.RuthPet else " That's it... Eat my pussy...")
    ruth "[ss][dia]"
    scene 08_0095 with dissolve
    scene 08_0096 with dis1
    ruth "[ss]{size=*1.2}{b}OHHHHH!"
    scene 08_0097 with dissolve
    ruth "[ss]... HEAVENS ABOVE!..."
    ruth "[ss].....OHHHHH!!!...."
    scene 08_0098 with dissolve
    ruth "[ss]..OHHH, YES..."
    ruth "[ss]....YES......YES......"
    scene 08_0099 with dissolve
    call Moan (ruth, 8, True)
    scene 08_0100 with dissolve
    ruth "[ss]{size=*1.2}{b}...YES!..."
    ruth "[ss]{size=*1.2}{b}......YES!...GOD, YESSS!!....."
    scene 08_0101 with dissolve
    ruth "[ss].....Ohhh, my boy....."
    $ dia = "....Yes! ... Ohhh.... You've " + ("made Mommy happy!......" if persistent.RuthPet else "made me happy!......")
    ruth "[ss][dia]"
    call CharCum ("e08/08_0101.webp", "e08/08_0102.webp", ruth, "...MMMMMMMMHHHHHH!!....")
    call CharCum ("e08/08_0102.webp", "e08/08_0103.webp", ruth, "..OHHHHHHHH!!..")
    scene 08_0104 with dissolve
    ruth "[ss]Mmmmmhhhhhhhhh...."
    scene 08_0105 with dissolve
    call Emotion (mc, "Muffled", "{size=*.8}You can, uhh, release my head now!")
    scene 08_0106 with dissolve
    ruth "Oh, {i}must{/i} I?\nVery well, if you insist..."
    scene 08_0107 with dissolve
    ruth "I hope you enjoyed that as much as I."
    scene 08_0108 with dissolve
    ruth "She likes {i}you{/i}!"
    if _in_replay:
        scene black with ReplayFade
        return
    scene 08_0109 with dissolve
    mc "So we're good?\nI can move forward with the gym teacher?"
    ruth "Yes, as agreed. \nBut please, make sure she's at least competent for the role."
    scene 08_0110 with dissolve
    ruth "She has five days.\nIf you require more time... I'll require a bonus payment."
    scene 08_0111 with dissolve
    ruth "Which {i}could{/i} be paid in advance."
    scene 08_0112 with dissolve
    mc "Five days will work."
    scene 08_0079 with fade
    ruth "That was splendid!"
return

label RuthReplay02:
    call Unlocker ("RuthReplay02")
    $ Ruth.incSex()
    scene 11_0195 with fade
    pause 0.5
    scene 11_0196 with dis1
    scene 11_0197 with dis1
    ruth "Show me what my loyalty is worth."
    $ dia = "Yes, " + ("{i}Mom{/i}." if persistent.RuthPet else "Ma'am.")
    scene 11_0198 with dissolve
    mc "[dia]"
    if persistent.RuthPet:
        ruth "That's my good boy."
    scene 11_0199 with dissolve
    ruth "[ss]Mmhh."
    scene 11_0200 with dissolve
    ruth "[ss]..Mmmmhh.."
    scene 11_0201 with dissolve
    ruth "I don't recall the last time I sucked dick, but ever since our last encounter - I've been very much looking forward to sucking yours."
    scene 11_0202 with fade
    scene 11_0203 with dis1
    scene 11_0204 with dis1
    pause
    scene 11_0205 with dissolve
    scene 11_0206 with dis1
    scene 11_0207 with dis1
    ruth "[ss]..Mmmhh.."
    scene 11_0208 with dissolve
    pause
    scene 11_0209 with dissolve
    image RuthR02_01 = Movie(play="images/e11/11_0210.webm")
    show RuthR02_01
    ruth "[ss]..Mmmmhh.."
    scene 11_0211 with dissolve
    image RuthR02_02 = Movie(play="images/e11/11_0212.webm")
    show RuthR02_02
    ruth "[ss]..Mmhh.."
    scene 11_0213 with dissolve
    mc "You can take more than that."
    scene 11_0214 with dis1
    scene 11_0215 with dis1
    call Gag (ruth)
    scene 11_0216 with dis1
    image RuthR02_03 = Movie(play="images/e11/11_0217.webm")
    show RuthR02_03
    mc "That's more like it."
    scene 11_0218 with dissolve
    image RuthR02_04 = Movie(play="images/e11/11_0219.webm")
    show RuthR02_04
    ruth "[ss]..Mmmmhh.."
    scene 11_0220 with dissolve
    image RuthR02_05 = Movie(play="images/e11/11_0221.webm")
    show RuthR02_05
    ruth "[ss]..Mmhh.."
    scene 11_0222 with dissolve
    ruth "Enough foreplay."
    $ dia = "" + ("Mommy can't wait a moment longer to feel your magnificent cock inside her." if persistent.RuthPet else "I can't wait a moment longer to feel your magnificent cock inside me.")
    ruth "[dia]"
    $ dia = "Lie on the bed" + (", Son." if persistent.RuthPet else ".")
    ruth "[dia]"
    scene 11_0223 with dissolve
    pause
    scene 11_0224 with dissolve
    image RuthR02_06 = Movie(play="images/e11/11_0225.webm", loop=False, keep_last_frame=True)
    show RuthR02_06
    pause
    scene 11_0226 with dissolve
    ruth "Oh, heavens!\nI'd forgotten how good that feels!"
    scene 11_0227 with dissolve
    image RuthR02_07 = Movie(play="images/e11/11_0228.webm")
    show RuthR02_07
    ruth "[ss]..Ohh.."
    scene 11_0229 with dissolve
    image RuthR02_08 = Movie(play="images/e11/11_0230.webm")
    show RuthR02_08
    call Moan (ruth)
    scene 11_0231 with dissolve
    ruth "[ss]Ohh, my boy.... This is glorious!..."
    scene 11_0232 with dissolve
    image RuthR02_09 = Movie(play="images/e11/11_0233.webm")
    show RuthR02_09
    ruth "[ss]..Mmmmhhhhh.."
    scene 11_0234 with dissolve
    image RuthR02_10 = Movie(play="images/e11/11_0235.webm")
    show RuthR02_10
    call Moan (ruth)
    scene 11_0236 with dissolve
    if persistent.RuthPet:
        ruth "[ss]Oh, my sweet baby... Mommy didn't know she could still get so wet!..."
    else:
        ruth "[ss]Oh...you're making me so wet!..."
    scene 11_0237 with dissolve
    image RuthR02_11 = Movie(play="images/e11/11_0238.webm")
    show RuthR02_11
    call Moan (ruth)
    scene 11_0239 with dissolve
    mc "[whi]Fuck... Slow down, you're gonna make me cum.... "
    scene 11_0240 with dissolve
    image RuthR02_12 = Movie(play="images/e11/11_0241.webm")
    show RuthR02_12
    call Moan (ruth)
    scene 11_0242 with dissolve
    ruth "[ss]...Ohhh..."
    scene 11_0243 with dissolve
    image RuthR02_13 = Movie(play="images/e11/11_0244.webm")
    show RuthR02_13
    call Moan (ruth)
    scene 11_0245 with dissolve
    call AutoA
    $ apause()
    scene 11_0246 with dis1
    $ apause()
    call AutoA (False)
    scene 11_0247 with dissolve
    $ dia = "" + ("Oh Baby, yes... Suckle mommy..." if persistent.RuthPet else "Oh, yes... Suckle me, Baby.....")
    ruth "[ss][dia]"
    scene 11_0248 with dissolve
    ruth "[ss]Ohh, god... I can't contain myself...."
    scene 11_0249 with dissolve
    image RuthR02_14 = Movie(play="images/e11/11_0250.webm")
    show RuthR02_14
    call Moan (ruth, 8)
    call CharCum ("e11/11_0251.webp", "e11/11_0252.webp", ruth, "...OHHHHHHHH....")
    call CharCum ("e11/11_0252.webp", "e11/11_0253.webp", ruth, "..Mmmmmhhhhhh..")
    scene 11_0254 with dissolve
    ruth "[ss]That was wonderful!"
    $ dia = "Now, how would you like " + ("mommy" if persistent.RuthPet else "me")+" to milk you?"
    ruth "[ss][dia]"
    call CmOpts (["Cum inside Ruth", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        $ Ruth.incCm()
        scene 11_0255 with dissolve
        image RuthR02_15 = Movie(play="images/e11/11_0256.webm")
        show RuthR02_15
        if persistent.RuthPet:
            ruth "[ss]My sweet boy... Give Mommy your load..."
        else:
            ruth "[ss]..Mmmhh.."
        call CharCum ("e11/11_0255.webp", "e11/11_0257.webp", mc, "..Nnnnggghhhh..")
        scene 11_0258 with dissolve
        ruth "That was simply marvelous!\nYou must come back so we can do it again sometime!"
        scene 11_0259 with dissolve
        mc "You know what?..."
        scene 11_0260 with dissolve
    else:
        scene 11_0261 with fade
        ruth "[ss]..Mmhhh.."
        scene 11_0262 with dissolve
        image RuthR02_16 = Movie(play="images/e11/11_0263.webm")
        show RuthR02_16
        ruth "[ss]....Mmmmhhh...."
        call CharCum ("e11/11_0262.webp", "e11/11_0264.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e11/11_0264.webp", "e11/11_0265.webp", mc, "...Nnhhhh...")
        scene 11_0266 with dissolve
        ruth "That was simply marvelous!\nYou must come back so we can do it again sometime!"
        mc "You know what?..."
    mc "... Maybe I will."
    scene black with ReplayFade
return

label RuthReplay03:
    call Unlocker ("RuthReplay03")
    $ Ruth.incSex()
    scene 19_0475 with fade1
    pause 0.5
    scene 19_0476 with dis1
    if persistent.RuthPet:
        mct "Okay, let's give 'Mommy' a time to remember."
    scene 19_0477 with dis1
    scene 19_0478 with dis1
    pause 0.5
    scene 19_0479 with dissolve
    pause 0.5
    scene 19_0480 with dissolve
    if persistent.RuthPet:
        mc "I'm so lucky to have the most beautiful mom in the world!"
    else:
        mc "You look nervous."
    scene 19_0481 with dissolve
    if persistent.RuthPet:
        mc "Can I kiss you now, Mommy?"
        ruth "I'd like that very much... Son."
    else:
        mc "Just relax and enjoy it."
        ruth "It didn't go so well last time, but I'll try."
    scene 19_0482 with dis1
    mc "[kiss]"
    scene 19_0483 with dis1
    pause 0.5
    scene 19_0484 with dis1
    ruth "[whi]Mmhh."
    scene 19_0485 with dis1
    ruth "[whi]..Mmmhh.."
    scene 19_0486 with dissolve
    scene 19_0487 with dis1
    scene 19_0488 with dis1
    scene 19_0489 with dis1
    ruth "[whi]..Mmmmhh.."
    scene 19_0490 with dis1
    scene 19_0491 with dis1
    ruth "[ss]Mmhh."
    scene 19_0492 with dissolve
    ruth "[ss]..Mmhh.."
    scene 19_0493 with dissolve
    if persistent.RuthPet:
        ruth "[whi]Son, it's inappropriate to touch your mother that way."
        mc "[whi]I'm sorry, Mommy. I can't help it.\nI think about touching you {b}all the time{/b}."
        scene 19_0494 with dissolve
        ruth "[whi]Oh, my beautiful, dirty boy... You mustn't!"
        ruth "[whi]Come. We must purge these wicked thoughts!"
    else:
        ruth "[whi]Can we sit? My legs are like jelly."
    scene 19_0495 with fade
    if persistent.RuthPet:
        ruth "[whi]What other naughty thoughts of me have you had, my boy?"
        scene 19_0496 with dissolve
        mc "[whi]I thought about touching your sexy legs..."
        scene 19_0497 with dissolve
        mc "[whi]Moving my hand up your soft, warm thigh..."
        mc "[whi]Open your legs for me, Mommy. I want to play with it."
        ruth "[whi]Son... No..."
        mc "[whi]Don't you love me, Mommy?"
        scene 19_0498 with dissolve
        ruth "[whi]Of course I love you. You're my baby!"
        scene 19_0499 with dis1
        scene 19_0500 with dis1
        mc "[whi]Why aren't you wearing panties, Mom?"
        ruth "[whi]I... I took them off, Son."
        scene 19_0501 with dissolve
        mc "[whi]For me, Mommy?\nSo I could play with kitty?"
        scene 19_0502 with dissolve
        ruth "[whi]...Yes."
        mc "[whi]I love you, Mommy!"
    else:
        mc "[whi]Better?"
        ruth "[whi]Yes. Thank you."
        scene 19_0496 with dissolve
        mc "[whi]Are your legs feeling better?"
        scene 19_0497 with dis1
        scene 19_0498 with dis1
        ruth "[whi]...Yes."
        scene 19_0499 with dis1
        scene 19_0500 with dis1
        pause 0.5
        scene 19_0502 with dissolve
        mc "[whi]Are you ready to fuck?"
    scene 19_0503 with hpunch
    ruth "[ss]MMMHHHHH."
    scene 19_0501 with dissolve
    pause 0.5
    scene 19_0504 with dis1
    pause 0.5
    scene 19_0505 with dissolve
    pause 0.5
    scene 19_0506 with dis1
    scene 19_0507 with dis1
    ruth "[ss]..Mmmhh.."
    scene 19_0508 with dissolve
    ruth "[ss]Mmmhhhh."
    scene 19_0509 with dissolve
    image RuthR03_01 = Movie(play="images/e19/19_0510.webm")
    show RuthR03_01
    call Moan (ruth)
    scene 19_0511 with dissolve
    pause 0.5
    scene 19_0512 with dis1
    scene 19_0513 with dis1
    pause 0.5
    scene 19_0514 with dissolve
    ruth "[ss]..MMMHHH.."
    scene 19_0515 with dissolve
    image RuthR03_02 = Movie(play="images/e19/19_0516.webm")
    show RuthR03_02
    call Moan (ruth)
    scene 19_0517 with dissolve
    ruth "[ss]..Mmmhh.."
    scene 19_0518 with dis1
    if persistent.RuthPet:
        ruth "[whi]Will you be a good boy for Mommy and kiss kitty?"
    else:
        mc "[whi]Have you ever tasted yourself?"
        ruth "[whi]No."
    scene 19_0519 with dis1
    scene 19_0520 with dis1
    if persistent.RuthPet:
        mc "[whi]Will I like the taste, Mommy?"
        scene 19_0521 with dis1
        ruth "[ss]Mmhh."
        scene 19_0522 with dis1
        ruth "[whi]Yes, Son. She's delicious."
        scene 19_0523 with dis1
        mc "[whi]But Mom, I'm hungry... Can you feed me first?"
        scene 19_0524 with dis1
        scene 19_0525 with dis1
        ruth "[whi]What sort of mother would I be to leave my special boy to go hungry?"
    else:
        mc "[whi]You should."
        scene 19_0521 with dis1
        ruth "[ss]Mmhh."
        scene 19_0522 with dis1
        ruth "[whi]Delicious."
        scene 19_0523 with dis1
        mc "[whi]Every inch of you is delicious."
        scene 19_0524 with dis1
        scene 19_0525 with dis1
        ruth "[whi]And every inch is yours."
    scene 19_0526 with dis1
    ruth "[ss]Ohhh."
    scene 19_0527 with dissolve
    image RuthR03_03 = Movie(play="images/e19/19_0528.webm")
    show RuthR03_03
    call Moan (ruth)
    scene 19_0529 with dissolve
    image RuthR03_04 = Movie(play="images/e19/19_0530.webm")
    show RuthR03_04
    call Moan (ruth)
    scene 19_0531 with dissolve
    pause 0.5
    scene 19_0532 with dis1
    scene 19_0533 with dis1
    scene 19_0534 with dis1
    scene 19_0535 with dis1
    scene 19_0536 with dis1
    ruth "[ss]..OHHHHHH.."
    scene 19_0538 with dissolve
    image RuthR03_05 = Movie(play="images/e19/19_0539.webm")
    show RuthR03_05
    pause
    scene 19_0537 with dissolve
    ruth "[ss]..OHHH LORD.."
    scene 19_0538 with dissolve
    image RuthR03_06 = Movie(play="images/e19/19_0540.webm")
    show RuthR03_06
    pause
    scene 19_0541 with dissolve
    call Moan (ruth)
    if persistent.Anal:
        scene 19_0542 with dis1
        scene 19_0543 with dis1
        scene 19_0544 with dis1
        if persistent.RuthPet:
            ruth "[whi]What are you doing to Mommy?"
            scene 19_0545 with dis1
            call EmotionSml (ruth, "Gasp", "My dirty boy!")
        else:
            ruth "[whi]What are you doing?"
            scene 19_0545 with dis1
            call EmotionSml (ruth, "Gasp")
        scene 19_0546 with dissolve
        image RuthR03_07 = Movie(play="images/e19/19_0547.webm")
        show RuthR03_07
        pause
        scene 19_0548 with dissolve
        pause
        scene 19_0549 with dissolve
        ruth "[ss]..OHH MY.."
        scene 19_0550 with dissolve
        call Moan (ruth)
    scene 19_0551 with dissolve
    if persistent.RuthPet:
        mc "[whi]Mommy, my PP's throbbing; it hurts!"
        scene 19_0552 with dis1
        ruth "[whi]My poor boy!"
        scene 19_0553 with dis1
        ruth "[whi]Would you like Mommy to kiss it better?"
        mc "[whi]Yes, please."
    else:
        pause 0.5
        scene 19_0552 with dis1
        scene 19_0553 with dis1
    scene 19_0554 with dis1
    scene 19_0555 with dis1
    scene 19_0556 with dis1
    image RuthR03_09 = Movie(play="images/e19/19_0559.webm")
    scene 19_0557 with dissolve
    image RuthR03_08 = Movie(play="images/e19/19_0558.webm", loop=False, keep_last_frame=True)
    show RuthR03_08
    pause 1.0
    ruth "[whi][kiss]"
    pause 3.5
    show RuthR03_09
    ruth "[ss]Mmhh."
    scene 19_0560 with dissolve
    image RuthR03_10 = Movie(play="images/e19/19_0561.webm")
    show RuthR03_10
    pause
    scene 19_0562 with dissolve
    image RuthR03_11 = Movie(play="images/e19/19_0563.webm")
    show RuthR03_11
    ruth "[ss]..Mmmmhh.."
    scene 19_0564 with dissolve
    if persistent.RuthPet:
        ruth "[whi]Better, Son?"
        mc "[whi]A little."
        mc "[whi]I'd like kitty to kiss it, too."
        ruth "[whi]... Very well."
    else:
        mc "[whi]I'm going to fuck you now, Ruth."
        ruth "[whi]Okay."
    scene 19_0565 with fadehold
    pause 0.5
    scene 19_0566 with dissolve
    if persistent.RuthPet:
        mc "[whi]I'm going to fuck you now, Mom."
        ruth "[whi]Good boy."
    else:
        pause
    scene 19_0567 with dissolve
    image RuthR03_12 = Movie(play="images/e19/19_0568.webm", loop=False, keep_last_frame=True)
    show RuthR03_12
    pause 1.5
    ruth "[ss]Mmhh.{w=1}{nw}"
    ruth "[ss]..Ohhhh.."
    scene 19_0569 with dissolve
    image RuthR03_13 = Movie(play="images/e19/19_0570.webm")
    show RuthR03_13
    ruth "[ss]Ohhh."
    scene 19_0571 with dissolve
    image RuthR03_14 = Movie(play="images/e19/19_0572.webm")
    show RuthR03_14
    call Moan (ruth)
    scene 19_0573 with dissolve
    ruth "[ss]Mmhhh.... Wonderful...."
    scene 19_0574 with dis1
    scene 19_0575 with dis1
    pause 0.5
    scene 19_0576 with dissolve
    if persistent.RuthPet:
        mc "[whi]Look at me while I fuck you, Mom."
    else:
        mc "[whi]Look at me while I fuck you."
    scene 19_0577 with dissolve
    image RuthR03_15 = Movie(play="images/e19/19_0578.webm")
    show RuthR03_15
    call Moan (ruth)
    scene 19_0579 with dissolve
    if persistent.RuthPet:
        ruth "[ss]Ohhh....My beautiful boy.... Slow down...You'll make Mommy climax too quickly again..."
    else:
        ruth "[ss]Ohhh.... Slow down... I'll climax too quickly again...."
    scene 19_0580 with dissolve
    image RuthR03_16 = Movie(play="images/e19/19_0581.webm")
    show RuthR03_16
    if persistent.RuthPet:
        mc "[whi]I {b}want{/b} you to cum for me, Mommy."
        mc "[whi]I want to hear you moan and scream."
    else:
        mc "[whi]Cum for me, Ruth."
    ruth "[ss]..OHHH.."
    scene 19_0582 with dissolve
    image RuthR03_17 = Movie(play="images/e19/19_0583.webm")
    show RuthR03_17
    call Moan (ruth, 7)
    scene 19_0584 with dissolve
    image RuthR03_18 = Movie(play="images/e19/19_0585.webm")
    show RuthR03_18
    ruth "[ss]OHHHH.....GOD....."
    if persistent.RuthPet:
        ruth "[ss]...SON, WAIT!....I'M GOING TO......OHHHHHHHH....."
    else:
        ruth "[ss]...[mc!u], WAIT!....I'M GOING TO......OHHHHHHHH....."
    call CharCum ("e19/19_0584.webp", "e19/19_0586.webp", ruth, "...OHHHHHHHH....")
    call CharCum ("e19/19_0586.webp", "e19/19_0587.webp", ruth, "....Ohhhhh....")
    scene 19_0588 with dissolve
    ruth "[whi]Ohh, you bad boy!\nI said slow down! I climaxed even faster than the last time!"
    mc "[whi]I wanted you to get it out of your system."
    if persistent.RuthPet:
        mc "[whi]Welcome to the new world, Mom."
    else:
        mc "[whi]Welcome to the new world."
    scene 19_0589 with dissolve
    image RuthR03_19 = Movie(play="images/e19/19_0590.webm")
    show RuthR03_19
    mc "[whi]It's a world where you're allowed more than one orgasm per session."
    mc "[whi]Now we're {b}really{/b} gonna fuck."
    scene 19_0591 with dissolve
    if persistent.RuthPet:
        ruth "[whi]My perfect boy."
    else:
        ruth "[whi]Then what are you waiting for?"
    scene 19_0592 with dissolve
    ruth "[ss]Mmmhhh."
    scene 19_0593 with dissolve
    image RuthR03_20 = Movie(play="images/e19/19_0594.webm")
    show RuthR03_20
    ruth "[ss]..Mmhhh.."
    scene 19_0595 with dissolve
    image RuthR03_21 = Movie(play="images/e19/19_0596.webm")
    show RuthR03_21
    ruth "[ss]Mmmmhhh."
    scene 19_0597 with dissolve
    ruth "[ss]..Mmhhh.."
    scene 19_0598 with dissolve
    image RuthR03_22 = Movie(play="images/e19/19_0599.webm")
    show RuthR03_22
    call Moan (ruth)
    scene 19_0600 with dissolve
    image RuthR03_23 = Movie(play="images/e19/19_0601.webm")
    show RuthR03_23
    ruth "[ss]..Ohhh.."
    scene 19_0602 with dissolve
    image RuthR03_24 = Movie(play="images/e19/19_0603.webm")
    show RuthR03_24
    pause
    scene 19_0604 with dissolve
    if persistent.RuthPet:
        ruth "[ss]Ohh, my boy.....Fuck Mommy hard.....Yes...."
    else:
        ruth "[ss]...Ohh, [persistent.McName]... Yes.......Fuck me hard......."
    scene 19_0605 with dissolve
    image RuthR03_25 = Movie(play="images/e19/19_0606.webm")
    image RuthR03_26 = Movie(play="images/e19/19_0607.webm", loop=False, keep_last_frame=True)
    image RuthR03_27 = Movie(play="images/e19/19_0608.webm")
    show RuthR03_25
    call Moan (ruth)
    show RuthR03_26
    pause 2.0
    show RuthR03_27
    ruth "[ss]....OHHH....YES...."
    if persistent.RuthPet:
        ruth "[ss]...FUCK ME, SON....."
    else:
        ruth "[ss].......YES, [mc!u].......FUCK, YES...."
    scene 19_0611 with dissolve
    image RuthR03_29 = Movie(play="images/e19/19_0612.webm")
    show RuthR03_29
    call Moan (ruth, 6)
    scene 19_0609 with dissolve
    image RuthR03_28 = Movie(play="images/e19/19_0610.webm")
    show RuthR03_28
    ruth "[ss]....OHHHHHHH...."
    ruth "[ss]...YES......OHHHHH........HEAVENS, YES!......"
    call CharCum ("e19/19_0609.webp", "e19/19_0613.webp", ruth, "...OHHHHHHHH....")
    call CharCum ("e19/19_0613.webp", "e19/19_0614.webp", ruth, "....Ohhhhh....")
    scene 19_0615 with dissolve
    image RuthR03_30 = Movie(play="images/e19/19_0616.webm")
    show RuthR03_30
    ruth "[ss]...My, oh my!..."
    ruth "[ss]I love this new world of yours!"
    ruth "[ss]...Mmhhh..."
    scene 19_0617 with dissolve
    mc "[whi]I'm not quite done with you yet."
    ruth "[whi]... You're not?"
    mc "[whi]Not until I've cum, too."
    if persistent.RuthPet:
        mc "[whi]Turn over, Mommy."
    else:
        mc "[whi]Turn over."
    scene 19_0618 with fade1
    ruth "[ss]OHHHHH."
    scene 19_0619 with dissolve
    image RuthR03_31 = Movie(play="images/e19/19_0620.webm")
    show RuthR03_31
    call Moan (ruth, 6)
    scene 19_0621 with dissolve
    image RuthR03_32 = Movie(play="images/e19/19_0622.webm")
    show RuthR03_32
    ruth "[ss]...Ohhhhhh...."
    pause
    if persistent.Anal:
        call CmOpts (["Cum inside Ruth", "Pull out", "Fuck Ruth in the ass"])
    else:
        call CmOpts (["Cum inside Ruth", "Pull out"])
    $ Copt=_return
    $ a=""
    if Copt==0:
        $ Ruth.incCm()
        call CharCum ("e19/19_0621.webp", "e19/19_0623.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e19/19_0623.webp", "e19/19_0624.webp", mc, "..Nnnhhh..")
        scene 19_0625 with dissolve
        ruth "[ss]Aaahh."
        scene 19_0626 with dissolve
        ruth "[ss]Mmhhhh."
        scene 19_0627 with dissolve
        pause
        scene 19_0628 with dissolve
        ruth "[whi]Mmhhh. That was magnificent.\nSimply magnificent!"
        $ a="a"
    elif Copt==2:
        $ Ruth.Add("A01")
        scene 19_0632 with dissolve
        pause 0.5
        scene 19_0633 with dis1
        scene 19_0634 with dissolve
        image RuthR03_33 = Movie(play="images/e19/19_0635.webm", loop=False, keep_last_frame=True)
        show RuthR03_33
        pause 2.0
        ruth "[ss]..What the...{w=2}{nw}"
        pause 0.5
        ruth "[ss]...OHHHHH!"
        scene 19_0636 with dissolve
        image RuthR03_34 = Movie(play="images/e19/19_0637.webm")
        show RuthR03_34
        ruth "[ss]..Fuuuuck.."
        if persistent.RuthPet:
            mc "[whi]You like having your son's hard dick in your ass, Mommy?"
            scene 19_0638 with dissolve
            ruth "[ss]Ngghh...Yes, I love my son fucking me in any hole he wants...."
        else:
            mc "[whi]You like my hard dick in your ass, don't you, Ruth?"
            scene 19_0638 with dissolve
            ruth "[ss]Ngghh...Yes..."
        scene 19_0639 with dissolve
        image RuthR03_41 = Movie(play="images/e19/19_0640.webm")
        show RuthR03_41
        ruth "[ss]..Ohhhhh.."
        scene 19_0641 with dissolve
        image RuthR03_35 = Movie(play="images/e19/19_0642.webm")
        show RuthR03_35
        call Moan (ruth)
        if persistent.RuthPet:
            mc "[whi]Damn, Mommy... Your asshole's so tight... is this your first time?"
            ruth "[ss]Yes, my horny little rascal .....Ohhhh..."
        else:
            mc "[whi]Damn... Your asshole's so tight... is this your first time?"
            ruth "[ss]...Yes....Ohhhh....."
        scene 19_0643 with dissolve
        image RuthR03_36 = Movie(play="images/e19/19_0644.webm")
        show RuthR03_36
        call Moan (ruth)
        pause
        call CmOpts (["Cum inside Ruth", "Pull out"])
        $ Copt2=_return
        if Copt2==0:
            call CharCum ("e19/19_0643.webp", "e19/19_0645.webp", mc, "..Nnnnggghhhh..")
            call CharCum ("e19/19_0645.webp", "e19/19_0646.webp", mc, "..Nnnhhh..")
            scene 19_0647 with dissolve
            ruth "[ss]FUUUUCK!!"
            scene 19_0648 with dissolve
            pause
            scene 19_0649 with dissolve
            ruth "[whi]Goodness me! I think you punctured a lung!"
            call laugh (mc, "Sorry.")
        else:
            call CharCum ("e19/19_0643.webp", "e19/19_0650.webp", mc, "..Nnnnggghhhh..")
            call CharCum ("e19/19_0650.webp", "e19/19_0651.webp", mc, "..Nnnhhh..")
            scene 19_0652 with dissolve
            ruth "[whi]Mmhhh. That was magnificent.\nSimply magnificent!"
    else:
        call CharCum ("e19/19_0621.webp", "e19/19_0629.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e19/19_0629.webp", "e19/19_0630.webp", mc, "..Nnnhhh..")
        scene 19_0631 with dissolve
        ruth "[whi]Mmhhh. That was magnificent.\nSimply magnificent!"
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
