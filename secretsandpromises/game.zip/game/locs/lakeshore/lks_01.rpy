label Lakeshore_Start1A:
    $ persistent.lakeshore_active=True
    $ curLOC=lakeshore_id
    call CenterText ("A long bus journey later.", True)
    call Lakeshore_MeetRuth
    mct "Probably still time to get straight back on a bus to Springhaven."
    $ curLOC=springhaven_id
return

label Lakeshore_Start1B:
    $ persistent.lakeshore_active=True
    $ curLOC=lakeshore_id
    call CenterText ("A few hours later.")
    scene 03_0260 with fade
    bill "We're here."
    scene 03_0261 with fade
    bill "Hey! Sleeping Beauty!"
    scene 03_0262 with dissolve
    pause 0.5
    scene 03_0263 with dissolve
    mc "Ughh... Sorry, Bill. Must've dozed off for a minute."
    bill "Son, you were snoring before we'd even left Springhaven![lol]"
    scene 03_0264 with dissolve
    bill "C'mon, gimme a hand to unhook the trailer."
    mc "Uh, sure."
    scene 03_0265 with dissolve
    call Emotion (bill, "Whistling")
    scene 03_0266 with dissolve
    mc "You just leave this thing here?"
    bill "Yup."
    scene 03_0267 with dissolve
    bill "I'll come back later to pick it up."
    scene 03_0268 with dissolve
    mc "What {b}is{/b} this place?"
    bill "What's with all the questions??"
    bill "I get paid to deliver it here.\nThat's all I care about. End of story, Son!"
    scene 03_0269 with dissolve
    bill "Do you need to be dropped off somewhere?"
    mc "Uh, yeah. Any idea where I can find the college?"
    bill "Yeah, you're almost there already!"
    scene 03_0270 with dissolve
    bill "You'll find it around the corner, back that way."
    mc "Great!"
    scene 03_0271 with dissolve
    bill "I don't know how long you're planning on stayin'..."
    bill "I'll be heading back to Springhaven in around four hours."
    mc "Might be enough time for me to do what I need to do..."
    scene 03_0272 with dissolve
    bill "Okay, but I can't be hanging around waitin' for ya, Son!"
    bill "Need to get back home, got another run to do later."
    mc "Understood. Thanks, Bill."
    call Lakeshore_MeetRuth
    scene 03_0325 with Fade(1, 1, 2)
    mct "Guess I'll hang around and wait for Bill."
    scene 03_0326 with dissolve
    mct "Doesn't seem to be anyone else here."
    scene 03_0327 with dissolve
    pause 0.5
    play sound "clang.mp3"
    scene 03_0328 with dissolve
    pause 0.2
    scene 03_0327 with Dissolve(0.1)
    pause 0.1
    scene 03_0328 with dissolve
    mct "Hmm, already been emptied."
    scene 03_0329 with dissolve
    mct "Parks it up in an abandoned depot and leaves."
    mct "Returns a few hours later, and it's magically been emptied?"
    scene 03_0330 with Fade(3, 2, 1)
    bill "[mc]?"
    play sound "kick01.mp3"
    scene 03_0331 with dissolve
    scene 03_0332 with dissolve
    bill "Hey!"
    scene 03_0333 with dissolve
    bill "Let's go!"
    scene 03_0334 with dissolve
    bill "Unlike you, I don't have the time to sleep![lol]"
    scene black with Fade(3, 1, 0)
    $ curLOC=springhaven_id
    jump Springhaven_MaryReunion
return

label Lakeshore_Start1C:
    $ persistent.lakeshore_active=True
    $ curLOC=lakeshore_id
    scene 03_0538 with Fade(2, 1, 1)
    pause 0.5
    play sound "car.mp3" volume 0.3
    scene 03_0539 with dis1
    pause 0.5
    scene 03_0540 with dis1
    pause 0.5
    play sound "driving.mp3" loop volume 0.3
    scene 03_0541 with dissolve
    mc "Your friend... uhh... Debbie, was it?"
    sar "Dawn."
    mc "Right. Dawn."
    mc "Another crisis?"
    scene 03_0542 with dissolve
    sar "Yeah."
    sar "I'm beginning to worry for her, to be honest."
    mc "Why?"
    scene 03_0543 with dissolve
    sar "She's {i}always{/i} been a bit of a drama queen, but... I don't know..."
    sar "I've never known her to be paranoid."
    scene 03_0544 with dissolve
    sar "She's convinced someone's been following her for the last few days!"
    mc "You don't believe her?"
    sar "No, I'm not saying...."
    scene 03_0545 with dissolve
    sar "She's probably noticed someone {b}innocently{/b} walking in the same direction for a few blocks and concluded that they're stalking her!"
    mc "That's quite a leap."
    scene 03_0546 with dissolve
    sar "Exactly!"
    mc "Yet, here you are - driving to Lakeshore, again."
    scene 03_0547 with dissolve
    sar "She's my best friend, and she needs my support."
    sar "I managed to get the day off work, so I'll stay with her tonight, but I'll have to leave super early in the morning!"
    scene 03_0548 with dissolve
    pause 0.5
    play sound "car.mp3" volume 0.3
    scene 03_0549 with dis1
    pause 0.5
    scene 03_0550 with dis1
    pause 0.5
    play sound "driving.mp3" loop volume 0.3
    scene 03_0551 with dissolve
    sar "What's your reason for heading back to Lakeshore?"
    pause 2.0
    scene 03_0552 with dissolve
    sar "[mc]?"
    scene 03_0553 with dissolve
    pause 0.5
    scene 03_0554 with dissolve
    mc "[whi]..Zzzz.."
    scene 03_0555 with dissolve
    pause 0.5
    scene 03_0556 with dissolve
    pause 0.5
    play sound "car.mp3" volume 0.3
    scene 03_0557 with dis1
    pause 0.5
    scene 03_0558 with dis1
    pause 0.5
    scene 03_0555 with dissolve
    pause 0.5
    scene 03_0559 with fade3
    pause 0.5
    scene 03_0560 with dissolve
    sar "[whi][mc]?"
    scene 03_0561 with dissolve
    sar "We're here."
    scene 03_0562 with dissolve
    call Emotion (mc, "Groan")
    mc "Sorry, must've dozed off for a minute."
    sar "Yeah, I guess so. [lol]"
    scene 03_0563 with dissolve
    sar "Want to come in and meet Dawn?"
    mc "Err..."
    sar "Come on.\nHave a coffee with us before you go off."
    mc "Okay, sure."
    scene 03_0564 with Fade(3, 1, 3)
    play sound "knock.mp3"
    pause 0.5
    scene 03_0565 with dissolve
    pause 2.0
    scene 03_0566 with dissolve
    pause 0.5
    scene 03_0567 with dissolve
    pause 0.5
    scene 03_0568 with dissolve
    dawn "You made it!"
    scene 03_0569 with dissolve
    sar "Of course!"
    scene 03_0570 with dissolve
    sar "Dawn, I'd like you to meet [mc]."
    mc "Hi."
    $ persistent.DawnLocked=False
    $ Dawn.Activate("Dawn")
    scene 03_0571 with dissolve
    dawn "Ooh, is this your soldier?"
    dawn "Nice to meet you!"
    scene 03_0572 with dissolve
    dawn "Come on in, guys!"
    scene 03_0573 with fade1
    dawn "Please excuse the shitty apartment, [mc]!\nIt's only temporary, until I find somewhere else."
    scene 03_0574 with dissolve
    dawn "Here you go."
    mc "Thanks."
    scene 03_0575 with dissolve
    sar "Before you sit down..."
    sar "I know I didn't tell you [mc] was coming. If you want to go change, we don't mind waiting."
    scene 03_0576 with dissolve
    dawn "Oh Sarah, relax!"
    scene 03_0577 with dissolve
    dawn "I'm wearing shorts![lol]"
    scene 03_0578 with dissolve
    sar "You want to tell me what happened?"
    dawn "Nothing {i}happened{/i}..."
    scene 03_0579 with dissolve
    dawn "He just kept following me."
    dawn "Whenever I stopped, he'd stop, too."
    scene 03_0580 with dissolve
    dawn "I walked into the mall, and it was busy. Eventually, he lost me."
    scene 03_0581 with dissolve
    mc "Have you seen him since?"
    dawn "No."
    scene 03_0582 with dissolve
    dawn "You think I'm crazy, don't you?"
    scene 03_0583 with dissolve
    sar "No one thinks you're crazy, Dawn!"
    scene 03_0584 with dissolve
    mc "Did you recognize the guy? Have you ever seen him before?"
    dawn "No."
    sar "If you see him following you again, call the police!"
    scene 03_0585 with dissolve
    dawn "I will. Promise."
    dawn "Jeez... maybe you're right... was I panicking over nothing??"
    scene 03_0586 with dissolve
    mc "To be honest, no, I don't think you were."
    mc "When you're walking around, how often do you think someone's following you?"
    dawn "Never. Until now, at least."
    mc "Yeah, exactly.\nThe fact is, you spotted this guy and your gut told you something wasn't right."
    mc "Trust your instincts.\nAnd follow Sarah's advice - If you see him again, stay in a crowded area and call the cops."
    scene 03_0587 with dissolve
    dawn "Okay. Thank you. Both of you."
    dawn "Thanks for believing me and not calling me nuts.\nI feel better for knowing that."
    if EzModeActive:
        call EzModeAsk ("Dawn")
        if _return:
            $ Dawn.Add("EZ")
    scene 03_0588 with dissolve
    sar "You know I'm {b}always{/b} here for you, Dawn!"
    dawn "Yes, I know.\nYou're the best friend a girl could ask for!"
    scene 03_0589 with dissolve
    mc "Thanks for the coffee, Dawn.\nI'm gonna get going..."
    if Sarah.Has("Nobed") or Sarah.isSexual():
        scene 03_0590 with dissolve
        dawn "Not so fast, Mister!"
        dawn "I have a question for {i}you{/i}!"
        mc "Uhh... Okay..."
        scene 03_0591 with dissolve
        if Sarah.Has("Nobed"):
            dawn "Why did you turn down Sarah's offer to share her bed?"
            scene 03_0592 with dissolve
            sar "DAWN!!"
            scene 03_0593 with dissolve
            dawn "I'm curious![lol]"
            menu:
                "Just want to be friends [wk_c]":
                    call CloseCharacterPath (Sarah, "Sarah")
                    mc "She's a lovely girl, and I'd like us to be friends, but nothing more."
                    dawn "Oh, okay. That's fair enough, I guess."
                    sar "I'm sorry, [mc]. She can be so rude sometimes!"
                "[wk_y]I was being a gentleman!":
                    $ Sarah.Add("L0")
                    mc "It was difficult, believe me!\nI was trying to play it cool."
                    scene 03_0594 with dissolve
                    dawn "That's very admirable!\nThere aren't many guys like you left!"
        else:
            $ Sarah.Add("L1")
            dawn "Did Sarah {i}really{/i} sexually assault you in her bed?"
            scene 03_0592 with dissolve
            sar "DAWN!!"
            scene 03_0593 with dissolve
            dawn "[lol]"
            if persistent.GroupSex and persistent.Lez:
                scene 03_0594 with dissolve
                dawn "Don't worry, [mc]!\nYou're not the first person she's abused!"
                dawn "She did the same to me when we were at college together!"
                scene 03_0595 with dissolve
                sar "OH MY GOD!"
                sar "We were both drunk!!"
                scene 03_0596 with dissolve
                sar "And, as I recall... it was {b}you{/b} who started it!"
                scene 03_0597 with dissolve
                dawn "Yeah, that {i}is{/i} true..."
                dawn "... But she still ravaged me![lol]"
                scene 03_0598 with dissolve
                sar "You did plenty of ravaging!"
                if not EzModeActive:
                    menu:
                        "[wk_y]Damn, wish I could've been there!":
                            $ Sarah.Add("3S")
                        "Sounds like you had fun!":
                            pass
                elif Dawn.Has("EZ"):
                    $ Sarah.Add("3S")
                scene 03_0599 with dissolve
                sar "[lol]\nYou know what college is like! It only happened once!"
                dawn "[lol]"
            else:
                scene 03_0594 with dissolve
                dawn "Sorry! It's just hard to believe!"
                dawn "That doesn't sound like Sarah {b}at all{/b}!"
                scene 03_0595 with dissolve
                sar "OH MY GOD! PLEASE STOP TALKING!"
                scene 03_0597 with dissolve
                dawn "You haven't denied it, so I'll presume it {i}really{/i} did happen![lol]"
    else:

        call CloseCharacterPath (Sarah)
    scene 03_0600 with dissolve
    mc "I'd better get going."
    sar "How long are you thinking of staying?\nYou're welcome to join me on the ride home tomorrow."
    mc "I'm not sure yet, but yeah, I may be able to make it."
    scene 03_0601 with dissolve
    sar "Call me and let me know."
    mc "I, err... left my cell at home."
    sar "Oh.\nOkay, well... I'll be leaving around 5 AM if you can get here before then."
    mc "Okay, great."
    scene 03_0602 with dissolve
    dawn "Where are you staying?"
    mc "Uhh... I'll find..."
    sar "No! Don't tell me..."
    scene 03_0603 with dissolve
    sar "A park bench??! {b}[mc]!"
    mc "It's fine!"
    scene 03_0604 with dissolve
    dawn "Nonsense!"
    dawn "You're staying {b}here{/b}.\nAnd we won't take no for an answer!"
    scene 03_0605 with dissolve
    mc "Guess I'll see you later, then.[lol]"
    scene black with Fade(3, 0,0)
    call CenterText ("After walking around the city for a couple of hours, you find the college...")
    call Lakeshore_MeetRuth
    mct "Think I'll take in the city for a while; Sarah and Dawn don't need me sitting with them all afternoon!"
    call CenterText ("Later that evening.", True)
    play sound "knock.mp3"
    scene 03_0606 with dissolve
    pause 1.0
    scene 03_0607 with dissolve
    dawn "Welcome back!"
    scene 03_0608 with fade
    sar "You have impeccable timing!"
    sar "We're about to watch a rom-com!"
    mc "Great.[lol]"
    scene 03_0609 with dissolve
    dawn "I bet your soldier secretly loves a good chick flick!"
    dawn "Tell me I'm right, [mc]!"
    mc "Okay, it's true!\nBut you both have to swear to keep my deepest, darkest secret![lol]"
    scene 03_0610 with dissolve
    dawn "Have you picked one?"
    sar "Yep![lol]"
    dawn "No! Not that one {b}again{/b}?!"
    scene 03_0611 with dissolve
    dawn "She does this {i}every time{/i}, [mc]!"
    dawn "Whenever it's her turn to choose the movie, she picks the same one every time!"
    dawn "I was forced to watch it at least twice a week at college![lol]"
    sar "Shut up! You love it, too!"
    scene 03_0612 with Fade(1, 0.5, 1)
    play sound "movie.mp3" volume 0.5
    pause 4.0
    scene black with Fade(2, 0, 0)
    call CenterText ("One (very cringy) movie later...")
    scene 03_0613 with Fade(0, 0, 1)
    call Emotion (dawn, "Sob", "", True)
    scene 03_0614 with dissolve
    dawn "Gets me every time!"
    dawn "I know {i}exactly{/i} what's going to happen, but it still makes me cry!"
    sar "Me, too!"
    scene 03_0615 with dissolve
    dawn "And guys wonder why we think they're heartless!\nLook at him, not even a hint of emotion![lol]"
    mc "[lol]"
    if not Sarah.Has("3S"):
        scene 03_0616 with dissolve
        mc "And that's my cue to call it a night and go to bed!"
        sar "[lol]"
        if Sarah.isActive():
            sar "I should do the same. We have to leave early."
            scene 03_0617 with dissolve
            if Sarah.Has("L0"):
                dawn "Okay, here's the situation...\nI only have two beds."
                dawn "So, [mc], who's going to be sharing with Sarah? Me... or you?"
                mc "Shouldn't that be Sarah's decision?"
                dawn "Oh, I already know she'll pick you, but will {b}you{/b} pick her?"
                mc "Absolutely."
            else:
                dawn "I take it you don't mind bunking with Sarah?\nI only have one spare bed!"
                mc "Don't mind at all![lol]"
            scene 03_0618 with dissolve
            sar "I'll show you where the bedroom is."
            scene 03_0619 with dissolve
            dawn "If you two are gonna fuck, keep the noise down.[lol]"
            call SaraReplay02_Part01
            jump Lakeshore_WakeupDawns_Sarah
        else:
            scene 03_0618 with dissolve
            sar "I'll show you where the bedroom is."
            mc "Thanks."
            scene 03_0619 with dissolve
            dawn "Goodnight, Soldier."
            mc "Night."
            scene 03_0620 with dissolve
            sar "It's a bit of a squeeze, but I'm sure you'll manage."
            sar "I imagine it's better than a park bench!"
            scene 03_0621 with dissolve
            sar "See you in the morning, [mc]."
            mc "Night."
            scene 03_0624 with Fade(1,1,1)
            mc "[whi]..Zzzz.."
            jump Lakeshore_WakeupDawns_Alone
    else:
        scene 03_0625 with dissolve
        mc "That's why we're so misunderstood!\nInside, I'm all torn up and cryin' like a little girl! [lol]"
        scene 03_0626 with dissolve
        dawn "Oh, he's a smart-ass!"
        sar "[lol]"
        scene 03_0627 with dissolve
        dawn "Thanks for coming today, Sarah.\nI feel so much better now."
        sar "Anytime. You know that."
        sar "Jeez, this wine's going straight through me!"
        scene 03_0628 with dissolve
        sar "Want another beer?"
        mc "Uh, sure. Thanks."
        dawn "Put the light on, since you're passing."
        scene 03_0629 with dissolve
        pause 2.0
        scene 03_0630 with dissolve
        dawn "Sorry if I made you feel uncomfortable earlier. That wasn't my intention."
        mc "Uncomfortable?"
        scene 03_0631 with dissolve
        dawn "When I asked about Sarah {i}attacking{/i} you."
        dawn "I didn't mean anything by it; I was only teasing her."
        scene 03_0632 with dissolve
        mc "Don't worry, you didn't make me feel uncomfortable.[lol]"
        if persistent.GroupSex:
            scene 03_0633 with dissolve
            call Emotion (dawn , "Sigh", "I shouldn't have mentioned the {i}other thing{/i}.")
            scene 03_0634 with dissolve
            dawn "Please don't think less of her... She really likes you."
            scene 03_0635 with dissolve
            dawn "We were drunk teenagers, and it only happened once!"
            scene 03_0636 with dissolve
            dawn "Can you just... I don't know... uhh... wipe it from your memory?"
            if not EzModeActive:
                menu:
                    "Wipe what?":
                        pass
                    "[wk_y]Nope! I'm keeping it for later!":
                        jump Lakeshore_DawnConvo
            elif Dawn.Has("EZ"):
                jump Lakeshore_DawnConvo
            scene 03_0637 with dissolve
            mc "I have no idea what you're talking about! There's nothing to wipe!"
            dawn "Hah! Okay, thanks."
        scene 03_0645 with dissolve
        dawn "She told me about how you met."
        dawn "Thank you for helping her with that disgusting pig at the gas station."
        mc "Yeah, right place, right time, I guess."
        scene 03_0647 with dissolve
        sar "I didn't realize how late it was already!"
        scene 03_0649 with dissolve
        sar "I should get some sleep; we have to leave early, remember."
        scene 03_0657 with dissolve
        dawn "You just brought him a beer, and now you want to send him to bed?"
        sar "I didn't say {i}he{/i} had to go to bed!"
        scene 03_0658 with dissolve
        sar "I wouldn't complain if he joined me, though."
        scene 03_0659 with dissolve
        sar "Night, guys."
        mc "Yeah, time for bed."
        scene 03_0660 with dissolve
        dawn "Keep the noise down, please![lol]"
        call SaraReplay02_Part01
        jump Lakeshore_WakeupDawns_Sarah
return

label Lakeshore_DawnConvo:
    $ Dawn.Score(1)
    mc "Sorry. I've locked that one away so I can use it later."
    scene 03_0638 with dissolve
    dawn "Oh my god! You're kidding?!"
    scene 03_0639 with dissolve
    mc "You and Sarah, {i}ravaging{/i} each other?\nDamn right I'm using it![lol]"
    scene 03_0640 with dissolve
    dawn "I'm not sure if I should be flattered or offended?!"
    dawn "..."
    scene 03_0641 with dissolve
    dawn "I'll go with flattered."
    scene 03_0642 with dissolve
    dawn "The thought of you masturbating, while imagining Sarah and me eating each other out, is actually quite the turn-on."
    dawn "Maybe I'll keep that in {i}my{/i} memory bank... for later."
    scene 03_0643 with dissolve
    mc "Then I'll go with flattered, too. Heh."
    scene 03_0644 with dissolve
    dawn "It's a shame we have to rely solely on our imagination."
    scene 03_0645 with dissolve
    dawn "But Sarah would never be up for it.[lol]"
    scene 03_0646 with dissolve
    sar "Up for what?"
    scene 03_0647 with dissolve
    dawn "Nothing.\n[mc] was just fantasizing about our little night of passion."
    scene 03_0648 with dissolve
    mc "Don't believe a word she's tellin' you!"
    dawn "[lol]"
    scene 03_0649 with dissolve
    sar "It doesn't bother you? What we did?"
    mc "Why would it bother me?"
    mc "Does it bother {i}you{/i}??"
    sar "It used to.\nI would cringe every time I thought about it!"
    scene 03_0650 with dissolve
    mc "Yeah?\nSo... it's something you still think about?"
    sar "Occasionally."
    scene 03_0651 with dissolve
    dawn "You do?!"
    scene 03_0652 with dissolve
    sar "Yeah!\nDon't you?"
    dawn "Well, yes... but..."
    scene 03_0653 with dissolve
    sar "Oh god, wait! I'm not saying I want to do it again!"
    sar "Don't worry, Dawn!"
    scene 03_0654 with dissolve
    sar "I'm not planning to sneak into your bed![lol]"
    sar "All I'm saying is, we shared a beautiful experience, so why should we feel embarrassed about it?"
    scene 03_0655 with dissolve
    dawn "It {i}was{/i} a beautiful experience. And I've never felt embarrassed about it."
    dawn "It's funny... We've never talked about it before!"
    scene 03_0656 with dissolve
    dawn "We were so drunk!"
    dawn "We woke up the next morning and pretended as if nothing had happened!"
    scene 03_0657 with dissolve
    sar "I never brought it up because {i}you{/i} didn't."
    dawn "Same!"
    scene 03_0658 with dissolve
    sar "Ready for bed?\nWe need to get up early."
    mc "Yeah."
    scene 03_0659 with dissolve
    sar "Night, Dawn."
    dawn "If you two are gonna fuck, keep the noise down."
    scene 03_0660 with dissolve
    sar "We'll try!"
    scene black with Fade(1, 0,0)
    call SaraReplay02_Part01
    jump Lakeshore_WakeupDawns_Dawn
return

label Lakeshore_WakeupDawns_Alone:
    scene black with Fade(3, 1, 1)
    call CenterText ("The next morning.")
    scene black
    "[whi][mc]?"
    scene 03_0884 with Dissolve(2)
    scene 03_0885 with Dissolve(2)
    "[mc]. Wake up."
    scene 03_0886 with dissolve
    sar "Good morning!"
    scene 03_0887 with dissolve
    sar "We need to get going."
    mc "[whi]Okay, I'll get dressed."
    jump Lakeshore_LeaveDawns
return

label Lakeshore_WakeupDawns_Sarah:
    scene black with Fade(2, 0, 0)
    call CenterText ("The next morning.")
    scene 03_0879 with fade
    pause 1.0
    scene 03_0880 with dissolve
    scene 03_0879 with dissolve
    scene 03_0880 with dissolve
    pause 1.0
    scene 03_0881 with dissolve
    pause 1.0
    scene 03_0882 with dissolve
    sar "[whi][mc]?"
    scene 03_0883 with dissolve
    sar "[whi]Good morning, Sweetheart.\nWe need to get going."
    jump Lakeshore_LeaveDawns
return

label Lakeshore_WakeupDawns_Dawn:
    scene black with Fade(2, 0, 0)
    call CenterText ("The next morning.")
    scene 03_0888 with dissolve
    pause 1.0
    scene 03_0889 with dis1
    pause 1.0
    scene 03_0890 with dissolve
    pause 1.0
    scene 03_0891 with dissolve
    sar "[whi][mc]?"
    scene 03_0892 with dissolve
    sar "[whi]Good morning, Sweetheart.\nWe need to get going."
    mc "[whi]Okay."
    jump Lakeshore_LeaveDawns
return

label Lakeshore_LeaveDawns:
    $ ab=""
    if Dawn.isSexual():
        $ ab="a"
    show expression "03_0893" + ab with Fade(2, 1, 1)
    dawn "Thanks for coming all this way, Sarah."
    show expression "03_0894" + ab with dissolve
    dawn "I don't know what I'd do without you."
    sar "Anytime. I'm always just a phone call away."
    show expression "03_0895" + ab with dissolve
    dawn "I'm sorry for dragging you out here. I feel a little silly now.\nMy mind went into overdrive, and I got paranoid!"
    dawn "But at least I got to meet your soldier![lol]"
    if ab=="a":
        sar "You did more than meet him!"
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e03/03_0896a.webp", 695, 787, True, "Lakeshore_AF01") with dissolve
            dawn "It was lovely meeting you, [mc]!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 03_0896a
                hide screen imgMap
                mc "You too."
        else:
            scene 03_0896a with dissolve
            dawn "It was lovely meeting you, [mc]!"
            call Lakeshore_AF01
    else:
        scene 03_0896 with dissolve
        dawn "It was lovely meeting you, [mc]!"
        mc "You too."
    show expression "03_0901" + ab with dissolve
    dawn "Poor thing, he looks {i}so{/i} tired!"
    sar "Don't worry about him, he'll be asleep in the car before we've even left your street![lol]"
    show expression "03_0902" + ab with dissolve
    sar "We need to go."
    mc "Okay."
    scene black with Fade(3, 0, 0)
    $ curLOC=springhaven_id
    jump Springhaven_SarahDropOff
return

label Lakeshore_MeetRuth:
    scene 03_0273 with Fade(2, 1, 2)
    mct "Yeah... This may take a while."
    scene 03_0274 with dissolve
    mct "Wish I had more info on this girl. Damn, even a name would've helped."
    scene 03_0275 with fade
    mct "You know the drill. Act like you belong here."
    scene 03_0276 with fade
    mct "Okay, I'm in..... Now what?"
    scene 03_0277 with dissolve
    mct "Shit. It's way too quiet in here. I'm gonna get noticed - fast."
    mct "Need a better plan."
    scene 03_0278 with dissolve
    mc "Excuse me. Can you point me to the Dean's office?"
    scene 03_0279 with dissolve
    unk "Sure. Follow that hallway to the end."
    scene 03_0280 with dissolve
    mc "Thanks."
    unk "You're welcome."
    scene 03_0281 with fade
    pause 1.0
    scene 03_0282 with dissolve
    pause 0.5
    play sound "door.mp3" volume 0.1
    scene 03_0283 with dissolve
    mc "Okay, we've got a serious problem here!"
    $ Ruth_name=""
    ruth "Excuse me?! How dare you barge into my office like this?"
    scene 03_0284 with dissolve
    ruth "Who are you?\nWhat's the meaning of this intrusion?"
    scene 03_0285 with dissolve
    mc "Exactly! That's precisely the problem!"
    mc "You have {b}no idea{/b} who I am...\nAnd yet, I've been walking around your campus for over an hour!"
    mc "Not one person questioned me - no ID check. No security. Nothing.\nIs that how things work here?"
    scene 03_0286 with dissolve
    ruth "I'm calling campus security!"
    mc "Please, do. I'd love to have a chat with them."
    mc "And while you're at it, I'll call my client - let them know their concerns about this institution's lax security were absolutely justified."
    scene 03_0287 with dissolve
    mc "I'm sure they'll be thrilled to pull their donations and move their precious daughter somewhere that actually prioritizes safety."
    scene 03_0288 with dissolve
    ruth "...Wait. What??"
    ruth "{i}Who{/i} are you??"
    scene 03_0289 with dissolve
    mc "I'm a private security consultant from Springhaven."
    mc "I was hired to assess your college for vulnerabilities, especially those that could endanger a {i}specific{/i} student."
    scene 03_0290 with dissolve
    mc "And from what I've seen so far, this place has more red flags than a parade."
    scene 03_0291 with dissolve
    ruth "And your client??"
    mc "Expects anonymity."
    ruth "I see."
    ruth "Well... it appears we've gotten off on the wrong foot, Mr...?"
    scene 03_0292 with dissolve
    mc "[mc]. You can just call me [mc]."
    ruth "Very well, [mc]. I'm Ms. Jackson."
    ruth "Or Ruth, if you prefer a first-name basis."
    $ Ruth_name="Ruth"
    $ persistent.RuthLocked=False
    $ Ruth.Activate("Ruth")
    scene 03_0293 with dissolve
    mc "Look, Ruth. You seem like a reasonable person."
    mc "I don't want to be the one to ruin your reputation - Or the reputation of this school."
    ruth "What do you suggest?"
    scene 03_0294 with dissolve
    mc "Inform security that I'm on campus, but I'm not to be approached. {b}Don't{/b} tell them {i}why{/i} I'm here."
    mc "I'll check on the student in question, complete my observations, and report back to you directly."
    mc "If you address my concerns, I won't need to include them in the final report to my client..."
    scene 03_0295 with dissolve
    ruth "Your client... Ms. Robinson?"
    scene 03_0296 with dissolve
    mc "...What?"
    scene 03_0297 with dissolve
    ruth "We're a small institution that relies heavily on the generosity of our benefactors."
    ruth "There's only one female student on this campus from Springhaven whose parent has both the wealth and motivation to hire a private consultant."
    scene 03_0295 with dissolve
    ruth "That student is Melissa."
    scene 03_0296 with dissolve
    mc "I never said {i}my client{/i} was from Springhaven."
    scene 03_0297 with dissolve
    ruth "And how do you think Ms. Robinson will react when she finds out her expensive consultant accidentally revealed her identity to me?"
    ruth "You seem like a decent man, [mc]."
    scene 03_0298 with dissolve
    ruth "I'd hate to be the one to ruin {b}your{/b} reputation."
    scene 03_0296 with dissolve
    mct "Damn it."
    mc "Then it sounds like we both have something to lose."
    scene 03_0299 with dissolve
    ruth "It does."
    ruth "So I assume Ms. Robinson will receive a glowing report on our security protocols?"
    mc "She will."
    ruth "Excellent."
    scene 03_0300 with dissolve
    ruth "Now... you mentioned you were also asked to check on Melissa personally?"
    mc "That's right. Where can I find her?"
    scene 03_0301 with dissolve
    ruth "If she's not in class, she's most likely in the library."
    ruth "She spends most of her time there, nose in a book."
    mc "Thanks."
    scene 03_0302 with dissolve
    ruth "One more thing, [mc]..."
    ruth "Next time, knock."
    scene 03_0303 with dissolve
    mc "Next time, make sure someone asks me who I am before I get this far."
    scene 03_0304 with dissolve
    call Emotion (ruth, "Exhales deeply")
    scene 03_0305 with dissolve
    pause 1.0
    scene 03_0306 with dissolve
    mct "Fuck, that almost backfired!"
    scene 03_0307 with dissolve
    mct "Worked out better than I hoped, though."
    scene 03_0308 with dissolve
    mct "Just need to find the ..."
    scene 03_0309 with dissolve
    mct "Library."
    scene 03_0310 with dissolve
    mct "Okay, Melissa Robinson..."
    scene 03_0311 with dissolve
    mct "I think I see you..."
    scene 03_0312 with dissolve
    mct "... Maybe."
    scene 03_0313 with dissolve
    mct "Need to attract her attention..."
    mct "... But who's the guy?"
    mct "Looks like he'd rather be anywhere but here.\n... And he hasn't taken his eyes off her."
    scene 03_0314 with dissolve
    mct "Okay..."
    scene 03_0315 with dissolve
    pause 0.5
    scene 03_0316 with dissolve
    play sound "doorrat.mp3"
    pause 0.5
    $ t=10
    while t>0:
        scene 03_0317
        pause 0.1
        scene 03_0316
        pause 0.1
        $ t-=1
    scene 03_0318 with dissolve
    mct "Yeah..."
    scene 03_0319 with dissolve
    mct "That's her."
    scene 03_0320 with dissolve
    pause 0.75
    scene 03_0321 with dissolve
    pause 0.75
    scene 03_0322 with dissolve
    pause 0.75
    scene 03_0323 with dissolve
    pause 0.75
    scene 03_0324 with fade1
    mct "Job done."
return

label Lakeshore_Start1:
    if not Dawn.isActive():
        jump Lakeshore_Start1_Alt
    scene 08_0113 with Fade(0, 3, 3)
    scene 08_0114 with dis1
    scene 08_0115 with dis1
    scene 08_0116 with dis1
    scene 08_0117 with dis1
    scene 08_0118 with dis1
    play sound "knock.mp3"
    pause 0.5
    scene 08_0119 with dissolve
    mct "Hope she saw Sarah's message telling her I was on my way!"
    scene 08_0120 with dissolve
    dawn "Hello?"
    scene 08_0121 with dissolve
    dawn "[mc], Welcome back!"
    mc "Hi Dawn."
    scene 08_0122 with dissolve
    dawn "Come in!"
    scene 08_0123 with fade
    mc "Thanks for letting me stay again."
    dawn "No need to thank me. You're always welcome here.\nAnd right now it's a relief!"
    mc "Right..."
    scene 08_0124 with dissolve
    mc "... Sarah said you were still having trouble with the stalker."
    dawn "It's been a nightmare, [mc]!"
    scene 08_0125 with dissolve
    dawn "Twice I've called the cops on this guy, but by the time they eventually show up - he's long gone!"
    dawn "I'm sure they're starting to think I'm crazy!"
    mc "You still have no idea who it is?"
    scene 08_0126 with dissolve
    dawn "Not a damn clue!"
    dawn "Never seen him before in my life!"
    scene 08_0127 with dissolve
    dawn "I can't tell you how glad I am to have you here!\nEven if it's only for a night or two."
    dawn "I hate being alone in this apartment.\nI feel so vulnerable all the damn time."
    scene 08_0128 with dissolve
    mc "Wish I could do more.\nIf you see this guy while I'm in town, don't hesitate to call me; I'll come immediately."
    dawn "Thanks, that's sweet of you.\nYou'll have to give me your number!"
    scene 08_0129 with dissolve
    mc "Right... This is my temporary number... Accidentally left {i}my{/i} cell at home again."
    dawn "Don't give it to me yet; my phone's in the kitchen.\nI'll make some coffee."
    scene 08_0130 with dissolve
    mc "Great.\nActually, mind if I make a quick call?"
    dawn "Sure!\nYou can use the bedroom if you need privacy."
    scene 08_0131 with fadehold
    mct "Hope this professor can help..."
    scene 08_0132 with dissolve
    mc "Uh, hello... Please don't hang up... this isn't a crank call..."
    mc "I'm a friend of Melissa's, and I need your help."
    $ cellVoice = "Female voice"
    unk_cell "[whi]What? Who is this??"
    scene 08_0133 with dissolve
    mc "My name's-"
    unk_cell "[whi][mc]?"
    unk_cell "[whi]... Is that you??\nWhat the hell?"
    mc "Huh?? How-"
    play sound "doorslam.mp3"
    scene 08_0134 with dissolve
    dawn "Prank calls? {i}Really{/i}??"
    dawn "Did Sarah put you up to this?\nBecause it's {b}NOT{/b} funny!!"
    scene 08_0135 with dissolve
    mc "Wait... {i}YOU'RE{/i} the professor??"
    scene 08_0136 with dissolve
    dawn "Professor??\nWhat are you talking about?"
    dawn "Why would you do this?!\nI {i}literally{/i} just told you how vulnerable I'm always feeling!"
    dawn "This isn't like Sarah! Why wou-"
    scene 08_0137 with dissolve
    dawn "Wait... I never told Sarah her name.\nI only ever referred to Melissa as {i}my student{/i}."
    dawn "How do you know her name??"
    scene 08_0138 with dissolve
    mc "Because this has nothing to do with Sarah.\nI work for Melissa's mother."
    mc "She's the reason I'm here. We need to get her out."
    mc "Sue - Melissa's mom - gave me the number of a professor who may be able to help..."
    mc "I didn't expect {i}you{/i} to answer."
    scene 08_0139 with dissolve
    dawn "I'm {i}not{/i} a professor - at least, not yet.\nI'm a lecturer. Melissa attends one of my classes."
    dawn "What do you mean by {i}get her out{/i}?"
    mc "Remove her from the situation she currently finds herself in."
    dawn "Oh, boy.\nCome on, coffee's getting cold."
    scene 08_0140 with fadehold
    dawn "You know Melissa is under constant guard, right?"
    mc "Yeah."
    dawn "They pretend they're her friends, but we all know they're not - yet no one does a thing."
    dawn "So how, exactly, do you plan on helping her?"
    mc "I'm not sure yet.\nThat's why I need to talk to you, and her."
    scene 08_0141 with dissolve
    dawn "Speaking to Melissa {i}alone{/i} is out of the question."
    dawn "One of her {i}friends{/i} is always at her side."
    scene 08_0142 with dissolve
    dawn "Even in class, I can't speak privately with her.\nWe have to pass notes to one another {i}very carefully{/i}."
    dawn "She's never alone.\nThey even check the bathroom stalls before letting her... you know."
    scene 08_0143 with dissolve
    dawn "They all live in the same place.\nThree guys watch her, and they work in shifts, so she's constantly guarded."
    mc "Damn."
    scene 08_0144 with dissolve
    dawn "She has no social life. No friends."
    dawn "She attends her classes; sometimes they'll allow her to hang out in the college library, and then they go home."
    dawn "The {b}only{/b} place she has to escape them for a while is her gym class."
    mc "Gym class?"
    scene 08_0145 with dissolve
    dawn "Yeah.\nGym classes are separated by gender, so no guys allowed with the girls, and vice versa."
    dawn "They used to have a female {i}friend{/i} to accompany her, but she hasn't been around for a few months."
    dawn "When she's attending the gym, they wait right outside the whole time."
    scene 08_0146 with dissolve
    mc "Then that's how we get to her."
    dawn "The college takes its single-sex environments seriously. You wouldn't get through the door."
    scene 08_0147 with dissolve
    dawn "Anyway, why go through all that?"
    dawn "Can't you just... I don't know... beat up whichever guy's guarding her, and get her out of here??"
    scene 08_0148 with dissolve
    mc "It's not that simple."
    mc "The people her friends work for... They can't know we've taken her. Not immediately anyway."
    mc "We need time to get her to a safe place.\nOnce that call has been made, they'll swarm the whole town to find her."
    mc "I'm guessing her friends have a check-in routine - probably every thirty minutes.\nSomeone doesn't check in, the alarm is sounded."
    scene 08_0142 with dissolve
    dawn "So how the hell are we supposed to do it??"
    scene 08_0146 with dissolve
    mc "That's why I need to talk to Melissa.\nShe'll know their routine better than anyone."
    dawn "Well, like I said - that's impossible."
    mc "Maybe not..."
    scene 08_0149 with dissolve
    mc "The college... is it closed today?"
    dawn "No. I have a free afternoon.\nI came home early after seeing Sarah's message saying you were on your way."
    mc "Okay, good.\nThink I'll go say hi to Ruth."
    scene 08_0150 with dissolve
    dawn "Ruth? {i}The Dean{/i}?!"
    dawn "You know her??"
    scene 08_0151 with dissolve
    mc "Yeah, we've met.\nBet she'll be delighted to see me again![lol]"
    call Lakeshore_BackToCollege
    scene 08_0167 with Fade(0,1,2)
    if not Sarah.isActive():
        $ Sarah.act = True
        $ Sarah.L=-1
    dawn "Wow!\nThe Dean's usually so... rigid... when it comes to college regulations!"
    dawn "She accepted your request... {i}Just like that{/i}??"
    mc "Yeah."
    scene 08_0168 with dissolve
    dawn "Bullshit![lol]"
    dawn "You have something on her!"
    scene 08_0169 with dissolve
    dawn "Oh my God... What is it? Tell me!\nI need a six-month, fully paid vacation {i}so{/i} desperately![lol]"
    scene 08_0170 with dissolve
    mc "[lol]"
    scene 08_0171 with dissolve
    dawn "I have to hand it to you, it's a good idea."
    dawn "Putting your friend in the one place where Melissa may actually be able to talk freely."
    scene 08_0172 with dissolve
    mc "I need you to pass a note.\nWe don't have the time to gain Melissa's trust."
    mc "If {b}you{/b} tell her we're on her side, hopefully she trusts {i}you{/i} enough to trust us."
    mc "Make sure she understands that Blaze is {i}only{/i} there to help her."
    scene 08_0173 with dissolve
    dawn "{i}Blaze{/i}. Such an unusual name!"
    mc "It's not her {i}real{/i} name."
    scene 08_0174 with dissolve
    mc "She was always the first to charge in, {i}guns'a'blazin'{/i}, heh."
    mc "Bravest person I've ever met.\nShe's done things that even make {i}me{/i} shudder! Heh."
    scene 08_0175 with dissolve
    mc "If it's okay with you, I'd like her to stay here."
    dawn "Uh... Yeah, sure."
    scene 08_0176 with dissolve
    mc "It's not for convenience, Dawn."
    mc "You being followed could be connected.\nSomeone might've noted your interactions with Melissa."
    scene 08_0177 with dissolve
    dawn "Fuck!"
    scene 08_0178 with dissolve
    mc "If I'm right, it's actually a {i}good{/i} thing."
    scene 08_0179 with dissolve
    dawn "Aren't these people dangerous??\nHow the hell is that a {i}good thing{/i}?!"
    scene 08_0180 with dissolve
    mc "Because you spotted them. They're clearly amateurs.\nA pro would {b}never{/b} have been seen by their target."
    scene 08_0176 with dissolve
    mc "Having Blaze here gives you some security."
    mc "Believe me, if these guys fuck with her, it'll be {i}their{/i} mistake."
    scene 08_0181 with dissolve
    dawn "Trying to keep me safe...\nAre you doing this for me?... Or for Sarah?"
    if Sarah.L>-1:
        dawn "Swooping in all heroic-like to save her best friend.\nThat's a lot of extra brownie points!"
        dawn "Because you don't need them, you know!\nShe already likes you more than she'll admit!"
    else:
        dawn "Has she been worrying about me so much that you feel the need to step in and help?"
    scene 08_0182 with dissolve
    mc "Sarah's worried about you, it's true, and if this helps put her mind at ease, then great."
    mc "But no, this isn't for Sarah."
    mc "I'm doing this because it's the right thing to do."
    mc "I consider {i}us{/i} friends, and when a friend needs help, I'm there."
    scene 08_0183 with dissolve
    if Dawn.L==4:
        dawn "Friends? Is that what we are, [mc]?"
        scene 08_0184 with dissolve
        dawn "Because -and correct me if I'm mistaken- didn't we fuck?"
        scene 08_0185 with dissolve
        dawn "So, I'd say we're {i}more{/i} than friends."
        dawn "More like friends with benefits."
        scene 08_0186 with dissolve
        dawn "And I'm in the mood to claim those benefits {i}right now{/i}."
        scene 08_0187 with dissolve
        dawn "If you are, too... You know where to find me."
        scene 08_0188 with dissolve
        pause 0.5
        $ tCh=Dawn.Has("EZ")
        if not EzModeActive:
            menu:
                "[wk_y]Follow Dawn":
                    $ tCh=True
                "Watch TV":
                    $ tCh=False
        if tCh:
            scene 08_0190 with dissolve
            pause 0.5
            scene 08_0219 with dis1
            call DawnReplay02
        else:
            $ Dawn.Add("Refused")
            scene 08_0189 with dis1
            pause 0.5
            scene 08_0188 with dis1
            mct "Too tired.\nJust wanna watch some TV before bed."
            jump Lakeshore_SleepAlone
    else:
        dawn "Absolutely, we're friends!"
        scene 08_0191 with dissolve
        dawn "And to prove it..."
        scene 08_0192 with dis1
        dawn "... I'll let you choose the movie!"
        mc "[lol]"
        scene 08_0193 with Fade(1, 2, 1)
        play sound "hm01.mp3" volume 0.5
        dawn "I didn't have you down as a horror fan!"
        scene 08_0194 with dissolve
        mc "I'm not.\nMy daughter Millie loves them though, so I'm tryin' to get into them."
        dawn "Aww! That's sweet![lol]"
        scene 08_0195 with Fade(1, 2, 1)
        play sound "hm03.mp3" volume 0.5
        dawn "What the fuck are they doing?? {b}RUUUUN{/b}!!"
        scene 08_0196 with Fade(1, 2, 1)
        play sound "hm04.mp3" volume 0.5
        dawn "OUCH!! That's gonna leave a scar!"
        scene 08_0197 with Fade(1, 2, 1)
        play music "hm05.mp3" loop volume 0.75
        dawn "Thanks for being here, [mc].\nI'm always on edge these days. It's nice to feel relaxed for a bit."
        scene 08_0198 with dissolve
        mc "I'm sorry you have to live like this.\nOnce it's all over, things will quickly get back to normal."
        scene 08_0199 with dissolve
        dawn "But... What if this stalker guy has nothing to do with Melissa?"
        dawn "What if it's something else?\nJust some random weirdo with a fixation?"
        mc "Then we'll deal with that, too.\nDon't worry. I won't abandon you."
        scene 08_0200 with dissolve
        dawn "I can see why Sarah fell for you so hard!"
        menu:
            "[wk_y]Kiss her":
                scene 08_0202 with dis1
                scene 08_0203 with dis1
                pause 0.5
                scene 08_0204 with dissolve
                dawn "[ss]Mmhh."
                scene 08_0205 with dissolve
                pause 0.5
                scene 08_0206 with dissolve
                dawn "[whi]FUCK!"
                if Plr.Has("Barry"):
                    dawn "What the hell am I doing??"
                    scene 08_0214 with dissolve
                    scene 08_0215 with dis1
                    scene 08_0216 with dis1
                    mc "Dawn, wait!"
                    scene 08_0217 with dissolve
                    mct "Crap."
                    scene 08_0218 with dis1
                    scene 08_0219 with dis1
                    stop music fadeout 1.0
                    play sound "knock.mp3" volume 0.5
                    scene 08_0220 with dis1
                    scene 08_0221 with dissolve
                    mc "Dawn..."
                    dawn "[whi]I'm sorry [mc], we should {b}not{/b} have done that."
                    dawn "[whi]Goodnight."
                    scene 08_0222 with dissolve
                    mc "Sarah told me to tell you something..."
                    dawn "[whi]Please, just go to bed."
                    mc "She said to tell you... {i}I'm her Barry.{i}"
                    scene 08_0221 with dissolve
                    dawn "[whi]..."
                    mc "I don't know what that means, bu-"
                    call DawnReplay02
                else:
                    dawn "We... We can't..."
                    mc "Why?"
                    scene 08_0207 with dissolve
                    dawn "I want to... really, I do."
                    dawn "But... Sarah."
                    scene 08_0208 with dissolve
                    mc "Sarah and I are friends, nothing more!"
                    dawn "I know... It's just, she likes you... a lot!"
                    scene 08_0209 with dissolve
                    dawn "It's hard to explain...\nIt feels like cheating, even though I know you're not together."
                    scene 08_0210 with dissolve
                    dawn "I have to talk with her first. I need to know she'd be okay with it."
                    mc "You need permission from your friend to kiss me?"
                    scene 08_0211 with dissolve
                    dawn "{i}Best{/i} friend!\nAnd we both know the permission isn't for {i}kissing{/i}."
                    dawn "I'm sorry, [mc].\nYou understand, right?"
                    menu:
                        "No. It's now or never! [wk_c]":
                            dawn "Wow!"
                            scene 08_0212 with dissolve
                            dawn "You just made that a lot easier. {b}ASSHOLE!{/b}"
                            mc "Dawn!"
                            dawn "GOODNIGHT!"
                            call CloseCharacterPath (Dawn, "Dawn")
                            $ Dawn.L=-2
                            scene 08_0213 with dissolve
                            mct "Damn... I really thought she was gonna choose 'Now'!"
                        "[wk_y]Yeah. It's okay, I get it":
                            $ Dawn.Add("Wait")
                            dawn "Okay."
                            dawn "I'm going to bed.\nI've had a lot of wine, and the temptation is killin' me."
                            scene 08_0212 with dissolve
                            dawn "Night."
                            mc "Night, Dawn."
                            scene 08_0213 with dissolve
                            mct "And this, ladies and gentlemen, is why we say 'Men are from Mars, Women are from Venus'. Heh."
                    jump Lakeshore_SleepAlone
            "Watch the movie[wk_c]":
                $ Dawn.L=-1
                scene 08_0201 with dissolve
                if Sarah.L==4:
                    mc "Yeah, I'm a lucky guy."
                    dawn "Yes, you are!"
                else:
                    mc "We're just friends."
                    dawn "Yeah, I know... We're all {i}just{/i} friends![lol]"
                jump Lakeshore_SleepAlone
    jump Lakeshore_SleepDawn
return

label Lakeshore_SleepAlone:
    stop music fadeout 1.0
    scene 08_0382 with Fade(2, 1, 1)
    mc "[whi]...Zzzzz..."
    scene 08_0426 with Fade(2, 3, 2)
    mc "[whi]..Zzz.."
    scene 08_0427 with hpunch
    dawn "[whi]{b}[mc!u]!"
    scene 08_0428 with dissolve
    dawn "[whi]I heard a noise! I think someone's broken in!"
    mc "[whi]Huh?!"
    scene 08_0429 with dissolve
    dawn "[whi]What if it's my stalker?!"
    scene 08_0430 with hpunch
    mc "[whi]Stay here!"
    call Lakeshore_MeetBlaze (False)
    jump Lakeshore_ContinueBlazeConvo
return

label Lakeshore_SleepDawn:
    scene 08_0447 with Fade(2, 3, 2)
    mc "[whi]..Zzz.."
    scene 08_0448 with hpunch
    dawn "[whi]{b}[mc!u]! Wake up!"
    scene 08_0449 with dissolve
    dawn "[whi]I think someone's broken in!"
    scene 08_0450 with dissolve
    mc "[whi]Huh?!"
    dawn "[whi]What if it's my stalker?!"
    scene 08_0451 with hpunch
    mc "[whi]Stay here!"
    call Lakeshore_MeetBlaze (True)
    jump Lakeshore_ContinueBlazeConvo
return

label Lakeshore_MeetBlaze(wD=False):
    scene 08_0431 with dissolve
    pause 0.5
    play sound "doorslam.mp3"
    scene 08_0432 with hpunch
    pause 0.5
    scene 08_0433 with dissolve
    mc "Jesus!"
    scene 08_0434 with dissolve
    blz "Mornin', Boss.\nMade some coffee."
    scene 08_0435 with dissolve
    blz "Good to see you can still get it up."
    scene 08_0436 with dissolve
    mc "Yeah, yeah... I've got a dick that still works, and you've got hair now...\nYou broke in??"
    blz "I didn't {i}break{/i} anything!\nI was knocking for ages, you didn't answer... so I let myself in."
    dawn "[whi][mc]?"
    if wD:
        scene 08_0438 with dissolve
    else:
        scene 08_0437 with dissolve
    mc "[whi]Shit.."
    mc "Everything's okay, Dawn.\nIt's just Blaze."
    blz "Ohh, shit... Sorry Boss, I didn't know you had company!"
    if wD:
        scene 08_0439 with dissolve
    else:
        scene 08_0440 with dissolve
    dawn "Err... Hello."
    mc "Blaze, this is Dawn.\nIt's {i}her{/i} apartment you just broke into!"
    $ persistent.BlazeLocked=False
    $ Blaze.Activate("Blaze")
    scene 08_0441 with dissolve
    blz "Ahh, fuck... I'm sorry!"
    blz "I thought this was {b}his{/b} place!\nI hope I didn't scare you!"
    if wD:
        scene 08_0444 with dissolve
        mc "I'm gonna get dressed."
        dawn "[whi]Okay."
    else:
        if Dawn.L>-2:
            scene 08_0442 with dissolve
            mc "I'm gonna get dressed."
            dawn "[whi]Hmm?"
            scene 08_0443 with dissolve
            dawn "Uhh... Okay."
        else:
            scene 08_0443 with dissolve
            mc "I'm gonna get dressed."
            dawn "[whi]Okay."
    scene 08_0445 with Fade(1, 2, 1)
    dawn "Forget about it.\nI'm just glad I didn't call the cops first!"
    blz "Hah! Shit, so am I!"
    scene 08_0446 with dissolve
    blz "You didn't need to get dressed for me, Boss![lol]"
    blz "So, wanna tell me why I'm here?"
    mc "Yeah..."
    scene 08_0452 with fade2
    blz "A gym instructor?!\nWhat the hell do I know about teaching gym??"
    mc "You won't need to teach it, just fake it... and it's {i}assistant{/i} gym instructor!"
    scene 08_0453 with dissolve
    blz "So, Melissa... Who is she?"
    call CenterText ("You explain the situation to Blaze.", True)
    scene 08_0461 with fade
    blz "Five days isn't much time!"
    scene 08_0462 with dissolve
    blz "That's barely enough time to get to know my new roomie!"
    dawn "I haven't had a roommate since my college days!"
    scene 08_0463 with dissolve
    mc "Uh, no... You only have five days at the gym, but I still need you afterward."
    blz "Why?"
return

label Lakeshore_Start1_Alt:
    scene 08_0001 with Fade(0, 3, 3)
    play sound "car3.mp3"
    scene 08_0002 with dis1
    scene 08_0003 with dis1
    scene 08_0004 with dis1
    scene 08_0005 with fadehold
    mct "Yeah... Knew I should've checked the reviews before booking online."
    scene 08_0006 with fadehold
    pause 0.5
    scene 08_0007 with dissolve
    mct "Shiit... This place is even worse than Cedar Grove!"
    scene 08_0008 with dissolve
    call Emotion (mct, "Sigh", "Might just sleep in the truck.")
    mct "Okay... Let's get to work..."
    scene 08_0009 with dissolve
    mct "Hope I put the professor's number in this new cell properly...\nCan't switch mine back on while I'm in Lakeshore..."
    scene 08_0010 with dissolve
    mct "Okay... ringing..."
    scene 08_0011 with dissolve
    mc "Uh, hello... Please don't hang up... this isn't a crank call..."
    mc "I'm a friend of Melissa's, and I need your help."
    $ cellVoice = "Female voice"
    unk_cell "[whi]What? Who is this??"
    scene 08_0012 with dissolve
    mc "My name's [mc].\nI need to see Melissa on her own, but she has, uhh, her friends around her all the time..."
    unk_cell "[whi]Where did you get my number??\nARE YOU THE GUY WHO'S BEEN FOLLOWING ME?!"
    mc "What? No!"
    mc "I just got into town!\nMelissa's mom, Sue, gave me your number, said you wanted to help."
    unk_cell "[whi]I don't know you... You could be anybody!"
    scene 08_0013 with dissolve
    mc "I know, but please... I'm just trying to help Melissa, I swear."
    mc "Can we meet?"
    unk_cell "[whi]No way! Don't ring this number again!"
    scene 08_0014 with dissolve
    mc "Wait! Please..."
    mc "Things are getting worse... Melissa could be in even more danger now..."
    mc "We're running out of time."
    unk_cell "[whi]..."
    unk_cell "[whi]A public place... Close to the college..."
    scene 08_0015 with dissolve
    mc "I can come to the college. It's the only place I know in this town."
    unk_cell "[whi]..."
    unk_cell "[whi]Fine. Meet me where Melissa usually hangs out. In one hour.\nIf you're really her friend, you'll know where that is."
    mc "Thank you."
    scene 08_0016 with dissolve
    mct "The library... I guess."
    call Lakeshore_BackToCollege
    scene 08_0383 with Fade(0, 1, 2)
    pause
    scene 08_0384 with dissolve
    mc "Dawn?\nHi, it's me... Uhh, [mc]."
    dawn cell "[whi]Hi."
    mc "I think I've found a way for us to help Melissa."
    scene 08_0385 with dissolve
    mc "Can we meet again?"
    dawn cell "[whi]Uhh, I've already left the college.\nI'm at home."
    scene 08_0386 with dissolve
    mc "Can you send me your address?\nI can come over."
    dawn cell "[whi]Ohh, err... I don't know..."
    mc "Dawn, please.\nI know I have no right to ask you to trust me, but I'm askin' anyway."
    scene 08_0387 with dissolve
    dawn cell "[whi]..."
    dawn cell "[whi]Fuck... Okay..."
    dawn cell "[whi]Just... Please don't murder me."
    mc "Thank you."
    scene 08_0388 with dissolve
    scene 08_0113 with Fade(2, 2, 3)
    scene 08_0114 with dis1
    scene 08_0115 with dis1
    scene 08_0116 with dis1
    scene 08_0117 with dis1
    scene 08_0118 with dis1
    play sound "knock.mp3"
    pause 0.5
    scene 08_0119 with dissolve
    pause
    scene 08_0389 with dissolve
    dawn "Hi... Come in."
    mc "Thanks."
    scene 08_0390 with dissolve
    dawn "Umm, sorry... I wasn't expecting company when I changed into my PJs."
    mc "Heh, it's fine."
    scene 08_0391 with dissolve
    mc "Nice place."
    dawn "It's a shithole, but thanks.\nIt's only temporary... At least, that's what I said when I moved in a couple of years ago."
    scene 08_0392 with dissolve
    dawn "So, how do we help her?"
    mc "Right...\nYou said you pass notes between yourself and Melissa..."
    mc "I need you to pass her one... from me."
    dawn "Okay... Saying what?"
    scene 08_0393 with Fade(1, 2, 1)
    dawn "Wow!\nThe Dean's usually so... rigid... when it comes to college regulations!"
    dawn "She accepted your request... {i}Just like that{/i}??"
    mc "Yep."
    scene 08_0394 with dissolve
    dawn "Yeah, you have something on her, don't you?\nIs it bad? [lol]"
    dawn "Damn, what is it?!\nI wouldn't mind a six-month, fully paid vacation right about now!"
    scene 08_0395 with dissolve
    mc "[lol]"
    dawn "It might just work... Putting your friend in the one place where Melissa may actually be able to talk freely."
    scene 08_0396 with dissolve
    mc "We don't have the time to gain Melissa's trust.\nIf {b}you{/b} tell her we're on her side, hopefully she trusts {i}you{/i} enough to trust us."
    mc "Make sure she understands that Blaze is {i}only{/i} there to help her."
    scene 08_0397 with dissolve
    dawn "{i}Blaze{/i}. Such an unusual name!"
    mc "Yeah, it's not her {i}real{/i} name."
    scene 08_0398 with dissolve
    mc "She was always the first to charge in, {i}guns'a'blazin'{/i}, heh."
    mc "Bravest person I've ever met.\nShe's done things that even make {i}me{/i} shudder! Heh."
    scene 08_0399 with dissolve
    mc "When I first called you, you said something about being followed?"
    scene 08_0400 with dissolve
    dawn "Ohh, yeah... There's some creep stalking me."
    dawn "My friend told me to call the cops the next time I saw him, which I did, but the guy was long gone by the time they arrived."
    scene 08_0396 with dissolve
    mc "How long has this been going on?"
    scene 08_0401 with dissolve
    dawn "I... Uhh.. I'm not sure."
    dawn "I first noticed him about three weeks ago, but he could've been following me for months!"
    dawn "Why?"
    scene 08_0402 with dissolve
    mc "Because it could be connected to Melissa.\nThe people guarding her... Someone might've noted your interactions with her."
    scene 08_0403 with dissolve
    dawn "Fuck!"
    scene 08_0396 with dissolve
    mc "If I'm right, it's actually a {i}good{/i} thing."
    scene 08_0403 with dissolve
    dawn "Aren't these people dangerous??\nHow the hell is that a {i}good thing{/i}?!"
    scene 08_0404 with dissolve
    mc "Because you spotted them. They're clearly amateurs.\nA pro would {b}never{/b} have been seen by their target."
    mc "If it's okay, I'd like Blaze to stay here with you.\nIt'll give you some security."
    mc "Believe me, if these guys fuck with her, it'll be {i}their{/i} mistake."
    dawn "Uh... Yes, okay."
    scene 08_0405 with dissolve
    mc "Good.\nWe'll come over in the morning, and I'll introduce you."
    dawn "Right."
    scene 08_0406 with dissolve
    mc "Thanks for seeing me. I'll let myself out."
    dawn "Oh, uhh.. Okay... Thank you."
    scene 08_0407 with fade2
    pause
    scene 08_0408 with dissolve
    mct "Fuck it..."
    mct "... you've slept in worse places."
    scene 08_0409 with Fade(2, 1, 1)
    mc "[whi]...Zzzzz..."
    scene 08_0410 with Fade(2, 3, 2)
    mc "[whi]..Zzzz..{w=1.0}{nw}"
    play sound "knock.mp3" volume 0.5
    pause
    scene 08_0411 with dissolve
    pause 1.0
    play sound "knock.mp3" volume 1.5
    pause
    scene 08_0412 with dissolve
    call Emotion (mc, "Groan", "", True)
    play sound "doorbang.mp3"
    pause 1.0
    mc "Okay, okay!! ...Fuck!"
    scene 08_0413 with dissolve
    play sound "doorbang.mp3" volume 1.5
    pause 0.5
    mc "I'M COMIN'!!!"
    scene 08_0414 with dissolve
    blz "Shit, Boss! You got old!"
    mc "And you've got... hair!"
    scene 08_0415 with dissolve
    blz "It's great to see you, man.\nI've been worried about you."
    mc "You too, Blaze.\nWorried? Why??"
    $ persistent.BlazeLocked=False
    $ Blaze.Activate("Blaze")
    scene 08_0416 with dissolve
    blz "You were a no-show at Pete's funeral. Not like you."
    blz "I tried reachin' out..."
    mc "Yeah, I know.\nI'm sorry... It took a while to get my head straight."
    scene 08_0417 with dissolve
    blz "So straight that you got up and quit?"
    blz "I didn't believe the rumorsfor a minute... until yesterday!"
    mc "You doggin' on me for quitting??\nYou did the same!"
    scene 08_0418 with dissolve
    blz "Fuck man, no!\nYou should've walked years ago, as I did."
    blz "Serving our country was a privilege, but they took too much."
    scene 08_0419 with dissolve
    blz "I had to get out while I still had a sliver of my soul left."
    blz "You understood that, right?\nI didn't quit on {b}you{/b}, Boss."
    mc "Yeah, I know."
    scene 08_0420 with dissolve
    blz "So, you gonna leave me standing at your door, or invite me in and tell me why I'm here?"
    mc "Heh, yeah. Come on."
    scene 08_0421 with fade2
    blz "A gym instructor?!\nWhat the hell do I know about teaching gym??"
    mc "You won't need to teach it, just fake it... and it's {i}assistant{/i} gym instructor!"
    scene 08_0422 with dissolve
    blz "So, Melissa... Who is she?"
    scene 08_0423 with dissolve
    mc "It's a long story, I'll fill you in on the way to Dawn's."
    blz "Who's Dawn??"
    scene 08_0424 with dissolve
    mc "Your new roomie."
    scene 08_0425 with dissolve
    mc "C'mon."
    scene 08_0454 with fade2
    play sound "knock.mp3"
    pause 0.5
    scene 08_0455 with dissolve
    blz "Five days isn't much time!"
    mc "If anyone can pull it off, it's you."
    scene 08_0456 with dissolve
    dawn "I know you said {i}morning{/i}, but I wasn't expecting it to be {b}this{/b} early!"
    mc "Sorry."
    dawn "It's fine. Come in."
    scene 08_0457 with fade
    mc "Dawn, I'd like you to meet Blaze - Your new roommate."
    dawn "Hello.\nI haven't had a roommate since my college days!"
    scene 08_0458 with dissolve
    blz "It's only for five days.\nDoubt we'll have time to get to know each other."
    scene 08_0459 with dissolve
    mc "Uh, no... You only have five days at the college gym, but I still need you afterward."
    scene 08_0460 with dissolve
    dawn "Do you guys want to sit?"
    $ Plr.Add("Alt")
    jump Lakeshore_ContinueBlazeConvo
return

label Lakeshore_BackToCollege:
    scene 08_0017 with Fade(2, 3, 2)
    pause 0.5
    scene 08_0018 with dissolve
    pause 0.5
    scene 08_0019 with dissolve
    secgrd "Can I help you?"
    mc "I have an appointment."
    scene 08_0020 with dissolve
    secgrd "If you had an appointment, I'd have been informed to expect you."
    mc "Yeah? Guess they forgot."
    secgrd "Name of the person you're visiting?"
    if not Dawn.isActive():
        mct "Crap..."
    scene 08_0021 with dissolve
    mc "The Dean.\nTell her it's the security consultant from Springhaven; she'll know who it is."
    secgrd "Wait here. Don't move!"
    scene 08_0022 with dissolve
    mct "Guess she took me seriously with the security concerns."
    scene 08_0023 with dissolve
    secgrd "She said she's not expecting you... But she'll see you anyway."
    mc "Great."
    scene 08_0024 with dissolve
    secgrd "Confirm your appointment before visiting next time."
    mc "You got it."
    scene 08_0025 with fade1
    if not Dawn.isActive():
        call Lakeshore_MeetDawn
    else:
        pause 0.5
    scene 08_0049 with Fade(2, 2, 1)
    play sound "knock.mp3"
    pause 0.5
    ruth "ENTER."
    scene 08_0050 with dissolve
    ruth "What a pleasant surprise - You've learnt how to knock."
    scene 08_0051 with dissolve
    mc "And you've upgraded security. Well done!"
    scene 08_0052 with dissolve
    ruth "That {i}was{/i} our agreement.\nThere is no need for another inspection."
    ruth "You can report back to your client that Melissa is perfectly safe here."
    scene 08_0053 with dissolve
    ruth "If there's nothing else, I'm extremely busy."
    mc "Actually, there is..."
    mc "I need a job."
    scene 08_0054 with dissolve
    ruth "[lol]"
    ruth "Sorry, comedy isn't on our curriculum."
    scene 08_0055 with dissolve
    mc "I was actually thinking more along the lines of a gym teacher."
    ruth "You're not seriously asking me to hire you?\nAre you insane?"
    mc "No, {i}I'm{/i} not asking..."
    mc "{b}My client{/b} is... and it's more of a demand."
    scene 08_0056 with dissolve
    ruth "This is outrageous!"
    ruth "Why would Ms Robinson require {b}you{/b} to teach gym??"
    scene 08_0057 with dissolve
    mc "She wants me to monitor her daughter.\nMelissa takes a gym class."
    ruth "The {b}girls'{/b} gym class?!\nImpossible!"
    ruth "We have separate gyms for our male and female students.\nThe girls are taught by female instructors, and {b}only{/b} female instructors!"
    mc "I'm sure Ms Robinson won't be happy when I report back to her."
    scene 08_0058 with dissolve
    ruth "Make your threats! But there's nothing I can do.\nI don't have the authority to change that rule."
    ruth "The most I can offer you is an assistant role in the male gym class."
    ruth "But you'll never see Melissa."
    scene 08_0059 with dissolve
    mc "[whi]Fuck."
    scene 08_0060 with dissolve
    mc "Okay... What if I provide a female instructor?"
    ruth "She'd have to be fully qualified and registered in {b}this{/b} state."
    scene 08_0061 with dissolve
    mc "Come on, Ruth!\nIt's only gonna be for a week or two!"
    scene 08_0062 with dissolve
    ruth "You're an {b}asshole{/b}, you know that?"
    ruth "All you do is make demands and offer threats.\nYou expect my help whilst never giving anything in return!"
    scene 08_0063 with dissolve
    mc "My client is very generous to your college! You get plenty!"
    ruth "Yes... {i}the college{/i}!\nIt's {i}always{/i} the college."
    ruth "{b}I'm{/b} the one risking my career! What do {b}I{/b} get??"
    mc "What do you want?"
    scene 08_0064 with dissolve
    ruth "I've sacrificed my life to this damn place."
    ruth "No husband. No children. No life.\nWork. Work. Work."
    ruth "And what do I have to show for this dedication?"
    scene 08_0065 with dissolve
    ruth "Not a goddamn thing!"
    scene 08_0066 with dissolve
    ruth "Do you know what the worst part of working here is?"
    ruth "The forbidden fruit."
    ruth "All these virile, horny young men walking around."
    scene 08_0067 with dissolve
    ruth "Not that any of them would be interested in an old hag like me."
    scene 08_0068 with dissolve
    ruth "But still, the desire remains."
    scene 08_0069 with dissolve
    ruth "Sometimes, a student will stand where you are now, seeking advice, or some other bullshit..."
    scene 08_0070 with dissolve
    ruth "And all I wish he'd do is shut the hell up, get on his knees with his head between my legs, and eat me."
    scene 08_0071 with dissolve
    ruth "It'll never happen, of course... But a girl can dream."
    ruth "Do you know how many {b}decades{/b} have passed since I last had my vagina eaten?"
    scene 08_0072 with dissolve
    ruth "You asked what I wanted..."
    ruth "I want {i}you{/i} to get on your knees and devour me."
    $ tCh=None
    if EzModeActive:
        call EzModeAsk ("Ruth")
        if _return:
            $ Ruth.Add("EZ")
            $ tCh=True
        else:
            mc "No fuckin' way!"
    if not EzModeActive:
        menu:
            "[wk_y]Eat Ruth":
                $ tCh=True
            "No fuckin' way! [wk_c]":
                pass
    if tCh:
        $ Ruth.L=1
        call RuthReplay01
    else:
        call CloseCharacterPath (Ruth, "Ruth")
        scene 08_0075 with dissolve
        mc "You're outta your damn mind, Lady."
        scene 08_0076 with dis1
        scene 08_0077 with dis1
        ruth "Fine!"
        ruth "Ten thousand."
        scene 08_0078 with dissolve
        ruth "That's the price."
        mc "My client will be in touch to arrange the transfer."
        scene 08_0079 with dissolve
        ruth "It was worth a try."
    scene 08_0152 with fade2
    mct "Hope she still monitors this email address... Have no other way of contacting her."
    scene 08_0153 with fade2
    play sound "vib.mp3"
    scene 08_0154 with dis1
    scene 08_0155 with dis1
    stop sound
    mc "Hello?"
    $ cellVoice = "Female voice"
    unk_cell "[whi]Hey."
    scene 08_0156 with dis1
    mc "Damn! That was fast!"
    unk_cell "[whi]You know me.\nWhen the boss tells me to call, I call."
    unk_cell "[whi]What do you need?"
    scene 08_0157 with dis1
    mc "How far away are you from Lakeshore?"
    unk_cell "[whi]Lakeshore? Where the fuck's that??"
    unk_cell "[whi]Gimme a minute..."
    scene 08_0158 with dis1
    scene 08_0159 with dis1
    scene 08_0160 with dis1
    unk_cell "[whi]Okay... About a six-hour drive."
    mc "Could do with your help here."
    scene 08_0161 with dissolve
    unk_cell "[whi]Shit, you've been radio silent for years.\nNow, out of the blue, you're askin' for help and expect me to drop everything for you?"
    unk_cell "[whi]Tomorrow okay?"
    scene 08_0162 with dissolve
    mc "I'll send you the address."
    mc "Blaze... Thanks, appreciate it."
    $ cellVoice = "Blaze"
    unk_cell "[whi]C'mon, man. Don't get all soppy on me.\nI owe you my life five times over, 'course I'm gonna help."
    scene 08_0163 with fade
    play sound "car_pull.mp3"
    scene 08_0164 with dis1
    scene 08_0165 with dis1
    scene 08_0166 with dis1
    pause 0.5
    call CenterText ("Later...", True)
return

label Lakeshore_MeetDawn:
    mct "Hope this {b}IS{/b} the place the professor meant; otherwise I'm screwed."
    scene 08_0026 with dissolve
    mct "Empty.\nAt least Melissa and her buddy aren't in there..."
    scene 08_0027 with fadehold
    mct "Okay... try to look friendly, {b}not{/b} intimidating!\nDon't want to scare her away."
    scene 08_0028 with Fade(1, 3, 2)
    pause 0.5
    scene 08_0029 with dissolve
    $ Dawn_name=""
    dawn "You don't look like a student. Can I help you?"
    mc "Uhh, no, I'm not... I'm just waiting for someone.\nI'm meeting a professor here."
    scene 08_0030 with dissolve
    dawn "Then you must be [mc]."
    dawn "But, a professor??\nYou're mistaken. I'm a lecturer, not a professor."
    scene 08_0031 with dissolve
    dawn "If you {i}were{/i} who you said you were, you would know that."
    mc "I'm sorry. I was told you were a professor.\nI {b}am{/b} here to help her."
    scene 08_0032 with dissolve
    dawn "I have a security guard posted right outside the door."
    dawn "One wrong move and I'll scream."
    scene 08_0033 with dissolve
    mc "That's fair.\nI promise you, I'm only here to help Melissa, nothing more."
    scene 08_0034 with dissolve
    dawn "And how, exactly, are you planning on doing that?"
    mc "I'm, err... not sure yet.\nThat's why I need to talk to you, and her."
    scene 08_0035 with dissolve
    dawn "Speaking to Melissa {i}alone{/i} is out of the question."
    dawn "One of her {i}friends{/i} is always at her side."
    scene 08_0036 with dissolve
    dawn "She attends one of my classes, but even I can't speak privately with her.\nWe have to pass notes to one another {i}very carefully{/i}."
    dawn "She's never alone.\nThey even check the bathroom stalls before letting her... you know."
    scene 08_0037 with dissolve
    dawn "They all live in the same place.\nThree guys watch her, and they work in shifts, so she's constantly guarded."
    mc "Damn it.\nThere must be a way..."
    scene 08_0038 with dissolve
    dawn "She has no social life. No friends."
    dawn "She attends her classes; sometimes they'll allow her to hang out here, and then they go home."
    dawn "The {b}only{/b} place she has to escape them for a while is her gym class."
    scene 08_0039 with dissolve
    dawn "Gym classes are separated by gender, so no guys allowed with the girls, and vice versa."
    dawn "They used to have a female {i}friend{/i} to accompany her, but she hasn't been around for a few months."
    dawn "When she's attending gym class, they wait right outside the whole time."
    scene 08_0040 with dissolve
    mc "Then that's how we get to her."
    dawn "Our college takes single-sex environments seriously. You wouldn't get through the door."
    scene 08_0041 with dissolve
    dawn "Why go through all that anyway?"
    dawn "Can't you just... I don't know... beat up whichever guy's guarding her, and get her out of here??"
    scene 08_0042 with dissolve
    mc "It's not that simple."
    mc "The people her friends work for... They can't know we've taken her. Not immediately anyway."
    mc "We need time to get her to a safe place.\nOnce that call has been made, they'll swarm the whole town to find her."
    mc "I'm guessing her friends have a check-in routine - probably every thirty minutes.\nSomeone doesn't check in, the alarm is sounded."
    scene 08_0043 with dissolve
    dawn "So how the hell are we supposed to do it??"
    scene 08_0044 with dissolve
    mc "That's why I need to talk to Melissa.\nShe'll know their routine better than anyone."
    dawn "Well, like I said... impossible."
    dawn "Sorry, but I have to get to my next class."
    scene 08_0045 with dissolve
    dawn "I wish I could've been of more help."
    mc "Thanks for meeting me, Prof-"
    mc "... Sorry, {i}not{/i} a professor! Heh."
    scene 08_0046 with dissolve
    dawn "Dawn."
    $ Dawn_name="Dawn"
    $ persistent.DawnLocked = False
    $ Dawn.Activate("Dawn")
    mc "Okay. Thank you, Dawn."
    if EzModeActive:
        call EzModeAsk ("Dawn")
        if _return:
            $ Dawn.Add("EZ")
    scene 08_0047 with dissolve
    dawn "I really want to help her if I can.\nYou have my number."
    mc "And you have mine."
    scene 08_0048 with fadehold
    mct "Gym class, huh?... Hmmm... Time to visit my favorite Dean..."
return

label Lakeshore_ContinueBlazeConvo:
    scene 08_0464 with dissolve
    mc "Getting Melissa out is only the first part of the problem..."
    mc "These guys have the resources to quickly get her back if we fuck up."
    scene 08_0465 with dissolve
    mc "I'm gonna need you to scout the local area and find a safehouse."
    mc "I'll need you to stay for a while to look after them."
    scene 08_0466 with dissolve
    dawn "{i}Them{/i}?"
    dawn "You're not including me, are you??"
    scene 08_0467 with dissolve
    mc "Yes, I am."
    mc "Dawn, if this stalker of yours {b}is{/b} connected, then they already suspect you're up to something."
    mc "We can't take that risk."
    scene 08_0468 with dissolve
    dawn "But..."
    dawn "My job... I can't..."
    scene 08_0469 with dissolve
    mc "Don't worry about that. I'll square it with your boss."
    scene 08_0470 with dissolve
    blz "I'm with you - You know that, but I can't babysit forever; I have a life back home."
    mc "I'll get you out of there as soon as it's safe."
    mc "A week... two at the most.\nThat'll buy us enough time to figure out a more permanent solution."
    scene 08_0471 with dissolve
    mc "We'll have a better understanding once you're in contact with Melissa."
    mc "Any info you can get from her on these guys can only help us."
    blz "Relax, Boss.\nHave I ever let you down?"
    mc "Nope. {b}Never{/b}."
    scene 08_0472 with dissolve
    mc "Okay... I guess I'll let you guys get to know each other."
    dawn "You're leaving?"
    mc "Yeah, for now.\nDon't worry, Blaze will look after you."
    scene 08_0473 with dissolve
    mc "I'll be back in a few days."
    scene 08_0474 with dissolve
    mct "Time to get back on the road..."
    if Plr.Has("Alt"):
        $ Plr.Del("Alt")
    else:
        scene 08_0475 with dissolve
        blz "Boss... Hold up."
        scene 08_0476 with dissolve
        blz "It's great to see you, man."
        mc "You too, Blaze."
        scene 08_0477 with dissolve
        blz "I've been worried about you."
        mc "Worried? Why??"
        scene 08_0478 with dissolve
        blz "You were a no-show at Pete's funeral. Not like you."
        blz "I tried reachin' out..."
        mc "Yeah, I know.\nI'm sorry... It took a while to get my head straight."
        scene 08_0479 with dissolve
        blz "So straight that you got up and quit?"
        blz "I didn't believe the rumorsfor a minute... until yesterday!"
        mc "You doggin' on me for quitting??\nYou did the same!"
        scene 08_0480 with dissolve
        blz "Fuck man, no!\nYou should've walked years ago, as I did."
        blz "Serving our country was a privilege, but they took too much."
        scene 08_0481 with dissolve
        blz "I had to get out while I still had a sliver of my soul left."
        blz "You understood that, right?\nI didn't quit on {b}you{/b}, Boss."
        mc "Yeah, I know."
        scene 08_0482 with dissolve
        blz "Okay. I'll see you in a few days then."
        mc "Yeah. Any problems, call me."
        scene 08_0483 with dissolve
        blz "SIR, YES SIR!"
        scene 08_0484 with dissolve
        mct "Still a wise-ass, heh."
    jump Lakeshore_Leave
return

label Lakeshore_Leave:
    $ lakeshore_open=False
    $ lakeshore_ch+=1
    call CheckShOpen
    call UpdateMapInfos
    scene black with Fade(3, 2, 1)
    jump ShowMap
return

label Lakeshore_GetMelissa:
    scene black with Fade(3, 2, 0)
    scene 11_0001 with Fade(0, 2, 3)
    if Sarah.isActive() and Sarah.Has("NoLift"):
        $ Sarah.act=False
    play sound "car2.mp3"
    scene 11_0002 with dissolve
    scene 11_0003 with dissolve
    scene 11_0004 with dissolve
    scene 11_0001 with dissolve
    scene 11_0005 with fade2
    mct "I must've taken a wrong turn somewhere."
    scene 11_0006 with dissolve
    mct "Either that or Blaze sent me the wrong coordinates."
    scene 11_0007 with dissolve
    mct "Hopefully there's somewhere to turn around ahead... before this track disappears completely."
    scene 11_0008 with dis1
    scene 11_0009 with dis1
    scene 11_0010 with dis1
    scene 11_0011 with dis1
    scene 11_0012 with dissolve
    mct "Hold on... Looks like a clearing up ahead."
    scene 11_0013 with dis1
    scene 11_0014 with dis1
    mct "That's her car.\nGuess she gave me the right coordinates after all!"
    scene 11_0015 with dis1
    scene 11_0016 with dis1
    scene 11_0017 with dissolve
    blz "Hey, Boss. Find us okay?"
    mc "Yeah, piece of cake."
    scene 11_0018 with dissolve
    blz "You got lost, didn't ya?"
    mc "Nope!"
    scene 11_0019 with dissolve
    mc "Everything go okay? Where is she?"
    blz "Yeah, smooth as silk. She's inside with Dawn."
    scene 11_0020 with dissolve
    mc "When I said find somewhere quiet to lay low, I wasn't expecting it to be {i}this{/i} quiet."
    scene 11_0021 with dissolve
    mc "How the hell did you find this place?"
    scene 11_0022 with dissolve
    blz "{i}You{/i} trained me. I learned from the best!"
    if EzModeActive:
        call EzModeAsk ("Blaze")
        if _return:
            $ Blaze.Add("EZ")
    blz "I was looking for alternatives, but given the time constraint, it'll do."
    scene 11_0023 with dissolve
    mc "Good job, Sergeant."
    scene 11_0024 with dissolve
    blz "What do you wanna do with Harry?"
    scene 11_0025 with dissolve
    call Emotion (mc, "Sigh", "Blaze...")
    mc "Who the fuck's Harry?"
    scene 11_0026 with dissolve
    scene 11_0027 with dis1
    scene 11_0028 with dis1
    mc "You've got to be kidding me."
    scene 11_0029 with dissolve
    blz "The kid guarding Melissa."
    mc "Why??"
    scene 11_0030 with dissolve
    blz "We needed to move quickly!\nI had to put him {i}somewhere{/i}."
    scene 11_0031 with dissolve
    scene 11_0032 with dissolve
    blz "If I'd have left him tied up in an alley, he would've been found and raised the alarm."
    scene 11_0033 with dissolve
    mc "Goddamnit."
    scene 11_0034 with dissolve
    mc "Secure him in that outbuilding for now."
    blz "Yes, Boss."
    scene 11_0035 with fade
    pause 0.5
    scene 11_0036 with dissolve
    dawn "{b}Please{/b} tell me this is a joke.\nWe're not {i}really{/i} staying here??"
    mc "It won't be for long."
    scene 11_0037 with dissolve
    dawn "Can I at least have my cellphone back?"
    mc "They could use it to track us down.\nI promise you, Dawn, I'll get you home as soon as I can."
    scene 11_0038 with dissolve
    dawn "How long is {i}as soon as I can{/i}?\nDays? Weeks? {b}Months{/b}??"
    dawn "I can't lose my job, [mc]! You gave me your word."
    scene 11_0039 with dissolve
    mc "I know. You won't.\nI'll go see the Dean and straighten it out. Your job will be waiting for you."
    mc "Where's Melissa?"
    scene 11_0040 with dissolve
    dawn "Upstairs. Door at the end of the hallway."
    scene 11_0041 with dissolve
    dawn "Go easy on her. She's fragile."
    mc "I will."
    call AutoA
    scene 11_0042 with dis1
    scene 11_0043 with dis1
    play sound "knock.mp3"
    scene 11_0044 with dis1
    scene 11_0045 with dissolve
    $ apause()
    call AutoA (False)
    meli "Come in."
    scene 11_0046 with dissolve
    mc "Hi, Melissa. I'm-"
    scene 11_0047 with dissolve
    meli "The guy who rescued me."
    scene 11_0048 with dissolve
    meli "Thank you so much."
    mc "Uhh... You're welcome."
    $ persistent.MelissaLocked=False
    $ Melissa.Activate("Melissa")
    scene 11_0049 with dissolve
    mc "You know {i}why{/i} I pulled you out, though, right?"
    scene 11_0050 with dissolve
    meli "You work for my mother."
    meli "You're not going to make me go back to her, are you?"
    mc "Honestly... I haven't decided yet."
    scene 11_0051 with dissolve
    meli "Is there anything I can say to convince you not to?"
    mc "You can tell me {i}why{/i} you don't wanna go home."
    scene 11_0052 with dissolve
    meli "You've met her.\nShe's a control freak. She's suffocating!"
    meli "She doesn't love me! Neither of them do.\nI'm just a pawn in their stupid game."
    scene 11_0053 with dissolve
    meli "Ever since my mother's last attempt to get me back failed, my father has become more and more paranoid."
    meli "I can't even use the bathroom in private now!"
    scene 11_0054 with dissolve
    meli "I just want to live my life in peace.\nDo the normal things other people my age get to do."
    scene 11_0055 with dissolve
    meli "Is that so much to ask?"
    scene 11_0060 with dissolve
    mc "Interesting phrasing... {i}my mother's last attempt to get me back{/i}."
    scene 11_0056 with dissolve
    mc "Not {i}my last attempted escape{/i}."
    mc "Is that why she failed? You sabotaged her plan, didn't you?"
    scene 11_0057 with dissolve
    meli "I didn't want to go back to Springhaven.\nI'd only be swapping one prison for another."
    meli "At least here I get to study. I'm allowed to attend classes."
    scene 11_0058 with dissolve
    meli "My mother would lock me inside the house and throw away the key."
    scene 11_0059 with dissolve
    meli "I told my father her plan."
    meli "When she arrived at our arranged pick-up, instead of me, he was waiting for her."
    meli "He warned her never to contact me again.\nThreatened he'd send me home to her in pieces."
    scene 11_0060 with dissolve
    mc "Jesus.\nYour {b}father{/b} said that?"
    scene 11_0061 with dissolve
    meli "Yeah.\nIt wasn't an empty threat either, and my mother knew it."
    scene 11_0062 with dissolve
    meli "I wasn't expecting him to increase my... {i}security{/i}, though."
    meli "It was bad enough before, but now it's unbearable."
    scene 11_0063 with dissolve
    mc "Whatever I decide, I need you to lay low here for a while."
    mc "Stay inside, and {b}no{/b} contact with anyone."
    scene 11_0064 with dissolve
    meli "So... just {i}another{/i} prison."
    mc "Yeah, for now. But at least you'll get to pee in private."
    scene 11_0065 with dissolve
    mc "If you need anything, talk to Blaze."
    meli "Wait..."
    scene 11_0066 with dissolve
    meli "What's going to happen to Harry?"
    meli "You're not going to kill him, are you??"
    scene 11_0067 with dissolve
    mc "No!"
    mc "I'm not here to kill {b}anyone{/b}."
    scene 11_0068 with dissolve
    meli "Please don't hurt him."
    mc "Why do you care?"
    meli "He's always been nice to me. He was only following my father's orders."
    scene 11_0069 with dissolve
    mc "Well, as long as he's willing to follow {b}my{/b} orders, he'll be fine."
    scene 11_0070 with dissolve
    mct "Jesus."
    scene 11_0071 with Fade(0.5, 1, 1.0)
    scene 11_0072 with dissolve
    mc "What can you tell me about this Harry kid?"
    dawn "Not much."
    scene 11_0073 with dissolve
    dawn "Wherever Melissa would go, he'd be right there with her."
    scene 11_0074 with dissolve
    dawn "He's spent the most time by her side.\nThe others, maybe once or twice a week."
    dawn "He just sits next to her in her classes and tries to look as intimidating as possible."
    scene 11_0075 with dissolve
    dawn "The other students refer to him as her guard dog, because he'd growl at anyone who got too close."
    dawn "He's never spoken a word to me or any of her classmates."
    scene 11_0076 with dissolve
    dawn "He talks with Melissa, though, and she never seems frightened of him."
    dawn "Sometimes I'd see them chatting and had to remind myself they weren't {i}actually{/i} friends."
    scene 11_0077 with dissolve
    mc "How long has he been a part of the group watching her?"
    dawn "He was with her the first day she attended my class."
    dawn "Something changed, though. He watches her much more closely than he used to."
    scene 11_0078 with dissolve
    mc "Is he awake?"
    blz "Yeah."
    mc "Okay, let's go talk to him."
    jump Lakeshore_HarryTalk
return

label Lakeshore_HarryTalk:
    scene 11_0079 with fadehold
    scene 11_0080 with dis1
    scene 11_0081 with dis1
    har "Hello??"
    scene 11_0082 with dis1
    mc "Talk."
    har "Wh--What do you want to know??"
    mc "{b}TALK{/b}!"
    har "I... I... I don't--"
    scene 11_0083 with dissolve
    mc "He doesn't know anything. Kill him."
    blz "Copy."
    scene 11_0084 with dissolve
    har "NO, WAIT! WAIT!!"
    har "I... I WORK FOR ANTON!! ANTON THE AXE!!"
    scene 11_0085 with dissolve
    har "The girl... Melissa... She's his daughter!"
    har "I was just watching her! That's it! I swear, bro!"
    mc "Watching her how?"
    har "Guarding her. Escorting her places. Making sure she didn't run. That's all."
    scene 11_0086 with dissolve
    mc "And if she did run? You'd hurt her?"
    har "No! Jesus, no.\nShe's a nice girl. I'm not like that."
    har "Please, man... I didn't hurt her. Ask her. She'll tell you."
    scene 11_0087 with dissolve
    mc "Who else was assigned to her?"
    har "Just me.\nBilly or Craig takes over sometimes when I need a break, but Melissa doesn't like them."
    mc "Where are Billy and Craig right now?"
    har "Cedar Grove, with Anton."
    scene 11_0088 with dissolve
    mc "He left you alone here to guard his daughter? He must trust you."
    if Nettie.isActive():
        har "He didn't have a choice.\nEveryone's been called to Cedar Grove. Some crew's pushing into our territory down there."
        if TeddyD:
            har "One of the higher-ups was killed; now they want to wipe this crew out. It'll be a bloodbath."
        else:
            har "One of the higher-ups was hurt; now they want to wipe this crew out. It'll be a bloodbath."
    else:
        har "He didn't have a choice.\nEveryone's been called to Cedar Grove. One of the big boss's brothers' gone missing."
        har "He killed his girlfriend and her two sisters! Her daughter, too! It was a bloodbath."
        har "Everyone's searching for him."
    scene 11_0089 with dissolve
    mc "How long before Anton realizes Melissa's gone?"
    har "When he checks in.\nHe doesn't always call, but when he does, he expects me to answer."
    blz "I hid his cell phone at the college.\nForwarded the calls to a burner.\nSo far, nothing."
    scene 11_0085 with dissolve
    har "Please! You need to let her go!\nHe'll kill every one of us!"
    har "Take us back, and we can forget this ever happened!"
    har "I won't say a word!\nIf I told him what happened, he'd kill me anyway!"
    scene 11_0086 with dissolve
    har "You're making a huge mistake!"
    har "He's a maniac, bro!\nI don't wanna die!!"
    har "Please, man... Just let us go, I beg you.\nAnton won't ever find out!"
    scene 11_0090 with dissolve
    har "We've still got time to fix this, bro!"
    har "Take us home, and we'll pretend as if nothing happened!"
    scene 11_0091 with dis1
    scene 11_0092 with dis1
    scene 11_0093 with dis1
    scene 11_0094 with dis1
    mc "Why do you call him {i}Anton the Axe{/i}?"
    har "You've never heard of him??"
    scene 11_0095 with dissolve
    har "He's not normal... craziest motherfucker you'll ever meet."
    har "He has this old Viking axe... carries it everywhere."
    scene 11_0096 with dissolve
    har "I've seen him use it more times than I want to remember."
    har "He takes his time. Cuts people apart like it's fun."
    scene 11_0097 with dissolve
    har "Bro, you don't fuck with Anton... You'll end up in a hundred pieces."
    scene 11_0098 with dissolve
    mc "You're scared of him."
    har "Terrified. You have no idea."
    har "You should be, too."
    scene 11_0099 with dissolve
    mc "Okay, Harry. Hang tight."
    mc "Don't try anything stupid, and you might get to walk away from this."
    scene 11_0100 with dissolve
    har "Where's Melissa? Is she okay?"
    mc "She's fine."
    scene 11_0101 with fade
    blz "What's the plan, Boss?"
    mc "I'm workin' on it."
    scene 11_0102 with dissolve
    blz "You were right, we {b}weren't{/b} ready to do this."
    mc "Doesn't matter, it's too late now."
    scene 11_0103 with dissolve
    blz "... Is it, though?"
    mc "Speak freely, Sergeant."
    scene 11_0104 with dissolve
    blz "We should've waited until we had a {i}full{/i} plan in place."
    blz "One that maybe doesn't include us being killed by a madman with an axe."
    blz "But, you heard him... We still have time to take them back."
    scene 11_0105 with dissolve
    mc "Extracting Melissa was always gonna be the most difficult part."
    mc "It was a risk pulling the trigger early, but it was worth it, and you executed it perfectly."
    mc "If Anton finds us, I'll deal with him."
    scene 11_0106 with dissolve
    mc "But, maybe there's a way we can end this without Anton ever knowing we were even here."
    blz "How so?"
    mc "We point the finger at Harry."
    scene 11_0107 with dissolve
    blz "C'mon, [mc]. He's just a kid."
    mc "If he goes back without Melissa, he's dead.\nHe's gonna have to leave either way."
    blz "You let him leave here, and they find him; first thing he'll do is rat us out!"
    blz "You saw how quick he was to spill to you just now, and you weren't swinging an axe in his face!"
    scene 11_0108 with dissolve
    mc "So let's make sure he understands how terrible it'd be for him if he were to get caught."
    mc "Keep an eye on him. Befriend him.\nI want him to think he can trust you."
    blz "Okay."
    scene 11_0109 with dis1
    scene 11_0110 with dissolve
    mc "You and Harry - how close {i}are{/i} you?"
    scene 11_0111 with dissolve
    meli "We're not."
    mc "You showed concern for him earlier; he did the same for you.\nThat doesn't happen between strangers."
    scene 11_0112 with dissolve
    meli "We're {i}friendly{/i}. That's all."
    meli "I've known him for a long time.\nHe's from Springhaven, too. We went to the same school."
    scene 11_0113 with dissolve
    mc "Did your father ever worry it might turn into something else?"
    meli "No! It was never like that."
    scene 11_0114 with dissolve
    meli "He wouldn't allow me to have a boyfriend. Ever."
    meli "And I'm sure Harry knows exactly what would happen if he crossed that line."
    scene 11_0115 with dissolve
    dawn "I see where this is going..."
    dawn "You want to sell this as a secret romance - two lovers who ran."
    mc "You said it yourself - You sometimes had to remind yourself they weren't actually friends when you saw them together."
    mc "Her father would have noticed the same thing."
    mc "If they {i}really were{/i} in love and planning to escape, today would make sense."
    scene 11_0116 with dissolve
    mc "Would he find it plausible?"
    mc "Even just possible?"
    scene 11_0117 with dissolve
    meli "I... I don't know... maybe."
    meli "He'd believe I'd betray him. But Harry??"
    scene 11_0118 with dissolve
    dawn "He'll believe it."
    dawn "Men do stupid, crazy shit when love's involved."
    scene 11_0119 with dissolve
    mc "I need you to write him a note confessing your love for Harry."
    mc "Say you've both decided to run - start over somewhere new. Fill it with as much romantic bullshit as you can come up with."
    mc "Make it dramatic. Messy.\nI want it to read like a bad love story."
    scene 11_0114 with dissolve
    meli "He won't stop looking.\nFor me... for {b}us{/b}."
    meli "Where's Harry? What have you done to him?"
    scene 11_0116 with dissolve
    mc "Relax. He's fine."
    mc "I'm letting him go. Giving him time to get far away."
    scene 11_0120 with dissolve
    dawn "You're letting him go??\nWhat if he runs straight back to her father?"
    mc "He won't."
    mc "Not if he believes going back means dying on the spot."
    scene 11_0121 with dissolve
    mc "Which is the reason I need to ask my next question..."
    mc "Are either of you wearing underwear?"
    meli "What?!"
    scene 11_0122 with dissolve
    mc "I need to borrow a pair of panties."
    dawn "Why??"
    scene 11_0123 with Fade(2, 2, 1)
    call AutoA
    $ apause(1)
    scene 11_0124 with dis1
    $ apause()
    call AutoA (False)
    scene 11_0125 with fadehold
    blz "As long as you do what he asks, you'll be alright."
    har "[whi]Okay."
    scene 11_0126 with dissolve
    blz "He's back. Don't move."
    scene 11_0127 with dis1
    pause 0.5
    scene 11_0128 with dis1
    call Emotion (mc, "Whispering")
    scene 11_0129 with dis1
    call Emotion (blz, "Whispering")
    scene 11_0130 with dis1
    pause 0.5
    scene 11_0131 with dis1
    blz "Good news, Harry.\nHe's agreed to let you go."
    blz "But he wants you to do one little thing before you leave."
    scene 11_0132 with dissolve
    blz "You need to masturbate."
    har "WHAT?? NO!"
    har "Why??"
    scene 11_0133 with dissolve
    blz "I know, it's a strange demand."
    blz "But think about it for a second!\n{b}That's all{/b} you need to do, and you'll be free!"
    scene 11_0134 with dissolve
    mc "Is he refusing, Sergeant?"
    mc "Take out your sidearm and point it at his head."
    scene 11_0133 with dissolve
    blz "Harry... Don't make me do this..."
    scene 11_0135 with dissolve
    har "WAIT!"
    har "OKAY!! I'LL DO IT!!"
    call CenterText ("Ten minutes later...", True)
    scene 11_0136 with dissolve
    mc "Hurry up."
    har "I... I'm trying!!"
    har "Shit!... I'm too nervous! I... I can't concentrate!!"
    mc "Sergeant."
    scene 11_0137 with dis1
    scene 11_0138 with dis1
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e11/11_0139.webp", 425, 306, True, "Lakeshore_AF02") with dis1
        blz "This is as much as you get."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 11_0139
            hide screen imgMap
    else:
        scene 11_0139 with dis1
        blz "This is as much as you get."
        if not EzModeActive:
            menu:
                "[wk_y]Check Blaze out":
                    call Lakeshore_AF02
                "Don't":
                    pass
        elif Blaze.Has("EZ"):
            call Lakeshore_AF02
    scene 11_0141 with dissolve
    pause
    call CharCum ("e11/11_0141.webp", "e11/11_0142.webp", har, "...Fuck...")
    scene 11_0143 with dissolve
    scene 11_0144 with dissolve
    scene 11_0145 with dissolve
    blz "Clean up your mess."
    scene 11_0146 with dissolve
    har "Are these... Panties?"
    scene 11_0147 with dissolve
    mc "Melissa's. And now they have your semen on them."
    mc "They'll be left in her room. Trashed. With a few drops of her blood on the floor."
    scene 11_0148 with dissolve
    har "You're... You're framing me!"
    scene 11_0149 with dissolve
    blz "No. He's making sure you understand the rules."
    blz "There's no walking this back. No explanations. No second chances."
    blz "If Anton finds you after this..."
    har "He'll kill me. He won't even ask... he'll just..."
    scene 11_0150 with dissolve
    mc "He'll make it slow. You'll suffer an agonizing death."
    har "Fuckin' hell."
    scene 11_0151 with dissolve
    mc "Wait for Anton to check in.\nOnce Harry's answered, take him to the station."
    mc "Put him on a train that travels out of state."
    blz "Sir."
    scene 11_0152 with dissolve
    mc "Only a fool would ever come back here, Harry."
    mc "You're not a fool, are you?"
    har "[whi]No, Sir."
    scene 11_0153 with fadehold
    scene 11_0154 with dis1
    call Emotion (mc, "Exhales deeply")
    mc "[whi]Sorry, Kid."
    scene 11_0155 with dis1
    scene 11_0156 with dis1
    scene 11_0157 with dis1
    dawn "Bring my underwear back?"
    mc "Uh, no.\nI'll need to wash them first."
    dawn "Oh jeez... Just keep them."
    scene 11_0158 with dissolve
    mc "How's your letter coming along?"
    meli "I'm still working on it."
    mc "Okay. Give it to Blaze before she leaves.\nShe'll leave it somewhere for your father to find."
    scene 11_0159 with dissolve
    mc "I'll be back soon.\nGonna go see the Dean about your job."
    scene 11_0160 with dissolve
    dawn "Great. Thank you."
    scene 11_0161 with dissolve
    pause 0.5
    jump Lakeshore_SeeRuth
return

label Lakeshore_SeeRuth:
    scene 11_0162 with Fade(2, 3, 2)
    call AutoA
    play sound "knock.mp3"
    $ apause()
    scene 11_0163 with dissolve
    $ apause(1)
    call AutoA (False)
    ruth "COME IN."
    scene 11_0164 with dissolve
    ruth "My, my.\nAn unexpected pleasure."
    scene 11_0165 with dissolve
    ruth "Let me guess... Your client demands my help yet again."
    mc "Something like that."
    scene 11_0166 with dissolve
    ruth "Very well."
    ruth "Lay out your demands, and I shall name my price."
    scene 11_0167 with dissolve
    mc "Melissa won't be attending her classes... for a while.\nI don't want you to kick up a fuss about it."
    mc "One of her lecturers - Dawn - also needs a two-week leave of absence, minimum."
    mc "No questions.\nIf anyone asks, she's here as normal."
    if not Ruth.isActive():
        scene 11_0168 with dissolve
        ruth "That's a lot."
        ruth "You're asking me to cover the unauthorized absence of a student, and a member of staff..."
        ruth "The price will be high."
        scene 11_0169 with dissolve
        mc "Whatever the cost of your {i}loyalty{/i}, you know my client will cover it."
        mc "And when Melissa's father comes asking questions, I was never here."
        mc "Guarantee me that, and you'll earn yourself a nice bonus payment when this is all over."
        mc "Do we have a deal?"
        scene 11_0170 with dissolve
        ruth "We certainly do."
        scene 11_0171 with dissolve
        ruth "Two weeks.\nAny longer and we'll need to re-negotiate."
        scene black with ReplayFade
        jump Lakeshore_ReturnToHideout
    scene 11_0172 with dissolve
    ruth "Covering the unauthorized absence of a student, and a member of staff..."
    scene 11_0173 with dissolve
    ruth "You're asking for a lot! The price will be high."
    ruth "The only question is..."
    scene 11_0174 with dissolve
    ruth "How are you willing to pay for it?"
    $ tCh=Ruth.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Whatever it takes":
                $ tCh=True
            "My client will pay whatever you demand[wk_c]":
                $ tCh=False
    if not tCh:
        call CloseCharacterPath (Ruth, "Ruth")
        scene 11_0175 with dissolve
        scene 11_0176 with dissolve
        ruth "That's disappointing..."
        scene 11_0177 with dissolve
        ruth "But acceptable."
        scene 11_0178 with dissolve
        ruth "You have two weeks."
        scene 11_0179 with dissolve
        ruth "Any longer and we'll need to re-negotiate."
        jump Lakeshore_ReturnToHideout
    mc "I'll pay whatever it takes."
    scene 11_0180 with dissolve
    ruth "Good boy."
    ruth "I'm just about done here for the day.\nYou may drive me home."
    scene black with Fade(2, 3, 0)
    scene 11_0181 with fade
    scene 11_0182 with dis1
    scene 11_0183 with dis1
    scene 11_0184 with dis1
    scene 11_0185 with dis1
    mc "Nice place."
    ruth "Make yourself comfortable. I'll be back in a moment."
    call AutoA
    scene 11_0186 with Fade(1, 2, 1)
    $ apause(1.5)
    scene 11_0187 with Fade(1, 2, 1)
    $ apause(1.5)
    call AutoA (False)
    scene 11_0188 with Fade(1, 2, 1)
    mct "She's been gone a while..."
    scene 11_0189 with dissolve
    mct "Make yourself comfortable..."
    mct "Fine, I WILL."
    scene 11_0190 with fadehold
    mct "Heh."
    ruth "Drink?"
    scene 11_0191 with dissolve
    mc "No thanks."
    scene 11_0192 with dissolve
    ruth "Good, I can see we do not need to engage in small talk."
    scene 11_0193 with dissolve
    ruth "Follow me..."
    scene 11_0194 with dissolve
    pause 1.0
    call RuthReplay02
    scene 11_0267 with fade
    ruth "I had hoped it would last longer."
    ruth "I'm not laying blame on you; it was {b}my{/b} fault.\nI became over-stimulated!"
    scene 11_0268 with dissolve
    ruth "It's been so long, I simply lost control."
    ruth "You held up your end, so I have no complaints."
    scene 11_0269 with dissolve
    ruth "I meant what I said in the bedroom, though... I hope you'll consider coming back."
    $ tCh=Ruth.Has("EZ")
    if not EzModeActive:
        menu:
            "Not a chance [wk_c]":
                $ tCh=False
            "[wk_y]I'll be back":
                $ tCh=True
    if tCh:
        scene 11_0271 with dissolve
        if persistent.Anal:
            $ dia = "Of course I'll be back.\nI haven't fucked " + ("{i}mommy{/i}" if persistent.RuthPet else "you ")+" in the ass yet."
        else:
            $ dia = "Of course I'll be back.\nI didn't get a taste of  " + ("{i}mommy's{/i}" if persistent.RuthPet else "your ")+" hairy pussy today."
        mc "[dia]"
        ruth "I'll give you my number."
    else:
        scene 11_0270 with dissolve
        mc "Don't hold your breath."
        call CloseCharacterPath (Ruth, "Ruth")
    scene black with ReplayFade
    jump Lakeshore_ReturnToHideout
return

label Lakeshore_ReturnToHideout:
    scene 11_0272 with dis1
    scene 11_0273 with dis1
    scene 11_0274 with dis1
    scene 11_0275 with dis1
    scene 11_0276 with dissolve
    scene 11_0277 with dissolve
    blz "Hey, Boss."
    blz "You were gone a while."
    blz "Thought you'd decided to go back to Springhaven."
    scene 11_0278 with dissolve
    mc "Drove around for a while, trying to clear my head."
    mc "Everything go okay?"
    blz "Yeah.\nI left Melissa's note in her bedroom for her father to find, and Harry's on the train."
    scene 11_0279 with dissolve
    blz "Kinda feel bad for the kid. You frightened the hell outta him."
    scene 11_0280 with dissolve
    mc "Yeah, me too."
    mc "He won't have to run forever, though.\nAs long as he keeps moving for now, he'll be fine."
    scene 11_0281 with dissolve
    blz "Decided what to do with Melissa?"
    blz "She {b}really{/b} doesn't want to go back to her mother."
    mc "Don't blame her."
    mc "She'll have to stay here and lie low, whatever the outcome, so it gives me a few days to figure it out."
    scene 11_0282 with dissolve
    mc "Good work today, Blaze.\nI'm glad you're here."
    blz "Wouldn't have it any other way, Boss."
    mc "Where's Dawn? Need to speak to her."
    blz "Upstairs, in her room."
    scene 11_0283 with fade
    call AutoA
    play sound "knock.mp3"
    $ apause()
    scene 11_0284 with dis1
    $ apause(1)
    call AutoA (False)
    dawn "Come in."
    scene 11_0285 with dissolve
    mc "Hey.\nI spoke to the Dean."
    mc "Your job's safe. You have two weeks of paid vacation."
    dawn "Wow, thank you!\nThat's a weight off my mind."
    dawn "Do you have a second to talk?"
    scene 11_0286 with dissolve
    mc "Sure. What's up?"
    if Sarah.isActive():
        dawn "Can you tell Sarah what's going on?\nYou know what she's like; she'll worry if I don't answer my cell."
        mc "Yeah, of course."
        scene 11_0287 with dissolve
        dawn "Maybe next time you're visiting us, you could bring her?"
        mc "Yeah, maybe. I'll talk to her."
        dawn "Good. Thanks."
        if Dawn.Has("Wait"):
            scene 11_0288 with dissolve
            dawn "I, uhh... spoke to her the other day..."
            dawn "She gave us the go-ahead... You know... if you're still interested."
            dawn "She said she was a little jealous, but still happy for me."
            mc "Oh, right..."
            scene 11_0289 with dissolve
            dawn "I'm not trying to put you on the spot!"
            dawn "Just saying... when you're ready for bed - this one {i}could{/i} be big enough for both of us... If you wanted."
            scene 11_0293 with dissolve
            mc "I may see you later then."
            dawn "I'll look forward to it."
        elif Dawn.isSexual():
            scene 11_0288 with dissolve
            dawn "If you're staying the night, feel free to share this bed."
            scene 11_0290 with dissolve
            mc "I might take you up on that.\nThe couch doesn't look very comfy!"
            dawn "And yet you'll probably get more sleep on it than you will in here!"
            scene 11_0292 with dissolve
            dawn "But it definitely won't suck your dick."
            mc "You make a compelling case!"
            scene 11_0293 with dissolve
            mc "I may see you later then."
            dawn "I'll look forward to it."
        else:
            scene 11_0293 with dissolve
            mc "I'll see you later."
            dawn "Okay."
    else:
        dawn "You're from Springhaven, right?"
        mc "Yeah."
        scene 11_0287 with dissolve
        dawn "My best friend, Sarah, lives there.\nIf I give you her address, can you let her know what's happening?"
        dawn "It's just... She worries about me... and she knows I've been going through the whole stalker thing."
        scene 11_0288 with dissolve
        dawn "If she doesn't hear from me, she'll probably call the cops!"
        dawn "And since I'm not allowed my cell phone..."
        scene 11_0289 with dissolve
        mc "Okay, you've made your point.\nGive me the address before I leave tomorrow, and I'll go see her."
        dawn "Great."
        dawn "You're staying the night?"
        mc "Yeah... Uh, is that a problem?"
        scene 11_0290 with dissolve
        dawn "No!\nIt's just... all the beds are taken."
        mc "I'll sleep on the couch, it's fine."
        dawn "I've been sitting on that thing since we got here.\nIt's not at all comfortable!"
        scene 11_0291 with dissolve
        dawn "You're welcome to share this bed!"
        dawn "I promise I'll try to keep my hands to myself!"
        scene 11_0292 with dissolve
        mc "You'll {i}try{/i}?"
        $ tCh=Dawn.Has("EZ")
        if not EzModeActive:
            menu:
                "Thanks, but the couch will do[wk_c]":
                    $ tCh=False
                "[wk_y]You're not worried about MY hands?":
                    $ tCh=True
        if tCh:
            mc "You not worried about {b}my{/b} hands?"
            dawn "Depends. Are they cold?"
            mc "No."
            dawn "Then, no."
            scene 11_0293 with dissolve
            mc "I may see you later then."
            dawn "I'll look forward to it."
        else:
            mc "Couch is fine."
            call CloseCharacterPath (Dawn, "Dawn")
            scene 11_0293 with dissolve
            mc "See you in the morning."
            dawn "Good night."
    scene 11_0294 with dissolve
    play sound "knock.mp3"
    scene 11_0295 with dis1
    pause 0.5
    meli "Come in."
    scene 11_0296 with dissolve
    mc "Uhh... You okay?"
    call Emotion (meli, "Ughh", "I'm so bored!")
    meli "There's nothing to do here!"
    mc "Get used to it; you could be here a while."
    scene 11_0297 with dissolve
    meli "Does that mean you're not taking me back to my mother?"
    mc "No, I haven't decided yet."
    mc "Even if your father believes you and Harry ran away together, the first place he's gonna check is Springhaven."
    mc "So it's safer for you to stay here for the time being."
    scene 11_0298 with dissolve
    meli "I know you're trying to help, and I'm sorry if I've come across as ungrateful... I'm just tired of this bullshit."
    meli "And thank you for letting Harry leave.\nI know you're using him, but at least you've given him a chance."
    meli "He's not a bad guy. Not like the rest of my father's thugs."
    scene 11_0299 with dissolve
    mc "So you {b}do{/b} like him, huh?"
    mc "Maybe the story we've spun isn't so unbelievable after all."
    scene 11_0300 with dissolve
    meli "No, I've never liked him like {i}that{/i}; he's not my type."
    meli "He treated me with respect and was kind.\nWe weren't friends, but he was the closest thing I had to one."
    scene 11_0301 with dissolve
    mc "It's been a long day. Get some rest.\nIf you need anything, I'll be downstairs."
    meli "Okay, goodnight."
    scene 11_0302 with fade1
    blz "You ain't gonna make me take the couch, are you?"
    mc "You know me better than that!"
    scene 11_0303 with dissolve
    blz "Need anything before I crash?"
    mc "Nah, I'm good - goodnight, Blaze."
    if Blaze.Has("Look"):
        scene 11_0304 with dissolve
        blz "Hey, can I ask you something?"
        blz "When Harry was doing his deed, and I got my tits out..."
        scene 11_0305 with dissolve
        blz "It's not the first time you've seen them, but you've never looked at me {i}that{/i} way before."
        mc "Sorry, I didn't mean to make you uncomfortable."
        scene 11_0306 with dissolve
        blz "Hah! I don't care that you looked."
        blz "I was just curious; why now but not back then?"
        scene 11_0307 with dissolve
        mc "Simple answer: I was married."
        blz "Oh, okay."
        scene 11_0308 with dissolve
        blz "But you know, looking {i}isn't{/i} cheating, right?"
        mc "I wasn't a great husband, but I always respected my marriage. I owed her at least that."
        scene 11_0309 with dissolve
        blz "Fair enough."
        blz "Goodnight, Boss."
        mc "Night."
    scene 11_0310 with fade1
    mct "Damn. It's like sleeping on a pile of bricks."
    if Dawn.isActive():
        $ tCh=Dawn.Has("EZ")
        pause 0.5
        if not EzModeActive:
            menu:
                "[wk_y]Sleep with Dawn":
                    $ tCh=True
                "Stay on the couch":
                    $ tCh=False
        if tCh:
            call DawnReplay03
            scene 11_0422 with Fade(0,1,3)
            call Emotion (mc, "Groan", "", True)
            scene 11_0423 with dissolve
            if Pix_Chloe:
                play sound "text.mp3"
                pause 0.5
                scene 11_0424 with dissolve
                pause 0.5
                call Msg_Chloe01
                $ Plr.Add("ChoMsg")
                scene 11_0425 with dissolve
                mct "Heh."
            else:
                pause 0.5
            scene 11_0429 with fade
            jump Lakeshore_HideoutDay02
    scene 11_0426 with fade1
    mc "[whi]..Zzzz.."
    scene black with ReplayFade
    scene 11_0427 with Fade(0,1,3)
    call Emotion (mc, "Groan", "", True)
    scene 11_0428 with dissolve
    jump Lakeshore_HideoutDay02
return

label Lakeshore_HideoutDay02:
    blz "Mornin', Boss."
    mc "[whi]Morning."
    dawn "Coffee?"
    mc "[whi]Yeah, please."
    scene 11_0430 with fade1
    blz "You heading back to Springhaven this morning?"
    scene 11_0431 with dissolve
    mc "Yeah."
    mc "I need to update Sue; hopefully she'll be back from Cedar Grove."
    scene 11_0432 with dissolve
    dawn "So we just sit around here for days until we hear from you??"
    dawn "That's going to drive me insane!"
    scene 11_0433 with dissolve
    mc "It's for your own safety."
    mc "You can help by keeping an eye on Melissa."
    scene 11_0434 with dissolve
    blz "Doubt she'll try anything stupid."
    blz "She may be bored, but she's happy to be here."
    scene 11_0435 with dissolve
    mc "Where is she?"
    dawn "Still in bed."
    scene 11_0436 with fade1
    blz "If you make a list of everything you need, I can swing by your apartment later today."
    dawn "That'll be great. Thanks, Blaze."
    scene 11_0437 with dissolve
    mct "Guess I should make a move."
    mct "Hate to admit it, but I'm a little uncomfortable leaving Blaze alone here to watch over them."
    mct "If this Anton guy is as bad as Harry made him out to be..."
    scene 11_0438 with dissolve
    mct "C'mon, man... Blaze is a good soldier. They'll be fine."
    mct "I can come back in a day or two."
    if Pix_Chloe:
        play sound "text.mp3"
        pause 0.5
        scene 11_0439 with dissolve
        pause 0.5
        if not Plr.Has("ChoMsg"):
            call Msg_Chloe01 (False)
            call Msg_Chloe02 (True)
        else:
            call Msg_Chloe02 ()
        $ Plr.Del("ChoMsg")
        scene 11_0440 with dissolve
        pause
        scene 11_0441 with dissolve
        dawn "How come you get to keep {i}your{/i} phone??"
        mc "It's a burner.\nI'm forwarding my calls and messages to it.\nThey can't track it."
    scene 11_0442 with dissolve
    mc "Okay, I'm gonna get going.\nI'll be back in a couple of days."
    blz "I'll walk you out."
    scene 11_0443 with dissolve
    dawn "You'll remember to talk to Sarah, right?"
    mc "Yeah, don't worry."
    scene 11_0444 with fade1
    mc "Any hint of trouble and you call me."
    blz "Relax. I got this."
    scene 11_0445 with dissolve
    mc "Is it {i}really{/i} necessary for you to go to Dawn's apartment?"
    blz "Yeah.\nWe're both gonna need clean clothes 'n stuff."
    blz "Don't worry, I'll be careful."
    scene 11_0446 with dissolve
    mc "Melissa's gonna need stuff, too.\nYou ain't planning on going back to her place, are you?"
    blz "No.\nI picked up some things for her yesterday when I planted the letter."
    blz "If she needs anything else, I'll go to a store in the next town over."
    scene 11_0447 with dissolve
    blz "This isn't my first rodeo, Boss!!\nStop worrying!"
    mc "I know. Sorry."
    $ tCh=Blaze.Has("EZ")
    if not EzModeActive:
        menu:
            "Leave":
                $ tCh=False
            "[wk_y]Hug her goodbye":
                $ tCh=True
    if tCh:
        $ Blaze.Score(1)
        $ Blaze.Add("Hug")
        scene 11_0448 with dissolve
        mc "Call me if you need me."
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e11/11_0449.webp", 1042, 704, True, "Lakeshore_AF03") with dissolve
            blz "Wow! Not like you to initiate a hug!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 11_0449
                hide screen imgMap
                mc "First time for everything!"
        else:
            scene 11_0449 with dissolve
            blz "Wow! Not like you to initiate a hug!"
            if not EzModeActive:
                menu:
                    "[wk_y]Slide your hand down":
                        call Lakeshore_AF03
                    "Don't":
                        mc "First time for everything!"
            else:
                call Lakeshore_AF03
    scene 11_0454 with fade
    pause 1.0
    jump Lakeshore_PhonecallFromSue
return

label Lakeshore_PhonecallFromSue:
    scene 11_0455 with Fade (1, 2, 1)
    play sound "car2.mp3"
    scene 11_0456 with dissolve
    scene 11_0457 with dissolve
    scene 11_0458 with dissolve
    scene 11_0455 with dissolve
    scene 11_0459 with Fade(2, 3, 2)
    play sound "vib.mp3"
    scene 11_0460 with dis1
    scene 11_0461 with dissolve
    stop sound
    mc cell "Hello?"
    sue cell "You are required in Cedar Grove.\nI will forward you the address. Leave immediately."
    mc cell "Are you kidd--"
    mc cell "HELLO? SUE??"
    scene 11_0462 with dissolve
    mc "Goddamnit!!"
    scene 11_0463 with dissolve
    scene 11_0464 with dis1
    scene 11_0465 with dis1
    scene black with Fade(3, 2, 0)
    jump CedarGrove_JoinSue
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
