label DawnReplay01:
    call Unlocker ("DawnReplay01")
    $ Dawn.incSex()
    scene 03_0753 with Fade(1, 0.5, 1)
    call Moan (dawn, 4)
    scene 03_0754 with dissolve
    dawn "[ss]..Mhhh.."
    scene 03_0755 with dissolve
    sar "[whi]Want some company?"
    scene 03_0756 with hpunch
    dawn "FUCK!!{w=1.0}{nw}"
    scene 03_0757 with dissolve
    dawn "You scared the hell out of me!"
    sar "Sorry!"
    sar "What are you doing under there?"
    scene 03_0758 with dissolve
    dawn "Masturbating to the sound of you and [persistent.McName] fucking."
    scene 03_0759 with dissolve
    sar "We were hoping... you'd like to join us."
    dawn "Are you serious??"
    dawn "I didn't think you'd want..."
    sar "I do."
    scene 03_0760 with dissolve
    sar "We both do."
    scene 03_0761 with dis1
    pause 0.5
    scene 03_0762 with dis1
    pause 0.5
    scene 03_0763 with dissolve
    sar "I think she's going to say yes."
    scene 03_0764 with dissolve
    scene 03_0765 with dis1
    scene 03_0766 with dis1
    scene 03_0767 with dis1
    dawn "I'm all yours."
    scene 03_0768 with dis1
    dawn "I can't believe you convinced her!"
    scene 03_0769 with dissolve
    dawn "Are we both pretending to be drunk again?"
    sar "Not this time."
    scene 03_0770 with dissolve
    dawn "[ss]Mmh."
    scene 03_0771 with dissolve
    sar "[ss]..Nnhh.."
    scene 03_0772 with dissolve
    dawn "[ss]..Ohhh.."
    scene 03_0773 with dissolve
    dawn "[ss]..Mmhh.."
    scene 03_0774 with dissolve
    pause
    scene 03_0775 with dissolve
    dawn "[ss]..Nnnhhh.."
    scene 03_0776 with dis1
    pause 0.5
    scene 03_0777 with dis1
    dawn "[ss]..Mmhh.."
    scene 03_0778 with dissolve
    image r_dawn_01 = Movie(play="images/e03/03_0779.webm")
    show r_dawn_01 with dissolve
    dawn "[ss]..Mmmmmhhhh.."
    scene 03_0780 with dissolve
    image r_dawn_02 = Movie(play="images/e03/03_0781.webm")
    show r_dawn_02 with dissolve
    dawn "[ss]..Mmmhhh.."
    scene 03_0782 with dissolve
    pause
    scene 03_0783 with fade
    pause
    scene 03_0784 with dissolve
    dawn "[ss]..Mmhhh.."
    if persistent.Anal:
        scene 03_0785 with dissolve
        call Moan (dawn, 4)
        scene 03_0786 with dis1
        pause 0.5
        scene 03_0787 with dis1
        pause 1.0
        scene 03_0788 with dissolve
        call Moan (sar, 5)
        scene 03_0789 with dissolve
        sar "[ss]..OHHH.."
        scene 03_0790 with dissolve
        call Moan (sar, 10)
        scene 03_0791 with dissolve
        sar "[ss]..Ohhhhhh.."
        scene 03_0792 with dissolve
        dawn "[whi]Oh my...\nIs he eating your {i}asshole{/i}?!"
        sar "[ss]...Mmh-hmm..."
        scene 03_0793 with dissolve
        dawn "[whi]Damn... What's {i}that{/i} like?"
        scene 03_0794 with dissolve
        sar "[whi]Would you like to find out?"
        dawn "[whi]No!"
        dawn "[whi]..."
        scene 03_0795 with dissolve
        dawn "[whi]Yes."
        scene 03_0796 with dissolve
        pause 1.0
        scene 03_0797 with dis1
        pause 1.0
        scene 03_0798 with dis1
        dawn "[ss]..OHHH.."
        scene 03_0799 with dissolve
        pause
        scene 03_0800 with dissolve
        dawn "[ss]..Mmhhh.."
        scene 03_0801 with dissolve
        call Moan (sar)
        scene 03_0806 with dis1
        dawn "[ss]..OHHH.."
        scene 03_0807 with dissolve
        pause
        image r_dawn_03 = Movie(play="images/e03/03_0808.webm", loop=False, keep_last_frame=True)
        show r_dawn_03 with dissolve
        pause 1.0
        sar "[ss]..Mmmhhh..{w=2}{nw}"
        pause 0.5
        sar "[ss]..OHHH.."
        scene 03_0809 with dissolve
        image r_dawn_04 = Movie(play="images/e03/03_0810.webm")
        show r_dawn_04 with dissolve
        call Moan (dawn)
        scene 03_0811 with dissolve
        dawn "[ss]..Ohhhhh..."
        scene 03_0812 with dis1
        pause 0.5
        scene 03_0813 with dis1
        call Moan (dawn, 7)
        scene 03_0814 with dissolve
        image r_dawn_05 = Movie(play="images/e03/03_0815.webm")
        show r_dawn_05 with dissolve
        sar "[ss]..OHHH.."
        scene 03_0818 with dissolve
        dawn "[ss][persistent.McName]..."
    else:
        scene 03_0802 with dissolve
        pause  
        scene 03_0803 with dissolve
        sar "[ss]..Ohhhhhh.."
        scene 03_0804 with dissolve
        sar "[ss].Nnnhhhh.."
        scene 03_0805 with dissolve
        call Moan (dawn)
        scene 03_0816 with dissolve
        sar "[ss].Nnnhhh.."
        scene 03_0817 with dissolve
        pause 0.2
        call Loop_Punch (5, "e03/03_0818.webp", "e03/03_0817.webp")
    scene 03_0819 with dissolve
    dawn "[whi]I want to feel {i}your{/i} tongue in my pussy."
    scene 03_0820 with fade1
    dawn "[ss]..Mmhhh.."
    scene 03_0821 with dissolve
    pause
    scene 03_0822 with dissolve
    call Moan (sar)
    scene 03_0823 with Fade(0.5, 1, 0.5)
    sar "[ss]..Ohhhhhh.."
    call Loop_Punch (6, "e03/03_0824.webp", "e03/03_0825.webp")
    call CharCum ("e03/03_0825.webp", "e03/03_0826.webp", sar, "....OHHHHH!!....")
    call CharCum ("e03/03_0826.webp", "e03/03_0827.webp", sar, "..Ohhhhhhh..")
    scene 03_0828 with dissolve
    sar "[ss]..Mmmhhh.."
    dawn "[ss]My turn."
    scene 03_0829 with fade1
    pause
    scene 03_0830 with dissolve
    image r_dawn_06 = Movie(play="images/e03/03_0831.webm", loop=False, keep_last_frame=True)
    show r_dawn_06 with dissolve
    pause 1.0
    dawn "[ss]..Mmmhhh..{w=2}{nw}"
    pause 0.5
    dawn "[ss]..OHHH.."
    scene 03_0832 with dissolve
    call Moan (dawn)
    scene 03_0833 with dissolve
    image r_dawn_07 = Movie(play="images/e03/03_0834.webm")
    show r_dawn_07 with dissolve
    dawn "[ss]....Mmmhhh...."
    scene 03_0835 with dissolve
    sar "[ss]..Mhhh.."
    scene 03_0836 with dissolve
    call Moan (dawn)
    scene 03_0837 with dissolve
    dawn "[whi]I haven't had {i}your{/i} pussy, yet..."
    scene 03_0838 with fade1
    dawn "[ss]..Nnhhh.."
    scene 03_0839 with dissolve
    sar "[ss]..Mhhh.."
    scene 03_0840 with dissolve
    image r_dawn_08 = Movie(play="images/e03/03_0841.webm")
    show r_dawn_08 with dissolve
    sar "[ss]....Mmmhhh...."
    scene 03_0842 with fade1
    dawn "[ss]..Ohhh, fuck....Yes [persistent.McName]....OHHH...."
    scene 03_0843 with dissolve
    call Moan (dawn)
    scene 03_0844 with dissolve
    dawn "[ss]..YES.....OHHHHHHHH......."
    scene 03_0845 with dissolve
    image r_dawn_09 = Movie(play="images/e03/03_0846.webm")
    show r_dawn_09 with dissolve
    dawn "[ss]....OHHHHH GOD......."
    dawn "[ss]...YES....YES....OHHHHH....."
    call CharCum ("e03/03_0845.webp", "e03/03_0847.webp", dawn, "....OOOOOOHHHHH!!....")
    call CharCum ("e03/03_0847.webp", "e03/03_0848.webp", dawn, "..MHHHHHHHH..")
    scene 03_0849 with dissolve
    call Loop_Punch (6, "e03/03_0850.webp", "e03/03_0849.webp")
    call CmOpts (["Cum inside Dawn", "Pull out", "Cum in Sarah's mouth", "Cum on Sarah's face"])
    $ Copt=_return
    if Copt==0:
        $ Dawn.incCm()
        call CharCum ("e03/03_0849.webp", "e03/03_0851.webp", mc, "..NNNGGGGGHHHH!!...")
        scene 03_0852 with dissolve
        pause 
        scene 03_0853 with dissolve
        dawn "Not trying to get me pregnant, are you, [persistent.McName]?"
    elif Copt==1:
        call CharCum ("e03/03_0849.webp", "e03/03_0854.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e03/03_0854.webp", "e03/03_0855.webp", mc, "....nnnnhhhhh...")
        scene 03_0856 with dissolve
        pause
        scene 03_0857 with dissolve
        sar "That was the {b}best{/b} sex I've ever had!"
        dawn "[ss]Mmhhhh.... Me too!"
    elif Copt==2:
        scene 03_0858 with dissolve
        mc "[whi]Come here..."
        call CharCum ("e03/03_0859.webp", "e03/03_0860.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e03/03_0860.webp", "e03/03_0861.webp", mc, "....nnnnhhhhh...")
        scene 03_0862 with dissolve
        dawn "[ss]I want some!"
        scene 03_0863 with dissolve
        pause
        scene 03_0864 with dissolve
        dawn "[ss]..Mmhhhh.."
        scene 03_0865 with dissolve
        sar "That was the {b}best{/b} sex I've ever had!"
        dawn "[ss]Mmhhhh.... Me too!"
    else:
        scene 03_0858 with dissolve
        mc "[whi]Come here..."
        call CharCum ("e03/03_0858.webp", "e03/03_0866.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e03/03_0866.webp", "e03/03_0867.webp", mc, "....nnnnhhhhh...")
        scene 03_0868 with dissolve
        sar "That was the {b}best{/b} sex I've ever had!"
        dawn "[ss]Mmhhhh.... Me too!"
    if _in_replay:
        scene black with Fade(3, 0, 0)
        return
    scene 03_0869 with Fade(2, 2, 1)
    mc "[whi]...Zzzzz..."
return

label DawnReplay02:
    call Unlocker ("DawnReplay02")
    if not _in_replay:
        $ persistent.DawnRP02Dat = Plr.Has("Barry")
        $ Dawn.incSex()
    if persistent.DawnRP02Dat:
        scene 08_0223 with dissolve
        dawn "What did you say?"
        mc "{i}I'm her Barry{/i}... She said you'd unders-"
        scene 08_0224 with vpunch
        dawn "[ss]Mmmhhh.."
        scene 08_0225 with dissolve
        dawn "[ss]..Mmhh.."
        scene 08_0226 with dissolve
    else:
        scene 08_0226 with fade2
    dawn "[whi]Get your ass in here!"
    scene 08_0227 with dissolve
    mc "[whi]Yes Ma'am."
    scene 08_0228 with dissolve
    play sound "closedoor.mp3"
    scene 08_0229 with dissolve
    scene black with Fade(2, 1, 1)
    scene 08_0230 with dissolve
    pause 0.5
    scene 08_0231 with dis1
    dawn "[kiss]"
    scene 08_0232 with dis1
    pause 0.5
    scene 08_0233 with dis1
    dawn "[ss]..Nnnhh.."
    scene 08_0234 with dis1
    pause
    scene 08_0235 with dis1
    dawn "[ss]Mmhh.."
    scene 08_0236 with dissolve
    image r_dawn_10 = Movie(play="images/e08/08_0237.webm")
    show r_dawn_10
    mc "[whi]...Fuuck..."
    scene 08_0238 with dissolve
    scene 08_0239 with dis1
    pause
    scene 08_0240 with dissolve
    image r_dawn_11 = Movie(play="images/e08/08_0241.webm")
    show r_dawn_11
    dawn "[ss]...Mmmmhh...."
    scene 08_0242 with dissolve
    dawn "[ss]..Mmhh.."
    scene 08_0243 with dissolve
    pause
    scene 08_0244 with dissolve
    mc "[whi]Come here."
    scene 08_0245 with Fade(0.5, 1, 0.5)
    dawn "[ss]...Fuuck..."
    scene 08_0246 with dissolve
    dawn "[ss]..Ohhh..."
    scene 08_0247 with dissolve
    image r_dawn_12 = Movie(play="images/e08/08_0248.webm")
    show r_dawn_12
    dawn "[ss]...Mmmmhh...."
    scene 08_0249 with dissolve
    call Moan (dawn)
    scene 08_0250 with dissolve
    dawn "[ss]Mmhh... You look good eating my little ginger pussy..."
    scene 08_0251 with dissolve
    dawn "[ss]... You're so fuckin' good at it, too...."
    scene 08_0252 with dissolve
    call Moan (dawn, 7)
    scene 08_0253 with dissolve
    dawn "[ss]...Mmmmhh...."
    scene 08_0254 with dissolve
    dawn "[ss]...Ohhh..."
    scene 08_0255 with Fade(1, 1, 2)
    pause
    scene 08_0256 with dissolve
    image r_dawn_13 = Movie(play="images/e08/08_0257.webm", loop=False, keep_last_frame=True)
    show r_dawn_13
    pause 2.0
    dawn "[ss]...Mmmmhh....{w=1}{nw}"
    pause 0.5
    dawn "[ss]...Ohhh..."
    scene 08_0258 with dissolve
    image r_dawn_14 = Movie(play="images/e08/08_0259.webm")
    show r_dawn_14
    dawn "[ss]..Mmhh..."
    scene 08_0260 with dissolve
    dawn "[ss]..Watching that movie, all I could think about was this...."
    scene 08_0261 with dissolve
    image r_dawn_15 = Movie(play="images/e08/08_0262.webm")
    show r_dawn_15
    dawn "[ss]..Mmhh..."
    scene 08_0263 with dissolve
    dawn "[ss]... so stop making love to me, [persistent.McName], and {b}FUCK{/b} me...."
    mc "[whi]Yes, Ma'am..."
    scene 08_0264 with dissolve
    image r_dawn_16 = Movie(play="images/e08/08_0265.webm")
    show r_dawn_16
    dawn "[ss]..Mmhh...Fuck, yes...."
    scene 08_0266 with dissolve
    dawn "[ss].....Make my pussy beg for more...."
    scene 08_0267 with hpunch
    dawn "[ss]..OHHHHH..."
    scene 08_0268 with dissolve
    image r_dawn_17 = Movie(play="images/e08/08_0269.webm")
    show r_dawn_17
    call Moan (dawn, 7)
    scene 08_0270 with dissolve
    dawn "[ss]....OHHHH....YES, [persistent.McName!u]...."
    call Loop_Punch (5, "e08/08_0271.webp", "e08/08_0272.webp")
    scene 08_0273 with dissolve
    dawn "[ss]..Mmmhhhhh.."
    call Loop_Punch (4, "e08/08_0275.webp", "e08/08_0274.webp")
    scene 08_0276 with Fade(1, 1, 2)
    dawn "[ss]....OHHHHH...."
    scene 08_0277 with dissolve
    image r_dawn_18 = Movie(play="images/e08/08_0278.webm")
    show r_dawn_18
    dawn "[ss]... Your dick feels fuckin' amazing...."
    scene 08_0279 with dissolve
    image r_dawn_19 = Movie(play="images/e08/08_0280.webm")
    show r_dawn_19
    call Moan (dawn, 7)
    scene 08_0281 with dissolve
    dawn "[ss]...OHHHHHHHHHH..."
    scene 08_0282 with dissolve
    image r_dawn_20 = Movie(play="images/e08/08_0283.webm")
    show r_dawn_20
    call Moan (dawn, 7)
    scene 08_0284 with Fade(1, 1, 2)
    dawn "[ss]...Mhhh......Don't cum yet......Keep going.........."
    call Loop_Punch (6, "e08/08_0285.webp", "e08/08_0286.webp")
    scene 08_0287 with dissolve
    dawn "[ss]...Fuuck......It's so good...."
    scene 08_0288 with dissolve
    call Moan (dawn, 7)
    scene 08_0289 with Fade(1, 1, 2)
    dawn "[ss]...Holy shit......Yes, [persistent.McName].....Fuck me, Baby...."
    scene 08_0290 with dissolve
    image r_dawn_21 = Movie(play="images/e08/08_0291.webm")
    show r_dawn_21
    dawn "[ss]...OHHHHHHH..."
    scene 08_0292 with dissolve
    image r_dawn_22 = Movie(play="images/e08/08_0293.webm")
    show r_dawn_22
    call Moan (dawn, 7)
    scene 08_0294 with dissolve
    dawn "[ss]...MMMMHHHHHHH..."
    scene 08_0295 with dissolve
    dawn "[ss]......MMHHH......"
    scene 08_0296 with Fade(1, 1, 2)
    dawn "[ss]...OHHHHH......YES....."
    scene 08_0297 with dissolve
    image r_dawn_23 = Movie(play="images/e08/08_0298.webm")
    show r_dawn_23
    call Moan (dawn, 10)
    scene 08_0299 with dissolve
    dawn "....OH GOD, YES........YES, BABY.......{b}YES{/b}....."
    call Loop_Punch (6, "e08/08_0300.webp", "e08/08_0301.webp", 0.15)
    call CharCum ("e08/08_0300.webp", "e08/08_0302.webp", dawn, "....OHHHHHHHHHHHHHH!!....")
    call CharCum ("e08/08_0302.webp", "e08/08_0303.webp", dawn, "...OHHHHHHH...")
    scene 08_0304 with dissolve
    call Emotion (dawn, "Breathing heavily")
    dawn "[ss]...Holy shit, that was great!..."
    scene 08_0305 with dissolve
    image r_dawn_24 = Movie(play="images/e08/08_0306.webm")
    show r_dawn_24
    dawn "[ss]..Mmhhh..."
    scene 08_0307 with dissolve
    image r_dawn_25 = Movie(play="images/e08/08_0308.webm")
    show r_dawn_25
    pause
    if persistent.Anal:
        call CmOpts (["Cum inside Dawn", "Pull out", "Cum on her face", "Cum in her mouth", "Stick it in her butt"])
    else:
        call CmOpts (["Cum inside Dawn", "Pull out", "Cum on her face", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        $ Dawn.incCm()
        call CharCum ("e08/08_0307.webp", "e08/08_0322.webp", mc, "..NNNGGGGGHHHH!!...")
        scene 08_0350 with dissolve
        pause
        scene 08_0351 with dissolve
        dawn "Damn, that was so much fun!"
        scene 08_0325 with dissolve
        dawn "Wanna go again?? [lol]"
    elif Copt==1:
        call CharCum ("e08/08_0307.webp", "e08/08_0330.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e08/08_0330.webp", "e08/08_0331.webp", mc, "....Nnnnhhhhhh...")
        scene 08_0332 with dissolve
        pause
        scene 08_0329 with dissolve
        dawn "Damn, that was so much fun!"
        dawn "Wanna go again?? [lol]"
    elif Copt==2:
        call DawnReplay02_Face
    elif Copt==4:
        $ Dawn.Add("Anal")
        scene 08_0307 with dissolve
        scene 08_0309 with dis1
        scene 08_0310 with dis1
        scene 08_0311 with dissolve
        image r_dawn_26 = Movie(play="images/e08/08_0312.webm", loop=False, keep_last_frame=True)
        show r_dawn_26
        dawn "[ss]Mhhh..{w=2}{nw}"
        dawn "[ss]...What the-{w=1}{nw}"
        scene 08_0313 with hpunch
        dawn "[ss]{size=*1.5}FUUUUUCK!!!..."
        scene 08_0314 with dissolve
        image r_dawn_27 = Movie(play="images/e08/08_0315.webm")
        show r_dawn_27
        dawn "[ss]...Aaahh.....Fuuuuck....."
        scene 08_0317 with dissolve
        image r_dawn_28 = Movie(play="images/e08/08_0318.webm")
        show r_dawn_28
        pause
        scene 08_0319 with dissolve
        dawn "[ss]...Nnnnhhhhhhh...."
        scene 08_0316 with dissolve
        dawn "[ss]Damn you... It feels..."
        dawn "[ss]... good..."
        scene 08_0320 with dissolve
        image r_dawn_29 = Movie(play="images/e08/08_0321.webm")
        show r_dawn_29
        pause
        call CmOpts (["Cum inside Dawn", "Pull out", "Cum on her face", "Cum in her mouth"])
        $ Copt=_return
        if Copt==0:
            call CharCum ("e08/08_0320.webp", "e08/08_0322.webp", mc, "..NNNGGGGGHHHH!!...")
            scene 08_0323 with dissolve
            dawn "[ss]Did you just cum in my ass??"
            scene 08_0324 with dissolve
            mc "[whi]Yep... and it looks beautiful, heh."
            scene 08_0325 with dissolve
            dawn "[lol] You're an idiot."
        elif Copt==1:
            call CharCum ("e08/08_0320.webp", "e08/08_0326.webp", mc, "..NNNGGGGGHHHH!!...")
            call CharCum ("e08/08_0326.webp", "e08/08_0327.webp", mc, "....Nnnnhhhhhh...")
            scene 08_0328 with dissolve
            pause
            scene 08_0329 with dissolve
            dawn "Damn, that was so much fun!"
            dawn "Wanna go again?? [lol]"
        elif Copt==2:
            call DawnReplay02_Face
        else:
            call DawnReplay02_Mouth
    else:
        call DawnReplay02_Mouth
    if _in_replay:
        scene black with ReplayFade
        return
    scene 08_0352 with Fade(2, 1, 2)
    dawn "[whi]Wow, I haven't felt this relaxed in a long time!"
    dawn "[whi]I'm glad you decided to visit!"
    mc "[whi]Heh. Me too."
    if Dawn.Has("Anal"):
        scene 08_0353 with dissolve
        dawn "[whi]But promise me something...."
        dawn "[whi]Next time you want to put something in my ass, at least give me a heads-up first! Jesus!"
        mc "[lol]"
    if not Plr.Has("Barry"):
        scene 08_0381 with Fade(2, 1, 1)
        mc "[whi]...Zzzzz..."
        return
    scene 08_0354 with dissolve
    mc "[whi]Damn it... Okay, I gotta ask..."
    mc "[whi]Who the hell is Barry? Heh."
    scene 08_0355 with dissolve
    dawn "[lol]"
    scene 08_0356 with dissolve
    dawn "Are you {i}jealous{/i} of Barry?"
    mc "Hah! No, of course not!\nHe sounds like a helluva guy, that's all!"
    scene 08_0357 with dissolve
    dawn "Oh, my God! You {b}are{/b} jealous!"
    mc "[lol] I'm not!"
    dawn "Well... Maybe you {i}should{/i} be!\nBarry's the best![lol]"
    scene 08_0358 with dissolve
    dawn "Barry was my {i}first{/i} love!\nSarah's, too!"
    mc "So you were like a, err... thruple?"
    scene 08_0359 with dissolve
    dawn "Hah... No, not really.\nI'd let her borrow him sometimes."
    mc "Umm... Okay."
    scene 08_0360 with dissolve
    dawn "You wanna meet him??"
    mc "What?!\nUhh... Nah, I'm good."
    scene 08_0361 with dissolve
    dawn "Don't move! I'll be right back!"
    scene 08_0362 with dissolve
    mc "Wait... What?!"
    scene 08_0363 with Fade(0.5, 2, 0.5)
    dawn "[mc], I'd like you to meet Barry!"
    mc "{i}That's{/i} Barry??"
    scene 08_0364 with dissolve
    dawn "Yeah! [lol]"
    scene 08_0365 with dissolve
    dawn "When we were kids, Sarah and I loved having sleepovers."
    dawn "Most of the time, we'd stay at her house, but every once in a while, she'd have to stay at mine."
    scene 08_0366 with dissolve
    dawn "Back then, she was a {i}really{/i} shy and nervous kid.\nShe hated being out of her comfort zone."
    dawn "And staying the night in my crazy house - with two loud, obnoxious little brothers - was definitely out of her comfort zone!"
    dawn "But she'd stay anyway, because I wanted her to."
    scene 08_0367 with dissolve
    dawn "{i}This{/i} was my favorite thing..."
    scene 08_0368 with dissolve
    dawn "...so snuggly and soft.\nHe slept in my bed every night."
    scene 08_0369 with dissolve
    dawn "On one sleepover, Sarah was particularly uncomfortable... I can't remember why... One of my brothers had upset her, probably!"
    dawn "Anyway, I gave her Barry... Told her she could hold on to him for a while."
    scene 08_0370 with dissolve
    dawn "She was so happy!\nBarry kept her safe; she cuddled him the whole night."
    dawn "From that night on, whenever she felt a little uncomfortable or scared, Barry would come to the rescue!"
    scene 08_0371 with dissolve
    mc "Okay... but... I still don't get it..."
    mc "How does calling me {i}her Barry{/i} tell you that she's okay with {i}us{/i} having sex??"
    scene 08_0372 with dissolve
    dawn "[lol]"
    dawn "I guess we {i}do{/i} owe you an explanation!"
    scene 08_0373 with dissolve
    dawn "Okay, one thing you should know about Barry... He has a button inside his hand..."
    scene 08_0374 with dissolve
    dawn "He's broken now..."
    dawn "But when it was pressed, he would shake and vibrate like crazy."
    scene 08_0375 with dissolve
    dawn "When I was about twelve or thirteen, I was in bed, falling asleep, spooning him, and I must've accidentally triggered the button."
    dawn "He started doing his thing!\nHis little butt was pushed right up against my..."
    scene 08_0376 with dissolve
    dawn "... {i}little ginger pussy{/i}!"
    dawn "Holy shit! It was... {b}magical{/b}!!"
    dawn "That night, Barry gave me my first ever orgasm![lol]"
    scene 08_0377 with dissolve
    dawn "When I told Sarah what had happened, she didn't believe me and wanted to try it for herself..."
    dawn "He made {i}her{/i} orgasm, too!"
    scene 08_0378 with dissolve
    dawn "After we discovered his {i}talent{/i}, whenever she slept over, she'd ask if she could keep Barry in her bed."
    dawn "Not because she was still shy or uncomfortable. She'd already grown out of that!"
    scene 08_0379 with dissolve
    dawn "She wanted him for the same reason I still slept with him every night!"
    dawn "So, even though I loved Barry, I'd let her borrow him sometimes, too."
    scene 08_0380 with dissolve
    dawn "Because she's my best friend, and I wanted her to be happy, to feel safe, and to feel loved."
    mc "Okay, I think I get it... Heh."
    scene 08_0380_1 with dissolve
    mc "Damn, Barry... You da man![lol]"
    scene 08_0381 with Fade(2, 1, 1)
    mc "[whi]...Zzzzz..."
return

label DawnReplay02_Face:
    scene 08_0333 with dissolve
    mc "[whi]Turn around..."
    dawn "[ss]Oohh... You have something for me, Baby?"
    call Loop_Dissolve (6, False, False, "e08/08_0342.webp", "e08/08_0341.webp")
    call CharCum ("e08/08_0342.webp", "e08/08_0343.webp", mc, "..NNNGGGGGHHHH!!...")
    call CharCum ("e08/08_0343.webp", "e08/08_0344.webp", mc, "....Nnnnhhhhhh...")
    scene 08_0345 with dissolve
    scene 08_0346 with dis1
    scene 08_0347 with dis1
    dawn "[ss]Mmmmhhh.."
    scene 08_0348 with dissolve
    dawn "Well, damn! That was fun!"
    dawn "Wanna go again? [lol]"
return

label DawnReplay02_Mouth:
    scene 08_0333 with dissolve
    mc "[whi]Turn around..."
    dawn "[ss]Oohh... You have something for me, Baby?"
    call Loop_Dissolve (6, False, False, "e08/08_0334.webp", "e08/08_0335.webp")
    call CharCum ("e08/08_0334.webp", "e08/08_0336.webp", mc, "..NNNGGGGGHHHH!!...")
    call CharCum ("e08/08_0336.webp", "e08/08_0337.webp", mc, "....Nnnnhhhhhh...")
    call Loop_Dissolve (2, True, False, "e08/08_0338.webp", "e08/08_0339.webp")
    scene 08_0340 with dissolve
    dawn "[ss]Nnnnhhh.."
    scene 08_0349 with dissolve
    dawn "Well, damn! That was fun!"
    dawn "Wanna go again? [lol]"
return

label DawnReplay03:
    call Unlocker ("DawnReplay03")
    scene 11_0311 with fade1
    mc "Can I come in?"
    dawn "Yes, I've been waiting for you."
    if not _in_replay:
        $ persistent.DawnRP03Dat=Dawn.getSex()
        $ Dawn.incSex()
    scene 11_0312 with dissolve
    if persistent.DawnRP03Dat==0:
        dawn h "I hope you don't mind; I prefer to sleep naked."
        mc h "That's lucky - me too."
    else:
        dawn h "It's the ginger pussy, right? It's irresistible!"
    scene 11_0313 with fade1
    dawn "[ss]Mmh."
    scene 11_0314 with dissolve
    scene 11_0315 with Dissolve(2)
    dawn "[ss]..Mmmhhh.."
    scene 11_0316 with dissolve
    scene 11_0317 with Dissolve(2)
    scene 11_0318 with Dissolve(2)
    scene 11_0319 with Dissolve(2)
    dawn "[ss]..Mmhhh.."
    scene 11_0320 with dissolve
    image DawnR03_01 = Movie(play="images/e11/11_0321.webm")
    show DawnR03_01
    dawn "[ss]Mmh."
    scene 11_0322 with dissolve
    dawn "[ss]..Mmhhh.."
    scene 11_0320 with dissolve
    image DawnR03_02 = Movie(play="images/e11/11_0323.webm", loop=False, keep_last_frame=True)
    show DawnR03_02
    dawn "[ss]Mmh."
    scene 11_0322 with dissolve
    call Moan (dawn)
    scene 11_0324 with dissolve
    image DawnR03_03 = Movie(play="images/e11/11_0325.webm")
    show DawnR03_03
    dawn "[ss]..Mmmhhh.."
    scene 11_0326 with dissolve
    scene 11_0327 with Dissolve(2)
    scene 11_0328 with Dissolve(2)
    scene 11_0329 with Dissolve(2)
    scene 11_0330 with Dissolve(2)
    scene 11_0331 with Dissolve(2)
    scene 11_0332 with dissolve
    dawn "[ss]Nnh."
    scene 11_0333 with dis1
    scene 11_0334 with dis1
    scene 11_0335 with dis1
    dawn "[ss]..Mmmhhh.."
    scene 11_0336 with dissolve
    pause
    scene 11_0337 with dissolve
    image DawnR03_04 = Movie(play="images/e11/11_0338.webm")
    show DawnR03_04
    dawn "[ss]..Mmmmhhh.."
    scene 11_0339 with dissolve
    image DawnR03_05 = Movie(play="images/e11/11_0340.webm")
    show DawnR03_05
    dawn "[ss].Mmhh."
    scene 11_0341 with dissolve
    image DawnR03_06 = Movie(play="images/e11/11_0342.webm")
    show DawnR03_06
    pause
    scene 11_0343 with dissolve
    dawn "[ss]..Nnnhhh.."
    call Loop_Dissolve (4, True, False, "images/e11/11_0345.webp", "images/e11/11_0346.webp")
    pause
    scene 11_0344 with dissolve
    dawn "[ss]Mmhh."
    scene 11_0347 with dissolve
    image DawnR03_07 = Movie(play="images/e11/11_0348.webm")
    show DawnR03_07
    dawn "[ss]...Damn, that's good..."
    dawn "[ss]..Mmmmhhhh.."
    scene 11_0349 with dissolve
    dawn h "[whi]Mind if I scooch down a bit?"
    mc h "[whi]Not at all."
    scene 11_0350 with fade
    pause
    scene 11_0351 with dissolve
    image DawnR03_08 = Movie(play="images/e11/11_0352.webm", loop=False, keep_last_frame=True)
    show DawnR03_08
    pause 2.0
    dawn "[ss]..Nnnnhh.."
    scene 11_0353 with dissolve
    image DawnR03_09 = Movie(play="images/e11/11_0354.webm")
    show DawnR03_09
    dawn "[ss]Ohhh."
    scene 11_0355 with dissolve
    image DawnR03_10 = Movie(play="images/e11/11_0356.webm")
    show DawnR03_10
    pause
    scene 11_0357 with dissolve
    image DawnR03_11 = Movie(play="images/e11/11_0358.webm")
    show DawnR03_11
    dawn "[ss]...Ohhh..."
    scene 11_0359 with dissolve
    call Moan (dawn)
    scene 11_0360 with dissolve
    image DawnR03_12 = Movie(play="images/e11/11_0361.webm")
    show DawnR03_12
    dawn "[ss]....OHHHHH...."
    scene 11_0362 with dissolve
    image DawnR03_13 = Movie(play="images/e11/11_0363.webm")
    show DawnR03_13
    dawn "[ss]..Ohhhh.."
    scene 11_0364 with dissolve
    call Moan (dawn)
    scene 11_0365 with dissolve
    image DawnR03_14 = Movie(play="images/e11/11_0366.webm")
    show DawnR03_14
    call Moan (dawn)
    if persistent.Anal:
        scene 11_0367 with dissolve
        pause
        scene 11_0368 with dissolve
        dawn "[ss]....OHHHHH...."
        scene 11_0369 with dissolve
        image DawnR03_15 = Movie(play="images/e11/11_0370.webm")
        show DawnR03_15
        dawn "[ss]...Mmmmhhhhh...."
    scene 11_0371 with fade
    dawn "[ss].....Ohh, [persistent.McName]......Yes...."
    scene 11_0372 with dissolve
    image DawnR03_16 = Movie(play="images/e11/11_0373.webm")
    show DawnR03_16
    dawn "[ss]....Ohhhhhh...."
    scene 11_0374 with dissolve
    image DawnR03_17 = Movie(play="images/e11/11_0375.webm")
    show DawnR03_17
    call Moan (dawn, 7)
    scene 11_0376 with dissolve
    dawn "[ss]....Fuck....That's good.......Ohhhh....."
    scene 11_0377 with dissolve
    image DawnR03_18 = Movie(play="images/e11/11_0378.webm")
    show DawnR03_18
    dawn "[ss]....OHHHHH...."
    scene 11_0379 with dissolve
    call Moan (dawn, 7)
    scene 11_0380 with dissolve
    image DawnR03_19 = Movie(play="images/e11/11_0381.webm")
    show DawnR03_19
    dawn "[ss].....OHHH, HONEY.....YES...."
    scene 11_0382 with dissolve
    image DawnR03_20 = Movie(play="images/e11/11_0383.webm")
    show DawnR03_20
    call Moan (dawn, 7)
    if persistent.Anal:
        scene 11_0384 with dissolve
        dawn "[whi]Is that going where I think it's going?"
        mc h "[whi]It sure is."
        scene 11_0385 with dissolve
        image DawnR03_21 = Movie(play="images/e11/11_0386.webm", loop=False, keep_last_frame=True)
        show DawnR03_21
        pause 4.0
        dawn "[ss]..Aaaahhhh.."
        scene 11_0387 with dissolve
        image DawnR03_22 = Movie(play="images/e11/11_0388.webm")
        show DawnR03_22
        dawn "[ss].....Ahhhhh....Yes, Honey....Nice and slow....."
        scene 11_0389 with dissolve
        image DawnR03_23 = Movie(play="images/e11/11_0390.webm")
        show DawnR03_23
        dawn "[ss]..Aaahhhhh.."
        scene 11_0391 with dissolve
        image DawnR03_24 = Movie(play="images/e11/11_0392.webm")
        show DawnR03_24
        dawn "[ss].....Fuuuuck....."
        scene 11_0393 with fade
        dawn "[ss]..Mmmhhh.."
        scene 11_0394 with dissolve
        image DawnR03_25 = Movie(play="images/e11/11_0395.webm")
        show DawnR03_25
        dawn "[ss]..Mmmhhh.."
        scene 11_0396 with dissolve
        image DawnR03_26 = Movie(play="images/e11/11_0397.webm")
        show DawnR03_26
        dawn "[ss]..ohhhhhhh.."
        scene 11_0398 with fade1
    else:
        scene 11_0393 with fade
        dawn "[ss]..Mmmhhh.."
        scene 11_0398 with dissolve
    image DawnR03_27 = Movie(play="images/e11/11_0399.webm")
    show DawnR03_27
    dawn "[ss]..Mmmhhh.."
    scene 11_0400 with dissolve
    image DawnR03_28 = Movie(play="images/e11/11_0401.webm")
    show DawnR03_28
    call Moan (dawn, 8)
    scene 11_0402 with dissolve
    dawn "[ss]....Fuck, [persistent.McName].......Yes....."
    dawn "[ss]......You're gonna make me orgasm so hard.........OHHHHH....."
    scene 11_0403 with dissolve
    image DawnR03_29 = Movie(play="images/e11/11_0404.webm")
    show DawnR03_29
    call Moan (dawn, 8)
    dawn "[ss]..Ohhhh......Yes.......God, yes......"
    scene 11_0405 with dissolve
    image DawnR03_30 = Movie(play="images/e11/11_0406.webm")
    show DawnR03_30
    dawn "[ss]...Mmmmhhhh....Ohhh Honey, yes......YES....."
    call Moan (dawn, 8)
    scene 11_0407 with dissolve
    image DawnR03_31 = Movie(play="images/e11/11_0408.webm")
    show DawnR03_31
    dawn "[ss].....YES.....OHHHH....YES....."
    call Moan (dawn, 10)
    call CharCum ("e11/11_0407.webp", "e11/11_0409.webp", dawn, "....Ohhhhhhhhhh....")
    call CharCum ("e11/11_0409.webp", "e11/11_0410.webp", dawn, "...Mmmmmmhhhhh..")
    scene 11_0411 with dissolve
    image DawnR03_32 = Movie(play="images/e11/11_0412.webm")
    show DawnR03_32
    dawn "[ss]..Mmmhhh.."
    pause
    call CmOpts (["Cum inside Dawn", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Dawn.incCm()
        call CharCum ("e11/11_0411.webp", "e11/11_0413.webp", mc, "..Nnnnngghhhh...")
        call CharCum ("e11/11_0413.webp", "e11/11_0414.webp", mc, "....Nnnhhh...")
        scene 11_0415 with dissolve
        dawn "[ss]...Mhhh..."
        scene 11_0416 with dissolve
    else:
        call CharCum ("e11/11_0411.webp", "e11/11_0417.webp", mc, "..Nnnnngghhhh...")
        call CharCum ("e11/11_0417.webp", "e11/11_0418.webp", mc, "....Nnnhhh...")
        scene 11_0419 with dissolve
        dawn "[ss]...Mhhh..."
        scene 11_0420 with dissolve
    dawn "[whi]Wow."
    scene 11_0421 with fade1
    mc "[whi]..Zzzz.."
    scene black with ReplayFade
return

label DawnReplay04:
    call Unlocker ("DawnReplay04")
    $ Dawn.incSex()
    scene 19_0857 with fade1
    dawn "[ss]Mmhh."
    scene 19_0858 with dissolve
    pause 0.5
    scene 19_0859 with dis1
    scene 19_0860 with dis1
    scene 19_0861 with dis1
    scene 19_0862 with dis1
    scene 19_0863 with dis1
    scene 19_0864 with dis1
    pause 0.5
    scene 19_0865 with dissolve
    dawn "[ss]Nnnh."
    scene 19_0866 with dis1
    scene 19_0867 with dis1
    image DawnR04_02 = Movie(play="images/e19/19_0869.webm")
    image DawnR04_01 = Movie(play="images/e19/19_0868.webm", loop=False, keep_last_frame=True)
    show DawnR04_01
    pause 2.5
    show DawnR04_02
    dawn "[ss]Mmhhh."
    scene 19_0870 with dissolve
    image DawnR04_03 = Movie(play="images/e19/19_0871.webm")
    show DawnR04_03
    pause
    scene 19_0872 with dissolve
    image DawnR04_04 = Movie(play="images/e19/19_0873.webm")
    show DawnR04_04
    dawn "[ss]..Mmmhhh.."
    scene 19_0874 with dissolve
    image DawnR04_05 = Movie(play="images/e19/19_0875.webm")
    show DawnR04_05
    dawn "[ss]Mmmmhhh."
    scene 19_0876 with dissolve
    scene 19_0877 with dis1
    scene 19_0878 with dis1
    dawn "[whi]Hungry?"
    scene 19_0879 with dis1
    scene 19_0880 with dis1
    scene 19_0881 with dis1
    dawn "[ss]Ohhh."
    scene 19_0882 with dissolve
    image DawnR04_06 = Movie(play="images/e19/19_0883.webm")
    show DawnR04_06
    call Moan (dawn)
    scene 19_0884 with dissolve
    dawn "[ss]Ohhh."
    scene 19_0885 with dissolve
    call Moan (dawn)
    scene 19_0886 with dissolve
    pause
    scene 19_0887 with dissolve
    pause
    scene 19_0888 with dissolve
    dawn "[ss]Goddamn, you're a master at that!"
    scene 19_0889 with dissolve
    dawn "[whi]Want give your tongue a rest and swap it for your dick?"
    scene 19_0890 with dis1
    scene 19_0891 with dis1
    pause
    scene 19_0892 with dissolve
    image DawnR04_07 = Movie(play="images/e19/19_0893.webm", loop=False, keep_last_frame=True)
    show DawnR04_07
    pause 4.0
    dawn "[ss]Ohhh."
    scene 19_0894 with dissolve
    image DawnR04_08 = Movie(play="images/e19/19_0895.webm")
    show DawnR04_08
    pause
    scene 19_0896 with dissolve
    image DawnR04_09 = Movie(play="images/e19/19_0897.webm")
    show DawnR04_09
    pause
    scene 19_0898 with dissolve
    dawn "[ss]..Ohhh.."
    scene 19_0899 with dissolve
    image DawnR04_10 = Movie(play="images/e19/19_0900.webm")
    show DawnR04_10
    pause
    scene 19_0901 with dissolve
    image DawnR04_11 = Movie(play="images/e19/19_0902.webm")
    show DawnR04_11
    call Moan (dawn)
    scene 19_0903 with dissolve
    image DawnR04_12 = Movie(play="images/e19/19_0904.webm")
    show DawnR04_12
    pause
    scene 19_0905 with dissolve
    dawn "[ss]..Ohhh.."
    scene 19_0906 with dissolve
    image DawnR04_13 = Movie(play="images/e19/19_0907.webm")
    show DawnR04_13
    pause
    scene 19_0908 with dissolve
    image DawnR04_14 = Movie(play="images/e19/19_0909.webm")
    show DawnR04_14
    pause
    scene 19_0910 with dis1
    scene 19_0911 with dis1
    scene 19_0912 with dis1
    scene 19_0913 with dis1
    image DawnR04_15 = Movie(play="images/e19/19_0914.webm")
    show DawnR04_15
    dawn "[ss]OHHHH, [persistent.McName!u].......YES...."
    scene 19_0915 with dissolve
    image DawnR04_16 = Movie(play="images/e19/19_0916.webm")
    show DawnR04_16
    call Moan (dawn)
    scene 19_0917 with dissolve
    dawn "[ss]...OHHHH..."
    scene 19_0918 with dissolve
    image DawnR04_17 = Movie(play="images/e19/19_0919.webm")
    show DawnR04_17
    call Moan (dawn)
    scene 19_0920 with dis1
    scene 19_0921 with dis1
    scene 19_0922 with dis1
    image DawnR04_18 = Movie(play="images/e19/19_0923.webm")
    show DawnR04_18
    call Moan (dawn)
    scene 19_0924 with dissolve
    image DawnR04_19 = Movie(play="images/e19/19_0925.webm")
    show DawnR04_19
    dawn "[ss]..OHHHHHH.."
    dawn "[ss]....Fuck.........Yes....."
    scene 19_0926 with dissolve
    dawn "[ss]...OHHHH, [persistent.McName!u]...."
    scene 19_0927 with dissolve
    image DawnR04_20 = Movie(play="images/e19/19_0928.webm")
    show DawnR04_20
    call Moan (dawn)
    scene 19_0929 with dissolve
    image DawnR04_21 = Movie(play="images/e19/19_0930.webm")
    show DawnR04_21
    call Moan (dawn)
    call CharCum ("e19/19_0929.webp", "e19/19_0931.webp", dawn, "....Ohhhhhhh....")
    call CharCum ("e19/19_0931.webp", "e19/19_0932.webp", dawn, "...Ohhhhh...")
    scene 19_0933 with dissolve
    image DawnR04_22 = Movie(play="images/e19/19_0934.webm")
    show DawnR04_22
    dawn "[ss]..Mmmhhhh.."
    pause 
    call CmOpts (["Cum inside Dawn", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Dawn.incCm()
        call CharCum ("e19/19_0933.webp", "e19/19_0935.webp", mc, "..Nnnnngghhhh...")
        call CharCum ("e19/19_0935.webp", "e19/19_0936.webp", mc, "..Nnnhhhh..")
        scene 19_0937 with dissolve
        pause
        scene 19_0938 with dissolve
        pause
    elif Copt==1:
        call CharCum ("e19/19_0933.webp", "e19/19_0939.webp", mc, "..Nnnnngghhhh...")
        call CharCum ("e19/19_0939.webp", "e19/19_0940.webp", mc, "..Nnnhhhh..")
        scene 19_0941 with dissolve
        pause
        scene 19_0942 with dissolve
        dawn "[whi]You know the only bathroom in this dump is downstairs, right?[lol]"
        call laugh (mc, "My bad.")
    if _in_replay:
        scene black with ReplayFade
    else:
        scene 19_0943 with fade1
        mc "[whi]..Zzzz.."
        scene black with Fade(3, 1, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
