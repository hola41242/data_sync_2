default persistent.lakeshore_active = False
default lakeshore_id = "LKS"
default lakeshore_ch = 1
default lakeshore_open = False
default lakeshore_info = [""]

label UpdateLakeshoreData(id=0):
    if len(lakeshore_info)<=1:
        $ lakeshore_info.insert(1, "Need to come up with a plan to get Sue's daughter Melissa to safety. Hopefully her professor can help.")
    if len(lakeshore_info)<=2:
        $ lakeshore_info.insert(2, "Need to check in on Blaze. Better not forget to pick Sarah up on the way!")
    if len(lakeshore_info)<=3:
        $ lakeshore_info.insert(3, "Promised Ruth a meeting. Need to find out what happened with Anton's guys.")
return

default persistent.RuthLocked = True
default Ruth_name = "Ruth"
define ruth = Character("[Ruth_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="ruth")
default Ruth = Stats()
default persistent.RuthPet = True
image side ruth cell = side+"ruth_c.png"
image side ruth h = side+"ruth_hp.png"
image side ruth s = side+"ruth_sd.png"
image side ruth a = side+"ruth_an.png"
image side ruth sh = side+"ruth_sh.png"
image side ruth su = side+"ruth_su.png"

default persistent.MelissaLocked = True
default Melissa_name = "Melissa"
define meli = Character("[Melissa_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="melissa")
default Melissa = Stats()
image side melissa cell = side+"melissa_c.png"
image side melissa h = side+"melissa_hp.png"
image side melissa s = side+"melissa_sd.png"
image side melissa a = side+"melissa_an.png"
image side melissa sh = side+"melissa_sh.png"
image side melissa su = side+"melissa_su.png"

default persistent.DawnLocked = True
default Dawn_name = "Dawn"
define dawn = Character("[Dawn_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="dawn")
image side dawn cell = side+"dawn_c.png"
image side dawn h = side+"dawn_hp.png"
image side dawn s = side+"dawn_sd.png"
image side dawn a = side+"dawn_an.png"
image side dawn sh = side+"dawn_sh.png"
image side dawn su = side+"dawn_su.png"
default Dawn = Stats()
default persistent.DawnRP02Dat = False
default persistent.DawnRP03Dat = 0

default persistent.BlazeLocked = True
default Blaze_name = "Blaze"
define blz = Character("[Blaze_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="blaze")
image side blaze cell = side+"blaze_c.png"
image side blaze h = side+"blaze_hp.png"
image side blaze s = side+"blaze_sd.png"
image side blaze a = side+"blaze_an.png"
image side blaze sh = side+"blaze_sh.png"
image side blaze su = side+"blaze_su.png"
default Blaze = Stats()

define secgrd = Character("Security Guard", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define har = Character("Harry", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="harry")
default Craig_name = "Craig"
define cra = Character("[Craig_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="craig")
default Anton_name = ""
define ant = Character("[Anton_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="anton")
default Zack_name = ""
define zac = Character("[Zack_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="zack")
default Jt_name = ""
define jt = Character("[Jt_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="jt")
screen Lakeshore_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "lks", "blaze", Blaze_Replay, persistent.BlazeLocked, "Ex-military friend of [persistent.McName].")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "lks", "dawn", Dawn_Replay, persistent.DawnLocked, "Sarah's friend. One of Melissa's college lectureres.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "lks", "melissa", Melissa_Replay, persistent.MelissaLocked, "Sue's daughter.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "lks", "ruth", Ruth_Replay, persistent.RuthLocked, "Dean at the college Melissa attends.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
