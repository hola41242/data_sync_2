label Lakeshore_Start2:
    scene 16_0192 with Fade(2,1,4)
    pause 0.5
    scene 16_0193 with dis1
    scene 16_0194 with dis1
    scene 16_0195 with dis1
    pause 0.5
    scene 16_0196 with dissolve
    mc "We're here."
    sar "Jesus! {i}This{/i} is the place?!\nLooks creepy as Hell!"
    scene 16_0197 with dissolve
    pause 0.5
    scene 16_0198 with dis1
    scene 16_0199 with dis1
    scene 16_0200 with dissolve
    dawn "Are they here at last?"
    blz "Yeah."
    scene 16_0201 with dissolve
    dawn "Sarah!"
    scene 16_0202 with dis1
    scene 16_0203 with dis1
    scene 16_0204 with dis1
    scene 16_0205 with dissolve
    sar "I'm glad you're okay!\nI've been so worried!"
    dawn "I knew you would be."
    scene 16_0206 with dissolve
    mc "We should get inside."
    scene 16_0207 with dissolve
    blz "Boss."
    mc "Hey, Blaze."
    scene 16_0208 with dissolve
    mc "Everything good here?"
    blz "Peachy."
    scene 16_0209 with dissolve
    mc "Melissa?"
    blz "Good as gold."
    scene 16_0210 with dis1
    pause 0.5
    scene 16_0211 with dissolve
    dawn "I'll show you my room.\nWe can talk there."
    sar "Okay."
    scene 16_0212 with dissolve
    if Plr.Has("ATK"):
        mc "There could be another spanner in the works..."
        blz "Why?"
        mc "One of Anton's guys... Think I recognized him."
        scene 16_0213 with dissolve
        mc "Do you remember that useless idiot who tried out for the team a few years back?"
        mc "I don't recall his damn name... He almost fell off the mountain trippin' over his own fuckin' boots.."
        scene 16_0214 with dissolve
        blz "Oh, shit... Yeah!\nHe was a liability! Longest week of my life!"
        blz "Still don't know how the hell he even made it to the try-outs!"
        scene 16_0215 with dissolve
        blz "Wasn't his name J... something?"
        if CraigD:
            blz "JP?... JB?..."
            scene 16_0216 with dissolve
            blz "{b}JT!{/b}"
        else:
            mc "J... T?"
            scene 16_0216 with dissolve
            blz "Yes! JT! That was it."
        scene 16_0217 with dissolve
        blz "{b}He{/b} works for Anton now??"
        blz "Damn.\nGuess they'll take anyone."
        scene 16_0218 with dissolve
        if CraigD:
            mc "I'm sure it was him.\nLooks older, but yeah."
        else:
            mc "Yeah, I thought it {i}could{/i} be him."
            mc "Looks older, but wasn't sure... until now. Anton called him JT."
        mc "I'm pretty sure he recognized me, too.\nThe way he looked at me..."
        scene 16_0219 with dissolve
        blz "Does it matter?\nThey already know you served, don't they?"
        blz "They have access to your record. JT can't tell them anything they wouldn't already know."
        scene 16_0220 with dissolve
        mc "Yeah... Maybe."
        mc "Stay clear of the city.\nIf he {i}did{/i} recognize me, then he's sure as shit gonna remember {b}you{/b}."
        mc "After everything that's happened with Melissa, the last thing we need right now is for him to eyeball you in the area."
        blz "Copy."
        scene 16_0223 with dissolve
    else:
        mc "What about our train station CCTV problem?"
        blz "Dealt with."
        scene 16_0219 with dissolve
        blz "Thankfully, they're still using old tech.\nNo off-site backup system. Records directly to DVD."
        blz "Found the disc; there was some grainy footage, good enough to see I wasn't Melissa, though."
        blz "Destroyed it."
        scene 16_0220 with dissolve
        mc "{i}It{/i}? As in the disc, right?"
        scene 16_0221 with dissolve
        blz "C'mon. You know me better than that, Boss."
        blz "I did them a favor. It needed a serious upgrade.\nNow their insurance can pay for it."
        scene 16_0222 with dissolve
        blz "Don't worry. I made it look like an electrical fault."
        scene 16_0223 with dissolve
        mc "Right... Why use a hammer when you have a wrecking ball?"
    mc "Where's Melissa?"
    blz "In her room."
    scene 16_0224 with dissolve
    blz "Bring me snacks?"
    mc "In the truck."
    scene 16_0225 with dissolve
    blz "[whi]Yes!"
    call Lakeshore_02_VisitMelissa
    call Lakeshore_02_VisitDawn
    scene 16_0269 with fade1
    mc "Save me some?"
    blz "Oops, was I supposed to?"
    call laugh (mc)
    scene 16_0270 with dissolve
    blz "Wanna watch a movie?"
    mc "Sure."
    scene 16_0271 with Fade(3, 4, 3)
    pause
    scene 16_0272 with dissolve
    meli "[lol]"
    scene 16_0273 with dissolve
    blz "That's complete bullshit!"
    scene 16_0274 with dissolve
    blz "Melissa, don't listen to him!\nHe's lying!"
    mc "Sergeant, are you denying the event took place?"
    scene 16_0275 with dissolve
    blz "Yes!"
    blz "Okay, no..."
    scene 16_0276 with dissolve
    blz "But he's exaggerating!"
    blz "There were {b}two{/b} guys, not five.\nAnd one of 'em was a scrawny, little thing!"
    blz "Didn't even break a sweat knocking his ass out!"
    scene 16_0277 with dissolve
    blz "And I knew I had the meanest son-of-a-bitch I'd ever met, in my corner ready to back me up."
    blz "Someone I've always been able to count on, no matter how tough the odds."
    scene 16_0278 with dissolve
    mc "You know I only stayed because you were my ride home that night, right?"
    blz "[lol]"
    scene 16_0279 with dissolve
    meli "This has been fun, listening to some of your stories!"
    meli "All this laughing has worn me out!\nSo, if you don't mind, I'm going to head up to bed."
    scene 16_0280 with dissolve
    meli "Safe journey home, [mc]."
    mc "Thanks.\nGoodnight, Melissa."
    scene 16_0281 with dissolve
    meli "See you in the morning, Blaze."
    blz "Night."
    scene 16_0282 with dissolve
    mc "If you wanna hit the sack too, go ahead.\nNo need to keep me company."
    blz "Nah, I'm good."
    scene 16_0283 with dissolve
    meli "Ohh... [mc], there was something I wanted to say before you left..."
    meli "Could you come up real quick?"
    mc "Uhh, yeah... okay."
    scene 16_0284 with fade
    pause 0.5
    scene 16_0285 with dissolve
    sar "Hey. I'm ready to leave when you are."
    mc "Okay, great.\nI just need a few minutes."
    scene 16_0286 with dis1
    scene 16_0287 with dissolve
    mc "What's up? Everything okay?"
    meli "...Yeah."
    scene 16_0288 with dissolve
    meli "I just, uhh..."
    if EzModeActive:
        call EzModeAsk ("Melissa")
        if _return:
            $ Melissa.Add("EZ")
    meli "I wanted to apologize again for making you uncomfortable earlier... when I embarrassed myself."
    mc "When you embarrassed yourself?\nSorry, I must've missed it; I don't recall..."
    scene 16_0289 with dissolve
    meli "I kissed you."
    scene 16_0290 with dissolve
    mc "Why would you feel embarrassed about {i}that{/i}?"
    mc "You were happy in the moment and expressed yourself. So what?"
    meli "I wasn't sure... I just wanted to clear the air..."
    scene 16_0291 with dissolve
    mc "Nah, forget about it! No big deal."
    meli "Okay, thanks."
    scene 16_0292 with dissolve
    meli "It wasn't how I imagined my first kiss would be."
    scene 16_0293 with dissolve
    mc "Huh?"
    mc "Melissa, that {i}wasn't{/i} your first kiss."
    meli "It really was."
    meli "You're the first guy I've kissed on the lips."
    scene 16_0294 with dissolve
    mc "Yeah, I get that... but still, it {i}wasn't{/i} your first kiss!"
    mc "You gave me a little peck, that's all! It doesn't count as a first kiss.\nDon't worry about it."
    scene 16_0295 with dissolve
    meli "[whi]Ohh."
    meli "In that case, I apologize for embarrassing myself {b}again{/b}!"
    meli "The amount of books I've read, movies I've watched... You'd think I'd know my shit, huh?"
    meli "I thought a kiss on the lips counted as a real kiss. Sorry."
    scene 16_0296 with dissolve
    mc "Okay, first of all - stop apologizing!"
    mc "It's not your fault you've had the life you have."
    scene 16_0297 with dissolve
    mc "Your first kiss isn't quick or meaningless - even on the lips."
    mc "It'll be full of passion and desire."
    mc "Believe me, when it happens - you'll know."
    scene 16_0298 with dissolve
    meli "Sounds nice."
    mc "It is!"
    meli "But what if it {i}never{/i} happens?"
    scene 16_0299 with dissolve
    mc "Trust me, it will."
    mc "Once you start living that new life you're dreaming about - you're gonna have {i}so{/i} much fun."
    scene 16_0300 with dissolve
    meli "That's easy for you to say."
    meli "I have no idea what I'm supposed to do when it comes to... you know, things like that."
    mc "You'll figure it out, stop worrying!"
    scene 16_0301 with dissolve
    meli "But all the girls my age will already have experience.\nHow can I compete with that?"
    meli "No guy will choose {b}me{/b} over {i}them{/i}."
    scene 16_0302 with dissolve
    mc "Okay, listen to me - If someone rejects you because of inexperience, that's not someone you should be with in the first place."
    mc "There are plenty of guys out there who are gonna like you for who you are, and they won't give a damn about your experience."
    meli "I understand what you're saying, I do, and I appreciate it..."
    scene 16_0303 with dissolve
    mc "But?"
    meli "I don't know..."
    meli "I just... I wish I knew what I was doing!\nI'd feel more confident in myself!"
    scene 16_0304 with dissolve
    mc "Honestly, you're gonna be fine. Don't sweat it!"
    meli "But, I do... sweat it!"
    scene 16_0305 with dissolve
    meli "Can you teach me?"
    scene 16_0306 with dissolve
    mc "Teach you?? To do what??"
    scene 16_0307 with dissolve
    meli "[mc], I've already screwed up my first kiss once; I'd rather not do it again."
    meli "Can you teach me to kiss someone - as you described?"
    scene 16_0308 with dissolve
    mc "Melissa, this stuff... It's not something to be {i}taught{/i}."
    mc "You learn by {i}doing{/i}.\nIt's nothing more than experience."
    mc "Stop worrying so much about it; when the time comes, you'll be fine!"
    meli "So... Practice? That's it??"
    mc "Yeah."
    scene 16_0309 with dissolve
    meli "But how am I supposed to do that if I don't have anyone to..."
    scene 16_0310 with dissolve
    meli "... Can {i}you{/i} help me practice?"
    scene 16_0311 with dissolve
    mc "What? No, that's not what I meant!"
    mc "You find someone you like first, {i}then{/i} you practice!"
    meli "I like you!"
    mc "No, I mean--"
    meli "[mc], please!\nI'd really like your help!"
    $ tCh=Melissa.Has("EZ")
    if not EzModeActive:
        menu:
            "Don't help Melissa [wk_c]":
                $ tCh=False
            "[wk_y]Help Melissa":
                $ tCh=True
    if tCh:
        meli "[mc]..."
        scene 16_0314 with dis1
        scene 16_0315 with dis1
        scene 16_0316 with dis1
        scene 16_0317 with dissolve
        meli "Would you do me the honor of being my {i}real{/i} first kiss?"
        scene 16_0318 with dis1
        scene 16_0319 with dis1
        scene 16_0320 with dissolve
        pause 0.5
        scene 16_0321 with dis1
        mc "[whi][kiss]"
        scene 16_0322 with dis1
        pause 0.5
        scene 16_0323 with dis1
        scene 16_0324 with dis1
        meli "[ss]Mmmmhhh."
        scene 16_0325 with dissolve
        meli "[ss]..Mmhhh.."
        scene 16_0326 with dissolve
        pause
        scene 16_0327 with dissolve
        meli "[whi]Wow."
        meli "Okay, yeah... You were right."
        scene 16_0328 with dissolve
        meli "{b}THAT{/b} was definitely my first kiss!\nAnd it was amazing!"
        mc "Good. That's how it {i}should{/i} be."
        scene 16_0329 with dissolve
        mc "I'd better get outta here. Sarah's waiting to leave."
        meli "Yeah."
        scene 16_0330 with dissolve
        mc "See you soon, Melissa."
        meli "Bye."
        scene 16_0331 with dis1
        pause 0.5
    else:
        call CloseCharacterPath (Melissa, "Melissa")
        mc "It doesn't work like that, trust me."
        mc "One day you'll meet someone special, and you'll understand."
        scene 16_0312 with dissolve
        meli "Yeah... okay."
        meli "Sorry I asked. I'm just being impatient.\nI know you're only trying to help."
        scene 16_0313 with dissolve
        mc "Your time will come; you'll see!"
        meli "I hope so!\nBye, [mc]."
    scene 16_0332 with fade1
    sar "Remember to call me as soon as you're back home, Dawn!"
    dawn "I will, don't worry!\nBye, Sarah."
    sar "Bye, guys."
    $ lakeshore_open=False
    $ lakeshore_ch+=1
    call CheckShOpen
    jump Springhaven_05_ReturnFromLakeshore
return

label Lakeshore_02_VisitMelissa:
    scene black with Fade(1,0,0)
    play sound "knock.mp3"
    scene 16_0226 with Fade(0,1,1)
    pause 0.5
    meli "[whi]Come in."
    scene 16_0227 with dis1
    scene 16_0228 with dissolve
    mc "Hey, Melissa. How you doing?"
    meli "Good, thanks.\nAs far as prisons go, this isn't the worst!"
    scene 16_0230 with dissolve
    mc "I know it may feel like it, but you're {i}not{/i} a prisoner here."
    meli "Oh, really? I'm not?"
    scene 16_0229 with dissolve
    meli "So I'm free to go?"
    meli "I can get up, walk out the door, and no one will stop me?"
    scene 16_0230 with dissolve
    mc "I'd rather you didn't, but... Yes."
    mc "We won't keep you here against your will, so if you wanna leave - leave."
    scene 16_0231 with dissolve
    mc "I'll tell Blaze we can all pack up and go home."
    scene 16_0232 with dissolve
    meli "[mc]... Wait!"
    scene 16_0233 with dissolve
    meli "I'm Sorry, I was being facetious; I didn't mean it."
    meli "I know you're trying to help me."
    scene 16_0234 with dissolve
    meli "It's frustrating being stuck here, dreaming of a new life.\nI want to start it already!"
    meli "Nobody's telling me anything, and I feel forgotten."
    meli "I just want it to be over."
    scene 16_0235 with dissolve
    mc "It's tough being here."
    scene 16_0236 with dissolve
    mc "But no one's forgotten about you."
    mc "This is a dangerous situation, and things need to be done right. That takes time."
    mc "Getting you out of Lakeshore - away from your father - is the easy part."
    mc "Making sure you're safe afterward? {b}That's{/b} what I'm still working on."
    scene 16_0237 with dissolve
    meli "But... why?"
    meli "Once you've delivered me to my mother, my safety is {i}her{/i} responsibility, not yours."
    mc "Yeah... We should talk about that."
    scene 16_0238 with fade1
    mc "Your mom plans to smuggle you both out of the country and start over somewhere else."
    meli "That won't stop my father. He'll still find us."
    mc "Maybe.\nYou'd have to keep moving, always looking over your shoulder."
    scene 16_0239 with dissolve
    meli "That sounds... awful.\nNothing like the life I've been dreaming about."
    meli "Living like rats?... in a foreign country?... with my {b}mother{/b}??"
    meli "{i}Great!{/i}"
    scene 16_0240 with dissolve
    mc "Don't worry. It's not gonna happen."
    meli "Why?"
    mc "You asked me not to take you back to her."
    scene 16_0241 with dissolve
    mc "I'm agreeing to your request."
    meli "Are you serious??"
    mc "Yeah."
    scene 16_0242 with dissolve
    meli "Holy shit!"
    scene 16_0243 with dis1
    scene 16_0244 with dis1
    meli "Thank you. Thank you. Thank you!"
    scene 16_0245 with dissolve
    mc "You're {i}not{/i} a prisoner here, you're one of the {b}team{/b}."
    mc "Try not to forget that."
    scene 16_0246 with dissolve
    meli "I'm never going to forget {b}this{/b}."
    meli "I'm going to name my first-born after you!"
    call laugh (mc, "Slow down.")
    mc "You'll have plenty of time to ponder those kinda decisions once this is all over!"
    scene 16_0247 with dissolve
    meli "That's it though, isn't it?"
    meli "For the first time in my life I {b}can{/b} plan for the future!"
    meli "I've never been able to do that before!"
    scene 16_0248 with dissolve
    meli "I've {i}dreamed{/i} about it, yeah, but that's all they were - dreams."
    meli "I didn't think for a second they'd ever be real."
    scene 16_0249 with dissolve
    meli "Damn! My mind's racing with the possibilities right now!"
    scene 16_0250 with dissolve
    meli "[kiss]"
    scene 16_0251 with dissolve
    scene 16_0252 with hpunch
    meli "Oh my god! Sorry!"
    meli "I got excited... I... I..."
    scene 16_0253 with dissolve
    mc "Relax, it's fine."
    mc "We still have a long way to go before you can start living some of those dreams of yours."
    mc "But it's those dreams that get you through {i}this{/i} part.\nSo you hold on to them."
    scene 16_0254 with dissolve
    meli "I've no clue how you ended up working for my mother, but I'm so glad you did."
    meli "Thanks, [mc]. For everything you're doing for me."
    meli "You're all risking so much. I can never repay you."
    mc "Hmmm, I don't know about that..."
    scene 16_0255 with dissolve
    mc "I'm starting to warm to the idea of your first-born being named after me!"
    scene 16_0256 with dissolve
    meli "[lol]"
return

label Lakeshore_02_VisitDawn:
    scene 16_0257 with dissolve
    play sound "knock.mp3"
    scene 16_0258 with dis1
    pause 1.0
    dawn "[whi]Come in."
    scene 16_0259 with dissolve
    mc "Hey.\nEverything good with you guys?"
    dawn "Yes. Thanks for bringing her, [mc]."
    scene 16_0260 with dissolve
    mc "No problem."
    dawn "I don't suppose you thought to bring more bedding with you?"
    scene 16_0261 with dissolve
    mc "You haven't told her?"
    sar "I didn't get the chance yet."
    dawn "Tell me what?"
    scene 16_0262 with dissolve
    sar "I'm sorry, Dawn, but I can't stay."
    scene 16_0263 with dissolve
    sar "I tried my best to get the time off work, but they refused."
    sar "They've already allowed me more than they should, so I couldn't argue."
    scene 16_0264 with dissolve
    dawn "That sucks."
    dawn "Jesus, Sarah.\nI don't deserve you, you know that?"
    scene 16_0265 with dissolve
    dawn "Coming all this way and back again in a single day, just because you were worried for me."
    dawn "I honestly don't know what I'd do without you."
    scene 16_0266 with dissolve
    sar "We can't stay the night, but [mc] said we don't have to leave until I'm ready."
    sar "We can still hang out for a few hours, and you can catch me up with everything that's been going on."
    scene 16_0267 with dissolve
    mc "And that's my cue to leave."
    scene 16_0268 with dissolve
    mc "I'll let you ladies gossip in private."
    dawn "You sure you don't wanna join us?\nYou're more than welcome! You might like it!"
    mc "Nah, I'm good."
    sar "[lol]"
return

label Lakeshore_Start3:
    scene 19_0346 with Fade(0, 2, 3)
    scene 19_0347 with dis1
    scene 19_0348 with dis1
    scene 19_0349 with dis1
    pause 0.5
    scene 19_0350 with dis1
    pause 0.5
    scene 19_0351 with dis1
    mc "You know you don't {i}need{/i} to stand guard out here, right?"
    scene 19_0352 with dissolve
    blz "I only do it when you're arriving.\nWant to make it seem like I'm earning my pay."
    call laugh (mc, "You want me to pay you for your time, Sargeant?")
    scene 19_0353 with dissolve
    blz "Yes, sir, I do."
    mc "Damn.\nI hope you're willing to offer me a discount. I could never afford the going rate for a soldier of your caliber!"
    if not Blaze.hasScore(2):
        call CloseCharacterPath (Blaze)
    scene 19_0354 with dissolve
    blz "Not after your money, sir!\nI have enough of my own."
    scene 19_0355 with dissolve
    if Blaze.isActive():
        blz "But the way you've been behaving around me recently... There is {i}something{/i} you have that I'd love to occasionally make use of."
        mc "My truck?"
        blz "[lol]"
        scene 19_0356 with dissolve
        blz "Sure. Let's call it that."
        blz "And I have a nice little garage where you can park it."
    else:
        blz "Just your charming personality and conversation skills!"
        blz "These women are driving me up the wall with all their girly talk."
        blz "Melissa's been badgering us for dating tips! Dawn was happy to oblige."
        scene 19_0356 with dissolve
        blz "You're my last hope, boss!\nGive me {b}real{/b} conversation, or I'm likely to kill them myself!"
    scene 19_0357 with dissolve
    scene 19_0358 with dis1
    scene 19_0359 with dissolve
    blz "Okay, to business - I have another safehouse set up in case we need to relocate."
    mc "That shouldn't be necessary.\nThe Dean doesn't know where we are."
    scene 19_0360 with dissolve
    mc "She {i}does{/i} know that Sue's behind all this, though."
    blz "How do you know she hasn't already spilled to them?"
    mc "Because Sue's still breathing.\nI called to warn her on the way up here."
    scene 19_0361 with dissolve
    blz "Shit. I thought the Harry story would've bought us more time.\nWonder how they figured it out so fast?"
    mc "Maybe they haven't.\nThey might think Dawn was helping them both."
    blz "Yeah, possibly."
    scene 19_0362 with dissolve
    mc "She in her room? I need to talk to her."
    blz "Yeah."
    scene 19_0361 with dissolve
    mc "Have you told her?"
    blz "No. Figured it might be better coming from you."
    scene 19_0363 with dissolve
    call EmotionSml (mc, "Sigh", "Great.")
    scene black with Fade(1, 1, 0)
    play sound "knock.mp3"
    scene 19_0364 with Fade(0,0,1)
    pause 0.5
    dawn "Yes?"
    scene 19_0365 with dissolve
    mc "Hey guys."
    dawn "Hey, [mc]!\nBlaze told us you were visiting."
    meli "Hi, [mc]."
    scene 19_0366 with dissolve
    mc "Everything okay?\nAny problems or issues I should know about?"
    scene 19_0367 with dissolve
    dawn "Well... Since you asked..."
    dawn "We could do with some more clothes.\nWe're down to our PJs!"
    scene 19_0368 with dissolve
    mc "Uh, okay."
    mc "You know you can talk to Blaze about that stuff, right?\nShe'd get you more clothes."
    scene 19_0369 with dissolve
    dawn "Yeah, she still scares the crap out of us."
    dawn "I don't want to risk upsetting her by saying the wrong thing!"
    scene 19_0370 with dissolve
    call laugh (mc, "She's not THAT scary!")
    mc "But okay, I'll talk to her."
    mc "Anything else?"
    dawn "No."
    if Melissa.isActive():
        scene 19_0371 with dissolve
        dawn "Unless you have any fancy dating tips for our horny, little Miss Sunshine here. I've run out!"
        scene 19_0372 with dissolve
        meli "DAWN!"
        dawn "[lol]"
        scene 19_0373 with dissolve
        meli "She knows it winds me up when she calls me little Miss Sunshine!"
        call laugh (mc)
    scene 19_0374 with dissolve
    mc "I hate to disturb you two, but Melissa, would you mind if I had a quick word with Dawn in private?"
    meli "Yeah, sure."
    scene 19_0375 with dissolve
    mc "Thanks. It shouldn't take too long."
    meli "Okay."
    scene 19_0376 with dissolve
    dawn "What's wrong? Is Sarah okay??"
    scene 19_0377 with dissolve
    mc "Yeah, don't worry, she's fine."
    mc "She wanted to come, but had to stay behind for work."
    scene 19_0378 with dissolve
    mc "Ruth called me yesterday.\nMelissa's father sent some guys to the college looking for you."
    dawn "For {b}me{/b}?? Oh, god!"
    dawn "How do they know I helped??"
    scene 19_0379 with dissolve
    mc "I don't think they do."
    mc "But... They were at your apartment looking for you, too."
    mc "This pretty much confirms what we suspected about your stalker.\nThat's how they know where you live."
    scene 19_0380 with dissolve
    dawn "Fuck! So it wasn't just some random weirdo?"
    dawn "Her father sent someone to watch me... Jesus. That's so scary."
    dawn "How the hell did he even know?!\nWe thought we were being {b}so{/b} careful."
    scene 19_0381 with dissolve
    mc "Melissa's mom had already tried to... rescue... her once. Her father was paranoid it would happen again."
    mc "I guess whoever was watching Melissa told him you were both friendly, so he wanted to keep an eye on you."
    mc "He might think you helped Melissa and Harry with their escape, but he doesn't know for sure."
    scene 19_0382 with dissolve
    dawn "This won't ever be over, will it?"
    dawn "I'll never be able to go back home."
    scene 19_0383 with dissolve
    mc "Don't talk that way. Don't even {i}think{/i} that way."
    scene 19_0384 with dissolve
    mc "I promised to keep you safe.\nI promised to get you home."
    mc "I {b}keep{/b} my promises, Dawn."
    scene 19_0385 with dissolve
    call Emotion (dawn, "Sniffles", "Why?")
    scene 19_0386 with dissolve
    dawn "Your commitment is to Melissa, not me. I'm just collateral damage."
    scene 19_0387 with dissolve
    mc "You're wrong. You're much more than that!"
    mc "We're in this together - all the way."
    dawn "[whi]Okay... Thank you."
    scene 19_0388 with dissolve
    dawn "So what happens now?"
    mc "I'm gonna see the Dean to find out what happened, and reassure her that we have everything under control."
    dawn "Do we, though?"
    scene 19_0389 with dissolve
    mc "We knew they'd show up at the college looking for information."
    mc "We already suspected your stalker was connected, and now we know for sure."
    mc "I know you're scared, but nothing's changed."
    dawn "When you put it like that... Yeah, I guess you're right."
    scene 19_0390 with dissolve
    mc "I have to go. You gonna be okay?"
    dawn "Yeah."
    scene 19_0391 with dissolve
    dawn "Are you coming back later?"
    scene 19_0392 with dissolve
    mc "Yeah, I'll probably stay the night if that's alright."
    dawn "Of course it is."
    if Dawn.isSexual():
        scene 19_0393 with dissolve
        dawn "I'll be sure to leave enough room in my bed for you to sneak in... should you want to."
    scene 19_0394 with dissolve
    mc "See you later."
    dawn "[whi]Bye."
    scene 19_0395 with dis1
    scene 19_0396 with dis1
    scene 19_0397 with dis1
    blz "How'd it go?"
    mc "As expected."
    scene 19_0398 with dissolve
    blz "She okay?"
    mc "Yeah, she will be."
    scene 19_0399 with dissolve
    mc "Back in a bit. Gonna see the Dean."
    blz "Okay."
    scene 19_0400 with dis1
    pause 0.5
    if Nettie.isActive():
        play sound "vib.mp3"
        pause 0.5
        scene 19_0401 with dis1
        stop sound
        mc cell "Nettie. Hey.\nHow's things?"
        net cell "Hi, [mc].\nEverything's okay here."
        scene 19_0402 with dissolve
        net cell "You asked me to talk to Hayley about helping your police officer friend with her case."
        net cell "Well, despite my best efforts to convince her not to, she seems determined to help you."
        scene 19_0403 with dissolve
        mc cell "Okay, good.\nHopefully it won't come to that, but it's good to know it's an option."
        net cell "She hasn't fully made up her mind yet.\nShe'd like to talk it through with you first."
        scene 19_0404 with dissolve
        mc cell "Okay, I can talk to her; put her on."
        net cell "[mc]! Not on the phone!\nThis is a big deal for her!"
        scene 19_0405 with dissolve
        net cell "The least you can do is speak to her face-to-face!"
        mc cell "Yeah, okay. Sorry.\nYou're right. I'll come down as soon as I can."
        scene 19_0406 with dissolve
        net cell "Great. We'll see you soon then."
        mc cell "Bye, Nettie."
        scene 19_0407 with dissolve
    else:
        scene 19_0407 with dis1
    pause 0.5
    scene 19_0408 with dissolve
    mc cell "Hi Ruth.\nI'm ready for our meeting if you are."
    ruth cell "Yes."
    mc cell "It's probably best to meet somewhere off campus.\nMelissa's father could have guys watching the place."
    ruth cell "Very well.\nWe can meet at my apartment if that's acceptable to you."
    mc cell "Yeah. Perfect."
    if Ruth.isActive():
        ruth cell "Do you remember where it is?"
        mc cell "Yeah. I'm on my way now."
    else:
        ruth cell "I'll forward you my address."
        mc cell "Okay, great. I'm on my way now."
    scene 19_0409 with dis1
    scene 19_0410 with dis1
    scene 19_0411 with dis1
    scene 19_0412 with dis1
    scene 19_0413 with dis1
    call Lakeshore_03_VisitRuth
    scene 19_0653 with fade2
    pause
    scene 19_0654 with fade
    blz "Hey, Boss.\nEverything go A-OK?"
    mc "Yeah."
    scene 19_0655 with dissolve
    mc "They still hiding from you?"
    blz "Hiding??\nThey're upstairs, as usual."
    scene 19_0656 with dissolve
    mc "You know they're scared stiff of you, right?\nThey're keeping out of your way."
    scene 19_0657 with dissolve
    blz "That's the point. And it's not the {i}only{/i} benefit!"
    blz "They're easier to keep in line, and they don't whine at me."
    scene 19_0658 with dissolve
    mc "Blaze, c'mon.\nCan you {b}please{/b} play nice with them?"
    mc "They're living in their PJs because they don't want to 'bother' you and ask for more clothes!"
    scene 19_0659 with dissolve
    blz "Big deal!\nIt's not like they need to get dressed up for prom!"
    blz "They're not going anywhere anytime soon!\nThey should be grateful - PJs are comfy!"
    scene 19_0660 with dissolve
    mc "Yeah, I'm not buying it, so you can quit pretending to be a hard-ass."
    scene 19_0661 with dissolve
    mc "I know you want to see this as {i}just another mission{/i}."
    scene 19_0662 with dissolve
    mc "You're trying to hide it, but you care about them."
    mc "Anton scares you, and you're worried about what's gonna happen to them if we don't stop him."
    scene 19_0663 with dissolve
    blz "You know the rules, Boss.\nThe minute it becomes personal, we stop being professional."
    blz "They've put their lives in {i}our{/i} hands. We {b}can't{/b} let them down!"
    mc "We won't."
    scene 19_0664 with dissolve
    blz "It's just the {b}two{/b} of us, against fuck knows how many!"
    blz "If they find us... this is a battle we can't win."
    scene 19_0665 with dissolve
    mc "If that's what you believe, then why are you still here?"
    blz "Because you needed my help, and I'll never turn my back on you."
    blz "I know you'll never walk away. Neither will I."
    scene 19_0666 with dissolve
    mc "We're not gonna let anything happen to them."
    mc "We're gonna keep them safe, no matter what. Agreed?"
    scene 19_0667 with dissolve
    blz "Yes, Sir."
    scene 19_0668 with dissolve
    blz "Don't see why they can't be safe in their PJs, but... whatever."
    call laugh (mc)
    mc "Less rottweiler, more poodle, please Sergeant."
    blz "Copy."
    scene 19_0669 with dissolve
    mc "I'll update Dawn."
    scene 19_0670 with dissolve
    blz "Tell her I'll do a run tomorrow, so make a list of everything they need."
    scene 19_0671 with dis1
    play sound "knock.mp3" volume 0.5
    scene 19_0672 with dissolve
    pause 0.5
    dawn "[whi]Come in."
    scene 19_0673 with dissolve
    mc "[whi]Hey."
    scene 19_0674 with dissolve
    dawn "How was Ruth?"
    scene 19_0675 with dissolve
    mc "She's fine."
    dawn "What did she say?"
    scene 19_0676 with fade1
    dawn "So... What'll happen when they come back in two weeks??"
    scene 19_0677 with dissolve
    mc "They probably won't, but even if they do, Ruth can fob them off some more."
    mc "She'll tell them you called and requested extra vacation time... Something like that."
    scene 19_0678 with dissolve
    dawn "Melissa's father won't stop searching for her, [mc]."
    dawn "You should hear some of the horror stories she's told me about him. He's a goddamn monster."
    dawn "I can't be on vacation forever! I don't see how this ends!"
    scene 19_0679 with dissolve
    mc "I know."
    mc "Okay, listen... I need to tell you something."
    mc "I'm not in this alone.\nThere's a cop in Springhaven - we're working together to bring down this whole fuckin' gang."
    scene 19_0680 with dissolve
    dawn "The police are involved??"
    dawn "Why didn't you tell me this sooner?!"
    scene 19_0681 with dissolve
    mc "Because it's a secret operation!"
    mc "I shouldn't be telling you now, but I think you can handle it."
    mc "And I think it's best if Melissa doesn't find out yet."
    scene 19_0682 with dissolve
    dawn "Why?\nYou're not worried she'd warn her father, are you?"
    dawn "There's no love lost there. She wants to be free of him."
    dawn "I don't think she cares {b}how{/b} it happens, or what it takes."
    scene 19_0683 with dissolve
    mc "Okay... You know her best, so I'll leave it up to you."
    mc "If you think she ought to know, then I won't ask you to keep it from her."
    scene 19_0684 with dissolve
    dawn "That didn't take much convincing!"
    dawn "Why do I feel manipulated?"
    dawn "You {b}want{/b} her to know, don't you?\nAnd you wanted {i}me{/i} to be the one to tell her!"
    scene 19_0685 with dissolve
    mc "It'll be better coming from you."
    mc "You sounded relieved when I told you cops were involved.\nYou're more optimistic about the outcome."
    mc "That'll help when you tell Melissa, and hopefully she'll feel the same way."
    scene 19_0686 with dissolve
    dawn "I can't deny it. Knowing the police are a part of this... It helps."
    dawn "Okay, I'll talk to her."
    mc "Thanks."
    scene 19_0687 with dissolve
    dawn "And I understand why you didn't tell me right away."
    dawn "So thank you for telling me now."
    scene 19_0688 with dissolve
    mc "I'll let you get back to your book."
    scene 19_0689 with dis1
    scene 19_0690 with dis1
    mc "Oh... I almost forgot."
    mc "I talked to Blaze.\nShe asked you guys to make a list of everything you need, and she'll go out tomorrow."
    dawn "Oh, that's great!\nI'll get right on it, thanks!"
    if Melissa.isActive():
        scene 19_0692 with dissolve
        dawn "That reminds me... I nearly forgot something too!"
        dawn "Melissa wants you to go see her when you have a minute.\nShe's in her room."
        scene 19_0693 with dissolve
        mc "Okay.\nAny idea why?"
        dawn "I think she wants you to help her practice some more."
        mc "Err.. Practice?"
        scene 19_0694 with dissolve
        dawn "No need to play coy!\nYou know {i}exactly{/i} what I'm talking about."
        dawn "I think it's sweet that you agreed to help.\nIt's a good confidence boost for her."
        scene 19_0695 with dissolve
        dawn "I wasn't kidding earlier when I said she was horny. Be careful! [lol]"
        call laugh (mc, "I will.")
        scene 19_0696 with dissolve
        scene 19_0698 with dis1
        play sound "knock.mp3"
        scene 19_0699 with dissolve
        meli "[whi]Come in."
        call MelissaReplay01
        scene 19_0812 with fade1
        meli "If it's okay with you, I'd like to keep practicing when you visit."
        mc "Sure. If that's what you want."
        scene 19_0813 with dissolve
        meli "Maybe you can teach me some other things, too."
        mc "Like what?"
        scene 19_0814 with dis1
        meli "Umm... I don't know..."
        scene 19_0815 with dis1
        meli "Just... {i}things{/i}."
        scene 19_0816 with dissolve
        mc "Sure."
        meli "Cool."
        scene 19_0817 with dis1
        scene 19_0818 with dis1
        scene 19_0819 with dissolve
        pause
    else:
        scene 19_0691 with dis1
        scene 19_0696 with dis1
        scene 19_0697 with dis1
        scene black with fade2
    call CenterText ("Later that evening.")
    scene 19_0820 with Fade(0,1, 3)
    pause
    scene 19_0821 with fade1
    meli "What about snacks? Can we get snacks??"
    scene 19_0822 with dissolve
    dawn "I'm sure Blaze wouldn't mind getting us some!\nHave anything in particular in mind?"
    scene 19_0823 with dissolve
    blz "And you've heard {i}nothing{/i} from her since?"
    mc "Apart from the text telling me she was busy, no."
    mc "I thought maybe she's been working the night shift... but... I dunno... I'm starting to worry."
    scene 19_0824 with dissolve
    blz "I'm sure she's fine, [mc]."
    blz "She's a cop; probably just snowed under with work."
    scene 19_0825 with dissolve
    mc "Too busy to even send a quick text to let me know she's okay?"
    blz "She did, though!"
    mc "Only when I threatened to go looking for her!"
    blz "Because she realized you were worrying!"
    scene 19_0826 with dissolve
    mc "I dunno, Blaze... something's not right.\nI've got a bad feeling."
    blz "So what you gonna do?"
    mc "If she ain't called by the time I get home... I'm gonna find her myself."
    scene 19_0827 with dissolve
    blz "You've always trusted your gut, Boss... Hell, {b}I've{/b} always trusted it!"
    blz "It's saved our skin more than I care to remember, so if that's how you feel, then yeah - you should do something."
    scene 19_0828 with dissolve
    blz "Although... There was that {i}one time{/i} when your gut told you the guy by that bridge was up to no good!"
    mc "I was being cautious! We were on high alert!"
    blz "Remind me... What was it again??"
    scene 19_0829 with dissolve
    call laugh (mc, "Fuck you!")
    mc "It looked like he was trying to hide from us!\nYou weren't sure either!"
    blz "No, no, no - I was just agreeing with my commanding officer!"
    call laugh (mc, "Bullshit!")
    scene 19_0830 with dissolve
    dawn "So what was he doing?"
    scene 19_0831 with dissolve
    mc "Uhh, nothing. It was just an innocent mistake."
    blz "[lol]"
    scene 19_0832 with dissolve
    blz "It wasn't even a {i}he{/i}!\nIt was an old, discarded rug!"
    meli "How could you mistake a rug for a man??"
    blz "[lol]"
    scene 19_0833 with dissolve
    mc "It was rolled up! And on a bank... We could only see part of it!"
    mc "That part we couldn't see... a stupid goat had got itself tangled up in it and was trying to pull free!"
    mc "From our vantage point, it looked like a guy crawling prone!"
    scene 19_0834 with dissolve
    meli "[lol]"
    mc "We were pretty far away!"
    scene 19_0835 with dissolve
    call laugh (mc, "Yeah, yeah...Okay. Get back to your shopping list, you two!")
    dawn "[lol]"
    scene 19_0836 with dissolve
    mc "And if memory serves correctly... Wasn't it {i}you{/i} who suggested--"
    blz "Okay! Tell me more about this dog we gotta rescue!"
    call laugh (mc)
    scene 19_0837 with dissolve
    blz "I don't get why we even need a plan?"
    blz "You said we're just goin' through the motions with this whole smuggler thing... You don't actually need the plane?"
    blz "So can't you keep stringing her along until you no longer need her?"
    scene 19_0838 with dissolve
    mc "Yeah... I thought about doin' that."
    blz "But where's your compassion?! It's her dog!\nIf we can get Bruno home... It's the right thing to do."
    scene 19_0839 with dissolve
    blz "{i}Riiight{/i}."
    blz "One question though... Would you feel the same way if the smuggler was a dude?"
    blz "Is this really about her dog, or her pussy?"
    scene 19_0840 with dissolve
    mc "C'mon! Obviously it's about the dog!"
    mc "... {i}Mostly{/i}."
    blz "[lol]"
    scene 19_0841 with dissolve
    blz "Well, I don't think you'll be getting any!\nThere's no way you're getting the dog outta there without..."
    blz "Oh... Unless..."
    blz "Do you remember that stupid joke Tomo pulled on Riggs?"
    scene 19_0842 with dissolve
    mc "Damn! Which one??\nThose two were always raggin' on each other!"
    blz "Riggs always kept a framed picture of his mom next to his cot, and Tomo switched out the photo."
    blz "Wasn't it Mrs. Doubtfire, or something?"
    scene 19_0843 with dissolve
    call laugh (mc)
    mc "He kissed that thing goodnight for almost two weeks before he noticed!"
    mc "But to be fair, his mom did kinda look like Robin Williams!"
    scene 19_0844 with dissolve
    blz "That's my point.\nFind another dog that looks similar to Bruno and swap them!"
    blz "Sure - the smuggler would notice right away... but Jemma? I doubt it."
    scene 19_0836 with dissolve
    mc "Yeah... it {i}might{/i} work... But where the hell do I get another dog??\nIt's the size of a small pony... Not very common."
    blz "Call in to some local animal shelters; you may get lucky."
    mc "Worth a shot, I guess."
    scene 19_0845 with dissolve
    dawn "Okay, I think we're done with the list.\nI'll leave it here for you."
    dawn "I... hope it's not too much."
    dawn "... And we added a couple of not-so-important things... Snacks... But you can ignore them if you want."
    blz "Hell no! We {b}need{/b} snacks!"
    scene 19_0846 with dissolve
    blz "{i}Someone{/i} forgot to buy me some on his way here!"
    mc "Damn! I said sorry!"
    scene 19_0845 with dissolve
    dawn "Okay, great!"
    dawn "I'm going to read for a while before bed."
    scene 19_0847 with dissolve
    dawn "Goodnight everyone."
    mc "Night."
    scene 19_0848 with dissolve
    meli "I think I'll go to bed, too. I'm tired."
    scene 19_0849 with dissolve
    meli "Goodnight."
    mc "Night Melissa."
    scene 19_0850 with dissolve
    mc "See?!\nPoor girl's terrified of being in the same room as you without her friend!"
    blz "[lol] Shut up!"
    blz "Fine, I'll go easier on them."
    scene 19_0851 with dissolve
    blz "Think I'll get some shut-eye, too.\nI'll get you a blanket."
    mc "Thanks."
    scene 19_0852 with fade2
    pause
    scene 19_0853 with dissolve
    mct "As crazy as the idea sounds, switching dogs might actually work."
    mct "Finding another Bruno, though... That's gonna be tough."
    mct "..."
    mct "Damn... This couch sucks!"
    $ a=True
    if Dawn.isSexual() or Blaze.isActive():
        menu:
            "Sleep in Dawn's bed" if Dawn.isSexual():
                $ Dawn.Add("A00")
                scene black with fade
                play sound "knock.mp3"
                scene 19_0855 with fade1
                mc "[whi]Hey."
                scene 19_0856 with dissolve
                dawn "[whi]Hey.\nI was just about to go to sleep... But, fancy a quickie first?"
                call DawnReplay04
                $ a=False
            "Sleep in Blaze's bed" if Blaze.isActive():
                $ Blaze.Add("A00")
                call BlazeReplay01
                $ a=False
            "Go to sleep":
                pass
    if a:
        scene 19_0854 with fade1
        mc "[whi]..Zzzzz.."
        scene black with Fade(3, 2, 0)
    scene 19_1054 with Fade(0, 2, 3)
    pause
    scene 19_1055 with dissolve
    mc "See you soon, guys."
    meli "Bye, [mc]."
    scene 19_1056 with dis1
    scene 19_1057 with dis1
    scene 19_1058 with dis1
    scene 19_1059 with dis1
    jump Lakeshore_Leave
return

label Lakeshore_03_VisitRuth:
    scene 19_0414 with fade2
    scene 19_0415 with dis1
    scene 19_0416 with dis1
    scene 19_0417 with dis1
    scene 19_0418 with dis1
    scene 19_0419 with dis1
    scene 19_0420 with dis1
    scene 19_0421 with dis1
    scene 19_0422 with fadehold
    ruth "Thank you for coming.\nPlease, come in."
    mc "Thanks."
    scene 19_0423 with dissolve
    mc "How's the security guard?"
    ruth "Only minor injuries.\nWe treated him at the nurses' station we provide on campus."
    if not Ruth.isActive():
        scene 19_0424 with dissolve
        mc "Nice place!"
        ruth "Yes. Thank you."
    scene 19_0425 with dissolve
    mc "Can you tell me what happened?"
    ruth "Two... {i}gentlemen{/i}... showed up demanding to see me.\nThe security guard explained that an appointment was required to enter campus."
    ruth "They decided otherwise and assaulted him."
    scene 19_0426 with dissolve
    ruth "They came to my office and demanded to see all security footage that might show Melissa and the boy, Harry."
    scene 19_0427 with dissolve
    ruth "I explained that we don't keep any such footage on-site."
    ruth "All electronic building monitoring is contracted to an external security company."
    scene 19_0428 with dissolve
    ruth "They wanted the company details."
    ruth "I told them they'd have to request such information from the board of directors.\nI'm in charge of our students' education, not campus security."
    scene 19_0429 with dissolve
    mc "And they bought that??"
    ruth "Apparently, yes.\nThey {i}did{/i} seem rather dim-witted."
    scene 19_0430 with dissolve
    ruth "I imagine that was the first time either of them had set foot inside a college."
    scene 19_0431 with dissolve
    mc "You said they asked about Dawn?"
    ruth "Yes."
    scene 19_0432 with dissolve
    ruth "They demanded to speak to her. Insisted I fetch her at once."
    mc "So they thought she was there? On campus?"
    scene 19_0433 with dissolve
    mc "Do you think they believed you when you told them she was on vacation?"
    ruth "It's impossible to know for certain, but I'd say so, yes."
    scene 19_0434 with dissolve
    ruth "I even came up with a story about how she'd been banking her days off so she could go and visit her elderly mother for two weeks."
    ruth "And of course, I had no idea where her mother lives - why would I?\nSo I could be of no further help."
    scene 19_0435 with dissolve
    ruth "That's when they threatened to return. In two weeks.\nThey're determined to question her."
    scene 19_0436 with dissolve
    mc "Okay, I admit - I'm impressed!\nYou even bought us some time."
    mc "The way you spoke when you called, I imagined you were cowering behind your desk the whole time!"
    mc "Sounds like you ran rings around them, though."
    scene 19_0437 with dissolve
    ruth "I've been dealing with bullies my whole life."
    ruth "A stern look and a firm voice are usually enough to put them in their place."
    mc "Yeah, you definitely have that whole {i}mom vibe{/i} going for you."
    scene 19_0438 with dissolve
    mc "When they asked for Dawn, did they mention her by name, or did they ask to see Melissa's teacher?"
    ruth "By name. They know about her.\nThey came to the college because they didn't find her at her apartment."
    ruth "I give you my word - Any information they have on her didn't come from me."
    scene 19_0439 with dissolve
    mc "No, I know. Melissa's father already knew about her.\nThey'd been following her around for a while."
    mc "What about Melissa's mother? Any mention of her, or Springhaven?"
    ruth "No, nothing."
    mc "Good."
    scene 19_0440 with dissolve
    mc "Okay... We've established that you {i}weren't{/i} actually scared."
    mc "So why did you want this meeting?"
    if Ruth.isActive():
        scene 19_0466 with dissolve
        ruth "You said you'd come back... But you didn't."
        ruth "I thought maybe you were waiting for a reason, so I gave you one."
        scene 19_0467 with dissolve
        ruth "I'm sorry.\nSaying it out loud... I can see how foolish I'm being."
        scene 19_0468 with dissolve
        mc "I {b}was{/b} planning on coming back, Ruth.\nI've been busy, that's all."
        scene 19_0469 with dissolve
        ruth "It's quite alright. I set my hopes too high."
        scene 19_0470 with dissolve
        ruth "You don't need to pander to this old woman's silly fantasies any longer."
        ruth "You honored your end of our arrangement. I shall continue to honor mine."
        $ tCh=Ruth.Has("EZ")
        if not EzModeActive:
            menu:
                "Leave [wk_c]":
                    $ tCh=False
                "Stay":
                    $ tCh=True
        if tCh:
            scene 19_0471 with dis1
            scene 19_0472 with dis1
            mc "Come on."
            scene 19_0473 with dis1
            ruth "Where are we going?"
            mc "Bed."
            scene 19_0474 with dis1
            call RuthReplay03
        else:
            call CloseCharacterPath (Ruth, "Ruth")
            $ Ruth.Add("Z00")
            scene 19_0449 with dissolve
            mc "I appreciate that."
            scene 19_0450 with dissolve
            mc "I {b}did{/b} enjoy our time together."
            ruth "Not as much as I did, I'm sure."
            scene 19_0451 with dissolve
            mc "If they come back, call me immediately."
            ruth "I will."
            scene 19_0452 with dissolve
            ruth "Thank you, [mc]. It's been a pleasure."
            scene 19_0453 with dis1
            scene 19_0454 with dis1
            scene 19_0455 with dis1
    else:
        scene 19_0441 with dissolve
        ruth "I assume you require further assistance from me?"
        mc "We need you to keep doing what you're doing, yeah."
        ruth "Then we need to negotiate a {b}new{/b} arrangement!"
        scene 19_0442 with dissolve
        ruth "I kept my end of our bargain, but {i}that{/i} deal expired the moment those thugs left my office."
        ruth "If you still require my allegiance..."
        scene 19_0443 with dissolve
        call Emotion (mc, "Sigh", "You want {b}more{/b} money??")
        ruth "Your boss can afford it."
        mc "Even she has limits, Ruth. Haven't we given you enough??"
        scene 19_0444 with dissolve
        ruth "No, you haven't!"
        ruth "It's my life and career on the line!"
        ruth "If you aren't willing to compensate me for my true worth, so be it!"
        mc "What the hell does that mean?"
        scene 19_0445 with dissolve
        ruth "If my loyalty is no longer of importance to you, I'm sure {b}Melissa's father{/b} will pay handsomely for it."
        scene 19_0446 with dissolve
        mc "You want to blackmail us?! Are you fuckin' crazy??"
        mc "That's a path you {b}don't{/b} wanna take, Ruth. Jesus!"
        scene 19_0447 with dissolve
        ruth "So don't force me down it.\nSeventy-five thousand is a reasonable figure."
        mc "That's a lot of money. I'll need to discuss it with Sue before I can agree."
        mc "But I need your guarantee that this is it."
        scene 19_0448 with dissolve
        mc "No more demands. No more negotiating.\nYou're with us until this is over."
        ruth "You have my word."
        scene 19_0449 with dissolve
        mc "We'll be in touch."
        scene 19_0450 with dissolve
        mc "Jesus, Ruth... I hope that blackmail attempt came from desperation, not greed."
        ruth "Perhaps a little of both."
        scene 19_0451 with dissolve
        mc "Just don't do anything stupid before you hear from us."
        scene 19_0452 with dissolve
        ruth "Don't leave me waiting too long."
        scene 19_0453 with dis1
        scene 19_0454 with dis1
        scene 19_0455 with dis1
    scene 19_0456 with Fade(2, 3, 2)
    scene 19_0457 with dis1
    scene 19_0458 with dis1
    scene 19_0459 with dis1
    scene 19_0460 with dis1
    scene 19_0461 with dis1
    mc cell "Hey, it's me."
    mc cell "I just spoke with her.\nThings aren't as bad as we feared."
    mc cell "It was a fishing expedition. They still have no idea."
    sue cell "Excellent."
    if not Ruth.isActive() and not Ruth.Has("Z00"):
        mc cell "She wants more cash if she's to continue helping us, though."
        sue cell "Of course she does. Greed knows no bounds."
        mc cell "She's demanding seventy-five thousand."
        sue cell "We have little option but to comply.\nI'll make the arrangements."
        show screen WlkGuide(wkg008)            
        menu:
            "Tell Sue about the blackmail":
                hide screen WlkGuide 
                scene 19_0465 with dissolve
                $ Ruth.Add("A00")
                mc cell "She threatened to go to Anton if you didn't pay."
                sue cell "{size=*0.8}{font=Vanilla.ttf}*{i}Sigh{/i}*{/font}{/size} ...So be it."
                sue cell "We can no longer guarantee her loyalty."
                sue cell "She must be silenced. Permanently."
                mc cell "Is that really necessary?\nIf we pay her..."
                sue cell "You know as well as I do that, even if payment is forthcoming, she'll eventually betray us."
                sue cell "Don't be concerned. I'm not asking it of you."
                sue cell "Other arrangements will be made."
                scene 19_0461 with dis1
            "Don't say anything":
                hide screen WlkGuide 
    else:
        sue cell "She's okay?"
        mc cell "Yeah, a little shook up. I've calmed her down and reassured her."
        sue cell "Good work."
    sue cell "We shall speak more on your return."
    $ Ruth.Del("Z00")
    scene 19_0462 with dis1
    scene 19_0463 with dis1
    scene 19_0464 with dis1
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
