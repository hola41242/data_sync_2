label BlazeReplay01:
    call Unlocker ("BlazeReplay01")
    $ Blaze.incSex()
    scene black with fade
    play sound "knock.mp3"
    scene 19_0944 with fade1
    mc "[whi]Blaze?"
    scene 19_0945 with dissolve
    blz "What's up?"
    scene 19_0946 with dissolve
    mc "Time we parked the truck."
    scene 19_0947 with dissolve
    blz "Yes Sir!"
    scene 19_0948 with dissolve
    blz "Not to put any pressure on you, but I've thought about us fucking many times over the years..."
    scene 19_0949 with dissolve
    scene 19_0950 with dissolve
    blz "... So I hope you're able to live up to the fantasy!"
    scene 19_0951 with dissolve
    mc "I'll try not to let you down, Sergeant."
    scene 19_0952 with dissolve
    blz "[whi]So far, so good."
    scene 19_0953 with dis1
    pause
    scene 19_0954 with dissolve
    image BlazeR01_01 = Movie(play="images/e19/19_0955.webm", loop=False, keep_last_frame=True)
    image BlazeR01_02 = Movie(play="images/e19/19_0956.webm")
    show BlazeR01_01
    pause 2.9
    show BlazeR01_02
    blz "[ss]Mhhh."
    scene 19_0957 with dissolve
    image BlazeR01_03 = Movie(play="images/e19/19_0958.webm")
    show BlazeR01_03
    blz "[ss]..Mmhhh.."
    scene 19_0959 with dissolve
    blz "[ss]...Mhh..."
    scene 19_0960 with dis1
    pause 0.5
    scene 19_0961 with dis1
    pause 0.5
    scene 19_0962 with dissolve
    image BlazeR01_04 = Movie(play="images/e19/19_0963.webm")
    show BlazeR01_04
    blz "[ss]..Mmmmhhh.."
    scene 19_0964 with dissolve
    image BlazeR01_05 = Movie(play="images/e19/19_0965.webm")
    show BlazeR01_05
    pause
    scene 19_0966 with dissolve
    call Moan (blz, 4)
    scene 19_0967 with dissolve
    pause 0.5
    scene 19_0968 with dis1
    scene 19_0969 with dis1
    pause 0.5
    scene 19_0970 with dissolve
    blz "[ss]Shit, Boss... That's nice...."
    scene 19_0971 with dissolve
    image BlazeR01_06 = Movie(play="images/e19/19_0972.webm")
    show BlazeR01_06
    call Moan (blz, 4)
    scene 19_0973 with dissolve
    image BlazeR01_07 = Movie(play="images/e19/19_0974.webm")
    show BlazeR01_07
    pause
    scene 19_0975 with dis1
    scene 19_0976 with dis1
    scene 19_0977 with dis1
    scene 19_0978 with dis1
    scene 19_0979 with dis1
    blz "[ss]Ohhh.."
    scene 19_0980 with dissolve
    call Moan (blz, 4)
    scene 19_0981 with dissolve
    blz "[ss]...Fuuuuuck..."
    scene 19_0982 with dissolve
    pause
    scene 19_0983 with dissolve
    image BlazeR01_08 = Movie(play="images/e19/19_0984.webm")
    show BlazeR01_08
    call Moan (blz)
    scene 19_0985 with dis1
    scene 19_0986 with dis1
    scene 19_0987 with dis1
    image BlazeR01_10 = Movie(play="images/e19/19_0989.webm")
    image BlazeR01_09 = Movie(play="images/e19/19_0988.webm", loop=False, keep_last_frame=True)
    show BlazeR01_09
    pause 1.0
    blz "[ss]..Mmhh..{w=2}{nw}"
    pause 0.4
    show BlazeR01_10
    blz "[ss]..Ohhh.."
    scene 19_0990 with dissolve
    image BlazeR01_11 = Movie(play="images/e19/19_0991.webm")
    show BlazeR01_11
    pause
    scene 19_0992 with dissolve
    blz "[ss]..Ohhhhh.."
    scene 19_0993 with dissolve
    image BlazeR01_12 = Movie(play="images/e19/19_0994.webm")
    show BlazeR01_12
    blz "[ss]Fuck........That's more like it...."
    scene 19_0995 with dissolve
    image BlazeR01_13 = Movie(play="images/e19/19_0996.webm")
    show BlazeR01_13
    mc "[whi]You like it rough, Sergeant?"
    blz "[ss]Mmhhh.... No, Sir.... but I'm not made of glass either...."
    mc "[whi]Copy that."
    scene 19_0997 with dissolve
    image BlazeR01_14 = Movie(play="images/e19/19_0998.webm")
    show BlazeR01_14
    blz "[ss]..Ohhhhh.."
    scene 19_0999 with dis1
    call Moan (blz)
    blz "[ss]Ohhh......That's good, [persistent.McName]...."
    scene 19_1000 with dis1
    blz "[ss]...Fuck me from behind...."
    scene 19_1001 with dis1
    scene 19_1002 with dis1
    image BlazeR01_15 = Movie(play="images/e19/19_1003.webm")
    show BlazeR01_15
    blz "[ss]....Fuuck.......Yes....."
    scene 19_1004 with dis1
    image BlazeR01_16 = Movie(play="images/e19/19_1005.webm")
    show BlazeR01_16
    call Moan (blz)
    scene 19_1006 with dissolve
    blz "[ss]...fuck yeah.......Ohhh...."
    scene 19_1007 with dis1
    image BlazeR01_17 = Movie(play="images/e19/19_1008.webm")
    show BlazeR01_17
    call Moan (blz)
    scene 19_1009 with dissolve
    pause 0.5
    scene 19_1010 with dis1
    scene 19_1011 with dis1
    scene 19_1012 with dis1
    scene 19_1013 with dissolve
    image BlazeR01_18 = Movie(play="images/e19/19_1014.webm")
    show BlazeR01_18
    blz "[ss]Ohhhh.....Yes......Fuck.....Yes...."
    scene 19_1015 with dissolve
    image BlazeR01_19 = Movie(play="images/e19/19_1016.webm")
    show BlazeR01_19
    call Moan (blz)
    scene 19_1017 with dissolve
    pause 0.5
    scene 19_1018 with dis1
    scene 19_1019 with dis1
    scene 19_1020 with dis1
    scene 19_1021 with dis1
    scene 19_1022 with dis1
    blz "[ss]Mmhh."
    scene 19_1023 with dissolve
    image BlazeR01_20 = Movie(play="images/e19/19_1024.webm")
    show BlazeR01_20
    blz "[ss]..Mmmhh.."
    scene 19_1025 with dissolve
    blz "[ss]Mmhhhh."
    scene 19_1026 with dissolve
    image BlazeR01_21 = Movie(play="images/e19/19_1027.webm")
    show BlazeR01_21
    call Moan (blz)
    scene 19_1028 with dis1
    scene 19_1029 with dis1
    image BlazeR01_22 = Movie(play="images/e19/19_1030.webm")
    show BlazeR01_22
    blz "[ss]...OHHHH, GOD.......YES......FUCK ME, [persistent.McName!u]..."
    scene 19_1031 with dissolve
    image BlazeR01_23 = Movie(play="images/e19/19_1032.webm")
    show BlazeR01_23
    call Moan (blz)
    scene 19_1033 with dissolve
    image BlazeR01_24 = Movie(play="images/e19/19_1034.webm")
    show BlazeR01_24
    blz "[ss]...FUCK......I'M SO CLOSE......OHHHHH......."
    scene 19_1035 with dissolve
    image BlazeR01_25 = Movie(play="images/e19/19_1036.webm")
    show BlazeR01_25
    call Moan (blz)
    scene 19_1037 with dis1
    scene 19_1038 with dis1
    image BlazeR01_26 = Movie(play="images/e19/19_1039.webm")
    show BlazeR01_26
    blz "[ss]...OHHHH..."
    scene 19_1040 with dissolve
    blz "[ss]Mmhhhh."
    scene 19_1041 with dissolve
    image BlazeR01_27 = Movie(play="images/e19/19_1042.webm")
    show BlazeR01_27
    blz "[ss]..Mmmhh.."
    scene 19_1043 with dissolve
    blz "[ss]Mmhhhh."
    call CharCum ("e19/19_1043.webp", "e19/19_1044.webp", blz, "....Ohhhhhhh....")
    call CharCum ("e19/19_1044.webp", "e19/19_1045.webp", blz, "...Ohhhhh...")
    scene 19_1046 with dissolve
    image BlazeR01_28 = Movie(play="images/e19/19_1047.webm")
    show BlazeR01_28
    blz "[ss]..Mmhhhhhhh.."
    $ Blaze.incCm()
    call CharCum ("e19/19_1046.webp", "e19/19_1048.webp", mc, "..Nnnnngghhhh...")
    call CharCum ("e19/19_1048.webp", "e19/19_1049.webp", mc, "..Nnnhhhh..")
    scene 19_1050 with dissolve
    blz "[whi]Holy shitballs, boss!\nYou can {b}fuck{/b}!"
    scene 19_1051 with dissolve
    pause
    scene 19_1052 with dissolve
    blz "You blew my fantasy outta the damn water!"
    call laugh (mc)
    if _in_replay:
        scene black with ReplayFade
    else:
        scene 19_1053 with fade1
        mc "[whi]..Zzzz.."
        scene black with Fade(3, 1, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
