label GabbyReplay01:
    call Unlocker ("GabbyReplay01")
    $ Gabby.isSexual(True)
    scene 13_0326 with dissolve
    mel "Come on through."
    scene 13_0327 with dis1
    scene 13_0328 with dis1
    scene 13_0329 with dis1
    mel "She's right, you know."
    mel "I do want to suck your dick again. To hell with our deal."
    scene 13_0330 with hpunch
    $ apause(.25)
    scene 13_0331 with dissolve
    mel "[ss]Mmhh."
    scene 13_0332 with dis1
    $ apause(h=False)
    scene 13_0333 with dis1
    $ apause()
    scene 13_0334 with dis1
    $ apause()
    scene 13_0335 with dis1
    $ apause(h=True)
    scene 13_0336 with dis1
    mc "[whi]Nice desk."
    scene 13_0337 with dissolve
    mel "[whi]Thanks."
    scene 13_0338 with dis1
    $ apause(h=False)
    scene 13_0339 with dis1
    $ apause()
    scene 13_0340 with dis1
    $ apause(h=True)
    scene 13_0341 with dis1
    mel "[ss]Nnhhh."
    scene 13_0342 with dis1
    $ apause(h=False)
    scene 13_0343 with dis1
    $ apause()
    scene 13_0344 with dis1
    $ apause(h=True)
    scene 13_0345 with dissolve
    mel "[ss]Mmhhh."
    scene 13_0346 with dissolve
    image GabbyR01_01 = Movie(play="images/e13/13_0347.webm")
    show GabbyR01_01
    mel "[ss]Mmhhh."
    scene 13_0348 with dissolve
    pause
    scene 13_0349 with dissolve
    image GabbyR01_02 = Movie(play="images/e13/13_0350.webm")
    show GabbyR01_02
    mel "[ss]..Mmmhhh.."
    scene 13_0351 with dissolve
    $ apause(h=False)
    scene 13_0352 with dis1
    $ apause(h=True)
    scene 13_0353 with dis1
    image GabbyR01_03 = Movie(play="images/e13/13_0354.webm")
    show GabbyR01_03
    mel "[ss]..Mmmhhh.."
    scene 13_0355 with dissolve
    pause
    scene 13_0356 with dissolve
    pause
    scene 13_0357 with dissolve
    image GabbyR01_04 = Movie(play="images/e13/13_0358.webm")
    show GabbyR01_04
    mel "[ss]..Mhhh.."
    scene 13_0359 with dissolve
    image GabbyR01_05 = Movie(play="images/e13/13_0360.webm")
    show GabbyR01_05
    mel "[ss]..Mmmmhhh.."
    scene 13_0361 with dissolve
    scene 13_0362 with dis1
    scene 13_0363 with dis1
    scene 13_0364 with dis1
    mel "[ss]..Mhhh.."
    scene 13_0365 with dis1
    $ apause(h=False)
    scene 13_0366 with dis1
    $ apause()
    scene 13_0367 with dis1
    $ apause(h=True)
    scene 13_0368 with dis1
    mel "[ss]..Mmmmhhh.."
    scene 13_0369 with dissolve
    pause
    scene 13_0370 with dissolve
    mel "[ss]..Mhhh.."
    scene 13_0372 with dissolve
    scene 13_0373 with dis1
    scene 13_0374 with dis1
    scene 13_0375 with dis1
    scene 13_0376 with dis1
    scene 13_0377 with dis1
    scene 13_0378 with dis1
    scene 13_0379 with dis1
    scene 13_0380 with dis1
    scene 13_0381 with dis1
    $ apause()
    scene 13_0382 with dis1
    mel "[ss]Fuuck..."
    scene 13_0383 with dissolve
    mel "[ss]..Ohhh.."
    scene 13_0384 with dissolve
    pause
    scene 13_0385 with dissolve
    $ apause(h=False)
    scene 13_0386 with dis1
    $ apause()
    scene 13_0387 with dis1
    $ apause(h=True)
    scene 13_0388 with dis1
    gab "[ss]Mmhh."
    scene 13_0389 with dissolve
    pause
    scene 13_0390 with dissolve
    image GabbyR01_06 = Movie(play="images/e13/13_0391.webm")
    show GabbyR01_06
    call Moan (mel, 4)
    scene 13_0392 with dissolve
    mel "[ss]...Fuck....."
    scene 13_0393 with dissolve
    pause
    scene 13_0394 with dissolve
    pause
    scene 13_0395 with dissolve
    pause
    scene 13_0396 with dissolve
    pause
    scene 13_0397 with dissolve
    call Moan (mel, 4)
    scene 13_0401 with fadehold
    pause
    scene 13_0402 with dissolve
    image GabbyR01_07 = Movie(play="images/e13/13_0403.webm", loop=False, keep_last_frame=True)
    show GabbyR01_07
    pause 2.0
    mel "[ss]Ohhh..{w=1}{nw}"
    pause 1.0
    mel "[ss]...OHHHH..."
    scene 13_0404 with dissolve
    image GabbyR01_08 = Movie(play="images/e13/13_0405.webm")
    show GabbyR01_08
    call Moan (mel, 4)
    scene 13_0408 with dissolve
    mel "[ss]..Ohhhhh.."
    scene 13_0409 with dissolve
    pause
    scene 13_0413 with dissolve
    mel "[ss]....Ohhhhhhh...."
    scene 13_0414 with dissolve
    image GabbyR01_09 = Movie(play="images/e13/13_0415.webm")
    show GabbyR01_09
    call Moan (mel)
    scene 13_0416 with dissolve
    $ apause()
    scene 13_0417 with dis1
    scene 13_0418 with dis1
    scene 13_0419 with dis1
    pause
    scene 13_0420 with dissolve
    $ apause()
    scene 13_0421 with dis1
    scene 13_0422 with dis1
    scene 13_0423 with dis1
    pause
    scene 13_0424 with dissolve
    mel "[ss]..Ohhhhh.."
    scene 13_0425 with dissolve
    image GabbyR01_10 = Movie(play="images/e13/13_0426.webm")
    show GabbyR01_10
    call Moan (mel)
    scene 13_0427 with dissolve
    gab "[ss]Mmhh."
    scene 13_0428 with dissolve
    mel "[whi]Jesus, Gabby!\nI know you're back there, I can hear you kissing!"
    scene 13_0429 with dissolve
    gab "You can't stop me from coming in here."
    scene 13_0430 with dissolve
    call Moan (mel, 4)
    scene 13_0431 with dissolve
    $ apause()
    scene 13_0432 with dis1
    gab "[whi]Is he good, Mel?"
    scene 13_0433 with dissolve
    mel "[ss]....Mhhhh...SO fuckin' good..."
    scene 13_0434 with dissolve
    image GabbyR01_11 = Movie(play="images/e13/13_0435.webm")
    show GabbyR01_11
    call Moan (mel)
    scene 13_0436 with dissolve
    image GabbyR01_12 = Movie(play="images/e13/13_0437.webm")
    show GabbyR01_12
    call Moan (mel)
    scene 13_0438 with dissolve
    image GabbyR01_13 = Movie(play="images/e13/13_0439.webm")
    show GabbyR01_13
    call Moan (mel)
    scene 13_0442 with dissolve
    $ apause()
    scene 13_0443 with dis1
    scene 13_0444 with dis1
    pause
    scene 13_0445 with dissolve
    $ apause()
    scene 13_0446 with dis1
    $ apause()
    scene 13_0447 with dis1
    scene 13_0448 with dissolve
    image GabbyR01_14 = Movie(play="images/e13/13_0449.webm")
    show GabbyR01_14
    gab "[ss]..Mmmhhhh.."
    scene 13_0450 with dissolve
    mel "Gabby!"
    scene 13_0451 with dissolve
    mel "That's wrong!"
    scene 13_0452 with dissolve
    mel "He likes us to take it all!"
    scene 13_0453 with dissolve
    mel "Like that!"
    scene 13_0454 with dissolve
    call Gag (gab)
    scene 13_0455 with dissolve
    image GabbyR01_15 = Movie(play="images/e13/13_0456.webm")
    show GabbyR01_15
    gab "[ss]..Mmhhh.."
    scene 13_0457 with dissolve
    mel "Guess I'm not the only one who wanted to suck your dick."
    scene 13_0458 with dissolve
    image GabbyR01_16 = Movie(play="images/e13/13_0459.webm")
    show GabbyR01_16
    mel "[ss]..Mmmmhhh.."
    scene 13_0460 with dissolve
    $ apause()
    scene 13_0461 with dis1
    mel "Okay, you little brat...\nYou've had your fun. Back to work!"
    scene 13_0462 with dissolve
    gab "Why?? There are no customers!"
    mel "Go!"
    scene 13_0463 with dissolve
    gab "Jeez! You're such a killjoy!\nYou just want him all to yourself!"
    scene 13_0464 with dissolve
    mel "Shut up!"
    mel "Give him another kiss before you leave."
    scene 13_0465 with dis1
    scene 13_0466 with dis1
    gab "[ss]..Mmmmhhh.."
    scene 13_0467 with dis1
    mel "Now get outta here."
    if not _in_replay and persistent.Lez and mAndG==None:
        call Encourage ("Melanie", "Gabby")
        $ mAndG=_return
        $ persistent.MelandGab=mAndG
    if persistent.MelandGab:
        mc "Not so fast..."
        scene 13_0468 with dissolve
        mc "Kiss your sister, too."
        mel "What??"
        scene 13_0469 with dissolve
        mc "If we're gonna be a threesome, we should {b}be{/b} a threesome!"
        scene 13_0470 with dissolve
        gab "I'm game if you are, Mel."
        mel "But... We're sisters!"
        scene 13_0471 with dissolve
        mc "Shut up and kiss."
        scene 13_0472 with dissolve
        gab "[ss]..Mmhhh.."
        scene 13_0473 with dissolve
        pause
        scene 13_0474 with dissolve
        mel "[ss]...Mmmmhhh..."
        scene 13_0475 with dissolve
        pause
        scene 13_0476 with dissolve
        image GabbyR01_17 = Movie(play="images/e13/13_0477.webm")
        show GabbyR01_17
        gab "[ss]..Mmhh.."
        scene 13_0478 with dissolve
        mel "What are you doing?"
        gab "Keeping it nice and hard for you!"
    scene 13_0479 with dissolve
    gab "I'm leaving!"
    scene 13_0480 with dissolve
    scene 13_0481 with dissolve
    mel "Now, where were we?"
    call MelanieReplay03_P2
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
