label Springhaven_ConvoCara:
    call CenterText ("Later that night...")
    scene 03_0077 with fade
    pause 1.0
    scene 03_0078 with dis1
    pause 0.5
    scene 03_0079 with dis1
    pause 0.5
    scene 03_0080 with dis1
    car "[whi]Uncle [mc]?"
    scene 03_0081 with dissolve
    car "Uncle [mc]."
    call Emotion (mc, "Groan")
    car "I'm sorry, I know it's late."
    mc "Cara?\nIs everything okay??"
    car "Yeah.\nI can't sleep. I need to talk to you."
    scene 03_0082 with dissolve
    pause 0.5
    scene 03_0083
    pause 0.5
    scene 03_0084 with dissolve
    mc "[whi]What's up?"
    scene 03_0085 with dissolve
    car "Uhh..."
    car "I... I don't know how to start..."
    scene 03_0086 with dissolve
    mc "It's okay. Sit down.\nTake your time, Pipsqueak."
    scene 03_0087 with dissolve
    car "I've been lying in bed for hours, trying to figure out how to have this conversation with you."
    car "I... know something.\nBut I don't know if you know it, too."
    mc "Okay."
    scene 03_0088 with dissolve
    car "I {i}want{/i} you to know.\nBut, if you don't already know, and I tell you...\nI'm frightened it'll ruin everything."
    car "But if you {b}do{/b} know, I want you to know that I know, too."
    car "But if I tell you what I know, and you {b}already{/b} know, you might be upset that I know."
    scene 03_0089 with dissolve
    car "What's wrong??"
    mc "I think my head's about to explode."
    scene 03_0090 with dissolve
    car "{b}This isn't a joke!{/b}"
    scene 03_0091 with dissolve
    mc "I know, I'm sorry.\nI'm not trying to make light of... whatever it is."
    mc "Okay..."
    mc "What if I {b}promise{/b} that nothing will change if you tell me?"
    scene 03_0092 with dissolve
    car "No.\nBecause I don't think you'd be able to keep that promise if you don't already know."
    mc "Umm... Can you tell me {i}how{/i} you know what you know?"
    scene 03_0093 with dissolve
    car "Uhh... yeah, I can do that."
    scene 03_0094 with dissolve
    car "After Dad died, Grandma came to stay with us for a while, you know, to support Mom."
    car "They were chatting in the living room one evening.\nThey must've thought I'd already left to go and see Alex..."
    car "I was about to walk in to say bye, and heard them talking about... me."
    car "I paused to listen... and that's when I found out."
    scene 03_0095 with dissolve
    mc "Okay. So, this thing you know - it's about you, and your mom and grandma know, too?"
    car "Yes."
    scene 03_0096 with dissolve
    mct "FUCK! Does she know????"
    scene 03_0097 with dissolve
    car "That look on your face... {i}Do you know{/i} what I'm talking about??"
    scene 03_0098 with dissolve
    car "If you know, please tell me."
    scene 03_0099 with dissolve
    car "Are you my dad?"
    scene 03_0100 with dissolve
    mc "Yes."
    mc "I'm sorry we kept it from you."
    scene 03_0101 with dissolve
    call Emotion (car, "Sobbing", "Why??")
    mc "I've wanted to tell you {i}so{/i} many times."
    mc "I wish I could say it was your mom's decision, but the truth is, we {i}both{/i} decided it was for the best."
    scene 03_0102 with fade
    mc "We were all best friends."
    mc "Your dad had a {b}major{/b} crush on your mom, had done for years."
    car "Pete."
    scene 03_0103 with dissolve
    car "He's not my dad, {i}you{/i} are."
    mc "Uh, okay."
    scene 03_0104 with dissolve
    mc "We'd all been out drinking, like you do, when you're teenagers."
    mc "Your da..."
    mc "... {i}Pete{/i}... had left early, can't remember why."
    mc "Your mom and I... It was just a bit of fun, foolin' around. One thing led to another..."
    mc "We woke up in the same bed the next morning.\nAt the time, it didn't seem like a big deal, you know."
    mc "We had always been close, hell - we were even boyfriend and girlfriend back in our school days."
    scene 03_0105 with dissolve
    mc "Pete eventually plucked up the courage to ask your mom out on a date, and I was happy for them both."
    mc "My two best friends, together as a couple."
    mc "She didn't find out she was pregnant until a couple of months later."
    mc "Pete automatically figured he was the father.\nProposed immediately."
    mc "Your mom wasn't certain {i}who{/i} the father was."
    scene 03_0106 with dissolve
    mc "We talked about it.\nShe decided to accept his proposal, and we agreed to presume he {i}was{/i} your father."
    mc "After you were born... I... I {b}needed{/b} to know."
    mc "We arranged a DNA test."
    scene 03_0107 with dissolve
    mc "By now, they were already married and truly in love.\nI was with Violet."
    mc "Your mom was frantic. If Pete ever found out, it would destroy their marriage."
    mc "He was a good husband. A good father.\nI, reluctantly, agreed."
    scene 03_0108 with dissolve
    mc "It broke my heart.\nBut I swear, Cara, I thought I was doing what was best for {i}you{/i}."
    scene 03_0109 with dissolve
    car "Did he ever find out?"
    mc "No."
    mc "Why haven't you told your mom that you know?"
    scene 03_0110 with dissolve
    car "I don't know.\nShe's been going through so much..."
    car "... I didn't want to add to it."
    scene 03_0111 with dissolve
    car "Thank you for being honest with me."
    car "I have one more question, though..."
    scene 03_0112 with dissolve
    car "When we're alone together, can I call you Dad?"
    scene 03_0113 with dissolve
    mc "Hell yeah!"
    scene 03_0114 with dissolve
    mc "But... why only when we're alone?"
    mc "You still don't want to tell your mom you know the truth?"
    scene 03_0115 with dissolve
    car "Not yet.\nI {b}will{/b} tell her."
    car "For now, though, I like the thought of {i}just{/i} us knowing."
    car "You won't tell her, will you?"
    scene 03_0116 with dissolve
    mc "It's {i}your{/i} secret, Pipsqueak. My lips are sealed."
    scene 03_0117 with dissolve
    car "Thank you."
    scene 03_0118 with dissolve
    car "I love you... Dad."
    mc "I love you too, Pipsqueak."
    scene 03_0119 with dissolve
    car "[kiss]"
    scene 03_0118 with dissolve
    pause 0.5
    if persistent.Incest and Cara.isActive() and (Cara.Has("L0") or Cara.Has("L1")):
        scene 03_0124 with dis1
        scene 03_0125 with dissolve
        mc "[whi]Whoa. Wait."
        mc "We... can't!"
        car "[whi]Oh... Sorry."
        scene 03_0126 with dissolve
        car "You, uhh... don't want to kiss me?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Yes":
                    $ tCh=True
                "No[wk_c]":
                    pass
        if tCh or Cara.Has("EZ"):
            call CaraReplay02_Part01
        else:
            call CloseCharacterPath (Cara, "Cara")
            $ Cara.Del("L0")
            $ Cara.Del("L1")
            mc "No. I'm sorry Cara, we can't do that!"
            car "Umm... Okay."
            scene 03_0127 with dissolve
            car "It was only a kiss, I didn't mean to..."
            mc "It's fine. We just can't - that's all. I'm your Dad!"
            car "I know. I'm sorry, it won't happen again."
            scene 03_0128 with dissolve
            car "Goodnight, Dad."
            mc "Night, Pipsqueak."
            scene 03_0129 with dissolve
            mc "Love you."
            scene 03_0130 with dissolve
            car "I love you, too!"
            scene black with Fade(3, 0,0)
    else:
        call CloseCharacterPath (Cara)
        scene 03_0120 with dissolve
        car "Goodnight."
        mc "Night."
        scene 03_0121 with fade
        mct "No idea how Alison's gonna react to this news when she finds out."
        scene 03_0122 with dissolve
        mct "She finally knows!"
        scene 03_0123 with dissolve
        pause 0.5
    scene black
    pause 0.5
    jump Springhaven_PrepForLakeshore
return

label Springhaven_PrepForLakeshore:
    scene 03_0224 with Fade(0,3,3)
    call Emotion (ali, "Yawn")
    scene 03_0225 with dissolve
    ali "Morning!\nYou're up early."
    scene 03_0226 with dissolve
    mc "Yeah. I'm, uh, heading out to Lakeshore."
    ali "Lakeshore?? Why?"
    scene 03_0227 with dissolve
    mc "Err..."
    mc "Oh! I forgot to tell you yesterday!"
    mc "I went to see Millie!"
    scene 03_0228 with dissolve
    ali "You did?! [mc]! That's good!"
    ali "How'd it go??"
    scene 03_0229 with dissolve
    mc "Surprisingly well!"
    mc "Even Violet seemed happy to see me!"
    scene 03_0230 with dissolve
    ali "That's great!"
    ali "You should invite them over sometime!"
    ali "Cara would love to spend time with Millie!"
    scene 03_0231 with dissolve
    ali "Nice work deflecting my question, by the way![lol]"
    scene 03_0232 with dissolve
    ali "Don't worry, I'm not gonna ask again."
    ali "But if this is going to be a regular thing - you, traveling - you should consider buying a car!"
    ali "Public transport in this state is terrible!"
    scene 03_0233 with dissolve
    mc "Hmm, yeah... You could be right."
    scene 03_0234 with dissolve
    mc "Especially if I'm gonna be back and forth to Oakhill now."
    mc "Sounds like a plan! Thanks, Ali."
    scene 03_0235 with dissolve
    ali "Have you decided what to do about Nettie?"
    scene 03_0236 with dissolve
    mc "I want to go and see her again."
    mc "Hopefully, she'll accept my apology."
    scene 03_0237 with dissolve
    mc "Wouldn't blame her if she didn't, though."
    mc "I was such an idiot."
    scene 03_0238 with dissolve
    ali "Don't be too hard on yourself, [mc]. It was a lot to take in."
    scene 03_0239 with dissolve
    ali "But yeah, you {b}were{/b} an idiot![lol]"
    scene 03_0240 with dissolve
    if Alison.isSexual():
        ali h "I was tempted to sneak into your bed last night."
        mc "Hmmm, why would you want to do that? Heh."
        scene 03_0241 with dissolve
        if Alison.Has("Anal"):
            ali "Oh, I don't know... Maybe my ass wanted to be violated again."
        else:
            ali "Your bed's more comfortable than mine.[lol]"
        scene 03_0242 with dissolve
        ali "I was about to get out of bed, but I heard Cara walking around."
        ali "I tried to wait 'till the coast was clear, but I fell asleep!"
        scene 03_0243 with dissolve
        mc "[lol]"
    else:
        ali "Have you had breakfast?"
        ali "I can make you something before you leave."
        mc "No thanks, I'll eat later."
    scene 03_0244 with dissolve
    mc "I need to get going."
    ali "How long will you be gone?"
    mc "Uh, I'm not sure.\nHopefully, no more than a day or two."
    if Alison.isSexual():
        scene 03_0245 with dissolve
        if Alison.Has("Anal"):
            mc "When I get back, we can see about violating that ass of yours."
            ali h "Aww! Who says romance is dead?"
        else:
            mc "When I get back, maybe I'll sneak into {i}your{/i} room."
            ali h "Okay... But it really was the bed I wanted!"
        scene 03_0246 with dissolve
        mc "[kiss]"
    scene 03_0247 with fade
    mc "See ya."
    ali "Bye."
    if Mary.Has("Cell"):
        jump Springhaven_LakeshoreBill
    elif Sarah.Has("Cell"):
        jump Springhaven_LakeshoreSarah
    jump Springhaven_LakeshoreBus
return

label Springhaven_LakeshoreBus:
    scene 03_0248 with Fade(3, 2, 2)
    mct "Jeez."
    mct "Alison's right - I {b}do{/b} need to get myself a car."
    scene 03_0249 with dissolve
    call Emotion (mc, "Sigh", "At last!")
    call Lakeshore_Start1A
    call CenterText ("Another long bus journey later.", True)
    $ curLOC=springhaven_id
    scene 03_0903 with dissolve
    mc "It's just a little further down this road."
    scene 03_0904 with dissolve
    mc "Perfect. Thank you."
    scene 03_0905 with dissolve
    mct "Ughh... I'm exhausted!"
    scene black with Fade(3, 0, 0)
    call CenterText ("The next day.", True)
    jump Springhaven_UpdateSue
return

label Springhaven_LakeshoreBill:
    scene 03_0250 with Fade(3, 2, 2)
    mct "Damn it... I {b}think{/b} this is the place he dropped me!"
    mct "These streets all look the same!"
    scene 03_0251 with fade
    mct "Well, look at that... Guess I {b}am{/b} in the right place! Heh."
    play sound "tidle.mp3" loop
    scene 03_0252 with fade
    mc "Hey, Bill! Good to see you again."
    mc "Appreciate the ride."
    bill "Howdy, Son!\nJump on in, we gotta get movin'!"
    play sound "truck02.mp3"
    scene 03_0253 with dissolve
    pause 0.5
    scene black with Fade(3, 1, 0)
    jump Lakeshore_Start1B
return

label Springhaven_LakeshoreSarah:
    scene 03_0254 with Fade(3, 2, 2)
    mct "I'm sure that's her building."
    scene 03_0255 with Fade(1, 0.5, 1)
    play sound "knock.mp3"
    pause 1.0
    scene 03_0256 with dissolve
    pause 1.0
    scene 03_0257 with dissolve
    mc "Hi."
    sar "Great! You made it!"
    sar "I thought you might've changed your mind."
    scene 03_0258 with dissolve
    mc "Sorry.\nIt took a little longer than expected to find your street again."
    sar "Why didn't you call me for directions?[lol]"
    sar "Ready to go?"
    mc "Yeah."
    scene 03_0259 with fade
    sar "It'll be nice to have some company for the long drive again!"
    sar "It was so much fun last time!\nRemember how I couldn't get you to shut up? [lol]"
    mc "Hah. Yeah, sorry."
    sar "[lol]"
    jump Lakeshore_Start1C
return

label Springhaven_MaryReunion:
    $ curLOC=springhaven_id
    call CenterText ("A few hours later...")
    scene 01_0358 with fade
    play sound "truck03.mp3" loop
    bill "I'm sorry, Son."
    mc "Bill! It's fine."
    bill "If I wasn't running so goddamn late...."
    scene 01_0359 with dissolve
    mc "I'll just get a cab home!"
    stop sound
    scene 03_0335 with fade
    bill "At least come inside, I'm sure my Mary would like to say hello!"
    mc "Yeah, of course!"
    scene 03_0336 with dissolve
    mc "I'll need to use your phone anyway, if that's okay."
    mc "I left my cell at home."
    bill "Sure thing!"
    scene 03_0337 with dissolve
    bill "Mary! I'm home!"
    mar "You're so late, Pops!\nI was worried!"
    scene 03_0338 with dissolve
    bill "I know, Pumpkin. I'm sorry."
    bill "I need to get straight back on the road, too."
    scene 03_0339 with dissolve
    mar "Do you have to?? You need to rest!\nYou know I hate being all alone in this house at night!"
    bill "I know, I know!\nBut that other load {b}has{/b} to be delivered tonight!"
    scene 03_0340 with dissolve
    bill "Oh, don't be upset with me, Pumpkin!"
    scene 03_0341 with dissolve
    bill "Look! I have a surprise for you!"
    mc "Hi, Mary."
    scene 03_0342 with dissolve
    pause 0.5
    scene 03_0343 with dissolve
    mar "[mc!u]!"
    scene 03_0344 with dissolve
    pause 0.5
    scene 03_0345 with dissolve
    bill "How come I never get a welcome like that?"
    scene 03_0346 with dissolve
    mar "Oh, Pops! I see you {i}every day{/i}!"
    bill "[lol]"
    scene 03_0347 with dissolve
    mar "Are you staying the night again?"
    scene 03_0348 with dissolve
    mc "Uh, no."
    mc "I wanted to come in and say hello before I left."
    mar "What?"
    scene 03_0349 with dissolve
    mar "No... Please, stay!"
    scene 03_0350 with dissolve
    mar "Pops!!"
    scene 03_0351 with dissolve
    bill "What can I do?[lol]"
    scene 03_0352 with dissolve
    bill "'Course he's more than welcome to stay!"
    bill "But, Mary... You can't force him! "
    scene 03_0353 with dissolve
    bill "Sorry, Pumpkin, but I gotta get movin'!"
    bill "See you in the mornin'."
    scene 03_0354 with dissolve
    bill "Take care, Son!\nMaybe next time we can have a beer together!"
    mc "See ya, Bill. Thanks again for the lift."
    bill "Anytime!"
    scene 03_0355 with dissolve
    mar "Please, [mc]. Can you stay?"
    scene 03_0356 with dissolve
    mar "I'm going to be all alone!"
    mc "Uhh..."
    mc "... Okay, I guess I can stay."
    if Mary.Has("Stay"):
        $ Mary.Add("L1")
    elif Mary.Has("Ran"):
        $ Mary.Add("L0")
    else:
        call CloseCharacterPath (Mary)
    $ Mary.Del("Stay")
    $ Mary.Del("Ran")
    $ Mary.Del("NoDaddy")
    scene 03_0357 with dissolve
    mar "You can?!"
    scene 03_0358 with dissolve
    mar "Yay!"
    scene 03_0360 with dissolve
    mar "Would you like to watch some TV with me?"
    mc "Sure."
    scene 03_0361 with Fade(1, 2, 1)
    pause 2.0
    scene 03_0362 with dissolve
    mar "Sorry about the television, it's old - like Pops!"
    mc "[lol]"
    scene 03_0363 with dissolve
    mar "We used to have a modern one, but we had to sell it."
    mar "... Just like most other things."
    mc "It's fine. An old TV is better than {i}no{/i} TV, right? Heh."
    scene 03_0364 with dissolve
    mc "Does Bill do a lot of overnight runs?"
    mar "Yeah."
    mar "He never used to.\nHe'd always be sure to be home by supper!"
    scene 03_0365 with dissolve
    mar "I wish he'd slow down, take things easy for a while. But he says..."
    scene 03_0366 with dissolve
    call Emotion (mar, "Bill impersonation", "I got not choice, Pumpkin! Bill needs payin'!")
    scene 03_0367 with dissolve
    mc "[lol] Wow!\nYou sound {i}just{/i} like him!"
    mar "[giggles]"
    scene 03_0368 with dissolve
    mc "But... {i}Bill{/i} needs payin'? Or, was it... {b}The bills{/b} need payin'?"
    mar "Oh... Yeah!"
    scene 03_0369 with dissolve
    mar "That {i}does{/i} make more sense! [lol]"
    scene 03_0370 with dissolve
    mc "How come you don't like being alone here?\nI thought you'd be used to it?"
    scene 03_0371 with dissolve
    mar "No! I'll {b}never{/b} get used to it!"
    mar "Only two things scare the bejesus outta me..."
    mar "Being alone in this house at night..."
    if Mary.isActive():
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e03/03_0372.webp", 1148, 647, True, "Springhaven_AF18") with dissolve
            mar "... and thunderstorms!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 03_0372
                hide screen imgMap
        else:
            scene 03_0372 with dissolve
            mar "... and thunderstorms!"
            if not EzModeActive:
                menu:
                    "[wk_y]Take a closer look":
                        call Springhaven_AF18
                    "Don't":
                        pass
            elif Mary.Has("EZ"):
                call Springhaven_AF18
        scene 03_0378 with dissolve
        pause 0.5
        scene 03_0379 with dissolve
    else:
        mar "... and thunderstorms!"
    mc "Thunderstorms??"
    scene 03_0380 with dissolve
    mar "They don't scare you??"
    mar "I always hide under my blankets![lol]"
    scene 03_0381 with dissolve
    mar "Dang! I'm thirsty!"
    scene 03_0382 with dissolve
    mar "Can I get you anything?"
    mc "No, I'm fine, thanks."
    mar "Okay, I'll be right back!"
    scene 03_0383 with fade1
    pause 1.0
    mar "[whi]Oh dear!"
    scene 03_0384 with dissolve
    mc "Uhh... Is everything okay?"
    mar "[whi]Yeah."
    scene 03_0385 with fade
    mar h "I'm so clumsy!"
    mar "I spilled some juice!"
    mc "Oh, do you... need some help?"
    mar "No, it's fine.\nI'll just go change."
    scene 03_0386 with dissolve
    mar " Won't be long."
    mar h "... Oh, I can wear the new nightie I bought yesterday!"
    scene 03_0387 with fade2
    mct "Damn. Feel bad for Bill.\nWorks his ass off and still has to sell his shit just to keep his head above water."
    mar "Do you like it?"
    if Mary.isActive():
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e03/03_0388.webp", 943, 335, True, "Springhaven_AF19") with dissolve
            mc "Wow!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 03_0388
                hide screen imgMap
            else:
                scene 03_0388 with dissolve
        else:
            call Springhaven_AF19
            scene 03_0388 with dissolve
        mc "You look beautiful!"
    else:
        scene 03_0388 with dissolve
        mc "You look very pretty!"
    scene 03_0390 with dissolve
    mar "I do?"
    scene 03_0391 with dissolve
    mar "You're just sayin' that because you're nice."
    scene 03_0392 with dissolve
    mc "No, I'm telling you the truth!"
    if Mary.isActive():
        scene 03_0393 with dissolve
        mar "You really think so? Thank you!"
        scene 03_0394 with dissolve
        mar "[kiss]"
        scene 03_0393 with dissolve
        mar "[giggles]"
    else:
        mar "Thank you!"
    scene 03_0395 with dis1
    pause 2.0
    call CenterText ("An hour or so of TV later...")
    scene 03_0396 with fade
    pause 1.0
    scene 03_0397 with dissolve
    pause 0.5
    scene 03_0398 with dissolve
    call Emotion (mar, "Yawn")
    scene 03_0399 with dissolve
    mar "I think it's time for me to go to bed."
    mc "It's getting quite late. Heh."
    scene 03_0400 with dissolve
    mar "It is!\nYou should probably go to bed, too!"
    mc "Uhh... Yeah, I guess you're right."
    scene 03_0401 with Fade(1, 0.5, 1)
    mar "I don't usually stay up this late!"
    mar "You're a bad influence!"
    scene 03_0402 with dissolve
    mc "Heh. You're not the first person to tell me that."
    call MaryReplay02_Part01
    call CenterText ("The next morning.", True)
    scene 03_0907 with Fade(0,0,2)
    mc "Morning, Mary."
    scene 03_0908 with dissolve
    mar "Good morning!"
    mar "I heard you walking around upstairs, so I made you some breakfast."
    scene 03_0909 with dissolve
    mc "Oh, thank you!\nThat's very sweet of you."
    scene 03_0910 with dissolve
    mc "You sure know how to take care of someone! Heh."
    scene 03_0911 with dissolve
    if persistent.MaryDaddy:
        mar "I told you I'd take good care of you, Daddy!"
    else:
        mar "I like to take care of the people I love!"
    if Mary.isActive():
        scene 03_0912 with dissolve
        mar h "Just like I took care of you last night."
    scene 03_0913 with Fade(1, 0.5, 1)
    mc "Ohh... What happened to your new nightie?"
    scene 03_0914 with dissolve
    mar "Pops got home a couple of hours ago.\nI don't think he'd like it. He's old-fashioned!"
    mc "Like his television?"
    scene 03_0915 with dissolve
    mar "[lol] YES!"
    scene 03_0916 with dissolve
    mar "He told me to wake him when you're ready to leave."
    mc "Why?"
    mar "So he can drive you home!"
    scene 03_0917 with dissolve
    mc "Damn. No, let the poor guy sleep!"
    mc "Besides, I've already called a cab."
    scene 03_0918 with dissolve
    mar "Ohh, I wish you could stay longer."
    mc "Sorry, I need to get back. Maybe next time!"
    scene 03_0919 with dissolve
    mar "We can have another sleepover?"
    mc "Sure, why not?"
    play sound "horn.mp3"
    pause 1.0
    scene 03_0920 with dissolve
    mc "Whoa, my cab's here already. That was fast."
    scene 03_0921 with dissolve
    mc "Thanks for breakfast, Mary. It was delicious."
    mar "You're welcome."
    scene 03_0922 with fade
    $ dia = "Bye," + (" Daddy." if persistent.MaryDaddy else " [mc].")+"\nWill you visit again, soon?"
    mar "[dia]"
    mc "Of course."
    if Mary.isActive():
        scene 03_0923 with dissolve
        mar "Promise?"
        mc "I promise."
        scene 03_0924 with dissolve
        mar "[kiss]"
        scene 03_0925 with dissolve
        if Mary.Has("L0"):
            mar "Okay."
        else:
            mar h "I always get butterflies in my tummy when I kiss you."
            mar "I liked the {i}big{/i} kiss we had last night.\nCan we kiss like that before you leave?"
            mc "Sure."
            scene 03_0926 with dissolve
            mar "[ss]Mmhh."
            scene 03_0927 with dissolve
            mar "[ss]..Mmmmhhh..."
            if persistent.UseFocus and not EzModeActive:
                $ _skipping = False
                show screen imgMap("images/e03/03_0928.webp", 1053, 787, True, "Springhaven_AF20") with dissolve
                mar "[ss]..Mmhh.."
                $ _skipping = True
                if renpy.get_screen("imgMap"):
                    play sound "horn.mp3"
                    pause 1.0
                    scene 03_0928
                    hide screen imgMap
            else:
                scene 03_0928 with dissolve
                mar "[ss]..Mmhh.."
                call Springhaven_AF20
    scene 03_0934 with dissolve
    mc "Bye, Mary."
    mar "Bye."
    scene black with Fade(3, 2, 2)
    scene 03_0903a with dissolve
    mc "It's just a little further down this road."
    scene 03_0904a with dissolve
    mc "Perfect. Thank you."
    scene 03_0905a with dissolve
    mct "Quick shower before reporting in to Sue, I guess."
    jump Springhaven_UpdateSue
return

label Springhaven_SarahDropOff:
    $ curLOC=springhaven_id
    call CenterText ("Two hours later...")
    scene 03_0903b with dissolve
    mc "It's just a little further down this road."
    scene 03_0904b with dissolve
    mc "You know, you didn't have to bring me home, right?\nI could've walked from your place!"
    sar h "I wanted to see where you live!"
    scene 03_0905b with dissolve
    mc "Thanks, Sarah. I appreciate it."
    sar "You're welcome."
    sar "I'd better go, I'm running late... again!"
    mc "Okay."
    sar "Keep in touch!"
    scene 03_0906 with dissolve
    mct "Quick shower before reporting in to Sue, I guess."
    jump Springhaven_UpdateSue
return

label Springhaven_UpdateSue:
    scene 03_0935 with Fade(2,1,3)
    mc "Mornin', girls."
    scene 03_0936 with dissolve
    car "Morning, {b}Dad{/b}!"
    scene 03_0937 with dissolve
    mc "Uhh, Dad?\nI thought you wanted to keep it quiet for now?"
    car "Not from {i}these two{/i}! They've known for as long as I have!"
    scene 03_0938 with dissolve
    if Alex.isActive():
        alex "{i}Daddy{/i} sounds {b}so{/b} much hotter than Uncle [mc]![lol]"
    else:
        alex "We don't have any secrets between us!"
    scene 03_0939 with dissolve
    car "I tried to call you yesterday, but you didn't pick up."
    scene 03_0940 with dissolve
    mc "Ahh, yeah. Sorry.\nI forgot to grab my cell before I left for Lakeshore."
    mc "Is everything okay?"
    scene 03_0941 with dissolve
    car "Yeah.\nMom told me you were thinking about getting a car."
    car "So I wanted to let you know that Nicole's Mom is selling her truck, in case you wanted to take a look."
    mc "Oh, okay. Yeah, I'll take a look at it."
    scene 03_0942 with dissolve
    nic "There's nothing wrong with it."
    scene 03_0943 with dissolve
    nic "It's too powerful for her; she's scared to drive it![lol]"
    scene 03_0944 with dissolve
    car "We're just on our way to college, but Nic's staying with us tonight, so we can sort it out later."
    mc "Yeah, okay. Great."
    mc "You, err... still have sleepovers? [lol]"
    scene 03_0945 with dissolve
    car "Shut up.[lol]"
    scene 03_0946 with dissolve
    car "Nicole's mom is a nurse and works at the same hospital as Mom.\nNic {i}always{/i} stays here when her mom does the night shift."
    scene 03_0947 with dissolve
    car "C'mon guys, let's go."
    scene 03_0948 with dissolve
    car "See you later, Dad."
    mc "Bye, Pipsqueak."
    scene 03_0949 with dissolve
    car "[kiss]"
    scene 03_0948 with dissolve
    mc "I'm guessing your mom ain't home, for you to be calling me Dad. Heh."
    car "She left for work already."
    if persistent.Incest and Cara.isActive():
        scene 03_0950 with dissolve
        car "So it's safe to kiss me... if you'd like to."
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Kiss Cara":
                    $ tCh=True
                "Don't":
                    pass
        if tCh or Cara.Has("EZ"):
            scene 03_0952 with dissolve
            car "[ss]Mmhh.."
            $ Nicole.Score(1)
            if Alex.isActive():
                scene 03_0953 with dissolve
                alex "That is so fuckin' hot!"
                alex "Do I get one?"
                $ tCh=None
                if not EzModeActive:
                    menu:
                        "[wk_y]Kiss Alex":
                            $ tCh=True
                        "Don't":
                            scene 03_0954 with dissolve
                            mc "Sorry, but I don't think that would be appropriate! Heh."
                            alex h "Such a tease!"
                if tCh or Alex.Has("EZ"):
                    scene 03_0954 with dissolve
                    car "Kiss her, Dad.\nOtherwise, she'll be sulking all day."
                    scene 03_0956 with dissolve
                    alex "[ss]Mmhh.."
                    scene 03_0955 with dissolve
                    alex "[ss]..Mmmmhh.."
                    scene 03_0957 with dissolve
                    alex "I can't wait for us to fuck!"
                    car "ALEX!"
                    scene 03_0958 with dissolve
                    alex "Well, you can't do it![lol]"
                    car "[lol]"
                    scene 03_0959 with dissolve
                    pause 1.0
                    if not EzModeActive:
                        menu:
                            "Ask Nicole if she'd like a kiss":
                                $ Nicole.Score(-1)
                                scene 03_0960 with dissolve
                                nic "No, I don't!"
                            "[wk_y]Don't":
                                pass
        else:
            $ Cara.Add("NoFr")
            mc "I don't think we should in front of your friends."
            scene 03_0951 with dissolve
            car "Oh... Okay."
    elif Alex.isActive():
        scene 03_0954 with dissolve
        alex "Do I get a kiss goodbye?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Kiss Alex":
                    $ tCh=True
                "Don't":
                    pass
        if tCh or Alex.Has("EZ"):
            car "Kiss her, Dad.\nOtherwise, she'll be sulking all day."
            scene 03_0956 with dissolve
            alex "[ss]Mmhh.."
            scene 03_0955 with dissolve
            alex "[ss]..Mmmmhh.."
            scene 03_0957 with dissolve
            alex "I can't wait for us to fuck!"
            car "ALEX!"
            scene 03_0958 with dissolve
            alex "You know it's gonna happen eventually! [lol]"
            car "[lol]"
            scene 03_0959 with dissolve
            pause 1.0
            if not EzModeActive:
                menu:
                    "Ask Nicole if she's like a kiss":
                        $ Nicole.Score(-1)
                        scene 03_0960 with dissolve
                        nic "No, I don't!"
                    "[wk_y]Don't":
                        pass
        else:
            mc "Sorry, but I don't think that would be appropriate! Heh."
            alex "Such a tease!"

    scene 03_0961 with dissolve
    car "Bye."
    mc "Bye girls, have a good day."
    if Nicole.hasScore(3):
        scene 03_0961_01 with dissolve
        nic "[whi]Bye, [mc]."
        scene 03_0961_02 with dissolve
        pause 1.0
        scene 03_0961_03 with dis1
        pause 0.5
        scene 03_0961_04 with dis1
        pause 0.5
        scene 03_0961_05 with dissolve
        mc "[whi]Bye."
    scene 03_0962 with dissolve
    mct "Should let Sue know I'm back, and find out where she wants to meet."
    scene 03_0963 with dissolve
    mct "Ahh, shit."
    scene 03_0964 with dissolve
    show screen CellPhone("Lucy")
    msg_nvl "That's just great!\nYou were in the area, and NOT ONCE did you think about coming to see me!\nAt least I know where I stand with you!\nASSHOLE!"
    mc_nvl "I'm sorry, Sis!\nIt was a flying visit, I didn't have the time!"
    msg_nvl "Wow! He finally gets around to replying!"
    msg_nvl "You didn't have the time to visit your only sister?!\nWHO YOU HAVEN'T SEEN FOR... HOW MANY YEARS??!{image=/thumbs/cell/emoji/angry.png}"
    mc_nvl "You're right. I should've called in to see you."
    msg_nvl "Whatever."
    msg_nvl "I DO need to see you. I have something we need to talk about."
    mc_nvl "What is it?"
    msg_nvl "I'm not doing it over text!"
    msg_nvl "It's important. Come see me next time you visit your ex-wife."
    mc_nvl "Ahh, right. She told you I was there, of course."
    msg_nvl "She may not be my family anymore, but at least she still treats me like a sister!"
    mc_nvl "Jeez, Sis! I said I was sorry! What more do you want?!"
    msg_nvl "From you? NOTHING!"
    msg_nvl "You know what? I don't even care if you don't come to see me. Fuck you, Bro."
    call CloseCell ()
    scene 03_0965 with dissolve
    mct "Goddamnit."
    scene 03_0964 with dissolve
    pause 1.0
    show screen CellPhone("Sue")
    mc_nvl "I'm back."
    msg_nvl "I presume you completed your assignment, in which case, bravo on the prompt resolution."
    msg_nvl "The girl, is she okay?"
    mc_nvl "Yeah"
    msg_nvl "Good."
    msg_nvl "Report to me at my home. I'll send you the location."
    call CloseCell ()
    scene 03_0965 with dissolve
    mct "{b}The girl{/b}?... Think you mean your daughter, right?"
    scene black with Fade(3, 0, 0)
    jump Springhaven_SueHouse01
return

label Springhaven_SueHouse01:
    scene 03_0966 with Fade(0,2,2)
    pause 1.0
    play sound "car3.mp3"
    scene 03_0967 with dis1
    scene 03_0968 with dis1
    scene 03_0969 with dis1
    pause 0.5
    scene 03_0970 with dissolve
    mc "[whi]Damn!"
    mc "Is this the right place?"
    cabby "This is the address you gave me, Buddy."
    play sound "car.mp3" volume 0.5
    scene 03_0971 with fade
    pause 0.5
    scene 03_0972 with dis1
    pause 0.5
    play sound "doorbell.mp3"
    scene 03_0973 with dis1
    pause 1.0
    scene 03_0974 with dissolve
    mct "Crime doesn't pay? Yeah, if you say so!"
    $ Kiyomi_name="Maid"
    scene 03_0975 with dissolve
    pause 1.0
    scene 03_0976 with dissolve
    ki "You are [mc], yes?"
    mc "Yeah."
    scene 03_0977 with dissolve
    ki "In please. Miss expecting you."
    scene 03_0978 with dissolve
    mc "Thank you."
    scene 03_0979 with dissolve
    ki "Follow, please."
    scene 03_0980 with dissolve
    ki "He here, Miss."
    sue "Good. Show him in."
    scene 03_0981 with dissolve
    ki "Sit please."
    scene 03_0982 with dis1
    pause 0.5
    scene 03_0983 with dis1
    pause 0.5
    scene 03_0984 with dissolve
    sue "You're certain it was {b}her{/b} you saw?"
    mc "Without a doubt. It was her."
    if EzModeActive:
        call EzModeAsk ("Sue")
        if _return:
            $ Sue.Add("EZ")
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e03/03_0985.webp", 526, 360, True, "Springhaven_AF21") with dissolve
        sue "And no one discovered {i}why{/i} you were there?"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 03_0985
            hide screen imgMap
            mc "No. I was discreet."
            sue "Excellent."
    else:
        scene 03_0985 with dissolve
        sue "And no one discovered {i}why{/i} you were there?"
        call Springhaven_AF21
    scene 03_0987 with dissolve
    sue "How did she seem?"
    scene 03_0988 with dissolve
    mc "Okay, look - it's obvious that you're personally concerned for this girl, so I'll lay it out for you."
    mc "She was fine.\nShe was studying in the library."
    mc "She looked pretty much like any other student."
    scene 03_0989 with dissolve
    sue "{i}Pretty much{/i}?"
    sue "What do you mean by that?"
    scene 03_0990 with dissolve
    mc "There was a guy with her... Well, not {i}with{/i} her, but... he was watching over her."
    mc "He was guarding her, but he wasn't acting like her bodyguard."
    mc "I got the impression he was there for a different reason."
    scene 03_0991 with dissolve
    sue "Very astute of you."
    sue "I know to whom you're referring. His name is Harry."
    sue "He didn't see you, did he?"
    scene 03_0983 with dissolve
    mc "No."
    mc "If Melissa's in trouble, maybe I can help you."
    scene 03_0992 with dissolve
    sue "I don't recall giving you her name?"
    mc "You didn't have to. I'm good at what I do, {i}Ms. Robinson{/i}."
    scene 03_0993 with dissolve
    sue "Yes, you are.\nThat's why I wanted you to work for me."
    sue "But don't overstep, [mc].\nYou're heading into {b}dangerous{/b} territory."
    scene 03_0994 with dissolve
    sue "Whatever it is you {i}think{/i} you know, keep it to yourself.\nIf anything were to happen to... Melissa..."
    scene 03_0983 with dissolve
    mc "Understood."
    scene 03_0995 with dissolve
    sue "Never mention her name again."
    call SueReplay01_Part01
    jump Springhaven_UpdateAlysha
return

label Springhaven_UpdateAlysha:
    call CenterText ("Later in the day.")
    scene 03_1090 with fade
    pause 0.5
    scene 03_1091 with dis1
    mc "Thanks for coming."
    scene 03_1092 with dissolve
    aly "I wasn't expecting to hear from you again."
    if SentDocs:
        aly "And before you ask, no - I still haven't figured out what those plans you sent me are for, yet."
        aly "They're incomplete; there's not enough information in them."
        mc "Okay."
    scene 03_1093 with dissolve
    mc "I need you to do something for me."
    mc "Find out everything you can about a woman called Sue Robinson."
    scene 03_1094 with dissolve
    aly "Why?"
    aly "Who is she?"
    scene 03_1093 with dissolve
    mc "She's the boss, for this area at least."
    mc "So be careful. Don't mention her name to anyone you don't completely trust."
    scene 03_1095 with dissolve
    aly "That's {i}not{/i} how this is supposed to work."
    aly "You should be giving {b}me{/b} information, not the other way around!"
    scene 03_1093 with dissolve
    mc "I just did."
    mc "You didn't know who was running things in this town, now you do."
    scene 03_1096 with dissolve
    aly "Okay smart ass, why do you want this information?"
    scene 03_1093 with dissolve
    mc "She has a daughter, Melissa, who attends a college in Lakeshore."
    scene 03_1097 with dissolve
    mc "Something is going on with her, but I'm not sure what, yet."
    mc "Melissa's being guarded, but not by Sue."
    scene 03_1098 with dissolve
    mc "Sue's worried, frightened even."
    mc "We need to find out why."
    scene 03_1099 with dissolve
    aly "{i}We{/i}?"
    aly "You said you didn't want to get involved?"
    scene 03_1100 with dissolve
    mc "I think you were right about them not allowing me to walk away."
    mc "And if they get rid of me, Alison and Cara become loose ends that need to be tied up."
    aly "Okay. I'll find out everything I can."
    mc "Good."
    scene 03_1101 with dissolve
    aly "You not gonna visit your friend?"
    mc "Nope."
    scene 03_1102 with dissolve
    mc "I've got nothing left to say to him."
    jump Springhaven_MeetChristina
return

label Springhaven_MeetChristina:
    scene 03_1103 with Fade(5, 4, 4)
    pause
    scene 03_1104 with dissolve
    car "Dad, can you tell Nicole that you don't mind her staying here."
    scene 03_1105 with dissolve
    mc "Why would I mind??"
    car "She thinks it wasn't polite not to ask you if she could stay!"
    scene 03_1106 with dissolve
    mc "It has nothing to do with me! I'm a guest here, too! Heh."
    mc "But, Nicole, if it makes you feel any better... You're welcome here anytime!"
    nic "Thank you."
    scene 03_1107 with dissolve
    mc "So is it some kinda tradition, or something?"
    car "Yeah!"
    scene 03_1108 with dissolve
    car "When she was too young to stay home alone, we would always have a sleepover when her mom worked nights."
    car "It's just carried on ever since!"
    scene 03_1109 with dissolve
    mc "So... Where you gonna sleep??"
    scene 03_1110 with dissolve
    nic "Normally, I'd stay in your room."
    car "My bed's big enough for both of us."
    scene 03_1111 with dissolve
    mc "Ooh! Nice![lol]"
    scene 03_1112 with dissolve
    car "Oh jeez! Perv! [lol]"
    play sound "msg.mp3" volume 0.5
    pause 0.5
    scene 03_1113 with dissolve
    nic "My mom's outside."
    car "Why?"
    scene 03_1114 with dissolve
    nic "She's brought the truck for you to look at."
    mc "Oh, okay. Great."
    scene 03_1115 with fade2
    pause
    $ persistent.ChristinaLocked = False
    $ Christina_name=""
    scene 03_1116 with dissolve
    nic "Hi, Mom."
    cri "Hi, Sweetie."
    scene 03_1117 with dissolve
    nic "[mc], this is my mom, Christina.\nMom, this is [mc]."
    $ Christina_name="Christina"
    $ Christina.Activate()
    scene 03_1118 with dissolve
    mc "Hi."
    cri "Hello. I've heard a lot about you; It's nice to meet you finally!"
    scene 03_1119 with dissolve
    mc "Damn! This is a {b}nice{/b} truck!"
    cri "It's too much for me to handle! I've bought myself something smaller."
    scene 03_1120 with dissolve
    car "Come on, Nic. Leave them to it, let's go put our PJs on."
    nic "Okay."
    scene 03_1121 with dissolve
    nic "See you in the morning, Mom."
    cri "Yeah, bye girls."
    scene 03_1122 with dissolve
    mc "Before we go any further... It looks expensive."
    mc "What's the price tag?"
    cri "Oh, don't worry!"
    scene 03_1123 with dissolve
    cri "I just want rid of it, and Alison's a good friend of mine, so I'll give you a good deal!"
    cri "I'll leave it with you for a couple of days, take it somewhere for a long run. Get a feel for it."
    cri "And, if you're still interested, we can discuss a price later."
    scene 03_1124 with dissolve
    mc "Damn, can't argue with that!\nOkay, if you're sure, let's do it."
    cri "Great!"
    cri "Sorry, I'd love to stay and chat, but I need to go to work."
    scene 03_1125 with dissolve
    mc "Need a lift?"
    cri "Hah! No thanks."
    scene 03_1126 with dissolve
    cri "Keys are in the ignition.\nNicole will give you my number. Call me when you've made a decision."
    scene 03_1127 with dissolve
    cri "See you, [mc]!"
    mc "Bye. Thanks, Christina."
    mc "[whi]Sweet!"
    scene 03_1128 with Fade(2, 3, 2)
    pause
    scene 03_1129 with dissolve
    if Alison.isSexual():
        ali "[mc]..."
        ali "Do you think Cara knows?"
        scene 03_1130 with dissolve
        mc "Umm... knows what??"
        ali "About us!"
        mc "I, err.. don't think so."
        scene 03_1131 with dissolve
        ali "As much as I want you in my bed tonight, we'd better stick to our own."
        ali "They'll probably stay up 'till late, and hear us sneaking around."
        mc "Heh. Yeah, okay."
    else:
        ali "How was your trip to Lakeshore?"
        scene 03_1130 with dissolve
        mc "Great. It's nice to be home, though."
        scene 03_1131 with dissolve
        ali "Good.\nI'm glad you think of {i}here{/i} as your home!"
    scene 03_1132 with dissolve
    car "Hi Mom!\nHow was work?"
    ali "Exhausting."
    scene 03_1133 with dissolve
    car "Did you see Uncle [mc]'s new truck in the driveway?"
    ali "Uncle [mc]'s?"
    scene 03_1134 with dissolve
    ali "Oh! You bought it?"
    mc "No![lol]"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        $ a=True
        if not Alison.isSexual():
            $ a=False
        show screen imgMap("images/e03/03_1135.webp", 635, 540, a, "Springhaven_AF22") with dissolve
        mc "She wants me to test drive it for a couple of days before I decide."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 03_1135
            hide screen imgMap 
    else:
        scene 03_1135 with dissolve
        mc "She wants me to test drive it for a couple of days before I decide."
    scene 03_1142 with dissolve
    car "You are {i}going{/i} to buy it, right?"
    scene 03_1143 with dissolve
    mc "I'm not sure yet!"
    mc "It's a {i}nice{/i} truck, though! So, probably, yeah. [lol]"
    scene 03_1144 with dissolve
    car "Think about all the adventures we can have!"
    mc "Exactly!"
    mc "In fact, I was thinking maybe we can have one tomorrow?"
    mc "Nics' mom said I should give it a long run, so I figure we could drive down to Oakhill and visit Millie."
    scene 03_1145 with dissolve
    ali "Oh, sorry [mc]. I have work tomorrow."
    car "I can't do tomorrow either."
    car "I've got class in the morning and I've already booked a tanning bed in the afternoon!"
    scene 03_1146 with dissolve
    mc "Damn, Cara!\nAren't you tanned enough? Those things are dangerous, aren't they?"
    scene 03_1147 with dissolve
    car "Shut up![lol]"
    scene 03_1148 with dissolve
    car "You ain't my Dad, you can't tell me what to do!"
    scene 03_1149 with dissolve
    pause
    if persistent.Incest and Cara.isActive():
        scene 03_1150 with dissolve
        mc "You're lucky I'm not!"
        mc "I'd have to put you over my knee and spank you for being cheeky![lol]"
        scene 03_1151 with dissolve
        car "Oh!\nNow I wish you {i}were{/i} my daddy!"
    scene 03_1152 with dissolve
    ali "Err, can we just watch TV, please?!"
    car "[lol]"
    scene 03_1153 with dissolve
    ali "We can't make it, but {b}you{/b} should still go tomorrow!"
    mc "Yeah, I will.\nMight even go and try to give Nettie the apology I owe her."
    scene 03_1154 with dissolve
    ali "Yes! That's a good idea.\nThe longer you leave it, the tougher it'll get."
    scene 03_1155 with dissolve
    pause
    if not persistent.Incest or not Cara.isActive():
        call CenterText ("Later that night...")
        jump Springhaven_HeadingOut
    scene 03_1156 with fade1
    pause 1.0
    scene 03_1157 with dissolve
    pause 1.0
    scene 03_1158 with dissolve
    car "I'm gonna sit by Uncle [mc]. My neck hurts trying to watch from here."
    nic "Okay."
    scene 03_1159 with dissolve
    car "Mind if I sit here?"
    mc "'course not!"
    scene 03_1160 with dissolve
    pause
    call Springhaven_CarasGame
    jump Springhaven_HeadingOut
return

label Springhaven_CarasGame:
    scene 03_1161 with fade1
    mct "Is she leaning on my dick on purpose?"
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Two can play at this game":
                $ tCh=True
            "Don't do anything":
                pass
    elif Cara.Has("EZ"):
        $ tCh=True
    if not tCh:
        scene 03_1162 with dissolve
        mct "Nah, she probably doesn't even realize."
        call CenterText ("Later that night...")
        return
    scene 03_1163 with dissolve
    pause
    scene 03_1164 with dissolve
    pause
    if not Cara.Has("L2"):
        return
    scene 03_1165 with dis1
    mct "What the hell is she doing?\nHer mom's right there!!"
    scene 03_1166 with dissolve
    pause 1.0
    scene 03_1167 with dissolve
    mct "She wants to play?\nHeh, okay. Let's play."
    scene 03_1168 with dis1
    pause 0.5
    scene 03_1169 with dis1
    pause 0.5
    scene 03_1170 with dissolve
    pause 0.5
    scene 03_1171 with dissolve
    pause 0.5
    scene 03_1172 with dissolve
    pause
    scene 03_1173 with dissolve
    pause 0.5
    scene 03_1174 with dissolve
    pause 0.5
    scene 03_1175 with dissolve
    mct "NOPE!"
    scene 03_1176 with dissolve
    mc "Man, am I tired!\nThink I'm gonna call it a night. Heh."
    ali "Jeez, you {i}really are{/i} getting old![lol]"
    scene 03_1177 with dissolve
    mc "Night, everyone!"
    car "Night, Uncle [mc].[giggles]"
return

label Springhaven_HeadingOut:
    scene 03_1178 with Fade(2, 2, 1)
    pause 1.0
    show screen CellPhone("Violet")
    mc_nvl "Hi Vi."
    mc_nvl "Is it okay to come down and see Millie tomorrow?"
    msg_nvl "Hi [mc]! Yeah, of course you can!"
    msg_nvl "Would you like to stay over again?"
    msg_nvl "Actually, CAN you stay over?\nWe need to talk, how about I book us a table somewhere?"
    mc_nvl "Talk? Is everything okay?"
    msg_nvl "Yeah! Sorry, it's nothing to worry about! Didn't mean to scare you lol."
    mc_nvl "Okay, yeah, I can stay for the night."
    msg_nvl "Great. See you tomorrow then! x"
    call CloseCell ()
    scene black with Fade(4, 2, 2)
    call CenterText ("The next day")
    scene 04_0001 with fade
    mct "Yeah, the more I see this truck, the more I want it!"
    scene 04_0002 with dissolve
    mct "If it rides as good as it looks, it's mine! Heh."
    $ oakhill_open=True
    jump Springhaven_Leave
return

label Springhaven_Start3:
    if cedargrove_ch==2:
        $ curLOC=cedargrove_ch
        $ springhaven_open=False
        jump CedarGrove_Start2
    if Plr.Has("GotPackage"):
        call Springhaven_DeliverMiyuka
    scene 05_0212 with Fade(0, 2, 2)
    pause 1.0
    scene 05_0213 with fade
    mct "Need coffee!"
    scene 05_0214 with dissolve
    car "Dad! I didn't know you were home."
    scene 05_0215 with dissolve
    mc "Hi, Pipsqueak! I just got back a few minutes ago."
    mc "Your mom not home?"
    car "No, still at work."
    scene 05_0216 with dissolve
    car "It's good that we're alone.\nI wanted to ask you something."
    mc "Okay."
    scene 05_0217 with dissolve
    car "I want to tell Millie that we're sisters.\nAre you cool with that?"
    scene 05_0218 with dissolve
    car "I'd {i}really{/i} like her to know! She'll love it!"
    scene 05_0219 with dissolve
    mc "No, you can't tell her!"
    car "Huh? Why not??"
    scene 05_0220 with dissolve
    car "Are you... ashamed of me??"
    scene 05_0221 with dissolve
    mc "Oh, Sweetheart, {b}no{/b}, of course not!\nI'm proud to be your father."
    mc "I want Millie to know, too!"
    scene 05_0222 with dissolve
    mc "I want {i}everyone{/i} to know, Pipsqueak!"
    mc "It's just... We need to go about it in the right way."
    scene 05_0223 with dissolve
    mc "My relationship with Millie and Violet is great right now."
    scene 05_0224 with dissolve
    mc "But it's still delicate, and I'm worried I'll fuck it up again."
    scene 05_0225 with dissolve
    mc "I promise you, we'll tell them, but the time has to be right."
    car "Okay."
    scene 05_0226 with dissolve
    mc "And I know you're excited to tell her, but I think it'd be better coming from me."
    mc "If she hears it from you, they might think I'm trying to keep it a secret from them."
    car "Yeah, I suppose."
    scene 05_0227 with dissolve
    mc "But, you know..."
    mc "We shouldn't tell {i}anyone else{/i} until you've told your mom."
    scene 05_0228 with dissolve
    mc "She {b}has{/b} to be told, Cara."
    scene 05_0229 with dissolve
    car "Yes, I know!\nI'm gonna talk to her!"
    scene 05_0230 with dissolve
    car "Like you, I'm just waiting for the right time![lol]"
    scene 05_0231 with dissolve
    mc "Do you {i}really{/i} think Millie will be happy when she finds out?"
    scene 05_0232 with dissolve
    car "Hell yeah!"
    scene 05_0233 with dissolve
    car "Remember when you and Pete would be home on leave, and you'd take us out for the day?"
    car "Just the four of us.\nWe'd go to the beach, or the fairground, or... Jeez, you took us to lots of places!"
    car "Millie would always ask if we could pretend to be sisters for the day."
    scene 05_0234 with dissolve
    car "Every single time!\nWe loved being sisters!"
    car "Even now, when we message each other, we both sign off with {i}Love you, Sis{/i}."
    scene 05_0235 with dissolve
    car "Don't worry, Dad. I {b}know{/b} she'll be happy."
    scene 05_0236 with dissolve
    mc "I hope you're right.\nIt'll be easier to tell Violet if I have Millie on my side."
    mc "If Vi sees that Millie's okay with it, she shouldn't have a reason to be upset about it either."
    scene 05_0237 with dissolve
    car "[lol] Oh, Daddy!"
    scene 05_0238 with dissolve
    car "You don't know women very well, do you?"
    scene 05_0239 with dissolve
    pause 0.5
    scene 05_0240 with dissolve
    mc "Okay, I'm gonna jump in the shower real quick, before heading out for a while."
    car "Okay."
    scene 05_0241 with dissolve
    if persistent.Incest and Cara.isActive():
        car "Oh, Dad, hold on a sec!"
        scene 05_0242 with dissolve
        car "I'd like to get your opinion on something."
        mc "Uh, okay.\nCan it wait till I'm out of the shower?"
        scene 05_0243 with dissolve
        car "It'll only take a minute!"
        car "It's in my bedroom.\nHead to the bathroom, I'll meet you there."
        call CaraReplay03
        $ Cara.L=3
    else:
        car "Thanks, Dad. Love you."
        mc "Love you, too, Pipsqueak."
    jump Springhaven_MeetWithAlysha
return

label Springhaven_MeetWithAlysha:
    scene 05_0338 with Fade(0,0,2)
    pause 1.0
    show screen CellPhone("Alysha")
    mc_nvl "Hey. Find anything out?"
    msg_nvl "Hi.\nYes, a little."
    mc_nvl "Can we meet?"
    msg_nvl "I'm not at work today."
    mc_nvl "So??"
    msg_nvl "Okay"
    msg_nvl "Usual place?"
    mc_nvl "No. Too risky to keep meeting in the same spot."
    mc_nvl "Since you're not in uniform, meet me at Rosie's cafe."
    msg_nvl "Okay. I can be there in 30 minutes."
    mc_nvl "Great."
    call CloseCell ()
    scene 05_0339 with dissolve
    pause
    scene 05_0340 with Fade(2,2,2)
    pause
    scene 05_0341 with dissolve
    mct "Hmm, guess I'm a little early."
    scene 05_0342 with dissolve
    gab "What are you doing here?? We're not due yet!?"
    scene 05_0343 with dissolve
    mc "Relax!\nI'm here as a customer, nothing more."
    scene 05_0344 with dissolve
    gab "Oh, uhh... sorry.\nWhat can I get you?"
    mc "Coffee."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e05/05_0345.webp", 1123, 505, True, "Springhaven_AF25") with dissolve
        mc "Is your sister around?"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 05_0345
            hide screen imgMap
            scene 05_0347 with dissolve
            gab "Why?"
            if Melanie.Has("TookBJ"):
                gab "Hoping for another blowjob?"
                mc "What? NO!"
    else:
        scene 05_0345 with dissolve
        mc "Is your sister around?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    $ tCh=True
                "Don't":
                    pass
        elif Gabby.Has("EZ"):
            $ tCh=True
        if tCh:
            call Springhaven_AF25
        else:
            scene 05_0347 with dissolve
            gab "Why?"
            if Melanie.Has("TookBJ"):
                gab "Hoping for another blowjob?"
                mc "What? NO!"
    scene 05_0349 with dissolve
    if helpedMel:
        mc "I wanted to let her know that I've managed to get her payments reduced."
        gab "Are you serious??"
        scene 05_0350 with dissolve
        gab "Why would {i}you{/i} do that??"
        mc "I told your sister I'd try to help if I could."
        scene 05_0351 with dissolve
        gab "Why do you want to help us?\nWhat's in it for you?"
        mc "Can't a guy just help?"
    else:
        mc "No reason, just wanted to say hi."
        scene 05_0350 with dissolve
        gab "You think you're her friend now?"
        scene 05_0351 with dissolve
        mc "Jeez! Forget I asked."
    scene 05_0352 with dissolve
    aly "Hey."
    mc "Oh, hey.\nCoffee?"
    aly "Sure."
    if EzModeActive:
        call EzModeAsk ("Alysha")
        if _return:
            $ Alysha.Add("EZ")
    scene 05_0353 with Fade(1, 0.5, 1)
    aly "I thought I'd have more time. It's only been a few days."
    mc "It's fine. Tell me what you've got so far."
    scene 05_0354 with dissolve
    aly "Like I said... not much."
    aly "She's an only child, born into money. Parents died in an accident back in 2005."
    scene 05_0355 with dissolve
    aly "She got married in 2010, had one kid."
    aly "Always active in the community, donated to charities. Looked good on the surface."
    scene 05_0356 with dissolve
    aly "In 2011, she and her husband set up a loan company.\nIt worked more like a community fund - small loans to locals, very low interest."
    aly "Their goal was to help people start businesses, lift up the community."
    scene 05_0353 with dissolve
    mc "That almost sounds... noble."
    aly "Maybe at first."
    scene 05_0357 with dissolve
    aly "Four years ago, her husband was killed in a carjacking.\nSoon after, things change."
    scene 05_0358 with dissolve
    aly "Complaints start coming in. Higher interest rates, threats, intimidation."
    aly "Reports were filed, then suddenly withdrawn.\nEvery single one."
    aly "After that, she just drops off the radar."
    scene 05_0359 with dissolve
    mc "Her husband was killed in a carjacking?"
    aly "Yeah. It's unusual, but it happens."
    scene 05_0360 with dissolve
    aly "I pulled the file, seems no {i}real{/i} investigation was ever done."
    aly "It was quickly swept under the rug."
    aly "I'm guessing the husband was the real target.\nMade it look like a carjacking gone wrong to cover it up."
    mc "Damn."
    scene 05_0361 with dissolve
    aly "Psycho bitch didn't want to divorce him, so she had him killed?"
    scene 05_0362 with dissolve
    mc "That's quite the leap."
    scene 05_0363 with dissolve
    aly "Divorces can be messy!\nFighting over assets, custody of their kid?"
    mc "Or, it really was just a carjacking gone wrong."
    mc "Keep digging."
    aly "Yeah."
    if MiyukaDelivered or MiyukaEscaped:
        scene 05_0364 with dissolve
        mc "There's something else..."
        mc "I was ordered to pick something up from Brookvale."
        scene 05_0365 with dissolve
        mc "The {i}thing{/i} I had to collect was actually a person.\nA young asian woman."
        mc "She was a mess.\nThey'd kept her locked up in a damn cage!"
        scene 05_0366 with dissolve
        if MiyukaDelivered:
            mc "I had to deliver her to Sue's home."
            mc "Sue has a maid, Kiyomi."
            mc "Turns out this pick-up is Kiyomi's sister."
            mc "Kiyomi told me Sue is punishing their mother, forcing her to do something."
            scene 05_0367 with dissolve
            aly "Forcing her to do what??"
            mc "She didn't know."
            scene 05_0368 with dissolve
            aly "Jesus, [mc]!\nThis is serious! Kidnapping? Blackmail?"
            aly "I need to report this!"
            scene 05_0369 with dissolve
            mc "Are you crazy?!\nYou can't tell {b}anyone{/b} yet!"
            aly "You expect me to risk my career over this??"
            mc "Your {i}career{/i}??\nI'm risking my fuckin' {b}life{/b} over this, Alysha!"
            scene 05_0370 with dissolve
            mc "You blow this open too soon... you're killing me and my family!"
            mc "You're the one who asked {i}me{/i} for help, remember?!"
            scene 05_0371 with dissolve
            aly "Fuck! Okay!"
            aly "... You're right, I'm sorry. I just panicked for a minute.\nThis is some deep shit we're wading through here!"
            scene 05_0372 with dissolve
            aly "I should probably get outta here.\nWe shouldn't be seen together for too long."
            mc "Yeah."
            scene 05_0373 with dissolve
            aly "Thanks for the coffee."
            mc "Anytime."
        else:
            mc "But there's a problem... She managed to get away from me."
            mc "I looked everywhere, but she was gone."
            scene 05_0368 with dissolve
            aly "Fuck, [mc]!"
            scene 05_0369 with dissolve
            mc "Now I gotta go and tell Sue that I fucked up."
            mc "If you don't hear from me in twenty-four hours, I need you to take Alison and Cara far away from here."
            scene 05_0371 with dissolve
            aly "Shit!!\nOkay, I give you my word."
            scene 05_0370 with dissolve
            aly "I fuckin' told you it was a bad idea to work for them!!"
            mc "Yeah, I know."
            scene 05_0372 with dissolve
            mc "Yoy should probably get outta here.\nWe shouldn't be seen together for too long."
            aly "Yeah, okay."
            scene 05_0373 with dissolve
            aly "Fuck, [mc], I {i}really{/i} hope I hear from you by tomorrow."
            mc "Me too."
    else:
        scene 05_0367 with dissolve
        aly "Do you think any of this helps?"
        scene 05_0366 with dissolve
        mc "I don't know. It's better than no information, though."
        scene 05_0368 with dissolve
        aly "So what's next?"
        scene 05_0370 with dissolve
        mc "I'm on my way to report in to her.\nApparently, we need to discuss my attitude problem, heh."
        scene 05_0371 with dissolve
        aly "You like to make life tough for yourself, don't you?"
        scene 05_0364 with dissolve
        mc "Fuck 'em!\nCrazy bitch probably just wants to put me over he knee and spank me.[lol]"
        scene 05_0363 with dissolve
        aly "This isn't a joke, [mc]!\nThese are serious fuckin' people!"
        mc "Don't worry, I'll be fine."
        mc "Yoy should probably get outta here.\nWe shouldn't be seen together for too long."
        aly "Yeah, okay."
        scene 05_0373 with dissolve
        aly "Thanks for the coffee."
        mc "Anytime."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e05/05_0374.webp", 561, 502, True, "Springhaven_AF26") with dissolve
        pause
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 05_0374
            hide screen imgMap
    else:
        scene 05_0374 with dissolve
        pause 1.0
        if not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    call Springhaven_AF26
                "Don't":
                    pass
        elif Alysha.Has("EZ"):
            call Springhaven_AF26
    scene 05_0377 with dissolve
    pause 
    scene 05_0378 with dissolve
    if helpedMel or Melanie.hasScore(5):
        mel "[mc]! What are you doing here?"
    else:
        mel "Why are {b}you{/b} here?? Our payment isn't due yet!"
    gab "It's okay, Mel.\nHe's here as a customer."
    if helpedMel:
        scene 05_0379 with dissolve
        gab "He told me our payments have been reduced."
        scene 05_0380 with dissolve
        mel "So it's true??\nI received an email with revised repayments, but I thought it was a mistake!"
        scene 05_0381 with dissolve
        mc "Seems the other guys collecting from you wanted their own cut."
        mc "They increased your payments and pocketed it for themselves."
        mel "Bastards!"
        scene 05_0383 with dissolve
        mel "Gabby, can you give us a minute, please?"
        gab "Uh, yeah..."
        scene 05_0384 with dissolve
        mel "I owe you an apology."
        mc "Why?"
        mel "When you said you'd try to help us, I didn't believe you.\nI thought you were being cruel, playing with me."
        scene 05_0385 with dissolve
        mc "Can't really blame you.\nYou've not been treated well, and you don't know me."
        mel "Thank you, [mc]. I mean it."
        mc "No problem."
        scene 05_0384 with dissolve
        if Melanie.isSexual():
            mel "Do I, uhh... owe you {i}anything{/i}?"
            mc "Owe me??"
            mel "That was the deal, wasn't it? We help each other."
            mc "Oh, that's right! Heh."
            $ tCh=None
            if not EzModeActive:
                menu:
                    "No, not this time.":
                        scene 05_0386 with dissolve
                        pass
                    "[wk_y]Wouldn't say no to another blowjob!":
                        $ tCh=True
            elif Melanie.Has("EZ"):
                $ tCh=True
            if tCh:
                mc "Well... I {i}did{/i} enjoy it last time."
                scene 05_0386 with dissolve
                mel h "Yeah?"
                mel "Follow me."
                scene 05_0387 with dissolve
                mel "I need to show [mc] something, won't be long."
                gab "More paperwork?[lol]"
                mel "Umm... yeah."
                call MelanieReplay02
                scene 05_0453 with fade1
                mc "Mel will be out in a minute."
                scene 05_0454 with dissolve
                gab "Is my sister sucking you off going to be a regular thing?"
                scene 05_0455 with dissolve
                if Gabby.Has("Watch"):
                    mc "Maybe.\nYou gonna keep spying?"
                    scene 05_0456 with dissolve
                    gab "Yeah. I like watching."
                    mc "You were doing a little more than watching this time!"
                    scene 05_0457 with dissolve
                    gab "So?\nI was turned on."
                    scene 05_0455 with dissolve
                    mc "Watching your sister suck dick turns you on?"
                    scene 05_0458 with dissolve
                    gab "Maybe."
                    mc "Then {i}maybe{/i} next time you should come in and get a closer look."
                    gab "[lol]"
                    scene 05_0459 with dissolve
                    gab "I'm sure {b}you'd{/b} love that!\nMel... not so much!"
                    scene 05_0460 with dissolve
                    mc "Can't blame a guy for trying! Heh."
                    mc "See ya, Gabby."
                    gab "Bye."
                else:
                    mc "We were looking at some paperwork!"
                    scene 05_0457 with dissolve
                    gab "Yeah, if you say so.[lol]"
                    scene 05_0460 with dissolve
                    mc "[lol] See ya, Gabby."
                    gab "Bye."
            else:
                $ Melanie.Score(5)
                mel "Oh, okay."
                mel "I really appreciate your help. It means the world to me."
                mel "I'd better get back to work.\nHave to make sure I'll have your next payment ready in full!"
                mc "Okay."
        else:
            mel "I'd better get back to work.\nHave to make sure I'll have your payment ready in full!"
            mc "Okay."
    else:
        scene 05_0380 with dissolve
        if Melanie.hasScore(5):
            mel "Oh, sorry."
            scene 05_0381 with dissolve
            mc "It's okay, I'm just leaving anyway."
            scene 05_0382 with dissolve
            mel "Everything okay here?"
            gab "Yeah."
        else:
            mel "Oh.\nIf we weren't so desperate for cash, you wouldn't be welcome here."
            scene 05_0381 with dissolve
            mc "Don't worry, I'm just leaving."
            mel "Good."
            scene 05_0382 with dissolve
            mel "Are you okay?"
            gab "Yeah. Everything's fine. Stop worrying."
    scene 05_0461 with fade1
    scene black with Fade(4, 2, 1)
    jump Springhaven_ReportToSue
return

label Springhaven_DeliverMiyuka:
    $ Plr.Del("GotPackage")
    $ MiyukaDelivered=True
    $ MiyukaSpringhaven=True
    scene 05_0193 with Fade(2, 2, 1)
    play sound "car3.mp3"
    scene 05_0194 with dis1
    scene 05_0195 with dis1
    scene 05_0196 with dis1
    $ aa=""
    if Miyuka.Has("Food"):
        $ aa="a"
    show expression "05_0197" + aa with dissolve
    mc "We're here."
    mc "This is my boss's house. It's where I was told to bring you."
    show expression "05_0198" + aa with dissolve
    pause
    play sound "doorbell.mp3"
    show expression "05_0199" + aa with dissolve
    pause
    show expression "05_0200" + aa with dis1
    show expression "05_0201" + aa with dis1
    show expression "05_0202" + aa with dissolve
    ki "MIYUKA!!"
    $ Miyuka_name="Miyuka"
    show expression "05_0203" + aa with dissolve
    mc "You know her?"
    show expression "05_0204" + aa with dissolve
    ki "She's my sister."
    show expression "05_0205" + aa with dissolve
    ki "Did they hurt you?"
    show expression "05_0206" + aa with dissolve
    ki "Did {b}you{/b} hurt her??"
    mc "No!"
    if Miyuka.Has("Food"):
        mi "No, he was kind."
    mc "What the hell is going on?"
    show expression "05_0207" + aa with dissolve
    ki "They're punishing our mother."
    mc "Your mom?? Why?"
    show expression "05_0208" + aa with dissolve
    ki "Because she refused to do what they wanted.\nThey're making sure she obeys."
    mc "What do they want her to do?"
    ki "I.. I don't know."
    ki "You need to leave now."
    if persistent.KiyomiLocked:
        $ persistent.KiyomiLocked=False
        show expression "05_0209" + aa with dissolve
        mc "Okay, I'll leave... But first, I gotta ask..."
        mc "Weren't you speaking broken English the last time I was here??"
        ki "She {i}demands{/i} I talk that way at all times, especially in front of guests."
        show expression "05_0210" + aa with dissolve
        ki "She's a crazy bitch!"
        ki "I'm from Northcrest! I speak English perfectly well."
        ki "Now, please leave. I need to attend to my sister."
    show expression "05_0211" + aa with Fade(1, 0.5, 1)
    scene black with Fade(4, 1, 0)
return

label Springhaven_ReportToSue:
    scene 05_0462 with fade1
    pause 1.0
    scene 05_0463 with fade1
    mct "Sue insisted I not take my cell with me to Lakeshore."
    mct "She didn't want anyone else knowing I was there."
    scene 05_0464 with dissolve
    mct "Who else is tracking my phone besides her and her dog?"
    mct "Unless..."
    scene 05_0465 with dissolve
    mct "... He isn't HER dog?"
    scene 05_0466 with dissolve
    sue "[whi]Send him in."
    scene 05_0467 with dissolve
    jam "In."
    scene 05_0468 with fade
    sue "I never normally doubt a decision I've made."
    sue "But {b}you{/b} have me questioning my judgment."
    scene 05_0469 with dissolve
    sue "We came to a mutually beneficial arrangement."
    sue "You're supposed to be working {b}for{/b} me.\nYet, I feel you're consistently working {b}against{/b} me."
    if MiyukaDelivered or MiyukaEscaped:
        jump Springhaven_SueConvoMiyaki
    scene 05_0470 with dissolve
    sue "Your attitude is becoming a problem."
    sue "Brookvale. You ignored a direct order."
    sue "Why?"
    scene 05_0471 with dissolve
    mc "Sorry, I didn't have time to go!\nI had to get back."
    mc "I figured if it were important, you would've sent your dog."
    play sound "hit02.mp3"
    scene 05_0472 with vpunch
    mc "NNNGGGHHH!"
    scene 05_0473 with vpunch
    mc "...Arrggghh..."
    scene 05_0474 with dissolve
    sue "{b}Every{/b} order I give is important."
    sue "James would like nothing more than to take you somewhere and put a bullet in the back of your head."
    scene 05_0475 with dissolve
    sue "I'm {i}almost{/i} inclined to agree with him..."
    scene 05_0476 with fade
    sue "... but I'm not prepared to give up on you quite yet."
    if helpedMel:
        scene 05_0477 with Fade(0.5, 0.5, 1.0)
        sue "There's something I'd like you to see first."
        scene black with Fade(1.0, 0.5, 0)
        sue "[whi]It may help you see the error of your ways."
        jump Springhaven_Assholes
    else:
        scene 05_0477 with Fade(0.5, 0.5, 1.0)
        sue "You must understand - I'm your superior. You {b}will{/b} respect me."
        scene 05_0501 with dissolve
        sue "Thank you, James."
        scene 05_0502 with dissolve
        call Emotion (mc, "Coughing")
        scene 05_0503 with dissolve
        sue "That's all."
        scene 05_0504 with fade
        sue "I hope, for your sake, it's a lesson learned."
        scene 05_0505 with dissolve
        sue "You may leave."
        sue "I will be in touch."
        scene 05_0500 with fade
        jam "See you soon, soldier boy."
        mc "Lookin' forward to it."
        jump Springhaven_AnEveningAtHome
return

label Springhaven_SueConvoMiyaki:
    scene 05_0470 with dissolve
    if MiyukaEscaped:
        sue "You're supposed to deliver the girl to my house, but Kiyomi informs me you haven't yet visited."
        sue "Where is she?"
        scene 05_0471 with dissolve
        mc "I'm sorry, Sue, but I... don't know.\nI turned my back for a minute, and she ran!"
        mc "She just vanished! I looked everywhere for her, I swear!"
        play sound "hit02.mp3"
        scene 05_0472 with vpunch
        mc "NNNGGGHHH!"
        scene 05_0473 with vpunch
        mc "...Arrggghh..."
        scene 05_0474 with dissolve
        sue "Am I really to believe you're that incompetent?"
        scene 05_0475 with dissolve
        sue "Who do you work for?"
        scene 05_0476 with fade
        sue "I {b}will{/b} find out."
        scene 05_0477 with Fade(0.5, 0.5, 1.0)
        sue "The girl belongs to us. We want her back."
        scene black with Fade(1.0, 0.5, 0)
        sue "[whi]Your life depends on it."
        jump Springhaven_InTrouble
    else:
        sue "I don't like your attitude."
        scene 05_0471 with dissolve
        mc "Being nice wasn't a part of the job description!"
        mc "What's the problem?\nI've followed your orders and done everything asked of me!"
        if Plr.Has("Mat_Hit"):
            scene 05_0478 with dissolve
            sue "Remind me... When did I give the order to assault {i}another{/i} one of our employees?"
            scene 05_0479 with dissolve
            mc "The guy was being a dick!"
            mc "And you didn't order me {i}not{/i} to hit him!"
            scene 05_0480 with dissolve
            sue "You think yourself amusing; You're mistaken."
        scene 05_0481 with dissolve
        sue "That's all, James."
        scene 05_0482 with dissolve
        mc "[whi]Good little puppy!"
        jam "Keep it up.\nWhen the order comes to kill you, I'm gonna do it for free."
        scene 05_0483 with fade
        sue "Why do you insist on provoking him?"
        mc "It's fun."
        sue "You lie."
        scene 05_0484 with dissolve
        mc "Survival."
        mc "When the day comes for him to take me out..."
        mc "He won't be professional. It'll be personal."
        mc "And when things become personal, people make mistakes, they can become sloppy."
        scene 05_0485 with dissolve
        sue "You underestimate him."
        sue "This game you play... you can't win."
        mc "Neither can you."
        scene 05_0486 with dissolve
        sue "I {b}always{/b} win."
        scene 05_0487 with dissolve
        mc "But at what cost?"
        scene 05_0488 with dissolve
        sue "Elaborate."
        scene 05_0489 with dissolve
        mc "Okay..."
        menu:
            "Mention her husband":
                $ Plr.Add("Sue_MH")
                mc "Your husband being killed wasn't too high a price?"
                scene 05_0490 with dissolve
                sue "{b}How dare you{/b}!!"
                scene 05_0491 with dissolve
                sue "{b}JAMES!!"
                play sound "hit02.mp3"
                scene 05_0472 with vpunch
                mc "NNNGGGHHH!"
                scene 05_0473 with vpunch
                mc "...Arrggghh..."
                scene 05_0474 with dissolve
                sue "You need to learn your place."
                if helpedMel:
                    scene 05_0476 with fade
                    sue "There's something I'd like you to see."
                    scene 05_0477 with Fade(0.5, 0.5, 1.0)
                    sue "It may help adjust your attitude."
                    scene black with Fade(1.0, 0.5, 0)
                    pause 0.5
                    jump Springhaven_Assholes
                else:
                    scene 05_0476 with fade
                    sue "I refuse to tolerate your attitude a moment longer."
                    scene 05_0477 with Fade(0.5, 0.5, 1.0)
                    sue "I'm your superior. You {b}will{/b} respect me."
                    scene 05_0501 with dissolve
                    sue "Thank you, James."
                    scene 05_0502 with dissolve
                    call Emotion (mc, "Coughing")
                    scene 05_0503 with dissolve
                    sue "That's all."
                    scene 05_0504 with fade
                    sue "I hope, for your sake, it's a lesson learned."
                    scene 05_0505 with dissolve
                    sue "You may leave."
                    sue "I will be in touch."
                    scene 05_0506 with fade
                    jam "See you soon, soldier boy."
            "[wk_y]Mention her daughter":
                $ Plr.Add("Sue_MD")
                mc "Your daughter's freedom isn't too high a price?"
                scene 05_0490 with dissolve
                sue "{b}How dare you{/b}!!"
                scene 05_0492 with dissolve
                sue "I should order James to dispose of you right now!"
                scene 05_0493 with dissolve
                mc "Go ahead! Call him in!"
                mc "I can tell him all about my Lakeshore trip."
                scene 05_0494 with dissolve
                sue "It was foolish of me to put my trust in you!"
                mc "You {b}can{/b} trust me, Sue..."
                mc "But trust is a two-way street!\nI need to be able to trust {i}you{/i}, too!"
                scene 05_0495 with dissolve
                call Emotion (sue, "Breathing deeply", "I don't like this.")
                sue "You're causing me stress."
                scene 05_0496 with dissolve
                sue "I should return home. I need to relax."
                scene 05_0497 with dissolve
                sue "But... what to do about you?"
                scene 05_0498 with dissolve
                sue "Don't make me regret this."
                sue "Leave."
                scene 05_0499 with dissolve
                sue "I will be in touch."
                mc "Okay."
                scene 05_0500 with fade
                call Emotion (mc, "Bark", "Good boy!")
    jump Springhaven_AnEveningAtHome
return

label Springhaven_Assholes:
    pause 4.0
    $ Plr.Add("SawAH")
    "[whi]Asshole! Wake up."
    "[whi]{b}HEY!{/b}"
    scene 05_0506 with fade
    scene black with fade
    "{b}ASSHOLE!{/b}"
    scene 05_0507 with fade
    scene black with fade
    scene 05_0508 with dis1
    scene 05_0509 with dis1
    call Emotion (mc, "Cough", "Fuck.")
    jam "He's back."
    scene 05_0510 with dissolve
    sue "Excellent."
    scene 05_0511 with dissolve
    mc "What the fuck?!"
    sue "Indeed."
    scene 05_0512 with dissolve
    sue "I'm sure you remember Simon and Douglas."
    scene 05_0513 with dissolve
    sue "James has been reminding them of the consequences to employees who break the rules."
    sue "They are in this predicament thanks to you."
    scene 05_0514 with dissolve
    sue "Had you not alerted me to the payment discrepancy for the cafe account, we would never have discovered their little scheme."
    mc "Are they dead?"
    sue "Not yet."
    scene 05_0515 with dissolve
    sue "You may not regard it as truth, but it would deeply sadden me to see you hanging alongside them."
    mc "Yeah, not gonna lie, I wouldn't be thrilled either."
    scene 05_0516 with dissolve
    sue "Splendid.\nWe agree then."
    sue "No more insolence, and no more disrespectful behavior."
    mc "Okay. You've made your point."
    scene 05_0517 with dissolve
    sue "Good.\nThis place reeks of death."
    sue "You are free to leave."
    scene 05_0518 with dissolve
    sue "I will be in touch."
    scene 05_0638 with fade1
    pause
    scene 05_0639 with dissolve
    mct "Whoa... Where the hell am I??"
    mct "At least they brought the truck here!"
    jump Springhaven_AnEveningAtHome
return

label Springhaven_InTrouble:
    pause 4.0
    $ aaa=""
    if helpedMel:
        $ Plr.Add("SawAH")
        $ aaa="a"
    scene 05_0519 with fade
    scene black with fade
    pause 0.5 
    scene 05_0519 with fade
    scene black with fade
    pause 0.5
    scene 05_0520 with fade
    scene black with fade
    scene 05_0521 with fade
    call Emotion (mc, "Groan")
    scene 05_0522 with fade
    mct "Fuck."
    scene 05_0523 with dissolve
    mct "Fuck!"
    if Plr.Has("SawAH"):
        scene 05_0524 with dissolve
        mct "Damn!\nAsshole1 and Asshole2?"
    else:
        scene 05_0525 with dissolve
        mct "Not good, [mc]!"
    scene 05_0526 with dissolve
    sue "It gives me no pleasure to see you like this."
    scene 05_0527 with dissolve
    sue "You disappoint me. I expected better."
    sue "Who has the girl?"
    scene 05_0528 with dissolve
    mc "Nobody {i}has{/i} her, Sue!"
    mc "I made a stupid mistake, and she escaped. That's the truth!"
    scene 05_0529 with dissolve
    sue "You'd have me believe you're {i}that{/i} inept?"
    if Plr.Has("SawAH"):
        scene 05_0530 with dissolve
        sue "I could expect as much from your feckless companions."
        sue "But not you."
        scene 05_0531 with dissolve
        sue "If they wake, they can thank you for their predicament."
        sue "Had you not alerted me to the payment discrepancy for the cafe account, we would never have discovered their little scheme."
    scene 05_0532 with dissolve
    sue "Who has the girl?"
    mc "She ran!"
    scene 05_0533 with dissolve
    sue "Who is Helen Johnson?"
    mc "What??"
    sue "You traveled to Brookvale, collected the girl, and left."
    sue "Afterward, you stopped at a property in Brook Ridge, owned by Helen Johnson."
    scene 05_0534 with dissolve
    mc "This has nothing to do with her, Sue!"
    mc "I was there for... personal reasons."
    mc "That's when she escaped. Check the tracking data!\nIt'll show me driving around the area looking for her!"
    scene 05_0535 with dissolve
    sue "{i}Personal reasons{/i}?! {b}Not{/b} an acceptable answer!"
    scene 05_0536 with dissolve
    sue "We shall resume tomorrow.\nI suggest you find better excuses; you're not doing terribly well."
    scene 05_0537 with dissolve
    mc "SUE!"
    show expression "05_0538" + aaa with dissolve
    mc "{size=*1.5}{b}SUUUE!!"
    show expression "05_0539" + aaa with dissolve
    mc "DAMN IT!"
    scene black with Fade(2, 1, 0)
    pause 4.0
    call Springhaven_Nightmare
    scene 05_0540
    call Emotion (mc, "GASP")
    scene 05_0541 with dissolve
    mc "[whi]Fuck."
    if Plr.Has("SawAH"):
        ah1 "Ohh, look! The princess is awake!"
        scene 05_0542 with dissolve
        ah1 "I really hope they fuckin' kill you first so I can watch."
        ah1 "I'll die a happy man knowing you got to Hell before me, motherfucker."
        scene 05_0543 with dissolve
        ah1 "Dougie? Still with us, Brother?"
        call Emotion (ah2, "Groan")
        scene 05_0544 with dissolve
        ah1 "If we get out of this... I'm gonna hunt you, and cut you up slowly - piece by little piece."
        mc "Whatever you say, buddy."
        scene 05_0545 with dissolve
        ah1 "Ahh, shit!"
    else:
        scene 05_0546 with dissolve
        mc "[whi]Great."
    scene 05_0547 with dissolve
    jam "Shall we get started?"
    mc "Nice to see you with a smile on your face for a change."
    scene 05_0548 with dissolve
    jam "I don't often come to work this happy!"
    scene 05_0549 with dissolve
    mc "This the day you've been looking forward to?"
    jam "Yep!"
    mc "Gotta say, I'm surprised..."
    mc "Not many guys look forward to the day they're gonna die."
    jam "[lol]"
    scene 05_0550 with dissolve
    jam "You should've been a comedian, man."
    jam "Keep talkin' your tough-guy talk."
    show expression "05_0551" + aaa with dissolve
    jam "It's just gonna make me enjoy it more."
    if Plr.Has("SawAH"):
        scene 05_0552 with dissolve
        mc "Shit, you were right!"
        mc "He {b}does{/b} look like a little bitch without his suit! Heh."
        ah1 "Huh??"
        scene 05_0553 with dissolve
        play sound "punch03.mp3"
        scene 05_0554 with vpunch
        scene 05_0555 with dissolve
        scene 05_0556 with dis1
        scene 05_0557 with dis1
        jam "Pussy."
    scene 05_0558 with dissolve
    jam "Your file says you were taught to ignore pain.\nLet's see."
    play sound "punch01.mp3"
    scene 05_0559 with vpunch
    mc "[whi]..Nnnghh.. {w=0.5}{nw}"
    play sound "punch02.mp3"
    scene 05_0560 with vpunch
    mc "[whi]..Mmmghh..{w=0.5}{nw}"
    scene black with Fade(2, 0, 0)
    pause 1.0
    play sound "punch04.mp3"
    pause 2.0
    play sound "punch03.mp3"
    pause 1.5
    play sound "punch01.mp3"
    pause 2.0
    play sound "punch02.mp3"
    pause 3.0
    call CenterText ("Some time later...")
    scene 05_0561 with Fade(0, 0, 4)
    jam "You'll scream eventually. Everyone does."
    scene 05_0562 with dissolve
    jam "The longer it takes, the sweeter it'll sound."
    sue "JAMES!"
    scene 05_0563 with dissolve
    sue "You were to {b}wait{/b} for me!!"
    jam "You took too long."
    scene 05_0564 with dissolve
    sue "Irrelevant!\n{b}I'M{/b} in authority here!"
    jam "If you say so."
    scene 05_0565 with dissolve
    sue "What has he told you?"
    jam "Nothing."
    scene 05_0566 with dissolve
    sue "He's remained silent??"
    jam "Not a damn word so far."
    scene 05_0567 with dissolve
    jam "Don't worry, he'll talk. Everyone breaks eventually."
    play sound "punch01.mp3"
    scene 05_0568 with vpunch
    mc "[whi]..Nnnhh.. {w=0.5}{nw}"
    scene 05_0569 with dis1
    play sound "punch02.mp3"
    scene 05_0570 with vpunch
    mc "[whi]Ngghh{w=0.5}{nw}"
    scene 05_0571 with dissolve
    jam "Tell me a joke, tough guy."
    scene 05_0572 with dissolve
    sue "We require the location of the girl, not {i}jokes{/i}.\nDon't lose focus."
    show expression "05_0573" + aaa with dissolve
    jam "I warned you not to trust this clown!\nYou wouldn't be in this mess if you'd fuckin' listened to me!"
    scene 05_0574 with dissolve
    sue "HOW DARE YOU SPEAK TO ME IN THAT MANNER!"
    scene 05_0575 with dissolve
    jam "I'll speak to you however the fuck I want!\nI'm sick of your bullshit!"
    scene 05_0576 with hpunch
    call Emotion (sue, "GASP")
    scene 05_0577 with dissolve
    jam "AARRGG!!"
    scene 05_0578 with dissolve
    play sound "punch01.mp3"
    scene 05_0579 with vpunch
    scene 05_0578 with dissolve
    play sound "punch01.mp3"
    scene 05_0579 with vpunch
    scene 05_0578 with dissolve
    play sound "punch01.mp3"
    scene 05_0579 with vpunch
    scene 05_0580 with dissolve
    call Emotion (jam, "Choking")
    if Plr.Has("SawAH"):
        scene 05_0581 with dissolve
        ah1 "YES, BIG MAN!\nKILL THAT MOTHERFUCKER!![lol]"
    scene 05_0582 with dissolve
    jam "...SUE..."
    jam "... MY... GUN!"
    scene 05_0583 with dissolve
    jam "...Sue..."
    scene 05_0584 with dissolve
    scene 05_0585 with dis1
    scene 05_0586 with dis1
    mc "SUE, NO!"
    scene 05_0587 with dissolve
    sue "Release him!"
    scene 05_0588 with dissolve
    call Emotion (jam, "COUGHING", "FUCK!")
    scene 05_0589 with dissolve
    jam "Shoot him!"
    sue "{i}Him{/i}?"
    scene 05_0590 with dissolve
    sue "This is for Michael, you son of a bitch."
    play sound "gun.mp3"
    scene black with Fade(.1, 0.0, .5, color="#fff")
    pause 2.0
    scene 05_0591 with fade
    mc "Shit!"
    $ JamesD=True
    scene 05_0592 with dissolve
    sue "Rot in Hell, you bastard."
    if Plr.Has("SawAH"):
        scene 05_0593 with dissolve
        ah1 "HOLY FUCK!! YOU KILLED JAMES!!"
        scene 05_0594 with dissolve
        play sound "gun.mp3"
        scene 05_0595 with Fade(.1, 0.0, .5, color="#fff")
        pause 0.5
        scene 05_0596 with dissolve
        mc "SUE, NO!\nSTOP!!"
        $ SimonD=True
        $ Plr.Add("DR")
        scene 05_0597 with dissolve
        sue "He's a witness."
        scene 05_0598 with dissolve
        mc "Don't. We need him alive."
        sue "Why?"
        mc "Please. Trust me."
        pause 1.0
        scene 05_0599 with dissolve
        sue "You've earned him a temporary reprieve. Nothing more."
    else:
        scene 05_0599 with dissolve
        sue "This has developed into quite the mess."
    scene 05_0600 with Fade(2, 3, 2)
    sue "What are we to do?"
    scene 05_0601 with dissolve
    mc "Call your bosses."
    mc "Tell them James didn't show up today, and you've had no contact with him."
    sue "Why?"
    scene 05_0602 with dissolve
    mc "I'm guessing he wasn't one of {i}your{/i} guys, so they're gonna realize he's missing sooner or later."
    mc "If they don't hear it from you, it'll raise their suspicions."
    scene 05_0603 with dissolve
    mc "I'm gonna need the gun."
    scene 05_0604 with dissolve
    sue "If you betray me..."
    scene 05_0605 with dissolve
    pause 0.5
    scene 05_0606 with dis1
    scene 05_0607 with dis1
    mc "Go home.\nI'll clean up this mess and come by later so we can talk."
    sue "Very well."
    show expression "05_0608" + aaa with dissolve
    mct "Fuck..."
    mct "What a mess."
    show expression "05_0609" + aaa with dissolve
    mct "Nngghh...\nAsshole. Think you cracked a rib."
    if Plr.Has("SawAH"):
        jump Springhaven_TimeToRunDoug
    scene 05_0623 with Fade(4, 3, 3)
    pause
    scene 05_0624 with dissolve
    call Emotion (mc, "Breathing heavily")
    scene 05_0625 with dissolve
    mc "...NNNGGGGHHHH..."
    scene 05_0626 with fade1
    pause
    scene 05_0627 with dissolve
    play sound "shutter.mp3"
    scene 05_0628 with dis1
    scene 05_0629 with dis1
    scene 05_0630 with dis1
    scene 05_0631 with dissolve
    mct "Where the hell am I??"
    scene 05_0632 with dissolve
    mct "Good. The truck's here."
    scene 05_0634 with dissolve
    mc "...Nnnnhhh..."
    scene 05_0637 with fade1
    call Emotion (mc, "Breathing heavily")
    mct "Need to find somewhere to dump him."
    scene black with Fade(3, 0, 0)
    jump Springhaven_ReturnHomeAfterDumping
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
