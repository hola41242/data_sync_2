label Springhaven_Start1:
    $ persistent.springhaven_active=True
    $ curLOC = springhaven_id
    if persistent.WalkthroughEnabled:
        $ wk_y="{color=#00ff00}"
        $ wk_n="{color=#ff0000}"
        $ wk_c= " {color=#ff0000}(Closes Path)"
    else:
        $ wk_y=""
        $ wk_n=""
        $ wk_c= ""
    $ renpy.music.set_volume(0.05)
    $ renpy.music.play("radio.mp3", channel='music', fadein=6)
    call AutoA
    scene 01_0001 with Fade(0,0,5)
    $ apause(1)
    scene 01_0002 with dis1
    $ apause()
    scene 01_0003 with dis1
    $ apause()
    $ renpy.music.set_volume(0.1)
    scene 01_0004 with dis1
    $ apause()
    scene 01_0005 with dis1
    $ apause()
    scene 01_0006 with dis1
    $ apause()
    scene 01_0007 with Dissolve(0.2)
    $ apause()
    $ renpy.music.set_volume(0.3)
    scene 01_0008 with dissolve
    $ apause(1)
    $ renpy.music.set_volume(1.0)
    scene 01_0009 with dissolve
    call AutoA (False)
    $ Sarah_name=""
    sar h "{nw}"
    call Emotion (sar, "Singing loudly", "", False)
    scene 01_0010 with dissolve
    sar "Come on, you can make it!\nAlmost there!"
    call Loop_Dissolve (2, False, False, "e01/01_0011.webp", "e01/01_0012.webp")
    scene 01_0011 with dissolve
    call Emotion (sar, "Sigh", "Can't believe I forgot to fill up before leaving.")
    $ renpy.music.set_volume(0.3)
    call AutoA
    scene 01_0013 with dissolve
    $ apause(1)
    $ renpy.music.set_volume(0.5)
    scene 01_0014 with dissolve
    call AutoA (False)
    sar "Sorry, Mr Hitchhiker... I've seen enough horror movies that start with picking you up!"
    $ renpy.music.set_volume(0.2)
    play sound "car.mp3"
    call AutoA
    scene 01_0015 with dissolve
    $ apause()
    scene 01_0016 with dissolve
    $ apause()
    scene 01_0017 with dissolve
    $ apause()
    $ renpy.music.set_volume(0.3)
    scene 01_0018 with dis1
    $ apause()
    $ renpy.music.set_volume(0.2)
    scene 01_0019 with dis1
    $ apause()
    $ renpy.music.set_volume(0.1)
    scene 01_0020 with dis1
    $ apause()
    $ renpy.music.set_volume(0.05)
    scene 01_0021 with dis1
    $ apause()
    $ renpy.music.stop(channel='music')
    $ renpy.music.set_volume(1.0)
    scene 01_0022 with fade
    call AutoA (False)
    sar a "I've already told you, I {b}don't{/b} need your help!"
    scene 01_0023 with dissolve
    sar a "I only need gas. Please leave me alone."
    mech "Come on, Sweetheart!\nLet me show you {i}my{/i} pumping skills! [lol]"
    scene 01_0024 with dissolve
    mech "I'll pump you {i}reeeal{/i} good."
    scene 01_0025 with dissolve
    sar a "That's disgusting! Go away!"
    call AutoA
    scene 01_0026 with fade
    $ renpy.music.play("shopbg.mp3", channel='music')
    $ renpy.music.set_volume(0.5)
    play sound "bell01.mp3"
    $ apause(1)
    scene 01_0027 with dissolve
    call AutoA (False)
    mechbro "Hello.\nIs there anything I can help with?"
    scene 01_0028 with dissolve
    $ pmcn = persistent.McName
    $ persistent.McName = ""
    mc "No thanks."
    scene 01_0029 with fade
    mechbro "[whi]Goddamnit..."
    scene 01_0030 with dissolve
    mechbro "Uhh, Sir..."
    mechbro "I think my drunk, asshole brother is bothering your wife."
    scene 01_0031 with dissolve
    mc "She's not my wife."
    mc "I'm not with her."
    scene 01_0032 with dissolve
    mechbro "Oh, sorry."
    mechbro "Just the soda then?"
    mc "Yeah."
    $ renpy.music.stop(channel='music')
    $ renpy.music.set_volume(1.0)
    scene 01_0033 with fade1
    mech "C'mon, take a sip!"
    sar a "I don't want a drink! {b}Please stop!{/b}"
    mech "Stop playing hard to get, Sweetheart!"
    scene 01_0034 with dissolve
    mech "Damn!..."
    scene 01_0035 with dis1
    scene 01_0036 with dis1
    mech "... That's one SWEET ASS!"
    sar a "TAKE YOUR HANDS OFF ME!!"
    scene 01_0037 with dissolve
    mech "Bet it could take my whole dick!"
    sar a "{b}PLEASE!{/b} LEAVE ME ALONE!!"
    menu:
        "[wk_y]Intervene":
            jump Springhaven_MeetSarah
        "None of my business":
            jump Springhaven_MeetBill
return

label Springhaven_MeetSarah:
    scene 01_0038 with dissolve
    mech "You good at suckin'?"
    play sound "punch.mp3"
    scene 01_0039 with dissolve
    scene 01_0040 with dissolve
    scene 01_0041 with dissolve
    sar sh "{nw}"
    call Emotion (sar, "GASP", "")
    scene 01_0042 with dissolve
    mc a "[whi]Asshole."
    call AutoA
    scene 01_0043 with dissolve
    $ apause(1)
    scene 01_0044 with fade1
    $ apause()
    $ renpy.sound.set_volume(0.25)
    play sound "engine.mp3" loop
    scene 01_0045 with dis1
    $ apause()
    $ renpy.sound.set_volume(0.5)
    scene 01_0046 with dissolve
    $ apause()
    $ renpy.sound.set_volume(1.0)
    scene 01_0052 with dissolve
    call AutoA (False)
    sar "Thank you."
    mc "No problem."
    scene 01_0053 with dissolve
    mc "Got what he deserved."
    sar "Where you headed?"
    mc "Springhaven."
    scene 01_0054 with dissolve
    sar "You've got a long way to go, and it'll be dark soon!"
    sar "That's where I'm headed. Jump in."
    show screen WlkGuide(wkg001)
    menu:
        "Accept offer":
            hide screen WlkGuide  
        "Decline offer":
            hide screen WlkGuide 
            $ Sarah.Score(1)
            $ Sarah.Add("NoLift")
            mc "Thanks, but I'm good."
            scene 01_0055 with dissolve
            sar "I'm confused... Aren't you hitchhiking??"
            scene 01_0056 with dissolve
            mc "You didn't stop earlier."
            mc "You probably weren't comfortable offering a stranger a lift, which is understandable since you're traveling alone."
            mc "You don't owe me anything, and I'm in no hurry to get where I'm going."
            scene 01_0055 with dissolve
            sar "Uh, okay."
            sar "Thanks again for your help back there."
            play sound "car.mp3"
            call AutoA
            scene 01_0050 with dissolve
            $ apause(1)
            scene black with Fade(1, 0, 0)
            call AutoA (False)
            jump Springhaven_MeetBill
    scene 01_0057 with dissolve
    mc "Thanks."
    sar "You can toss your bag in the back seat."
    stop sound
    scene 01_0058 with fade
    sar "Thanks again for what you did back there."
    play sound "driving.mp3" loop volume 0.3
    scene 01_0059 with dissolve
    sar "That guy was such a creep!"
    sar "I drive this route often, but I've never stopped there."
    sar "And I'm never stopping there again!"
    scene 01_0060 with dissolve
    sar "Uh... Sorry I didn't offer you a lift earlier."
    mc "It's alright, I understand.\nOffering a stranger a lift is a risk you didn't want to take."
    scene 01_0061 with dissolve
    sar "Please tell me I didn't make a huge mistake!"
    mc "Hah. Don't worry, you're safe with me."
    sar h "That's a relief!"
    scene 01_0062 with dissolve
    sar "... But then, that's exactly what a psycho {i}would{/i} say![lol]"
    scene 01_0063 with dissolve
    sar "I'm Sarah, by the way."
    $ Sarah_name="Sarah"
    $ Sarah.Activate("Sarah")
    $ persistent.SarahLocked=False
    scene 01_0064 with dissolve
    call UpdateName
    scene 01_0063 with dissolve
    sar "Nice to meet you, [mc]!"
    scene 01_0065 with fade
    pause 0.5
    play sound "car.mp3" volume 0.3
    call AutoA
    scene 01_0066 with dis1
    $ apause()
    scene 01_0067 with dis1
    $ apause()
    play sound "driving.mp3" loop volume 0.3
    scene 01_0068 with fade
    call AutoA (False)
    sar "What you doin' walking around out here in the middle of nowhere?"
    sar "Car trouble?"
    mc "No. Don't own a car.\nJust makin' my way to Springhaven."
    scene 01_0069 with dissolve
    sar "Damn! It's a helluva walk!!\nDidn't think about getting a bus?"
    mc "No buses were coming out this way from the airport.\nFigured I'd start walking."
    sar "Wait - You walked from Lakeshore airport??"
    scene 01_0070 with dissolve
    sar "Holy crap, that's insane!\nIt's like a two-hour drive to Springhaven from Lakeshore!!"
    sar "What were you doing at the airport?"
    scene 01_0071 with dissolve
    sar "Ohh, sorry! I have a terrible habit of being nosy.\nYou don't have to answer."
    mc "It's fine. I just got back from overseas."
    sar "Oh!\nSomewhere nice?"
    mc "No, not really."
    scene 01_0072 with dissolve
    mc "I was in the military.\nWe don't usually pick {i}vacation{/i} spots."
    sar "Oh."
    scene 01_0073 with dissolve
    sar "So you're heading home?"
    sar "I, uhh... bet your wife'll be glad to see you!"
    scene 01_0072 with dissolve
    mc "{b}Ex{/b}-wife.\nAnd I'm pretty sure I'm the last person she wants to see."
    scene 01_0074 with dissolve
    sar "Shit! Sorry. I keep putting my foot in it."
    scene 01_0075 with dissolve
    mc "How about you?"
    mc "Let me guess... Husband, white picket fence, and 2.4 children?"
    scene 01_0076 with dissolve
    sar "Hell no!"
    scene 01_0075 with dissolve
    mc h "Whoa! Sorry!"
    scene 01_0077 with dissolve
    sar h "Sorry, I didn't mean to snap at you!"
    sar "I'm not against marriage, just not {i}my{/i} thing."
    mc "Fair enough."
    scene 01_0078 with fade
    mc "You from Springhaven?"
    sar "Yeah. Born and bred."
    scene 01_0079 with dissolve
    sar "I spent the weekend in Lakeshore, visiting a friend."
    sar "She's been going through a rough patch, so I decided to go and cheer her up."
    scene 01_0080 with dissolve
    mc "Did it work?"
    sar "Of course!"
    scene 01_0081 with dissolve
    sar h "We've been at this our whole lives.\nI'm basically a professional at cheering her up."
    sar "You a Springhaven'er too?"
    mc "No, just passing through."
    scene 01_0082 with dissolve
    sar "Oh. So not staying long?"
    mc "Nah. Just got a promise to keep."
    scene 01_0083 with dissolve
    sar "Hmm, that sounds... intriguing!"
    scene 01_0084 with dissolve
    pause
    scene 01_0085 with dissolve
    sar h "Not much of a talker, are you?"
    mc "Err... no, I guess not. Sorry."
    scene 01_0086 with dissolve
    sar h "It's okay, [mc]. I love awkward silences."
    call AutoA
    scene 01_0087 with fade
    $ apause()
    play sound "car2.mp3" volume 0.3
    scene 01_0088 with dis1
    $ apause()
    scene 01_0089 with dis1
    $ apause()
    scene black with fade2
    scene 01_0090 with fade
    $ apause()
    play sound "car.mp3" volume 0.3
    scene 01_0091 with dis1
    $ apause()
    scene 01_0092 with dis1
    $ apause()
    play sound "driving.mp3" loop volume 0.3
    scene 01_0093 with dissolve
    call AutoA (False)
    sar "Not much further now."
    scene 01_0094 with dissolve
    sar "[mc]?"
    scene 01_0095 with dissolve
    call Emotion (mc, "Snore", "")
    call AutoA
    scene 01_0096 with dissolve
    play sound "car2.mp3" volume 0.3
    $ apause()
    scene 01_0097 with dis1
    $ apause()
    scene 01_0098 with dis1
    $ apause()
    call AutoA (False)
    call Springhaven_Nightmare
    scene 01_0104
    mc sh "{nw}"
    call Emotion (mc, "GASP", "NO!")
    scene 01_0105 with dissolve
    sar "Hey... Are you okay?"
    scene 01_0106 with dissolve
    mc "[whi]... Uh, yeah."
    mc "Sorry, must've nodded off for a minute."
    scene 01_0107 with dissolve
    sar h "A minute? You've been asleep for over an hour!"
    scene 01_0108 with dissolve
    sar "We're here. Springhaven."
    sar "You didn't tell me where you wanted to be dropped off."
    scene 01_0109 with dissolve
    mc "Here's fine, thanks."
    sar "Where you staying?\nI don't mind taking you if it's not far."
    mc "I, err..."
    scene 01_0110 with dissolve
    mc "I'll find somewhere."
    sar "You don't have anywhere to stay??"
    mc "I'll find a park bench to crash on."
    scene 01_0111 with dissolve
    sar "You can't be serious??"
    scene 01_0112 with dissolve
    mc h "I've slept in worse places."
    scene 01_0113 with dissolve
    sar "Right. Military."
    mc "Yeah... not anymore."
    scene 01_0114 with dissolve
    mc "Thanks for the lift, Sarah.\nIt was nice meeting you."
    scene 01_0115 with dissolve
    sar "You're welcome.\nGreat to meet you, too!"
    scene 01_0116 with dissolve
    mc "See ya."
    sar "Bye."
    call AutoA
    scene 01_0117 with dissolve
    $ apause()
    scene 01_0118 with dis1
    $ apause()
    scene 01_0119 with dis1
    $ apause()
    scene 01_0120 with dissolve
    call AutoA (False)
    sar "[mc], wait..."
    scene 01_0121 with dissolve
    sar "I can't leave you out here with no place to go..."
    sar "I... Uhh..."
    scene 01_0122 with dissolve
    sar "I... have a crappy sofa..."
    sar "It's not much, but I'm positive it'll be comfier than a park bench."
    $ TCh=None
    if EzModeActive:
        call EzModeAsk ("Sarah")
        if _return:
            $ Sarah.Add("EZ")
            $ TCh=True
    else:
        menu:
            "[wk_y]Accept":
                $ TCh=True
            "Decline[wk_c]":
                pass
    if TCh:
        scene 01_0123 with dissolve
        mc "You sure? I don't wanna put you out."
        sar "Honestly, it's fine."
        sar "C'mon."
        scene black with Fade(1, 2, 1)
    else:
        $ Sarah.Add("NoSofa")
        call CloseCharacterPath (Sarah, "Sarah")
        scene 01_0123 with dissolve
        mc "That's very kind of you, but you've already done more than enough for me."
        mc "I'll be fine."
        scene 01_0124 with dissolve
        sar "Uhh... Okay, if you're sure."
        sar "Take care of yourself, [mc]."
        scene 01_0125 with dissolve
        mc "You too."
        scene 01_0126 with fade
        pause 1.0
        jump Springhaven_Park
    call AutoA
    scene 01_0127 with Fade(0,0,2)
    $ apause(1)
    scene 01_0128 with dissolve
    call AutoA (False)
    sar "Come on in."
    scene 01_0129 with dissolve
    mc "Thanks."
    scene 01_0130
    pause 0.5  
    scene 01_0131 with dissolve
    sar "It's not much, but it's mine."
    mc "Looks great."
    scene 01_0132 with dissolve
    sar "Oh, crap!... Err, ignore the mess!"
    scene 01_0133 with dissolve
    sar h "I was in the middle of grading when Dawn called with her mini-meltdown."
    mc "Grading?"
    scene 01_0134 with dissolve
    sar "Yeah.\nI'm a teacher."
    sar "I work at the local high school."
    scene 01_0135 with dissolve
    sar "Most of my evenings are spent going over homework."
    scene 01_0136 with dissolve
    sar h "Such a glamorous life!"
    scene 01_0137 with dissolve
    mc "Whoa!"
    sar "Oh, that's Binx!"
    scene 01_0138 with dissolve
    "[mo]Meeowww"
    scene 01_0139 with dissolve
    sar "Shoot!\nYou're not allergic, are you?"
    scene 01_0140 with dissolve
    mc "Nah."
    scene 01_0141 with dissolve
    sar "Awww, looks like you have a new friend!"
    scene 01_0142 with dissolve
    sar h "He likes you!"
    scene 01_0143 with dissolve
    sar "He's a good judge of character."
    scene 01_0144 with dissolve
    mc "Thanks again for letting me crash here, Sarah.\nIt's very kind of you."
    sar "No problem!"
    scene 01_0145 with dissolve
    sar "Let me take your things, and you can make yourself comfortable."
    scene 01_0146 with Fade(1, 0.5, 0.5)
    sar "Oh my... That sofa looks a lot smaller with {i}you{/i} sitting there!"
    sar "Will you be able to sleep on it?"
    scene 01_0147 with dissolve
    mc h "I'm sure I'll manage.\nLike you said, it's more comfy than a bench!"
    scene 01_0148 with dissolve
    sar "Is there anything I can get you?\nDrink?"
    scene 01_0149 with dissolve
    sar "Are you hungry?\nI have plenty of food!"
    mc "No, I'm fine, honestly."
    scene 01_0150 with dissolve
    mc "You're a kind, sweet person. I can see why your friend relies on you!"
    sar h "Dawn? Yeah, lucky for me, she's never far from the next crisis!"
    scene 01_0151 with dissolve
    sar "How long were you in the military?"
    mc "Signed up on my eighteenth birthday. Left yesterday."
    scene 01_0152 with dissolve
    sar "Wow. What did you do?"
    mc "Jumped on a plane and started walking to Springhaven."
    scene 01_0153 with dissolve
    sar "[lol]"
    scene 01_0154 with dissolve
    sar "No! I mean in the military. Uhh... your job."
    mc h "Right! Sorry..."
    mc "I... Err... I can't really talk about it."
    scene 01_0155 with dissolve
    sar h "Ooohh! Like, top secret n'stuff?"
    mc "Yeah, something like that."
    sar "Very intriguing... again!"
    scene 01_0156 with dissolve
    sar h "Damn, [mc]!\nYou play the handsome, mysterious stranger role very well!"
    mc h "Uhh, thanks... I guess!"
    scene 01_0157 with dissolve
    sar "Okay, I'll take the hint. No more questions."
    sar "I'll get you a blanket, and then I'm gonna get some sleep. I'm exhausted."
    scene 01_0158 with dissolve
    mc "Thanks."
    scene 01_0159 with Fade(1,0.5,2)
    sar "Here you go.\nIt's the biggest I could find."
    mc "Thank you.\nI'll be outta your hair at first light."
    scene 01_0160 with dissolve
    sar "Bathroom's just there if you need it.\nGoodnight."
    mc "Night."
    call AutoA
    scene 01_0161 with Fade(3,0.5,2)
    $ apause(2)
    scene 01_0162 with Fade(3,0.5,2)
    $ apause(3)
    scene 01_0163 with dissolve
    $ apause(1)
    scene 01_0164 with dissolve
    $ apause()
    scene 01_0165 with dis1
    $ apause()
    scene 01_0166 with dis1
    call AutoA (False)
    sar "[whi][mc]?\nAre you awake?"
    scene 01_0167 with dissolve
    mc "Uhh, yeah... Is everything okay?"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e01/01_0168.webp", 995, 540, True, "Springhaven_AF01") with dissolve
        sar "Yeah, I can't sleep."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0168
            hide screen imgMap
    else:
        scene 01_0168 with dissolve
        sar "Yeah, I can't sleep."
        if Sarah.Has("EZ"):
            call Springhaven_AF01
        elif not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    call Springhaven_AF01
                "Don't":
                    pass
    scene 01_0170 with dissolve
    sar "I feel terrible knowing you're out here squashed up on that couch, while I'm lying in a big, comfy bed."
    mc "You wanna swap?"
    sar h "No! [lol]"
    scene 01_0171 with dissolve
    sar "But, I was thinking... We're both adults, right?..."
    sar "We're capable of sharing a bed without... doing {i}anything{/i}, aren't we?"
    if Sarah.Has("EZ"):
        jump Springhaven_SarahBed
    if not EzModeActive:
        menu:
            "[wk_y]Agree":
                jump Springhaven_SarahBed
            "Disagree":
                pass
    scene 01_0170 with dissolve
    $ Sarah.Score(1)
    $ Sarah.Add("NoBed")
    mc "Honestly, Sarah? No."
    mc h "You're a beautiful woman. Not sure I could trust myself!"
    mc "You can sleep soundly. This is the comfiest couch I've slept on."
    scene 01_0172 with dissolve
    sar h "Really? {i}It is{/i}?"
    sar "Okay, if you're sure."
    scene 01_0173 with dissolve
    sar "Goodnight."
    mc "Night."
    scene 01_0161 with Fade(3,0.5,2)
    call Emotion (mc, "Snoring", "")
    jump Springhaven_WakeUpCouch
return

label Springhaven_SarahBed:
    scene 01_0174 with dissolve
    mc "I guess so, yeah."
    sar "Great! C'mon."
    if persistent.UseFocus and not Sarah.Has("EZ"):
        $ _skipping = False
        show screen imgMap("images/e01/01_0175.webp", 1022, 784, True, "Springhaven_AF02") with dissolve
        sar h "I'll sleep so much better with a clear conscience!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0175
            hide screen imgMap   
    else:
        scene 01_0175 with dissolve
        sar h "I'll sleep so much better with a clear conscience!"
        if Sarah.Has("EZ"):
            call Springhaven_AF02
        else:
            menu:
                "[wk_y]Check her out again":
                    call Springhaven_AF02
                "Don't":
                    pass
    scene 01_0178 with dissolve
    sar "I'd just like to point out that I don't {i}usually{/i} invite strangers into my home, or bed!"
    scene 01_0179 with dissolve
    sar h "You're the first!"
    mc h "Understood."
    scene 01_0180 with fade
    mc "Damn, you're right! It {i}is{/i} comfy!"
    scene black with Fade(4,0,0)
    call AutoA
    $ apause(3)
    scene 01_0181 with Fade(0, 0, 2)
    $ apause(1)
    scene 01_0182 with dis1
    call AutoA (False)
    call Emotion (mc, "Sigh", "")
    scene 01_0183 with dis1
    call AutoA
    $ apause()
    scene 01_0184 with dis1
    play sound "pee.mp3"
    $ apause(16)
    scene 01_0185 with dis1
    $ apause()
    scene 01_0186 with dis1
    $ apause()
    call AutoA (False)
    if persistent.UseFocus and not Sarah.Has("EZ"):
        $ _skipping = False
        show screen imgMap("images/e01/01_0187.webp", 314, 378,  True, "Springhaven_AF03") with dissolve
        mct "Tempting... heh"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0187
            hide screen imgMap
    else:
        scene 01_0187 with dissolve
        mct "Tempting... heh"
        if Sarah.Has("EZ"):
            call Springhaven_AF03
        else:
            menu:
                "[wk_y]Take a closer look":
                    call Springhaven_AF03
                "Don't":
                    pass
    if not Sarah.isActive():
        jump Springhaven_WakeUpCouch
    scene 01_0181 with Fade(3, 2, 2)
    call AutoA
    $ apause(2)
    scene 01_0198 with Fade(2, 3, 2)
    $ apause(2)
    scene 01_0199 with Fade(2, 3, 2)
    $ apause(2)
    scene 01_0200 with Fade(2, 3, 2)
    $ apause(1)
    scene 01_0201 with dis1
    $ apause(2)
    scene 01_0202 with dis1
    $ apause(1)
    if not Sarah.hasScore(2):
        scene 01_0204 with dis1
        $ apause()
        scene 01_0205 with dis1
        $ apause()
        scene 01_0206 with dis1
        $ apause()
        scene 01_0298 with Fade(3, 1, 2)
        call AutoA (False)
        sar "Morning!"
        scene 01_0299 with dissolve
        sar "Hungry?"
        mc "Yeah, starving."
        scene 01_0300 with dissolve
        mc "I should.. err, my clothes..."
        sar "Right! [lol]"
        jump Springhaven_BreakfastWithSarah
    scene 01_0203 with dis1
    $ apause(1)
    scene 01_0207 with Fade(2, 3, 2)
    $ apause(1)
    scene 01_0208 with dis1
    $ apause(1)
    scene 01_0209 with dissolve
    $ apause(1)
    scene 01_0210 with dis1
    $ apause(2)
    scene 01_0211 with dis1
    $ apause(1)
    scene 01_0212 with dis1
    $ apause(0.25)
    scene 01_0213 with dis1
    $ apause(0.25)
    scene 01_0214 with dis1
    $ apause(0.25)
    scene 01_0215 with dis1
    $ apause(1)
    if not Sarah.hasScore(3):
        scene 01_0216 with dis1
        $ apause(1)
        scene 01_0217 with Fade(2, 1, 1)
        mc "[whi]...Zzzzzz...{w=1}{nw}"
        call AutoA (False)
        jump Springhaven_BreakfastWithSarah
    call AutoA (False)
    call SaraReplay01
    if Sarah.getCumIns()>0:
        scene 01_0280 with fade
        sar "[ss]I knew you were gonna be trouble."
        menu:
            "[wk_y]Apologize for not pulling out":
                sar "[whi]It's fine, I'm on birth control.\nI would've warned you!"
                sar h "[whi]Appreciate the apology, though."
                $ Sarah.Score(1)
            "Don't say anything":
                pass
        scene 01_0282 with dissolve
        sar "[ss]Mmhhh."
    else:
        scene 01_0281 with fade
        sar "[ss]I knew you were gonna be trouble."
        scene 01_0283 with dissolve
        sar "[ss]Mmhhh."
    scene 01_0284 with dissolve
    sar "[whi]I'm gonna get dressed for work, then I'll make us breakfast."
    mc "[whi]Great."
    scene 01_0285 with dissolve
    sar "[kiss]"
    scene 01_0286 with dissolve
    call AutoA
    $ apause(1)
    scene 01_0298 with Fade(2, 1, 2)
    call AutoA (False)
    sar "Hungry?"
    mc "Yeah, starving."
    scene 01_0299 with dissolve
    sar h "Not that I'm complaining, but...\nYou gonna eat... like {i}that{/i}?"
    mc "Heh, nah."
    scene 01_0300 with dissolve
    mc "My clothes are, uhh.."
    sar h "Right!"
    jump Springhaven_BreakfastWithSarah
return

label Springhaven_WakeUpCouch:
    scene black with Fade(4,0,0)
    call AutoA
    $ apause(3)
    scene 01_0287 with fade
    mc "...zzzZZzz...{w=1}{nw}"
    scene 01_0288 with dissolve
    $ apause()
    $ aa=""
    if not Sarah.isActive():
        $ aa="a"
    show expression "01_0289" + aa with dissolve
    call AutoA (False)
    sar "Good morning."
    show expression "01_0290" + aa with dissolve
    sar h "Looks like at least {i}one{/i} of you had a comfortable night!"
    scene 01_0291 with dissolve
    "[mo]Meeooowwww"
    show expression "01_0292" + aa with dissolve
    sar "Did you sleep okay?"
    mc "Yeah, fine."
    if not Sarah.isActive():
        scene 01_0293 with dissolve
        mc "Sarah, about last night..."
        mc "I'm sorry.\nI... I shouldn't have done... that."
        scene 01_0294 with dissolve
        sar "Err... thanks.\nI think it's best we pretend it never happened. Don't {i}you{/i}?"
        mc "Uhh... Yeah."
        scene 01_0292a with dissolve
        sar "I need to get ready for work. You should get dressed, too."
    else:
        scene 01_0295 with dissolve
        sar "I'd better go and get ready for work."
        if not EzModeActive:
            menu:
                "I should get dressed, too.":
                    pass
                "[wk_y]Shame. I like what you're wearing now.":
                    if Sarah.Has("Nobed"):
                        $ Sarah.Score(1)
                        scene 01_0296 with dissolve
                        sar "You should have accepted my offer last night, then."
        else:
            mc "I should get dressed, too."
    scene 01_0297 with fade1
    sar "Hungry?"
    mc "Starving."
    jump Springhaven_BreakfastWithSarah
return

label Springhaven_BreakfastWithSarah:
    scene black with Fade(2, 2, 1)
    scene 01_0301 with fade
    mc "You didn't need to make me breakfast, Sarah. Thanks."
    sar "I can't let you leave on an empty stomach!"
    if Sarah.isSexual():
        scene 01_0302 with dissolve
        sar h "Besides, I think you've earned it!"
        scene 01_0303 with dissolve
        sar "I'm, err... Sorry for jumping on you."
        sar "It's a little embarrassing to admit, but... it's been a while since I've had sex!"
        sar h "Waking up with you... I was {i}so{/i} horny!"
        mc h "I'm not complaining."
        scene 01_0304 with dissolve
        sar "I know.\nIt's just..."
        sar "I don't want you to think I'm {i}that{/i} type of gal."
        scene 01_0305 with dissolve
        sar "I don't {i}usually{/i} jump on a guy's dick the first chance I get!"
        sar "I, uhh... "
        scene 01_0306 with dissolve
        mc "Hey, don't sweat it..."
        $ TmpChosen=None
        if not Sarah.Has("EZ"):
            menu:
                "It meant nothing, it was just sex!":
                    $ Sarah.Score(-2)
                    sar "[whi]Right."
                "[wk_y]I'm happy you did what you did.":
                    $ TmpChosen=True
        if TmpChosen or Sarah.Has("EZ"):
            mc "I'm happy you did what you did."
            $ Sarah.Score(1)
            sar "You are?"
            scene 01_0307 with dissolve
            sar h "Okay."
    scene 01_0308 with dissolve
    sar "How long will you be in town?"
    mc "Not sure. A day or two."
    scene 01_0309 with dissolve
    sar "Right. Just keepin' your promise..."
    mc "Yeah."
    sar h "It's fine if you don't wanna tell me."
    scene 01_0310 with dissolve
    mc "I swore to a friend that if he died, I'd deliver something for him."
    sar "Oh God. I'm Sorry."
    scene 01_0311 with dissolve
    sar "What'll you do {i}after{/i}...? Head home?"
    mc "I don't... I don't know. I don't really have a home anymore."
    scene 01_0312 with dissolve
    sar "What about family? Parents? Siblings?\nYou mentioned an ex-wife. Do you have children?"
    mc h "Damn! You ask a lot of questions!"
    scene 01_0313 with dissolve
    sar "Shit. I'm sorry... {i}again{/i}!"
    sar h "I did warn you I was kinda nosey!"
    mc h "It's okay, I'm teasing you."
    scene 01_0310 with dissolve
    mc "Parents - No. Never knew my father. Mom passed away last year."
    mc "Siblings - Yes, a sister. Not very close, though."
    mc "Kids - Yeah, a daughter, but she hates me even more than her mom."
    sar "[whi]Damn!"
    scene 01_0312 with dissolve
    sar "Oh, shoot! Eat up!\nI'm gonna be late for work! I'm already in enough trouble for not grading these papers!"
    scene 01_0314 with Fade(2, 2, 1)
    mc "Thanks again for letting me stay."
    sar "You're very welcome."
    if Sarah.isActive():
        $ Sarah.Add("Cell")
        sar "I've, err... put my cell number in your jacket pocket, in case you need a friend."
        mc "Thanks, that's sweet of you.\nI'll shoot you a text so you have mine, too."
        $ TmpChosen=None
        if not EzModeActive:
            menu:
                "[wk_y]Say bye to Binx":
                    $ TmpChosen=True
                "Ignore the cat":
                    pass
        if TmpChosen or Sarah.Has("EZ"):
            scene 01_0315 with dissolve
            $ Sarah.Score(1)
            mc "Bye-bye, Binx! Take good care of your Mommy."
            "[mo]Meowwww"
        if Sarah.isSexual():
            scene 01_0316 with dissolve
            sar "Look after yourself, [mc]."
            mc "I will. You too."
            sar "Remember, you'll always have a place to stay in Springhaven."
            sar "And I promise..."
            scene 01_0317 with dissolve
            sar "The next time we have sex, we'll take our time and {i}really{/i} fuck."
            scene 01_0318 with dissolve
            pause 0.5 
            scene 01_0319 with dissolve
            sar "Mmmhhh..."
    scene 01_0320 with dissolve
    mc "See ya'"
    sar "Bye, [mc]."
    scene black with Fade(2, 1, 2)
    jump Springhaven_Delivery
return

label Springhaven_MeetBill:
    if not Sarah.Has("NoLift"):
        call AutoA
        scene 01_0044 with fade1
        $ apause()
        scene 01_0045 with dis1
        $ apause()
        scene 01_0046 with dis1
        $ apause()
        play sound "car.mp3"
        scene 01_0048 with dissolve
        scene 01_0049 with dissolve
        scene 01_0050 with dissolve
        scene 01_0051 with dissolve
        $ apause(1)
        call AutoA (False)
    call CenterText ("A couple of hours later...", True)
    call AutoA
    scene 01_0321 with fade
    play sound "truck01.mp3"
    $ apause()
    scene 01_0322 with dis1
    scene 01_0323 with dis1
    scene 01_0324 with dis1
    scene 01_0325 with dis1
    scene 01_0326 with dis1
    scene 01_0327 with dissolve
    $ apause()
    scene 01_0328 with dis1
    play sound "tidle.mp3" loop
    $ apause()
    scene 01_0329 with dis1
    $ renpy.music.set_volume(0.5)
    $ renpy.music.play("<from 50>truckradio.mp3", channel='music', fadein=1)
    $ apause()
    scene 01_0330 with dissolve
    call AutoA (False)
    $ Bill_name=""
    bill "Damn, son! You tryin' to get yourself killed?"
    bill "What the hell you doin' walkin' out here in the middle of nowhere?"
    bill "Almost made you roadkill."
    mc "Err, sorry."
    bill "Climb in."
    scene 01_0331 with dissolve
    mc "Thanks."
    $ renpy.music.set_volume(0)
    play sound "truck02.mp3" fadein 0.2
    call AutoA
    scene 01_0332 with dissolve
    $ apause()
    scene 01_0333 with dis1
    $ apause()
    scene 01_0334 with dis1
    $ apause()
    $ renpy.music.set_volume(0.1)
    scene 01_0335 with dissolve
    call AutoA (False)
    bill "Been drivin' this route thirty years. You're the first hitchhiker I've seen!"
    bill "Name's Bill."
    $ Bill_name="Bill"
    scene 01_0336 with dissolve
    call UpdateName
    mc "Thanks for the ride, Bill."
    bill "You lost, [mc]?\nRunning from the law?"
    mc "No.\nJust tryin' to get to Springhaven."
    scene 01_0337 with dissolve
    bill "On foot? Jesus. You're nuts."
    bill "No buses where you live?"
    mc "Nope. None heading this way from the airport."
    scene 01_0338 with dissolve
    bill "Airport?"
    bill "You tellin' me you walked all this way from Lakeshore??"
    bill "Shit! You {b}ARE{/b} crazy, Son!"
    scene 01_0336 with dissolve
    bill "Good news, though - Springhaven's where I'm headed."
    mc "Great."
    play sound "truck03.mp3"
    scene 01_0339 with dissolve
    call AutoA
    $ apause()
    scene 01_0340 with dis1
    $ apause()
    scene 01_0341 with dis1
    $ apause()
    scene 01_0342 with dissolve
    call AutoA (False)
    bill "Vacation?"
    scene 01_0336 with dissolve
    mc "Huh?"
    bill "Travelin' light for a guy off a plane.\nWeekend getaway?"
    bill "Escape the wife's naggin'?[lol]"
    mc "Ex-wife. Already escaped that."
    scene 01_0343 with dissolve
    mc "Been overseas. Military."
    bill "Military huh?\nGotta lot of respect for you guys."
    scene 01_0344 with dissolve
    mc "Thanks.\nBut, ex-military now."
    scene 01_0345 with dissolve
    bill "You from Springhaven?"
    mc "Nah, just passin' through.\nSpringhaven's... a promise I gotta keep."
    scene 01_0343 with dissolve
    mc "You seem like a nice guy, Bill.\nI'm not big on small talk, though."
    mc "Mind if I get some shut-eye? It's been a long damn day."
    scene 01_0337 with dissolve
    bill "Uh, sure. Go ahead, kid."
    bill "Ain't like I picked you up for the company."
    $ renpy.music.stop(channel='music')
    play sound "truck03.mp3"
    call AutoA
    scene 01_0339 with dissolve
    $ apause()
    scene 01_0340 with dis1
    $ apause()
    scene 01_0341 with dis1
    $ apause()
    scene black with Fade(2, 1, 0)
    call AutoA (False)
    call Springhaven_Nightmare
    scene 01_0346
    call Emotion (mc, "GASP", "NO!")
    $ renpy.music.play("<from 20>truckradio.mp3")
    scene 01_0347 with dissolve
    bill "You okay there, Son?"
    mc "Uhh... Yeah."
    bill "Seen that before."
    scene 01_0348 with dissolve
    mc "Huh?"
    bill "My son was military, too.\nHe suffered the same. Terrible nightmares from the war.\nHaunted him."
    bill "You should get help with that.\nTalk to a professional. There's no shame in it."
    mc "I'm fine."
    bill "Uh, okay."
    scene 01_0349 with dissolve
    bill "We're here. Springhaven. Where can I drop you?"
    mc "Here's good. Thanks, Bill."
    bill "Do you even know where {i}here{/i} is?"
    scene 01_0350 with dissolve
    bill "Where you staying?"
    mc "I'll find somewhere."
    bill "You ain't gotta place to stay?"
    scene 01_0351 with dissolve
    bill "You won't find anything open this time of night."
    mc "I'll make do with a park bench, then."
    bill "Damn, Son!\nI'm starting to think you really {i}are{/i} crazy."
    scene 01_0352 with dissolve
    bill "Shit..."
    bill "You remind me a lot of him, you know? My boy."
    scene 01_0353 with dissolve
    bill "Goddamn war."
    bill "Couldn't handle coming home with everything he'd been through.\nNightmares, flashbacks - like you."
    scene 01_0354 with dissolve
    bill "Ended up blowing his own fuckin' brains out."
    scene 01_0344 with dissolve
    mc "Shit, Bill! I'm sorry."
    scene 01_0355 with dissolve
    bill "Listen... I have a spare room at home.\nMaybe my Mary will even cook you up summat before bed."
    bill "Sure as hell beats sleepin' on a bench!"
    menu:
        "[wk_y]Accept offer":
            scene 01_0350 with dissolve
            mc "You're a good guy, Bill. Appreciate it."
            bill "Okay then."
            scene 01_0358 with Fade(2, 2, 1)
            play sound "truck03.mp3"
            mc "You sure... uhh, Mary... won't mind you bringing home a stray?"
            scene 01_0359 with dissolve
            bill "Nah.\nShe'll be over the moon! We don't get many visitors out here."
            mc "Don't wanna cause you any trouble."
            scene 01_0360 with dissolve
            bill "Don't you worry, Son.\nUnlike me, my Mary's a people person![lol]"
            scene 01_0361 with dissolve
            $ renpy.music.stop(channel='music')
            $ renpy.music.set_volume(1.0)
            bill "Let's get inside."
            jump Springhaven_MeetMary
        "Decline offer":
            scene 01_0350 with dissolve
            mc "Appreciate the offer, Bill, but the lift was enough."
            bill "Uhh, okay."
            scene 01_0351 with dissolve
            bill "There's a park just around the next corner; you'll find a bench there."
            mc "Thanks, Bill."
            bill "Take care of yourself, Son."
            $ renpy.music.stop(channel='music')
            $ renpy.music.set_volume(1.0)
            scene 01_0357 with dissolve
            play sound "truck03.mp3"
            pause 1.0
            jump Springhaven_Park
return

label Springhaven_Nightmare:
    call AutoA
    scene black with Fade(2, 1, 2)
    play sound "war.mp3"
    $ apause()
    scene 01_0099 with fade
    $ apause(0.1)
    scene black with fade
    $ apause()
    scene 01_0100 with fade
    $ apause(0.25)
    scene black with fade
    $ apause()
    scene 01_0101
    "{size=*0.75}[mc]{w=0.5}{nw}"
    scene black with fade
    $ apause(0.25)
    scene 01_0102
    "[mc]{w=1.0}{nw}"
    scene black with fade
    $ apause(0.25)
    scene 01_0103
    "{size=*2.5}[mc!u]! WAKE UP!{w=1.0}{nw}"
    stop sound
    call AutoA (False)
return

label Springhaven_MeetMary:
    scene 01_0362 with Fade(2, 1, 1)
    bill "Come on in."
    mc "Thanks."
    "Is that you, Pops?"
    scene 01_0363 with dissolve
    bill "Who else you expecting?"
    scene 01_0364 with dissolve
    bill "Mary, this is [mc], he's a new friend of mine!"
    mar "Hello."
    $ Mary.Activate("Mary")
    $ persistent.MaryLocked=False
    scene 01_0365 with dissolve
    mc "I thought Mary was your wife!"
    bill "My wife?! Mary's my granddaughter!"
    scene 01_0366 with dissolve
    mar "I'm very pleased to meet you, [mc]."
    scene 01_0367 with dissolve
    mc "Nice to meet you."
    bill "[mc]'s gonna stay the night, can you show him up to the spare room?"
    bill "I need to take a shower after that run!"
    scene 01_0368 with dissolve
    mar "Sure thing, Pops!"
    scene 01_0369 with dissolve
    bill "Once you've settled in, come back down and Mary can make you summat to eat if you're hungry."
    mc "That's not necessary.\nI'll just hit the hay, if that's okay with you."
    bill "Up to you, Son."
    scene 01_0370 with dissolve
    mar h "This way, follow me."
    mc "Yes Ma'am."
    mar "[giggles]"
    scene 01_0371 with dissolve
    mar "How'd you meet Pops?"
    mc "He, err... almost ran me over with his rig."
    mar "Oh dear!\nI keep telling him to get his eyes checked out!"
    scene 01_0372 with dissolve
    mar "I'm glad he didn't hit you!"
    scene 01_0373 with dissolve
    mc h "You and me both!"
    scene 01_0374 with dissolve
    mar "This is you. I'm across the hall, should you need anything."
    scene 01_0375 with dissolve
    mc "Thanks, Mary. I'll be fine."
    scene 01_0376
    mar "I don't know how comfortable the bed is.\nIt hasn't been slept on for a while."
    scene 01_0377 with dissolve
    mc "Better than a bench, I bet."
    mar "Huh?"
    mc "Heh. Never mind."
    if EzModeActive:
        call EzModeAsk ("Mary")
        if _return:
            $ Mary.Add("EZ")
    scene 01_0378 with dissolve
    mar "In town for long?\nI'm sure Pops would like the company. He doesn't have many friends!"
    mc "No. Only a quick visit."
    mar "Oh.\nWhere you from?"
    scene 01_0379 with dissolve
    mc "Not really from anywhere anymore."
    mc "Just left the military, got some shi... stuff, to figure out, I guess."
    scene 01_0380 with dissolve
    mar "My dad was a soldier!"
    mc "Yeah?"
    scene 01_0381 with dissolve
    mar "He died.\nIt was a long time ago; I don't remember him too much."
    scene 01_0382 with dissolve
    mc "Damn, I'm sorry, Mary. That sucks."
    scene 01_0383 with dissolve
    mc "I'm sure he was a great guy."
    scene 01_0384 with dissolve
    mar "Pops misses him a lot."
    mc "Bill takes care of you?"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e01/01_0385.webp", 866, 767, True, "Springhaven_AF05") with dissolve
        mar "Yeah, I guess."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0385
            hide screen imgMap
    else:
        scene 01_0385 with dissolve
        mar "Yeah, I guess."
        $ tCh=Mary.Has("EZ")
        if not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    $ tCh=True
                "Don't":
                    $ tCh=False
        if tCh:
            call Springhaven_AF05
    $ a=""
    if Mary.hasScore(1):
        $ a="a"
    $ persistent.MaryDaddy=False
    show expression "01_0389" + a with dissolve
    mar "Mom stops by now and then, but she's never been the same since Dad... you know."
    mar "You have family?"
    scene 01_0390 with dissolve
    mc "{i}Had{/i}."
    mc "Got divorced a few years back.\nI have a daughter, but we, uhh... don't get on."
    mar "Aww, that's a shame!"
    scene 01_0391 with dissolve
    mar "A daughter should always take care of her Daddy!"
    mar "I'm sure she'll come around. You're a good dad. I can tell."
    mc "You can?"
    mar "Yeah!"
    if Mary.hasScore(1):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0392.webp", 862, 769, True, "Springhaven_AF06") with dissolve
            mar "If you were {i}my{/i} daddy, I'd take good care of you!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0392
                hide screen imgMap
                mc "You would?"
                mar h "Of course!"
        else:
            scene 01_0392 with dissolve
            mar "If you were {i}my{/i} daddy, I'd take good care of you!"
            if EzModeActive and Mary.Has("EZ"):
                call Springhaven_AF06
            else:
                menu:
                    "[wk_y]Check her out again":
                        call Springhaven_AF06
                    "Don't":
                        mc "You would?"
                        mar h "Of course!"
    scene 01_0397 with dissolve
    mar "I'd better go prepare Pops' supper!\nHe'll be outta the shower soon."
    mar "You're welcome to join us."
    scene 01_0398 with dissolve
    mc "I'm good, thanks.\nJust need some rest."
    if persistent.MaryDaddy:
        scene 01_0399 with dissolve
        mar "Okay, goodnight..."
        scene 01_0400 with dissolve
        mar h "... Daddy."
        mc "Night, Mary."
        scene 01_0401 with dissolve
        mar "[kiss]"
    scene 01_0402 with dissolve
    if persistent.MaryDaddy:
        mar "See you in the morning!"
    else:
        mar "Night. See you in the morning."
    scene 01_0403 with Fade(1, 0.5, 0.5)
    pause
    scene 01_0404 with Fade(1, 0.5, 0.5)
    mct "Oh yeah. Definitely comfier than a bench."
    if not Mary.hasScore(1):
        scene 01_0405 with Fade(2, 1, 2)
        call Emotion (mc, "Snore", "...ZzzzZZzz...")
        jump Springhaven_WakeupBills
    scene black with Fade(2, 1, 2)
    call CenterText ("An hour or so later...", False)
    scene 01_0406 with fade
    pause
    scene 01_0407 with dissolve
    mct "Ughh..."
    mct "... So tired, must've dozed off."
    play sound "creak.mp3" volume 0.5
    "{size=*0.5}*Creak* {w=0.5}{nw}"
    scene 01_0408 with dissolve
    mc "[whi]Huh?"
    call AutoA
    scene 01_0409 with dissolve
    $ apause()
    scene 01_0410 with dissolve
    call AutoA (False)
    mct "Was that... Mary?"
    $ tmpCh=None
    if not EzModeActive:
        menu:
            "Close the door and go to bed":
                pass
            "[wk_y]Leave the door open and get undressed":
                $ tmpCh=True
    if not tmpCh and not Mary.Has("EZ"):
        call AutoA
        scene 01_0411 with dissolve
        $ apause()
        scene 01_0412 with dissolve
        play sound "closedoor.mp3"
        $ apause()
        call AutoA (False)
        scene 01_0405 with Fade(2, 1, 2)
        call Emotion (mc, "Snore", "...ZzzzZZzz...")
        jump Springhaven_WakeupBills
    call AutoA
    scene 01_0413 with dissolve
    $ apause(1)
    scene 01_0414 with dissolve
    $ apause(2)
    scene 01_0415 with dissolve
    $ apause(1)
    scene 01_0416 with dissolve
    $ apause(1)
    $ tmpCh=None
    if not EzModeActive:
        menu:
            "Keep underwear on":
                pass
            "[wk_y]Remove underwear":
                $ tmpCh=True
    if not tmpCh and not Mary.Has("EZ"):
        scene 01_0420 with dissolve
        $ apause(1)
        scene 01_0418 with dissolve
        call AutoA (False)
        mar "[whi]Hot damn."
        call Springhaven_MaryRun
        scene 01_0424 with dissolve
        mct "Night, Mary!"
        scene 01_0405 with Fade(2, 1, 2)
        call Emotion (mc, "Snore", "...ZzzzZZzz...")
        jump Springhaven_WakeupBills
    scene 01_0417 with dissolve
    $ apause(1)
    scene 01_0418 with dissolve
    $ apause(1)
    scene 01_0419 with dissolve
    call AutoA (False)
    mar "{size=*.6}{font=Vanilla.ttf}*{i}Gasp{/i}*"
    scene 01_0421 with dissolve
    mar "[whi]Oh, my..."
    scene 01_0425 with dissolve
    mct "What the hell am I doing?!"
    call AutoA
    scene 01_0426 with dissolve
    $ apause(1)
    scene 01_0427 with dissolve
    $ apause(1)
    scene 01_0425 with dissolve
    call AutoA (False)
    $ tmpCh=None
    if not EzModeActive:
        menu:
            "Get into bed and sleep":
                pass
            "[wk_y]Start masturbating":
                $ tmpCh=True
    if not tmpCh and not Mary.Has("EZ"):
        scene 01_0405 with Fade(2, 1, 2)
        call Emotion (mc, "Snore", "...ZzzzZZzz...")
        jump Springhaven_WakeupBills
    mct "Fuck it!\nIf she wants to peep, I'll give her a show..."
    call AutoA
    scene 01_0428 with dissolve
    $ apause()
    scene 01_0429 with dis1
    $ apause()
    scene 01_0430 with dissolve
    call AutoA (False)
    mar "{size=*.6}{font=Vanilla.ttf}*{i}GASP{/i}*"
    if Mary.hasScore(3):
        call MaryReplay01_Part01
        if Mary.Has("Ran"):
            scene 01_0431 with dissolve
            mc "Guess not."
            mc "Oh well, may as well finish before going to sleep!"
            scene 01_0405 with Fade(2, 1, 2)
            call Emotion (mc, "Snore", "...ZzzzZZzz...")
            jump Springhaven_WakeupBills
        else:
            scene 01_0405 with Fade(2, 1, 2)
            call Emotion (mc, "Snore", "...ZzzzZZzz...")
            jump Springhaven_WakeupBills
    else:
        call Springhaven_MaryRun
        scene 01_0431 with dissolve
        mc "[lol] Probably took it too far!"
        mc "Oh well, may as well finish before going to sleep!"
        scene 01_0405 with Fade(0, 0, 2)
        call Emotion (mc, "Snore", "...ZzzzZZzz...")
        jump Springhaven_WakeupBills
return

label Springhaven_MaryRun:
    call AutoA
    $ Mary.Add("Ran")
    scene 01_0422 with dissolve
    $ apause(0.25)
    scene 01_0423 with dissolve
    $ apause(0.25)
    call AutoA (False)
return

label Springhaven_WakeupBills:
    scene black with Fade(2, 0, 0)
    call CenterText ("The next morning.", False)
    scene 01_0504 with fade
    scene 01_0505 with dis1
    call Emotion (mc, "Groan", "")
    $ aaa=""
    if Mary.Has("Stay"):
        $ aaa="a"
    show expression "01_0506" + aaa with Fade(2, 1, 1)
    mc "Mornin'."
    mar "Oh, great! You're up!"
    mc "Bill not around?"
    show expression "01_0507" + aaa with dissolve
    mar "I sent him to the store to get him outta my hair for a while."
    mar "Coffee?"
    mc "Yeah, thanks."
    show expression "01_0508" + aaa with dissolve
    mar "Did you sleep okay?"
    mc "Great!\nIt's so quiet out here."
    show expression "01_0509" + aaa with dissolve
    mar "There ain't another house for miles!"
    mar h "No people either!\nI can go weeks without seeing anyone but Pops!"
    scene 01_0510 with dissolve
    mc "Sounds kinda lonely."
    mar "No, it's how it's always been."
    show expression "01_0511" + aaa with dissolve
    if Mary.Has("Stay"):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0511a.webp", 920, 475, True, "Springhaven_AF07") with dissolve
            mar "Don't know any different."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0511a
                hide screen imgMap
        else:
            scene 01_0511a with dissolve
            mar "Don't know any different."
            call Springhaven_AF07
    else:
        scene 01_0511 with dissolve
        mar "Don't know any different."
    show expression "01_0513" + aaa with dissolve
    if Mary.Has("Ran") or Mary.Has("Stay"):
        mc "Uhh... About last night..."
        if Mary.Has("Stay"):
            scene 01_0514a with dissolve
            mar "Umm... Last night?"
            mar "I... I... Uhh..."
            mc "It was, err... just a bit of fun, right?"
            scene 01_0515 with dissolve
            mar "Oh!"
            mar "Yeah, it was!"
            scene 01_0516 with dissolve
            mar "It was so much fun that I couldn't sleep for hours!\nJust kept thinking about it!"
            scene 01_0517 with dissolve
            mar "You ain't gonna tell Pops I was spyin', right?"
            mc h "Nah, it's our little secret."
            scene 01_0518 with dissolve
            mar "[whi]Our little secret..."
            scene 01_0519 with dissolve
            mar "I like that!"
            scene 01_0520 with dissolve
            mar h "[whi]{i}Our little secret{/i}."
            scene 01_0521 with dissolve
            mar "[kiss]"
            scene 01_0522 with dissolve
            mar "I'm gonna cook you breakfast."
            mc "No, you don't..."
            mar h "Ain't takin' no for an answer!"
        else:
            scene 01_0514 with dissolve
            mar "Umm... Did something happen last night?"
            mar "I... I wouldn't know. I went straight to bed!"
            mc "Uhh... Okay."
            scene 01_0523 with dissolve
            mar "I'm gonna cook you breakfast."
            mc "No, you don't..."
            mar h "Ain't takin' no for an answer!"
    else:
        mar "Here you go."
        mc "Thanks."
        scene 01_0523 with dissolve
        mar "I'm gonna cook you breakfast."
        mc "No, you don't...{w=1.0}{nw}"
        mar h "Ain't takin' no for an answer!"
    show expression "01_0524" + aaa with Fade(2, 1, 1)
    mc h "Wow, Mary! That was delicious!\nI'm stuffed!"
    if Mary.Has("Stay"):
        scene 01_0525a with dissolve
        mar "OH SHOOT! Pops is back!"
        call AutoA
        scene 01_0526 with dissolve
        $ apause(0.25)
        scene 01_0527 with dissolve
        $ apause(0.25)
        scene 01_0528 with dissolve
        $ apause(0.25)
        call AutoA (False)
    else:
        scene 01_0525 with dissolve
        mar "Pops is back."
    scene 01_0529 with fade
    bill "Mornin', Son.\nGlad to see Mary made you breakfast."
    mc "Mornin' Bill."
    if not Mary.Has("Stay"):
        scene 01_0530 with dissolve
        mar "Of course I did, Pops!"
    scene 01_0531 with dissolve
    bill "I'll drive you into town if you're ready to go."
    mc "You sure? Don't mind walking."
    bill "Nah, it's fine."
    scene 01_0532 with dissolve
    mc "That'll be great, Bill. Appreciate it."
    if not Mary.Has("Stay"):
        scene 01_0533 with dissolve
        mar "Aww! You're leaving so soon?"
        mc "Uh, yeah, sorry.\nI have something important I need to do."
    else:
        scene 01_0533a with dissolve
        mar "You're leaving? So soon?"
        scene 01_0534 with dissolve
        mc "Uh, yeah, sorry.\nI have something important I need to do."
    scene 01_0535 with Fade(2, 1, 1)
    bill "Ready?"
    mc "Yeah."
    scene 01_0536 with dissolve
    mc "Bye, Mary."
    mar "[whi]Bye."
    scene 01_0537 with dissolve
    pause 1.0
    mar "Wait!"
    scene 01_0538 with dissolve
    mar "We should get your cell number!"
    mar "... For, uhh... For Pops!"
    scene 01_0539 with dissolve
    mar "Friends should have each other's numbers!"
    bill "I guess it wouldn't hurt.\nIf you need to get back to Lakeshore, I do that run often."
    bill "Happy to have you along for the company."
    mc "Uhh, sure."
    scene 01_0540 with fade
    mar "Come visit us again soon!"
    $ Mary.Add("Cell")
    scene 01_0541 with Fade(3, 1, 1)
    play sound "truck04.mp3"
    mc "Anywhere here will be great, Bill."
    scene 01_0542 with dissolve
    bill "Meant what I said back at the house."
    bill "If you need a ride back to Lakeshore..."
    mc "Thanks.\nMight take you up on it."
    scene 01_0543 with dissolve
    bill "Sure my Mary would love to see you again, too."
    bill "Thinkin' she's taken a bit of a shine to you, Son. [lol]"
    scene 01_0544 with dissolve
    mc "She's very sweet. You must be proud of her."
    bill "Damn straight!"
    scene 01_0545 with dissolve
    mc "Thanks, Bill. See ya 'round."
    bill "Look after yourself, Kid."
    play sound "truck02.mp3" volume 0.5
    scene 01_0546 with dissolve
    pause 1.0
    jump Springhaven_Delivery
return

label Springhaven_Park:
    call AutoA
    scene 01_0547 with Fade(3, 0, 1)
    stop sound
    $ apause(1)
    scene 01_0548 with Fade(1, 0, 1)
    $ apause(1)
    scene 01_0549 with Fade(1, 0, 1)
    call AutoA (False)
    mct "Not exactly what I had in mind, but guess it'll do."
    scene 01_0550 with dissolve
    call AutoA
    $ apause(1)
    scene 01_0551 with dissolve
    call AutoA (False)
    mct "Good enough."
    scene 01_0552 with dissolve
    call AutoA
    $ apause(1)
    scene 01_0553 with Fade(2,0,2)
    $ apause(1)
    scene 01_0554 with Fade(2,0,2)
    $ apause(1)
    scene black with Fade(2,0,3)
    $ apause(2)
    call AutoA (False)
    call CenterText ("Daybreak.", False)
    $ Alysha_name="Police Officer"
    $ Alysha.Add("park")
    scene 01_0555 with Fade(0,0,2)
    "Hey!{w=1.0}{nw}"
    scene 01_0556 with dissolve
    "Hey, {b}Buddy{/b}!{w=1.0}{nw}"
    scene 01_0557 with dissolve
    "Mornin', Princess.{w=1.0}{nw}"
    scene 01_0558 with dissolve
    aly "Can't sleep here."
    scene 01_0559 with dissolve
    mc "Uh, sorry."
    aly "New in town?\nLoitering's a crime in this state."
    mc "Yeah.\nGot here late, couldn't find anywhere to stay."
    scene 01_0560 with dissolve
    aly "Where you from?"
    mc "Don't worry, Officer. I'm not here to cause trouble.\nJust passin' through."
    aly "Good to hear.\nOkay, on your way."
    scene 01_0561 with dissolve
    aly "Don't let me find you here again.\nNext time, I'll have to arrest you."
    mc "Understood."
    jump Springhaven_Delivery
return

label Springhaven_Delivery:
    scene 01_0562 with Fade(2, 0.5, 1)
    call AutoA
    $ apause()
    scene 01_0563 with Fade(1, 0.5, 1)
    $ apause()
    scene 01_0564 with Fade(1, 0.5, 1)
    $ apause()
    scene 01_0565 with Fade(1, 0.5, 1)
    $ apause()
    scene 01_0566 with Fade(1, 0.5, 1)
    $ apause()
    scene 01_0567 with dis1
    $ apause()
    scene 01_0568 with dis1
    play sound "knock.mp3"
    $ apause()
    scene 01_0569 with dissolve
    $ apause(1)
    scene 01_0570 with dissolve
    $ apause(1)
    scene 01_0571 with dissolve
    call AutoA (False)
    "Hello? Can I help..."
    scene 01_0572 with dissolve
    car "HOLY SHIT!"
    scene 01_0573 with dissolve
    car "UNCLE [mc!u]!!"
    scene 01_0574 with dissolve
    mc "Hey, Pipsqueak!"
    $ Cara.Activate("Cara")
    $ persistent.CaraLocked=False
    scene 01_0575 with dissolve
    mc h "Damn! You've grown!"
    car "I'm not a kid anymore!"
    if persistent.Incest:
        if EzModeActive:
            call EzModeAsk ("Cara")
            if _return:
                $ Cara.Add("EZ")
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Give her a bear hug":
                    $ tCh=True
                "Grab her butt":
                    pass
        if tCh or EzModeActive:
            if tCh or Cara.Has("EZ"):
                $ Cara.Score(1)
                scene 01_0579 with dissolve
                mc "Never too old for an Uncle [mc] hug!"
                car h "[giggles]"
                scene 01_0580 with dissolve
                car h "You grabbing my ass to stop me falling, or for a quick grope?"
                mc h "Stop you falling, {b}obviously{/b}!"
                scene 01_0581 with dissolve
                car "I can't believe you're here!!"
            scene 01_0582 with dissolve
            car "Come on in!"
        else:
            $ Cara.Score(-1)
            scene 01_0576 with dissolve
            mc h "I can see that!"
            scene 01_0577 with dissolve
            car sh "Whoa! What the hell?!"
            mc h "I'm teasing you!"
            scene 01_0578 with dissolve
            car a "[whi]Perv!"
            mc h "It was a joke!"
    else:
        scene 01_0579 with dissolve
        mc "Never too old for an Uncle [mc] hug!"
        car "[giggles]"
        scene 01_0581 with dissolve
        car "I can't believe you're here!!"
        scene 01_0582 with dissolve
        car "Come on in!"
    scene 01_0583 with dissolve
    car "Mom! It's okay.\nYou'll never guess who it is!"
    scene 01_0584 with fade
    ali "Who was it?"
    scene 01_0585 with dissolve
    mc "Hi, Alison."
    ali sh "OH MY GOD!"
    $ Alison.Activate("Alison")
    $ persistent.AlisonLocked=False
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0586.webp", 956, 820, False, "Springhaven_AF08") with dissolve
            ali "[mc!u]!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0586
                hide screen imgMap
                scene 01_0590 with dissolve
                ali "Cara, can you get dressed, please, Sweetheart?\nWe have company and your butts showing!"
                if not Cara.hasScore(0):
                    scene 01_0589 with dissolve
                    car "I was {i}just{/i} about to, Mom."
                else:
                    scene 01_0591 with dissolve
                    car h "Ohh, Mom! It's only Uncle [mc]!\nI'm sure he doesn't mind seeing my ass!"
                    ali "Go!"
                    scene 01_0592 with dissolve
                    car "UGGH!! Fine!"
        else:
            scene 01_0586 with dissolve
            ali "[mc!u]!"
            $ tCh=None
            if not EzModeActive:
                menu:
                    "Check Cara out":
                        pass
                    "[wk_y]Don't":
                        $ tCh=True
            if not tCh and not EzModeActive:
                call Springhaven_AF08
            else:
                ali "Cara, can you get dressed, please, Sweetheart?\nWe have company and your butts showing!"
                if not Cara.hasScore(0):
                    scene 01_0589 with dissolve
                    car "I was {i}just{/i} about to, Mom."
                else:
                    scene 01_0591 with dissolve
                    car h "Ohh, Mom! It's only Uncle [mc]!\nI'm sure he doesn't mind seeing my ass!"
                    ali "Go!"
                    scene 01_0592 with dissolve
                    car "UGGH!! Fine!"
    else:
        scene 01_0586 with dissolve
        ali "Cara, can you get dressed, please, Sweetheart?\nWe have company and your butts showing!"
        scene 01_0591 with dissolve
        car h "Ohh, Mom! It's only Uncle [mc]!\nI'm sure he doesn't mind seeing my ass!"
        ali "Go!"
        scene 01_0592 with dissolve
        car "UGGH!! Fine!"
    scene 01_0593 with dissolve
    ali "It's good to see you! It's been so long!"
    scene 01_0594 with dissolve
    mc "Sorry for just showing up and for it being so early."
    scene 01_0595 with dissolve
    ali "What are you doing here? Is everything okay?"
    mc "Yeah, everything's fine."
    scene 01_0596 with dissolve
    mc "I, uhh... have something for you."
    scene 01_0597 with dissolve
    ali "You came all the way out here to bring me something?"
    mc "Yeah."
    scene 01_0598 with dissolve
    mc "[whi]Here."
    ali "What is it?"
    mc "It's... uhh, from Pete."
    scene 01_0599 with dissolve
    ali "Pete??"
    ali "I don't understand..."
    mc "He made me promise to give you this if anything happened to him."
    scene 01_0600 with dissolve
    ali "[mc], he died {b}two years{/b} ago!"
    mc "I know, I'm sorry.\nIt's the first time I've been home since it...err.. you know."
    ali "Is that why you weren't at his service?\nIt must've been important for you to miss your best friend's funeral."
    mc "Uhh..."
    scene 01_0601 with dissolve
    ali "Yeah, I know. You can't talk about it!"
    ali "You fuckin' guys and your code of silence."
    scene 01_0602 with dissolve
    ali "They wouldn't even tell me {i}how{/i} he died! Will {i}you{/i} tell me?"
    ali "No! Of course you won't."
    scene 01_0603 with dissolve
    mc "He died saving my life."
    mc "We were on an op. He was covering me, as usual."
    mc "It all went south.\nI was in trouble; he gave away his position helping me."
    scene 01_0604 with dissolve
    mc "By the time I got to him... I was too late."
    mc "It was {i}my{/i} fault, Alison...."
    mc "You lost your husband. Cara lost her father... Because I fucked up."
    scene 01_0605 with dissolve
    ali "You two were more than best friends, [mc].\nYou were like brothers."
    ali "He wouldn't have wanted to go any other way."
    mc "I'm sorry, Alison."
    scene 01_0606 with dissolve
    ali "Oh, [mc]... I lost Pete {i}long{/i} before he died."
    mc "What do you mean?"
    scene 01_0607 with dissolve
    ali "He told you we were getting divorced, right?"
    mc "Uh, no."
    ali "Oh."
    scene 01_0608 with dissolve
    ali "Guess I wasn't the {i}only one{/i} he was keeping secrets from."
    scene 01_0609 with dissolve
    ali "But you knew about the other women? The gambling?"
    mc "Err... I knew he liked hanging out with women occasionally, but he was just blowin' off steam..."
    mc "They didn't mean anything. He loved {i}you{/i}."
    scene 01_0610 with dissolve
    mc "And, gambling?"
    mc "I mean, sure. Now and then. Just a bit of fun!"
    scene 01_0611 with dissolve
    ali "{i}A bit of fun{/i}?!!\nYou're fuckin' kidding me, right?"
    mc "What? I don't understand."
    scene 01_0612 with dissolve
    ali "I'm sorry, [mc].\nForget about it. It's not your problem."
    mc "What isn't? Alison?"
    ali "Nothing.\nIt's nothing. I guess I'm still angry with him."
    scene 01_0613 with dissolve
    mc "I didn't come here to upset you."
    scene 01_0614 with dissolve
    mc "[whi]... I made him a promise."
    scene 01_0615 with dissolve
    mc "I'll... leave this here, and go."
    scene 01_0616 with dissolve
    pause 0.5
    scene 01_0617 with dissolve
    ali "[mc], Wait!"
    scene 01_0618 with dissolve
    ali "Don't go. Please."
    ali "I'm making coffee. Take a seat."
    scene 01_0619 with Fade(1, 0.5, 0.5)
    ali "How long have you been back?"
    mc "Yesterday."
    ali "Oh.\nHow long's your leave?"
    mc "Permanent. I've quit."
    scene 01_0620 with dissolve
    ali "Hah!\nYeah, right."
    scene 01_0621 with dissolve
    ali "Wait... Are you being serious??"
    mc "Yeah."
    scene 01_0622 with dissolve
    ali "Shit!"
    ali "What happened??\nI always thought you'd be the last person to quit the unit!"
    mc "I was. The rest are dead."
    scene 01_0623 with dissolve
    ali "Fuck!"
    ali "[mc]! I'm so sorry."
    ali "But still, you'd get new guys, right?\nEveryone wanted in on your squad!"
    mc "I woke up one morning, figured I'd had enough. I was done."
    scene 01_0624 with dissolve
    ali "Wow!\nSo, what are you gonna do?"
    mc "Haven't thought about it, to be honest."
    mc "I, err... I have another letter to deliver."
    scene 01_0625 with dissolve
    ali "To his {i}lover{/i}, I bet?\nI know the bastard was cheating on me."
    mc "No!\nIt's for... Nettie."
    scene 01_0626 with dissolve
    ali "Nettie?!"
    ali "Pete and his sister hadn't spoken in {b}years{/b}!\nWhy would he write her a letter??"
    mc "I don't know."
    mc "Any idea where I can find her?"
    scene 01_0627 with dissolve
    ali "Last time I saw her was at Pete's funeral. I think she mentioned... Uhh... Cedar Grove."
    mc "It's a start at least - more than I had."
    scene 01_0628 with dissolve
    car "Are you gonna visit Millie while you're back?"
    mc "I... don't think she'd want to see {i}me{/i}."
    scene 01_0629 with dissolve
    ali "[mc], she's your daughter! Of course she'll want to see you!"
    mc "Things haven't been good between us since her mom and I divorced."
    ali "Still, you {i}have{/i} to make the effort!"
    scene 01_0630 with dissolve
    car "She talks about you a lot. She misses you!"
    mc "She does?"
    mc "Wait... you've seen her??"
    car h "No, but we text each other all the time!"
    scene 01_0631 with dissolve
    ali "You should visit her, [mc]."
    mc "Yeah. I guess."
    scene 01_0632 with dissolve
    mc h "So, what you been up to, Pipsqueak?\nStill gettin' into trouble?"
    scene 01_0633 with Fade(3, 2, 2)
    pause 1.0
    scene 01_0634 with dissolve
    ali "It was {i}really{/i} good to see you, [mc]."
    mc "You, too."
    ali "Take care, and remember, you're welcome here anytime!"
    mc "You have my number. If you need {i}anything{/i}, call me."
    ali "I will, thanks."
    scene 01_0635 with fade
    mc "Bye, Pipsqueak."
    car "Bye, Uncle [mc]."
    call AutoA
    scene 01_0636 with fade
    $ apause(1)
    scene 01_0637 with dis1
    $ apause(1)
    scene 01_0638 with fade
    $ apause(1)
    call AutoA (False)
    jump Springhaven_Cemetry
return

label Springhaven_Cemetry:
    call CenterText ("Later that day.", True)
    scene 01_0639 with fade
    mc "[whi]Miss you, Buddy."
    scene 01_0640 with fade
    mc "[whi]Should be me in there, not you."
    $ Alysha_name="Police Officer"
    scene 01_0641 with dissolve
    aly "You talk to them, too, huh?"
    scene 01_0642 with dissolve
    mc "Excuse me?"
    aly "The dead."
    aly "You speak to them, too."
    mc "Uh, yeah. Guess so."
    scene 01_0643 with dissolve
    aly "I'm sorry.\nIt was rude of me to disturb you; forgive me."
    mc "It's okay. I was leaving anyway."
    scene 01_0644 with dissolve
    if Alysha.Has("Park"):
        aly "Wait. Do I know you?"
        mc "Nope."
        scene 01_0645 with dissolve
        aly "Yeah, I do. This morning at the park, that was you."
        aly "Not heading back there, I hope?"
        mc "No, about to leave town."
        aly "Okay.\nHave a good day, sir."
        mc "You, too."
    else:
        aly "Have a good day, sir."
        mc "You, too."
    scene 01_0646 with dissolve
    aly "I should get back to work, Pa.\nSee you tomorrow."
    scene 01_0647 with Fade(2, 1, 3)
    pause 1.0
    call CenterText ("Three hours later...", False)
    scene 01_0648 with fade
    call AutoA
    $ apause()
    play sound "bus.mp3"
    scene 01_0649 with dis1
    $ apause()
    scene 01_0650 with dis1
    $ apause()
    scene 01_0651 with dis1
    $ apause()
    scene 01_0652 with dis1
    $ apause()
    scene 01_0653 with dis1
    $ apause()
    scene 01_0654 with dis1
    $ apause()
    scene 01_0655 with Fade(2, 1, 2)
    $ apause(1)
    play sound "vib.mp3"
    $ apause(1)
    scene 01_0656 with dissolve
    $ apause()
    play sound "bus02.mp3" loop
    scene 01_0657 with dissolve
    call AutoA (False)
    mc cell "Alison? Wasn't expecting to..."
    ali cell "[mc!u]! Are you still in the city?"
    mc "Uhh, kinda. I'm on a bus about..."
    ali cell "I can't get a hold of Cara!"
    scene 01_0658 with dissolve
    mc cell "Huh?"
    ali cell "I'm worried, [mc]! She {b}always{/b} answers her cell!"
    mc cell "I'm sure she's fine! Maybe she's out of range?"
    ali cell "Something's wrong! I know it!"
    ali cell "Can you find her?\nPlease, [mc]! I... I didn't know who else to call!"
    scene 01_0659 with dissolve
    mc cell "Aren't you overreacting a little?"
    ali cell "NO!\nYou... don't know what's been going on!"
    ali cell "They might've hurt her!"
    mc cell "Who??"
    ali cell "Please, [mc]!\nI'm begging you!! HELP ME!"
    scene 01_0660 with dissolve
    mc cell "Okay, okay. Don't worry.\nI'll find her and bring her home."
    mc cell "Where was she going?"
    ali cell "She was meeting Alex at the bar. I'll text you the address."
    mc cell "I'll go straight there."
    ali cell "Thank you. PLEASE HURRY!"
    stop sound fadeout 1.0
    jump Springhaven_DiveBar01
return

label Springhaven_DiveBar01:
    $ renpy.music.set_volume(0.05)
    $ renpy.music.play("bar01.mp3", channel='music', fadein=6)
    scene 01_0661 with Fade(2, 3, 2)
    call AutoA
    $ apause(1)
    scene 01_0662 with dissolve
    $ apause(1)
    scene 01_0663 with dissolve
    call AutoA (False)
    mct "There she is... Without a care in the world."
    mc "CARA!"
    scene 01_0664 with dissolve
    car "Uncle [mc]!?"
    car "What are you doin' here?"
    scene 01_0665 with dissolve
    mc "Lookin' for you!"
    mc "Your mom's going crazy with worry!"
    scene 01_0666 with dissolve
    car "Ehh?? Why?"
    mc "You didn't answer your phone."
    scene 01_0667 with dissolve
    car "Huh?\nBut it hasn't rung? Not even once!\nWhat's she talking about?"
    scene 01_0668 with dissolve
    car "Did you hear my phone ring?"
    alex "No."
    scene 01_0669 with dissolve
    car "Uhh... Where is it?"
    barman "Anything I can get you?"
    scene 01_0670 with dissolve
    mc "Uh, no thanks."
    mc "Kinda quiet in here."
    barman "Still early."
    scene 01_0671 with dissolve
    barman "Come back in a couple of hours!\nTrust me, you won't be able to move!"
    mc "I'll take your word for it."
    scene 01_0672 with dissolve
    car "WHERE THE HELL IS IT??!"
    alex "Are you sure you had it with you?\nI haven't seen you use it since we got here."
    scene 01_0673 with dissolve
    car "Yes!\nI grabbed it just as..."
    scene 01_0674 with dissolve
    car "Shit!..."
    car "I forgot to get it before I left!\nIt's still in my bedroom, charging!"
    scene 01_0675 with dissolve
    mc "Here. Call your mom and tell her you're okay."
    car "Yeah.\nFuck, she's gonna be so pissed!"
    scene 01_0676 with fade
    car "I'm fine, Mom!\nI'm so sorry!"
    alex "So you're Uncle [mc], huh?"
    scene 01_0677 with dissolve
    mc "Uh, yeah. You must be Alex?"
    alex "I sure am!"
    $ Alex.Activate("Alex")
    $ persistent.AlexLocked=False
    if EzModeActive:
        call EzModeAsk ("Alex")
        if _return:
            $ Alex.Add("EZ")
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e01/01_0678.webp", 982, 749, True, "Springhaven_AF09") with dissolve
        alex h "Jeez! Cara was right about you!\nYou {i}are{/i} cute!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0678
            hide screen imgMap
            mc "{b}Cara{/b} said that?"
    else:
        scene 01_0680 with dissolve
        alex h "Jeez! Cara was right about you!\nYou {i}are{/i} cute!"
        if not EzModeActive:
            menu:
                "[wk_y]Take a closer look":
                    call Springhaven_AF09
                "Don't":
                    mc "{b}Cara{/b} said that?"
        elif Alex.Has("EZ"):
            call Springhaven_AF09
        else:
            mc "{b}Cara{/b} said that?"
    scene 01_0680 with dissolve
    alex "What?... Uh, no..."
    alex "Shit!... Yeah, but don't tell her I told you!"
    scene 01_0681 with dissolve
    alex "I always thought it was weird that she had a crush on her {i}Uncle{/i}, but I get it now!"
    mc "I'm not... I'm not her {i}real{/i} uncle. I'm just a family friend."
    alex h "OHH!\nOkay, that makes more sense!"
    scene 01_0682 with dissolve
    car "I need to go home, my mom's still freaking."
    mc "Come on, I'll walk you back."
    car "Thanks, Uncle [mc]."
    scene 01_0683 with dissolve
    car "Alex, you coming?"
    alex "Mmh-hmm."
    scene 01_0684 with dissolve
    car "She lives close to me."
    mc "Okay."
    scene 01_0685 with dissolve
    mc "Does the barman know you're underage?"
    car "Shh!\nDon't say anything! We have fake IDs!"
    car "We only have one or two while we play pool. I swear!"
    stop music fadeout 1.0
    scene 01_0686 with fade
    mc "So what's goin' on with your mom?\nWhy's she in panic mode?"
    car "Uh, she won't talk to me about it."
    car "All I know is it has something to do with Dad, and she's {i}always{/i} frightened."
    scene 01_0687 with dissolve
    mc "You often hang out in bars like that?"
    car "Only that one. We go to play pool, not to drink beer!"
    scene 01_0688 with dissolve
    alex h "And one day you may even beat me![lol]"
    car h "Shut up!"
    car h "I swear! One of these days, it's gonna happen, Alex!"
    scene 01_0689 with Fade(2, 0.5, 1)
    alex "You have a girlfriend, [mc]?"
    car "Alex!"
    alex h "I'm only asking!"
    scene 01_0690 with dissolve
    mc "No, I don't."
    alex "You into girls with tats?"
    car "Oh, jeez!"
    if not EzModeActive:
        menu:
            "Nah, not really my thing[wk_c]":
                call CloseCharacterPath (Alex, "Alex")
            "[wk_y]Depends on the girl":
                scene 01_0691 with dissolve
                alex h "Hmm, interesting."
    else:
        if Alex.Has("EZ"):
            mc "Depends on the girl."
            scene 01_0691 with dissolve
            alex h "Hmm, interesting."
        else:
            mc "Nah, not really my thing."
            call CloseCharacterPath (Alex)
    scene 01_0692 with fade
    alex "This is my stop.\nNice meeting you, [mc]!"
    mc "You, too."
    car "See you tomorrow, Alex."
    alex "Night, guys!"
    scene 01_0693 with dissolve
    car h "Sorry, Uncle [mc]!\nOne drop of booze and she turns into a horn dog!"
    mc h "[lol]"
    if Alex.isActive() and Alex.hasScore(1):
        $ Alex.Add("Flash")
        scene 01_0694 with dissolve
        alex h "Hey. {i}Uncle [mc]{/i}!"
        scene 01_0695 with dissolve
        alex h "I know you've been dyin' to see 'em!"
        scene 01_0696 with dissolve
        alex "[lol]{w=1.0}{nw}"
        scene 01_0697 with dissolve
        car su "ALEX!!\nSo embarrassing!"
    scene 01_0698 with fade
    mc "So, pool, huh?"
    car "Yeah! You ever played?"
    mc "Hell, yeah! Your dad and I would play all the time!"
    scene 01_0699 with dissolve
    car "Really?? You good?"
    mc h "Damn right! I'd beat him every time!"
    car "Oh my God!\nCan you teach me?!"
    scene 01_0700 with dissolve
    mc "What? No! It takes a lot of {b}practice{/b}!\n Can't just {i}teach{/i} someone to be good at it."
    car "Oh, please, Uncle [mc]!\nI just wanna beat her {b}ONCE{/b}!!\nShe never shuts up about it!"
    car h "PLLEEEAASSSEEE!!!"
    scene 01_0701 with dissolve
    mc h "Jeez... I'll think about it."
    car h "Yes! You're the best!"
    scene 01_0702 with Fade(1, 1, 2)
    car "I'm {i}so{/i} sorry, Mom."
    ali "You're okay, that's all that matters."
    scene 01_0703 with dissolve
    car "I'm gonna get ready for bed."
    ali "Okay, Sweetie."
    scene 01_0704 with dissolve
    ali "Thank you, [mc].\nI don't know what I would've done had you not been in town."
    ali "I'm sorry for the false alarm."
    mc "What's going on, Alison?"
    scene 01_0705 with dissolve
    ali "Jesus, how long you got?"
    mc "All night.\nI was on the last bus outta here when you called."
    ali "Crap, I'm so sorry!\nYou can stay here, you know that."
    mc "Thanks."
    ali "Okay, I'll get you a drink... I think you're gonna need one."
    scene 01_0706 with Fade(1, 0.5, 0.5)
    pause 1.0
    scene 01_0707 with dissolve
    ali "It's been a long time since we've had a beer together!"
    scene 01_0708 with dissolve
    ali "It all started a couple of days after the funeral."
    ali "A couple of shady-looking guys turned up looking for Pete."
    ali "I told them I'd just buried him.\nThey wouldn't believe me at first, but eventually..."
    ali "Anyway, they told me..."
    scene 01_0709 with dissolve
    ali "... Pete owed them money. A {b}lot{/b} of money."
    ali "He borrowed from them and gambled it all away."
    mc "Damn! I had no idea."
    ali "They said his debt was now {i}my{/i} debt!"
    scene 01_0710 with dissolve
    ali "I told them to get lost! To get the hell out of my house!"
    ali "They started threatening me!\nTold me {i}not{/i} paying wasn't an option."
    ali "They told me... bad things would happen to me, to Cara.\nShit like that."
    scene 01_0711 with dissolve
    mc "How much money are we talkin' here?"
    scene 01_0712 with dissolve
    ali "It started at twenty-seven thousand."
    mc sh "What?!"
    ali "I've been trying to pay them.\nI even tried to sell the house!"
    ali "I give them everything I have when they show up."
    ali "But they keep adding interest!\nThe last time they were here, it had gone up to thirty-four!"
    scene 01_0713 with dissolve
    mc "What the fuck?!"
    mc "Pete borrowed that much?? For gambling?!"
    scene 01_0714 with dissolve
    ali "He was an addict, [mc]!\nHe did a damn good job hiding it, too!"
    ali "So, when I rang Cara earlier and she didn't pick up..."
    scene 01_0713 with dissolve
    mc "Panic mode."
    ali "Yeah."
    mc "Who are these guys?"
    ali "I don't know."
    ali "I have no idea how Pete even got involved with them."
    scene 01_0715 with dissolve
    mc "When are they coming back?"
    ali "They show up whenever they want.\nI thought it was them this morning when you knocked on the door!"
    mc "You've both been going through this for two years??"
    ali "Yeah."
    ali "I've tried to shield Cara from it as much as possible, but she's not stupid. She knows {i}something's{/i} up."
    scene 01_0716 with dissolve
    mc "You need to tell me {b}everything{/b} you know about these assholes."
    scene 01_0712 with dissolve
    ali "No. It's not your problem, [mc].\nI'm not dragging you into it."
    scene 01_0716 with dissolve
    mc "They threatened... Cara. They threatened you.\n{b}I'M{/b} making it my goddamn problem."
    mc "Tell me EVERYTHING you know, Alison."
    scene 01_0717 with dissolve
    ali "[whi]Okay."
    scene 01_0718 with Fade(2, 1, 1)
    ali "That's it. That's all I know."
    mc "It's not a lot to go on, but don't worry.\nI'm gonna deal with it."
    scene 01_0712 with dissolve
    ali "Thanks, [mc].\nI didn't want to involve you. It's not your mess."
    mc "It's not {i}yours{/i} either!"
    scene 01_0719 with dissolve
    car "Ooh, beer! Can I have one?"
    ali "Weren't you drinking at the bar?"
    car "Only soda!"
    scene 01_0720 with dissolve
    ali "[mc]?"
    $ ab=""
    $ tCh=None
    if not EzModeActive:
        menu:
            "She was drinking beer":
                pass
            "[wk_y]She was drinking soda":
                $ tCh=True
    else:
        if Cara.Has("EZ"):
            mc "She was drinking soda."
        else:
            mc "She was drinking beer."
    if tCh or Cara.Has("EZ"):
        $ Cara.Score(1)
        $ ab="a"
        ali "Fine, you can have {b}one{/b}!"
        car h "Yay!"
    else:
        car su "Uncle [mc]!"
    show expression "01_0721" + ab with Fade(2, 1, 1)
    car "Oh, Mom! Did Uncle [mc] tell you?"
    car h "He's gonna teach me how to beat the shit out of Alex at pool!"
    show expression "01_0722" + ab with dissolve
    mc "Whoa, hold up! I said I'd {i}think about{/i} it!"
    ali h "Oh, [mc]! You {b}know{/b} you're gonna!\nShe's always had you wrapped around her little finger!"
    mc "Well, since I'm sticking around for another day or two..."
    show expression "01_0723" + ab with dissolve
    car "You are?? That's great!!"
    car "We can go to the bar tomorrow!"
    mc h "Damn, you must {i}really{/i} want to beat her, huh?"
    scene 01_0724 with dissolve
    car "You have no idea!"
    car h "She's been teasing me for as long as I can remember.\nI can't wait to see the look on her stupid face!"
    show expression "01_0725" + ab with dissolve
    ali "It's late, Sweetie. You should get to bed. You have an early class tomorrow."
    car "Yeah, I suppose."
    ali h "Don't worry, Uncle [mc] will still be here when you get home!"
    car h "Better be!\nHe's not allowed to leave town till I'm the pool Queen!"
    scene 01_0726 with dissolve
    car "Night, guys."
    mc "Night, Pipsqueak."
    ali "Fancy another one?"
    $ tCh=None
    if EzModeActive:
        call EzModeAsk ("Alison")
        if _return:
            $ Alison.Add("EZ")
            $ tCh=True
    if not EzModeActive:
        menu:
            "[wk_y]Yeah, why not.":
                $ tCh=True
            "Nah, I'm good. My bedtime, too.":
                pass
    if tCh:
        ali h "Great.\nI'm just gonna get into my pjs."
    else:
        mc "Nah, better not."
        ali "Okay."
        jump Springhaven_Bedtime01
    scene 01_0727 with Fade(2, 1, 1)
    ali "Jeez, just having someone to talk about all this shit with... Feels like a weight has been lifted."
    mc "I don't want you worrying about it anymore, Alison."
    scene 01_0728 with dissolve
    mc "I won't have {b}anyone{/b} threatening..."
    ali "Please, [mc], be careful with these guys."
    scene 01_0729 with dissolve
    ali "Pete {i}really{/i} didn't tell you about us divorcing?"
    mc "Nope.\nHe always said things were fine at home."
    scene 01_0730 with dissolve
    mc "Maybe he thought you'd both eventually sort it out."
    ali "No. We both knew it was over.\nIt had been for a long time."
    scene 01_0731 with dissolve
    ali "Whenever he came home on leave, he'd sleep in the spare room... if he came home at all."
    mc "What happened?"
    scene 01_0732 with dissolve
    ali "Do you even need to ask?\nCheating. Gambling. Drinking. Pick any one of those."
    ali "Even Cara couldn't stand him being around towards the end."
    mc "She doesn't...?"
    scene 01_0733 with dissolve
    ali "No! Of course not."
    ali "Wait... He never found out, did he??"
    mc "No."
    scene 01_0734 with dissolve
    ali "So, where were you headed? When I called."
    mc "I, uhh... hadn't decided."
    mc "Thought I might take your advice and go see Millie.\nEither that or head towards Cedar Grove to try and find Nettie."
    scene 01_0735 with dissolve
    ali "Millie would love to see her Dad."
    ali "Go see her, [mc]. It's the first step to putting things right."
    scene 01_0736 with dissolve
    mc h "Tryin' to get rid of me?"
    ali "Shit! No!"
    scene 01_0737 with dissolve
    ali "That's not what I meant {i}at all{/i}!"
    ali "You can stay as long as you want!"
    mc h "[lol]"
    scene 01_0738 with dissolve
    ali h "Oh! Asshole!"
    ali h "I thought you were being serious!"
    scene 01_0739 with dissolve
    ali h "I'm happy you're here, [mc]."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e01/01_0740.webp", 1156, 747,  True, "Springhaven_AF10") with dissolve
        mc "Me, too."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 01_0740
            hide screen imgMap
            ali "You should visit more often!"
            mc "Now that I'm home for good, I will."
    else:
        scene 01_0740 with dissolve
        mc "Me, too."
        if not EzModeActive:
            menu:
                "[wk_y]Check out her boobs":
                    call Springhaven_AF10
                "Don't":
                    ali "You should visit more often!"
                    mc "Now that I'm home for good, I will."
        elif Alison.Has("EZ"):
            call Springhaven_AF10
    mc x "I'm sorry I wasn't there for you when he died."
    scene 01_0742 with dissolve
    ali "You had a job to do - orders to follow.\nI knew the score, [mc]. I always did."
    mc "Yeah."
    scene 01_0743 with dissolve
    ali "You're here now. That's what matters."
    scene 01_0744 with Fade(1, 2, 1)
    ali h "[lol] Damn! Those were fun days!"
    mc h "Yeah, they sure were!"
    scene 01_0745 with dissolve
    ali "Uh-ohh, empty again."
    scene 01_0746 with dissolve
    ali "Fancy one more?"
    mc "Nah, I should get some sleep."
    ali "Yeah, it's late."
    scene 01_0747 with dissolve
    ali "Time for bed."
    if Alison.hasScore(1):
        scene 01_0748 with dissolve
        ali "Coming?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Yeah":
                    $ tCh=True
                "I don't think that's a good idea":
                    pass
        if tCh or Alison.Has("EZ"):
            call AlisonReplay01
            jump Springhaven_Bedtime01
        scene 01_0749 with dissolve
        $ Alison.Score(1)
        $ Alison.Add("SaidNo")
        mc "We're both a little drunk. Probably not a good idea, Ali."
        ali "Yeah... I guess."
    scene 01_0750 with dissolve
    ali "Good night, [mc]."
    mc "Night."
    jump Springhaven_Bedtime01
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
