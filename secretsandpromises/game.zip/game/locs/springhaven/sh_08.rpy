label Springhaven_06_ReturnFromBrookvale:
    call CenterText ("Hours later.")
    scene ah_nt with Fade(0, 0, 3)
    call ShowLocation (springhaven_id)
    pause
    scene 17_0825 with fade1
    mct "Man... Regretting the offer to drive Alison down to Oakhill now... I'm exhausted!"
    scene 17_0826 with Fade(1, 5, 2)
    mc "[whi]...Zzz.."
    scene 17_0827 with dissolve
    scene 17_0828 with dis1
    car "Dad."
    scene 17_0829 with dissolve
    car "Wakey, wakey!"
    call Emotion (mc, "Mumbles", "", True)
    scene 17_0830 with dissolve
    car "C'mon, Dad! Wake up!\nWe're going to Oakhill today!"
    call Emotion (mc, "Groan", "", True)
    mc "[whi]... 'kay."
    scene 17_0831 with dissolve
    scene 17_0832 with dis1
    scene 17_0833 with dis1
    scene 17_0834 with dis1
    mc "[whi]I'm awake! Jesus!\nClose 'em!"
    scene 17_0835 with dissolve
    scene 17_0836 with dissolve
    car "I'm under strict instructions not to let you go back to sleep!"
    scene 17_0837 with dissolve
    if Cara.isSexual():
        mc "Get under the covers and suck daddy's dick - {i}That'll{/i} wake me up!"
        scene 17_0838 with dissolve
        car "You know I'd love to!"
        if Cara.Has("NoRisk"):
            car "But we agreed - no risks!"
        else:
            car "But I need to get ready!"
    else:
        mc "You could've made me a coffee at least!"
        scene 17_0838 with dissolve
        car "I did. It's on the table in the kitchen with your breakfast!"
    scene 17_0839 with dissolve
    mc "Okay, Pipsqueak, you win - I'm up.\nI won't go back to sleep."
    car "Promise?"
    mc "Yeah."
    if Alison.isActive():
        scene 17_0840 with dissolve
        car "Mom talked to me last night.\nShe finally admitted to you two being an item!"
        mc "Yeah, she said she was gonna.\nHow did you take the news?"
        car "Pretended I had no idea. Acted surprised."
        scene 17_0841 with dissolve
        car "Told her how happy I was for her - for you both."
        mc "Good. That's something she was hoping you'd say."
    if Cara.isSexual():
        car "I wanted to tell her I was fuckin' you too, but thought nah... better not.[lol]"
        mc "Heh. {b}Not{/b} something she'd want to hear!"
        scene 17_0842 with dissolve
        mc "Damn, you're beautiful."
        scene 17_0843 with dissolve
        car "I ain't blowin' you. We don't have the time!"
        scene 17_0844 with dissolve
        car "But I promise I'll make it up to you, Daddy."
    scene 17_0845 with dissolve
    car "I'm so excited for today!"
    mc "Yeah, I bet Millie is too!"
    scene 17_0846 with dis1
    call Emotion (mc, "Sigh", "It's gonna be a long day...")
    scene black with Fade(2, 2, 0)
    call CenterText ("An hour later.")
    scene 17_0847 with Fade(0,0,2)
    car "Guys! C'mon, let's go!!"
    scene 17_0848 with dissolve
    mc "We're comin'!"
    if Alison.isActive():
        scene 17_0849 with dissolve
        ali "She was really mature about it! I was so relieved."
        scene 17_0850 with dissolve
        ali "And she had no idea!\nI honestly thought she was on to us, but nope!"
        call laugh (mc)
    scene 17_0851 with dissolve
    car "Are you guys deliberately walking slow just to annoy me?!"
    ali "[lol]"
    scene 17_0852 with dissolve
    scene 17_0853 with dis1
    scene 17_0854 with dis1
    scene black with Fade(3, 1, 0)
    jump OakHill_CaraAndAlisonVisit
return

label Springhaven_06_ReturnFromOakhill:
    scene black with Fade(3, 2, 0)
    call CenterText ("Later that day.")
    scene ah_eve with Fade(0, 0, 3)
    call ShowLocation (springhaven_id)
    pause
    scene 19_0001 with fade1
    play sound "cellringtone.mp3" loop
    pause
    scene 19_0002 with dissolve
    stop sound
    pause 0.5
    call Msg_Alysha01
    scene 19_0003 with dissolve
    pause
    if Chloe.isActive():
        if not TeddyD:
            play sound "text.mp3"
            pause 0.5
            scene 19_0004 with dissolve
            pause 0.5
            call Msg_Chloe04
            scene 19_0005 with dissolve
            pause
        elif Pix_Chloe:
            play sound "text.mp3"
            pause 0.5
            scene 19_0004 with dissolve
            pause 0.5
            call Msg_Chloe05
            scene 19_0005 with dissolve
            pause
    scene ah_nt with fade2
    pause 1.0
    centered "{font=Vanilla.ttf}{color=#ffff}You spend a quiet evening at home relaxing and watching TV."
    scene ah_day with Fade(3, 3, 4)
    pause
    scene 19_0006 with dissolve
    play sound "cellringtone.mp3" loop
    pause
    scene 19_0007 with dissolve
    pause
    scene 19_0008 with dissolve
    stop sound
    mct "Damn it."
    scene 19_0009 with dissolve
    pause 0.5
    call Msg_Alysha02
    scene 19_0010 with dissolve
    pause 0.5
    scene 17_0643 with dis1
    scene 17_0644 with dis1
    scene 17_0645 with dis1
    jump Springhaven_06_ReportToOffice
return

label Springhaven_06_ReportToOffice:
    scene 19_0011 with fade2
    pause
    if JamesD:
        scene 19_0012 with fade
        pause 0.5
        scene 19_0014 with dis1
        play sound "knock.mp3"
        scene 19_0015 with dis1
        pause 0.5
        sue "[whi]Enter."
        scene 19_0016 with dis1
        pause 0.5
    else:
        scene 19_0013 with fade
        pause 0.5
        scene 19_0017 with dis1
        mc "How's my favorite doorman doin'?"
        jam "She's busy, so fuck off."
        scene 19_0018 with dis1
        mc "C'mon, Puppy!\nYou {b}know{/b} she always makes time for {i}me{/i}!"
        scene 19_0019 with dis1
        jam "I know you're up to something.\nIt's just a matter of time before I figure it out."
        scene 19_0020 with dissolve
        jam "And then I get to do what I should've done from the start - put a bullet between your eyes."
        mc "Damn! That hurts!\nI thought we were friends??"
        scene 19_0021 with dissolve
        jam "What were you doing in Brookvale?"
        mc "Oh! Okay, {i}now{/i} I see why you got your panties in a twist.\nShe didn't tell you, huh? Keeping you out of the loop?"
        mc "Yeah, that has to sting a little."
        scene 19_0022 with dissolve
        jam "Whatever she's got you doing, it's going to end badly for you."
        jam "Don't be stupid. Do yourself a favor and tell me."
        jam "I can help you; it's not too late."
        scene 19_0023 with dissolve
        mc "First of all - don't ever touch me again."
        scene 19_0024 with dissolve
        mc "I don't know why you think we're up to {i}anything{/i}, but you've got it all wrong."
        mc "I went to Brookvale to see Jemma.\nShe's looking for a new right-hand guy, and I offered my services."
        mc "I'd still be working for you guys, so the original arrangement still stands."
        mc "But I wouldn't have to put up with this crazy bitch anymore."
        scene 19_0025 with dissolve
        play sound "knock.mp3"
        mc "I'd appreciate it if you kept it to yourself though, yeah?"
        scene 19_0024 with dissolve
        sue "[whi]Enter."
        mc "Wouldn't want things to get awkward with her before I left."
        scene 19_0026 with dissolve
        mc "Hey, Boss."
    scene 19_0027 with dissolve
    sue "[mc]. Is there something you need?"
    if JamesD:
        mc "Just got back from Brookvale."
        scene 19_0028 with dissolve
        sue "Yes..."
        scene 19_0029 with dissolve
        sue "I'm aware."
        scene 19_0030 with dissolve
        mc "You're still tracking my movements?"
        mc "I thought we trusted each other?"
        sue "We do."
        scene 19_0031 with dissolve
        sue "Which is why I've arranged a meeting with an associate."
        sue "He can manipulate your tracker.\nIt will allow {b}you{/b} to set its location at will."
        sue "Others have access to your data, so we must remain cautious."
        scene 19_0033 with dissolve
        mc "Okay. Good."
        sue "So, Brookvale?"
    else:
        mc "Can we talk here? Without {i}ears{/i} listening?"
        scene 19_0028 with dissolve
        sue "If you're referring to James, he won't hear us unless we raise our voices."
        scene 19_0029 with dissolve
        sue "Speak."
        scene 19_0030 with dissolve
        mc "He's starting to suspect we're up to something."
        mc "He knew I'd been to Brookvale - wanted to know why."
        sue "He's tracking you more closely than I expected."
        scene 19_0031 with dissolve
        sue "I'll arrange a meeting with an associate."
        sue "He can manipulate your tracker.\nIt will allow {b}you{/b} to set its location at will."
        mc "Great. Thanks."
        scene 19_0032 with dissolve
        sue "What reason did you give James for being there?"
        mc "I told him Jemma was looking for a new guy and I wanted to throw my hat in the ring."
        sue "Good. That shows a lack of loyalty to me.\nIt should appease him for a while."
        scene 19_0033 with dissolve
        sue "Whilst on the subject of Brookvale - Has any progress been made?"
    mc "Yeah..."
    mc "I found Bruno.\nHe's a damn {b}dog{/b}."
    sue "Hank abducted Priya's {i}dog{/i}?"
    scene 19_0029 with dissolve
    sue "The man certainly knows how to twist a knife."
    sue "She's always treated that thing like her child."
    scene 19_0030 with dissolve
    mc "You knew?"
    sue "I never knew the animal's name.\nLike you, I assumed Bruno was a person."
    scene 19_0031 with dissolve
    sue "It's unexpected for Hank to stoop so low."
    sue "He may be unaware of {i}what{/i} Jemma took."
    scene 19_0032 with dissolve
    mc "Jemma keeps the dog at her house.\nIt's gonna be impossible to recover it without her knowing."
    sue "You must find a way.\nIf she discovers the animal missing, Priya will immediately become her prime suspect."
    sue "We cannot afford to have a light shone in her direction - not until we've been safely extracted."
    scene 19_0034 with dissolve
    sue "You continue to impress me with your work."
    sue "Your loyalty means a great deal to me; I do not take it for granted."
    sue "You inspire confidence that our mission will succeed."
    scene 19_0035 with dissolve
    sue "If there's nothing else, I'm rather busy."
    show screen WlkGuide(wkg007)
    menu:
        "Inform Sue of Jemma's plan":
            hide screen WlkGuide
            $ ToldSue=True
            mc "Jemma asked me to work for her."
            mc "She wants me to keep an eye on you.\nShe said Hank doesn't trust you, and she's looking for a way to replace you at the top table."
            scene 19_0036 with dissolve
            sue "You agreed to her proposition?"
            mc "Yeah.\nWorking for her will give me access to the dog."
            sue "Excellent."
            scene 19_0037 with dissolve
            sue "This could be an unexpected opportunity to remove her from Hank's good graces permanently."
            sue "A nice little parting shot."
        "Keep it to yourself":
            hide screen WlkGuide
            $ ToldSue=False
            mc "I'm gonna need to spend more time in Brookvale while I figure out a way to get Bruno."
            mc "Will that be a problem?"
            scene 19_0037 with dissolve
            sue "No.\nOnce you have control over the tracker, keep your location set to Springhaven."
            sue "I'll make it a priority."
    scene 19_0038 with dissolve
    sue "Thank you, [mc].\nI shall be in touch."
    if not JamesD:
        scene 19_0039 with dissolve
        pause 0.5
        scene 19_0040 with dis1
        jam "She'll see it as a betrayal."
        scene 19_0041 with dissolve
        mc "She'll get over it."
        jam "I wouldn't count on it."
        jam "She'll want payback, and she'll probably send {b}me{/b} to get it."
        scene 19_0042 with dissolve
        mc "Good luck with that."
        scene 19_0043 with dis1
        scene 19_0044 with dis1
        jam "[whi]Asshole."
    scene black with fade2
    call CenterText ("Later that day.")
    scene 19_0045 with Fade(1,1,3)
    play sound "vib.mp3" loop
    pause
    stop sound
    mc cell "Hello?"
    scene 19_0046 with dissolve
    ruth cell "We need a meeting."
    mc cell "Ruth? What's going on?"
    ruth cell "Melissa's father sent some thugs here looking for information on Dawn."
    ruth cell "They were very intimidating. They assaulted a security guard."
    scene 19_0047 with dissolve
    mc cell "What did you tell them?"
    ruth cell "Only what we agreed.\nI informed them that Dawn was currently on vacation."
    mc cell "We expected them to show up there..."
    ruth cell "They threatened to return soon if they couldn't locate her."
    scene 19_0048 with dissolve
    ruth cell "They know where she lives, [mc].\nThey told me they'd already been to her apartment."
    ruth cell "This is too much for me."
    mc cell "I doubt they'll be back."
    ruth cell "I'm sorry, but... I... I don't think I can do this."
    mc cell "Ruth... Calm down.\nYou asked for a meeting... I'll come and see you tomorrow."
    ruth cell "Thank you."
    scene 19_0049 with dissolve
    mct "Damn it."
    scene 19_0050 with dis1
    scene 19_0051 with dis1
    scene 19_0052 with dis1
    scene 19_0053 with fade1
    mct "It's around here... somewhere."
    scene 19_0054 with dis1
    scene 19_0055 with dis1
    scene 19_0056 with dis1
    mct "THIS is the place??"
    scene 19_0057 with dis1
    mct "Expected something a little more upmarket for Sue's tech guy."
    scene 19_0058 with dis1
    scene 19_0059 with dis1
    scene black with fade1
    call CenterText ("30 mintues later.")
    scene 19_0060 with dis1
    scene 19_0061 with dis1
    scene 19_0062 with dis1
    mct "Good. No more tracking me."
    scene 19_0063 with fade1
    mct "Guess I should let Sarah know that I'm going back to Lakeshore tomorrow.\nShe might wanna come along to see Dawn."
    scene 19_0064 with dis1
    mct "It's short notice... but I can at least make the offer."
    scene 19_0065 with dis1
    scene 19_0066 with dis1
    mct "Should talk to Blaze about the dog problem..."
    scene 19_0067 with dis1
    mct "She's good at thinking outside the box... might come up with an idea or two."
    alex "Not even gonna say hello, [mc]?"
    scene 19_0068 with dissolve
    mc "Oh, Alex! Hey.\nSorry, I was in a world of my own!"
    scene 19_0069 with dissolve
    alex "I hope that's true!\nI'd be upset if you were ignoring me on purpose![lol]"
    mc "Nah, you know I'd never do that!"
    scene 19_0070 with dissolve
    mc "Where you headed?\nI'm on my way home if you need a ride?"
    scene 19_0071 with dissolve
    alex "Yeah? I was going to get the bus home."
    mc "Yeah. C'mon, I'm parked around the corner."
    scene 19_0072 with dissolve
    alex "Great! Thanks."
    call Springhaven_06_HomeWithAlex
    scene ah_nt with Fade(2, 3, 2)
    pause
    scene 19_0275 with fade1
    mct "Damn it, Alysha."
    call Msg_Alysha03 ()
    scene 19_0276 with dissolve
    mct "Maybe I should go and check her place."
    play sound "text.mp3"
    pause 0.5
    scene 19_0275 with dissolve
    pause 0.5
    call Msg_Alysha03 (False)
    scene 19_0276 with dissolve
    mct "What the hell?"
    scene 19_0277 with dissolve
    pause 0.5
    scene 19_0278 with dissolve
    play sound "cellringtone.mp3" loop
    pause
    mc "[whi]Pick up, Alysha!"
    stop sound
    scene 19_0279 with dissolve
    mct "Damn you."
    mct "... She's fine. You're being paranoid."
    mct "Like she said, she's just busy."
    scene 19_0280 with dissolve
    mct "I need to get some sleep. Want to make an early start in the morning."
    scene 19_0281 with dis1
    mct "She'll probably call tomorrow like it's no big deal."
    scene 19_0282 with dis1
    scene black with Fade(3, 3, 0)
    scene ah_day with Fade(0, 2, 3)
    pause
    scene 19_0283 with dissolve
    call Emotion (mc, "Yawn")
    scene 19_0284 with dis1
    scene 19_0285 with dis1
    mct "Okay, let's go."
    call UpdateMapInfos
    $ lakeshore_open=True
    $ milfork_open=True
    jump Springhaven_Leave
return

label Springhaven_06_HomeWithAlex:
    scene 19_0073 with fade1
    scene 19_0074 with dis1
    alex "You missing Cara yet? Or just enjoying the peace?"
    mc "Honestly, a bit of both!"
    scene 19_0075 with dis1
    mc "You'll have to point out your house for me... I know it's {i}one{/i} of these!"
    alex "[lol]"
    if not Alex.isSexual():
        alex "The light colored one, right there."
        scene 19_0076 with dis1
        scene 19_0078 with dis1
        scene 19_0079 with dis1
        alex "Thanks for the ride!"
        mc "Anytime."
        scene 19_0080 with dis1
        scene 19_0081 with dis1
        scene ah_day with fade2
        pause
        scene 19_0088 with fade1
        call Msg_Sarah01
        scene 19_0089 with dissolve
        pause
        return
    alex "Head straight to Cara's; I'll walk from there."
    scene 19_0076 with dis1
    mc "You sure? It's no trouble to stop!"
    alex "Yeah."
    scene 19_0077 with dis1
    scene 19_0073 with dis1
    scene 19_0082 with dis1
    scene 19_0083 with dis1
    scene 19_0084 with dis1
    alex "Thanks for the ride!"
    mc "Anytime."
    scene 19_0085 with dis1
    alex "Can I come in and use the bathroom real quick?"
    mc "Uh, yeah... sure."
    scene 19_0086 with dis1
    alex "Cool. Thanks."
    scene 19_0087 with dis1
    scene 19_0088 with fade1
    call Msg_Sarah01
    scene 19_0089 with dissolve
    pause
    scene 19_0090 with dissolve
    alex "Wow. You drink a {b}lot{/b} of coffee!"
    scene 19_0091 with dissolve
    mc "Yeah, guess so."
    scene 19_0092 with dissolve
    mc "Want one?"
    alex "{i}Ughh{/i}, no thanks. Can't stand the stuff."
    scene 19_0093 with dissolve
    alex "Have any tea?"
    call laugh (mc, "Nope.")
    scene 19_0094 with dissolve
    mc "You okay?"
    alex "Yeah. Why?"
    mc "I get the impression you're stalling.\nEverything okay at home?"
    scene 19_0095 with dissolve
    alex "Shit. Is it that obvious?"
    alex "My mom called me earlier. She's drunk again."
    scene 19_0096 with dissolve
    alex "If I'd caught the bus, I'd be home around the same time as Nicole gets back from college."
    alex "When you offered a ride, that slipped my mind."
    scene 19_0097 with dissolve
    mc "I'm sorry you're dealing with that."
    mc "But you're welcome to hang out here until Nicole gets home."
    alex "Yeah? Thanks."
    scene 19_0098 with fade1
    alex "... from that day on, I {i}knew{/i} we'd all be best friends for the rest of our lives!"
    alex "And we've done everything together ever since."
    scene 19_0099 with dissolve
    mc "Including attending the same college?"
    alex "Yeah."
    mc "So how come Nicole's there today, but you're not?"
    scene 19_0100 with dissolve
    alex "She has a class this afternoon; I don't."
    alex "Same college but different courses."
    alex "I'm studying sports therapy."
    scene 19_0101 with dissolve
    mc "Sports therapy? Nice!"
    mc "That includes massage, right?"
    scene 19_0102 with dissolve
    alex "[lol]\nYeah - it's a {i}part{/i} of it, but there's a {b}lot more{/b} to it than that!"
    alex "Recovery and prevention of injury, physical performance enhancement - there's a lot to learn!"
    scene 19_0103 with dissolve
    mc "Good for you, Alex.\nAre you enjoying it?"
    alex "You're dyin' to ask for a massage, aren't you? [lol]"
    mc "I'm {i}really{/i} trying my best not to!"
    scene 19_0104 with dissolve
    alex "[lol]"
    scene 19_0105 with dissolve
    alex "I'll bring my table around one day; I'd happily practice on you."
    mc "You don't need a massage table! I can just lie on my bed!"
    scene 19_0106 with dissolve
    alex "Wait... You mean {i}right now{/i}??"
    mc "Yeah!"
    scene 19_0104 with dissolve
    alex "[lol]"
    scene 19_0105 with dissolve
    alex "... Okay."
    scene 19_0107 with fade1
    scene 19_0108 with dis1
    scene 19_0109 with dissolve
    mc "Good enough, right?"
    alex "It's lower than I'm used to, but I'll manage."
    scene 19_0110 with dissolve
    alex "Oh, wait... We don't have any oils."
    alex "Is it okay to go to Cara's room? She'll definitely have {i}something{/i} we can use."
    mc "Yeah."
    scene 19_0111 with dissolve
    alex "Lie down and get comfortable; I'll be right back."
    mc "Okay."
    scene 19_0112 with fade1
    alex "Found something!\nIt's not ideal, but it works."
    scene 19_0113 with dissolve
    alex "What the hell?! [lol]"
    scene 19_0114 with dissolve
    call laugh (mc, "Is this not what you meant when you said {i}get comfortable{/i}?")
    alex "[lol] Not exactly, no!"
    scene 19_0115 with dissolve
    call laugh (mc, "I'm only playin' with you.")
    mc "Let me just put my pants back on."
    alex "No, it's all good!"
    alex "I don't get much opportunity to practice on glutes, so this is great."
    mc "Okay... if you insist."
    call AlexReplay03
    scene 19_0268 with fade1
    alex "I hope we get to do that again sometime!"
    scene 19_0269 with dissolve
    mc "I'm game if you are."
    scene 19_0270 with dissolve
    alex "Are you kidding me?\nI'll be game whenever you want!"
    scene 19_0271 with dissolve
    alex "[whi]Mmmhh."
    scene 19_0272 with dissolve
    alex "I'm so glad I bumped into you in town!"
    mc "Me too."
    alex "I have to go.\nNicole's been calling me, wondering where I am."
    if Nicole.isSexual():
        alex "I told her to come here, but she refused.\nShe's so shy around you! It's kinda cute."
    scene 19_0271 with dissolve
    alex "[whi]Mmmmhhh."
    scene 19_0273 with dissolve
    alex "See you later, [mc]."
    mc "See ya."
    scene 19_0274 with dis1
    pause 0.5
return

label Springhaven_Start7:
    scene ah_day with Fade(2, 4, 3)
    pause
    scene 20_0001 with fade1
    play sound "cellringtone.mp3" loop
    pause
    mc "[whi]C'mon Alysha, pick up."
    scene 20_0002 with dissolve
    stop sound
    mct "Damn it."
    scene 20_0003 with dissolve
    pause
    scene 20_0004 with dissolve
    scene 20_0005 with dissolve
    scene 20_0006 with dissolve
    mct "Fuck it."
    scene 20_0007 with dissolve
    scene 20_0008 with dissolve
    scene 20_0009 with dissolve
    scene black with fade3
    play sound "knock.mp3" volume 0.5
    scene 20_0010 with fade
    pause
    scene 20_0011 with dissolve
    play sound "knock.mp3" volume 1.0
    pause 0.5
    scene 20_0010 with dissolve
    mc "Alysha?"
    scene 20_0012 with dissolve
    play sound "doorbang.mp3"
    mc "ALYSHA??"
    mc "YOU IN THERE?"
    scene 20_0013 with dissolve
    mct "Locked."
    scene 20_0014 with dis1
    scene 20_0015 with dis1
    scene 20_0016 with dis1
    scene 20_0017 with dis1
    scene 20_0018 with dis1
    scene 20_0019 with fade3
    mct "Was worth a shot."
    scene 20_0020 with dis1
    scene 20_0021 with dis1
    scene 20_0022 with dis1
    scene 20_0023 with fade3
    scene 20_0024 with dis1
    scene 20_0025 with dis1
    scene 20_0026 with dis1
    scene 20_0027 with dis1
    scene 20_0028 with dis1
    scene 20_0029 with fade1
    pause 0.5
    scene 20_0030 with dissolve
    cop "Hello, sir. How can I help you?"
    mc "Hey. I'm looking for a police officer."
    cop "Well, you've come to the right place!"
    scene 20_0031 with dissolve
    mc "Yeah..."
    mc "I was involved in a traffic accident last week.\nIt wasn't serious..."
    mc "But my insurance company is pressing me for the police report incident ID... or something?"
    mc "I was hoping I could speak with the officer who attended that day."
    scene 20_0032 with dissolve
    cop "Count yourself lucky, sir. Insurance companies usually do everything they can to {i}delay{/i} payouts!"
    cop "I wouldn't worry about it, though.\nReports can take a while to go through the system. They'll have it in a few more days."
    scene 20_0033 with dissolve
    mc "Right... But now that I'm here... I guess it wouldn't hurt to get them what they want."
    mc "The sooner I get them to fix my truck, the sooner I can get back to work. You know how it is."
    call Emotion (cop, "Sigh", "Fine.")
    scene 20_0034 with dissolve
    cop "Did you get the officer's badge number?"
    mc "Uhh... No... She did tell me her name, though..."
    scene 20_0035 with dissolve
    mc "Shoot... What was it? Aliana?..."
    mc "... Aleeyah??..."
    mc "Err... Ali {i}something{/i}, I'm sure..."
    cop "{i}Alysha{/i}?"
    scene 20_0036 with dissolve
    mc "Yeah, Dude! That's it!"
    mc "Officer Alysha! Is she here?"
    scene 20_0037 with dissolve
    cop "No, don't think she is right now."
    cop "Come to think of it... Haven't seen her around for a couple of days. Probably on vacation."
    cop "Give me your number, and I'll pass it on to her when she's back on duty."
    scene 20_0038 with dissolve
    mc "Meh... Maybe you're right.\nThe insurance company can wait a few more days."
    mc "Sorry to bother you, officer."
    scene 20_0039 with dissolve
    pause 0.5
    scene 20_0040 with dis1
    mct "Shit. Don't know where else to look."
    scene 20_0041 with dis1
    mct "Could break into her apartment... Make sure she isn't in there... Might even find a clue..."
    scene 20_0042 with dis1
    mct "Desperate move, but it's all I have left."
    if Plr.Has("ATK"):
        scene 20_0043 with dis1
        play sound "vib.mp3"
        mct "I'll go tonight, when it's dark."
        stop sound
        mc cell "Hello?"
        ki cell "[mc]? It's Kiyomi."
        mc cell "Oh, hey."
        ki cell "There's a man here. He's asking to see you and won't leave."
        ki cell "I'm scared... I think he was here before with that crazy axe man."
        mc cell "Okay... Don't worry, I'm on my way right now."
        call Springhaven_07_MeetTheGuy
        if Christina.isActive():
            call Springhaven_07_LeakyPipe
    elif Christina.isActive():
        scene 20_0043 with dis1
        play sound "vib.mp3"
        mct "I'll go tonight, when it's dark."
        stop sound
        mc cell "Christina, hey."
        cri cell "Hi, [mc].\nI'm sorry to bother you, but I could really use your help!"
        mc cell "Okay, what's up?"
        cri cell "The pipe that's leaking in the bathroom... it's... there's water everywhere! I don't know what to do!"
        mc cell "The pipe's burst??"
        cri cell "I don't know what's happened... HELP!"
        mc cell "Okay... Don't worry, I'm on my way right now."
        call Springhaven_07_LeakyPipe
    else:
        scene 20_0043 with dis1
        mct "I'll go tonight, when it's dark."
        scene black with fade2
        call CenterText ("A couple of hour later.")
    scene ah_day with fade1
    pause
    scene 20_0290 with fade
    mct "Still nothing."
    call Msg_Alysha04
    scene 20_0291 with dissolve
    mct "Where the hell can she be??"
    mct "Can't see Sue being involved here... No way I'd still be walking around freely if she'd found out about Alysha."
    scene 20_0292 with dissolve
    mct "If I don't find anything at her apartment, I'll need to escalate..."
    mct "If anything bad has happened to her... The dirty cop - Wilks - will probably know something about it."
    mct "And if he knows anything... He'll fuckin' talk - I'll make sure of it.\nWhatever it takes."
    scene 20_0293 with dissolve
    mct "Nothing else I can do until the sun goes down."
    mct "..."
    mct "Waiting's gonna drive me crazy..."
    scene 20_0294 with dissolve
    mct "Try watchin' TV... take my mind off it."
    scene 20_0295 with dis1
    scene 20_0296 with dis1
    scene black with fade2
    call CenterText ("Some time later.")
    scene 20_0297 with fade1
    play sound "vib.mp3" loop
    mc "[whi]Zzz."
    scene 20_0298 with dis1
    call EmotionSml (mc, "Groan")
    scene 20_0299 with dis1
    scene 20_0300 with dis1
    mc "[whi]Holy shit!{w=0.5}{nw}" with vpunch
    scene 20_0301 with dissolve
    stop sound
    mc cell "ALYSHA??"
    aly cell "Hi, [mc]."
    scene 20_0302 with dissolve
    mc cell "Where the fuck have you been?! I've been worried sick!"
    mc cell "Are you okay??"
    aly cell "Yeah, I'm good."
    scene 20_0303 with dissolve
    mc cell "You're {b}good{/b}?? Jesus! I need more than that!"
    mc cell "I was gonna break into your apartment!"
    mc cell "Why the hell didn't you respond to my messages??"
    scene 20_0304 with dissolve
    aly cell "I'm sorry, but I couldn't."
    aly cell "We need to talk. I'll explain everything when I see you."
    aly cell "Can you come over to my place?"
    scene 20_0305 with dissolve
    mc cell "When?"
    aly cell "Right now."
    mc cell "Okay."
    scene 20_0306 with dissolve
    mc cell "Hey, Alysha..."
    mc cell "Are you okay? Really?"
    aly cell "Yeah.\nThanks for lookin' out for me, [mc]."
    scene 20_0307 with dissolve
    call Emotion (mc, "Exhales sharply")
    mct "Thank fuck she's alright."
    scene 20_0308 with dis1
    scene 20_0309 with dis1
    scene 20_0310 with dis1
    call Springhaven_07_VisitAlysha
    play music "rain.mp3" loop volume 0.5
    scene 20_0456 with fade
    pause
    $ renpy.music.set_volume(0.3)
    scene 20_0457 with fade
    play sound "thunder01.mp3" volume 0.25
    mct "Damn, sounds rough out there."
    mct "Hope it clears up by morning... Hate driving long distance in this kinda weather."
    scene 20_0458 with dissolve
    mct "Crap... That reminds me..."
    scene 20_0459 with dissolve
    if Nettie.isActive():
        mct "Should let Nettie know I'll be visiting tomorrow."
    else:
        mct "Should make sure Alison's ready to come home."
    scene 20_0460 with dissolve
    mc cell "Hey, it's me."
    if Nettie.isActive():
        mc cell "Just checkin' it's okay if I come by tomorrow to have that chat with Hayley."
        net cell "Hi, [mc].\nYeah, of course it's okay!"
        net cell "Is this gonna be another flying visit, or are you planning to stay?"
        scene 20_0463 with dissolve
        mc cell "Figured I'd stay over for the night this time."
        net cell "Great! Looking forward to seeing you."
        scene 20_0464 with dissolve
        mct "Sorted."
        mct "Better check in with Alison, too."
        scene 20_0460 with dissolve
    ali cell "Hi, [mc]!"
    mc cell "You ready to come home yet?"
    ali cell "[lol]Not really, but yeah."
    play sound "thunder02.mp3" volume 0.25
    scene 20_0461 with dissolve
    if Nettie.isActive():
        mc cell "I'm gonna visit Nettie tomorrow.\nThought I'd stay the night in Cedar Grove and come to Oakhill the morning after."
        ali cell "Sounds good. Say hi to Nettie for me!"
    else:
        mc cell "Okay, I'll set off in the morning."
    ali cell "We don't have to leave as soon as you get here, do we?"
    ali cell "Millie will be heartbroken if she doesn't get to spend some time with you!"
    scene 20_0462 with dissolve
    mc cell "Nah, I was planning to stay over and leave early."
    ali cell "Perfect!"
    scene 20_0465 with dissolve
    mct "Sweet."
    mct "Should probably get some rest.\nThe earlier I leave, the better."
    if Plr.Has("SarahPath"):
        if Mary.isActive() and Mary.L>1:
            $ Mary.isSexual(True)
    $ a=True
    if Plr.Has("MaryPath") and Sarah.isSexual():
        scene 20_0466 with dissolve
        mct "Shit... Forgot to message Sarah after coming back from Lakeshore."
        scene 20_0467 with dissolve
        pause 0.5
        call Msg_Sarah02
        scene 20_0468 with dissolve
        mct "Devily... I'm such an idiot. Heh."
        scene black with fade2
        stop music fadeout 0.5
        call Springhaven_07_VisitSarah
    elif Plr.Has("SarahPath") and Mary.isSexual():
        scene 20_0469 with fade1
        play sound "thunder02.mp3" volume 0.25
        scene 20_0470 with dis1
        scene 20_0471 with dis1
        play sound "text.mp3"
        scene 20_0472 with dis1
        scene 20_0473 with dis1
        mct "Hmm... Text from Mary."
        call Msg_Mary01
        scene 20_0474 with dis1
        scene 20_0475 with dis1
        call Springhaven_07_VisitMary
        stop music
    else:
        stop music fadeout 0.5
        scene black with fade2
        scene ah_day with Fade(0, 2, 3)
        pause
        scene 19_0283 with dissolve
        call Emotion (mc, "Yawn")
        scene 19_0284 with dis1
        scene 19_0285 with dis1
        mct "Okay, let's go."
        $ a=False
    if a:
        scene black with fade1
        call CenterText ("You head home for a quick shower before hitting the road yet again.")
    if Nettie.isActive():
        $ cedargrove_ch=5
        $ cedargrove_open=True
    else:
        $ oakhill_open=True
    call UpdateMapInfos
    stop music
    jump Springhaven_Leave
return

label Springhaven_07_MeetTheGuy:
    $ Plr.Add("A00")
    $ Plr.Del("ATK")
    $ Jt_name="JT"
    scene 20_0044 with fade2
    pause 0.5
    scene 20_0045 with dis1
    scene 20_0046 with dis1
    scene 20_0047 with dis1
    scene black with fade
    play sound "doorbell.mp3" volume 0.5
    scene 20_0048 with dis1
    pause 0.5
    if MiyukaSpringhaven:
        scene 20_0049 with dis1
        scene 20_0052 with dis1
        mi "Thanks for coming, [mc]. Please make him leave."
        scene 20_0053 with dissolve
        mc "Where is he?"
        mi "In the office with Kiyomi."
        scene 20_0056 with dissolve
        mc "He didn't hurt you or your sister, did he?"
        mi "No.\nHe's just refusing to leave until he's seen you."
        mc "Leave it to me.\nI'll get Kiyomi out of there. Both of you keep away from the office."
        scene 20_0057 with dissolve
        mi "Okay."
        scene 20_0060 with dis1
        scene 20_0062 with dis1
        jt "Here he is! The main man!"
        mc "Leave us."
        scene 20_0063 with dis1
        mc "The fuck you doin' here, JT?"
        jt "Yeah, I thought you recognized me.\nGood. Means we can skip the bullshit."
        scene 20_0066 with dis1
        mc "Bullshit's all you ever had.\nSay your piece and get the fuck out."
        jt "Always was a motherfucker. See you ain't changed."
        mc "You have ten seconds before I drag your ass outta here."
    else:
        scene 20_0050 with dis1
        scene 20_0051 with dis1
        ki "Thank you for coming so quickly."
        mc "Are you okay?"
        ki "Yes."
        scene 20_0054 with dissolve
        mc "Where is he?"
        ki "In the office."
        scene 20_0055 with dissolve
        mc "He didn't hurt you, did he?"
        ki "No.\nHe's just refusing to leave until he's seen you."
        mc "Leave it to me.\nStay away from the office."
        scene 20_0058 with dissolve
        ki "Okay."
        scene 20_0059 with dis1
        scene 20_0061 with dis1
        jt "The maid comin' back?\nShe's cute. Think I'm in there!"
        scene 20_0064 with dis1
        mc "The fuck you doin' here, JT?"
        jt "Yeah, I thought you recognized me.\nGood. Means we can skip the bullshit."
        scene 20_0065 with dis1
        mc "Bullshit's all you ever had.\nSay your piece and get the fuck out."
        jt "Always was a motherfucker. See you ain't changed."
        mc "You have ten seconds before I drag your ass outta here."
    scene 20_0067 with dissolve
    jt "You don't wanna do that, tough guy."
    jt "You're gonna want to hear what I got to say."
    scene 20_0068 with dis1
    scene 20_0069 with dis1
    scene 20_0070 with dis1
    mc "What's this?"
    scene 20_0071 with dissolve
    jt "Take a peek."
    scene 20_0072 with dissolve
    pause 0.5
    scene 20_0073 with dissolve
    mc "What am I lookin' at?"
    jt "CCTV stills from the Lakeshore train station."
    jt "See anyone you know?\nNo? Try the other one."
    scene 20_0074 with dissolve
    jt "Almost didn't recognize her. She's grown her hair!"
    jt "But that stance. Same old jacket she always wore..."
    scene 20_0075 with dissolve
    mc "Could be anybody."
    jt "Nah. That's {b}Blaze{/b}. We both know it."
    scene 20_0076 with dissolve
    mc "Blaze?? Nah.\nYou were never the brightest spark, huh?"
    jt "Bit strange that she's with the kid we're lookin' for, don't you think?"
    jt "And the girl he supposedly ran off with is nowhere to be seen."
    scene 20_0077 with dissolve
    scene 20_0078 with dissolve
    mc "I got shit to do, and you're wastin' my time, so get the fuck out and don't come back here."
    scene 20_0079 with dissolve
    jt "Okay, I can leave."
    jt "And I'll report back to Anton with what I found."
    jt "I'm sure he'll be happy when I tell him {i}all about{/i} the woman in the picture, and how her close friend happens to work for Sue."
    scene 20_0080 with dissolve
    jt "I know what you're thinkin'... {i}I should just kill him{/i}!"
    jt "Yeah, that ain't gonna fly.\nI have a guy waitin' for me to call."
    jt "He don't hear from me... You can guess what happens next."
    mc "This ain't a game, JT.\nWalk away. You don't wanna get mixed up in this."
    scene 20_0081 with dissolve
    jt "Don't pretend to give a shit about me!"
    jt "You always looked down on me.\nDidn't even want me on your squad."
    jt "So {b}fuck you{/b}! I'm lookin' out for myself!"
    scene 20_0082 with dissolve
    mc "Is that what this is? It wasn't personal."
    mc "You were a decent soldier, but we only took the best of the best."
    mc "Most of those who tried out didn't make the cut."
    scene 20_0083 with dissolve
    jt "Your fuckin' loss."
    jt "I know Blaze has Melissa... and if she's involved, so are {b}you{/b}."
    jt "Anton will kill you both.\nHe'll probably do her first and make you watch, 'cause he's like that."
    mc "So what are you doin' {b}here{/b}?"
    scene 20_0084 with dissolve
    jt "Saving your fuckin' life, {i}Sir{/i}."
    jt "I'll destroy the CCTV evidence and keep my mouth shut."
    jt "I want Melissa... and half a million dollars."
    call laugh (mc, "half a million dollars?? Is that all?")
    scene 20_0085 with dissolve
    jt "She has to go home to her father."
    jt "He ain't gonna stop looking until she's found."
    scene 20_0086 with dissolve
    mc "Let me guess, {b}you{/b} wanna be the hero taking her back to a grateful father?"
    jt "Yeah. Why not?"
    mc "You're fuckin' nuts."
    scene 20_0087 with dissolve
    mc "Even {b}if{/b} all that bullshit was true, where the fuck am I supposed to get {b}half a million{/b} dollars??"
    scene 20_0088 with dissolve
    jt "Don't play the fool; it doesn't suit you."
    jt "We both know your boss is pullin' the strings.\nShe's got more cash than she knows what to do with. They all have!"
    scene 20_0089 with dissolve
    jt "I'm not an unreasonable man... I'll give you some time to make the arrangements."
    mc "You're makin' a mistake, JT."
    scene 20_0090 with dissolve
    jt "You can keep the photos. I have copies."
    scene 20_0091 with dissolve
    jt "The hot maid gave me your number. I'll be in touch."
    scene 20_0092 with dis1
    scene 20_0093 with dis1
    pause
    scene 20_0094 with dissolve
    mct "Damn it."
    scene 20_0095 with dissolve
    ki "Are you okay?"
    scene 20_0096 with dissolve
    mc "Yeah."
    scene 20_0097 with dissolve
    mc "He said you gave him my number?"
    ki "Yes.\nI thought that might get rid of him, but he insisted on seeing you in person."
    ki "Did I do the wrong thing?"
    mc "No."
    scene 20_0098 with dissolve
    mc "Did you tell Sue he was here?"
    ki "No."
    mc "Good. Let's keep it that way for now."
    scene 20_0099 with dissolve
    ki "You'd better leave then; she's on her way home."
    ki "She just called and told me to prepare her a bath."
    scene 20_0100 with dissolve
    mc "Yeah."
    ki "Is he going to come back?"
    mc "No."
    scene 20_0101 with dissolve
    mc "But..."
    scene 20_0102 with dissolve
    mc "If he does, don't open the door and call me immediately."
    if Christina.isActive():
        play sound "vib.mp3"
        ki "Okay."
        scene 20_0103 with dissolve
        scene 20_0104 with dissolve
        call EmotionSml (mc, "Sigh")
        stop sound
        ki "Do you need to take it?"
        scene 20_0105 with dissolve
        mc "Uhh, no.\nI thought it might be someone else."
    else:
        ki "Okay."
    scene 20_0106 with dis1
    scene 20_0107 with dis1
    if Christina.isActive():
        scene 20_0108 with fade1
        mc cell "Hi, Christina.\nYou just called me?"
        cri cell "Oh [mc], yes! Thank goodness! I could really use your help!"
        scene 20_0109 with dissolve
        mc cell "What's wrong?"
        cri cell "The pipe that's leaking in the bathroom... it's... there's water everywhere! I don't know what to do!"
        scene 20_0110 with dissolve
        mc cell "The pipe's burst??"
        cri cell "I don't know what's happened... HELP!"
        scene 20_0111 with dissolve
        mc cell "Okay... Don't worry, I'm on my way."
        scene 20_0112 with dis1
    else:
        scene 20_0112 with fade1
    scene 20_0113 with dis1
    scene 20_0114 with dis1
    scene 20_0115 with dis1
return

label Springhaven_07_LeakyPipe:
    scene black with Fade(3, 2, 1)
    play sound "knock.mp3" volume 0.5
    scene 20_0116 with fade
    pause
    scene 20_0117 with dissolve
    cri "Thank you for coming so quickly!"
    mc "No problem."
    scene 20_0118 with fade1
    cri "I'm sorry for calling you out of the blue like that... I didn't know who else could help!"
    mc "It's fine!"
    scene 20_0119 with dissolve
    cri "I was in such a panic! I almost dialed 911!"
    call laugh (mc)
    scene 20_0120 with dissolve
    cri "I'm supposed to be at work!\nMy shift started ten minutes ago."
    scene 20_0121 with dissolve
    cri "So I hope you're good under pressure!"
    if Nicole.isSexual():
        scene 20_0122 with dissolve
        mc "Oh, hey."
        call EmotionSml (nic, "GASP")
        play sound "doorclose.mp3" volume 0.5
        scene 20_0123 with hpunch
        mc "[whi]Okay...?"
    scene 20_0124 with dissolve
    pause 0.5
    scene 20_0125 with dissolve
    cri "Please tell me you can fix it!"
    mc "Wow!"
    scene 20_0126 with dissolve
    mc "That looks a lot less dramatic than your phone call had me believe!"
    scene 20_0127 with dissolve
    cri "[lol] Shut up!\nI was panicking!"
    cri "It doesn't look {i}so bad{/i} now because I've had a chance to clean it up a bit!"
    cri "There was water {b}EVERYWHERE{/b}!"
    scene 20_0128 with dissolve
    cri "Is there anything you can do?"
    cri "The bucket needs emptying every five minutes!"
    scene 20_0129 with dissolve
    cri "It's so heavy when it's full and spills everywhere!"
    cri "I get wet every time!"
    mc "Yeah? Good to know!"
    cri "Huh?"
    scene 20_0130 with dissolve
    cri "[lol] {b}[mc]{/b}!"
    scene 20_0131 with dissolve
    cri "I wouldn't mind if it were in the {i}fun way{/i}!"
    call laugh (mc, "Also good to know!")
    scene 20_0132 with dissolve
    mc "Okay... Yeah."
    mc "I can stop the leak, but it's only a temporary fix."
    scene 20_0133 with dissolve
    mc "I'll need to come back to fix it properly another time."
    mc "This whole section of pipe needs to be replaced. It's a bigger job."
    scene 20_0134 with dissolve
    cri "Sounds good to me."
    cri "Do you need me to stick around?\nI really should get to work!"
    mc "Nah, you're good."
    scene 20_0135 with dissolve
    mc "I'll get my tools from the truck."
    cri "Great."
    scene 20_0136 with dissolve
    cri "Nicole's in her room, so if you need anything, give her a knock."
    mc "Okay."
    scene 20_0137 with dis1
    scene 20_0138 with dis1
    scene black with fade2
    call CenterText ("Twenty minutes later...")
    scene 20_0139 with Fade(0,0,1)
    mct "Might not be pretty, but it ain't leaking!"
    mct "Should hold for a few days."
    scene 20_0140 with dissolve
    pause 0.5
    scene 20_0141 with dis1
    scene 20_0142 with dis1
    scene 20_0143 with dis1
    scene 20_0144 with dis1
    mct "Should let Nicole know I'm done."
    scene 20_0145 with dis1
    play sound "knock.mp3" volume 0.5
    scene 20_0146 with dis1
    pause 0.5
    if not Nicole.isSexual():
        nic "[whi]Come in."
        scene 20_0147 with dis1
        scene 20_0148 with dissolve
        mc "Hey.\nFixed the leak. I'm leaving now."
        mc "Figured I'd let you know, in case you're waiting to use the bathroom."
        nic "Okay. Thanks."
        scene 20_0149 with dissolve
        mc "See ya, Nic."
        nic "[whi]Bye."
        scene 20_0150 with dis1
        scene 20_0151 with dis1
        scene 20_0152 with dis1
        scene 20_0153 with dis1
        scene black with fade2
        return
    nic "[whi]Umm... yes?"
    scene 20_0147 with dis1
    scene 20_0154 with dissolve
    mc "Hey.\nFixed the leak. I'm leaving now."
    mc "Figured I'd let you know, in case you're waiting to use the bathroom."
    scene 20_0155 with dissolve
    nic "Uhh, alright. Thanks."
    mc "You okay?"
    nic "[whi]Mh-mhh."
    scene 20_0156 with dissolve
    mc "You still feelin' embarrassed about the other day?"
    nic "[whi]A little."
    mc "Why?"
    scene 20_0157 with dissolve
    nic "It's not a choice!"
    nic "I don't {i}choose{/i} to feel this way!"
    scene 20_0158 with dissolve
    nic "[whi]Sorry."
    nic "I didn't mean to snap at you."
    scene 20_0159 with dissolve
    mc "Nic, it's okay!"
    mc "It was your first time doing something like that.\nIt's perfectly normal to feel the way you do."
    nic "Is it? I can't even look at myself in the mirror without cringing."
    scene 20_0160 with dissolve
    scene 20_0161 with dissolve
    scene 20_0162 with dissolve
    scene 20_0163 with dissolve
    mc "Come here."
    scene 20_0164 with dissolve
    scene 20_0165 with dissolve
    scene 20_0166 with dissolve
    scene 20_0167 with dissolve
    scene 20_0168 with dissolve
    nic "What are we doing?"
    mc "Keep going."
    scene 20_0169 with dissolve
    call NicoleReplay02
return

label Springhaven_07_VisitAlysha:
    $ Amelia.Del("Lied")
    if Amelia.Has("Truth"):
        $ Amelia.Add("A00")
    $ Amelia.Del("Truth")
    if Alysha.Has("Niece"):
        $ Alysha.Add("A00")
        $ Alysha.Del("Niece")
    scene black with fade2
    play sound "knock.mp3"
    scene 20_0311 with fade
    pause
    scene 20_0312 with dissolve
    scene 20_0313 with dis1
    aly "Hey."
    scene 20_0314 with dissolve
    mc "[whi]I thought they'd got to you.\nI was afraid you were dead."
    aly "[whi]I'm okay."
    scene 20_0315 with dissolve
    aly "I'm sorry.\nI knew you'd be worried, but I had no way of contacting you."
    mc "What happened??"
    aly "Come in. Let me explain."
    scene 20_0316 with dissolve
    aly "[mc]... Promise me you'll stay calm, okay?"
    mc "Stay calm?? Why?"
    scene 20_0317 with dissolve
    aly "Just... hear her out."
    mc "Who?"
    scene 20_0318 with dissolve
    ame "Hi, [mc]."
    mc "What the fuck?!"
    scene 20_0319 with dissolve
    mc "What the hell's she doin' here?\nYou know that's the {i}private investigator{/i}, right?"
    ame "I'm not a private investigator."
    scene 20_0320 with dissolve
    mc "Yeah, no shit!\nSo who are you {i}today{/i}, Amelia?"
    scene 20_0321 with dis1
    scene 20_0322 with dis1
    scene 20_0323 with dis1
    mc "What's this?"
    scene 20_0324 with dissolve
    call EmotionSml (mc, "Sigh", "You've gotta be shittin' me.")
    scene 20_0325 with dissolve
    mc "How do I know this is even real?"
    ame "You don't."
    aly "I spent days with the people who issued it.\nIt's real, [mc]."
    scene 20_0326 with dissolve
    ame "The minute Alysha ran my prints, they were flagged on our system."
    ame "Anyone accessing them is supposed to have federal authorization."
    ame "We needed answers. We {b}had{/b} to bring her in."
    scene 20_0327 with dissolve
    mc "You arrested a cop for running your prints?"
    ame "She ran them without any legitimate reason to have them."
    scene 20_0356 with dissolve
    aly "They didn't know if I was one of the dirty cops... or if I'd been compromised."
    aly "And with what we already know about my precinct, I couldn't exactly blame them for being suspicious."
    scene 20_0328 with dissolve
    mc "You should've told me the truth."
    if not Amelia.Has("A00"):
        ame "I'm not the only one who lied that day. Get over it."
    ame "When you followed me home, I contacted my supervisor. We came up with the private investigator story because we couldn't risk blowing my cover."
    mc "So why are you tellin' me now?"
    scene 20_0329 with dissolve
    ame "You left us no choice with your little fingerprint stunt."
    ame "When a police officer runs the prints of an undercover federal agent with no established connection, it tends to raise all sorts of red flags."
    ame "But we're not the bad guys, [mc].\nWe don't get rid of good cops just because they're onto us."
    scene 20_0330 with dissolve
    mc "Right. You just goddamn kidnap them for a few days!"
    ame "We needed answers, and Alysha wasn't exactly cooperative.\nIt took a while to find... common ground."
    mc "{i}Common ground{/i}?"
    aly "You."
    scene 20_0331 with dissolve
    aly "They wanted to know where I got the prints, but I refused to tell them."
    aly "I didn't know which side {i}they{/i} were on either."
    aly "Any one of them could've been in Sue or Hank's pocket."
    scene 20_0332 with dissolve
    ame "One of our technicians was going through her phone. He noticed one number kept calling and sending messages."
    ame "He replied to one of the messages, telling the sender everything was fine. But the number kept calling."
    scene 20_0333 with dissolve
    ame "He traced it back to you."
    ame "It was the {b}same{/b} number you gave me before you left my apartment."
    ame "{i}That's{/i} how you got my fingerprints.\nYou asked to use the bathroom before you left."
    ame "I didn't notice anything missing."
    mc "Trash can."
    ame "Ahh... Of course."
    ame "Once I realized who Alysha was working with, I asked to speak with her myself."
    scene 20_0334 with dissolve
    aly "During the interrogation, she started to talk about you."
    aly "And she told me {b}she{/b} was the private investigator."
    aly "You'd already told me you had doubts about her, but you were convinced she was on our side."
    aly "So I agreed to talk to her. And her alone."
    scene 20_0335 with dissolve
    mc "I'm not buyin' it."
    mc "The FBI wouldn't send a rookie agent undercover."
    mc "It'd be reckless. Dangerous."
    scene 20_0336 with dissolve
    ame "I never said I was a rookie."
    mc "You didn't have to.\nIf you were experienced, you wouldn't have been so sloppy with your questions at the bar."
    ame "Fine, you're right.\nBut they didn't send me."
    ame "I volunteered."
    aly "[whi]Jesus."
    mc "Why?"
    ame "I have my reasons."
    scene 20_0337 with dissolve
    mc "Okay..."
    ame "The FBI has been trying to dismantle this organization for years."
    mc "Years?!"
    scene 20_0338 with dissolve
    ame "Different investigations. Different teams. Different approaches.\nEvery time we got close, something happened."
    ame "Witnesses disappeared. Evidence vanished. Informants were exposed. Someone inside law enforcement tipped them off."
    aly "Goddamn dirty cops."
    scene 20_0339 with dissolve
    ame "Not just cops."
    ame "Judges. Politicians. Even some of our own agents."
    scene 20_0340 with dissolve
    mc "And what makes you think it'll be any different this time?"
    scene 20_0341 with dissolve
    mc "Okay... I'm sorry for stepping on the FBI's toes.\nWe'll walk away and let the professionals take over."
    mc "But do yourself a favor, Amelia. Find yourself another assignment. This one's gonna get you killed."
    aly "[mc]..."
    scene 20_0342 with dissolve
    aly "They're not asking us to walk away. They're asking us to help."
    scene 20_0343 with dissolve
    ame "We've never had anyone on the inside with access to people this important."
    ame "Your relationship with Sue, and even Hank, would be invaluable."
    scene 20_0344 with dissolve
    mc "Excuse us for a second."
    scene 20_0345 with dis1
    scene 20_0346 with dis1
    scene 20_0347 with dissolve
    mc "[whi]Tell me you're not seriously thinking about helping her!"
    aly "[whi]Why not? She's exactly what we needed, [mc]!"
    mc "[whi]We can't trust her! She's already lied to me!"
    if not Amelia.Has("A00"):
        aly "[whi]And you to her!\nBoth with good reason."
    else:
        aly "[whi]Out of necessity, not choice!\nShe's undercover, for Christ's sake!"
    scene 20_0348 with dissolve
    mc "[whi]Alysha, she's inexperienced. She doesn't know what the hell she's doing.\nShe's gonna get us both killed."
    aly "[whi]Can you honestly tell me that our chances of surviving this are any better {i}without{/i} her?"
    scene 20_0349 with dissolve
    mc "[whi]No."
    mc "[whi]Which is why we should stop and leave it to {i}them{/i}."
    scene 20_0350 with dissolve
    aly "[whi]They need us, [mc]. They need {b}you{/b}."
    aly "[whi]{b}We{/b} can end it with their help."
    mc "[whi]You trust her?"
    aly "[whi]I'm willing to give her a chance."
    aly "[whi]And so are you. Otherwise, you would've left already."
    scene 20_0351 with dissolve
    aly "[whi]I'm sorry I worried you, but you're not responsible for me."
    aly "[whi]You can't be."
    aly "[whi]You don't get to make my decisions for me just because you're afraid of losing me."
    scene 20_0352 with dissolve
    aly "[whi]I want to see this through."
    aly "[whi]{b}I'm{/b} choosing this, [mc]. If it goes wrong, that's my choice too."
    scene 20_0353 with dissolve
    aly "[whi]We knew this was too big for us alone.\nWe agreed we needed someone with more authority to help us."
    aly "[whi]Guess what?"
    aly "[whi]We have."
    aly "[whi]She's sitting right over there."
    scene 20_0354 with dissolve
    call EmotionSml (mc, "Sigh")
    scene 20_0355 with dissolve
    mc "[whi]If you fuckin' die, I swear, I'm gonna bring you back just so I can kill you again!"
    scene 20_0357 with fadehold
    aly "Alright, we're in."
    scene 20_0358 with dissolve
    mc "So what's the plan?"
    scene 20_0359 with dissolve
    ame "For now, just keep doing what you've been doing."
    aly "What does that mean?"
    ame "It means you don't change a thing.\nKeep investigating. Keep building your case. Keep your eyes and ears open."
    scene 20_0360 with dissolve
    ame "Welcome to the team."
    scene 20_0361 with dissolve
    mc "That's it? {i}Welcome to the team?{/i}"
    ame "What were you expecting?"
    mc "I don't know. Maybe a little more than a handshake."
    ame "If we're doing this, we need to do it properly."
    scene 20_0362 with dissolve
    ame "Making it official requires a lot of paperwork.\nI'll be in touch once it's sorted."
    scene 20_0363 with dissolve
    mc "So we're just supposed to trust you?"
    ame "No."
    scene 20_0364 with dissolve
    ame "You're supposed to trust that we're working toward the same goal."
    mc "That's not exactly reassuring."
    ame "It wasn't meant to be."
    scene 20_0365 with dissolve
    ame "But for what it's worth... I'm glad you're both on board."
    mc "Don't make me regret it."
    scene 20_0366 with dissolve
    ame "I'll do my best."
    scene 20_0367 with dissolve
    call EmotionSml (mc, "Sigh", "Great.")
    scene 20_0368 with fadehold
    aly "It's the right move, [mc]."
    mc "[whi]Yeah... I know."
    scene 20_0369 with dissolve
    mc "Doesn't mean I have to like it."
    scene 20_0370 with dissolve
    aly "C'mon! It's the fuckin' {b}FBI{/b}!\nWe needed this!"
    scene 20_0371 with dissolve
    mc "They treat you okay?"
    aly "Yeah."
    scene 20_0372 with dissolve
    aly "Thanks for caring about me.\nI'd almost forgotten what that was like."
    mc "Of course I care about you!\nWe're partners... We're friends, aren't we?!"
    if Alysha.L>0:
        $ Alysha.isSexual(True)
    scene 20_0373 with dissolve
    if not Alysha.isSexual():
        aly "Hell yeah we are!"
        scene 20_0374 with dissolve
        mc "Damn straight. And don't you forget it."
        mc "I'm gonna get outta here. Let you get some rest."
        aly "Okay."
        scene 20_0375 with fadehold
    else:
        call AlyshaReplay01
        scene 20_0375 with fade1
    mc "If you need anything, don't hesitate to call."
    aly "Thanks, [mc].\nI'm just gonna hit the shower and call it a night."
    scene 20_0376 with dis1
    scene 20_0377 with dis1
    scene 20_0378 with dis1
    scene black with fade2
return

label Springhaven_07_VisitSarah:
    $ persistent.SarahRP03Dat=True
    play sound "knock.mp3"
    scene 06_0213 with fade
    pause 0.5
    scene 06_0214 with dissolve
    sar "Hi."
    call SaraReplay03
    scene black with Fade(3, 2, 1)
    call CenterText ("The next morning.")
    scene 20_0476 with fade
    pause 
return

label Springhaven_07_VisitMary:
    $ renpy.music.set_volume(0.5)
    scene 06_0052 with fade3
    pause 0.5
    play sound "thunder01.mp3"
    scene 06_0053 with dissolve
    scene 06_0054
    pause 0.25
    scene 06_0053
    pause 0.25
    scene 06_0055 with dissolve
    mc "Mary?\nIt's [mc], I'm here."
    $ renpy.music.set_volume(0.2)
    scene 06_0056 with dissolve
    mc "HELLO?? MARY?"
    mar "[whi]I'm upstairs."
    scene 06_0057 with dis1
    play music "thunder_bg.mp3" loop volume 0.5
    scene 06_0058 with dis1
    mar "I'm so happy you're here! Thank you for coming!"
    mc "Heh. You're welcome."
    scene 06_0059 with dissolve
    mar "I've been sooo frightened here all alone!"
    scene 06_0060 with dissolve
    mar "Oh dear! You're soaking!\nI'll fetch you a towel."
    mc "Thanks."
    scene 06_0061 with fade
    mc "So Bill's broken down somewhere, huh?"
    mar "Yeah.\nHe was on his way home from Northcrest.\nSomething broke in the truck."
    mar "The mechanic said he won't be able to have it repaired until morning."
    mar "He'll just sleep in the cab."
    scene 06_0062 with dissolve
    mc "Damn, that sucks."
    mar "He'll be okay. He loves to sleep in that thing!"
    scene 06_0063 with dissolve
    mar "I feel so much better knowing you're here!"
    mar "I'll let you get some sleep."
    scene 06_0064 with dissolve
    mar "Goodnight."
    mc "Night, Mary."
    scene 06_0065 with fade2
    pause 1.0
    play sound "thunder01.mp3"
    scene 06_0066
    pause 0.25
    scene 06_0065 with dissolve
    mct "Damn. Poor Bill!"
    scene 06_0067 with dissolve
    mct "Glad I ain't out there!"
    play sound "thunder04.mp3" volume 0.5
    call MaryReplay03 (False)
    scene 06_0183 with Fade(0, 1, 4)
    pause
    scene 06_0184 with dis1
    call Emotion (mc, "Groan")
    scene 06_0185 with Fade(2, 1, 2)
    mc "Mornin'."
    scene 06_0186 with dissolve
    mar "Good morning!"
    mar "Coffee?"
    mc "Yeah, thanks."
    scene 06_0187 with dissolve
    mar "Sleep well?"
    mc "Uh, yeah. You?"
    scene 06_0188 with dissolve
    mar h "Best sleep of my life!"
    scene 06_0189 with dissolve
    mar "I got a message from Pops.\nThe truck's been repaired, and he's on his way home."
    mc "That's good to hear."
    scene 06_0190 with dissolve
    mar "He asked me to thank you on his behalf for coming to my rescue!"
    mc "Anytime."
    scene 06_0191 with dissolve
    mc "Thanks."
    scene 06_0192 with dissolve
    mar "Anytime.[giggles]"
    scene 06_0197 with fade1
    mar "I'll see you again soon?"
    mc "Of course."
    if Mary.isSexual():
        scene 06_0198 with dissolve
        mar "And we... can have more sex?"
        mc "If that's what you'd like, then yeah, absolutely!"
        mar "I {b}would{/b} like that."
        if persistent.Preg:
            if Mary.getCumIns()>0:
                scene 06_0199 with dissolve
                mar "Last night...\nYou... Umm... don't think I'll be pregnant, do you??"
                mc "Err... No... I, uh, I doubt it."
                mc "You don't take birth control?"
                scene 06_0200 with dissolve
                mar "No.\nI've never had reason to."
                mar "Should I start taking it?"
            else:
                scene 06_0199 with dissolve
                mar "I should probably... umm... start taking birth control."
                mar "What do you think?"
            menu:
                "Yes, best to be safe":
                    $ Mary.Add("OnBC")
                "No, you don't need it":
                    $ Mary.Add("NoBC")
            scene 06_0201 with dissolve
            mar "Okay."
        scene 06_0202 with dissolve
        mar "[ss]Mmmhhh.."
        scene 06_0203 with dissolve
        mar "[ss]...Mmmmhh..."
    scene 06_0204 with fadehold
    $ dia = "Bye, "  + ("Daddy" if persistent.MaryDaddy else persistent.McName) + "."
    mar "[dia]"
    mc "Bye, Sweetheart."
    scene black with Fade(3, 2, 1)
return

label Springhaven_Start8:
    scene ah_day with Fade(2, 4, 3)
    pause
    scene eou with Fade(3, 1, 1)
    pause
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
