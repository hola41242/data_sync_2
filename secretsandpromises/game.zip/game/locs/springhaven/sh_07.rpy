label Springhaven_05_TalkToAlison:
    scene 05_0640 with Fade(2,3,2)
    pause
    scene 14_0001 with fade1
    pause
    scene 14_0002 with dissolve
    ali "[whi]This is nice - relaxing with you."
    ali "[whi]The last couple of years are starting to feel like a distant memory.\nSome hazy nightmare I've finally woken up from."
    scene 14_0003 with dissolve
    mc "[whi]Good.\nI'm glad you're feeling that way."
    mc "[whi]Wish I'd come to see you sooner.\nI {b}should've{/b} come sooner."
    scene 14_0004 with dissolve
    ali "No. Don't do that.\nDon't you dare beat yourself up."
    ali "You've done more for us than I could ever have asked."
    scene 14_0005 with dissolve
    ali "I had your number. I could've called you."
    ali "I wanted to."
    ali "So many times, I almost did."
    mc "Why didn't you?"
    scene 14_0006 with dissolve
    ali "Because I knew you'd come."
    ali "You would've dropped everything, no matter the personal consequences."
    ali "But I was wrong. I {b}should've{/b} reached out to you.\nI'm sorry."
    scene 14_0007 with dissolve
    mc "{i}Now{/i} who's beating themselves up?"
    ali "So let's agree to give ourselves a break.\nYou're here now."
    mc "Deal."
    scene 14_0008 with dissolve
    ali "Talking about reaching out, I took your advice and called Violet."
    mc "Yeah? How'd it go?"
    ali "Great! We talked for a good while!"
    mc "You both had a lot to catch up on, I guess!"
    scene 14_0009 with dissolve
    $ j = True
    if Violet.isActive():
        if Alison.isActive():
            ali "You didn't tell me you two were back together."
            mc "She told you that?\nI wouldn't say... it's... complicated."
            scene 14_0010 with dissolve
            ali "I'm just bustin' your balls.\nI'm glad you're trying to work things out with her."
            ali "And don't worry, I didn't tell her about us."
            scene 14_0011 with dissolve
            ali "We can't carry on behind her back like this, though, [mc].\nIt's not fair to her."
            mc "Alison, me and Vi... We're {b}not{/b} back together.\nNot like it used to be, anyway."
            scene 14_0012 with dissolve
            ali "You {b}have{/b} to give it a chance."
            ali "And we have to stop."
            ali "Honestly, I'm happy for you and Violet; I am.\nIt's a good thing, and I refuse to be the one standing in the way of that."
            mc "What if she was okay with it? With us?"
            mc "What if I talk to her?"
            scene 14_0013 with dissolve
            ali "You want to take that risk?"
            ali "If you tell her about us, and she's okay with it - That'd be amazing."
            ali "But, there's a greater chance it'll go the {i}other{/i} way, and you'll blow everything with her."
            $ tCh=True
            if not EzModeActive:
                menu:
                    "I'll talk to her"(friend="Sexual", color="#1acc03"):
                        pass
                    "Yeah, you're right. Friends it is"(friend="Friendship", color="#1acc03"):
                        $ tCh=False
                        call CloseCharacterPath (Alison, "Alison", True)
                        scene 14_0014 with dissolve
                        ali "Just don't mess it up this time!\nYou deserve to be happy. Both of you!"
            if tCh:
                mc "Okay, I'll talk to her."
                scene 14_0015 with dissolve
                ali "[whi]Mmhh."
                scene 14_0014 with dissolve
                mc "I'll talk to her."
                ali "Okay, but until you do, we can't do anything."
                ali "Can you handle that?"
                mc "I'll give it my best shot!"
        else:
            ali "I'm glad you two are trying to work things out."
            mc "We're just taking things slow."
            scene 14_0014 with dissolve
            ali "Don't mess it up this time, [mc]!\nYou deserve to be happy. Both of you!"
            mc "I'm tryin' not to!"
    else:
        ali "Think you two will ever get back together?"
        mc "Nah.\nWe're friends, and that's good enough for me."
        scene 14_0010 with dissolve
        if Alison.isActive():
            ali "Friends like {i}us{/i}?"
            mc "No. Not like us."
            scene 14_0015 with dissolve
            ali "[whi]Mmhh."
            scene 14_0016 with dissolve
            ali "[whi]..Mmhh.."
            scene 14_0017 with dis1
            scene 14_0018 with dis1
            scene 14_0019 with dis1
            ali "[ss]Mmhh."
            scene 14_0020 with vpunch
            call Emotion (ali, "Gasp", "", True)
            scene 14_0021 with dissolve
            pause 0.5
            scene 14_0022 with dissolve
            car "Hey, parents!\nWhat ya up to?"
            ali "Uhh... Just watching a movie."
            scene 14_0023 with dissolve
            car "Cool."
            ali "I didn't know you were home, Sweetheart."
            car "I wasn't. Just got in."
            scene 14_0024 with dissolve
            car "I'm gonna put my PJs on. Back in a minute."
            ali "Okay."
            scene 14_0025 with dissolve
            mc "Still not ready to tell her about us, huh?"
            ali "I'm sorry.\nI know she won't care, it's just..."
            scene 14_0026 with dissolve
            mc "I get it.\nShe's been through a lot recently."
            ali "I just want the dust to settle for a while."
            ali "You okay with that?"
            mc "Sure."
            scene 14_0027 with dissolve
            ali "I thought she was staying at Nicole's tonight.\nI was looking forward to us spending the night together."
            mc "There'll be other nights."
            $ j = False
        else:
            ali "Makes things less complicated with Millie, I suppose."
            mc "Yeah."
    if j:
        scene 14_0022 with dissolve
        car "Hey, parents!\nWhat ya up to?"
        ali "Just watching a movie."
        scene 14_0023 with dissolve
        car "Cool."
        ali "I didn't know you were home, Sweetheart."
        car "I wasn't. Just got in."
        scene 14_0024 with dissolve
        car "I'm gonna put my PJs on. Back in a minute."
        ali "Okay."
    scene 14_0028 with fade1
    pause
    $ renpy.music.set_volume(1.0)
    play music "bgm02.mp3" volume 0.3 fadein 5.0
    scene 05_0212 with Fade(2, 4, 4)
    $ apause(2, False)
    scene 14_0029 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0030 with Fade(2, 1, 2)
    $ apause(2)
    play sound "shower.mp3" volume 1.0 loop fadein 1.0
    scene 14_0031 with Fade(2, 1, 2)
    $ apause(2)
    stop sound fadeout 1.5
    scene 14_0032 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0033 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0034 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0035 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0036 with Fade(2, 1, 2)
    $ apause(2)
    scene 14_0037 with fade1
    $ apause(2)
    scene 14_0038 with fade1
    $ apause(2)
    scene 14_0039 with fade1
    $ apause(2)
    scene 14_0040 with fade1
    $ apause(2)
    scene 14_0041 with fade1
    $ apause(2)
    scene 14_0042 with fade1
    $ apause(2)
    scene 14_0043 with dis1
    scene 14_0044 with dis1
    $ apause(2, True)
    scene black with Fade(2, 0, 0)
    stop music fadeout 2.0
    jump Springhaven_05_BackToCafe
return

label Springhaven_05_BackToCafe:
    scene 13_0299 with Fade(0, 3, 2)
    mct "Hate doin' this.\nSooner it's all over the better."
    scene 13_0300 with dis1
    mct "She asleep??"
    scene 13_0301 with dis1
    scene 13_0302 with dis1
    mc "[whi]Gabby?"
    scene 13_0303 with dissolve
    mc "Late night?"
    scene 13_0304 with dissolve
    gab "I wish."
    scene 13_0305 with dissolve
    gab "Busy morning."
    gab "I'll go get Mel."
    scene 13_0306 with dissolve
    mc "No rush."
    scene 13_0307 with dissolve
    if not Melanie.hasScore(4):
        mel "Leave her alone! I have your money."
        mc "Relax. I was just saying hi."
    else:
        mel "Hi, [mc]. I've been expecting you."
        mc "Hey."
    scene 13_0308 with dis1
    scene 13_0309 with dis1
    if not Melanie.hasScore(4):
        mel "You have no reason to harass my sister.\nYou deal with {b}me{/b}."
        scene 13_0310 with dissolve
        gab "Chill out, Mel!\nWe were just chatting."
        scene 13_0311 with dissolve
        mel "You don't have to {i}chat{/i} with him. He's not your friend, Gabby."
        mel "We need more filters. Go get some, please."
        scene 13_0320 with dissolve
        gab "Real subtle, Mel!\nWhy not just say {i}go hide in the closet until the mean man has left{/i}?"
    else:
        if Melanie.L==1:
            $ Melanie.isSexual(True)
        if Melanie.isSexual():
            mel "I'm sorry, but... I'm going to need another twenty-four hours."
            scene 13_0310 with dissolve
            gab "Why?? We have it--"
            scene 13_0311 with dissolve
            mel "No, we don't! Not {i}all{/i} of it!"
            gab "But I counted it! It's--"
            scene 13_0312 with dissolve
            gab "Ohhh... You just want to suck his dick again!"
            scene 13_0313 with dissolve
            if Gabby.Has("AskMel"):
                mel "GABBY!"
                scene 13_0315 with dissolve
                mel "Our arrangement still stands... if you want it to."
                $ tCh=Melanie.Has("EZ")
                if not EzModeActive:
                    menu:
                        "Take the offer"(friend="Sexual", color="#1acc03"):
                            $ tCh=True
                        "Take the money"(friend="Friendship", color="#1acc03"):
                            $ tCh=False
                if tCh:
                    scene 13_0314 with dissolve
                    gab "You said you'd ask. Now's your chance."
                    mel "Ask me what?"
                    scene 13_0315 with dissolve
                    mc "Right... Uhh..."
                    mc "She'd like to watch."
                    scene 13_0316 with dissolve
                    gab "{b}And{/b}??"
                    scene 13_0317 with dissolve
                    mc "And... I'd like her to watch, too."
                    mel "You want my baby sister to watch me give you a blowjob??"
                    mc "She {i}already{/i} watches us!\nWhat's the point in pretending she doesn't?"
                    scene 13_0318 with dissolve
                    mel "I'm not giving you a front-row seat, Gabby!\nAnd stop spying on us!"
                    gab "You can't stop me."
                    scene 13_0319 with dissolve
                    mel "You shouldn't encourage her!"
                    call MelanieReplay03 (True)
                    scene 13_0517 with Fade(0,1,1)
                    gab "Not a single customer!"
                    gab "You should've told her to let me stay!"
                    mc "Sorry."
                    scene 13_0518 with dissolve
                    gab "You should be. I might have let you fuck me."
                    mc "Next time."
                    scene 13_0519 with dissolve
                    gab "Bold of you to presume there'll be a next time!"
                    gab "Maybe that was your one and only chance."
                    scene 13_0520 with dissolve
                    mc "Nah. Your sister wouldn't have let us fuck in there."
                    mc "We need to ease her in.\nHonestly, I thought your blowjob was pushing it!"
                    scene 13_0521 with dissolve
                    gab "Didn't hesitate to stick it in my mouth, though, did you?"
                    mc "Hell no."
                    scene 13_0522 with dissolve
                    gab "Did you {b}want{/b} to fuck me?"
                    mc "You're kiddin', right? Of course I did!"
                    scene 13_0523 with dissolve
                    gab "Okay... Then, {i}maybe{/i} next time."
                    scene 13_0524 with dissolve
                    gab "Give me your cell number."
                    gab "I'll get Mel to invite you over for dinner. This is a cafe, not a brothel!"
                    mc "Heh. Fair enough."
                    scene 13_0525 with dissolve
                    mel "Right... Let's get this month's payment out of the way."
                    jump Springhaven_05_ToTheOffice
                else:
                    $ Melanie.isSexual(False)
                    scene 13_0319 with dissolve
                    mel "Ohh... Okay."
                    scene 13_0321 with dissolve
                    mel "There should be just enough in the till to make up the balance.\nIt'll leave us short, but we'll manage."
            else:
                mel "GABBY!\nCan you give us a minute, please??"
                scene 13_0319 with dissolve
                mel "So? Do I get my twenty-four hours?"
                $ tCh=Melanie.Has("EZ")
                if not EzModeActive:
                    menu:
                        "[wk_y]Take the offer"(friend="Sexual", color="#1acc03"):
                            $ tCh=True
                        "Take the money"(friend="Friendship", color="#1acc03"):
                            $ tCh=False
                if tCh:
                    call MelanieReplay03
                    scene 13_0517 with Fade(0,1,1)
                    gab "If you're gonna keep fucking her, can you please find somewhere else?"
                    scene 13_0518 with dissolve
                    gab "This is a cafe, not a brothel."
                    scene 13_0519 with dissolve
                    gab "Give me your cell number, and I'll pass it on to her.\nYou can make arrangements to meet somewhere else."
                    scene 13_0520 with dissolve
                    if Gabby.Has("Watch"):
                        mc "But then how would {b}you{/b} watch?"
                        gab "I didn't say I wouldn't be there, too."
                    mc "Fair enough. I'll give you my number."
                    scene 13_0521 with dissolve
                    gab "Don't hurt her, [mc]. She likes you."
                    mc "I have no intention of hurting her."
                    scene 13_0522 with dissolve
                    gab "Swear?"
                    mc "I swear, Gabby."
                    gab "Okay."
                    scene 13_0525 with dissolve
                    mel "Right... Let's get this month's payment out of the way."
                    jump Springhaven_05_ToTheOffice
                else:
                    $ Melanie.isSexual(False)
                    scene 13_0321 with dissolve
                    mel "Ohh... Okay."
                    mel "There should be just enough in the till to make up the balance.\nIt'll leave us short, but we'll manage."
        else:
            mel "I have the money. We've had a busy few weeks."
            mc "Great."
            scene 13_0310 with dissolve
            gab "We work our asses off, just to hand over all our cash!"
            scene 13_0311 with dissolve
            mel "It's our debt, Gabby. It's what we agreed to."
            gab "I know, still sucks though!"
            mel "We need more filters. Go get some, please."
            scene 13_0320 with dissolve
            gab "What I meant was, I work {b}my{/b} ass off, while you order me around!"
    scene 13_0322 with dissolve
    mel "Want to count it?"
    mc "Nah, I trust you."
    scene 13_0323 with dissolve
    mc "And a coffee... If I'm still welcome as a customer."
    if not Melanie.hasScore(4):
        mel "Certainly.\nI'm in no position to turn away paying customers."
        mel "... No matter how much I'd like to."
    else:
        mel "Of course you are.\nWe all have a job to do, right?"
    scene 13_0324 with fade1
    pause
    jump Springhaven_05_ToTheOffice
return

label Springhaven_05_ToTheOffice:
    scene 14_0045 with fade1
    pause
    if JamesD and SimonD:
        scene 14_0046 with fade1
        play sound "knock.mp3"
        scene 14_0061 with dis1
        pause 0.5
        sue "[whi]Enter."
        scene 14_0062 with dissolve
        mc "Hey."
    elif SimonD:
        scene 14_0047 with fade1
        mc "Hey, look who's back!\nI've missed you, buddy!"
        scene 14_0063 with dissolve
        jam "What are you doing here?"
        mc "Come to see Sue."
        scene 14_0069 with dissolve
        jam "You don't just {i}show up{/i} here.\nMake an appointment, like everyone else."
        mc "Tell your master I'm here, puppy.\n{b}She{/b} can decide if an appointment is needed."
        jam "She's busy."
        scene 14_0070 with dissolve
        scene 14_0071 with dis1
        scene 14_0072 with dis1
        sue "[mc], come in."
        mc "Guess I don't need an appointment after all."
        scene 14_0073 with dissolve
        call Emotion (jam, "Growls", "Asshole.", True)
    elif JamesD:
        scene 14_0048 with fade1
        mc "Hey, look who it is! How's the shoulder, buddy?"
        ah1 "Fuck you, prick!"
        scene 14_0064 with dissolve
        mc "You got promoted to door duty!\nCongrats, man!"
        ah1 "Come on then, big man, let's go!\nRight fuckin' now!"
        scene 14_0065 with dissolve
        mc "Relax, Stabby!\nI'm just here to see the boss."
        scene 14_0066 with dissolve
        ah1 "You're a fuckin' dead man. You just don't know it yet."
        scene 14_0067 with dissolve
        sue "Simon!\nReturn to your post at once."
        sue "[mc], come in."
        scene 14_0068 with dissolve
        ah1 "[whi]Asshole."
        call laugh (mc)
    else:
        scene 14_0049 with fade1
        mc "Hey, look who's back!\nI've missed you, buddy!"
        scene 14_0050 with dissolve
        mc "Asshole 2! How ya doin'?"
        ah2 "Fuck you."
        scene 14_0051 with dissolve
        jam "What are you doing here?"
        mc "Come to see Sue."
        scene 14_0052 with dissolve
        jam "You don't just {i}show up{/i} here.\nMake an appointment, like everyone else."
        mc "Tell your master I'm here, puppy."
        mc "{b}She{/b} can decide if an appointment is needed."
        scene 14_0053 with dissolve
        jam "She's busy."
        jam "Leave, before I--"
        scene 14_0054 with dissolve
        ah1 "He should be fuckin' dead, Sue!\nThis is bullshit!"
        scene 14_0055 with dissolve
        ah1 "And here he is. Just the prick I've been looking for."
        mc "Stabby! Nice to see you up and around again!"
        jam "Simon, not here."
        scene 14_0056 with dissolve
        ah1 "I'm going to kill you, motherfucker."
        mc "Step away before I put you back on your ass."
        scene 14_0057 with dissolve
        jam "{b}Not here{/b}!"
        scene 14_0058 with dissolve
        sue "Simon! Leave."
        sue "{b}NOW{/b}!"
        ah1 "This ain't over, asshole."
        scene 14_0059 with dissolve
        sue "[mc], come in."
        scene 14_0060 with dissolve
        mc "Guess I don't need an appointment after all."
        call Emotion (jam, "Growls", "", True)
    scene 14_0074 with dissolve
    mc "I'm here to drop off this month's cafe payment."
    sue "Excellent."
    scene 14_0075 with dissolve
    if BillSick:
        sue "William has informed me that you agreed to assist with another delivery."
        sue "It has to be done today.\nYou must depart as soon as possible."
        scene 14_0076 with dissolve
        mc "It's the same as before? Same pickup and drop-off locations?"
        sue "Correct."
        mc "Okay, I'll get right on it."
    else:
        sue "Your military record revealed that you are proficient in operating large vehicles."
        sue "I have an urgent matter that requires this skill set."
        mc "Uh, okay..."
        scene 14_0076 with dissolve
        sue "William is unwell and is currently recuperating in the hospital."
        mc "Bill? Is he okay?"
        sue "Irrelevant."
        scene 14_0077 with dissolve
        sue "I have a priority delivery that {b}must{/b} be fulfilled today."
        sue "You accompanied William on this particular route."
        sue "I have no alternative but to rely on {b}you{/b} to complete this task."
        scene 14_0075 with dissolve
        sue "William has agreed to the use of his vehicle.\nIt is waiting for you at his farm."
        mc "It's been a while since I've driven something that size, but, okay... I guess."
    scene 14_0074 with dissolve
    sue "Kiyomi shall accompany you."
    mc "Kiyomi?? Why?"
    sue "She wishes to see that her mother is safe and well.\nI have granted her request."
    if MiyukaSpringhaven:
        mc "Okay.\nWhat about her sister?"
        scene 14_0077 with dissolve
        sue "Miyuka shall remain at my residence."
        sue "She cannot be trusted to follow the rules."
    else:
        mc "Okay."
    scene 14_0075 with dissolve
    sue "I shall inform Kiyomi to expect your arrival imminently."
    mc "Right. Better get going then."
    sue "Indeed."
    scene 14_0078 with fade1
    mct "Better swing by home first and let Alison know I'm gonna be back late.\nGrab a sweater, too. Gets damn cold in Bill's truck with the heater busted!"
    scene black with Fade(2, 3, 2)
    call CenterText ("An hour or so later.")
    scene 14_0079 with fade
    pause
    play sound "knock.mp3"
    scene 14_0080 with dis1
    pause
    scene 14_0081 with dissolve
    ki "Hi [mc]."
    mc "Ready to go?"
    scene 14_0082 with dissolve
    mc "Barely recognize you in regular clothes.\nYou look nice!"
    ki "Thanks."
    scene 14_0083 with dissolve
    mc "Looking forward to seeing your mom?"
    ki "Yes."
    mc "How long's it been?"
    ki "A few months."
    mc "Damn."
    scene 14_0084 with dissolve
    mc "Okay, let's go put it right."
    call Northcrest_SecondPickup
    call Brookvale_SecondDelivery
    if Plr.Has("MaryPath") or not Mary.hasScore(2):
        scene 05_0640 with Fade(0,4,3)
        pause
        jump Springhaven_05_GoHome
    jump Springhaven_05_MaryReunionAlt
return

label Springhaven_05_MaryReunionAlt:
    scene 14_0160 with Fade(0,4,3)
    scene 14_0161 with dis1
    scene 14_0162 with dis1
    scene 14_0163 with dis1
    scene 14_0164 with dis1
    pause 0.5
    scene 14_0165 with dis1
    scene 14_0166 with dis1
    mct "Man, glad that's over with."
    scene 14_0167 with dissolve
    mct "Lookin' forward to my bed!"
    mar "[mc]?"
    scene 14_0168 with dissolve
    mc "Oh, hey Mary.\nHope I didn't wake you with that noisy old truck."
    mar "No, I was watching TV."
    scene 14_0169 with dissolve
    mar "It's so cold out here!"
    mar "Would you like to come in?"
    scene 14_0170 with dissolve
    mc "Uhh, it's late, I should probably get going."
    mar "Please..."
    mar "I don't like being on my own!\nWe can watch some TV together."
    mc "Uhh..."
    scene 14_0171 with dissolve
    mc "...Okay.\nGuess I can keep you company for a little while."
    scene 14_0172 with dissolve
    mc "Sorry to hear about Bill. How's he doing?"
    scene 14_0173 with dissolve
    mar "He'll be home in a day or two."
    mc "That's good."
    scene 14_0174 with dissolve
    mar "Something to do with his heart."
    mar "Just part of getting old, he says."
    scene 14_0175 with dissolve
    mar "Thinks I won't worry about him if he don't tell me, but he's wrong - I worry all the time!"
    scene 14_0176 with dissolve
    mc "I'm sure if it were something serious, he'd tell you."
    scene 14_0177 with dissolve
    mar "I hope you're right.\nI bet he's lyin' in his hospital bed right now, doin' nothing but worrying about {b}me{/b}!"
    mar "That won't do his heart any good!"
    scene 14_0178 with dissolve
    mar "Would you like to stay the night again?"
    mc "Uh, no, I don't think that's a good idea."
    mar "Why?"
    scene 14_0179 with dissolve
    mc "You're home alone, Mary.\nI doubt Bill would be happy with me staying!"
    mar "No... You're wrong!"
    mar "Pops knows I hate being all alone in this house at night!"
    mar "If he were here right now, he'd tell you himself!\nHe'd {b}want{/b} you to stay and keep me company!"
    scene 14_0180 with dissolve
    mar "Please, [mc]. Can you stay?"
    mar "I don't like being alone!"
    scene 14_0181 with dissolve
    mc "Uhh..."
    mc "... Okay, what the hell, I'll stay."
    scene 14_0182 with dissolve
    mar "You will?!"
    mar "Yay!"
    if Mary.Has("Stay"):
        $ Mary.Add("L1")
    elif Mary.Has("Ran"):
        $ Mary.Add("L0")
    else:
        call CloseCharacterPath (Mary)
    $ Mary.Del("Stay")
    $ Mary.Del("Ran")
    $ Mary.Del("NoDaddy")
    scene 03_0361 with Fade(1, 2, 1)
    pause
    scene 03_0362 with dissolve
    mar "Sorry about the television, it's old - like Pops!"
    call laugh (mc)
    scene 03_0363 with dissolve
    mar "We used to have a modern one, but we had to sell it."
    mar "... Just like most other things."
    mc "It's fine. An old TV is better than {i}no{/i} TV, right?"
    scene 03_0364 with dissolve
    mc "Guess money's tight for everyone these days."
    mar "Yeah."
    mar "That's why he's always out on the road, too."
    scene 03_0365 with dissolve
    mar "I wish he'd slow down, take things easy for a while. But he says..."
    scene 03_0366 with dissolve
    call Emotion (mar, "Bill impersonation", "I got not choice, Pumpkin! Bill needs payin'!")
    scene 03_0367 with dissolve
    call laugh (mc, "Wow!\nYou sound {i}just{/i} like him!")

    mar "[giggles]"
    scene 03_0368 with dissolve
    mc "But... {i}Bill{/i} needs payin'? Or, was it... {b}The bills{/b} need payin'?"
    mar "Oh... Yeah!"
    scene 03_0369 with dissolve
    mar "That {i}does{/i} make more sense! [lol]"
    scene 03_0370 with dissolve
    mc "How come you don't like being alone here?\nI thought you'd be used to it?"
    scene 03_0371 with dissolve
    mar "No! I'll {b}never{/b} get used to it!"
    mar "Only two things scare the bejesus outta me..."
    mar "Being alone in this house at night..."
    if Mary.isActive():
        if persistent.UseFocus:
            $ _skipping = False
            show screen imgMap("images/e03/03_0372.webp", 1148, 647, True, "Springhaven_AF18") with dissolve
            mar "... and thunderstorms!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 03_0372
                hide screen imgMap
        else:
            scene 03_0372 with dissolve
            mar "... and thunderstorms!"
            menu:
                "[wk_y]Take a closer look":
                    call Springhaven_AF18
                "Don't":
                    pass
        scene 03_0378 with dissolve
        pause 0.5
        scene 03_0379 with dissolve
        mc "So... Thunderstorms??"
    else:
        mar "... and thunderstorms!"
        mc "Thunderstorms??"
    scene 03_0380 with dissolve
    mar "They don't scare you??"
    mar "I always hide under my blankets!"
    scene 03_0381 with dissolve
    mar "Dang! I'm thirsty!"
    scene 03_0382 with dissolve
    mar "Can I get you anything?"
    mc "No, I'm fine, thanks."
    mar "Okay, I'll be right back!"
    scene 03_0383 with fade1
    pause 1.0
    mar "[whi]Oh dear!"
    scene 03_0384 with dissolve
    mc "Uhh... Is everything okay?"
    mar "[whi]Yeah."
    scene 03_0385 with fade
    mar h "I'm so clumsy!"
    mar "I spilled some juice!"
    mc "Oh, do you... need some help?"
    mar "No, it's fine.\nI'll just go change."
    scene 03_0386 with dissolve
    mar " Won't be long."
    mar h "... Oh, I can wear the new nightie I bought yesterday!"
    scene 03_0387 with fade2
    mct "Damn. Feel bad for Bill.\nWorks his ass off and still has to sell his shit just to keep his head above water."
    mar "Do you like it?"
    if Mary.isActive():
        if persistent.UseFocus:
            $ _skipping = False
            show screen imgMap("images/e03/03_0388.webp", 943, 335, True, "Springhaven_AF19") with dissolve
            mc "Wow!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 03_0388
                hide screen imgMap
            else:
                scene 03_0388 with dissolve
        else:
            call Springhaven_AF19
            scene 03_0388 with dissolve
        mc "You look beautiful!"
    else:
        scene 03_0388 with dissolve
        mc "You look very pretty!"
    scene 03_0390 with dissolve
    mar "I do?"
    scene 03_0391 with dissolve
    mar "You're just sayin' that because you're nice."
    scene 03_0392 with dissolve
    mc "No, I'm telling you the truth!"
    if Mary.isActive():
        scene 03_0393 with dissolve
        mar "You really think so? Thank you!"
        scene 03_0394 with dissolve
        mar "[kiss]"
        scene 03_0393 with dissolve
        mar "[giggles]"
    else:
        mar "Thank you!"
    scene 03_0395 with dis1
    pause 2.0
    call CenterText ("An hour or so of TV later...")
    scene 03_0396 with fade
    pause 1.0
    scene 03_0397 with dissolve
    pause 0.5
    scene 03_0398 with dissolve
    call Emotion (mar, "Yawn")
    scene 03_0399 with dissolve
    mar "I think it's time for me to go to bed."
    mc "Yeah, it's pretty late."
    scene 03_0400 with dissolve
    mar "It is!\nYou should probably go to bed, too!"
    mc "Uhh... Yeah, I guess you're right."
    scene 03_0401 with Fade(1, 0.5, 1)
    mar "I don't usually stay up this late!"
    mar "You're a bad influence!"
    scene 03_0402 with dissolve
    mc "Yeah... You're not the first person to tell me that."
    $ persistent.MaryRP02Dat=False
    call MaryReplay02_Part01
    scene 14_0183 with Fade(0,2,2)
    mc "Morning, Mary."
    if Mary.Has("L1"):
        $ Mary.L=2
    elif Mary.Has("L0"):
        $ Mary.L=1
    $ Mary.Del("L0")
    $ Mary.Del("L1")
    scene 14_0184 with dissolve
    mar "Good morning!"
    mar "I made you breakfast."
    scene 14_0185 with dissolve
    mc "Oh, that's very sweet of you. Thanks!"
    scene 14_0186 with dissolve
    mc "Wow, you sure know how to take care of someone!"
    scene 14_0187 with dissolve
    if persistent.MaryDaddy:
        mar "Didn't I tell you I'd take good care of you, Daddy?"
    else:
        mar "I like taking care of my friends!"
    if Mary.isActive():
        scene 14_0188 with dissolve
        mar h "Just like I took care of you last night."
    scene 14_0189 with dissolve
    mar "Thank you for staying, and keeping me company."
    mc "You're welcome, Sweetheart."
    scene 14_0190 with dissolve
    mar "Can we have another sleepover sometime?"
    mar "It was fun!"
    scene 14_0191 with dissolve
    mc "Err... Yeah, I guess..."
    mc "You should clear it with Bill first, though."
    scene 14_0192 with dissolve
    mar "I will!"
    mar "Pops don't have many friends, 'bout time he had a new one!"
    mar "Can I get your number?"
    scene 14_0191 with dissolve
    mc "Sure, why not?"
    $ Mary.Add("Cell")
    scene 14_0193 with fade1
    mc "Thanks again for breakfast, Mary.\nIt was delicious."
    mar "You're very welcome."
    scene 14_0194 with dissolve
    mar "Can you visit again, soon?"
    mc "Yeah."
    if Mary.isActive():
        mar "Promise?"
        mc "I promise."
        scene 14_0195 with dissolve
        mar "[kiss]"
        scene 14_0196 with dissolve
        if Mary.L==1:
            mar "Okay."
        else:
            mar h "I always get butterflies in my tummy when I kiss you."
            mar "I liked the {i}big{/i} kiss we had last night.\nCan we kiss like that again before you leave?"
            mc "Sure."
            scene 14_0197 with dis1
            mar "[ss]Mmhh."
            if persistent.UseFocus:
                $ _skipping = False
                show screen imgMap("images/e14/14_0198.webp", 923, 635, True, "Springhaven_AF35") with dissolve
                mar "[ss]..Mmmmhhh..."
                $ _skipping = True
                if renpy.get_screen("imgMap"):
                    scene 14_0198
                    hide screen imgMap
                    scene 14_0201 with dissolve
                    mar "[ss]..Mmmmhhh..."
            else:
                scene 14_0198 with dissolve
                mar "[ss]..Mmhh.."
                call Springhaven_AF35
    scene 14_0205 with fade
    mc "Bye, Mary."
    mar "Bye."
    call CenterText ("A little later that morning...")
    jump Springhaven_05_DealWithSomething
return

label Springhaven_05_GoHome:
    scene 14_0157 with fade1
    mct "Wow... What an exhausting day."
    scene 14_0158 with dissolve
    mct "Don't know how Bill does that every damn day!"
    mct "Man... I could sleep for a week..."
    scene 14_0159 with dis1
    mc "[whi]..Zzz.."
    scene black with Fade(2, 4, 0)
    jump Springhaven_05_DealWithSomething
return

label Springhaven_05_DealWithSomething:
    scene 14_0206 with Fade(0,0,3)
    mc cell "Morning Alysha, it's me."
    scene 14_0207 with dissolve
    mc cell "Our hunch was right - it {b}is{/b} drugs they're haulin'."
    aly cell "Can't say I'm surprised."
    aly cell "Still doesn't explain the chemist."
    mc cell "They've manufactured a new synthetic drug - highly addictive and cheap to make."
    scene 14_0208 with dissolve
    mc cell "They have a {i}slight{/i} problem with it, though... A few doses of this stuff and you'll end up in a body bag."
    aly cell "That can't be good for business!"
    mc cell "The chemist... Mitsui... They brought her in to find a solution."
    scene 14_0209 with dissolve
    aly cell "Has she??"
    mc cell "Not yet."
    aly cell "If this shit gets out on the street... it'll be a damn nightmare!"
    mc cell "Yeah. That's something to worry about for another day."
    scene 14_0207 with dissolve
    aly cell "What are you worrying about {i}today{/i}?"
    mc cell "I'm on my way to Sue's.\nGet more info on the smuggler."
    aly cell "You're not gonna go through with it, are you?\nWe can't let her skip town, [mc]."
    mc cell "Just playin' along for now."
    scene 14_0210 with dissolve
    mc cell "I'll call you later; need to deal with something real quick."
    aly cell "Okay. Be careful."
    scene 14_0211 with dis1
    scene 14_0212 with dis1
    $ apause()
    scene 14_0213 with fade1
    scene 14_0214 with dis1
    scene 14_0215 with dis1
    scene 14_0216 with dis1
    scene 14_0213 with dis1
    pause
    scene 14_0217 with dis1
    scene 14_0218 with dis1
    scene 14_0219 with dis1
    scene 14_0220 with dis1
    scene 14_0221 with dis1
    scene 14_0222 with dis1
    scene 14_0223 with vpunch
    pause 0.5
    scene 14_0224 with dissolve
    scene 14_0252 with dissolve
    scene 14_0253 with dissolve
    mc "Any weapons?"
    unk "[whi]No."
    scene 14_0254 with dissolve
    mc "Turn around."
    scene 14_0255 with dissolve
    mc "Wait... I {i}know{/i} you..."
    scene 14_0256 with dissolve
    mc "... You're the barmaid from Cedar Grove."
    mc "Put your hands down."
    scene 14_0225 with dissolve
    mc "Why are you following me?"
    ame "I... I'm not!"
    scene 14_0226 with vpunch
    mc "Don't fuckin' lie to me!"
    scene 14_0227 with dissolve
    mc "You've been tailing me ever since I left Sue's place."
    mc "{b}WHY?{/b}"
    ame "Hank!"
    scene 14_0228 with dissolve
    ame "Hank ordered me to keep tabs on you!"
    mc "Bullshit!\nWhy would Hank send his goddamn {b}barmaid{/b} to tail me?"
    ame "I... Uhh... There was no one..."
    scene 14_0229 with dissolve
    ame "It's {i}my{/i} test... to see if I could do the job... I don't want to be behind the bar forever!"
    ame "Please, I'm begging you! Don't tell him you saw me."
    scene 14_0230 with dissolve
    mc "You're terrible at surveillance, and you're even worse at lying."
    mc "Get in your car and go back to Cedar Grove.\nIf I see you following me again..."
    ame "You... You won't, I'm sorry."
    mc "Get the fuck outta here."
    scene 14_0231 with dissolve
    scene 14_0232 with dis1
    scene 14_0233 with dis1
    scene 14_0234 with dis1
    scene 14_0235 with dis1
    mct "What the fuck is that about??"
    scene 14_0236 with dissolve
    mct "More goddamn shit I'm gonna have to deal with."
    scene 14_0237 with fade2
    pause
    scene 14_0238 with fade1
    pause
    scene 14_0239 with dissolve
    ki "She has agreed to see you. She'll be down soon."
    mc "Thanks, Kiyomi."
    if Sue.L>0 and renpy.seen_label("SueReplay01_Part02"):
        scene 14_0240 with dis1
        mc "Can I ask you something personal?"
        ki "Uh... Okay."
        scene 14_0241 with dissolve
        mc "I'll understand if you don't want to answer, but..."
        mc "The first time I came here, when I... you know..."
        mc "And you... opened your mouth for me."
        mc "How often does Sue make you do that kinda thing?"
        scene 14_0242 with dissolve
        ki "That was the only time."
        ki "Everyone else leaves the moment she starts... relaxing."
        scene 14_0243 with dissolve
        ki "I was surprised {i}you{/i} didn't!"
        scene 14_0244 with dissolve
        ki "But then she told me to do {i}that{/i}."
        ki "I didn't know what to do.\nI don't even remember kneeling. I just felt... numb."
        scene 14_0245 with dissolve
        ki "When you refused, and told her to open {i}her own{/i} mouth... I wanted to cry with relief!"
        scene 14_0246 with dissolve
        mc "I'm sorry.\nI should've left, like everyone else."
        ki "I'm glad you didn't."
        mc "Why??"
        scene 14_0247 with dissolve
        ki "Because it showed me you were a man of integrity."
        ki "A {b}good{/b} man."
        if Kiyomi.L<10:
            scene 14_0248 with dissolve
            ki "If she makes such a demand again, I want you to know..."
            ki "I give you my permission, should you want it."
            ki "Now that I know you, it's different.\nI would kneel for {i}you{/i}."
            scene 14_0249 with dissolve
            $ tCh=Kiyomi.Has("EZ")
            if not EzModeActive:
                menu:
                    "[wk_y]Okay":
                        $ tCh=True
                    "That won't be necessary [wk_c]":
                        $ tCh=False
            if tCh:
                mc "Okay, if you're sure."
                scene 14_0267 with dissolve
                ki "Just try not to choke me with that thing; I have a terrible gag reflex!"
                call laugh (mc)
            else:
                mc "That won't be necessary."
                call CloseCharacterPath (Kiyomi, "Kiyomi")
        else:
            call Springhaven_05_KiyomiExplains
    else:
        scene 14_0246 with dissolve
        ki "Thank you again for taking me to see my mom."
        mc "My pleasure.\nHopefully, this will all be over for you and your family soon."
        scene 14_0267 with dissolve
        ki "I have faith in you."
        if Kiyomi.L==10:
            call Springhaven_05_KiyomiExplains
    scene 14_0268 with dissolve
    sue "This appointment was not scheduled."
    scene 14_0269 with dissolve
    sue "Do you have news of Melissa?"
    mc "No."
    scene 14_0270 with dissolve
    mc "I'm gonna go see the smuggler."
    sue "So soon?\nWould it not be wise to wait?"
    scene 14_0271 with dissolve
    mc "Right now, Anton will have all his guys out searching for Melissa and Harry."
    mc "He's preoccupied with the search, but sooner or later he's gonna figure out it was all a ruse."
    mc "That's when he'll focus his attention on you - on {i}us{/i}."
    mc "So, no, it's better to do it now, in all the chaos."
    scene 14_0272 with dissolve
    sue "Very well. I will trust your judgment."
    sue "I shall forward her location data to you."
    mc "Thanks."
    scene 14_0273 with dissolve
    mc "You said that you have something she wants."
    mc "What is it?"
    sue "You do not require that information at this time."
    scene 14_0274 with dissolve
    mc "Jesus, Sue!\nWhat is it with you and your damn secrets?"
    mc "How am I supposed to offer her something I know nothing about?"
    scene 14_0275 with dissolve
    sue "{i}She{/i} will know of what you speak!"
    sue "When the time comes for me to divulge to you this knowledge, I shall."
    sue "Until then, concern yourself only with the task at hand."
    scene 14_0276 with dissolve
    mc "When are you gonna start trusting me?"
    sue "I have placed my daughter's life in your hands.\nI trust you implicitly."
    mc "So why all the bullshit?"
    scene 14_0277 with dissolve
    scene 14_0278 with dis1
    sue "Kiyomi, I'm feeling anxious."
    scene 14_0279 with dissolve
    $ lv=True
    if not Sue.isActive():
        sue "And my guest is leaving."
    else:
        sue "... Unless my guest wishes to remain?"
        if not EzModeActive:
            menu:
                "Leave":
                    pass
                "Stay":
                    $ lv=False
        else:
            $ lv=False
    if lv:
        scene 14_0280 with dissolve
        sue "Do not reveal to her our intended cargo for the journey."
        scene 14_0281 with dissolve
        sue "You, too, are the keeper of secrets."
    else:
        scene 14_0284 with dissolve
        mc "Kiyomi, go take a break. You've earned it."
        scene 14_0285 with dissolve
        mc "No more performing in front of your staff."
        ki "Miss?"
        scene 14_0286 with dis1
        scene 14_0287 with dissolve
        scene 14_0286 with dissolve
        scene 14_0288 with dis1
        mc "And not here. Show me your bed."
        call SueReplay03
    scene 14_0282 with Fade(1, 2, 1)
    mct "Back on the road again."
    mct "Might be worth heading down to Cedar Grove to find out what the hell the barmaid was really up to."
    mct "She was terrified in the alley; no point tryin' to get her to spill then; she would've said anything just to get away."
    scene 14_0283 with dissolve
    mct "But... maybe, in safer surroundings and a friendlier approach... she might talk."
    mct "... or, I could just be wasting my damn time."
    if not Nettie.isActive():
        $ cedargrove_ch=4
    call UpdateMapInfos
    $ cedargrove_open=True
    $ oakhill_open=True
    $ milfork_open=True
    $ lakeshore_open=True
    jump Springhaven_Leave
return

label Springhaven_05_KiyomiExplains:
    scene 14_0250 with dissolve
    ki "I'm honored to belong to you."
    scene 14_0251 with dissolve
    mc "You keep saying that, but it's not true.\nYou don't owe me anything."
    mc "I have {b}no{/b} claim over you.\nYou're free to make your own decisions."
    ki "That's true; it {i}is{/i} my choice."
    ki "And I {b}choose{/b} to obey your every command."
    $ tCh=Kiyomi.Has("EZ")
    if not EzModeActive:
        menu:
            "I don't want you to [wk_c]":
                $ tCh=False
            "[wk_y]Okay, if you insist":
                $ tCh=True
    if not tCh:
        call CloseCharacterPath (Kiyomi, "Kiyomi")
        scene 14_0248 with dissolve
        ki "Okay, I understand."
        ki "I'll {b}never{/b} forget what you did for me, though.\nI want you to know that."
        scene 14_0251 with dissolve
        ki "My loyalty is, and will always be, yours."
        return
    mc "Okay, if you insist."
    scene 14_0257 with dissolve
    ki "I do."
    scene 14_0258 with dissolve
    ki "I insist on belonging to you."
    scene 14_0259 with dissolve
    ki "I am yours now."
    ki "My mind, my soul, ..."
    scene 14_0260 with dissolve
    ki "And, of course..."
    scene 14_0261 with dissolve
    ki "... my body."
    mc "No."
    scene 14_0262 with dissolve
    ki "No?"
    mc "I'd never ask you to do anything you like {i}that{/i}!"
    scene 14_0263 with dis1
    scene 14_0264 with dis1
    ki "[whi]I {b}want{/b} to please you."
    ki "[whi]In {b}every{/b} way you desire."
    ki "[whi]{i}This{/i} is our game now, and I'm looking forward to it.\nSo start playing."
    scene 14_0265 with dis1
    ki "[kiss]"
    scene 14_0261 with dis1
    scene 14_0266 with dis1
    pause 0.5
    scene 14_0267 with dissolve
    mc h "Okay... {i}now{/i} I understand!"
    ki "Good."
return

label Springhaven_05_ReturnFromLakeshore:
    $ curLOC = springhaven_id
    if Sarah.Has("NoLift"):
        jump Springhaven_05_SarahAltScene01Intro
    scene 16_0333 with Fade(3, 4, 3)
    sar "Thanks again for taking me to see her."
    mc "You're welcome."
    if Sarah.isSexual():
        sar "You sure you don't want to come up?"
        mc "Nah, I need some sleep, and if I stay here I won't get much!"
        sar "[lol] Okay, fair enough."
    sar "Bye [mc]."
    mc "See ya."
    scene 05_0640 with fade2
    pause 1.0
    scene 16_0369 with Fade(2, 2, 1)
    mc "[whi]Zzz."
    if springhaven_open:
        scene 16_0370 with Fade(3, 2, 1)
        jump Springhaven_Start6Real
    else:
        scene 16_0370 with Fade(3, 2, 1)
        mct "{size=*0.8}{font=Vanilla.ttf}*Sigh*{/font}{/size} Straight back on the road, I guess."
        jump ShowMap
return

label Springhaven_05_SarahAltScene01Intro:
    scene 16_0333 with Fade(3, 4, 3)
    pause
    scene 16_0334 with dissolve
    sar "[mc]?"
    scene 16_0335 with dissolve
    mc "[whi]Zzz."
    sar "[mc]."
    call Emotion (mc, "Groan", "", True)
    scene 16_0336 with dissolve
    mc "Ughh... Sorry, must've fallen asleep for a minute.\nWant me to drive again?"
    sar "We're home."
    scene 16_0337 with dissolve
    mc "Huh?"
    scene 16_0338 with dissolve
    mc "Shit! What time is it?"
    sar "Late!\nWhy?? What's wrong?"
    scene 16_0339 with dissolve
    mc "Crap.\nI forgot to let Alison know I was gonna be back late tonight."
    mc "She'll be asleep and will have locked the door by now."
    sar "Oh."
    scene 16_0340 with dissolve
    mc "Uhh, it's alright. I'll just sleep in the truck."
    scene 16_0341 with dissolve
    sar "What?! You can't sleep in here all night!"
    mc "Nah, I'll be fine. I've slept in worse places."
    scene 16_0342 with dissolve
    sar "Nonsense!\nI have a sofa - it's not much, but it's better than sleeping in this!"
    mc "Thanks, but there's no need, honestly."
    scene 16_0343 with dissolve
    sar "I'm not taking no for an answer, [mc].\nCome on!"
    scene 16_0344 with dissolve
    mc "Alright... If you insist."
    scene 16_0345 with dissolve
    pause 0.5
    scene 16_0346 with fade2
    pause 0.5
    scene 16_0347 with dissolve
    sar "Come in."
    scene 16_0348
    mc "Thanks."
    scene 16_0349 with dissolve
    sar "Ignore the mess.\nI was in the middle of grading when you picked me up."
    scene 16_0350 with dissolve
    mc "Dawn told me you were a teacher. High school, right?"
    sar "Yeah."
    scene 16_0351 with dissolve
    sar "Which means most of my evenings are spent going over homework."
    scene 16_0352 with dissolve
    sar "Such a glamorous life!"
    scene 16_0353 with dissolve
    mc "Whoa."
    sar "Oh, that's Binx!"
    scene 16_0354 with dissolve
    "[mo]Meeowww"
    scene 16_0355 with dissolve
    sar "Shoot!\nYou're not allergic, are you?"
    scene 16_0356 with dissolve
    mc "Nah."
    scene 16_0357 with dissolve
    sar "Awww, he likes you!"
    mc "You talking to the cat or me?"
    sar "[lol]"
    scene 16_0358 with dissolve
    sar "Make yourself at home, I'll fetch you a blanket."
    mc "Thanks."
    scene 16_0359 with fade1
    sar "Oh my... That sofa looks a lot smaller with {i}you{/i} sitting there!"
    sar "Will you be able to sleep on it?"
    scene 16_0360 with dissolve
    mc "Yeah, it's fine.\nLike you said, it's better than the truck!"
    scene 16_0361 with dissolve
    sar "Is there anything I can get you?\nDrink? I have plenty of food if you're hungry."
    mc "No, I'm fine. Thank you, though."
    scene 16_0362 with dissolve
    sar "Oh, I figured it out, by the way."
    mc "Figured what out?"
    sar "Why your face seemed familiar to me."
    scene 16_0363 with dissolve
    sar "You {b}are{/b} him, right?"
    sar "The guy who helped me out with that perverted asshole from the gas station!"
    sar "You turned down my offer of a ride."
    scene 16_0364 with dissolve
    mc "Oh, right! That was {b}you{/b}?"
    sar "Yeah!"
    mc "Wow. Small world!"
    scene 16_0365 with dissolve
    sar "Thank you again for that!\nYou restored my faith in humanity."
    mc "My pleasure. That guy {i}was{/i} an asshole."
    if EzModeActive:
        call EzModeAsk ("Sarah")
        if _return:
            $ Sarah.Add("EZ")
    scene 16_0366 with dissolve
    sar "I'd better get some sleep. See you in the morning."
    mc "Night, Sarah."
    scene 16_0367 with dissolve
    sar "Oh, bathroom's just there if you need it.\nGoodnight."
    mc "Great, thanks."
    scene 01_0161 with Fade(2,2,2)
    $ aPs(2, True)
    scene 01_0162 with Fade(1,2,1)
    $ aPs(3)
    scene 01_0163 with dissolve
    $ aPs(1)
    scene 01_0164 with dissolve
    $ aPs()
    scene 01_0165 with dis1
    $ aPs(0, False, True)
    scene 01_0166 with dis1
    sar "[whi][mc]?\nAre you awake?"
    scene 01_0167 with dissolve
    mc "Uhh, yeah... Is everything okay?"
    sar "Yeah, I can't sleep."
    scene 01_0170 with dissolve
    sar "I feel terrible knowing you're out here squashed up on that couch, while I'm lying in a big, comfy bed."
    mc "You wanna swap?"
    sar h "No! [lol]"
    scene 01_0171 with dissolve
    sar "But, I was thinking... We're both adults, right?..."
    sar "We're capable of sharing a bed without... doing {i}anything{/i}, aren't we?"
    $ tCh=Sarah.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Agree":
                $ tCh=True
            "Disagree [wk_c]":
                $ tCh=False
    if tCh:
        call Springhaven_05_SarahBed
    else:
        scene 01_0170 with dissolve
        call CloseCharacterPath (Sarah, "Sarah")
        mc "Don't worry, Sarah. I'm absolutely fine here."
        mc "You can sleep soundly. This is the comfiest couch I've slept on."
        scene 01_0172 with dissolve
        sar h "Really? {i}It is{/i}?"
        sar "Okay, if you're sure."
        scene 01_0173 with dissolve
        sar "Goodnight."
        mc "Night."
        scene 01_0161 with Fade(3,0.5,2)
        call Emotion (mc, "Snoring", "")
    scene 16_0368 with Fade(2,2,2)
    if springhaven_open:
        jump Springhaven_Start6Real
    else:
        mct "Better get straight back on the road - No time to go home."
        jump ShowMap
return

label Springhaven_05_SarahBed:
    $ Sarah.Activate()
    scene 01_0174 with dissolve
    mc "I guess so, yeah."
    sar "Great! C'mon."
    scene 01_0175 with dissolve
    sar "I'll sleep so much better with a clear conscience!"
    scene 01_0178 with dissolve
    if Dawn.getSex()>0:
        mc "I know this isn't about sex, but... Uh, you know about Dawn and me, right?"
        sar "Of course I do!\nShe told me all about you, that's how I know I can trust you!"
        scene 01_0179 with dissolve
        sar "And she won't mind, believe me."
    else:
        sar "I'd like to point out that I don't normally invite men to share my bed!"
        scene 01_0179 with dissolve
        mc "Understood."
    scene 01_0180 with fade
    mc "Damn, you're right! It {i}is{/i} comfy!"
    scene 01_0181 with Fade(3, 4, 2)
    $ aPs(2, True)
    scene 01_0198 with Fade(2, 3, 2)
    $ aPs(2)
    scene 01_0199 with Fade(2, 3, 2)
    $ aPs(2)
    scene 01_0200 with Fade(2, 3, 2)
    $ aPs(1)
    scene 01_0201 with dis1
    $ aPs(2)
    scene 01_0202 with dis1
    $ aPs(1)
    scene 01_0203 with dis1
    $ aPs(1)
    scene 01_0207 with Fade(2, 3, 2)
    $ aPs(1)
    scene 01_0208 with dis1
    $ aPs(1)
    scene 01_0209 with dissolve
    $ aPs(1)
    scene 01_0210 with dis1
    $ aPs(2)
    scene 01_0211 with dis1
    $ aPs(1)
    scene 01_0212 with dis1
    $ aPs(0.25)
    scene 01_0213 with dis1
    $ aPs(0.25)
    scene 01_0214 with dis1
    $ aPs(0.25)
    scene 01_0215 with dis1
    $ aPs(1)
    call SaraReplay01
    if Sarah.getCumIns()>0:
        scene 01_0280 with fade
        sar "[ss]I knew you were gonna be trouble."
        scene 01_0282 with dissolve
        sar "[ss]Mmhhh."
    else:
        scene 01_0281 with fade
        sar "[ss]I knew you were gonna be trouble."
        scene 01_0283 with dissolve
        sar "[ss]Mmhhh."
    scene 01_0284 with dissolve
    sar "[whi]I'd better get dressed for work; I'm already running late!"
return

label Springhaven_Start6:
    scene 05_0640 with fade2
    pause 1.0
    scene 16_0369 with Fade(2, 2, 1)
    mc "[whi]Zzz."
    scene 16_0370 with Fade(3, 2, 1)
    jump Springhaven_Start6Real
return

label Springhaven_Start6Real:
    mct "Better go see Sue.\nHopefully she can arrange the photoshoot with that Bruno guy."
    if oakhill_ch<6:
        mct "Actually, have some catching up to do in Oakhill first...\n{i}{font=DejaVuSans.ttf}{color=#fff}[[Mandatory catch-up]"
        $ springhaven_open=False
        $ curLOC=oakhill_id
        jump expression "".join(["OakHill_Start", str(oakhill_ch)])
    $ brookridge_open=False
    scene 17_0045 with fade2
    pause
    scene 17_0001 with fade1
    if Kiyomi.isActive() and Kiyomi.L==10:
        ki "She'll be here in a few minutes."
        mc "Great. Thanks, Kiyomi."
        scene 17_0002 with dissolve
        ki "Is there anything else I can help you with while we wait?"
        mc "Actually, yeah, there is."
        mc "When I shot that guy, and you fell... I couldn't help but notice you were wearing panties."
        mc "I guess you're wearing some today, too?"
        ki "Yes."
        mc "Can I see?"
        scene 17_0003 with dis1
        scene 17_0004 with dis1
        ki "Of course."
        scene 17_0005 with dissolve
        mc "Hmm, okay."
        ki "Does this displease you?"
        mc "Yeah, kinda... I'd prefer you didn't wear any."
        scene 17_0006 with dis1
        scene 17_0007 with dis1
        scene 17_0008 with dis1
        scene 17_0009 with dis1
        ki "Like me, {i}these{/i} belong to you now."
        scene 17_0010 with dissolve
        ki "I shall no longer wear {i}any{/i} underwear in your presence."
        scene 17_0011 with dissolve
        scene 17_0012 with dis1
        scene 17_0013 with dis1
        scene 17_0014 with dis1
        scene 17_0015 with dis1
        ki "Is this more pleasing?"
        scene 17_0016 with dissolve
        mc "Most definitely."
        scene 17_0015 with dissolve
        scene 17_0014 with dissolve
        scene 17_0002 with dissolve
        ki "Then I am happy."
    else:
        ki "She'll be here momentarily."
        mc "Great. Thanks, Kiyomi."
    scene 17_0017 with dissolve
    scene 17_0018 with dis1
    sue "Did you secure her services?"
    scene 17_0019 with dissolve
    mc "Yeah, but not until she's had proof of life."
    scene 17_0020 with dissolve
    sue "Proof of life?... Interesting."
    mc "Is that gonna be a problem?"
    sue "[whi]Possibly..."
    scene 17_0021 with dissolve
    call Emotion (mc, "Sigh", "You've gotta be kidding me.")
    scene 17_0022 with dissolve
    mc "That's why you didn't tell me what the bargaining chip was..."
    mc "Because you didn't know!"
    mc "You didn't know {b}what{/b} was taken from her!"
    scene 17_0023 with dissolve
    mc "Which means it wasn't {i}you{/i} who took him..."
    mc "Jesus, Sue!\nWhy would you send me there if you have no way of returning this guy?"
    scene 17_0024 with dissolve
    sue "Your assertion is correct.\nI had no role in this event."
    sue "I did not know which item was acquired, only who took it."
    scene 17_0025 with dissolve
    mc "{i}Item{/i}?? {i}It{/i}??\nHis name's Bruno, Sue! We're talkin' about a person here!"
    sue "That does indeed complicate the matter."
    mc "So where is he? Who has him?"
    scene 17_0026 with dissolve
    sue "Hank appointed Jemma as the instigator of Priya's punishment."
    sue "You will find {i}whoever{/i} was taken in Brookvale."
    scene 17_0027 with dissolve
    mc "{b}I'll{/b} find?\nHow the hell am I supposed to do that?"
    sue "I'm confident you'll find a way."
    scene 17_0028 with dissolve
    mc "There's bad blood between Priya and you.\nI'm not sure she'll even let you on her plane."
    sue "That is of no concern to you.\nFulfill her demand; leave the rest to me."
    scene 17_0029 with dissolve
    mc "What the hell does that mean?"
    sue "Our meeting has concluded. You are dismissed."
    scene 17_0030 with dissolve
    sue "Kiyomi, come."
    scene 17_0031 with dis1
    scene 17_0032 with dis1
    mct "Goddamnit."
    scene 17_0033 with dis1
    if not Miyuka.Has("NTC"):
        if not Miyuka.isActive():
            scene 17_0034 with dissolve
            mc "Hi, you must be Miyuka?"
            $ Miyuka_name="Miyuka"
            mi "Yes."
            $ Miyuka.Activate("Miyuka")
            $ persistent.MiyukaLocked=False
            scene 17_0035 with dissolve
            mc "Is Sue treating you okay?"
            scene 17_0036 with dissolve
            mi "If you don't include making us wear these stupid uniforms, and cleaning her dildos, then... sure, I guess."
            scene 17_0037 with dissolve
            mi "It beats being locked inside a cage; I know that much."
            mc "Listen, I'm sorry I didn't pick you up.\nI had no idea I was sent to pick up {i}a person{/i}. They didn't tell me."
            mi "Okay."
        else:
            scene 17_0034 with dissolve
            mc "Hi, Miyuka."
            scene 17_0035 with dissolve
            mc "Is Sue treating you okay?"
            scene 17_0036 with dissolve
            mi "If you don't include making us wear these stupid uniforms, and cleaning her dildos, then... sure, I guess."
            scene 17_0037 with dissolve
            mi "It beats being locked inside a cage, I know that much."
            if MiyukaEscaped:
                mc "Listen, I'm sorry I couldn't leave you with your mom."
                mc "If they'd have found you hiding there, it would've made things worse for you {i}and{/i} your mom."
                mi "Yeah, I know."
            elif Miyuka.Has("Food"):
                mi "I never thanked you for taking care of me - Buying me food and clothes..."
                mc "And you don't have to.\nThey shouldn't have treated you so badly to begin with."
        scene 17_0038 with dissolve
        if Kiyomi.L==10:
            mi "Kiyomi trusts you. She said I should, too."
            mi "Is it true you're going to help us?"
        else:
            mi "Kiyomi said you are going to help us."
        mc "I'm gonna try, yeah."
        scene 17_0039 with dissolve
        mi "Why?"
        mc "I've been caught up in this world, just like you and your family."
        mc "I'm working to get myself out.\nMy conscience wouldn't allow me to leave you and your family behind."
        if Kiyomi.L==10:
            scene 17_0040 with dissolve
            mi "My sister has put her complete faith into you - I choose to do the same."
            scene 17_0041 with dissolve
            mi "We're counting on you. Please don't let us down."
            mi "Bye, [mc]."
        else:
            scene 17_0041 with dissolve
            mi "Then, I wish you luck. You're going to need it."
            mi "Bye, [mc]."
        mc "Bye."
    scene 17_0042 with fade1
    mc cell "Hey, it's me.\nI need to ask a favor."
    aly cell "I'm at work right now."
    scene 17_0043 with dissolve
    mc cell "Can we meet?\nThe place where I first asked for your help."
    mc cell "It won't take long."
    scene 17_0044 with dissolve
    aly cell "Okay, I'll be there as soon as I can."
    mc cell "Great. Thanks."
    jump Springhaven_06_UpdateAlysha
return

label Springhaven_06_UpdateAlysha:
    scene 17_0046 with fade2
    pause 0.5
    scene 17_0047 with dis1
    scene 17_0048 with dis1
    scene 17_0049 with dis1
    mc "Hey."
    scene 17_0050 with dissolve
    aly "How'd things go with the smuggler?"
    scene black with Fade(1, 1, 0)
    call CenterText ("You update Alysha regarding Priya and her demands, as well as the events of Cedar Grove, the dead prisoner, and Amelia.")
    if PrisonerD:
        call CenterText ("... You leave out the part about HOW the prisoner died.")
    scene 17_0051 with dissolve
    aly "Jesus..."
    aly "Do you realize how many {b}more{/b} crimes you're asking me to ignore?"
    aly "Cedar Grove and Millfork may be out of my jurisdiction, but I still have a responsibility to report them."
    scene 17_0052 with dissolve
    mc "I know this isn't easy for you, Alysha."
    mc "I'm tryin' to be straight with you, but if you'd rather I didn't share {i}certain{/i} intel with you..."
    aly "No, don't do that.\nYou {b}need{/b} to tell me everything, [mc]."
    aly "It's the only way I can protect you when the shit inevitably hits the fan."
    scene 17_0053 with dissolve
    aly "You said you needed a favor..."
    aly "Please tell me it's not to help with getting proof of life for the smuggler - I can't get involved with that!"
    mc "No, that's not it."
    scene 17_0054 with dissolve
    mc "There are a couple of items in here I want you to run prints on."
    scene 17_0055 with dissolve
    mc "They belong to the barmaid.\nRecovered them from the trash in her bathroom before I left."
    mc "I was careful retrieving and bagging them.\nHopefully one or two of her fingerprints survived."
    aly "Why?"
    scene 17_0056 with dissolve
    mc "I don't know... call it a hunch."
    mc "Something's off with her."
    if Amelia.Has("Truth"):
        aly "Then why the hell did you tell her about Melissa??"
    else:
        aly "Is that why you lied to her about your reason for being there?"
    scene 17_0057 with dissolve
    mc "I {i}do{/i} believe she's on the same side of this as we are... I just don't believe her motive."
    mc "This State treats licensed private investigators the same as law enforcement, right?"
    mc "They have to submit their biometrics to a database?"
    aly "Yeah, but they're deleted once their license has expired or been revoked."
    scene 17_0058 with dissolve
    mc "So... if you find her in there, her story checks out."
    aly "And if not?"
    mc "Run her through the other databases; we might catch a break and get a hit."
    aly "Okay."
    scene 17_0059 with dissolve
    mc "Thanks.\nI'd better get outta here."
    scene 17_0060 with dissolve
    mc "Keep in touch."
    aly "Yeah, you too."
    scene 17_0061 with dissolve
    aly "[whi]What ya' think, Pops?\nWe got any chance of walking away from this at the end?"
    jump Springhaven_06_GoHome
return

label Springhaven_06_GoHome:
    scene ah_day with fade2
    pause
    scene 17_0062 with fade
    pause 0.5
    scene 17_0063 with dis1
    mc "Hey, Pipsqueak."
    car "Dad! You're home!"
    scene 17_0064 with dissolve
    mc "What's up with your mom? She okay??"
    car "Yeah, she's fine."
    scene 17_0065 with dissolve
    car "Suffering from a hangover."
    ali "[whi]..Zzzz.."
    scene 17_0066 with dissolve
    car "She went over to Christina's last night for a couple of drinks, and now she's paying the price."
    scene 17_0067 with dissolve
    car "She {i}tried{/i} to go back to bed, but gave up and fell asleep there, so I threw a blanket over her."
    call laugh (mc, "She's always been a lightweight.")
    car "[lol]"
    scene 17_0068 with dissolve
    car "I've just been texting with Millie."
    car "She's always so damn happy since you've been back! She can't talk about anything else!"
    scene 17_0069 with dissolve
    mc "I'm glad she's happy, and so am I..."
    mc "Can't help wishing I'd done it sooner."
    scene 17_0070 with dissolve
    car "She doesn't hold it against you - you being away for so long - you know that, right?"
    car "And neither do I!\nWe're just happy our dad's back home - for good!"
    scene 17_0071 with dissolve
    car "Next time you're visiting her, can you take me with you?\nWe haven't seen each other in {i}so{/i} long."
    scene 17_0072 with dissolve
    mc "Yeah, of course!"
    mc "I'm sure your mom'll wanna come along too, now she and Violet are friends again."
    if not persistent.Incest or not Cara.isSexual():
        scene 17_0073 with dissolve
        mc "I'm gonna jump in the shower real quick.\nDidn't get the chance this morning!"
        scene 17_0074 with dissolve
        car "[lol] Sorry.\nYou snooze, you lose!"
        call laugh (mc)
    else:
        if Millie.isSexual():
            scene 17_0075 with dissolve
            car "Millie told me that you'd told her!"
            mc "Told her what?"
            scene 17_0076 with dissolve
            car "About {i}{b}us{/b}{/i}!"
            scene 17_0077 with dis1
            scene 17_0078 with dis1
            mc "[whi]Shh!"
            scene 17_0079 with dissolve
            car "Ohh, don't worry!\nLook at her, she's practically unconscious!"
            scene 17_0080 with dissolve
            car "What changed?\nI thought you weren't gonna say anything to her?"
            mc "She already suspected and asked me outright, so I told her the truth."
            scene 17_0081 with dissolve
            car "God, you don't know how happy that made me!\nWell, not only me, {i}both{/i} of us!"
            scene 17_0082 with dissolve
            car "We've already started to compare notes!"
            scene 17_0083 with dissolve
            mc "Compare notes?? Wh--"
            mc "... Know what? I don't wanna know!"
            car "[lol]"
        scene 17_0084 with dissolve
        mc "[whi]Come here and give your dad a hug."
        scene 17_0085 with dis1
        scene 17_0086 with dis1
        car "I'm happy you're home, Daddy."
        mc "Me too, Pipsqueak."
        scene 17_0087 with dissolve
        mc "[whi]Damn you and your sexy little shorts..."
        scene 17_0088 with dis1
        car "[whi][lol]"
        car "[whi]Damn {i}you{/i} and your beautiful Daddy dick!"
        scene 17_0089 with dis1
        pause
        scene 17_0090 with dis1
        car "[whi]Kiss me."
        mc "[whi]Cara... Your mom... She's right there.\nIf she were to open her eyes..."
        scene 17_0091 with dissolve
        car "[whi]I know it excites you - the risk of her catching us. It excites me too."
        car "[whi]That's why you touched me in the kitchen the other day..."
        car "[whi]You put your hand between my legs while she was sat there with us."
        scene 17_0092 with dissolve
        car "[whi]My heart was pounding - not because I was scared - I wasn't."
        car "[whi]When the tip of your finger brushed against my pussy, I had to stop myself from letting out a moan."
        car "[whi]I'd never felt a rush like that before, and I liked it."
        scene 17_0093 with dissolve
        car "[ss]Mmh."
        scene 17_0094 with dissolve
        ali "[whi]....Zzzz...."
        scene 17_0095 with dis1
        pause 0.5
        scene 17_0096 with dis1
        pause 0.5
        scene 17_0097 with dissolve
        mc "[whi]Cara..."
        scene 17_0098 with dissolve
        car "[whi]Just a blowjob, Daddy."
        mc "[whi]Okay, so let's go upstairs."
        car "[whi]No!"
        scene 17_0099 with dissolve
        car "[whi]I want to suck your dick in front of her."
        mc "[whi]You {i}know{/i} what'll happen if she wakes up..."
        car "[whi]Yeah. She'll kill us both."
        $ tCh=Cara.Has("EZ")
        if not EzModeActive:
            menu:
                "Stop her":
                    $ tCh=False
                "[wk_y]Allow her to continue":
                    $ tCh=True
        if not tCh:
            $ Cara.Add("NoRisk")
            scene 17_0100 with dissolve
            mc "[whi]C'mon, it's not worth it.\nAre you {i}really{/i} willing to risk everything for {b}this{/b}?"
            car "[whi]... No, I guess you're right."
            mc "[whi]We can take {b}small{/b} risks, sure, but we don't cross the line."
            car "[whi]Okay."
            scene 17_0101 with dissolve
            mc "[whi]I need to take a shower.\nWant to come up with me?"
            car "[whi]No, better not... sounds {i}too risky{/i}.\nI need to get changed and go over to see Alex anyway."
            mc "[whi]Are you... sulking?"
            scene 17_0102 with dissolve
            mc "Cara!"
            scene 17_0103 with dissolve
            car "Enjoy your shower.\nSee you later."
            scene 17_0104 with dissolve
            ali "[whi]..Zzz.."
            scene 17_0105 with dis1
            scene 17_0106 with dis1
        else:
            call CaraReplay06
    scene 17_0190 with Fade(2, 3, 2)
    pause 0.5
    if Hannah.isSexual() and Pix_Hannah:
        play sound "text.mp3"
        pause 0.5
        scene 17_0191 with dis1
        scene 17_0192 with dis1
        pause 0.5
        call Msg_Hannah01
        scene 17_0193 with dissolve
        mct "Can't wait."
        scene 17_0191 with dis1
    scene 17_0194 with dis1
    scene 17_0195 with dis1
    play sound "knock.mp3" volume 0.5
    pause 0.5
    scene 17_0196 with dissolve
    if persistent.Incest and Cara.isSexual():
        car "Hey, I'm leaving now."
        if Cara.Has("NoRisk"):
            mc "Okay, bye Pipsqueak."
            scene 17_0197 with dissolve
            car "Dad... I'm sorry."
            car "I acted like a spoilt brat, but you were right - it wasn't worth risking everything."
            scene 17_0198 with dissolve
            mc "It's fine. We {b}have{/b} to be careful, that's all."
            scene 17_0203 with dissolve
            call Emotion (car, "Sigh", "Yeah, I know.")
            car "We will be from now on."
        else:
            mc "You wanna tell me what that was about with your mom?"
            scene 17_0197 with dissolve
            car "What do you mean?"
            scene 17_0198 with dissolve
            mc "Kneeling next to her to swallow, and then kissing her?"
            car "It wasn't about anything!"
            mc "C'mon, Cara."
            scene 17_0199 with dissolve
            car "I don't know... It was like... I just had the urge to do it."
            car "The thought just popped into my head... and I couldn't stop myself..."
            scene 17_0200 with dissolve
            car "But the strangest bit was... Part of me {i}wanted{/i} her to wake up..."
            car "I wished she'd opened her eyes, then opened her mouth, so I could share with her what was in mine."
            if Millie.isSexual() and Violet.isSexual():
                scene 17_0201 with dissolve
                car "Why can't she be like Millie's mom?!"
                car "God, I'm so jealous!"
                mc "Why?"
                car "Because her mom understands and is supportive!"
            scene 17_0202 with dissolve
            mc "Your mom's never gonna be like that, Cara, and you can't blame her for it."
            mc "I'd love for her to accept us, Pipsqueak, but you need to understand - she {b}never{/b} will."
            car "Yeah, and that makes me sad for her. She's the one missing out."
            mc "That's {b}not{/b} how she'd see it."
            scene 17_0203 with dissolve
            call Emotion (car, "Sigh", "Yeah, I know.")
            scene 17_0204 with dissolve
            car "Love you, Dad."
            mc "I love you, too."
            scene 17_0205 with dissolve
            car "See you later."
            mc "Yeah."
    else:
        car "Hey Dad, I'm going to see Alex for a while."
        mc "Okay, see you later, Pipsqueak."
        car "Bye."
    scene 17_0206 with fade1
    pause 0.5
    scene 17_0207 with fade1
    pause 0.5
    $ ta=False
    if Christina.isActive():
        call Springhaven_06_Diy
        scene 17_0385 with fade1
        scene 17_0386 with dis1
        scene 17_0387 with dis1
        scene 17_0388 with dis1
        scene 17_0389 with dis1
        $ ta=True
    if BillSick:
        call Springhaven_06_VisitBill
        $ ta=True
    if ta:
        scene ah_day with fade2
    else:
        scene black with fade2
    pause 0.5
    scene 17_0627 with fade
    mc "Hey, how's the head?"
    call Emotion (ali, "Groan", "I'm never drinking again.")
    scene 17_0628 with dissolve
    call laugh (mc, "Damn! How many times have I heard you say that?")
    ali "[whi]I mean it this time."
    scene 17_0629 with dissolve
    ali "[whi]How was your trip?"
    mc "Good."
    mc "Bad news is, I've got to make another one."
    scene 17_0630 with dissolve
    ali "So soon?"
    mc "Yeah. Have to go to Brookvale."
    scene 17_0631 with dissolve
    ali "That's disappointing... I have a few days off; I was hoping we could hang out together, like the old days."
    mc "I shouldn't be gone long."
    scene 17_0632 with dissolve
    mc "Cara wants to tag along the next time I visit Millie.\nI told her you might wanna come too."
    mc "If you've got a few days off, why don't you both go down for a visit?"
    mc "I can try to get back tonight, or early tomorrow morning.\nI could drive you down there. What do ya say?"
    scene 17_0633 with dissolve
    if Alison.isActive() and Violet.isActive():
        ali "You two sorted things out then?"
        mc "Thanks to you, yeah."
    ali "It {i}would{/i} be nice to see her after all this time."
    scene 17_0634 with dissolve
    ali "And Cara's desperate to hang out with her sister!"
    ali "Okay. Sounds like a plan!"
    scene 17_0635 with dissolve
    mc "Great."
    ali "I'll call her, make sure she doesn't already have plans."
    if Alison.isActive():
        ali "I want to ask her advice on something anyway."
        mc "Oh? My advice not good enough for you?"
        scene 17_0636 with dissolve
        ali "Normally, yes, of course."
        ali "But since this also concerns you, your advice would be biased."
        scene 17_0637 with dissolve
        ali "I want to tell Cara about {b}us{/b}. I think it's time."
        ali "I just need to hear it from someone else that I'm not making a mistake."
        mc "Don't worry, you're not."
        scene 17_0638 with dissolve
        ali "See? {b}Biased{/b}!"
        call laugh (mc)
        scene 17_0639 with dissolve
        call Emotion (ali, "Groan", "It hurts to laugh.")
    else:
        scene 17_0639 with dissolve
        ali "... Once my head stops banging."
    mc "Get some rest, Ali. Call her later."
    ali "[whi]Yeah."
    scene 17_0640 with dissolve
    mc "I'll be home as soon as I can."
    ali "[whi]Okay. Drive safe."
    scene 17_0641 with fade1
    pause 0.5
    if not BillSick and Christina.isActive():
        call Springhaven_06_ChristinaAlt
    else:
        scene 17_0642 with dis1
    scene 17_0643 with dis1
    scene 17_0644 with dis1
    scene 17_0645 with dis1
    scene black with Fade(3, 1, 0)
    jump Brookvale_RightHandMan
return

label Springhaven_06_ChristinaAlt:
    scene 17_0646 with dis1
    cri "Hey, [mc]."
    mc "Oh, hey Christina."
    scene 17_0647 with dissolve
    cri "How's her head today?"
    mc "Guess!"
    cri "[lol]"
    scene 17_0648 with dissolve
    cri "The wall looks fantastic! Thank you!"
    mc "Glad you're happy with it."
    cri "I am!"
    scene 17_0649 with dissolve
    cri "And I'll be even happier if you tell me the leaky pipe in the bathroom is next on your list!"
    mc "Well, I'm {b}your{/b} guy!"
    mc "So you tell me what to do, and I do it!"
    scene 17_0650 with dissolve
    cri "You probably shouldn't tell me that, [mc]!"
    cri "I may be tempted to show you more holes that would like to be filled!"
    mc "Sweetheart, you show me the hole, and I'll fill it."
    scene 17_0651 with dissolve
    cri "[lol] Oh, my God! You made me blush!"
    call laugh (mc, "Sorry.")
    mc "Sometimes I say things without thinking.\nI'll try and stop."
    scene 17_0652 with dissolve
    cri "No, don't do that... I like it."
    cri "You make me feel like a dizzy teenager all over again!"
    mc "And who wouldn't want that, right?"
    cri "Exactly![lol]"
    scene 17_0653 with dissolve
    cri "I'd better check on my hungover patient."
    mc "Heh, yeah."
    if Nicole.Has("Uniform2"):
        scene 17_0654 with dissolve
        mc "Ohh... Could I ask your advice on something quickly?"
        scene 17_0655 with dissolve
        cri "Of course. What's up?"
        mc "You know I have another daughter, right?"
        cri "Yeah, Alison told me about her... Millie?"
        mc "Yeah."
        scene 17_0656 with dissolve
        mc "On my last visit, I... uhh..."
        mc "I kinda walked in on her while she was... {i}busy{/i}... if you know what I mean."
        cri "Oh dear!"
        mc "Yeah... I yelled at her... I--"
        scene 17_0657 with dissolve
        cri "Are you asking my advice as a nurse, or a parent?"
        cri "Because, as a parent - Why would you yell at her??\nIt's a perfectly natural thing for someone of her age to do!"
        mc " I was embarrassed, I guess... I didn't think she did that kinda thing."
        scene 17_0658 with dissolve
        cri "[mc], I hate to break it to you, but {b}all{/b} young women do {i}that kinda thing{/i}!"
        cri "It's normal! Don't be so hard on her!"
        cri "I had a similar experience just the other--"
        scene 17_0659 with dissolve
        cri "Ohhh... Wow!"
        cri "She {i}actually{/i} told you about that, huh??"
        scene 17_0656 with dissolve
        mc "Yeah... I'm sorry.\nI was there when you called her."
        mc "She was upset about the whole thing... asked me if I'd talk to you."
        mc "I tried to tell her it'd probably make things worse, but she--"
        scene 17_0660 with dissolve
        cri "Gave you the 'ole puppy dog eyes? [lol]"
        mc "Yeah, something like that."
        scene 17_0661 with dissolve
        cri "I would never have guessed she'd tell you about that!"
        cri "I'm glad she felt able to, though."
        scene 17_0662 with dissolve
        cri "Yes, I was shocked... But I've had time to calm down."
        cri "The phone call - I was actually trying to apologize to her, but it didn't go as planned!"
        scene 17_0663 with dissolve
        cri "Don't worry... I'm gonna give {b}you{/b} the brownie points with her; you deserve them."
        cri "I'll apologize and tell her that {i}you{/i} convinced me I was in the wrong!"
        call laugh (mc, "Why?")
        cri "Because it's nice to know she has someone like you, who she can trust, in her corner."
        scene 17_0664 with dissolve
        cri "And I'm guessing you {i}didn't{/i} walk in on Millie either, right?"
        mc "Oh, no - I did... But I didn't yell; I just lay next to her and joined in."
        scene 17_0665 with dissolve
        cri "[lol] [mc]! You're terrible!"
        scene 17_0666 with dissolve
        cri "Why'd you choose Millie though?"
        cri "Wouldn't Cara have been more relatable to me, since I already know her?"
        scene 17_0667 with dissolve
        mc "Yeah, but I wasn't sure how you'd take it."
        mc "It could've backfired. You might've decided Cara was a bad influence or something."
        mc "I didn't want to jeopardize their friendship."
        cri "Ahhh... Smart!"
        scene 17_0668 with dissolve
        mc "Okay, I need to get outta here.\nThanks for not taking offense to my interfering!"
        cri "I'll never take offense to someone looking out for Nicole! So, thank {i}you{/i}!"
    scene 17_0669 with dissolve
    cri "Bye [mc]."
    mc "See ya."
return

label Springhaven_06_Diy:
    scene 17_0208 with fade2
    pause 0.5
    scene 17_0209 with dis1
    scene 17_0210 with dis1
    scene 17_0211 with dis1
    mct "Damn, her car isn't here."
    scene 17_0212 with dissolve
    mct "Probably at work...\nWas hoping to finish the wall today."
    mct "Hmm... Wonder if Nicole's home?"
    scene 17_0213 with dissolve
    mct "Already here, might as well knock."
    play sound "knock.mp3"
    scene 17_0214 with dis1
    pause
    scene 17_0215 with dissolve
    mc "Hey."
    nic "[mc]! Hello."
    scene 17_0216 with dissolve
    nic "Are you looking for Mom? She's at work."
    mc "Right... I wanted to get the painting done today.\nWhat time will she be back?"
    nic "Not until late."
    scene 17_0217 with dissolve
    nic "You can come in and do it now, if you like."
    mc "You sure? I don't wanna impose."
    nic "Yeah, it's fine!"
    mc "Okay, great... Thanks."
    scene 17_0218 with fade1
    nic "I don't get it... So you {i}don't{/i} want to paint??"
    mc "I do, but I need to take the photo first."
    scene 17_0219 with dissolve
    mc "Then I can go to the hardware store to try and find a matching color paint... or as close as possible, at least."
    nic "Why can't you use the paint that's in the garage?"
    scene 17_0220 with dissolve
    mc "What paint?"
    nic "There's a tin of this paint in the garage.\nI found it a while back when I was looking for supplies for an art project."
    scene 17_0221 with dissolve
    mc "There is? That's great!"
    nic "Cool. I'll get it for you."
    scene 17_0222 with dissolve
    mc "Great! Thanks, Nicole!"
    nic "You're welcome!"
    scene 17_0223 with fade
    mct "Hope it's the same paint! Makes my job a whole lot easier."
    call CenterText ("A few minutes later.")
    scene 17_0224 with fade
    mct "Should look good as new once it's been painted."
    nic "[whi]Yes, I know! Just--"
    scene 17_0225 with dissolve
    nic cell "Okay! Jeez, Mom! You've made your point!"
    nic cell "No, I--"
    scene 17_0226 with dissolve
    nic cell "Yes!"
    nic cell "I already apologized! What more--"
    nic cell "Fine! BYE!"
    scene 17_0227 with dissolve
    nic "UUUGGGHH!"
    mc "Err... Everything alright?"
    scene 17_0228 with dissolve
    call Emotion (nic, "Sigh", "Yeah, sorry.")
    nic "My Mom's pissed at me, and now she's treating me like a child."
    scene 17_0229 with dissolve
    nic "It's the same, isn't it?"
    mc "Yeah, perfect."
    scene 17_0230 with dissolve
    mc "Thanks."
    mc "I'm sure your mom'll calm down in a day or two.\nParents can be like that!"
    scene 17_0231 with dissolve
    nic "Not mine!\nShe can hold a grudge for weeks!"
    if Nicole.hasScore(6) and Nicole.Has("Uniform"):
        $ Nicole.Add("Uniform2")
        mc "Well, uhh.... if there's anything I can do to help..."
        scene 17_0234 with dissolve
        nic "Could you try talking to her??"
        mc "Uh, what?"
        nic "She likes you! You get on well together!"
        scene 17_0235 with dissolve
        mc "Yeah... but..."
        nic "Please!"
        mc "I... I don't know, Nicole... I'm not sure she'd appreciate me sticking my nose in!"
        scene 17_0236 with dissolve
        nic "Please, [mc]."
        nic "It's not fair the way she's treating me; I didn't do anything wrong!"
        nic "She might listen to you!"
        scene 17_0237 with dissolve
        mc "What {i}did{/i} you do, anyway?\nMaybe she's right to feel the way she does!"
        nic "Umm... nothing bad!"
        nic "If Cara had done it, you wouldn't care - I promise!"
        scene 17_0238 with dissolve
        mc "So tell me."
        nic "No, I can't! It's... uhh..."
        scene 17_0239 with dissolve
        nic "Okay, sorry... forget I asked."
        scene 17_0240 with dissolve
        mc "Nicole..."
        mc "... Hold on."
        scene 17_0241 with dissolve
        mc "Let me think it over. Just while I paint. Yeah?"
        nic "Okay."
        nic "Thank you."
        scene 17_0242 with dissolve
        mct "Yeah... Not a good idea, [mc]! Probably best to stay out of it."
        scene 17_0243 with dissolve
        mct "Okay... Get the gear from the truck."
    else:
        scene 17_0232 with dis1
        scene 17_0233 with dis1
        mct "Right... Get the gear from the truck and get this job done!"
    scene 17_0244 with fade2
    pause 0.5
    scene 17_0245 with fade2
    pause 0.5
    scene 17_0246 with fade2
    pause 0.5
    scene 17_0247 with fade2
    mct "Done!"
    scene 17_0248 with fade1
    pause 0.5
    scene 17_0249 with fade1
    mct "Okay... Let Nicole know I've finished."
    play sound "knock.mp3"
    scene 17_0250 with dissolve
    pause 0.5
    nic "[whi]Come in."
    scene 17_0251 with dissolve
    if not Nicole.Has("Uniform2"):
        mc "Hey. I'm all done out here."
        scene 17_0252 with dissolve
        nic "Okay.\nHopefully it'll put my mom in a better mood when she gets home."
        mc "Yeah, I hope so!\nSee you later."
        nic "Bye."
        scene 17_0269 with dissolve
        pause 0.5
        scene 17_0270 with dis1
        scene 17_0271 with dis1
        pause 0.5
        return
    mc "Hey. I'm a--"
    scene 17_0253 with dissolve
    nic "I thought if I wore this again, it might help convince you to talk to my mom."
    scene 17_0254 with dissolve
    mc "I'd like to help you, Nicole. really.\nI'm just not sure I can."
    scene 17_0255 with dissolve
    mc "Talking to your mom might make things worse."
    nic "It won't."
    scene 17_0256 with dissolve
    mc "Okay... But if you want me to talk to her, I'll need to know what you did first."
    nic "... Yeah, I know."
    scene 17_0257 with dissolve
    nic "It's.. ughh..."
    nic "It's embarrassing."
    scene 17_0258 with dissolve
    nic "I don't want to say it out loud!"
    nic "I'll tell you, but... uhh.."
    nic "... Can I just whisper it into your ear?"
    scene 17_0259 with dissolve
    mc "If you think it'll help, sure."
    scene 17_0260 with dis1
    scene 17_0261 with dis1
    nic "[whi]My mom walked in on me... while I was watching..."
    nic "[whi]... porn."
    mc "[whi]Okay..."
    scene 17_0262 with dissolve
    mc "Wait... That's it??"
    nic "[whi]Yeah."
    scene 17_0263 with dissolve
    mc "Seriously?\nShe caught you watching porn? That's all??"
    nic "[whi]Yes."
    mc "Why would she be angry about that?!"
    nic "Because she thinks I'm {i}not that type of girl{/i}!"
    scene 17_0264 with dissolve
    mc "Yeah... I can see where she's coming from."
    mc "Okay, I'm not sure {i}how{/i}... but if I get the chance, I'll talk to her for you."
    nic "Really?"
    scene 17_0265 with dissolve
    mc "How can I say no to you when you're wearing the {i}sexiest damn uniform ever{/i}?"
    nic "[lol]"
    $ tCh=Nicole.Has("EZ")
    if not EzModeActive:
        menu:
            "Leave":
                $ tCh=False
            "[wk_y]Ask about the porn":
                $ tCh=True
    if not tCh:
        scene 17_0266 with dissolve
        mc "Don't worry about it. It's not a big deal.\nShe was probably just a little shocked."
        scene 17_0267 with dissolve
        nic "But you'll talk to her?"
        mc "Yeah. I'll figure something out."
        scene 17_0268 with dissolve
        mc "See you later."
        nic "Thanks, [mc]. Bye."
        scene 17_0269 with dissolve
        pause 0.5
        scene 17_0270 with dis1
        scene 17_0271 with dis1
        pause 0.5
        return
    scene 17_0272 with dissolve
    mc "What kinda porn was it?"
    nic "...Huh?"
    mc "What were you watching?"
    nic "Umm... I don't know... just normal... Why??"
    scene 17_0273 with dissolve
    mc "The more information I have, the better I can help!"
    mc "I know it's embarrassing..."
    scene 17_0274 with dissolve
    mc "If it makes it easier to tell me, you can sit on my knee and whisper it?"
    nic "Uhh... okay..."
    call NicoleReplay01
    nic "[whi]I, uhh... I need to lie down..."
    nic "[whi]Can you see yourself out?"
    scene 17_0377 with dissolve
    mc "[whi]Uhh... Yeah.\nWhat's wrong?"
    nic "[whi]Nothing."
    nic "[whi]It's just... I've never done anything like that before."
    scene 17_0378 with dissolve
    mc "[whi]Hey, it's okay, Sweetheart!\nYou don't need to feel embarrassed!"
    nic "[whi]I know... But... I do."
    scene 17_0379 with dissolve
    nic "[whi]Please."
    mc "[whi]Okay."
    scene 17_0380 with dissolve
    nic "[whi][mc], I'm sorry... I'm not upset with you."
    mc "[whi]Don't sweat it! It's fine, Nic."
    scene 17_0381f with dissolve
    pause 0.5
    scene 17_0382f with dissolve
    scene 17_0383f with dis1
    pause 0.5
    scene 17_0384f with dis1
    mct "Mmmm, tasty!"
return

label Springhaven_06_VisitBill:
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    scene 17_0390 with fade2
    scene 17_0391 with dis1
    scene 17_0392 with dis1
    scene 17_0393 with dis1
    scene 17_0394 with dis1
    mct "Is that Christina's car?\nShe must be here to assess Bill."
    play sound "knock.mp3"
    scene 17_0395 with dis1
    pause
    scene 17_0396 with dissolve
    mar "[mc]! I didn't know you were visiting today!"
    mc "Hi, Mary.\nI just wanted to check in on you and Bill."
    scene 17_0397 with dissolve
    mar "Awww, you're so sweet!"
    scene 17_0398 with dissolve
    mc "How's he doin'? Feelin' better?"
    mar "Yes! I think he's taken a shine to the nurse you sent him!"
    scene 17_0399 with dissolve
    mc "Christina? She's only here to see what kinda care he needs."
    mar "Are you sure? She comes every day."
    scene 17_0400 with dissolve
    mc "Every day??"
    mar "She's amazing! And so lovely!"
    scene 17_0401 with dissolve
    cri "Mary, Bill asked me-- Oh, hi [mc]."
    mc "Hey."
    scene 17_0402 with dissolve
    cri "He asked me to remind you to feed the chickens."
    mar "Darn it!\nWhy do I always forget?!"
    scene 17_0403 with dissolve
    mar "Don't you leave before I get back!"
    mc "I won't!"
    scene 17_0404 with dissolve
    cri "She adores you."
    cri "I was surprised when Bill told me you'd only recently met."
    scene 17_0405 with dissolve
    cri "The way she speaks about you, I thought she'd known you her whole life!"
    mc "What are you doing here?\nI thought it'd only take a single visit to assess his needs?"
    cri "Yeah, it did."
    scene 17_0406 with dissolve
    cri "Private care is expensive.\nBill only requires the basics, but even that costs a lot."
    cri "He'll be back on his feet in a few days, so I don't mind helping out until then."
    scene 17_0407 with dissolve
    mc "Damn, Christina. That's incredibly kind of you, but I can't let you do that!"
    cri "Nonsense!"
    mc "... Well, at least let me pay you for your time!"
    scene 17_0408 with dissolve
    cri "I won't hear of it!"
    cri "I only spend an hour or so here before work, and another after."
    cri "If I have the day free, I spend more time here.\nBut I'm more than happy to help, [mc]."
    mc "Wow, I don't know what to say. Thank you so much."
    mc "So, how's he doin'?"
    scene 17_0409 with dissolve
    cri "Good!\nHe'll be back to work in no time - even though he shouldn't be working at all!"
    cri "If it were up to him, he'd be out on the road right now!"
    cri "He's a stubborn old man! Half my time here is spent convincing him to stay in bed."
    scene 17_0410 with dissolve
    mc "He's not giving you a hard time, is he?\nI'll talk to him if he's being difficult."
    cri "No, he's fine!\nHe's always polite and respectful. Just doesn't like the fuss."
    scene 17_0411 with dissolve
    cri "He permitted me to access his medical records, on condition I don't reveal too much to Mary."
    mc "Yeah, she doesn't know how bad things are."
    cri "He {i}did{/i} tell me I could discuss them with you, however."
    mc "Okay... So how bad is it?"
    scene 17_0412 with dissolve
    cri "It's not great."
    cri "The specialist approximated that he could have as little as eight to fifteen months."
    mc "[whi]Damn."
    cri "The sad part is, if he'd had medical insurance, they would've given him the surgery."
    scene 17_0413 with dissolve
    mc "Surgery? You mean they can fix him??"
    cri "Yeah, if his insurance had covered it."
    mc "I guess it's too late now?"
    scene 17_0414 with dissolve
    cri "For insurance, yes - his pre-existing conditions wouldn't be covered."
    mc "But it's not too late for the operation?"
    cri "No, but without insurance, the cost would be astronomical."
    mc "How astronomical?"
    scene 17_0415 with dissolve
    cri "You're not thinking..."
    cri "... Unless you're a secret millionaire, you couldn't afford it. Sorry."
    scene 17_0416 with dissolve
    cri "And if you {b}are{/b}... I'll be kicking myself for giving you a good deal on the truck!"
    scene 17_0417 with dissolve
    mc "Nah, I'm not."
    if Christina.isActive():
        mc "If I were, I probably wouldn't have spent the morning painting your holes!"
        cri "You did?!"
        mc "Yeah, the wall looks good as new."
        scene 17_0418 with dissolve
        cri "That's great! Thank you!"
        cri "Please tell me the leaky pipe in the bathroom is next on your list!"
        scene 17_0419 with dissolve
        mc "Well, I'm {b}your{/b} guy!"
        mc "So you tell me what to do, and I do it!"
        scene 17_0420 with dissolve
        cri "You probably shouldn't tell me that, [mc]!"
        cri "I may be tempted to show you more holes that would like to be filled!"
        scene 17_0419 with dissolve
        mc "Sweetheart, you show me the hole, and I'll fill it."
        scene 17_0421 with dissolve
        cri "[lol] Oh, my God! You made me blush!"
        call laugh (mc, "Sorry.")
        scene 17_0422 with dissolve
    else:
        scene 17_0423 with dissolve
    cri "I should get back to work."
    mc "Yeah, okay."
    if Nicole.Has("Uniform2"):
        scene 17_0424 with dissolve
        mc "Ohh... Could I ask your advice on something quickly?"
        scene 17_0425 with dissolve
        cri "Of course. What's up?"
        mc "You know I have another daughter, right?"
        cri "Yeah, Alison told me about her... Millie?"
        mc "Yeah."
        scene 17_0426 with dissolve
        mc "On my last visit, I... uhh..."
        mc "I kinda walked in on her while she was... {i}busy{/i}... if you know what I mean."
        cri "Oh dear!"
        mc "Yeah... I yelled at her... I--"
        scene 17_0427 with dissolve
        cri "Are you asking my advice as a nurse, or a parent?"
        cri "Because, as a parent - Why would you yell at her??\nIt's a perfectly natural thing for someone of her age to do!"
        mc " I was embarrassed, I guess... I didn't think she did that kinda thing."
        scene 17_0428 with dissolve
        cri "[mc], I hate to break it to you, but {b}all{/b} young women do {i}that kinda thing{/i}!"
        cri "It's normal! Don't be so hard on her!"
        cri "I had a similar experience just the other--"
        scene 17_0429 with dissolve
        cri "Ohhh... Wow!"
        cri "She {i}actually{/i} told you about that, huh??"
        scene 17_0430 with dissolve
        mc "Yeah... I'm sorry.\nI was there when you called her."
        mc "She was upset about the whole thing... asked me if I'd talk to you."
        mc "I tried to tell her it'd probably make things worse, but she--"
        cri "Gave you the 'ole puppy dog eyes? [lol]"
        mc "Yeah, something like that."
        scene 17_0431 with dissolve
        cri "I would never have guessed she'd tell you about that!"
        cri "I'm glad she felt able to, though."
        scene 17_0432 with dissolve
        cri "Yes, I was shocked... But I've had time to calm down."
        cri "The phone call - I was actually trying to apologize to her, but it didn't go as planned!"
        scene 17_0433 with dissolve
        cri "Don't worry... I'm gonna give {b}you{/b} the brownie points with her; you deserve them."
        cri "I'll apologize and tell her that {i}you{/i} convinced me I was in the wrong!"
        scene 17_0434 with dissolve
        call laugh (mc, "Why?")
        cri "Because it's nice to know she has someone like you, who she can trust, in her corner."
        cri "And I'm guessing you {i}didn't{/i} walk in on Millie either, right?"
        mc "Oh, no - I did... But I didn't yell; I just lay next to her and joined in."
        scene 17_0435 with dissolve
        cri "[lol] [mc]! You're terrible!"
        scene 17_0436 with dissolve
        cri "Why'd you choose Millie?"
        cri "Wouldn't Cara have been more relatable to me, since I already know her?"
        scene 17_0437 with dissolve
        mc "Yeah, but I wasn't sure how you'd take it."
        mc "It could've backfired. You might've decided Cara was a bad influence or something."
        mc "I didn't want to jeopardize their friendship."
        cri "Ahhh... Smart!"
    scene 17_0438 with dissolve
    mar "Chickens are done!"
    cri "I'll let Bill know!\nOne less thing for him to complain about."
    scene 17_0439 with dissolve
    mar "Should I see what else he needs?"
    cri "Honey, that's why {b}I'm{/b} here!"
    cri "We've talked about this.\nWhile I'm here, you should be relaxing."
    scene 17_0440 with dissolve
    mar "I know, sorry.\nI just feel like I'm not pulling my weight when you do everything."
    cri "You do plenty! More than plenty!"
    cri "You need to look after {i}yourself{/i}, too, Mary."
    scene 17_0441 with dissolve
    cri "Take a nap. Go for a walk. Watch a movie. Have a nice long soak in the bath."
    cri "Whatever it is that helps you recharge your batteries.\nThat's how you help your Pops while I'm here."
    mar "Okay. I'll try."
    if Mary.isSexual():
        $ tCh=Nicole.Has("EZ")
        if not EzModeActive:
            menu:
                "[wk_y]Offer to take Mary for a walk":
                    $ tCh=True
                "Convince Mary to relax":
                    $ tCh=False
    if tCh:
        scene 17_0442 with dissolve
        mc "She's right, Mary.\nI'll even come with you for a walk, if you like!"
        mar "You will?"
        scene 17_0443 with dissolve
        mc "Hell yeah!\nCome on, let's get outta Christina's hair for a while."
        mar "Okay!"
        scene 17_0444 with dissolve
        cri "Thanks, [mc].\nGetting her to relax has been virtually impossible."
        mc "Happy to help."
        call Springhaven_06_MaryWalk
        return
    scene 17_0442 with dissolve
    mc "She's right, Mary.\nBill's still gonna need your help once Christina's done here."
    scene 17_0443 with dissolve
    mc "So take advantage of her generosity and take it easy!"
    mar "Okay... I'll take a bath."
    scene 17_0444 with dissolve
    cri "Thanks, [mc].\nGetting her to relax is virtually impossible."
    mc "She needs to understand that sometimes, {i}not{/i} helping {b}is{/b} helping."
    scene 17_0445 with dissolve
    mc "Is he up for a visitor?"
    cri "Can you come back later? He's asleep right now."
    cri "He doesn't get much quality rest; I'd rather not disturb him."
    mc "Yeah, let him sleep."
    mc "Now that I know he's in capable hands, I don't need to worry so much."
    scene 17_0446 with fade1
    scene 17_0447 with dis1
    scene 17_0448 with dis1
    scene 17_0449 with dis1
return

label Springhaven_06_MaryWalk:
    scene 17_0450 with fade2
    pause 0.5
    scene 17_0451 with dis1
    mar "C'mon, slowpoke!"
    scene 17_0452 with dissolve
    mc "This is supposed to be a leisurely walk, not a race!"
    scene 17_0453 with dissolve
    mar "But you walk too slow!"
    scene 17_0454 with dissolve
    mc "What's the rush?"
    mar "I'm excited to show it to you!"
    scene 17_0455 with dissolve
    mar "We're almost there. It's not much further."
    mc "Why's this place special to you?"
    scene 17_0456 with dissolve
    mar "I used to love exploring around here when I was a kid.\nI found the place, and it felt like a {i}real{/i} adventure!"
    scene 17_0457 with dissolve
    mar "I kept going back to it.\nIt was like my own little secret garden that no one else could find."
    scene 17_0458 with dissolve
    mar "I haven't been in such a long time, though. I hope it's still there!"
    scene 17_0459 with fade2
    mar "We're here!!"
    call MaryReplay06
    scene 17_0613 with fade1
    mar "Going for a walk is a lot more fun with you![giggles]"
    call laugh (mc)
    scene 17_0614 with dis1
    scene 17_0615 with dis1
    scene 17_0616 with fade2
    pause 0.5
    scene 17_0617 with fade
    cri "How was your walk?"
    mar "Fun![giggles]"
    scene 17_0618 with dissolve
    mar "I'm gonna take a bath.\nI'm all sweaty and sticky... thanks to [mc]!"
    scene 17_0619 with dissolve
    cri "Wow! If he helps you relax this much, maybe he should visit more often!"
    mar "I agree![giggles]"
    scene 17_0620 with dissolve
    cri "Damn, must've been a helluva walk!\nWhatever you did to relax her... nice job!"
    if Christina.isActive():
        cri "I know who to call the next time {i}I'm{/i} stressed and need to relax!"
        mc "Sweetheart, I'd relax you so much you'd be in a coma."
        scene 17_0621 with dissolve
        cri "[lol]{w=1}{nw}"
        scene 17_0622 with dissolve
        cri "Jeez! I can't stop blushing around you!"
        cri "I can't decide whether you're good at flirting, or I'm terrible at it!"
        scene 17_0623 with dissolve
        call laugh (mc, "I'm sorry.")
        mc "Sometimes I say things without thinking.\nI'll try and stop."
        cri "No, don't do that... I like it."
        scene 17_0624 with dissolve
        cri "You make me feel like a dizzy teenager all over again!"
        mc "And who wouldn't want that, right?"
        cri "Exactly![lol]"
    mc "Bill up for a visitor?"
    scene 17_0625 with dissolve
    cri "Can you come back later? He's asleep right now."
    cri "He doesn't get much quality rest; I'd rather not disturb him."
    scene 17_0626 with dissolve
    mc "Yeah, let him sleep.\nAnd now that I know he's in capable hands, I don't need to worry so much."
    mc "Okay, I'll leave you to it.\nThanks again for this, Christina."
    cri "My pleasure. See you later."
    scene 17_0446 with fade1
    scene 17_0447 with dis1
    scene 17_0448 with dis1
    scene 17_0449 with dis1
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
