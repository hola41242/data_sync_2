label CaraReplay01_Part01:
    scene 01_0953 with Fade(2, 1, 1)
    pause 1.0
    scene 01_0954 with dissolve
    mc "Cara, we were only messin'!\nI didn't think you were serious!"
    car "It's what we agreed!\nYou did your part, now it's my turn."
    scene 01_0955 with dissolve
    car "Sit down, let's get it over with.[giggles]"
    mc "Okay, if you insist!"
    scene 01_0956 with dissolve
    car "Oh my god... This is embarrassing."
    mc h "Come on, let's just forget about it."
    scene 01_0957 with dissolve
    car "Err, no! Don't you move! I'm doin' this!"
    scene 01_0958 with dis1
    scene 01_0959 with dis1
    scene 01_0960 with dis1
    scene 01_0961 with dis1
    scene 01_0962 with dis1
    scene 01_0963 with dis1
    car "There!"
    scene 01_0964 with dissolve
    mc "I thought you were gonna show me your {b}boobs{/b}??"
    car "As much of them as you could see at the bar!"
    mc "[lol]"
    scene 01_0965 with dissolve
    mc "You look beautiful, Pipsqueak."
    car h "Thanks."
    mc "Okay, deal complete. I'll see you later."
    if not _in_replay:
        if not Cara.hasScore(4):
            car "Bye, Uncle [mc]."
            scene black with Fade(3, 1, 0)
            return
        else:
            $ Cara.Add("ShowsBoobs")
    scene 01_0966 with dissolve
    car "I know you're just teasing me.\nYou don't {i}really{/i} want to see them."
    mc h "I'm not teasing {i}you{/i}! You're teasing {b}me{/b}!"
    scene 01_0967 with dissolve
    if not _in_replay and Cara.Has("B1"):
        $ Cara.Del("B1")
        car h "So you {b}were{/b} lookin' at them this morning!\nI knew it!"
    else:
        car "Oh."
    scene 01_0968 with dis1
    scene 01_0969 with dis1
    scene 01_0970 with dis1
    car "Happy now?"
    if not _in_replay:
        if Cara.hasScore(6):
            if persistent.UseFocus and not EzModeActive:
                $ _skipping = False
                show screen imgMap("images/e01/01_0971.webp", 1182, 386, True, "CaraReplay01_Part02") with dissolve
                mc "Oh shit! You weren't teasing??"
                $ _skipping = True
                if renpy.get_screen("imgMap"):
                    scene 01_0971
                    hide screen imgMap  
                    call CaraReplay01_End
            else:
                scene 01_0971 with dissolve
                mc "Oh shit! You weren't teasing??"
                if not EzModeActive:
                    menu:
                        "[wk_y]Grab her boobs":
                            call CaraReplay01_Part02
                        "Don't":
                            call CaraReplay01_End
                else:
                    call CaraReplay01_Part02
        else:
            scene 01_0971 with dissolve
            mc "Oh shit! You weren't teasing??"
            call CaraReplay01_End
return

label CaraReplay01_End:
    car h "{b}Now{/b} it's {i}deal complete{/i}!"
    mc "Heh. Yep, it is."
    scene 01_0972 with dissolve
    mc "Damn!"
    car "Oh my god, you're such a perv![giggles]"
    mc h "See ya later, Pipsqueak."
    car "Bye."
    scene black with Fade(3, 1, 0)
return

label CaraReplay01_Part02:
    call Unlocker ("CaraReplay01_Part02")
    if _in_replay:
        call CaraReplay01_Part01
        scene 01_0971 with dissolve
        mc "Oh shit! You weren't teasing??"
    else:
        $ Cara.Add("BoobPlay")
        $ Cara.Del("ShowsBoobs")
        $ Cara.isSexual(True)
        scene 01_0971
        hide screen imgMap
        $ _skipping = True
    scene 01_0973 with dissolve
    car "Whoa!\nI didn't say anything about touching!"
    scene 01_0974 with dissolve
    mc "Shit. I don't know why I did that!\nI'm sorry, Pipsqueak."
    scene 01_0975 with dissolve
    car "Gotcha!"
    scene 01_0976 with dissolve
    car "You can touch 'em if you want."
    scene 01_0977 with dissolve
    mc "I... can?"
    car "[whi]Yeah."
    scene 01_0978 with fade
    car "Do you think they're too small?"
    scene 01_0979 with dissolve
    car "I kinda wish they were a bit bigger."
    scene 01_0980 with dissolve
    mc "No..."
    scene 01_0981 with dissolve
    mc "They're {i}perfect{/i} as they are."
    scene 01_0982 with dissolve
    mct "What the hell am I doing?! This is SO wrong!"
    scene 01_0984 with dissolve
    mct "... I can't stop myself!"
    call Loop_Dissolve (4, True, False, "e01/01_0983.webp", "e01/01_0984.webp")
    mc "You okay?"
    car "[whi]Mh-hmm."
    scene 01_0985 with dissolve
    car "[whi]I touch them all the time, but it's never felt like... this."
    mc "I can make it feel even nicer if you'd like me to..."
    car "[whi]Umm...{size=*.8} okay."
    scene 01_0986 with fade
    mct "I'm goin' to hell."
    scene 01_0987 with dissolve
    pause
    scene 01_0988 with dissolve
    car "[whi]This is {i}so{/i} wrong, but..."
    scene 01_0989 with dissolve
    car "[whi]Fuck..."
    scene 01_0990 with dissolve
    car "[ss]..Mmmhhh.."
    scene 01_0991 with dis1
    pause 1.0
    scene 01_0992 with dis1
    pause 1.0
    scene 01_0993 with dis1
    pause 1.0
    scene 01_0994 with dis1
    pause 1.0
    scene 01_0995 with dis1
    car "[whi][kiss]"
    pause 0.5
    scene 01_0996 with dis1
    car "[whi][kiss]"
    pause 0.5
    scene 01_0997 with dis1
    car "[whi][kiss]"
    pause 0.5
    scene 01_0998 with dissolve
    car "[whi][kiss]"
    scene 01_0999 with dis1
    pause 1.0
    scene 01_0998 with dissolve
    car "[whi][kiss]"
    scene 01_0999 with dis1
    pause 1.0
    scene 01_1000 with dis1
    scene 01_1001 with dis1
    car "[ss]..Mmmhhh.."
    scene 01_1002 with dissolve
    car "[ss]...Mmmmmhhh..."
    scene 01_1003 with dis1
    pause 0.5
    scene 01_1004 with dis1
    pause 0.5
    scene 01_1005 with dis1
    pause 0.5
    scene 01_1006 with dis1
    pause 0.5
    scene 01_1007 with dissolve
    pause 0.5
    scene 01_1001 with dissolve
    car "[ss]..Mmmmmhhh.."
    scene 01_1008 with dissolve
    pause 0.5
    scene 01_1009 with dissolve
    car "...WHOA!"
    scene 01_1010 with dissolve
    car "That's too far."
    mc "Yeah."
    scene 01_1011 with dissolve
    car "I've... uhh... never..."
    mc "It's okay, Pipsqueak!"
    car "You're not mad?"
    mc "No, of course not."
    scene 01_1012 with dissolve
    car "You'd better go, the cafe will be closing soon."
    scene 01_1013 with dissolve
    pause 0.5
    scene 01_1014 with dissolve
    car "[ss]..Mmmhhh.."
    scene 01_1015 with dissolve
    car h "[whi]God, I {i}really{/i} like kissing you!"
    mc "I like you kissing me, too."
    scene black with Fade(3, 1, 0)
return

label CaraReplay02_Part01:
    if _in_replay:
        scene 03_0126 with Fade(0,0,2)
        car "You, uhh... don't want to kiss me?"
    mc "Yes, I do. That's the problem!"
    car "Huh?"
    scene 03_0131 with dissolve
    mc "You're my {b}daughter{/b}, Cara!"
    mc "We shouldn't be doing... this."
    scene 03_0132 with dissolve
    car "I was your daughter when you wanted to see my tits!"
    if _in_replay or Cara.Has("L1"):
        car "I was your daughter when you had my nipple between your teeth!"
        car "You said you liked it when we kiss?"
        mc "I do!"
    mc "It's different now!"
    scene 03_0133 with dissolve
    car "Why?? Because I know you're my dad??"
    car "I knew {b}then{/b}, too!"
    scene 03_0134 with dissolve
    mc "And you're okay with that??"
    mc "Kissing {b}your dad{/b}? Like that??"
    car "Yeah."
    scene 03_0135 with dissolve
    car "I like us kissing, being close."
    car "I'm not stupid. I know we can't ever have sex 'n' stuff!"
    if _in_replay or Cara.Has("L1"):
        car "That was one of the reasons I stopped you in my bedroom!"
    car "But we can just kiss... fool around... can't we?"
    scene 03_0136 with dissolve
    mc "[whi]I guess.. If that's all it is, yeah..."
    scene 03_0137 with dissolve
    car "[ss]Mmhhh.."
    scene 03_0138 with dissolve
    car "[ss]...Mmmmhhh..."
    scene 03_0139 with dissolve
    car "[ss]..Mmhhh.."
    scene 03_0140 with dissolve
    car "[ss]..Mmh.."
    scene 03_0141 with dissolve
    pause 0.5
    scene 03_0142 with dis1
    pause 0.5
    scene 03_0143 with dis1
    pause 0.5
    scene 03_0144 with dis1
    car "[ss]..Mmhhh.."
    scene 03_0145 with dissolve
    car "[whi]Wanna see 'em {i}again{/i}?"
    scene 03_0146 with fade
    pause 0.5
    scene 03_0147 with dis1
    pause 0.5
    scene 03_0148 with dis1
    pause 0.5
    scene 03_0149 with dis1
    pause
    scene 03_0150 with dis1
    pause 0.5
    scene 03_0151 with dissolve
    car "[whi]Happy now?"
    scene 03_0152 with dissolve
    mc "Yep, heh."
    scene 03_0153 with dissolve
    mc "Happy, happy, happy."
    car "[lol]"
    scene 03_0154 with dissolve
    car "[ss]..Mmhhh.."
    scene 03_0155 with dissolve
    car "[ss]...Mmmmhhh..."
    scene 03_0156 with dissolve
    pause 1.0
    scene 03_0157 with dis1
    pause
    scene 03_0158 with dissolve
    pause 1.0
    scene 03_0159 with dis1
    pause
    scene 03_0160 with dissolve
    car "[ss]..Mmhhh.."
    scene 03_0161 with dissolve
    pause
    scene 03_0162 with dissolve
    car "[ss]...Mmmmhhh..."
    scene 03_0163 with dissolve
    car "[ss]Kiss me again, Daddy."
    scene 03_0164 with dissolve
    car "[ss]..Mmhhh.."
    scene 03_0165 with dissolve
    car "[ss]...Mmmmhhh..."
    scene 03_0166 with dissolve
    car "[whi]It's late. I should get back to bed."
    mc "[whi]Yeah."
    scene 03_0167 with dissolve
    car "[kiss]"
    scene 03_0168 with dissolve
    car "[whi]I love this."
    scene 03_0169 with fade
    car "I'd better not forget this!\nYou'd have some awkward questions to answer if Mom found it in here!"
    mc "[lol]"
    if not _in_replay:
        if Cara.Has("L0"):
            $ Cara.Add("L1")
            scene 03_0170 with dissolve
            car "[whi]Goodnight, Dad. Love you."
            mc "[whi]Night, Pipsqueak. I love you, too."
            scene 03_0121 with Fade(1, 0, 1)
            mct "No idea how Alison's gonna react when she finds out that Cara knows."
            scene 03_0122 with dissolve
            mct "She finally knows!"
            scene 03_0123 with dissolve
            pause 0.5
        else:
            $ Cara.Add("L2")
            call CaraReplay02_Part02
            scene 03_0121 with Fade(1, 0, 1)
            mct "Why the hell didn't I stop her? Fuck..."
            mct "... Because... I {b}didn't want{/b} her to stop... That's why."
            mct "..."
            mct "No idea how Alison's gonna react when she finds out Cara knows the truth."
            scene 03_0122 with dissolve
            mct "She finally knows!"
            scene 03_0123 with dissolve
            pause 0.5
return

label CaraReplay02_Part02:
    call Unlocker ("CaraReplay02_Part02")
    if _in_replay:
        call CaraReplay02_Part01
    scene 03_0171 with dissolve
    car "[giggles]Ummm..."
    scene 03_0172 with dissolve
    pause
    scene 03_0173 with dissolve
    pause 0.5
    scene 03_0174 with dissolve
    mc "{b}Fuck!{/b} Sorry!"
    scene 03_0175 with dissolve
    car "Aww, no! Don't hide him!"
    scene 03_0176 with dissolve
    car "I wanna meet him!"
    mc "No chance!!"
    scene 03_0177 with dissolve
    mc "And, uhh... {b}Him{/b}??"
    car "Yeah!"
    scene 03_0178 with dissolve
    car "You're {b}Daddy{/b}, and he's {b}Little Daddy{/b}!"
    mc "Under absolutely no circumstances are you ever allowed to call my penis {i}{b}Little{/b}{/i} Daddy![lol]"
    car "Well... if you want him to have a better name, I {b}have{/b} to meet him first!"
    scene 03_0179 with dissolve
    car "Don't I, {i}Little Daddy{/i}?"
    mc "[whi]Oh, jeez!"
    scene 03_0180 with dissolve
    car "[whi]Pleeeeease?"
    mc "[whi]... Fuck..."
    scene 03_0181 with dissolve
    pause 1.0
    scene 03_0182 with dis1
    pause 1.0
    scene 03_0183 with dis1
    pause 1.0
    scene 03_0184 with dis1
    pause 1.0
    scene 03_0185 with dis1
    car "[whi]Whoa, I didn't know they got {i}this{/i} hard!"
    scene 03_0186 with dissolve
    car "[whi]Doesn't it hurt??"
    mc "[whi]No. [lol]"
    car "[whi]Oh.\nAre you sure?"
    car "[whi]I thought I might try rubbing it better?"
    mc "[whi]Umm... actually, now you mention it..."
    scene 03_0187 with dissolve
    car "[giggles]"
    scene 03_0188 with dissolve
    pause 0.5
    image r_cara_001 = Movie(play="images/e03/03_0189.webm")
    show r_cara_001 with dissolve
    mct "...What the fuck am I doing?..."
    mct "... Damn, that feels nice... "
    scene 03_0190 with dissolve
    pause 1.0
    scene 03_0191 with dissolve
    pause 1.0
    scene 03_0192 with dissolve
    pause 1.0
    scene 03_0193 with dissolve
    pause 1.0
    scene 03_0194 with dis1
    pause 0.5
    scene 03_0195 with dis1
    pause 0.5
    scene 03_0196 with dis1
    pause 0.5
    scene 03_0197 with dissolve
    pause 0.5
    scene 03_0198 with dis1
    car "[ss]Mmhh.."
    scene 03_0199 with dissolve
    mc "Oh, shit! No!"
    scene 03_0200 with dissolve
    mc "[whi]You can't do..."
    scene 03_0201 with dissolve
    mc "[whi]..Fuck..."
    scene 03_0202 with dissolve
    pause 0.5
    image r_cara_002 = Movie(play="images/e03/03_0203.webm")
    show r_cara_002 with dissolve
    car "[ss]..Mmhh.."
    scene 03_0204 with dissolve
    mct "...This is wrong...."
    scene 03_0205 with dis1
    pause 0.5
    scene 03_0206 with dis1
    pause 1.0
    scene 03_0207 with dissolve
    mct "..Sooo fuckin' wrong...."
    scene 03_0208 with dissolve
    pause 0.5
    image r_cara_003 = Movie(play="images/e03/03_0209.webm")
    show r_cara_003 with dissolve
    car "[ss]..Mmmmhh.."
    scene 03_0210 with dissolve
    mc "[whi]Fuck... Cara, stop... I'm gonna..."
    scene 03_0211 with dissolve
    mc "[whi]...Cara...stop..."
    call CharCum ("e03/03_0212.webp", "e03/03_0213.webp", mc, "NNNGGGGGHHHH!!")
    call CharCum ("e03/03_0213.webp", "e03/03_0214.webp", mc, "....FUCK....")
    scene 03_0215 with dissolve
    car "[ss]Mmhhh.."
    scene 03_0216 with dissolve
    car "[ss]...Mmh..."
    scene 03_0217 with dissolve
    car "[whi]It's true! It {i}is{/i} salty!"
    scene 03_0218 with dissolve
    car "[whi]Night, Daddy."
    scene 03_0219 with dissolve
    car "[kiss]"
    scene 03_0220 with dissolve
    car "[whi]Night, {i}Little{/i} Daddy."
    scene 03_0221 with dissolve
    car "[kiss]"
    scene 03_0222 with dissolve
    mc "[whi]Goodnight, Pipsqueak."
    scene 03_0223 with dissolve
    pause 1.0
    if _in_replay:
        scene black with ReplayFade
return

label CaraReplay03:
    call Unlocker ("CaraReplay03")
    if not _in_replay:
        $ persistent.CaraRP03Dat=([cedargrove_ch, Nettie.isActive(), (True if (Alison.isActive() and Alison.L>3) else False), Alison.Has("Anal"), Cara.isSexual()])
    scene 05_0244 with fade2
    mct "What's taking her so long?"
    scene 05_0245 with dissolve
    car "Dad."
    scene 05_0246 with dissolve
    car "I want you to be honest with me, okay?"
    mc "Okay."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e05/05_0247.webp", 686, 275, True, "Springhaven_AF23") with dissolve
        car "What do you think of this new bikini?"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 05_0247
            hide screen imgMap
            mc "Damn!"
    else:
        scene 05_0247 with dissolve
        car "What do you think of this new bikini?"
        call Springhaven_AF23
    scene 05_0249 with dissolve
    car "You like it?"
    scene 05_0250 with dissolve
    mc "Yeah!!\nYou look... WOW!"
    scene 05_0251 with dissolve
    car "You're not just saying that, are you?"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e05/05_0252.webp", 1188, 475, True, "Springhaven_AF24") with dissolve
        car "What about the back? Do you like it from behind?"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 05_0252
            hide screen imgMap
            mc "Yup. Perfect."
    else:
        scene 05_0252 with dissolve
        car "What about the back? Do you like it from behind?"
        call Springhaven_AF24
    scene 05_0254 with dissolve
    car "Thanks, Dad!\nThat makes me happy."
    car "Because all I could think about when I was buying it was..."
    scene 05_0255 with dissolve
    car "... {i}I wonder if my daddy would love to see me in this?"
    scene 05_0256 with dissolve
    car "I can tell {i}Little Daddy{/i} does."
    if not persistent.CaraRP03Dat[4]:
        mc "Little Daddy??"
        car "Mh-mhh."
    car "I feel him pressing up against me."
    scene 05_0257 with dissolve
    car "[ss]Mmmmhh."
    scene 05_0258 with dissolve
    scene 05_0259 with dis1
    car "[ss]..Mmmhh.."
    scene 05_0260 with dissolve
    pause
    scene 05_0261 with dissolve
    car "[ss]..Mmmhh.."
    scene 05_0262 with dissolve
    scene 05_0263 with dis1
    pause
    scene 05_0264 with dissolve
    car "[ss]Mmmmhh."
    scene 05_0265 with dissolve
    scene 05_0266 with dis1
    car "[ss]..Mmmhh.."
    scene 05_0267 with dis1
    scene 05_0268 with dis1
    scene 05_0269 with dissolve
    mc "[whi]Whoa.\nWhat you doing?"
    scene 05_0270 with dissolve
    car "[whi]It's okay, Dad."
    mc "[whi]Cara, no. We're going too far."
    scene 05_0271 with dissolve
    if persistent.CaraRP03Dat[4]:
        car "[whi]You let me touch you, what's the difference?"
    else:
        car "[whi]You touch my breasts, what's the difference?"
    scene 05_0272 with dissolve
    car "[whi]It's only a little touching, that's all."
    car "[whi]No big deal."
    scene 05_0273 with dissolve
    car "[whi]Please, Daddy."
    scene 05_0274 with dissolve
    car "[ss]Mmmmhh."
    scene 05_0275 with dissolve
    mct "Fuck..."
    mct "It {b}IS{/b} too far..."
    scene 05_0276 with dis1
    mct "...But I can't stop myself..."
    scene 05_0277 with dissolve
    image r_cara_004 = Movie(play="images/e05/05_0278.webm")
    show r_cara_004 with dissolve
    car "[ss]..MMmmmhhh.."
    scene 05_0279 with dissolve
    call Moan (car, 4)
    scene 05_0280 with dissolve
    mct "Fuck it... Like she said, it's only touching..."
    scene 05_0281 with dis1
    scene 05_0282 with dis1
    scene 05_0283 with dis1
    scene 05_0284 with dis1
    scene 05_0285 with dissolve
    scene 05_0286 with dissolve
    scene 05_0287 with dissolve
    scene 05_0288 with dissolve
    image r_cara_005 = Movie(play="images/e05/05_0289.webm")
    show r_cara_005 with dissolve
    call Moan (car, 4)
    image r_cara_006 = Movie(play="images/e05/05_0290.webm", loop=False, keep_last_frame=True)
    show r_cara_006 with dissolve
    pause
    scene 05_0291 with dissolve
    car "[ss]...Ohh, Dad...."
    scene 05_0292 with dis1
    call Moan (car)
    scene 05_0293 with dis1
    car "[ss]...OHHHH...."
    play sound "qknock.mp3"
    pause 1.0
    ali "[whi][persistent.McName]? Is that you in there?"
    scene 05_0294 with hpunch
    mc "Err... Yeah.\nI'm in the shower."
    ali "[whi]I can't hear the water?"
    mc "No, uhh... I'm just getting in..."
    ali "[whi]What?"
    ali "[whi]Open the door, I can't hear you!"
    scene 05_0295 with dissolve
    mc "Uhh... Gimme a minute..."
    car "[whi]What?! You can't let her in!"
    car "[whi]She can't find me in here with you, dressed like this!!"
    scene 05_0296 with dissolve
    mc "[whi]If I don't open the door, she'll know something's up!"
    mc "[whi]I won't let her in; stay hidden!"
    ali "[whi][persistent.McName]?"
    scene 05_0297 with dissolve
    mc "Yeah, coming."
    scene 05_0298 with dissolve
    mc "Heeeyy, Alison! Wassup?"
    scene 05_0299 with dissolve
    ali "Did you see Nettie?? How'd it go?"
    scene 05_0300 with dissolve
    if persistent.CaraRP03Dat[0]<3:
        mc "Err, I didn't go.\nFigured I'd give her a bit more time to cool down."
        ali "Oh... Okay."
    elif not persistent.CaraRP03Dat[1]:
        mc "It was a disaster.\nShe's never gonna forgive me."
        ali "Oh dear.\nMaybe try again in a month or two?"
        mc "Nah, I'll just leave her be."
        ali "Oh... Okay."
    else:
        mc "Good, I think!\nWe're friends again, at least."
        ali "That's great!\nI'm so relieved you were able to make up with her!"
    scene 05_0301 with dissolve
    ali "Did you have time to visit Millie, too?"
    scene 05_0302 with dissolve
    mc "Yeah!\nThings are going pretty well with her."
    scene 05_0303 with dissolve
    ali "Violet doesn't mind you visiting so often?"
    mct "What the hell is she doing??"
    scene 05_0304 with dissolve
    ali "[persistent.McName]?"
    mc "Uhh, yeah.\nNo, Violet's been great."
    scene 05_0305 with dissolve
    image r_cara_007 = Movie(play="images/e05/05_0306.webm")
    show r_cara_007 with dissolve
    ali "That's good."
    mc "Uh, yeah."
    ali "I always got the feeling Vi didn't like me, but I think she's lovely, so I'm glad you're both making things work."
    mc "She {b}does{/b} like you! It was... uhh..."
    mc "Can we talk about this later?"
    ali "Yeah, of course. You want to shower."
    scene 05_0299 with dissolve
    ali "Ohh... Have you seen Cara?\nI thought she'd be home."
    show r_cara_007 with dissolve
    mc "Err, no."
    mc "I've only just got back myself."
    ali "Oh, okay."
    image r_cara_008 = Movie(play="images/e05/05_0307.webm", loop=False, keep_last_frame=True)
    show r_cara_008 with dissolve
    pause 1.0
    scene 05_0308 with dissolve
    ali "She's probably with Alex or Nicole.\nI'll text her."
    ali "I won't tell her you're back yet."
    scene 05_0309 with dissolve
    image r_cara_009 = Movie(play="images/e05/05_0310.webm")
    show r_cara_009 with dissolve
    ali "That girl loves you so much she'd probably ditch her friends to come hang out with you!"
    car "[ss]Mh-mhh."
    ali "God, I wish we could just tell her the truth."
    scene 05_0311 with dissolve
    image r_cara_010 = Movie(play="images/e05/05_0312.webm")
    show r_cara_010 with dissolve
    mc "Why can't we?"
    ali "I'd love to, [persistent.McName], you know that!"
    ali "I'm just not sure how she'd react to knowing she's your daughter.\nThat we've lied to her for all this time!"
    ali "I couldn't handle her hating us!"
    scene 05_0313 with dissolve
    mc "She wouldn't hate us!\nShe might even surprise you and understand why we didn't tell her!"
    scene 05_0311 with dissolve
    image r_cara_011 = Movie(play="images/e05/05_0314.webm", loop=False, keep_last_frame=True)
    show r_cara_011 with dissolve
    pause 3.0
    scene 05_0304 with dissolve
    ali "I'd like to believe that, but... I don't know... It's too risky."
    image r_cara_012 = Movie(play="images/e05/05_0315.webm")
    show r_cara_012
    ali "Perhaps we should discuss it later?"
    mc "Yeah."
    scene 05_0316 with dissolve
    image r_cara_013 = Movie(play="images/e05/05_0317.webm")
    show r_cara_013 with dissolve
    ali "She already acts like she's your daughter, anyway!"
    if persistent.CaraRP03Dat[2]:
        ali "Uhh... Why are you acting weird??"
        mc "Ehh?"
        scene 05_0318 with dissolve
        ali "Why are you hiding behind the door?"
        ali "It's not like I haven't seen you naked before![lol]"
        scene 05_0319 with dissolve
        mc "I'm not hiding!\nI feel grubby after the long drive.\nI'm all sweaty and stinky! Heh."
        scene 05_0320 with dissolve
        ali "The thought of you being naked behind there is making me a little horny."
        scene 05_0321 with dissolve
        ali "Want to sneak into my room tonight?"
        scene 05_0323 with dissolve
        if persistent.CaraRP03Dat[3]:
            ali "I'll let you put it in my ass again."
        else:
            ali "I want to feel you inside me again."
    else:
        ali "Okay, I'll let you shower in peace.[lol]"
    scene 05_0322 with dissolve
    mct "...Fuck....Can't hold....it..."
    call CharCum ("e05/05_0324.webp", "e05/05_0325.webp", mc, "....")
    call CharCum ("e05/05_0325.webp", "e05/05_0326.webp", mc, "...")
    scene 05_0327 with dissolve
    car "[whi][giggles]"
    scene 05_0328 with dissolve
    if persistent.CaraRP03Dat[2]:
        mc "Absolutely! I'm gonna jump in the shower now!"
    else:
        mc "Thanks!"
    play sound "doorclose.mp3"
    scene 05_0329 with dissolve
    ali "Uh, okay."
    scene 05_0330 with dissolve
    mc "[whi]Fuck!"
    scene 05_0331 with dissolve
    mc "[whi]Are you {i}trying{/i} to get us caught?!"
    scene 05_0332 with dissolve
    if persistent.CaraRP03Dat[2] and persistent.CaraRP03Dat[3]:
        car "[whi]You fucked my mom in the ass?"
    else:
        car "[whi]I wanted to show {i}Little Daddy{/i} how much I love him!"
    scene 05_0333 with dissolve
    mc "[whi]You'd better get outta here, in case she comes back."
    car "[whi]Yeah!"
    scene 05_0334 with dissolve
    mc "[whi]You, uh, should wipe your face first. Heh."
    car "[whi]I'll clean up in my room."
    car "[whi]I wanna take a selfie with my dad's cum all over my mouth!"
    scene 05_0335 with dissolve
    mc "[whi]Jesus! You're crazy! You're gonna be the death of me!"
    scene 05_0336 with dissolve
    mc "[whi]Okay, it's clear."
    scene 05_0337 with Fade(0.5, 1, 0.5)
    if persistent.CaraRP03Dat[4]:
        mct "Holy shit, that was too close!\nWe need to be more careful in the future."
    else:
        mct "Why the fuck didn't I stop her??"
    scene black with Fade(2, 2, 3)
return

label CaraReplay04:
    call Unlocker ("CaraReplay04")
    $ Cara.incSex()
    if not _in_replay:
        call Bruises (True)
        $ persistent.CaraRP04Dat[0]=Plr.Has("Bruises")
    $ aaa = ""
    if persistent.CaraRP04Dat[0]:
        $ aaa="a"
    if _in_replay:
        scene black with fade
        unk "[whi]Dad?"
        call Emotion (mc, "Groan", "", True)
        unk "Dad?"
        scene 09_0171 with dissolve
        mc "[whi]Mhh??"
        scene 09_0172 with dissolve
        mc "[whi]Cara?"
        scene 09_0173 with dissolve
        car "[whi]Sorry for waking you."
        mc "[whi]It's okay. What's up?"
        scene 09_0174 with dissolve
        car "Can I, umm... sleep in your bed?"
        mc "Huh?"
        car "Nic's been kicking hell out of me all night; I can't sleep!"
        scene 09_0175 with dissolve
        mc "Uhh... I don't know, Cara... Can't you sleep in your mom's bed?"
        car "No.\nThey came back {i}really{/i} drunk."
        scene 09_0176 with dissolve
        car "Christina could barely walk. They've both passed out in Mom's bed."
        car "Don't worry, I'll go back to my room way before anyone wakes up in the morning!"
    show expression "09_0178" + aaa with dissolve
    mc "Okay, come on."
    if persistent.CaraRP04Dat[0]:
        scene 09_0179 with dissolve
        car su "Are they bruises??"
        mc "Ohh... Yeah, it's nothing. Looks worse than it is."
        scene 09_0180 with dissolve
        mc "Come on, get into bed."
    show expression "09_0181" + aaa with dissolve
    car x "Are you, uhh... naked under there?"
    mc "Shit... yeah.\nHold on, I'll put on some pants."
    scene 09_0182 with dissolve
    car "Or maybe I could just get naked, too?"
    mc h "Damn... That option {i}does{/i} sound better."
    scene 09_0183 with dis1
    scene 09_0184 with dis1
    scene 09_0185 with dis1
    scene 09_0186 with dissolve
    mc "You should keep your panties on, though."
    if not _in_replay and not EzModeActive:
        $ persistent.CaraRP04Dat[1]=True
        if persistent.UseFocus:
            $ _skipping = False
            show screen imgMap("images/e09/09_0187.webp", 897, 503, True, "Springhaven_AF30") with dissolve
            car "{i}What{/i} panties?"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 09_0187
                hide screen imgMap
                $ persistent.CaraRP04Dat[1]=False
        else:
            scene 09_0187 with dissolve
            car "{i}What{/i} panties?"
            call Springhaven_AF30
    else:
        scene 09_0187 with dissolve
        car "{i}What{/i} panties?"
        if persistent.CaraRP04Dat[1]:
            call Springhaven_AF30
    scene 09_0189 with dissolve
    car h "{i}Happy now{/i}, Daddy?"
    mc h "[whi]Happy, happy, happy."
    scene 09_0190 with dissolve
    pause
    scene 09_0191 with dissolve
    car "[ss]Mmhh."
    scene 09_0192 with dissolve
    car "[whi]Oops. Sorry."
    mc "[whi]For what?"
    car h "[whi]Think I just woke Little Daddy, too."
    mc h "[whi]Pipsqueak, you woke him the minute you asked to get in my bed."
    scene 09_0193 with dissolve
    car "[whi]Would you like your naked daughter to suck your dick again?"
    scene 09_0194 with dissolve
    mc "[whi]Little Daddy's screaming at me to say yes..."
    scene 09_0195 with dissolve
    mc "[whi]... But I'd like to introduce myself to {i}Mini Pipsqueak{/i}."
    car h "[whi]Yeah? Okay."
    scene 09_0196 with dissolve
    car x "[ss]..Mmmhhh.."
    scene 09_0197 with dis1
    scene 09_0198 with dis1
    car "[ss]Mmmhhhhh.."
    scene 09_0199 with dissolve
    pause 0.5
    scene 09_0200 with dis1
    car "[ss]..Mmmhhh.."
    scene 09_0201 with dissolve
    car "[ss]Mmmhhhhh.."
    scene 09_0202 with dissolve
    pause
    scene 09_0203 with dissolve
    image CaraR04_01 = Movie(play="images/e09/09_0204.webm")
    show CaraR04_01 with dissolve
    car "[ss]..Mmmmhh.."
    scene 09_0205 with dissolve
    car "[ss]Mmhh."
    scene 09_0206 with dis1
    pause 0.5
    scene 09_0207 with dis1
    pause 0.5
    scene 09_0208 with dissolve
    car "[ss]..Mmmmhh.."
    scene 09_0209 with dissolve
    pause
    scene 09_0210 with dis1
    pause 0.5
    call Loop_Dissolve (4, False, False, "e09/09_0212.webp", "e09/09_0211.webp")
    scene 09_0213 with dis1
    scene 09_0214 with dis1
    scene 09_0215 with dis1
    scene 09_0216 with dis1
    pause 0.5
    scene 09_0217 with dissolve
    car "[ss]..Ohhhh.."
    scene 09_0218 with dissolve
    car "[ss]....Mmmmhhhhhhh....."
    scene 09_0219 with dissolve
    image CaraR04_02 = Movie(play="images/e09/09_0220.webm")
    show CaraR04_02 with dissolve
    car "[ss]..Ohhhhhh.."
    scene 09_0221 with dissolve
    call Moan (car)
    scene 09_0222 with dis1
    pause 0.5
    scene 09_0223 with dis1
    pause 0.5
    scene 09_0224 with fade1
    pause
    scene 09_0225 with dissolve
    mct "Fuck... About to eat my daughter's pussy..."
    mct "... And I've never felt so damn excited..."
    car "[whi]Dad?"
    scene 09_0226 with dissolve
    car "[whi]Is... everything okay?"
    mc "[whi]Yeah, Sweetheart.\nJust want to take my time and enjoy every moment with you."
    scene 09_0227 with dissolve
    car "[whi]Me too."
    scene 09_0228 with dissolve
    pause
    scene 09_0229 with dis1
    call Emotion (car, "Gasp")
    scene 09_0230 with dissolve
    pause
    scene 09_0231 with dissolve
    car "[ss]....Mmmmhhhh....."
    scene 09_0232 with dissolve
    car "[ss]...Oh my God!..."
    scene 09_0233 with dissolve
    pause
    call Loop_Dissolve (5, False, False, "e09/09_0234.webp", "e09/09_0235.webp")
    scene 09_0236 with dissolve
    scene 09_0237 with dissolve
    scene 09_0238 with dissolve
    scene 09_0239 with dissolve
    pause 0.5
    scene 09_0240 with dissolve
    call Moan (car, 6)
    scene 09_0241 with dis1
    car "[ss]...OHH......DAD......OHHHHH...."
    scene 09_0242 with dissolve
    image CaraR04_03 = Movie(play="images/e09/09_0243.webm")
    show CaraR04_03 with dissolve
    pause
    scene 09_0244 with dissolve
    car "[ss]...Mmmmhhhhh...."
    scene 09_0245 with dissolve
    image CaraR04_04 = Movie(play="images/e09/09_0246.webm", loop=False, keep_last_frame=True)
    show CaraR04_04 with dissolve
    pause
    scene 09_0247 with dissolve
    call Moan (car, 8)
    scene 09_0248 with dissolve
    image CaraR04_05 = Movie(play="images/e09/09_0249.webm")
    show CaraR04_05 with dissolve
    car "[ss]...OHHHH...."
    scene 09_0250 with dissolve
    call Moan (car, 8)
    scene 09_0251 with dissolve
    pause 0.5
    scene 09_0252 with dis1
    scene 09_0253 with dis1
    scene 09_0254 with dis1
    scene 09_0255 with dissolve
    car "[ss]...OH GOD, DADDY....."
    call CharCum ("e09/09_0255.webp", "e09/09_0256.webp", car, "..OHHHHHHHHH..", 1)
    call CharCum ("e09/09_0256.webp", "e09/09_0257.webp", car, "..Mmmmmmmmhhhh..", 2)
    scene 09_0258 with dissolve
    car "[whi]Holy shit, Dad! That was great!"
    scene 09_0259 with dissolve
    mct "....Fuuck...."
    scene 09_0260 with dissolve
    mct "... So damn tempting..."
    scene 09_0261 with dissolve
    image CaraR04_06 = Movie(play="images/e09/09_0263.webm", loop=False, keep_last_frame=True)
    car "[whi]Daddy..."
    car "[whi]... We can't."
    mc "[whi]Yeah... I know."
    scene 09_0262 with dissolve
    car "[whi]... We shouldn't."
    car "[whi]... should we?"
    mc "[whi]No..."
    show CaraR04_06 with dissolve
    mc "[whi]... we shouldn't.{w=2}{nw}"
    pause 1.0
    car "[ss]OHHHHH."
    scene 09_0264 with dissolve
    image CaraR04_07 = Movie(play="images/e09/09_0265.webm")
    show CaraR04_07 with dissolve
    car "[ss]...Mmmmhhhhh...."
    scene 09_0266 with dissolve
    car "[ss].....Yes......Ohhh, Daddy, yes......"
    scene 09_0267 with dissolve
    image CaraR04_08 = Movie(play="images/e09/09_0268.webm")
    show CaraR04_08 with dissolve
    car "[ss]...Mmmhh...."
    car "[ss]..Mmmhhh......You're fucking me, Dad....Ohhhhh...."
    car "[ss]....You're fucking your daughter.......Mhhh...."
    scene 09_0269 with dissolve
    image CaraR04_09 = Movie(play="images/e09/09_0270.webm")
    show CaraR04_09 with dissolve
    call Moan (car)
    scene 09_0271 with dissolve
    pause
    scene 09_0272 with dissolve
    image CaraR04_10 = Movie(play="images/e09/09_0273.webm")
    show CaraR04_10 with dissolve
    car "[ss].....Ohhh, Dad.....It feels soooo good......"
    scene 09_0274 with dissolve
    call Moan (car, 6)
    scene 09_0275 with dissolve
    image CaraR04_11 = Movie(play="images/e09/09_0276.webm")
    show CaraR04_11 with dissolve
    car "[ss]...OHHH..."
    scene 09_0277 with dissolve
    image CaraR04_12 = Movie(play="images/e09/09_0278.webm")
    show CaraR04_12 with dissolve
    car "[ss]...Mmmmhhh..."
    car "[ss].......Your dick feels amazing, Dad.......Ohhhh....."
    scene 09_0279 with dissolve
    image CaraR04_13 = Movie(play="images/e09/09_0280.webm")
    show CaraR04_13 with dissolve
    call Moan (car, 6)
    scene 09_0281 with dissolve
    car "[ss]Ohhh, Daddy.....Yesss....Fuck me......."
    scene 09_0282 with dissolve
    image CaraR04_14 = Movie(play="images/e09/09_0283.webm")
    show CaraR04_14 with dissolve
    car "[ss]...OHHHHHHH..."
    scene 09_0284 with dissolve
    car "[ss]...Mmmhh..."
    scene 09_0285 with dissolve
    car "[ss]...Mmmmhhh..."
    scene 09_0286 with dissolve
    image CaraR04_15 = Movie(play="images/e09/09_0287.webm")
    show CaraR04_15 with dissolve
    call Moan (car, 6)
    scene 09_0288 with dissolve
    image CaraR04_16 = Movie(play="images/e09/09_0289.webm")
    show CaraR04_16 with dissolve
    car "[ss]...OHHH, DAD....."
    car "[ss]...YES....."
    car "[ss]...FUCK...YESSS....."
    car "[ss]...OHHH, DADDYYYY....."
    call CharCum ("e09/09_0288.webp", "e09/09_0290.webp", car, "..OHHHHHHHHH..", 1)
    scene 09_0291 with dissolve
    car "[ss]God, I love this, Dad."
    scene 09_0292 with dissolve
    car "[ss]..Mmhhh.."
    scene 09_0293 with dissolve
    image CaraR04_17 = Movie(play="images/e09/09_0294.webm")
    show CaraR04_17 with dissolve
    car "[ss]..Mmmmhhh.."
    pause
    $ aaa=""
    call CmOpts (["Cum inside Cara", "Pull out"])
    $ Copt=_return
    if Copt==0:
        call CharCum ("e09/09_0295.webp", "e09/09_0296.webp", mc, "NNNGGGHHHH")
        call CharCum ("e09/09_0296.webp", "e09/09_0297.webp", mc, "..Nnnhhhh..")
        $ Cara.incCm()
    else:
        call CharCum ("e09/09_0295.webp", "e09/09_0296a.webp", mc, "NNNGGGHHHH")
        call CharCum ("e09/09_0296a.webp", "e09/09_0297a.webp", mc, "..Nnnhhhh..")
        $ aaa="a"
    show expression "09_0298" + aaa with dissolve
    mc "[whi]...Fuuuck..."
    show expression "09_0299" + aaa with dissolve
    car "[whi]That was fuckin' amazing, Dad."
    mc "[whi]Yeah, it was."
    show expression "09_0300" + aaa with dissolve
    car "[whi]Please don't spoil it by telling me we can't do that again."
    mc "[whi]Ohh, Pipsqueak, no..."
    show expression "09_0301" + aaa with dissolve
    mc "[whi]We're definitely doing that again!"
    show expression "09_0302" + aaa with dissolve
    mc "[whi]..and again, and again!"
    if _in_replay:
        scene black with ReplayFade
    else:
        scene 09_0303 with fade1
        mc "[whi]..Zzzz.."
return

label CaraReplay05:
    call Unlocker ("CaraReplay05")
    $ Cara.incSex()
    scene 13_0017 with dissolve
    mct "Don't think I'm gonna be able to sleep knowing she's next to me..."
    scene 13_0018 with dissolve
    mct "Maybe just a quick cuddle..."
    scene 13_0019 with dis1
    $ apause(-1)
    mc "[whi][kiss]"
    scene 13_0020 with dis1
    $ apause()
    scene 13_0021 with dis1
    mc "[whi][kiss]"
    scene 13_0022 with dissolve
    car "[whi]Mmhhhhh.{w=0.5}{nw}"
    scene 13_0023 with dis1
    $ apause(-1)
    mc "[whi][kiss]"
    scene 13_0024 with dis1
    $ apause()
    scene 13_0025 with dis1
    mc "[whi][kiss]"
    scene 13_0026 with dis1
    $ apause()
    scene 13_0027 with dis1
    $ apause(0)
    scene 13_0028 with dissolve
    car "[whi]Mhhh... Didn't know you were coming home tonight, Dad."
    mc "[whi]Yeah.\nSorry, Pipsqueak, I was trying not to wake you."
    car "[whi]I'm happy you did.\nKiss my back again, it feels nice."
    scene 13_0029 with dis1
    $ apause(-1)
    mc "[whi][kiss]"
    scene 13_0030 with dis1
    $ apause()
    scene 13_0031 with dis1
    $ apause()
    scene 13_0032 with dis1
    mc "[whi][kiss]"
    scene 13_0033 with dis1
    $ apause(0)
    mc "[whi]Damn, your ass is just perfect!"
    scene 13_0034 with dis1
    mc "[whi][kiss]"
    scene 13_0035 with dis1
    car "[ss]Mmmh."
    scene 13_0036 with dis1
    mc "[whi][kiss]"
    scene 13_0037 with dissolve
    image CaraR05_01 = Movie(play="images/e13/13_0038.webm")
    show CaraR05_01
    call Moan (car, 4)
    scene 13_0039 with dissolve
    car "[ss]..Mmmhh...."
    scene 13_0040 with dissolve
    scene 13_0041 with dis1
    scene 13_0042 with dis1
    car "[ss]..Mmmhh, Daddy... what are you doing?"
    scene 13_0043 with dissolve
    mc "[whi][kiss]"
    scene 13_0044 with dissolve
    mc "[whi]Fucking my gorgeous, sexy daughter."
    scene 13_0045 with dissolve
    image CaraR05_02 = Movie(play="images/e13/13_0046.webm", loop=False, keep_last_frame=True)
    show CaraR05_02
    pause 1.0
    car "[ss]..Mmmmhh..{w=3}{nw}"
    car "[ss]....That feels nice.....{w=3}{nw}"
    pause 3.0
    car "[ss]..Mmmhhhhh..{w=1.5}{nw}"
    car "[ss]..Ohhh.."
    scene 13_0047 with dissolve
    car "[ss]Ohhhh.... That feels even nicer."
    scene 13_0048 with dissolve
    image CaraR05_03 = Movie(play="images/e13/13_0049.webm")
    show CaraR05_03
    car "[ss]..Ohhhhh.."
    scene 13_0050 with dissolve
    image CaraR05_04 = Movie(play="images/e13/13_0051.webm")
    show CaraR05_04
    call Moan (car, 4)
    scene 13_0052 with dissolve
    call AutoA
    mc "[whi][kiss]"
    scene 13_0053 with dis1
    mc "[whi][kiss]"
    scene 13_0054 with dis1
    $ apause()
    scene 13_0055 with dis1
    $ apause()
    scene 13_0056 with dis1
    $ apause()
    call AutoA (False)
    scene 13_0057 with dissolve
    car "[ss]....Ohhh, Dad.....Yes...."
    scene 13_0058 with dissolve
    image CaraR05_05 = Movie(play="images/e13/13_0059.webm")
    show CaraR05_05
    call Moan (car, 6)
    scene 13_0061 with dissolve
    car "[ss].....Ohhhh, Dad......"
    scene 13_0060 with dissolve
    car "[ss]...OHHHH...."
    scene 13_0062 with dissolve
    image CaraR05_06 = Movie(play="images/e13/13_0063.webm")
    show CaraR05_06
    call Moan (car, 6)
    scene 13_0064 with dissolve
    car "[ss]..Ohhhh, Daddy, YES.......Fuck your daughter.......OHHHH....."
    scene 13_0065 with dissolve
    image CaraR05_07 = Movie(play="images/e13/13_0066.webm")
    show CaraR05_07
    mc "[whi]You make me so damn horny, Pipsqueak."
    car "[ss]....Fuck me, Daddy...."
    scene 13_0067 with dissolve
    car "[ss]...OHHHH...."
    scene 13_0068 with dissolve
    image CaraR05_08 = Movie(play="images/e13/13_0069.webm")
    show CaraR05_08
    call Moan (car, 6)
    scene 13_0070 with dissolve
    car "[ss]....Ohhh, yes Daddy.......Yes...."
    scene 13_0071 with dissolve
    image CaraR05_09 = Movie(play="images/e13/13_0072.webm")
    show CaraR05_09
    call Moan (car, 6)
    scene 13_0073 with dissolve
    car "[ss]...OHHH..."
    scene 13_0074 with dissolve
    image CaraR05_10 = Movie(play="images/e13/13_0075.webm")
    show CaraR05_10
    car "[ss]..God, Dad....Yes......"
    scene 13_0076 with dissolve
    image CaraR05_11 = Movie(play="images/e13/13_0077.webm")
    show CaraR05_11
    call Moan (car, 8)
    scene 13_0078 with dissolve
    car "[ss].....OHHHHH, DAD....."
    scene 13_0079 with dissolve
    image CaraR05_12 = Movie(play="images/e13/13_0080.webm")
    show CaraR05_12
    call Moan (car, 8)
    scene 13_0081 with dissolve
    car "[ss]...OHHH..."
    scene 13_0082 with dissolve
    image CaraR05_13 = Movie(play="images/e13/13_0083.webm")
    show CaraR05_13
    call Moan (car, 8)
    scene 13_0084 with dissolve
    image CaraR05_14 = Movie(play="images/e13/13_0085.webm")
    show CaraR05_14
    call Moan (car, 8)
    call CharCum ("e13/13_0084.webp", "e13/13_0086.webp", car, "..Ohhhhhh..")
    call CharCum ("e13/13_0086.webp", "e13/13_0087.webp", car, "....Mmmmmmhhhh....")
    scene 13_0088 with dissolve
    image CaraR05_15 = Movie(play="images/e13/13_0089.webm")
    show CaraR05_15
    car "[ss]..Mmmhhhh.."
    pause 2.0
    call CmOpts (["Cum inside Cara", "Pull out"])
    $ Copt=_return
    if Copt==0:
        call CharCum ("e13/13_0088.webp", "e13/13_0090.webp", mc, "..Nnnggghhh..")
        call CharCum ("e13/13_0090.webp", "e13/13_0091.webp", mc, "..Nnnhh..")
        $ Cara.incCm()
        scene 13_0092 with dissolve
        pause
        scene 13_0093 with dissolve
        pause
        scene 13_0094 with dissolve
    else:
        call CharCum ("e13/13_0088.webp", "e13/13_0095.webp", mc, "..Nnnggghhh..")
        call CharCum ("e13/13_0095.webp", "e13/13_0096.webp", mc, "..Nnnhh..")
        scene 13_0097 with dissolve
        pause
        scene 13_0098 with dissolve
    car "[whi]Welcome home, Daddy!"
    scene black with ReplayFade
return

label CaraReplay06:
    call Unlocker ("CaraReplay06")
    if _in_replay:
        scene 17_0090 with Fade(0,0,2)
        car "[whi]Kiss me."
        mc "[whi]Cara... Your mom... She's right there.\nIf she were to open her eyes..."
        scene 17_0091 with dissolve
        car "[whi]I know it excites you - the risk of her catching us. It excites me too."
        car "[whi]That's why you touched me in the kitchen the other day..."
        car "[whi]You put your hand between my legs while she was sat there with us."
        scene 17_0092 with dissolve
        car "[whi]My heart was pounding - not because I was scared - I wasn't."
        car "[whi]When the tip of your finger brushed against my pussy, I had to stop myself from letting out a moan."
        car "[whi]I'd never felt a rush like that before, and I liked it."
        scene 17_0093 with dissolve
        car "[ss]Mmh."
        scene 17_0094 with dissolve
        ali "[whi]....Zzzz...."
        scene 17_0095 with dis1
        pause 0.5
        scene 17_0096 with dis1
        pause 0.5
        scene 17_0097 with dissolve
        mc "[whi]Cara..."
        scene 17_0098 with dissolve
        car "[whi]Just a blowjob, Daddy."
        mc "[whi]Okay, so let's go upstairs."
        car "[whi]No!"
        scene 17_0099 with dissolve
        car "[whi]I want to suck your dick in front of her."
        mc "[whi]You {i}know{/i} what'll happen if she wakes up..."
        car "[whi]Yeah. She'll kill us both."
    scene 17_0107 with dissolve
    car "[whi]But that's what makes it exciting, right?"
    scene 17_0108 with dissolve
    mc "[whi]Yeah."
    scene 17_0109 with dissolve
    car "[ss]Mmh."
    scene 17_0110 with dissolve
    car "[ss]..Mmmmh.."
    scene 17_0111 with dissolve
    image CaraR06_01 = Movie(play="images/e17/17_0112.webm")
    show CaraR06_01
    pause
    scene 17_0113 with dissolve
    car "[whi]Tell me what you'd like me to do."
    mc "[whi]I want you to suck my dick in front of your mom."
    mc "[whi]And when you have a mouthful of my cum, I want you to look at her while you swallow it."
    scene 17_0114 with dissolve
    car "[whi]Yes, Daddy."
    scene 17_0115 with dissolve
    ali "[whi]Zzz."
    image CaraR06_02 = Movie(play="images/e17/17_0117.webm", loop=False, keep_last_frame=True)
    image CaraR06_03 = Movie(play="images/e17/17_0118.webm")
    scene 17_0116 with dissolve
    pause
    show CaraR06_02
    pause 3.4
    show CaraR06_03
    car "[ss]..Mmmhh.."
    scene 17_0119 with dissolve
    image CaraR06_04 = Movie(play="images/e17/17_0120.webm")
    show CaraR06_04
    pause
    scene 17_0121 with dissolve
    pause 0.5
    scene 17_0122 with dis1
    mc "[whi]...Fuck, that's good, Babygirl..."
    scene 17_0123 with dis1
    mc "[whi]Daddy wants to make you feel good, too..."
    scene 17_0124 with dis1
    scene 17_0125 with dis1
    scene 17_0126 with dis1
    call Moan (car, 4)
    call Loop_Dissolve (4, False, False, "e17/17_0127.webp", "e17/17_0128.webp")
    scene 17_0129 with dissolve
    car "[ss]...Mmhhhh..."
    scene 17_0130 with dis1
    image CaraR06_05 = Movie(play="images/e17/17_0131.webm")
    show CaraR06_05
    pause
    scene 17_0132 with dissolve
    image CaraR06_06 = Movie(play="images/e17/17_0133.webm")
    show CaraR06_06
    pause
    scene 17_0134 with dissolve
    image CaraR06_07 = Movie(play="images/e17/17_0135.webm")
    show CaraR06_07
    call Moan (car, 4)
    scene 17_0136 with dissolve
    pause 0.5
    scene 17_0137 with dis1
    call Emotion (ali, "Mumbles", "", True)
    scene 17_0138 with dissolve
    scene 17_0139 with dis1
    call Emotion (car, "Gasp", "", True)
    scene 17_0137 with dissolve
    pause 0.5
    scene 17_0140 with dis1
    ali "[whi]..Zzz.."
    scene 17_0141 with dissolve
    pause 0.5
    scene 17_0142 with dis1
    image CaraR06_08 = Movie(play="images/e17/17_0143.webm")
    show CaraR06_08
    car "[ss]...Mmhhhh..."
    scene 17_0144 with dissolve
    mc "[whi]...Damn, Pipsqueak....Daughter blowjobs are the best......"
    scene 17_0145 with dissolve
    image CaraR06_09 = Movie(play="images/e17/17_0146.webm")
    show CaraR06_09
    call Moan (car, 4)
    if persistent.Anal:
        $ Cara.Add("Anal")
        scene 17_0147 with dis1
        scene 17_0148 with dis1
        scene 17_0149 with dissolve
        image CaraR06_10 = Movie(play="images/e17/17_0150.webm")
        show CaraR06_10
        pause
        scene 17_0151 with dissolve
        car "[ss]...MMMHHH...."
        scene 17_0152 with dissolve
        image CaraR06_11 = Movie(play="images/e17/17_0153.webm")
        image CaraR06_12 = Movie(play="images/e17/17_0154.webm", loop=False, keep_last_frame=True)
        image CaraR06_13 = Movie(play="images/e17/17_0155.webm")
        show CaraR06_11
        pause
        show CaraR06_12 with dissolve
        pause 1.1
        show CaraR06_13
        pause
        scene 17_0156 with dissolve
        car "[ss]..Mmhh.."
        car "[ss]Fuck, Dad... I like that."
    else:
        scene 17_0156 with dissolve
        car "[ss]..Mmhh.."
    scene 17_0157 with dissolve
    image CaraR06_14 = Movie(play="images/e17/17_0158.webm")
    show CaraR06_14
    car "[ss]..Mmhh.."
    if persistent.Anal:
        scene 17_0159 with dissolve
        image CaraR06_15 = Movie(play="images/e17/17_0160.webm")
        show CaraR06_15
    else:
        scene 17_0161 with dissolve
        image CaraR06_16 = Movie(play="images/e17/17_0162.webm")
        show CaraR06_16
    car "[ss]..Mmhh.."
    scene 17_0163 with dissolve
    image CaraR06_17 = Movie(play="images/e17/17_0164.webm")
    show CaraR06_17
    pause
    call CharCum ("e17/17_0163.webp", "e17/17_0165.webp", mc, "..Nnnggghhh..")
    call CharCum ("e17/17_0165.webp", "e17/17_0166.webp", mc, "..Nnnhh..")
    scene 17_0167 with dissolve
    pause 0.5
    scene 17_0168 with dis1
    scene 17_0169 with dis1
    pause
    scene 17_0170 with dissolve
    mc "[whi]Cara? What you doin'?"
    scene 17_0171 with dissolve
    mc "[whi]Just swallow it!"
    scene 17_0172 with dis1
    pause 0.5
    scene 17_0173 with dissolve
    pause 0.5
    scene 17_0174 with dis1
    scene 17_0175 with dis1
    call Gulp (car)
    scene 17_0176 with dis1
    scene 17_0177 with dis1
    car "[whi][kiss]"
    scene 17_0176 with dis1
    call Emotion (ali, "Mumbles", "", True)
    scene 17_0178 with dis1
    pause 
    scene 17_0179 with dissolve
    mc "[whi]You just {i}had{/i} to take it one step further, didn't ya?"
    scene 17_0180 with dissolve
    car "I need to get changed.\nI told Alex I'd go hang out with her."
    scene 17_0181 with dissolve
    car "[whi]God, I love the taste of your cum, Daddy."
    scene 17_0182 with dissolve
    car "[ss]Mmmhh."
    scene 17_0183 with dis1
    scene 17_0184 with dis1
    scene 17_0185 with dis1
    mct "That girl's gonna be the death of me, heh."
    if _in_replay:
        scene black with ReplayFade
        return
    scene 17_0186 with dissolve
    mc "{size=*0.8}{font=Vanilla.ttf}*{i}Sniff{/i}*{/font}{/size}{w=0.5}{nw}"
    scene 17_0187 with dissolve
    mct "Man, I need to shower!"
    scene 17_0188 with dis1
    scene 17_0189 with dis1
    ali "[whi]...Zzz..."
return

label CaraReplay07:
    call Unlocker ("CaraReplay07")
    $ Hannah.incSex()
    $ Cara.incSex()
    $ Millie.incSex()
    if _in_replay:
        scene 21_0529 with Fade(0,1,2)
        mc "Damn, such a nice day!"
        scene 21_0530 with dissolve
        scene 21_0531 with dis1
        mc "Who's up for a spot of sunbathing?!"
    scene 21_0532 with dissolve
    han "I'll join you, Unc."
    scene 21_0533 with dis1
    pause 0.5
    scene 21_0534 with dis1
    pause 0.5
    scene 21_0535 with dis1
    mil "Me too!"
    scene 21_0536 with dissolve
    car "Count me in!"
    scene 21_0537 with dissolve
    mil "But Daddy..."
    scene 21_0538 with dissolve
    mil "... We don't want to {i}sunbathe{/i}."
    scene 21_0539 with dis1
    car "We want to fuck."
    scene 21_0540 with dis1
    han "All of us."
    scene 21_0541 with dis1
    pause 0.5
    scene 21_0542 with dissolve
    han "[whi]Mmhh."
    scene 21_0543 with dissolve
    pause
    scene 21_0544 with dissolve
    image CaraR07_01 = Movie(play="images/e21/21_0545.webm")
    show CaraR07_01
    mil "[ss]..Mmmhh.."
    scene 21_0546 with dissolve
    pause
    scene 21_0547 with dissolve
    mil "[ss]Mmhh."
    scene 21_0548 with dis1
    pause 0.5
    scene 21_0549 with dis1
    pause 0.5
    scene 21_0550 with dissolve
    image CaraR07_02 = Movie(play="images/e21/21_0551.webm")
    show CaraR07_02
    car "[ss]Mmmhh."
    scene 21_0552 with dissolve
    mc "[whi]Damn."
    han "Helluva view!"
    scene 21_0553 with dissolve
    image CaraR07_03 = Movie(play="images/e21/21_0554.webm")
    show CaraR07_03
    car "[ss]..Mmhhhh.."
    scene 21_0555 with dissolve
    pause
    mc "Okay... Who's pussy am I eatin' first?"
    scene 21_0556 with dissolve
    car "Mine please, Daddy!"
    mil "Wanna help me suck his dick, Han?"
    han "Hell yeah."
    if not _in_replay and persistent.Lez and persistent.MilandCar and miAndHan==None:
        scene 21_0557 with fade1
        pause
        call Encourage ("Millie", "Hannah", "Cara")
        $ miAndHan=_return
        $ persistent.milAndHan=miAndHan
        $ persistent.CarAndHan=miAndHan
    $ Lez=False
    if persistent.Lez and persistent.milAndHan:
        $ Lez=True
        $ Cara.Add("A03")
    if Lez:
        scene 21_0558 with dissolve
        mc "Milz."
        mil "Yeah?"
        mc "..."
        scene 21_0559 with dissolve
        mil "Han, your pervy uncle wants to watch us kiss."
        scene 21_0560 with dissolve
        han "[lol] Of course he does."
        scene 21_0561 with dissolve
        han "Well, we wouldn't want to disappoint him, would we?"
        mil "Nope."
        scene 21_0562 with dissolve
        han "[whi]Should we use our tongues?"
        mil "[whi]Yeah."
        scene 21_0563 with dis1
        han "[whi]Mmhh."
        scene 21_0564 with dissolve
        mil "[whi]..Mhhh.."
        scene 21_0565 with dissolve
        car "{i}Your{/i} work, I presume?"
        mc "Yep.\nBeautiful, right?"
        scene 21_0566 with dissolve
        car "Very!"
        scene 21_0567 with dis1
        scene 21_0568 with dis1
        pause
        scene 21_0569 with dissolve
    else:
        scene 21_0569 with fade1
    pause
    scene 21_0570 with dissolve
    image CaraR07_04 = Movie(play="images/e21/21_0571.webm")
    show CaraR07_04
    pause
    scene 21_0572 with dissolve
    car "[whi]God, that's so good, Dad."
    scene 21_0573 with dissolve
    call Moan (car)
    scene 21_0574 with dissolve
    image CaraR07_05 = Movie(play="images/e21/21_0575.webm")
    show CaraR07_05
    han "[whi]Mmhh."
    scene 21_0576 with dissolve
    mil "[whi]..Mmmhh.."
    scene 21_0577 with dissolve
    pause
    scene 21_0578 with dissolve
    han "[whi]..Mmmhh.."
    scene 21_0579 with dissolve
    car "[ss]..Ohhhh.."
    scene 21_0580 with dissolve
    pause
    scene 21_0581 with dissolve
    car "Who's going next?"
    scene 21_0582 with dissolve
    mil "Han.\nShe {b}loves{/b} Dad's tongue in her pussy!"
    scene 21_0583 with dissolve
    han "I love his dick in it, too!"
    mil "Don't we all? [lol]"
    scene 21_0584 with fade1
    pause
    if Lez:
        scene 21_0585 with dissolve
        mil "You know he'll want us to kiss again, right?"
        car "I'd be surprised if he didn't."
        scene 21_0586 with dis1
        car "[whi]Mmmh."
        scene 21_0587 with dissolve
        mil "[ss]..Mmmhhh.."
        scene 21_0588 with dissolve
        han "[whi]Hey, Unc."
        mc "[whi]Hey, Beautiful."
        han "[whi]So I, uhh, just squat over your head?"
        scene 21_0589 with dissolve
    else:
        scene 21_0589 with dissolve
        han "[whi]Hey, Unc."
        han "[whi]So I, uhh, just squat over your head?"
    mc "[whi]Yeah. I'll do the rest."
    han "[whi]'Kay."
    scene 21_0590 with dis1
    pause 0.5
    scene 21_0591 with dissolve
    han "[whi]Mmmh."
    if Lez:
        scene 21_0592 with dis1
        han "[whi]Is that Cara I can taste on your lips?"
        mc "[whi]Yeah."
        han "[whi]It's the first time I've tasted someone else's pussy."
        mc "[whi]It probably won't be the last, Han."
        scene 21_0593 with dissolve
        han "[whi][lol]"
    scene 21_0594 with fadehold
    pause
    scene 21_0595 with dissolve
    han "[ss]Ohh."
    scene 21_0596 with dissolve
    image CaraR07_06 = Movie(play="images/e21/21_0597.webm")
    show CaraR07_06
    car "[ss]Mmhh."
    scene 21_0598 with dissolve
    pause
    scene 21_0599 with dissolve
    car "[ss]..Mmmhh.."
    scene 21_0600 with dissolve
    han "[ss]...God..."
    scene 21_0601 with dissolve
    image CaraR07_07 = Movie(play="images/e21/21_0602.webm")
    show CaraR07_07
    mil "[ss]Mmhh."
    scene 21_0603 with dissolve
    mil "[ss]..Mmmhh.."
    scene 21_0604 with dissolve
    call Moan (han)
    scene 21_0605 with dissolve
    pause
    scene 21_0606 with dissolve
    car "You want to sit on it, Milz?"
    scene 21_0607 with dissolve
    mil "You go first. I like sucking his balls."
    car "Yeah, I noticed! [lol]"
    if Lez:
        car "You can, uhh.. lick my clit again... you know, if you want to."
        mil "You liked it, huh?"
        scene 21_0608 with dis1
        car "[ss]Mmhh."
    scene 21_0609 with fade1
    image CaraR07_08 = Movie(play="images/e21/21_0610.webm")
    show CaraR07_08
    pause
    scene 21_0611 with dissolve
    car "[ss]Ohhhh."
    scene 21_0612 with dissolve
    pause
    scene 21_0613 with dissolve
    call Moan (han)
    scene 21_0615 with dissolve
    car "[ss]..Ohhh.."
    scene 21_0614 with dissolve
    pause
    scene 21_0616 with dissolve
    image CaraR07_09 = Movie(play="images/e21/21_0617.webm")
    show CaraR07_09
    call Moan (car)
    scene 21_0618 with dissolve
    mil "[ss]Mmhh."
    if Lez:
        scene 21_0619 with dis1
        scene 21_0620 with dis1
        scene 21_0621 with dis1
        scene 21_0622 with dis1
        mil "[ss]Nnnhh."
        scene 21_0623 with dissolve
        car "[ss]Ohhhh."
        scene 21_0624 with dissolve
        image CaraR07_10 = Movie(play="images/e21/21_0625.webm")
        show CaraR07_10
        call Moan (car)
        scene 21_0626 with dissolve
        mil "[ss]Mmhh."
        scene 21_0627 with dissolve
        car "[ss]...Fuck, Sis.......Yes..."
        scene 21_0629 with dissolve
        han "[ss]..Ohhh.."
        scene 21_0630 with dissolve
    else:
        scene 21_0628 with dissolve
        han "[ss]..Ohhh.."
        scene 21_0631 with dissolve
    han "You're up, Milz."
    scene 21_0632 with fade1
    image CaraR07_11 = Movie(play="images/e21/21_0633.webm")
    show CaraR07_11
    pause
    scene 21_0634 with dissolve
    image CaraR07_12 = Movie(play="images/e21/21_0635.webm")
    show CaraR07_12
    call Moan (car)
    scene 21_0636 with dissolve
    han "[whi]How many times have we sat right here and dreamed about doing this with your dad, Milz?"
    mil "[ss]God... Hundreds of times!.."
    scene 21_0637 with dissolve
    han "[whi]Did you {b}ever{/b} expect it to come true??"
    mil "[ss]..Hell no..."
    scene 21_0638 with dissolve
    mil "[ss]..I'm so glad it did, though!"
    han "[whi]Yeah, me too!"
    if Lez:
        scene 21_0639 with dissolve
        han "[ss]Mmhh."
        scene 21_0640 with dissolve
        mil "[ss]..Mmmhh.."
    scene 21_0641 with dissolve
    car "[ss]..Ohhh.."
    scene 21_0642 with dissolve
    pause
    if Lez:
        scene 21_0643 with dissolve
        han "[ss]..Mmhh.."
    scene 21_0644 with dissolve
    han "Cara... Is that position good?"
    scene 21_0645 with dissolve
    car "You haven't tried it?"
    han "Not yet."
    car "Come on, you're gonna love it."
    scene 21_0646 with fade1
    image CaraR07_13 = Movie(play="images/e21/21_0647.webm")
    show CaraR07_13
    han "[ss]..Fuuck.."
    scene 21_0648 with dissolve
    car "Good, right?"
    han "[ss]Hell yeah."
    scene 21_0649 with dissolve
    image CaraR07_14 = Movie(play="images/e21/21_0650.webm")
    show CaraR07_14
    call Moan (han)
    scene 21_0651 with dissolve
    mil "[ss]Ohhh."
    scene 21_0652 with dissolve
    image CaraR07_15 = Movie(play="images/e21/21_0653.webm")
    show CaraR07_15
    pause
    scene 21_0654 with dissolve
    han "[ss]..Ohhh.."
    scene 21_0655 with dissolve
    pause
    scene 21_0656 with dissolve
    image CaraR07_16 = Movie(play="images/e21/21_0657.webm")
    show CaraR07_16
    call Moan (han)
    scene 21_0658 with dissolve
    car "You wanna ride him, Sis?"
    mil "[whi]Your tongue need a rest, Dad?"
    scene 21_0659 with dissolve
    mil "[whi]Wanna fuck me from behind? I know you love that position!"
    scene 21_0660 with dissolve
    mc "Oh, Sweetie! I love {b}every{/b} position when I'm fuckin' you!"
    scene 21_0661 with fade1
    image CaraR07_17 = Movie(play="images/e21/21_0662.webm")
    show CaraR07_17
    pause
    scene 21_0663 with dissolve
    mil "[ss]...Ohhh.."
    scene 21_0664 with dissolve
    car "God, it's so hot watching you fuck her, Dad."
    scene 21_0665 with dissolve
    image CaraR07_18 = Movie(play="images/e21/21_0666.webm")
    show CaraR07_18
    call Moan (mil)
    scene 21_0667 with dissolve
    call Moan (mil)
    scene 21_0668 with dissolve
    image CaraR07_19 = Movie(play="images/e21/21_0669.webm")
    show CaraR07_19
    call Moan (mil)
    scene 21_0670 with dissolve
    car "[whi]Kiss me."
    scene 21_0671 with dis1
    car "[ss]Mmmhhh."
    scene 21_0672 with dissolve
    car "[ss]..Mhhh.."
    scene 21_0673 with dissolve
    pause
    scene 21_0674 with dissolve
    car "[ss]Mmmhhh."
    image CaraR07_21 = Movie(play="images/e21/21_0685.webm")
    image CaraR07_22 = Movie(play="images/e21/21_0691.webm")
    scene 21_0675 with dissolve
    if Lez:
        car "I'm gonna spread my legs in front of my sister so you can watch her lick my pussy."
        scene 21_0676 with dissolve
        car "[whi]Hey, Sis."
        scene 21_0678 with dissolve
        car "[whi]Daddy wants to watch you eat me again."
        mil "[ss]..Mhhh.....Okay...."
        scene 21_0677 with dissolve
        han "[ss]..Mmhh.."
        scene 21_0679 with fadehold
        pause
        scene 21_0680 with dissolve
        pause
        scene 21_0681 with dissolve
        call Moan (car)
        scene 21_0682 with dissolve
        image CaraR07_20 = Movie(play="images/e21/21_0683.webm")
        show CaraR07_20
        pause
        scene 21_0684 with dissolve
        show CaraR07_21
        han "[ss]..Mmmhhh.."
        scene 21_0686 with dissolve
        mc "[whi]Damn."
        scene 21_0687 with dissolve
        car "[ss]....God, Dad...She's so good at it..."
        scene 21_0688 with dissolve
        mil "[ss]Mmhh."
        scene 21_0689 with dissolve
        pause
        scene 21_0690 with dissolve
        show CaraR07_22
        pause
        scene 21_0692 with dissolve
        call Moan (han)
        scene 21_0693 with dissolve
        pause
        scene 21_0694 with dissolve
        image CaraR07_23 = Movie(play="images/e21/21_0695.webm")
        show CaraR07_23
        pause
        scene 21_0696 with dissolve
        call Moan (han)
        mc "[whi]Get on your knees for me, Han."
        scene 21_0697 with dissolve
    else:
        car "We love you, Daddy."
        scene 21_0676 with dissolve
        han "[ss]Mmmhhh."
        scene 21_0677 with dissolve
        han "[ss]..Mmhh.."
        scene 21_0684 with dissolve
        show CaraR07_21
        han "[ss]..Mmmhhh.."
        scene 21_0690 with dissolve
        show CaraR07_22
        pause
        scene 21_0692 with dissolve
        call Moan (han)
        scene 21_0693 with dissolve
        pause
        scene 21_0697 with dissolve
        mc "[whi]Get on your knees for me, Han."
    han "[whi]Wanna do me doggy style, too?"
    mc "[whi]Gonna do you all doggy stlye!"
    scene 21_0698 with fade1
    han "[ss]..Ohhhh.."
    scene 21_0699 with dissolve
    pause
    scene 21_0700 with dissolve
    image CaraR07_24 = Movie(play="images/e21/21_0701.webm")
    show CaraR07_24
    call Moan (han)
    scene 21_0702 with dissolve
    han "[ss]..Ohhhh.."
    scene 21_0703 with dissolve
    image CaraR07_25 = Movie(play="images/e21/21_0704.webm")
    show CaraR07_25
    call Moan (han)
    scene 21_0705 with dissolve
    han "[ss]..Ohhhh, Unc..."
    han "[ss]...God......Yes...."
    scene 21_0706 with dissolve
    image CaraR07_26 = Movie(play="images/e21/21_0707.webm")
    show CaraR07_26
    call Moan (han)
    scene 21_0708 with dissolve
    mil "[whi]She's close, Daddy! Keep going!"
    scene 21_0709 with dissolve
    image CaraR07_27 = Movie(play="images/e21/21_0710.webm")
    show CaraR07_27
    call Moan (han)
    scene 21_0711 with dissolve
    image CaraR07_28 = Movie(play="images/e21/21_0712.webm")
    show CaraR07_28
    call Moan (han)
    call CharCum ("e21/21_0711.webp", "e21/21_0713.webp", han, "..OHHHHHHH..")
    call CharCum ("e21/21_0713.webp", "e21/21_0714.webp", han, "....Ohhhhhhhh....")
    scene 21_0715 with dissolve
    image CaraR07_29 = Movie(play="images/e21/21_0716.webm")
    show CaraR07_29
    han "[ss]..Mmmhhh.."
    scene 21_0717 with dissolve
    mc "Who's next?"
    car "Me!"
    scene 21_0718 with fade1
    image CaraR07_30 = Movie(play="images/e21/21_0719.webm")
    show CaraR07_30
    pause
    scene 21_0720 with dissolve
    car "[ss]..Ohhh, Dad......Yes, just like that...."
    scene 21_0721 with dissolve
    image CaraR07_31 = Movie(play="images/e21/21_0722.webm")
    show CaraR07_31
    pause
    scene 21_0723 with dissolve
    car "[ss]..Ohhh..."
    scene 21_0724 with dissolve
    image CaraR07_32 = Movie(play="images/e21/21_0725.webm")
    show CaraR07_32
    pause
    scene 21_0726 with dissolve
    pause
    scene 21_0727 with dissolve
    call Moan (car)
    scene 21_0728 with dissolve
    image CaraR07_33 = Movie(play="images/e21/21_0729.webm")
    show CaraR07_33
    car "[ss]..Ohhh, Dad......Yes.....Fuck....."
    scene 21_0730 with dissolve
    car "[ss]..Yes..."
    scene 21_0731 with dissolve
    image CaraR07_34 = Movie(play="images/e21/21_0732.webm")
    show CaraR07_34
    call Moan (car)
    car "[ss]....Ohh, Daddy.....YES...."
    call CharCum ("e21/21_0731.webp", "e21/21_0733.webp", car, "..OHHHHHHH..")
    call CharCum ("e21/21_0733.webp", "e21/21_0734.webp", car, "....Ohhhhhhhh....")
    scene 21_0735 with dissolve
    image CaraR07_35 = Movie(play="images/e21/21_0736.webm")
    show CaraR07_35
    car "[ss]..Mmmh..."
    mil "C'mon, Daddy... My turn to orgasm!"
    scene 21_0737 with fade1
    image CaraR07_36 = Movie(play="images/e21/21_0738.webm")
    show CaraR07_36
    pause
    scene 21_0739 with dissolve
    mil "[ss]..Ohhh, Daddy.."
    scene 21_0740 with dissolve
    image CaraR07_37 = Movie(play="images/e21/21_0741.webm")
    show CaraR07_37
    pause
    scene 21_0742 with dissolve
    image CaraR07_38 = Movie(play="images/e21/21_0743.webm")
    show CaraR07_38
    call Moan (mil)
    scene 21_0744 with dissolve
    pause
    scene 21_0745 with dissolve
    pause
    scene 21_0746 with dissolve
    image CaraR07_39 = Movie(play="images/e21/21_0747.webm")
    show CaraR07_39
    call Moan (mil)
    scene 21_0748 with dissolve
    image CaraR07_40 = Movie(play="images/e21/21_0749.webm")
    show CaraR07_40
    call Moan (mil)
    call CharCum ("e21/21_0748.webp", "e21/21_0750.webp", mil, "..OHHHHHHH..")
    call CharCum ("e21/21_0750.webp", "e21/21_0751.webp", mil, "....Ohhhhhhhh....")
    $ cRes=3
    while cRes!=0:
        if cRes==1:
            call CaraReplay07_Hannah
            $ cRes=_return
        elif cRes==2:
            call CaraReplay07_Cara
            $ cRes=_return
        elif cRes==3:
            call CaraReplay07_Millie
            $ cRes=_return
    scene 21_0789 with fade1
    han "C'mon! Let's go skinny dipping!"
    if _in_replay:
        scene black with ReplayFade
return

label CaraReplay07_Hannah:
    scene 21_0763 with dissolve
    image CaraR07_43 = Movie(play="images/e21/21_0764.webm")
    show CaraR07_43
    pause
    scene 21_0715 with dissolve
    image CaraR07_29 = Movie(play="images/e21/21_0716.webm")
    show CaraR07_29
    han "[ss]..Mmmhhh.."
    scene 21_0765 with dissolve
    image CaraR07_44 = Movie(play="images/e21/21_0766.webm")
    show CaraR07_44
    pause
    scene 21_0767 with dissolve
    image CaraR07_45 = Movie(play="images/e21/21_0768.webm")
    show CaraR07_45
    pause
    call CmOpts (["Cum inside Hannah", "Pull out", "Fuck Cara", "Fuck Millie"])
    $ Copt=_return
    if Copt==0:
        $ Hannah.incCm()
        call CharCum ("e21/21_0767.webp", "e21/21_0769.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0769.webp", "e21/21_0770.webp", mc, "..Nnnhhhh..")
        scene 21_0771 with dissolve
        pause
        scene 21_0772 with dissolve
        pause
    elif Copt==1:
        call CharCum ("e21/21_0767.webp", "e21/21_0773.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0773.webp", "e21/21_0774.webp", mc, "..Nnnhhhh..")
        scene 21_0775 with dissolve
        pause
        scene 21_0776 with dissolve
        pause
    elif Copt==2:
        return 2
    else:
        return 3
    return 0
return

label CaraReplay07_Cara:
    scene 21_0735 with dissolve
    image CaraR07_35 = Movie(play="images/e21/21_0736.webm")
    show CaraR07_35
    car "[ss]..Mmmh..."
    scene 21_0777 with dissolve
    image CaraR07_46 = Movie(play="images/e21/21_0778.webm")
    show CaraR07_46
    pause
    scene 21_0779 with dissolve
    image CaraR07_47 = Movie(play="images/e21/21_0780.webm")
    show CaraR07_47
    pause
    call CmOpts (["Cum inside Cara", "Pull out", "Fuck Hannah", "Fuck Millie"])
    $ Copt=_return
    if Copt==0:
        $ Cara.incCm()
        call CharCum ("e21/21_0779.webp", "e21/21_0781.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0781.webp", "e21/21_0782.webp", mc, "..Nnnhhhh..")
        scene 21_0787 with dissolve
        pause
        scene 21_0788 with dissolve
        pause
    elif Copt==1:
        call CharCum ("e21/21_0779.webp", "e21/21_0783.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0783.webp", "e21/21_0784.webp", mc, "..Nnnhhhh..")
        scene 21_0785 with dissolve
        pause
        scene 21_0786 with dissolve
        pause
    elif Copt==2:
        return 1
    else:
        return 3
    return 0
return

label CaraReplay07_Millie:
    scene 21_0752 with dissolve
    image CaraR07_41 = Movie(play="images/e21/21_0753.webm")
    show CaraR07_41
    pause
    scene 21_0754 with dissolve
    image CaraR07_42 = Movie(play="images/e21/21_0755.webm")
    show CaraR07_42
    pause
    call CmOpts (["Cum inside Millie", "Pull out", "Fuck Cara", "Fuck Hannah"])
    $ Copt=_return
    if Copt==0:
        $ Millie.incCm()
        call CharCum ("e21/21_0754.webp", "e21/21_0756.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0756.webp", "e21/21_0757.webp", mc, "..Nnnhhhh..")
        scene 21_0758 with dissolve
        pause
        scene 21_0759 with dissolve
        pause
    elif Copt==1:
        call CharCum ("e21/21_0754.webp", "e21/21_0760.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0760.webp", "e21/21_0761.webp", mc, "..Nnnhhhh..")
        scene 21_0762 with dissolve
        pause
    elif Copt==2:
        return 2
    else:
        return 1
    return 0
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
