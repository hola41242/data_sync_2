label NicoleReplay01:
    call Unlocker ("NicoleReplay01")
    if not _in_replay:
        $ persistent.NicoleRP01Dat = (persistent.Incest and Cara.getSex()>0)
    $ Nicole.isSexual(True)
    scene 17_0275 with fade1
    nic "[whi]It was a guy and a girl."
    nic "[whi]She was around my age; he was... older."
    scene 17_0276 with dissolve
    nic "[whi]If I had to guess, I'd say about... your age."
    if persistent.Incest:
        nic "[whi]... She called him Daddy."
    else:
        nic "[whi]I think he was her dad's friend."
    scene 17_0277 with dissolve
    if persistent.NicoleRP01Dat:
        nic "[whi]It reminded me of you and Cara."
    mc "[whi]Did you like watching them?"
    nic "[whi]Yeah."
    mc "[whi]And what were they doing?"
    scene 17_0278 with dissolve
    nic "[whi]Kissing..."
    nic "[whi]... Touching..."
    nic "[whi]... Other things."
    mc "[whi]{i}Other things{/i}?"
    scene 17_0279 with dissolve
    nic "[whi]Do I have to tell you everything?\nI can just put it on and show you."
    mc "[whi]No, I want {b}you{/b} to describe it to me."
    nic "[whi]Okay."
    scene 17_0280 with dissolve
    if persistent.Incest:
        nic "[whi]It started with the girl teasing her dad..."
        nic "[whi]She was wearing a revealing outfit, and she could tell her daddy liked it."
    else:
        nic "[whi]It started with the girl teasing him..."
        nic "[whi]She was wearing a revealing outfit, and she could tell he liked it."
    scene 17_0281 with dissolve
    nic "[whi]She sat down next to him, real close..."
    nic "[whi]... and draped her legs over his."
    nic "[whi]She playfully took his hand, and placed it on her thigh, close to her knee."
    scene 17_0282 with dissolve
    scene 17_0283 with dis1
    mc "[whi]Here, like this?"
    nic "[whi]Mhh-mhh."
    nic "[whi]He knew he should move his hand away, but he didn't want to."
    scene 17_0284 with dissolve
    nic "[whi]She hugged him tight, their cheeks touching..."
    nic "[whi]... She slowly turned her head, her lips getting closer and closer to his..."
    nic "[whi]They kissed... almost accidentally at first..."
    scene 17_0285 with dissolve
    nic "[whi]Passion overcomes her..."
    if persistent.Incest:
        nic "[whi]She thrusts her tongue into her dad's mouth, and he doesn't resist - at all."
    else:
        nic "[whi]She thrusts her tongue into his mouth, and he doesn't resist - at all."
    nic "[whi]They continue to kiss, almost devouring each other."
    scene 17_0286 with dissolve
    if persistent.Incest:
        nic "[whi]The dad moves his hand slowly... gently... up his daughter's thigh."
    else:
        nic "[whi]He moves his hand slowly... gently... up her thigh."
    scene 17_0287 with dis1
    scene 17_0288 with dis1
    nic "[whi]She parts her legs slightly..."
    scene 17_0289 with dis1
    nic "[whi]Just enough to encourage him to continue."
    if persistent.Incest:
        nic "[whi]She knows it's wrong... forbidden..."
    else:
        nic "[whi]She knows it's wrong..."
    nic "[whi]...But she's wanted him for so long."
    scene 17_0290 with dissolve
    mc "[whi]And how did it make you feel?"
    nic "[whi]..."
    nic "[whi]... Excited."
    scene 17_0291 with dissolve
    mc "[whi]Watching them made you horny?\nI imagine your beautiful, little nipples got hard."
    nic "[whi]Mhh-mhh."
    mc "[whi]... They look hard now.\nIs telling me the story turning you on, too?"
    nic "[whi]Yes."
    scene 17_0292 with dis1
    scene 17_0293 with dis1
    scene 17_0294 with dis1
    scene 17_0295 with dis1
    mc "[whi]What happened next?"
    nic "[whi]She put her hand down his pants..."
    nic "[whi]And pulled out his penis."
    scene 17_0296 with dis1
    if persistent.Incest:
        mc "[whi]Did that make you more excited?\nSeeing her daddy's dick in her hand?"
    else:
        mc "[whi]Did that make you more excited?"
    nic "[whi]Mhh-mhh."
    nic "[whi]She started stroking it. He liked that."
    scene 17_0297 with dis1
    mc "[whi]Did you?"
    nic "[whi]I preferred what she did next..."
    nic "[whi]They stopped kissing... He pushed her head down toward his waist..."
    call Loop_Dissolve (3, True, False, "e17/17_0298.webp", "e17/17_0299.webp")
    scene 17_0300 with dissolve
    nic "[whi]She stuck out her tongue and licked him..."
    nic "[whi]Slowly moving from the base, all the way up to the tip."
    scene 17_0301 with dissolve
    if persistent.Incest:
        nic "[whi]She teased her dad with her tongue for a few minutes... but she couldn't wait any longer..."
    else:
        nic "[whi]She teased him with her tongue for a few minutes... but she couldn't wait any longer..."
    nic "[whi]She opened her mouth and gently took in the tip of his penis."
    scene 17_0302 with dissolve
    nic "[whi]Her wet lips tightly wrapped around his... cock.... She went down as far as she could, before slowly moving back up..."
    nic "[whi]Up and down.... Up and down..."
    if persistent.Incest:
        nic "[whi]She let out a soft moan. I think she was excited to finally have Daddy's hard cock in her mouth..."
    else:
        nic "[whi]She let out a soft moan. I think she was excited to finally have his hard cock in her mouth..."
    scene 17_0303 with dissolve
    nic "[whi]She repositioned herself... Which allowed him to touch her..."
    nic "[whi]... He didn't hesitate."
    scene 17_0304 with dissolve
    nic "[whi]He pulled down her wet panties..."
    scene 17_0305 with dissolve
    mc "[whi]... Were yours wet?"
    scene 17_0306 with dissolve
    call Emotion (nic, "Breathing heavily", "", True)
    scene 17_0307 with dis1
    nic "[whi]Soaking."
    scene 17_0308 with dis1
    mc "[whi]Are they wet now?"
    nic "[whi]Mhh-mhh."
    scene 17_0309 with dissolve
    mc "[whi]What did he do next?"
    nic "[whi]... His fingers gently glanced her--"
    scene 17_0310 with dissolve
    call Emotion (nic, "Gasp", "", True)
    scene 17_0311 with dissolve
    nic "[ss]...Ohh..."
    nic "[whi]... His... fingers..."
    scene 17_0312 with dissolve
    nic "[whi]He... He gently massaged her..."
    scene 17_0313 with dissolve
    image NicoleR01_01 = Movie(play="images/e17/17_0314.webm")
    show NicoleR01_01
    pause
    scene 17_0315 with dissolve
    call Moan (nic)
    scene 17_0316 with dissolve
    nic "[ss]..Mhh.."
    mc "[whi]... Then what?"
    scene 17_0317 with dissolve
    nic "[whi]He..."
    nic "[whi]..."
    nic "[whi]... He..."
    nic "[whi]... slipped his finger in..."
    scene 17_0318 with dissolve
    pause 0.5
    scene 17_0319 with dis1
    scene 17_0320 with dis1
    call Loop_Dissolve (3, True, False, "e17/17_0321.webp", "e17/17_0322.webp")
    scene 17_0323 with dis1
    call Loop_Dissolve (2, True, False, "e17/17_0324.webp", "e17/17_0325.webp")
    scene 17_0326 with dis1
    pause 0.5
    scene 17_0327 with dis1
    scene 17_0328 with dis1
    scene 17_0329 with dis1
    pause 0.5
    scene 17_0330 with dissolve
    nic "[ss]Ohhh..."
    mc "[whi]Did she enjoy being touched like this?"
    nic "[ss]Mhhh..."
    scene 17_0331 with dis1
    image NicoleR01_02 = Movie(play="images/e17/17_0332.webm")
    show NicoleR01_02
    nic "[whi]...She was in Heaven..."
    nic "[ss]...Mhhh..."
    scene 17_0333 with dissolve
    image NicoleR01_03 = Movie(play="images/e17/17_0334.webm")
    show NicoleR01_03
    call Moan (nic)
    scene 17_0335 with dissolve
    nic "[ss]...Ohh..."
    scene 17_0336 with dis1
    scene 17_0337 with dis1
    scene 17_0338 with dis1
    scene 17_0339 with dissolve
    scene 17_0340 with dis1
    scene 17_0341 with dis1
    scene 17_0342 with dis1
    scene 17_0343 with dis1
    pause 0.5
    scene 17_0344 with dissolve
    image NicoleR01_04 = Movie(play="images/e17/17_0345.webm")
    show NicoleR01_04
    nic "[ss]Mmmhhhh."
    scene 17_0346 with dissolve
    image NicoleR01_05 = Movie(play="images/e17/17_0347.webm")
    show NicoleR01_05
    pause
    scene 17_0348 with dissolve
    nic "[ss]..Mmhhh.."
    scene 17_0349 with dis1
    mc "[whi]Did you watch them fuck?"
    nic "[whi]... No..."
    call Moan (nic)
    scene 17_0350 with dissolve
    nic "[whi]My mom walked in..."
    nic "[ss]..Mmhhh.."
    nic "[whi]... just as they were about to..."
    scene 17_0351 with dissolve
    scene 17_0352 with dis1
    scene 17_0353 with dis1
    scene 17_0354 with dis1
    image NicoleR01_06 = Movie(play="images/e17/17_0355.webm")
    show NicoleR01_06
    call Moan (nic)
    scene 17_0356 with dissolve
    if persistent.Incest:
        mc "[whi]So you didn't see Daddy squeeze his hard, throbbing dick..."
        nic "[ss]Ohhhh."
        mc "[whi]... into his daughter's tight, little pussy?"
    else:
        mc "[whi]So you didn't see him squeeze his hard, throbbing dick..."
        nic "[ss]Ohhhh."
        mc "[whi]... into her tight, little pussy?"
    scene 17_0357 with dis1
    mc "[whi][kiss]"
    scene 17_0358 with dissolve
    nic "[whi]No."
    if persistent.Incest:
        mc "[whi]You didn't hear her moan as Daddy slowly forced his dick all the way inside?"
    else:
        mc "[whi]You didn't hear her moan as he slowly forced his dick all the way inside?"
    if persistent.NicoleRP01Dat:
        mc "[whi]... Cara moaned the same when I fucked her for the first time."
    scene 17_0359 with dis1
    mc "[whi][kiss]"
    scene 17_0360 with dis1
    nic "[ss]..Ohhhhh..."
    if persistent.NicoleRP01Dat:
        mc "[whi]Her pussy was so tight. So warm, so wet."
        mc "[whi]We both knew it was wrong... but, damn, it felt so right."
    else:
        mc "[whi]Thrusting his rock-hard dick in and out of his daughter..."
    scene 17_0361 with dis1
    mc "[whi][kiss]"
    scene 17_0362 with dis1
    call Moan (nic)
    if persistent.NicoleRP01Dat:
        mc "[whi]I loved every second of it..."
        nic "[ss]..Mmmhhh... So did she."
        mc "[whi]I loved her sucking my dick... I loved eating her pussy."
        if Cara.getCumIns()>0:
            mc "[whi]...I loved cummin' inside her."
        else:
            mc "[whi]...I love cummin' in her mouth and watching her swallow every drop."
    else:
        mc "[whi]...Faster and faster.... He can't control himself... He loves fucking her...."
    scene 17_0363 with dis1
    nic "[ss]Ohhhhh..."
    scene 17_0364 with dissolve
    scene 17_0365 with dis1
    scene 17_0366 with dis1
    scene 17_0367 with dis1
    scene 17_0368 with dissolve
    call Moan (nic)
    scene 17_0369 with dis1
    image NicoleR01_07 = Movie(play="images/e17/17_0370.webm")
    show NicoleR01_07
    nic "[ss]....Ohhhh, God......"
    scene 17_0371 with dissolve
    image NicoleR01_08 = Movie(play="images/e17/17_0372.webm")
    show NicoleR01_08
    call Moan (nic, 6)
    scene 17_0373 with dissolve
    nic "[ss].......Ohhhh.........[persistent.McName].......Yes......."
    call CharCum ("e17/17_0373.webp", "e17/17_0374.webp", nic, "....OHHHHHHH....")
    call CharCum ("e17/17_0374.webp", "e17/17_0375.webp", nic, "...Mmmmhhhhhhhh...")
    scene 17_0376 with dissolve
    call Emotion (nic, "Breathing heavily")
    mc "[whi]You okay?"
    nic "[whi]... Mh-mhh."
    if _in_replay:
        scene black with ReplayFade
return

label NicoleReplay02:
    call Unlocker ("NicoleReplay02")
    if _in_replay:
        scene 20_0170 with Fade(0,1,1)
        mc "See that girl in the mirror?"
    else:
        scene 20_0170 with dissolve
        mc "Now, see that girl in the mirror?"
    nic "[whi]... Yeah."
    scene 20_0171 with dissolve
    mc "I want you to look her in the eyes and tell her that you have {b}nothing{/b} to feel embarrassed about."
    nic "[whi][persistent.McName]..."
    mc "Go on, tell her."
    scene 20_0172 with dissolve
    call EmotionSml (nic, "Sigh", "... You have nothing to feel embarrassed about.")
    mc "Good."
    mc "Tell her again, but this time I want you to {i}mean it{/i}."
    nic "..."
    scene 20_0173 with dissolve
    nic "You have {b}nothing{/b} to feel embarrassed about."
    mc "Again."
    scene 20_0174 with dissolve
    nic "{b}You have nothing to feel embarrassed about{/b}!"
    scene 20_0175 with dissolve
    mc "Now {b}that{/b} one I believed!"
    mc "If that girl could ask you if you enjoyed what we did, what would you answer?"
    scene 20_0176 with dissolve
    nic "[whi]I'd answer... yes."
    scene 20_0177 with dissolve
    mc "And if she asked if you've masturbated while thinking about it?"
    nic "[whi]..."
    scene 20_0178 with dissolve
    nic "[whi]Maybe."
    scene 20_0179 with dissolve
    mc "More than once?"
    nic "[whi]Yeah."
    mc "Have you thought about us doing it {i}again{/i}?"
    scene 20_0180 with dis1
    mc "[whi][kiss]"
    scene 20_0181 with dis1
    nic "[whi]A lot."
    scene 20_0182 with dis1
    mc "[whi]Three rules for today..."
    mc "[whi]We're {b}not{/b} going to have sex."
    mc "[whi]You're {b}not{/b} going to do anything to me."
    scene 20_0183 with dissolve
    mc "[whi]And if you say stop, I stop."
    mc "[whi]Are we agreed?"
    scene 20_0184 with dissolve
    nic "[whi]Yes."
    scene 20_0185 with dis1
    mc "[whi][kiss]"
    scene 20_0186 with dis1
    mc "[whi][kiss]"
    scene 20_0187 with dis1
    pause 0.5
    scene 20_0188 with dis1
    nic "[ss]Mhh."
    scene 20_0189 with dis1
    pause 0.5
    scene 20_0190 with dis1
    nic "[ss]..Mmmhh.."
    scene 20_0191 with dis1
    pause 0.5
    scene 20_0192 with dis1
    mc "[whi][kiss]"
    scene 20_0193 with dis1
    mc "[whi][kiss]"
    scene 20_0194 with dis1
    pause 0.5
    scene 20_0195 with dis1
    nic "[ss]..Mmmhh.."
    scene 20_0198 with dissolve
    nic "[ss]Mmmmhh."
    scene 20_0199 with dissolve
    pause 0.5
    scene 20_0200 with dis1
    nic "[ss]..Ohhhh.."
    scene 20_0201 with dissolve
    image NicoleR02_01 = Movie(play="images/e20/20_0202.webm")
    show NicoleR02_01
    nic "[ss]Mhh."
    scene 20_0203 with dissolve
    nic "[ss]..Ohhh.."
    scene 20_0204 with dissolve
    pause 0.5
    scene 20_0205 with dis1
    pause 0.5
    scene 20_0206 with dis1
    pause 0.5
    scene 20_0207 with dis1
    nic "[ss]Mhh."
    scene 20_0208 with dissolve
    call Moan (nic, 4)
    scene 20_0209 with dissolve
    pause 0.5
    scene 20_0210 with dis1
    mc "[whi][kiss]"
    scene 20_0211 with dis1
    pause 0.5
    scene 20_0212 with dis1
    mc "[whi][kiss]"
    scene 20_0213 with dis1
    scene 20_0214 with dis1
    scene 20_0215 with dis1
    pause
    scene 20_0216 with dis1
    scene 20_0217 with dis1
    pause
    scene 20_0218 with dissolve
    pause 0.5
    scene 20_0219 with dis1

    scene 20_0220 with dis1
    nic "[ss]Mmmmhh."
    scene 20_0221 with dissolve
    image NicoleR02_02 = Movie(play="images/e20/20_0222.webm")
    show NicoleR02_02
    nic "[ss]..Mmhh.."
    scene 20_0223 with dissolve
    image NicoleR02_03 = Movie(play="images/e20/20_0224.webm")
    show NicoleR02_03
    call Moan (nic)
    scene 20_0225 with dissolve
    pause
    scene 20_0226 with dissolve
    nic "[ss]Mhh."
    scene 20_0227 with dissolve
    pause 0.5
    scene 20_0228 with dis1
    scene 20_0229 with dis1
    nic "[ss]Mmmmhh."
    scene 20_0230 with dissolve
    nic "[ss]..Mhh.."
    scene 20_0231 with dis1
    mc "[whi][kiss]"
    scene 20_0232 with dis1
    scene 20_0233 with dis1
    mc "[whi][kiss]"
    scene 20_0234 with dis1
    scene 20_0235 with dis1
    mc "[whi][kiss]"
    scene 20_0236 with dis1
    pause 0.5
    scene 20_0237 with dissolve
    mct "I'm gonna enjoy this as much as she is."
    scene 20_0238 with dissolve
    $ aPs(0, True)
    image NicoleR02_04 = Movie(play="images/e20/20_0239.webm", loop=False, keep_last_frame=True)
    image NicoleR02_05 = Movie(play="images/e20/20_0240.webm")
    show NicoleR02_04
    pause 3.0
    nic "[ss]..Ohhh..{w=2}{nw}"
    pause 4.0
    nic "{font=Lemon.ttf}{size=*[Sz]}*Moans*{w=2}{nw}"
    pause 2.0
    $ aPs(-1, False, True)
    show NicoleR02_05
    nic "[ss]..Ohhh.."
    scene 20_0241 with dissolve
    nic "[ss]Ohhhh."
    scene 20_0242 with dissolve
    call Moan (nic)
    scene 20_0243 with dissolve
    pause 0.5
    scene 20_0244 with dis1
    nic "[ss]God."
    scene 20_0245 with dissolve
    image NicoleR02_06 = Movie(play="images/e20/20_0246.webm")
    show NicoleR02_06
    call Moan (nic)
    scene 20_0247 with dissolve
    image NicoleR02_07 = Movie(play="images/e20/20_0248.webm")
    show NicoleR02_07
    nic "[ss]..Ohhh, god......I love that, [persistent.McName]....."
    scene 20_0249 with dissolve
    nic "[ss]..Ohh....."
    scene 20_0250 with dissolve
    nic "[ss]Ohhhh."
    scene 20_0251 with dissolve
    call Moan (nic)
    scene 20_0252 with dissolve
    nic "[ss]..Mmmhhh.."
    scene 20_0253 with dissolve
    call Moan (nic)
    scene 20_0254 with dis1
    pause 0.5
    scene 20_0255 with dis1
    pause 0.5
    scene 20_0256 with dis1
    image NicoleR02_08 = Movie(play="images/e20/20_0257.webm")
    show NicoleR02_08
    nic "[ss]Ohhhh."
    scene 20_0258 with dis1
    nic "[ss]..OHHHH.."
    scene 20_0259 with dissolve
    nic "[ss]..GOD......YES...."
    scene 20_0260 with dissolve
    nic "[ss]....OHHHH, [persistent.McName!u]...YES.......FASTER....."
    scene 20_0261 with dissolve
    call Moan (nic, 8)
    scene 20_0262 with dissolve
    nic "[ss]...FUCK........YES........OHHHHH......"
    call CharCum ("e20/20_0262.webp", "e20/20_0263.webp", nic, "....OHHHHHHH....")
    call CharCum ("e20/20_0263.webp", "e20/20_0264.webp", nic, "...Ohhhhhhhh...")
    scene 20_0265 with dis1
    nic "[ss]God, that was magic!"
    scene 20_0266 with dissolve
    call EmotionSml (nic, "Breathing heavily", "I've been dyin' to know what that feels like.")
    scene 20_0267 with dissolve
    nic "[whi]I can't even describe it.\nIt was... amazing!"
    scene 20_0268 with dissolve
    mct "She tastes so damn good."
    scene 20_0267 with dissolve
    pause 0.5
    scene 20_0269 with dis1
    mc "[whi]Nnnnh."
    scene 20_0270 with dis1
    mc "[whi]Sorry... couldn't help it; just had to have one more lick!"
    nic "[lol]"
    scene 20_0271 with fade1
    nic "[whi]Mmhh."
    scene 20_0272 with dissolve
    nic "[whi]..Mmmhh.."
    if not _in_replay:
        scene 20_0273 with dissolve
        nic "Thank you for not getting angry with me when I asked you to leave last time."
        mc "I could never get angry with you, Sweetheart."
        nic "Promise?"
        mc "Yeah, why?"
        scene 20_0274 with dissolve
        nic "I have to do it again."
        mc "You want me to leave?"
        scene 20_0275 with dis1
        nic "Not {i}right{/i} now, and I don't {i}want{/i} you to... but yeah."
        nic "Alex is coming over soon."
        scene 20_0276 with dissolve
        mc "And you don't want her to find out about... this?"
        nic "I should be the one to tell Cara about us, and Alex couldn't keep a secret even if her life depended on it."
        scene 20_0277 with dissolve
        nic "Unless... You don't want Cara to know?"
        nic "She already knows I like you... She won't mind."
        $ tCh=True
        if not EzModeActive:
            menu:
                "[wk_y]Yeah, you can tell her":
                    pass
                "Don't say anything to her":
                    $ tCh=False
        if tCh:
            $ Nicole.Add("A00")
            scene 20_0279 with dissolve
            mc "Think she'll be okay with it?"
            nic "Yeah, I know she will."
            nic "She's the one who talked me into wearing the school uniform for you."
            scene 20_0280 with dissolve
            mc "Yeah? Damn, I'll have to remember to thank her for that."
            nic "[lol]"
        else:
            scene 20_0278 with dissolve
            nic "[whi]Oh... okay."
            mc "Just... for now."
    scene 20_0281 with dis1
    nic "[whi]Mmhh."
    scene 20_0282 with dissolve
    nic "[whi]..Mmmhh.."
    scene 20_0283 with dis1
    nic "[whi].Mmhh."
    scene 20_0284 with dissolve
    mc "Nope."
    nic "I only want to hold it."
    mc "Sorry, but we agreed on the rules!"
    scene 20_0285 with dissolve
    nic "[lol] Seriously?"
    mc "Yep!"
    scene 20_0286 with dissolve
    nic "Okay, fine... But next time, {b}I{/b} get to choose the rules."
    call laugh (mc, "Fair enough.")
    scene 20_0287 with dissolve
    nic "[whi]Mhh."
    scene 20_0288 with dissolve
    nic "[whi]..Mmmhh.."
    scene 20_0289 with dissolve
    pause
    scene black with Fade(2, 2, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
