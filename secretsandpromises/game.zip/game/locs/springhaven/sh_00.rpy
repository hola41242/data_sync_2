default persistent.springhaven_active = False
default springhaven_id = "SPH"
default springhaven_ch = 1
default springhaven_open = True
default springhaven_info = ["","", 
"I still have work to do in Springhaven to finish paying off Pete's debt.",
"I've given the truck a good test-drive.\nIf the price is right, I'm buying it!"
]

label UpdateSpringhavenData(id=0):
    if len(springhaven_info)<=4:
        $ springhaven_info.insert(4,"I'll need to update Sue on the Lakeshore plan.\nWe still need to figure out what to do once we have Melissa in the safehouse.")
    if len(springhaven_info)<=5:
        $ springhaven_info.insert(5, "Sue will be eager to find out what's happened with Melissa.\nNeed to break it to her that she doesn't actually want to return to Springhaven.")
    if len(springhaven_info)<=6:
        $ springhaven_info.insert(6, "Need to report back to Sue. She has a photoshoot to arrange.")
    if len(springhaven_info)<=7:
        $ springhaven_info.insert(7, "Alysha still hasn't called. Something's definitely wrong. I need to find her.")
    if len(springhaven_info)<=8:
        $ springhaven_info.insert(8, "Drop Alison and Cara off home, and then I guess it's back to work.")
return

default persistent.SarahLocked = True
default Sarah_name = "Sarah"
define sar = Character("[Sarah_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="sarah")
image side sarah cell = side+"sarah_c.png"
image side sarah h = side+"sarah_hp.png"
image side sarah s = side+"sarah_sd.png"
image side sarah a = side+"sarah_an.png"
image side sarah sh = side+"sarah_sh.png"
image side sarah su = side+"sarah_su.png"
default Sarah = Stats()
default persistent.SarahRP03Dat = False

default persistent.MaryLocked = True
default persistent.MaryDaddy = False
default Mary_name = "Mary"
define mar = Character("[Mary_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="mary")
image side mary cell = side+"mary_c.png"
image side mary h = side+"mary_hp.png"
image side mary s = side+"mary_sd.png"
image side mary a = side+"mary_an.png"
image side mary sh = side+"mary_sh.png"
image side mary su = side+"mary_su.png"
default Mary = Stats()
default persistent.MaryRP02Dat = True
default persistent.MaryRP03Dat = False
default persistent.MaryRP05Dat = 0

default persistent.CaraLocked = True
default Cara_name = "Cara"
define car = Character("[Cara_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="cara")
image side cara cell = side+"cara_c.png"
image side cara h = side+"cara_hp.png"
image side cara s = side+"cara_sd.png"
image side cara a = side+"cara_an.png"
image side cara sh = side+"cara_sh.png"
image side cara su = side+"cara_su.png"
default Cara = Stats()
default persistent.CaraRP03Dat = ([0, False, False, False, 0])
default persistent.CaraRP04Dat = [False, False]

default persistent.AlisonLocked = True
default Alison_name = "Alison"
define ali = Character("[Alison_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="alison")
image side alison cell = side+"alison_c.png"
image side alison h = side+"alison_hp.png"
image side alison s = side+"alison_sd.png"
image side alison a = side+"alison_an.png"
image side alison sh = side+"alison_sh.png"
image side alison su = side+"alison_su.png"
default Alison = Stats()

default persistent.AlyshaLocked = True
default Alysha_name = "Alysha"
define aly = Character("[Alysha_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="alysha")
image side alysha cell = side+"alysha_c.png"
image side alysha h = side+"alysha_hp.png"
image side alysha s = side+"alysha_sd.png"
image side alysha a = side+"alysha_an.png"
image side alysha sh = side+"alysha_sh.png"
image side alysha su = side+"alysha_su.png"
default Alysha = Stats()
default persistent.AlyshaRP01Dat = False

default persistent.AlexLocked = True
default Alex_name = "Alex"
define alex = Character("[Alex_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="alex")
image side alex cell = side+"alex_c.png"
image side alex h = side+"alex_hp.png"
image side alex s = side+"alex_sd.png"
image side alex a = side+"alex_an.png"
image side alex sh = side+"alex_sh.png"
image side alex su = side+"alex_su.png"
default Alex = Stats()
default persistent.AlexRP02Dat = [False, 0, False, False]

default persistent.MelandGab = False
default persistent.MelanieLocked = True
default Melanie_name = "Melanie"
define mel = Character("[Melanie_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="melanie")
image side melanie cell = side+"melanie_c.png"
image side melanie h = side+"melanie_hp.png"
image side melanie s = side+"melanie_sd.png"
image side melanie a = side+"melanie_an.png"
image side melanie sh = side+"melanie_sh.png"
image side melanie su = side+"melanie_su.png"
default Melanie = Stats()
default persistent.MelanieRP02Dat = ([False, False, False, False])
default persistent.MelanieRP03Dat = ([False, False])
default mAndG = None
default persistent.GabbyLocked = True
default Gabby_name = "Gabrielle"
define gab = Character("[Gabby_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="gabby")
image side gabby cell = side+"gabby_c.png"
image side gabby h = side+"gabby_hp.png"
image side gabby s = side+"gabby_sd.png"
image side gabby a = side+"gabby_an.png"
image side gabby sh = side+"gabby_sh.png"
image side gabby su = side+"gabby_su.png"
default Gabby = Stats()

default persistent.SueLocked = True
default Sue_name = "Sue"
define sue = Character("[Sue_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="sue")
image side sue cell = side+"sue_c.png"
image side sue h = side+"sue_hp.png"
image side sue s = side+"sue_sd.png"
image side sue a = side+"sue_an.png"
image side sue sh = side+"sue_sh.png"
image side sue su = side+"sue_su.png"

default Sue = Stats()
default persistent.SueRP02Dat = ([False, False])

default persistent.NicoleLocked = True
default Nicole_name = "Nicole"
define nic = Character("[Nicole_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="nicole")
image side nicole cell = side+"nicole_c.png"
image side nicole h = side+"nicole_hp.png"
image side nicole s = side+"nicole_sd.png"
image side nicole a = side+"nicole_an.png"
image side nicole sh = side+"nicole_sh.png"
image side nicole su = side+"nicole_su.png"
default Nicole = Stats()
default persistent.NicoleRP01Dat = False

default persistent.KiyomiLocked = True
default Kiyomi_name = "Kiyomi"
define ki = Character("[Kiyomi_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="kiyomi")
image side kiyomi cell = side+"kiyomi_c.png"
image side kiyomi h = side+"kiyomi_hp.png"
image side kiyomi s = side+"kiyomi_sd.png"
image side kiyomi a = side+"kiyomi_an.png"
image side kiyomi sh = side+"kiyomi_sh.png"
image side kiyomi su = side+"kiyomi_su.png"
default Kiyomi = Stats()

default persistent.ChristinaLocked = True
default Christina_name = "Christina"
default ChFx = False
define cri = Character("[Christina_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="christina")
image side christina cell = side+"christina_c.png"
image side christina h = side+"christina_hp.png"
image side christina s = side+"christina_sd.png"
image side christina a = side+"christina_an.png"
image side christina sh = side+"christina_sh.png"
image side christina su = side+"christina_su.png"
default Christina = Stats()

define mech = Character("", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="mech")
define mechbro = Character("", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="mechbro")
define cop = Character("Police officer", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define barman = Character("", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="barman")
define bus = Character("Bus Driver", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])
define cabby = Character("Cab Driver", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")])

default Bill_name = ""
define bill = Character("[Bill_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="bill")

default Ah1_name = ""
default Ah2_name = ""
define ah1 = Character("[Ah1_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="ah1")
define ah2 = Character("[Ah2_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="ah2")
default Wilks_name = ""
define wilks = Character("[Wilks_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="wilks")

default James_name = ""
define jam = Character("[James_name]", what_color=Wht, what_outlines=BlkO, who_color="#a5c2dd", who_outlines=[(1, "#362a55")], image="james")

screen Springhaven_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "sph", "alex", Alex_Replay, persistent.AlexLocked, "Cara and Nicole's friend.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "alison", Alison_Replay, persistent.AlisonLocked, "Cara's mom.\n[persistent.McName]'s long-time friend.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "alysha", Alysha_Replay, persistent.AlyshaLocked, "Springhaven Police Officer.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        if persistent.Incest:
            use ReplayItemBtn(next_x, next_y, "sph", "cara", Cara_Replay, persistent.CaraLocked, "Alison's daughter.\nAlex and Nicole's friend.")
            python:
                next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "christina", Christina_Replay, persistent.ChristinaLocked, "Nicole's mom.\nAlison's close friend.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "gabrielle", Gabby_Replay, persistent.GabbyLocked, "Co-owner of Rosie's cafe.\nMelanie's younger sister.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "kiyomi", Kiyomi_Replay, persistent.KiyomiLocked, "Sue's maid.\nMitsui's daughter and Miyuka's sister.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "mary", Mary_Replay, persistent.MaryLocked, "Bill the trucker's granddaughter.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "melanie", Melanie_Replay, persistent.MelanieLocked, "Co-owner of Rosie's cafe.\nGabrielle's older sister.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "nicole", Nicole_Replay, persistent.NicoleLocked, "Cara and Alex's friend.\nChristina's daughter.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "sarah", Sarah_Replay, persistent.SarahLocked, "Dawn's best friend.\nSchool teacher.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "sph", "sue", Sue_Replay, persistent.SueLocked, "Local boss for the company.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
