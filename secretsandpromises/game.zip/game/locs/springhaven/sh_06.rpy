label Springhaven_Start5:
    scene 12_0802 with Fade(0,0,3)
    call AutoA
    $ apause()
    scene 12_0803 with dis1
    scene 12_0804 with dis1
    scene 12_0805 with dis1
    scene 12_0806 with dissolve
    call AutoA (False)
    mct "Hope Alison saw my message about me getting back late, otherwise I'm sleeping in here!"
    if oakhill_ch<5:
        mct "Felt like I was stuck on that damn freeway for days, not hours!\nAll because some idiot decided to speed... and crash."
    if Chloe.Has("SndPic"):
        mct "Just remembered... Got a text message earlier..."
        pause 1.0
        scene 12_0807 with dissolve
        mct "It's from Chloe..."
        call Msg_Chloe03 (False)
        $ Chloe.Del("SndPic")
        scene 12_0808 with dissolve
        mct "She's so fuckin' hot. Heh."
    scene 12_0809 with dissolve
    pause
    scene 13_0001 with dissolve
    scene 13_0002 with dis1
    mct "So glad she didn't lock me out!"
    scene 13_0003 with dis1
    scene 13_0004 with dis1
    scene 13_0005 with dis1
    scene 13_0006 with dis1
    mct "I'm exhausted!"
    scene 13_0008 with dis1
    mct "Huh?... Who's in my bed??"
    scene 13_0009 with dissolve
    car "[whi]..Zzz.."
    mct "Hmm... Guess Nicole's having another sleepover."
    if not persistent.Incest or not Cara.isActive():
        jump Springhaven_05_WakeCara
    mct "Should probably wake her..."
    if Cara.L<4:
        $ Cara.Add("Slept")
        scene 13_0016 with fade1
        mc "[whi]..Zzz.."
        jump Springhaven_05_Breakfast
    if not EzModeActive:
        menu:
            "Send Cara back to her own room":
                jump Springhaven_05_WakeCara
            "[wk_y]Get into bed":
                pass
    elif not Cara.Has("EZ"):
        jump Springhaven_05_WakeCara
    else:
        mct "Nah, let her sleep."
    scene 13_0015 with fade1
    mct "Hopefully, she'll wake early and sneak back to her own room."
    $ tCh=True
    if not EzModeActive:
        menu:
            "Switch off the lamp and go to sleep":
                $ tCh=False
            "[wk_y]Not so fast...":
                pass
    if tCh:
        $ Cara.Add("FiB")
        call CaraReplay05
        scene 13_0099 with Fade(0,1,2)
        mc "[whi]Nicole staying over again?"
        car "[whi]No.\nI was just missing you, so slept in your bed."
        scene 13_0100 with dissolve
        mc "[whi]I missed you, too."
        scene 13_0101 with dissolve
        car "[whi]Mmh."
        scene 13_0102 with dissolve
        car "[whi]..Mmmhh.."
        scene 13_0103 with fade1
        mc "[whi]..Zzz.."
    else:
        $ Cara.Add("Slept")
        scene 13_0016 with fade1
        mc "[whi]..Zzz.."
    jump Springhaven_05_Breakfast
return

label Springhaven_05_WakeCara:
    $ Cara.Add("Woke")
    scene 13_0010 with dissolve
    mc "[whi]Cara..."
    mc "[whi]Sorry, Pipsqueak, but you need to get back into your own bed."
    scene 13_0011 with dissolve
    car "[whi]Mhhh... Dad?"
    mc "[whi]Yeah. I just got home."
    if persistent.Incest and Cara.isActive():
        mc "[whi]It's too risky for you to sleep here."
        car "[whi]Okay..."
    scene 13_0012 with dissolve
    mc "[whi]You gonna be okay sharing with Nicole?"
    car "[whi]Nicole?"
    car "[whi]She's not staying over tonight."
    scene 13_0013 with dissolve
    car "[whi]I was just missing you, so slept in your bed."
    car "[whi]Night, Dad."
    mc "[whi]Night, Pipsqueak."
    scene 13_0014 with fade1
    mc "[whi]..Zzz.."
    jump Springhaven_05_Breakfast
return

label Springhaven_05_Breakfast:
    scene 13_0104 with Fade(3, 2, 2)
    call Emotion (mc, "Groan", "", True)
    scene 13_0105 with fade1
    ali "Morning.\nI heard you walking around up there, so I made you a coffee."
    mc "Thanks."
    scene 13_0106 with dissolve
    ali "[mc]... Are we okay?"
    ali "I feel like you've been avoiding me."
    scene 13_0107 with dissolve
    mc "Why would I be avoiding you??"
    ali "I don't know, but I've hardly seen you in the last few days."
    mc "We're fine, Alison.\nI've just been really busy."
    scene 13_0108 with dissolve
    ali "Busy? Doing what?"
    mc "Traveling, mostly."
    if not Alison.Has("Knows") and not Alison.Has("KnowsAlt"):
        ali "You're still helping that old man out with his deliveries?"
        scene 13_0109 with dissolve
        mc "Uh, yeah, but that's not all..."
    else:
        ali "Traveling where??"
        ali "I hate you working for those guys, but I thought it was here, in Springhaven?"
        scene 13_0109 with dissolve
        mc "It is.\nThat's not why I've been on the road."
    if not Nettie.isActive():
        mc "I went back to Cedar Grove to try to apologize to Nettie again. Didn't get to see her, though."
    else:
        mc "Nettie needed my help with something, so I was down in Cedar Grove."
    mc "And I'm visiting Millie as much as possible, too."
    ali "I can understand that."
    scene 13_0110 with dissolve
    ali "How did she take the news about Cara?"
    scene 13_0111 with dissolve
    if oakhill_ch>3:
        mc "Good. She's happy to have a sister!"
        ali "And... Violet?"
        scene 13_0112 with dissolve
        mc "Funny story... She already knew!"
        mc "Apparently, I'd told her years ago.\nJust didn't remember 'cause I was drunk."
        scene 13_0113 with dissolve
        ali "Oh!"
        ali "That explains a lot."
        mc "It does?"
        ali "Yeah."
        scene 13_0114 with dissolve
        ali "I always knew I'd done {i}something{/i} to upset her, which is why we stopped being friends. Never knew what, though."
        scene 13_0109 with dissolve
        mc "Ahh, right... No, that wasn't it, and it wasn't anything {b}you{/b} did."
        mc "It wasn't {b}you{/b} she was upset with, Alison. It was Pete."
        scene 13_0115 with dissolve
        mc "He tried it on with her a couple of times, so she avoided him as much as she could."
        mc "I only recently found out myself."
        scene 13_0116 with dissolve
        call Emotion (ali, "Sigh", "Why am I not surprised?")
        ali "I should've known."
        ali "I was always tempted to reach out to her, but was worried I'd make things worse."
        scene 13_0117 with dissolve
        mc "You should give her a call!\nI bet she'd love to hear from you."
        ali "You really think so?"
        scene 13_0118 with dissolve
        ali "Yeah, maybe I will!"
        $ Alison.Add("CV")
    else:
        mc "I haven't told her yet."
        ali "Oh. You really should, [mc]!"
        mc "Yeah, I know. I will."
    scene 13_0119 with dissolve
    mc "I'd better make a move."
    ali "Will you be back later?"
    scene 13_0120 with dissolve
    mc "Yeah, should be."
    if Alison.isActive():
        scene 13_0122 with dissolve
        ali "Great. Perhaps we can spend a little {i}quality{/i} time together?"
        scene 13_0123 with dissolve
        mc "Absolutely."
        scene 13_0124 with dissolve
        ali "[whi]Mmh."
        scene 13_0125 with dissolve
        ali "[whi]..Mmmhh.."
        scene 13_0126 with dissolve
    else:
        scene 13_0121 with dissolve
    ali "Bye."
    mc "See ya."
    jump Springhaven_05_VisitSue
return

label Springhaven_05_VisitSue:
    scene 13_0127 with Fade(2, 3, 2)
    scene 13_0128 with dis1
    scene 13_0129 with dis1
    scene 13_0130 with dissolve
    mct "What the hell?"
    scene 13_0131 with dis1
    scene 13_0132 with dis1
    scene 13_0133 with dissolve
    mct "The door's been smashed in!"
    scene 13_0134 with dis1
    call AutoA
    scene 13_0135 with dis1
    $ apause()
    scene 13_0136 with dis1
    $ apause()
    scene 13_0137 with dis1
    $ apause()
    call AutoA (False)
    mct "... He's armed."
    show screen WlkGuide(wkg006)              
    menu:
        "Stealth":
            hide screen WlkGuide 
        "Attack":
            hide screen WlkGuide
            jump Springhaven_05_VisitSueAttack
    scene 13_0219 with dissolve
    $ apause()
    scene 13_0220 with dis1
    zac "Place is empty, Boss. No one else here."
    scene 13_0221 with dis1
    scene 13_0222 with dis1
    scene 13_0223 with dissolve
    sue "As I said, she is not here."
    $ aa=""
    if MiyukaSpringhaven:
        $ aa="a"
    show expression "13_0224" + aa with dissolve
    ant "When did she last contact you?"
    sue "There has been {b}no{/b} contact between us ever since you forbade it."
    sue "I'm positive you're already aware of that fact."
    scene 13_0225 with dissolve
    sue "Melissa isn't dumb.\nShe knows {b}this{/b} would be the first place you'd come to look for her."
    ant "I know. But I still had to be sure."
    scene 13_0226 with dissolve
    ant "Fuckin' Harry.\nDid {i}you{/i} know they were dating?"
    sue "No. I wasn't aware she even liked him."
    ant "They did a good job hiding it.\nWhen I find him..."
    scene 13_0227 with dissolve
    cra "Boss, I just got a message..."
    ant "{b}Did you just fuckin' interrupt me??" with hpunch
    scene 13_0228 with dissolve
    cra "S-Sorry, Boss!"
    ant "Well??"
    cra "[whi]Huh?"
    scene 13_0229 with dissolve
    ant "{b}What did the fuckin' message say??" with hpunch
    cra "Uhh... H-Harry was seen at the t-train station w-with a girl, the day they ran."
    show expression "13_0230" + aa with dissolve
    ant "Do we have anyone at the station?"
    zac "No, sorry Boss."
    scene 13_0231 with dissolve
    ant "They could have security footage showing which train they caught.\nWe need to get back."
    scene 13_0232 with dissolve
    ant "If she contacts you, you'd better fuckin' tell me."
    sue "Of course."
    scene 13_0233 with dissolve
    ant "And if I find out you {b}were{/b} involved in this... You know what happens next."
    sue "I do."
    show expression "13_0234" + aa with dissolve
    show expression "13_0235" + aa with dis1
    show expression "13_0236" + aa with dis1
    ant "Come on, boys."
    show expression "13_0237" + aa with dis1
    call AutoA
    scene 13_0238 with dis1
    $ apause()
    scene 13_0239 with dis1
    $ apause()
    scene 13_0240 with dissolve
    $ apause()
    scene 13_0241 with dissolve
    $ apause()
    scene 13_0242 with dissolve
    $ apause()
    scene 13_0243 with dissolve
    $ apause()
    scene 13_0244 with dissolve
    $ apause()
    scene 13_0245 with dissolve
    $ apause()
    scene 13_0246 with dissolve
    $ apause()
    scene 13_0247 with fade1
    $ apause()
    scene 13_0248 with fade1
    $ apause()
    call AutoA (False)
    show expression "13_0249" + aa with dissolve
    mc "Everyone okay?"
    show expression "13_0250" + aa with dissolve
    sue "Yes."
    sue "A visit from Anton. Quite expected."
    show expression "13_0251" + aa with dissolve
    mc "Yeah, I caught the end of it. Thought it best if I stayed hidden."
    show expression "13_0252" + aa with dissolve
    sue "A wise decision.\nProvoking him further would only exacerbate the situation."
    show expression "13_0253" + aa with dissolve
    if MiyukaSpringhaven:
        sue "Girls, you are excused."
    else:
        sue "Kiyomi, you are excused."
    show expression "13_0254" + aa with dis1
    jump Springhaven_05_SueConvo
return

label Springhaven_05_VisitSueAttack:
    $ Plr.Add("ATK")
    scene 13_0138 with dissolve
    scene 13_0139 with dis1
    scene 13_0140 with vpunch
    scene 13_0141 with dissolve
    call Emotion (zac, "Choking")
    mc "[whi]Drop the gun or I snap your fuckin' neck."
    scene 13_0142 with dissolve
    call Emotion (zac, "Choking")
    scene 13_0143 with dissolve
    scene 13_0144 with dissolve
    call Emotion (zac, "Coughing")
    mc "[whi]On your feet."
    scene 13_0145 with dis1
    mc "[whi]Move."
    scene 13_0146 with dis1
    scene 13_0147 with dis1
    scene 13_0148 with dis1
    scene 13_0149 with dissolve
    mc "No you don't."
    mc "Put it down on the desk."
    scene 13_0150 with dissolve
    jt "Uhh... Boss?"
    ant "Looks like he means business! I'd listen to him if I were you."
    scene 13_0151 with dissolve
    mc "Nice and easy."
    $ aa=""
    if MiyukaSpringhaven:
        $ aa="a"
    show expression "13_0152" + aa with dissolve
    mc "Slide it over to Sue."
    show expression "13_0153" + aa with dissolve
    show expression "13_0154" + aa with dissolve
    show expression "13_0155" + aa with dissolve
    mc "Back up."
    show expression "13_0156" + aa with dissolve
    mc "You too."
    show expression "13_0157" + aa with dissolve
    mc "Far corner, on your knees."
    if MiyukaSpringhaven:
        scene 13_0158a with dissolve
        mc "Miyuka, Kiyomi... Are you okay?"
        mi "Yes."
        ki "I'm okay."
    else:
        scene 13_0158 with dissolve
        mc "Miyuka... Are you okay?"
        ki "Yes."
    mc "Sue?"
    show expression "13_0159" + aa with dissolve
    sue "Thank you, [mc], but you can lower the weapon."
    sue "This was a misjudgment on Anton's part."
    show expression "13_0160" + aa with dissolve
    show expression "13_0161" + aa with dissolve
    show expression "13_0162" + aa with dissolve
    ki "AAAHHH!{w=0.5}{nw}"
    if MiyukaSpringhaven:
        mi "KIYOMI!!{w=0.5}{nw}"
    cra "D-DROP YOUR G-GUN OR I'LL K-K-KILL HER!!"
    scene 13_0163 with dissolve
    ant "Hah! Now what, Hero?"
    menu:
        "Take the shot":
            $ CraigD = True
            pause 0.5
            play sound("gun.mp3")
            scene black with Fade(.1, 0.0, .5, color="#fff")
            pause 0.5
            scene 13_0164 with dissolve
            scene 13_0165 with dissolve
            scene 13_0166 with dissolve
            scene 13_0167 with dissolve
            scene 13_0168 with dissolve
            if MiyukaSpringhaven:
                mi "KIYOMI!!{w=0.5}{nw}"
            call Emotion (sue, "GASP")
            scene 13_0169 with dissolve
            scene 13_0170 with dissolve
            mc "Time for you to leave."
            show expression "13_0171" + aa with dissolve
            ant "If she contacts you, you'd better fuckin' tell me."
            sue "Of course."
            show expression "13_0172" + aa with dissolve
            ant "You two clowns can get up now."
            scene 13_0173 with dissolve
            ant "Until next time, Hero."
            show expression "13_0174" + aa with dissolve
            show expression "13_0175" + aa with dis1
            show expression "13_0176" + aa with dis1
            scene 13_0177 with dis1
            pause 0.5
            show expression "13_0178" + aa with dissolve
            ant "You made that mess. It's yours to clean up."
            show expression "13_0179" + aa with dis1
            pause 0.5
            show expression "13_0180" + aa with dissolve
            mc "Are you okay, Kiyomi?"
            show expression "13_0181" + aa with dissolve
            ki "[whi]Yes."
            sue "That was unwarranted."
            show expression "13_0182" + aa with dissolve
            mc "Are you kidding me??\nHe had a goddamn knife to her throat!"
            sue "He was a frightened little boy. He wouldn't have used it."
            mc "He was a guy who might do anything to impress his boss!"
            mc "You don't {b}know{/b} he wouldn't have hurt her, neither do I..."
            scene 13_0183 with dissolve
            mc "I wasn't willing to take the chance... I {b}had{/b} to take the shot."
            show expression "13_0184" + aa with dissolve
            sue "I'll make sure the weapon is disposed of, along with the body."
            show expression "13_0185" + aa with dis1
            show expression "13_0186" + aa with dis1
            sue "What happened here today will never leave this room. You have my word."
            show expression "13_0187" + aa with dissolve
            if MiyukaSpringhaven:
                sue "Girls, you are excused."
            else:
                sue "Kiyomi, you are excused."
            show expression "13_0188" + aa with dis1
            show expression "13_0189" + aa with dis1
            show expression "13_0190" + aa with dis1
            show expression "13_0191" + aa with dis1
        "Lower the gun":
            scene 13_0193 with dissolve
            mc "Okay, okay.... Take it easy!"
            scene 13_0194 with dissolve
            scene 13_0195 with dis1
            ant "[lol]"
            scene 13_0196 with dissolve
            mc "It's down. Let her go."
            show expression "13_0197" + aa with dissolve
            ant "Pussy."
            show expression "13_0198" + aa with dissolve
            ant "I would've shot him."
            play sound "hb.mp3"
            show expression "13_0199" + aa with hpunch
            mc "NGGHHH!{w=0.5}{nw}"
            show expression "13_0200" + aa with dissolve
            call Emotion (mc, "Coughing")
            show expression "13_0201" + aa with dissolve
            ant "If she contacts you, you'd better fuckin' tell me."
            sue "Of course."
            show expression "13_0202" + aa with dissolve
            show expression "13_0203" + aa with dis1
            show expression "13_0204" + aa with dis1
            show expression "13_0205" + aa with dis1
            ant "I don't like you. You're starting to annoy me."
            show expression "13_0206" + aa with dis1
            ant "So..."
            ant "Do I deal with you now? Or later?"
            show expression "13_0207" + aa with dissolve
            jt "Boss, we don't have time..."
            scene 13_0208 with dissolve
            ant "JT's right! We have somewhere else to be."
            ant "Later then..."
            $ Jt_name="JT"
            scene 13_0209 with dissolve
            ant "'cause I'm gonna take my fuckin' time with you, Hero."
            mc "When I kill you, I'm using your axe to do it."
            scene 13_0210 with dissolve
            ant "[lol] Where did you find this clown, Sue?"
            show expression "13_0211" + aa with dissolve
            ant "Come on, boys."
            scene 13_0212 with dis1
            pause 0.5
            scene 13_0213 with dis1
            zac "Good work, kid!"
            scene 13_0214 with dis1
            scene 13_0215 with dissolve
            sue "A lesson learned, I hope. {b}Never{/b} provoke him."
            scene 13_0216 with dissolve
            mc "Are you okay, Kiyomi?\nI'm sorry, I didn't know he was in there."
            ki "Yes, I'm fine."
            show expression "13_0217" + aa with dissolve
            if MiyukaSpringhaven:
                sue "Girls, you are excused."
            else:
                sue "Kiyomi, you are excused."
            show expression "13_0218" + aa with dis1
    sue "Be seated."
    jump Springhaven_05_SueConvo
return

label Springhaven_05_SueConvo:
    scene 13_0192 with fade1
    sue "She's safe?"
    mc "Yeah."
    scene 13_0255 with dissolve
    sue "I wasn't expecting you to act so swiftly."
    mc "Neither was I, but with everyone called to Cedar Grove... it was the perfect time to strike."
    sue "Did she cooperate?"
    mc "Why {i}wouldn't{/i} she?"
    scene 13_0256 with dissolve
    mc "Ohh, right. Because she was never in any danger, you mean?"
    mc "Because she doesn't want to come back here?"
    mc "Because she was being protected from {b}you{/b} by her father?"
    scene 13_0257 with dissolve
    sue "{b}MICHAEL{/b} IS HER FATHER!"
    sue "Anton was merely the sperm donor. Nothing more!"
    scene 13_0258 with dissolve
    sue "I was incredibly intoxicated. It was a terrible mistake to have intercourse with him."
    sue "But my biggest error turned into my most precious..."
    scene 13_0259 with dissolve
    mc "Possession?"
    sue "Blessing!"
    sue "Anton is the one who sees her as a possession.\nAmmunition to use against me."
    mc "Why didn't you tell me about him?"
    sue "He was irrelevant."
    scene 13_0260 with dissolve
    mc "Bullshit! He was {b}very{/b} goddamn relevant!"
    scene 13_0261 with dissolve
    sue "Had I told you, would you have still agreed to assist in her rescue?"
    sue "I knew you would eventually find out about him.\nBut, by then, I was hoping you would see Melissa really was an innocent victim."
    scene 13_0262 with dissolve
    sue "I manipulated you, yes, and I offer my sincerest apologies."
    sue "But, wouldn't you honestly do {b}everything in your power{/b} to help your child?"
    scene 13_0263 with dissolve
    mc "[whi]Yeah, I would."
    scene 13_0259 with dissolve
    mc "So what's next?"
    mc "What's your plan?\nYou knew Anton would come looking for her; she couldn't stay here even if she {i}wanted{/i} to come back."
    scene 13_0264 with dissolve
    sue "Disappear."
    sue "Board a plane with Melissa, and leave the country. Never to return."
    scene 13_0265 with dissolve
    mc "You think running is that easy?"
    sue "No, but it's the only viable option."
    scene 13_0266 with dissolve
    sue "Once the dust has settled, I will need you to travel to Millfork."
    sue "We occasionally use the services of a pilot based there."
    scene 13_0267 with dissolve
    mc "Let me guess - a smuggler?"
    sue "If you insist on such a crude title, then, yes."
    sue "You will need to convince her to assist us."
    mc "How the hell am I supposed to do that?"
    scene 13_0268 with dissolve
    sue "I have something she wants. She will not object."
    sue "I cannot risk any contact with her at this delicate time.\nI must go about my business as I normally would."
    sue "{b}You{/b} must also be careful.\nAnton is yet to be convinced that I was not involved in Melissa's disappearance."
    scene 13_0259 with dissolve
    sue "I will forward you her location."
    sue "Once everything has been arranged, you will transport Melissa from her current location directly to the plane, where I shall be waiting."
    mc "Doesn't Melissa have a say in this?"
    scene 13_0262 with dissolve
    sue "She desires a normal life."
    sue "To have friends, lovers, and maybe, one day, children of her own.\nThings she can {b}never{/b} have while she remains within Anton's grasp."
    scene 13_0269 with dissolve
    sue "All this effort is for her benefit - not mine."
    sue "My priorities have been misplaced for far too long. I'm trying to make amends."
    show expression ("13_0270a" if CraigD else "13_0270") with dissolve
    sue "I congratulate you on your work so far. Once our business is concluded, you shall be rewarded for your efforts."
    sue "This meeting is over. You may leave."
    if CraigD:
        scene 13_0271 with dissolve
        sue "I must call our cleaner before it stains my floor."
    scene 13_0272 with dissolve
    scene 13_0273 with dis1
    if CraigD:
        call Springhaven_05_KiyomiConvo
    scene 13_0286 with fade
    $ apause()
    scene 13_0287 with fade
    mc cell "Hey, it's me."
    mc cell "So far, so good.\nSue just had a visit from Anton, looks like he bought the story."
    blz cell "Great."
    mc cell "Sitrep?"
    blz cell "All good here, Boss."
    scene 13_0288 with dissolve
    if Plr.Has("ATK"):
        mc cell "Let's hope it stays that way."
    else:
        mc cell "We may have a wrinkle..."
        mc cell "Harry was spotted at the train station with a girl."
        mc cell "Anton's on his way there to check for security cameras."
        blz cell "Understood. I'm on it."
        mc cell "Okay. See you soon."
    blz cell "Roger that."
    blz cell "Oh, Boss... Hold on a sec..."
    mc cell "..."
    dawn cell "[mc]? Did you go see Sarah?"
    scene 13_0289 with dissolve
    mc cell "Uhh, not yet. It's only my to-do list, don't worry."
    dawn cell "Okay, please don't forget!"
    mc cell "I won't."
    scene 13_0290 with dissolve
    mct "Damn, I'd totally forgotten about that!"
    if Sarah.Has("Cell"):
        scene 13_0291 with dissolve
        $ apause()
        scene 13_0289 with dissolve
        mct "Come on, Sarah, pick up."
        mct "Damn it."
        scene 13_0290 with dissolve
        $ apause()
    scene 13_0291 with dissolve
    mc cell "Hey. We need to meet."
    aly cell "I'm at work for another hour. Come by my place later?"
    mc cell "Okay."
    scene 13_0292 with dissolve
    if BillSick:
        $ apause()
        scene 13_0293 with dissolve
        mc cell "Hi Mary. How's Bill?"
        mar cell "Hello [mc]!\nHe's back home recovering, driving me up the wall!"
        mar cell "He keeps complaining that he wants to get back to work, but I think he's secretly enjoying the rest."
        scene 13_0291 with dissolve
        mc cell "That's good to hear. I'm glad he's out of the hospital."
        mc cell "Think he'd be up for a visitor?"
        mar cell "Heck yeah! You're always welcome!"
        mc cell "Not sure he feels the same way."
        scene 13_0294 with dissolve
        mc cell "Just do me a favor... make sure his shotgun is out of reach."
        mar cell "[lol]"
        mar cell "Don't worry! He don't seem mad with us anymore."
        scene 13_0291 with dissolve
        mc cell "He has no reason to be mad with you; it's me he wanted to shoot!"
        mar cell "You'll be okay, I'll protect you!"
        mc cell "Heh. Okay, I'll see you later."
        mar cell "Bye!"
        scene 13_0292 with dissolve
    mct "Got some time to kill..."
    if Sarah.Has("Cell"):
        mct "Guess I could swing by Sarah's place."
    else:
        mct "Better go see Dawn's friend before I forget again!"
    scene 13_0295 with dis1
    scene 13_0296 with dis1
    scene 13_0297 with dis1
    scene 13_0298 with dis1
    jump Springhaven_05_VisitSarah
return

label Springhaven_05_KiyomiConvo:
    scene 13_0274 with dissolve
    ki "[mc]! Wait."
    scene 13_0275 with dissolve
    mc "You okay? I'm sorry you had to go through that."
    scene 13_0276 with dissolve
    ki "Thank you."
    scene 13_0277 with dissolve
    ki "Even though I was so scared, somehow I... I just knew you wouldn't let anything bad happen to me."
    scene 13_0278 with dissolve
    ki "I owe you my life."
    mc "You owe me {b}nothing{/b}, Kiyomi."
    scene 13_0279 with dissolve
    ki "I don't know {i}why{/i} you're here, working for her..."
    ki "But my trust and loyalty are {b}yours{/b}."
    scene 13_0280 with dissolve
    ki "I belong to you now."
    ki "Anything you ask of me, I'll do without hesitation."
    $ tCh=False
    if EzModeActive:
        call EzModeAsk ("Kiyomi")
        if _return:
            $ Kiyomi.Add("EZ")
            $ tCh=True
            mc "{i}Anything{i}?"
        else:
            mc "That's not necessary."
    if not EzModeActive:
        menu:
            "[wk_y]Anything?":
                $ tCh=True
            "That's not necessary":
                pass
    if tCh:
        $ Kiyomi.Activate()
        $ Kiyomi.L=10
        scene 13_0281 with dissolve
        ki "{i}Anything{/i}."
        scene 13_0283 with dissolve
        mc "I'll keep that in mind."
        ki "Thank you."
        scene 13_0284 with dissolve
        ki "She called for me. I have to go."
        mc "Okay."
    else:
        scene 13_0282 with dissolve
        mc "Just be careful.\nI doubt that's the last we'll see of Anton and his friends."
        ki "Okay."
    scene 13_0285 with fade
    $ apause()
return

label Springhaven_05_VisitSarah:
    scene 13_0526 with Fade(2, 3, 2)
    scene 13_0527 with dis1
    scene 13_0528 with dis1
    scene 13_0529 with dis1
    scene 13_0530 with dis1
    scene 13_0531 with dis1
    if Plr.Has("couch") or Plr.Has("NoSofa"):
        mct "Hmm. This block seems... familiar."
    elif Sarah.isActive():
        mct "She's probably at work, got nothing else to do, though."
    else:
        mct "This is the address Dawn gave me..."
    scene 13_0532 with dis1
    $ apause()
    scene 13_0533 with dissolve
    $ apause()
    scene 13_0534 with dis1
    play sound "knock.mp3"
    scene 13_0535 with dis1
    scene 13_0536 with dis1
    $ apause(2)
    scene 13_0537 with dis1
    mct "I'll come back later."
    scene 13_0532 with fade1
    $ apause()
    scene 13_0538 with dis1
    mct "Guess I'll hang out at the cafe until Alysha's finished work."
    scene 13_0539 with dis1
    scene 13_0540 with dis1
    scene 13_0541 with dis1
    scene 13_0542 with dis1
    scene 13_0526 with dis1
    jump Springhaven_05_VisitCafe
return

label Springhaven_05_VisitCafe:
    scene 13_0832 with Fade(2, 3, 2)
    pause 0.5
    scene 13_0833 with fade
    gab "You're not very good at this, are you?"
    mc "Sorry?"
    scene 13_0834 with dissolve
    gab "You're supposed to be here tomorrow, not today."
    mc "Uhh, okay... Why??"
    scene 13_0835 with dissolve
    gab "Wow.\nLike I said - not very good."
    mc "Okay, you've lost me... {i}Why{/i} am I supposed to be here tomorrow?"
    scene 13_0836 with dissolve
    gab "Seriously??"
    mc "Yeah."
    scene 13_0837 with dissolve
    gab "Our payment's due! {b}TOMORROW{/b}."
    mc "Damn, it is? Already??"
    if Gabby.isActive() and Gabby.hasScore(2):
        mc "I just came for a coffee and to see my favorite barista!"
    else:
        mc "I just came for a coffee."
    scene 13_0838 with dissolve
    mc "Gabby, I'm not here to try and intimidate you, I promise!"
    mc "Just want a coffee, that's all."
    gab "Uhh, okay... Good.\nMel's not here right now, and she's the one who deals with the cash."
    scene 13_0839 with dissolve
    gab "Take a seat. I'll bring it over."
    mc "Thanks."
    scene 13_0840 with fade1
    pause
    scene 13_0841 with fade1
    gab "You okay?"
    mc "[whi]Hmm?"
    mc "Err, yeah..."
    scene 13_0842 with dissolve
    mc "You're right about me, Gabby... I'm {i}not{/i} very good at this... job.\nI hate it."
    gab "So why do it?\nThere are other jobs out there."
    scene 13_0843 with dissolve
    mc "No choice... for now."
    mc "Sorry if I scared you."
    gab "You didn't."
    scene 13_0844 with dissolve
    gab "The other men did. All the time."
    scene 13_0845 with dissolve
    gab "But you? You're {b}nothing{/b} like them."
    gab "They got off on our fear.\nThey enjoyed it."
    gab "You seem decent.\nDon't turn into them."
    scene 13_0846 with dissolve
    gab "You might hate your job, but the truth is, people like me, like Mel..."
    gab "We can give you a hard time, but we're grateful that it's {b}you{/b}, and not those assholes."
    scene 13_0847 with dissolve
    mc "Thanks, Gabby."
    mc "Think I needed to hear that more than I knew."
    scene 13_0848 with dissolve
    gab "You're welcome."
    scene 13_0849 with dissolve
    gab "You still suck at it, though."
    mc "Heh. Yeah, I do."
    scene 13_0850 with Fade(1, 2, 1)
    pause
    scene 13_0851 with Fade(1, 2, 1)
    pause
    scene 13_0852 with Fade(1, 2, 1)
    pause
    scene 13_0853 with Fade(1, 2, 1)
    gab "Get you anything else?"
    mc "Uh, no thanks... I should get going."
    if Melanie.isActive() and Melanie.isSexual():
        gab "Oh, I thought you were waiting for Mel to get back."
        mc "No.\nActually, I was waiting for a friend to finish work."
        scene 13_0854 with dissolve
        gab "So I cleaned up the office for nothing?"
        mc "Office?\nOh, you mean the store room?"
        gab "Nope.\nIt's an office now, got a desk n'everythin'!"
        scene 13_0855 with dissolve
        mc "Oh, then I stand corrected!"
        gab "Don't know why she wants a desk."
        gab "I told her - the way she is with you, she'd make better use of a bed in there!"
        scene 13_0856 with dissolve
        gab "Want to know what she said?"
        mc "Uh... okay."
        scene 13_0857 with dissolve
        gab "{i}He can bend me over the desk to fuck me, if that's what he wants to do{/i}."
        if Gabby.Has("askMel"):
            scene 13_0858 with dissolve
            gab "If you're gonna do that, I'd better be there to watch!"
            gab "You promised you'd ask her."
            mc "I will."
            scene 13_0859 with dissolve
            gab "You'd better!"
            gab "Even just thinkin' about it is making my nipples hard."
            if Gabby.Has("Look"):
                gab "And now you're tryin' your best {i}not{/i} to look down, aren't you?"
                gab "Oh, wait... Didn't I say because you let me watch, I'd let you look?"
                scene 13_0860 with dissolve
                gab "I keep my promises."
                gab "Who knows what other promises I might be tempted to make if I were in there with you!"
                scene 13_0861 with dissolve
                mc "Can't wait to find out!"
                scene 13_0862 with dissolve
                gab "Neither can I."
            else:
                scene 13_0862 with dissolve
                gab "And now you're tryin' your best {i}not{/i} to look down, aren't you?"
        else:
            scene 13_0862 with dissolve
            gab "Is that what you want to do, [mc]?"
            gab "Bend my sister over the desk and fuck her?"
            mc "Maybe."
    elif Gabby.isActive():
        gab "I hope you're not waiting for me to make you the same offer my sister gave you."
        mc "No!\nI was just waiting for a friend to finish work."
        gab "Good."
        scene 13_0854 with dissolve
        gab "I'd never put a dick in my mouth for the sake of an extra twenty-four hours!"
        mc "Right."
        scene 13_0855 with dissolve
        mc "Just out of curiosity... what {i}would{/i} it take?"
        scene 13_0856 with dissolve
        gab "Well, I guess that's for you to find out."
        scene 13_0857 with dissolve
        gab "Do you {i}want{/i} to find out, [mc]?"
        mc "Hell yeah."
        scene 13_0858 with dissolve
        gab "Good answer."
        gab "You just made my nipples go hard."
        scene 13_0859 with dissolve
        gab "And now you're fighting {b}not{/b} to look down at my boobs, right?"
        mc "Heh, more than you know."
        gab "You don't have to fight it."
        scene 13_0860 with dissolve
        gab "Go ahead and look."
        mc "[whi]Damn."
        gab "Like what you see?"
        scene 13_0861 with dissolve
        mc "Yeah, very much."
        scene 13_0862 with dissolve
        gab "Good."
    scene 13_0863 with dissolve
    gab "Guess we'll be seeing you tomorrow then."
    mc "Yeah."
    scene 13_0864 with dissolve
    gab "Don't come too early.\nMornings get crazy in here."
    mc "Got it."
    scene 13_0865 with fade
    pause 0.5
    jump Springhaven_05_VisitAlysha
return

label Springhaven_05_VisitAlysha:
    scene 13_0543 with Fade(2,3,2)
    aly "I've been thinking about your Melissa problem..."
    scene 13_0544 with dissolve
    aly "It's too messy."
    aly "Can't you tell Sue you don't want to get involved in a family dispute?"
    scene 13_0545 with dissolve
    mc "Bit late for that. We've already extracted her."
    scene 13_0546 with dissolve
    aly "Holy shit, that was fast!"
    aly "Last time we spoke, you weren't even sure you were gonna go ahead with it!"
    scene 13_0547 with dissolve
    mc "She was left pretty much unguarded for a while, so we took the chance."
    mc "Don't worry. No collateral damage."
    aly "...{i}Yet{/i}."
    scene 13_0548 with dissolve
    aly "What are we doing here, [mc]?"
    aly "This hole we're digging, it keeps getting deeper and deeper."
    scene 13_0549 with dissolve
    aly "We... We need to get out... While we still can."
    aly "I... I can't do this."
    scene 13_0550 with dissolve
    mc "Hey."
    mc "If you want out, then you're out.\nIt's okay, Alysha."
    aly "I don't know what I'm doing, [mc].\nI'm scared I'll fuck up and get us both killed."
    mc "So am I."
    scene 13_0551 with dissolve
    aly "Then we should {b}both{/b} get out!"
    mc "I can't. They won't let me.\nI'm in 'till the end."
    mc "But you? They know nothing of you."
    mc "No one would blame you for walking away."
    scene 13_0552 with dissolve
    aly "I'm so sorry, [mc].\nI should never have dragged you in."
    mc "You didn't!\nI was {i}already{/i} in. You showed me the way out."
    scene 13_0553 with dissolve
    mc "You wanna tell me what happened?"
    aly "What happened?"
    mc "Last time I saw you, you were pretty upbeat about the case, so, yeah - what happened?"
    scene 13_0554 with dissolve
    aly "Nothing {i}happened{/i}."
    aly "I just..."
    aly "Remember when I said Melissa could be a great witness for us?"
    scene 13_0555 with dissolve
    aly "We'd need to place her in a safehouse. Protect her. Interview her."
    aly "I thought about it... who could I go to? Who do I trust at the station to help me with this?"
    aly "Guess how many names I came up with."
    scene 13_0556 with dissolve
    aly "None."
    aly "Not a single goddamn person."
    scene 13_0557 with dissolve
    mc "So we go somewhere else.\nInternal affairs?"
    aly "And how do we know they ain't crooked, too?\nWe have no idea how deep these fuckers are into the whole system!"
    aly "We tell the wrong person what we're up to... We'll both be dead before the day's out."
    aly "But, we can't do this on our own! It's too big!"
    mc "{i}We{/i}?"
    scene 13_0558 with dissolve
    aly "[whi]Yeah..."
    aly "I know I {i}should{/i} walk away..."
    scene 13_0559 with dissolve
    aly "But I can't leave you behind. I refuse."
    aly "I'm in for as long as you're in."
    scene 13_0560 with dissolve
    mc "We're gonna get them, Alysha. Every one of them."
    scene 13_0561 with dissolve
    aly "Fuck. I wish I had your confidence."
    aly "All I see is us - running around like headless chickens, not getting anywhere."
    scene 13_0562 with dissolve
    aly "And it scares the shit out of me."
    scene 13_0563 with dissolve
    aly "Okay... Sorry. Enough of the pity party."
    aly "Tell me what happened with Melissa."
    scene 13_0564 with Fade(2, 3, 2)
    aly "Jesus."
    aly "And you're okay with that?\nLetting this Harry kid run for his life?"
    mc "What choice did I have?"
    scene 13_0565 with dissolve
    mc "We weren't ready. We didn't have a plan.\nBut it was too good an opportunity to let slide."
    mc "By the time I got there, it was already done."
    scene 13_0566 with dissolve
    mc "The kid couldn't have gone back, anyway. Anton would've killed him for losing her."
    mc "Couldn't leave him tied up in the outbuilding. Who knows for how long?"
    scene 13_0567 with dissolve
    mc "And let's not forget - this isn't some innocent kid we're talking about here!"
    mc "He {b}chose{/b} to work for Anton."
    scene 13_0568 with dissolve
    aly "Like you {i}chose{/i} to work for Sue?"
    mc "Fine! What would {b}you{/b} have done, Alysha??"
    mc "Let him leave?\nGive him a map of our exact location to pass on to his boss?"
    mc "Or maybe put a bullet between his eyes?\nThat's one way to get rid of the problem!"
    scene 13_0569 with dissolve
    aly "Jeez! Okay!"
    aly "I'm sorry!\nI wasn't having a go at you!"
    scene 13_0570 with dissolve
    mc "[whi]Fuck."
    scene 13_0571 with dissolve
    mc "Sorry. I didn't mean to snap at you."
    mc "And, no... I'm {b}not{/b} okay with it."
    mc "But with every other option I could come up with, either {i}he{/i} ended up dead, or {i}we{/i} did."
    scene 13_0572 with dissolve
    aly "It might leave a bad taste in the mouth, but you made the right call."
    aly "At least he has a chance. You gave him that."
    scene 13_0573 with dissolve
    aly "What was the reason for ordering everyone down to Cedar Grove?"
    mc "What else? Trouble."
    mc "I ended up down there myself. Met the boss and Anton."
    scene 13_0574 with dissolve
    aly "Why??"
    aly "I was hoping you'd stay off their radar for as long as possible!"
    scene 13_0575 with dissolve
    mc "Boss wanted a meet and greet. Feel me out."
    mc "Don't think he was too impressed, which is what I was aiming for."
    mc "Want him to see me as nothing more than just another grunt, for now."
    scene 13_0564 with dissolve
    aly "And Anton?"
    mc "Yeah, he could be a problem."
    mc "He paid Sue a visit earlier, looking for Melissa."
    mc "He believes that she took off with Harry, but wanted to double-check that Sue wasn't hiding them."
    if Nettie.isActive():
        scene 13_0576 with dissolve
        mc "We could have another potential witness, too."
        aly "Who?"
        mc "Her name's Hayley...."
        scene 13_0577 with Fade(2, 3, 2)
        aly "Jeez! Sounds like she'd be a goldmine of information!"
        aly "You get that I'm just a city cop, though... right?"
        aly "Cedar Grove isn't Springhaven.\nI have no authority there."
        mc "Yeah.\nAnd from what I can gather, they have even more cops in their pocket down there than they do here."
        aly "Great."
    scene 13_0578 with fade1
    aly "I'm not gonna let you down, [mc]."
    scene 13_0579 with dissolve
    aly "I'll find {i}someone{/i} who can help us."
    aly "All the work we've put in, I won't let it go to waste."
    scene 13_0580 with dissolve
    mc "I know. Just be careful."
    scene 13_0581 with dissolve
    mc "Trust your gut.\nOnly confide in someone when you're absolutely sure about them."
    scene 13_0582 with dissolve
    aly "You be careful out there, too, partner."
    scene 13_0583 with dissolve
    aly "Thanks for coming, [mc], and sorry for the freakout."
    if Alysha.L==1:
        scene 13_0584 with dissolve
        mc "Forget about it."
        scene 13_0585 with dissolve
        aly "Keep in touch, yeah?"
        mc "Yeah."
        scene 13_0586 with dissolve
        aly "[whi]Mmhh."
        scene 13_0587 with dissolve
        aly "[whi]..Mmmhh.."
        scene 13_0588 with dissolve
        scene 13_0589 with dis1
        scene 13_0590 with dis1
        scene 13_0591 with vpunch
        aly "[whi]Mmhh."
        scene 13_0592 with dis1
        scene 13_0593 with dis1
        aly "[whi]Fuck."
        aly "[whi][mc]... stop."
        scene 13_0594 with dissolve
        mc "[whi]Yeah, I know."
        aly "[whi]Sorry."
        scene 13_0595 with dissolve
        aly "[whi]Damn.\nYou {b}know{/b} I want to."
        aly "[whi]It's so fuckin' hard."
        mc "[whi]You can feel it, huh? Sorry."
        scene 13_0596 with dissolve
        aly "What?! No! I meant--"
        scene 13_0597 with dissolve
        aly "[lol]"
        scene 13_0598 with dissolve
        aly "Always the smart-ass."
        scene 13_0599 with dissolve
        aly "Damn, you're good! When did you unzip my top??"
        mc "Wanted to see what I had to look forward to."
        scene 13_0600 with dissolve
        aly "They'll be right here..."
        scene 13_0601 with dissolve
        aly "... waiting for you, Baby."
        scene 13_0602 with dissolve
        aly "Now get outta here, soldier."
        mc "Yes, Ma'am."
        scene 13_0603 with dissolve
        aly "See you soon, [mc]."
        scene 13_0604 with dissolve
        mc "See ya."
    else:
        mc "Forget about it."
        scene 13_0603 with dissolve
        aly "See you soon, [mc]."
        mc "See ya."
    scene 13_0605 with fade1
    scene 13_0606 with dis1
    mct "Last few days have been crazy."
    scene 13_0607 with dissolve
    mct "Go home, shower, and relax for a while."
    if BillSick:
        mct "Damn... Should go see Bill first. Can't keep putting it off."
        call Springhaven_05_VisitMary
    jump Springhaven_05_ReturnHome
return

label Springhaven_05_VisitMary:
    scene 13_0608 with fade1
    scene 13_0609 with dis1
    scene 13_0610 with dis1
    mct "Hope Mary hid his damn shotgun!"
    scene 13_0611 with dis1
    scene 13_0612 with dis1
    play sound "knock.mp3"
    scene 13_0613 with dis1
    scene 13_0614 with dissolve
    scene 13_0615 with dissolve
    scene 13_0616 with dissolve
    mar "You made it!"
    mc "Hi Mary."
    scene 13_0617 with dissolve
    mc "How is he?"
    scene 13_0618 with dissolve
    mar "Grumpy, as usual!"
    scene 13_0619 with dissolve
    mc "Did you tell him I was coming?"
    mar "Sure did."
    scene 13_0620 with dissolve
    mc "Did he ask for his gun?"
    mar "You're so funny."
    scene 13_0621 with dissolve
    mc "You get that he threatened to shoot me, right?"
    scene 13_0622 with dissolve
    mar "He'd never shoot you! Not {i}really{/i}!"
    mar "He was upset, that's all."
    scene 13_0623 with dissolve
    mc "Yeah, can't blame him for that."
    scene 13_0624 with dissolve
    mar "There ain't gonna be any arguing, is there?"
    mar "You be nice!\nI don't want him back in the hospital!"
    mc "I'm here to apologize, not fight."
    scene 13_0625 with dissolve
    scene 13_0626 with dis1
    $ dia = "I've missed you" + (", Daddy." if persistent.MaryDaddy else ".")
    mar "[dia]"
    scene 13_0627 with dissolve
    mar "I didn't mean to fall asleep in your bed, I'm sorry."
    mc "I got to hold you and cuddle you all through the night. Don't be sorry."
    scene 13_0628 with dissolve
    mar "It was the best night I've ever had."
    scene 13_0629 with dissolve
    mc "So, where's your mom?\nDidn't you say she was helping you take care of Bill?"
    mar "Yeah, she was until Pops sent her home!\nThey don't get on too well."
    mc "You're looking after him alone?"
    mar "Mhh-mhh."
    scene 13_0630 with dissolve
    mc "That's gotta be a lot of work."
    mar "He's always taken care of me; now it's my turn to take care of him."
    mc "You call me if there's {b}anything{/b} I can do to help, okay?"
    mar "Okay."
    scene 13_0631 with dissolve
    mar "Can we have a big kiss now?"
    mc "Uhh... Mary... We'd better not."
    scene 13_0632 with dissolve
    mar "Why?"
    mc "I need to talk with Bill first."
    mar "Okay."
    scene 13_0633 with dis1
    mar "Pops, [mc]'s here to see you."
    bill "[whi]Send him in, Pumpkin."
    scene 13_0634 with dissolve
    mar "[whi]No yellin'!"
    scene 13_0635 with dissolve
    mc "Bill."
    scene 13_0636 with dissolve
    bill "[whi]Son."
    mar "I'll be in my room."
    scene 13_0637 with dissolve
    mc "How you doin'?"
    bill "Been better."
    scene 13_0638 with dissolve
    mc "I'm sorry, Bill."
    mc "What I did was wrong, and it'll never happen again."
    mc "We just got caught up in the moment..."
    scene 13_0639 with dissolve
    bill "She thinks she's in love with you, you know."
    mc "Yeah. I'll talk to her."
    mc "Try to get her to understand..."
    scene 13_0640 with dissolve
    bill "Understand what?"
    bill "That she was just a bit of fun for you?\nSomething to keep you warm in bed?\nSomething you can toss away when you're done??"
    scene 13_0641 with dissolve
    mc "No!"
    mc "It wasn't like that, Bill, I swear!\nI like Mary! I like her a lot!"
    mc "She's so sweet, and kind, and--"
    bill "Young?"
    scene 13_0642 with dissolve
    mc "[whi]Yeah, I know."
    scene 13_0643 with dissolve
    bill "She told me that it was her who did the chasin'... is that right?"
    scene 13_0644 with dissolve
    mc "Doesn't matter who did what. I should've stopped it."
    scene 13_0645 with dissolve
    bill "Sit down, Son."
    scene 13_0646 with dissolve
    bill "Mary's old enough to make her own decisions."
    bill "Truth is... I probably encouraged her - both of you - to get closer."
    bill "... Just didn't expect it to happen so fast."
    bill "First time you stayed, I heard her sneakin' around.\nCould've stopped her, but didn't."
    bill "But when I saw her in your bed... I figured you were just takin' advantage."
    scene 13_0647 with dissolve
    bill "See... Mary's smart, but she ain't... {i}life smart{/i}."
    bill "I worry who will take care of her when I'm gone."
    scene 13_0648 with dissolve
    bill "It's my own damn fault.\nI tried to protect her, but I've sheltered her from life!"
    bill "She don't know how the real world works!"
    scene 13_0649 with dissolve
    bill "The moment she saw you, I could tell she liked you."
    bill "Didn't take much to see you liked her back."
    scene 13_0650 with dissolve
    bill "I could've said summat, but didn't."
    bill "You're a decent guy. A soldier, just like my boy."
    bill "... I {b}need{/b} to know she'll be okay."
    scene 13_0651 with dissolve
    mc "Damn."
    mc "Does Mary know?"
    bill "... Know what?"
    mc "That you're dying."
    scene 13_0652 with dissolve
    bill "..."
    scene 13_0653 with dissolve
    bill "She knows I'm sick... My heart..."
    bill "But, she don't know how serious."
    scene 13_0654 with dissolve
    mc "Damn, Bill. I'm sorry."
    mc "Did they tell you how long?"
    bill "Nah. They don't know."
    bill "Could be a month, could be a year."
    mc "Fuck."
    scene 13_0655 with dissolve
    mc "Why the hell are you still workin' so hard??\nShouldn't you be taking it easy?"
    bill "Take a look at my medical bills!\nThey'll frighten the pants off of ya!"
    bill "I can't leave Mary drowning in debt! They'll take this place!"
    scene 13_0656 with dissolve
    bill "That reminds me... Thank you."
    bill "Sue told me what you did. You saved my contract."
    bill "If I'd lost that... I don't know what I would've done!"
    scene 13_0657 with dissolve
    mc "Damn, Bill, I'm the reason you couldn't make that delivery yourself! It was the least I could do."
    bill "Thing is, I need you to do it again."
    bill "Sue's naggin' at me to get back to work.\nAnother pickup from Northcrest, same as last time."
    scene 13_0658 with dissolve
    mc "That goddamn woman has no empathy."
    mc "Don't worry, I'll get it done. You just take it easy and rest."
    bill "Appreciate it, Son."
    scene 13_0659 with dissolve
    bill "And Mary?"
    mc "Mary?"
    bill "I need your word, [mc]."
    bill "Swear to me, right now, you'll take good care of her when I ain't around no more."
    scene 13_0660 with dissolve
    mc "I give you my word."
    mc "That ain't something I give easily, but you have it."
    scene 13_0661 with dissolve
    bill "As her friend? Or as her lover?"
    bill "I need you to be honest with me."
    scene 13_0660 with dissolve
    mc "Bill..."
    $ tCh=Mary.Has("EZ")
    if not EzModeActive:
        menu:
            "As her lover"(friend="Sexual", color="#1acc03"):
                $ tCh=True
            "As her friend"(friend="Friends", color="#1acc03"):
                $ tCh=False
    if tCh:
        mc "I really like her.\nI don't wanna give her up."
        scene 13_0662 with dissolve
        bill "Then I give you both my blessing, Son."
    else:
        $ Mary.L=-1
        mc "What we did, it wasn't right, and it won't happen again."
        scene 13_0662 with dissolve
        bill "Thank you, Son."
    scene 13_0663 with dissolve
    bill "Oh, and thanks for gettin' me to the hospital."
    mc "Thanks for not shooting me!"
    scene 13_0664 with dissolve
    bill "[lol]"
    scene 13_0665 with dissolve
    bill "Okay, get outta here and let me rest."
    bill "I'll let Sue know we're back in business."
    scene 13_0666 with dissolve
    bill "Not a scratch on my rig, Son!\nI know where Mary hid my gun!"
    mc "Heh. Got it."
    scene 13_0667 with dissolve
    scene 13_0668 with dis1
    play sound "knock.mp3"
    scene 13_0669 with dis1
    pause 0.5
    mar "[whi]Come in."
    scene 13_0670 with dissolve
    mc "Hey."
    scene 13_0671 with dissolve
    mar "You both friends again?"
    mc "Yeah."
    scene 13_0672 with dissolve
    mc "Wow, you have a nice bedroom!"
    mar "Thanks! Biggest one in the house!"
    scene 13_0673 with dissolve
    mar "Pops always says he doesn't need so much space, and I should have it."
    scene 13_0674 with dissolve
    mar "Are you stayin' over again?"
    mc "No, I can't - not this time. Sorry."
    scene 13_0675 with dissolve
    mc "Just wanted to say bye before I left."
    mar "Oh."
    scene 13_0676 with dissolve
    mc "Must be tough lookin' after him all by yourself?"
    mar "Sometimes, I guess."
    mc "What happened with Bill and your mom?"
    scene 13_0677 with dissolve
    mar "Pops don't like her much. Never did."
    mar "They yell and fight all the time!\nHe won't get any better with her around."
    scene 13_0678 with dissolve
    mar "She always ends up drunk as a skunk by nighfall, anyway."
    mar "Was best she went back home and left me to it."
    scene 13_0679 with dissolve
    mc "You're doin' great, Mary."
    mc "But, if you'll let me, I want to send someone to help you. Just for a few days."
    scene 13_0680 with dissolve
    mar "I don't need any help! I can take care of Pops!"
    scene 13_0681 with dissolve
    mc "I know you can, Sweetie!"
    scene 13_0682 with dissolve
    mc "This is to make {b}me{/b} feel better!"
    mc "It's my fault you're having to do all this extra work!"
    mc "I worry about you, Mary, so please, let me do this."
    scene 13_0683 with dissolve
    mar "You worry about me?"
    mar "Who would you send?"
    mc "A friend of mine is a nurse, and I'm sure she'll know someone who could help out."
    mc "A few days, that's all. Please, for me."
    scene 13_0684 with dissolve
    mar "... Okay."
    scene 13_0685 with dissolve
    mc "Thank you."
    scene 13_0686 with dissolve
    mar "Sure you can't stay over?"
    mc "Yeah, sorry."
    scene 13_0687 with dissolve
    mar "Can you stay with me for a little while, at least?"
    if Mary.L==-1:
        scene 13_0688 with dissolve
        mc "Mary... We can't do that anymore."
        mar "Huh? How come??"
        scene 13_0689 with dissolve
        mc "Well, for a start... It's just not right."
        mc "I really like you, Mary, and I want us to be friends {b}forever{/b}.\nSex only gets in the way of that."
        if persistent.MaryDaddy:
            mar "But can I still call you Daddy?"
            menu:
                "Of course you can":
                    pass
                "No, I don't think you should":
                    $ persistent.MaryDaddy=False
        mar "[whi]Okay."
        mc "I'm sorry, but it's for the best."
        scene 13_0691 with dissolve
        call Emotion (mar, "Sniffles", "Bye.")
    else:
        mar "I'm getting sticky and wet again, just how you like it!"
        $ tCh=True
        if not EzModeActive:
            menu:
                "Stay a while":
                    pass
                "Leave":
                    $ tCh=False
        if tCh:
            call MaryReplay05
            scene 13_0818 with Fade(0,0,2)
            mar "[whi]I wish you could stay longer."
            mc "[whi]Yeah, me too."
            scene 13_0819 with dissolve
            mar "[whi]Will you come back soon?\nWe can have sex again."
            mc "[whi]Yeah, of cours--"
            scene 13_0820 with dissolve
            mc "Wait..."
            mc "Mary, you don't think I only come here so we can have sex, do you??"
            scene 13_0821 with dissolve
            mar "No! Silly!"
            mar "But it don't mean we can't!"
            scene 13_0822 with dissolve
            $ dia = "I love you, " + ("Daddy" if persistent.MaryDaddy else persistent.McName) +".\nAnd I love having sex with you!"
            mar "[dia]"
            mar "I wish you lived here and we could do it ten times every day!"
            scene 13_0823 with dissolve
            mc "Wow... Ten times, huh?"
            mar "Or more!"
            scene 13_0824 with dis1
            scene 13_0825 with dissolve
            mar "[whi]Mmhh."
            scene 13_0826 with dissolve
            mc "[whi]I'd better go... Otherwise, I'm never gonna leave."
            mar "[whi]Okay."
            scene 13_0825 with dissolve
            mar "[whi]Mmmhh."
            scene 13_0827 with fade
            mc "See you soon, Sweetie."
            $ dia = "Bye, " + ("Daddy" if persistent.MaryDaddy else persistent.McName)+"."
            mar "[dia]"
        else:
            scene 13_0688 with dissolve
            $ Mary.Add("Refused")
            mc "I wish I could stay, but I've got a lot to do today."
            mar "Aww."
            scene 13_0690 with dissolve
            mc "I'll come and stay over soon. Promise."
            mar "Okay."
            scene 13_0691 with dissolve
            mar "Bye."
    scene 13_0828 with Fade(2, 2, 1)
    scene 13_0829 with dis1
    scene 13_0830 with dis1
    scene 13_0831 with dis1
return

screen DevFuckedUp():
    python:
        def UpdateCh(res):
            Christina.act=res
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 700
        ysize 300
        background Solid("#2b4869ff")
        text "Developer messed up!" xalign 0.5
        frame:
            background None
            xalign 0.5
            ypos 40
            text "{size=*.6}Sorry! I forgot to save your choice regarding helping Christina fix-up her home. Please remind me:"
            textbutton _("{size=*.8}YES: I chose to help Christina"):
                ypos 100
                xalign 0.5
                text_color ("#000000ff")
                background Solid("#4487ebff")
                action Function(UpdateCh, True), Hide("DevFuckedUp")
            textbutton _("{size=*.8}NO: I chose NOT to help Christina"):
                text_color ("#000000ff")
                background Solid("#4487ebff")
                ypos 150
                xalign 0.5
                action Function(UpdateCh, False), Hide("DevFuckedUp")

return
label Springhaven_05_ReturnHome:
    scene 05_0212 with Fade(2, 3, 2)
    pause
    scene 13_0866 with fade
    alex "[whi]Mh-mhh."
    nic "You're not even listening."
    scene 13_0867 with dissolve
    alex "Sorry Nic... My Mom's being a bitch again..."
    nic "She drunk?"
    call Emotion (alex, "Sigh", "What do {i}you{/i} think?")
    scene 13_0868 with dissolve
    mc "Ladies."
    nic "Hi [mc]."
    if Alex.isActive():
        alex "Now there's a sight for sore eyes!"
    else:
        alex "Hey."
    scene 13_0869 with dissolve
    mc "Cara not here?"
    nic "She's upstairs, getting changed."
    scene 13_0870 with dissolve
    if Alex.L==3:
        alex "So we have some time if you wanna stick your dick in my mouth again!"
        nic "ALEX!"
        scene 13_0871 with dissolve
        alex "Nic said she'd like to stay and watch the {b}whole show{/b} next time."
        scene 13_0872 with dissolve
        nic "OH MY GOD! NO I DIDN'T!!\nDON'T LISTEN TO HER!"
        alex "[lol]"
        scene 13_0873 with dissolve
        mc "Yeah, I know you didn't."
        mc "Honestly, I don't know how you put up with her!"
        scene 13_0874 with dissolve
        nic "Neither do we half the time!"
        alex "Shut up!\nYou love me! You {b}all{/b} do!"
        scene 13_0875 with dissolve
        nic "Yeah, we do... but you make it hard sometimes!"
        scene 13_0876 with dissolve
        alex "[lol]{w=0.5}{nw}"
        scene 13_0877 with dissolve
        alex "There's only {b}one{/b} thing I wanna make hard."
        mc "Oh, don't worry - you have {b}that{/b} covered."
        scene 13_0878 with dissolve
        alex "We should swap numbers."
        mc "Why?"
        scene 13_0879 with dissolve
        alex "Next time I give you a blowie, I don't want us being disturbed."
        alex "And I have more than one place you can stick it."
        nic "You're terrible, Alex!"
        scene 13_0880 with dissolve
        alex "Why??"
        alex "He wants to fuck me, and I want him to fuck me!"
        scene 13_0881 with dissolve
        alex "You don't want us to do it in front of you, do you?"
        nic "God no!"
        alex "So we'll have to arrange to meet up somewhere. Just the two of us!"
        scene 13_0882 with dissolve
        mc "If you want my number, you can have it."
        alex "Cool."
        $ Alex.Add("Cell")
        if Nicole.isActive():
            nic "Can I get it, too?"
            scene 13_0883 with dissolve
            mc "Sure."
            nic "It's just... You know, umm... You might need to get in touch with Cara, and her cell phone could be off."
            nic "You could call mine instead."
            mc "Great."
            $ Nicole.Add("Cell")
            scene 13_0884 with dissolve
            alex "You're just gonna send him nudes, right?"
            scene 13_0885 with dissolve
            nic "{b}ALEX!{/b} WHAT THE FUCK?! NO!"
            alex "[lol]"
            scene 13_0886 with dissolve
            alex "I'm only joking! Chill!"
            alex "He's definitely gettin' some of my pussy pics, though!"
            scene 13_0887 with dissolve
            nic "[lol]"
        scene 13_0888 with dissolve
        mc "I'll tell Cara to pass along my number."
        alex "Great."
    else:
        mc "What you guys up to today?"
        alex "Not much. Heading into town."
        scene 13_0882 with dissolve
        mc "Drinking and pool at the bar again?"
        alex "No, retail therapy!"
        scene 13_0883 with dissolve
        nic "We don't play as much now... since Cara kicked her butt!"
        mc "Is that so?"
        alex "That's not the reason!"
        scene 13_0884 with dissolve
        nic "It is."
        scene 13_0888 with dissolve
        mc "Well, have fun!"
    scene 13_0889 with dissolve
    mc "See you later, girls."
    if BillSick or Christina.isActive():
        scene 13_0890 with dissolve
        mc "Oh... Hey, Nicole..."
        scene 13_0891 with dissolve
        mc "Do you know if your mom's busy tomorrow?"
        nic "Yeah. She's working the day shift."
        nic "She's at home right now, though."
        mc "Oh, okay. Thanks."
    scene 13_0892 with fade
    scene 13_0893 with dis1
    play sound "knock.mp3"
    scene 13_0894 with dis1
    pause 0.5
    car "[whi]Yeah?"
    mc "Hey, Pipsqueak, it's me."
    car "[whi]Come in."
    scene 13_0895 with dis1
    scene 13_0896 with dissolve
    car "Hey, Dad!"
    if Cara.Has("Woke"):
        mc "Hey.\nSorry about last night."
        scene 13_0897 with dissolve
        car "Me too.\nI should've called you to check that you weren't coming home first!"
        scene 13_0898 with dissolve
        if persistent.Incest and Cara.isActive():
            mc "I didn't want to kick you out, but we need to be careful..."
            car "Yeah, I know. Forget about it."
        else:
            mc "I should've let you and your mom know I was on my way back."
            mc "I guess we {b}both{/b} need to work on our communication skills, heh."
    elif Cara.Has("Slept"):
        car "Sorry for sleeping in your bed last night!\nI didn't think you were comin' home!"
        scene 13_0897 with dissolve
        car "It was a nice surprise waking up next to you, though!"
        scene 13_0898 with dissolve
        mc "Figured there was no point in disturbing your sleep, or Nicole's."
        car "Huh? What's Nic got to do with it??"
        mc "Wasn't she in your bed?"
        scene 13_0897 with dissolve
        car "Oh!"
        car "No, she didn't stay here last night!"
        scene 13_0899 with dissolve
        car "I slept in your bed 'cause I was missing you!"
        mc "Ohh, okay."
    else:
        mc "Sorry for disturbing your sleep last night!"
        scene 13_0897 with dissolve
        car "Why?"
        car "I would've done the same if it were the other way around!"
        scene 13_0898 with dissolve
        mc "Yeah?"
        car "Well, maybe not {i}exactly{/i} the same..."
        scene 13_0899 with dissolve
        car "Instead of kissing your back, I would've woken up {i}Little Daddy{/i} with a few sloppy licks and kisses!"
    scene 13_0900 with dissolve
    mc "You doin' okay?"
    car "Uhh, yeah... Why??"
    mc "No reason."
    mc "... It's just..."
    mc "We haven't really had a chance to talk about {i}me{/i} being your father."
    scene 13_0901 with dissolve
    car "I'm fine with it!\nYou know that!"
    mc "Yeah... and I'm happy you are."
    scene 13_0902 with dissolve
    mc "But, you know... If you have any questions... or anything to say..."
    mc "I just want you to know - I'm here. Anytime."
    mc "You can talk to me about anything."
    scene 13_0903 with dissolve
    car "Dad..."
    car "You don't need to worry about me."
    scene 13_0904 with dissolve
    car "I'm sad that Pete died.\nHe was your best friend, and he tried to be a dad to me."
    car "I don't think he was ever cut out to be a father... or a husband - and he knew it."
    car "Probably why he gave up tryin'."
    scene 13_0905 with dissolve
    car "You know... When I was a kid, I used to write little made-up stories for school..."
    car "Stories about what adventures me and my dad got up to that weekend..."
    scene 13_0906 with dissolve
    car "But they were never about Pete."
    car "In them, I would pretend {b}you{/b} were my dad."
    car "Every story I wrote was about us - you and me."
    scene 13_0907 with dissolve
    car "You've {b}always{/b} been my father. Even before I knew the truth."
    scene 13_0908 with dissolve
    car "So yeah, I'm fine, Dad. Really."
    scene 13_0909 with dissolve
    car "I love that I'm {b}your{/b} daughter."
    scene 13_0910 with dissolve
    car "I love that you're {b}my{/b} dad."
    if persistent.Incest and Cara.L>3:
        scene 13_0913 with dissolve
        car "And, god, I {b}love{/b} that we fuck."
        car "If my friends weren't waitin' on me, we'd be fucking right now."
        if Millie.L>3:
            car "Tell me you won't ever stop, Dad.\nYou'll never stop fucking your daughters."
            mc "I wo--"
            scene 13_0919 with dissolve
            mc "... {i}Daughter{b}s{/b}{/i}?"
            mc "Why did you say daughters?"
            scene 13_0920 with dissolve
            car "Because you have two!"
            car "And you're fucking us both, aren't you?"
            mc "... Who... Who told you that?"
            scene 13_0921 with dissolve
            car "Millie!"
            car "It's okay, Dad.\nI was so happy when she told me!"
            mc "Why?"
            scene 13_0922 with dissolve
            car "Because I know how amazing it feels when {i}we{/i} do it."
            car "I feel how much you love me with every kiss, every thrust."
            car "No one else could ever make us feel that, not the way {b}you{/b} do."
            scene 13_0923 with dissolve
            mc "Did you tell... Does she know about {i}us{/i}?"
            car "I wanted to tell her, but didn't."
            car "If you'd wanted her to know, you would've told her yourself."
            scene 13_0924 with dissolve
            car "You don't need to worry about her knowing, Dad."
            car "She's been encouraging me to sleep with you!"
            mc "What? Why??"
            scene 13_0925 with dissolve
            car "Because we're sisters, and we love our father more than anything in the world."
            car "I won't say a word to her if you don't want me to."
            scene 13_0926 with dissolve
            mc "It's not that I {b}want{/b} to keep it a secret from her..."
            car "You're worried how she'll react."
            mc "Yeah."
            mc "Her reaction when I told her that you were my daughter wasn't... great."
            scene 13_0927 with dissolve
            car "Yeah, she told me that she freaked out a bit."
            car "She was worried she wouldn't be special enough for you to want to have sex with her if she weren't your {b}only{/b} daughter."
            car "She knows now, though. She {b}is{/b} special. We both are."
            scene 13_0913 with dissolve
            car "You don't have to tell her about us if you don't want to."
            car "But don't stop fucking her, Dad. It wouldn't be fair."
            mc "And... you'd be okay with that?"
            scene 13_0914 with dissolve
            car "More than okay.\nI'm happy to share you, Daddy."
        else:
            car "Tell me you won't ever stop, Dad.\nYou'll never stop fucking your daughter."
            mc "I won't."
            scene 13_0914 with dissolve
            car "I love you, Daddy."
        scene 13_0915 with dissolve
        car "[whi]Mhh."
        scene 13_0916 with dissolve
        car "[whi]..Mmmhh.."
        scene 13_0917 with dissolve
        car "I'd better go, otherwise I'm gonna end up naked for you."
        mc "Sounds good to me!"
        car "[lol]"
        scene 13_0916 with dissolve
        car "[whi]..Mmmhh.."
        scene 13_0918 with dissolve
        mc "Love you, Pipsqueak."
        car "Love you too, Dad."
    else:
        car "So you can stop worrying about me."
        mc "Okay."
        scene 13_0911 with dissolve
        car "[kiss]"
        scene 13_0910 with dissolve
        car "I gotta go, Alex and Nic are waitin'."
        scene 13_0912 with dissolve
        mc "Love you, Pipsqueak."
        car "Love you too, Dad."
    scene 13_0928 with dissolve
    mct "How did I get so lucky to end up with such an awesome daughter?"
    scene 13_0929 with dissolve
    mct "Right... Shower!"
    scene 13_0930 with dis1
    scene 13_0931 with Fade(2,4, 2)
    mct "This is the life! Heh."
    mct "Nice to just... chill for a... little...."
    if BillSick or Christina.isActive():
        scene 13_0932 with dissolve
        mct "Damn."
        mct "No time for a nap, [mc]! Shit to do!"
        if not Christina.isActive():
            call Springhaven_05_VisitChristina
        else:
            call Springhaven_05_Diy01 (BillSick)
    else:
        mc "[whi]Zzz.."
        scene 13_0933 with Fade(4,2,3)
        call Emotion (mc, "Groan", "", True)
        scene 13_1067 with Fade(1,2,1)
        if Sarah.Has("Cell"):
            play sound "vib.mp3"
            pause 1.0
            scene 13_1068 with dissolve
            stop sound
            sar cell "[mc]?\nSorry I missed your call earlier. I was in a meeting."
            mc cell "Oh, hey."
            mc cell "I wanted to come see you. Are you home?"
            sar cell "Yes, but I'm about to leave."
            scene 13_1069 with dissolve
            sar cell "I can't reach Dawn. I'm going to Lakeshore."
            sar cell "She's not answering her phone and isn't returning my calls."
            sar cell "I'm really worried about her, [mc]."
            mc cell "Sarah, wait... she's okay. You don't need to worry."
            sar cell "You don't know that!\nI have to go and be sure!"
            scene 13_1070 with dissolve
            mc cell "No, you don't understand... I {b}do{/b} know."
            mc cell "I know exactly where she is.\nShe's safe, I promise you."
            mc cell "This is why I wanted to see you. We need to talk."
            sar cell "How the hell do you know where she is?"
            sar cell "[mc]? What's going on??"
            mc cell "Don't go to Lakeshore, Sarah. Let me come over and explain."
            scene 13_1071 with dissolve
            sar cell "..."
            sar cell "Fine."
            sar cell "But [mc], if I don't like what I hear... I'm going straight to Lakeshore!"
            mc cell "Fair enough.\nI'm on my way."
        else:
            mct "Hope Dawn's friend is home this time."
    jump Springhaven_05_VisitSarahAgain
return

label Springhaven_05_VisitChristina:
    scene 13_0935 with Fade(2,3,2)
    play sound "knock.mp3"
    scene 13_0936 with dis1
    scene 13_0939 with dis1
    scene 13_0940 with dis1
    cri "[mc]! Hello."
    mc "Hi.\nSorry to drop in like this, you got a minute?"
    scene 13_0941 with dissolve
    cri "Sure. Come on in."
    mc "Thanks."
    scene 13_0942 with dissolve
    cri "Everything okay?"
    mc "Yeah, fine."
    scene 13_0943 with dissolve
    mc "I was hoping you could point me in the right direction."
    cri "For?"
    mc "A friend of mine. Just got out of the hospital. Heart problem."
    cri "Okay..."
    scene 13_0944 with dissolve
    mc "He's recovering at home.\nLives out on a farm with his granddaughter."
    mc "She's taking care of him on her own."
    mc "It's a lot for one person."
    mc "I was hoping you might know someone?"
    cri "What kind of care does he need?"
    scene 13_0946 with dissolve
    mc "I don't have specifics. He didn't say much."
    cri "That makes it harder."
    scene 13_0947 with dissolve
    mc "I figured."
    mc "I just want to get Mary some help. Even short-term."
    scene 13_0948 with dissolve
    cri "Did the hospital set anything up?"
    mc "I don't think so. Might be an insurance issue."
    cri "Right."
    scene 13_0945 with dissolve
    cri "Give me his address."
    cri "I'm not promising anything.\nBut I can take a look and see what's actually needed."
    scene 13_0950 with dissolve
    mc "You'd do that?"
    cri "Of course."
    mc "Thanks. Appreciate it."
    cri "Anytime."
    scene 13_0951 with dissolve
    mc "And he's gonna tell you he's fine!"
    cri "They all do. Doesn't mean I believe them."
    cri "I'll call you after I've seen him."
    mc "Thanks, Christina."
    scene 13_0952 with dissolve
    mct "Sweet."
    mct "Hope it doesn't cost too much, might have to sell the damn truck!"
return

label Springhaven_05_Diy01(BillHelp):
    scene 13_0934 with Fade(2,3,2)
    play sound "knock.mp3"
    scene 13_0937 with dis1
    scene 13_0938 with dis1
    scene 13_0953 with dis1
    cri "Hi [mc]!"
    mc "Hey."
    scene 13_0954 with dissolve
    mc "Come to fill your holes!"
    scene 13_0955 with dissolve
    cri "Shoot! I'd better go put on some lingerie real quick!"
    call laugh (mc, "Be my guest!")
    scene 13_0956 with fade
    cri "Is there anything I can get you?"
    scene 13_0957 with dissolve
    cri "An old sheet? Rags? Bucket of water?"
    mc "Nah, got everything I need, thanks."
    cri "Great."
    scene 13_0958 with dissolve
    cri "Sorry, no idea why I offered you a bucket of water.\nProbably wouldn't help much!"
    call laugh (mc)
    scene 13_0959 with dissolve
    cri "..."
    mc "You okay?"
    cri "Yeah."
    scene 13_0960 with dissolve
    cri "Just saying goodbye to a bad memory."
    cri "And good riddance, too!"
    scene 13_0961 with dissolve
    cri "Can I get you a drink? Coffee?\nI have some beer in the fridge."
    mc "Sure. Beer would be great."
    cri "That's what I like to hear!"
    scene black with Fade(2, 2, 0)
    call CenterText ("A little while later...")
    scene 13_0962 with Fade(0,0,2)
    mct "Lookin' good!"
    scene 13_0963 with dissolve
    cri "Thought you might like another one."
    mc "Oh, uh... yeah. Thanks."
    scene 13_0964 with dissolve
    cri "Wow! You don't hang around, do you?"
    scene 13_0965 with dissolve
    cri "I hope you don't fill {i}every{/i} hole that quickly!"
    scene 13_0967 with dissolve
    mc "It was an honest mistake!"
    cri "[lol]"
    scene 13_0968 with dissolve
    cri "I'm sorry, that was the last one, I swear."
    cri "I'll leave you to get back to it."
    mc "Heh, thanks."
    scene 13_0969 with dissolve
    mc "Oh... Is it okay to go into Nicole's room?"
    scene 13_0970 with dissolve
    mc "This'll need to dry a bit before I can sand it down."
    mc "Thought I'd take a closer look at the ceiling fan while I'm waiting."
    cri "Yeah, of course! Great!"
    if Nicole.isActive() and Nicole.hasScore(6):
        cri "Better give her a knock before going in, though."
        scene 13_0971 with dissolve
        mc "Oh... She's here?"
        mc "She's not with Cara and Alex? Said they were going shopping."
        scene 13_0972 with dissolve
        cri "That {i}was{/i} the plan, but she came home."
        cri "She was feeling a little dizzy, so decided not to go."
        scene 13_0973 with dissolve
        mc "Oh, right.\nMaybe it's best not to disturb her then."
        cri "No, she's fine!"
        scene 13_0974 with dissolve
        cri "It's not the first time she's used that excuse!"
        cri "I think Alex can be a little much for her sometimes."
        scene 13_0975 with dissolve
        cri "She's a lovely girl, but better in small doses!"
        mc "Heh... yeah, I know what you mean."
    else:
        call CloseCharacterPath (Nicole)
    scene 13_0976 with Fade(2, 3, 2)
    mct "Cool."
    scene 13_0977 with dissolve
    mct "Now for the fan..."
    scene 13_0978 with dissolve
    if Nicole.isActive():
        call Springhaven_05_FixNicoleFan
    else:
        scene 13_0980 with dis1
        scene 13_0981 with dissolve
        mct "Gonna need the ladder..."
        scene 13_0982 with Fade(1, 2, 1)
        mct "...That's it... Come on..."
        scene 13_0983 with Fade(1, 2, 1)
        mct "Ahh... Hello there..."
        scene 13_0984 with Fade(1, 2, 1)
        $ t=5
        while t>0:
            scene 13_0985 with Dissolve(0.25)
            scene 13_0986 with Dissolve(0.25)
            scene 13_0984 with Dissolve(0.25)
            $ t-=1
        scene 13_0987 with dissolve
        mct "Nice job, [mc]! Heh."
    scene 13_1014 with Fade(1, 2, 1)
    pause
    scene 13_1015 with Fade(1, 2, 1)
    pause
    if Sarah.Has("Cell"):
        play sound "vib.mp3"
        pause 1.0
        scene 13_1016 with dissolve
        stop sound
        sar cell "[mc]?\nSorry I missed your call earlier. I was in a meeting."
        mc cell "Oh, hey."
        mc cell "I wanted to see you. Will you be home in a little while?"
        sar cell "No, sorry."
        scene 13_1017 with dissolve
        sar cell "I'm about to leave for Lakeshore.\nI can't reach Dawn."
        sar cell "She's not answering her phone and isn't returning my calls."
        sar cell "I'm really worried about her, [mc]."
        mc cell "Sarah, she's okay. You don't need to worry."
        sar cell "You don't know that!\nI have to go and be sure!"
        scene 13_1018 with dissolve
        mc cell "No, you don't understand... I {b}do{/b} know."
        mc cell "I know exactly where she is.\nShe's safe, I promise you."
        mc cell "This is why I wanted to see you. We need to talk."
        sar cell "How the hell do you know where she is?"
        sar cell "[mc]? What's going on??"
        scene 13_1019 with dissolve
        mc cell "I can't talk right now, and not over the phone.\nPlease, don't go to Lakeshore, Sarah."
        mc cell "I need you to trust me. I'll come over and explain."
        scene 13_1020 with dissolve
        sar cell "..."
        sar cell "Fine. I'll wait for you."
        sar cell "But [mc], if I don't like what I hear... I'm going to Lakeshore this evening!"
        mc cell "Fair enough.\nI'll be over as soon as I can."
        scene 13_1021 with dissolve
        mct "Better head straight over there once I'm done here."
        scene 13_1022 with dissolve
    else:
        scene 13_1022 with Fade(1, 2, 1)
    mct "Lookin' good."
    scene 13_1023 with dissolve
    cri "Hey.\nFancy another beer?"
    mc "Nah, I'd better not."
    mc "If I have another one, I might try lookin' for {i}other{/i} holes to fill."
    scene 13_1024 with dissolve
    cri "{i}Really{/i}?... I might go get you one anyway, then!\n[lol]"
    scene 13_1025 with dissolve
    cri "Wow! It looks great!"
    mc "Quick lick of paint and it'll look like new."
    scene 13_1026 with dissolve
    cri "[mc]! Are you offering to lick my holes?"
    scene 13_1027 with dissolve
    mc "Didn't you say you were done with the hole jokes?"
    cri "[lol]"
    scene 13_1028 with dissolve
    cri "I was! Until {b}you{/b} brought it up again!"
    call laugh (mc)
    scene 13_1029 with dissolve
    cri "I leave you to finish up."
    mc "Thanks."
    if BillSick:
        mc "Oh, hey... Can I get your advice on something?"
        scene 13_1030 with dissolve
        cri "Sure!"
        mc "I was hoping you could point me in the right direction."
        scene 13_1031 with dissolve
        cri "For?"
        mc "A friend of mine. Just got out of the hospital. Heart problem."
        cri "Okay..."
        scene 13_1032 with dissolve
        mc "He's recovering at home.\nLives out on a farm with his granddaughter."
        mc "She's taking care of him on her own."
        mc "It's a lot for one person."
        mc "I was hoping you might know someone?"
        cri "What kind of care does he need?"
        scene 13_1033 with dissolve
        mc "I don't have specifics. He didn't say much."
        cri "That makes it harder."
        mc "I figured."
        mc "I just want to get Mary some help. Even short-term."
        scene 13_1034 with dissolve
        cri "Did the hospital set anything up?"
        mc "I don't think so. Might be an insurance issue."
        cri "Right."
        cri "Okay... Give me his address before you leave.\nI can't promise anything, but I can take a look and see what's actually needed."
        mc "You'd do that?"
        scene 13_1035 with dissolve
        cri "Of course."
        mc "Thanks. Appreciate it."
        cri "Anytime!"
        scene 13_1036 with dissolve
        mc "And he's gonna tell you he's fine!"
        cri "They all do. Doesn't mean I believe them."
        scene 13_1037 with dissolve
        mct "Damn. That was kind of her!"
    scene 13_1038 with Fade(1, 2, 1)
    mct "All done.\nGive it a couple of days to dry out before painting it."
    if Nicole.Has("Uniform"):
        nic "Good. You're still here."
        scene 13_1039 with dissolve
        mc "Yeah... I was about to leave. Why?"
        scene 13_1040 with dissolve
        nic "Can you come in here for a second?"
        mc "Sure."
        scene 13_1041 with dis1
        scene 13_1042 with dis1
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e13/13_1043.webp", 1117, 433, True, "Springhaven_AF34") with dissolve
            nic "[whi]Do you like it?"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 13_1043
                hide screen imgMap
        else:
            scene 13_1043 with dissolve
            nic "[whi]Do you like it?"
            call Springhaven_AF34
        scene 13_1045 with dissolve
        mc "You look stunning!"
        scene 13_1046 with dissolve
        nic "You're mocking me.\nIt's just a silly uniform."
        scene 13_1047 with dissolve
        mc "Sweetheart, no! I would never."
        scene 13_1048 with dissolve
        mc "It might be just a silly uniform when it's in your closet."
        scene 13_1049 with dissolve
        mc "But, when {b}you're{/b} wearing it?"
        scene 13_1050 with dissolve
        mc "It's the sexiest damn uniform I've ever seen!"
        scene 13_1051 with dissolve
        image NicM = Movie(play="images/e13/13_1052.webm", loop=False, keep_last_frame=True)
        nic "Ohhh no! You're joking??"
        mc "Nope."
        show NicM
        pause 1.0
        mc "Beautiful!"
        nic "[lol]"
        scene 13_1053 with dissolve
        nic "You should probably go before my mom comes in and sees us!"
        mc "Yeah."
        scene 13_1054 with dissolve
        mc "..."
        nic "What are you doing?"
        scene 13_1055 with dissolve
        mc "Tryin' to burn this image into my brain!"
        nic "[lol]"
        scene 13_1056 with dissolve
        nic "A picture would last longer!"
        scene 13_1057 with dissolve
        nic "... I mean... you know..."
        nic "I could send you one... if... you wanted?"
        scene 13_1058 with dissolve
        mc "I'd love one."
        if not Nicole.Has("Cell"):
            mc "I'll give you my number."
            nic "Okay."
            $ Nicole.Add("Cell")
        else:
            mc "Did Cara give you my number?"
            nic "Yeah."
        scene 13_1059 with dissolve
        mc "I'd better get outta here."
        nic "[whi]Yeah."
        scene 13_1060 with dissolve
        mc "See you later, Sweetheart."
        scene 13_1061 with dissolve
        mc "Wow. Just... WOW!"
        scene 13_1062 with dissolve
        nic "[whi]Bye, [mc]."
        mc "Bye."
    scene 13_1063 with Fade(2,3,2)
    mct "Okay, next on the list..."
    if Sarah.Has("Cell"):
        mct "Go see Sarah."
    else:
        mct "Go see if Dawn's friend is home yet."
    if Nicole.Has("Uniform"):
        scene 13_1064 with dissolve
        mct "Maybe grab a bite to eat on the way... I'm starving!"
        play sound "text.mp3"
        pause 1.0
        scene 13_1065 with dissolve
        pause 0.5
        call Msg_Nicole01
        scene 13_1066 with dissolve
        mct "She's so damn fine!"
return

label Springhaven_05_FixNicoleFan:
    play sound "knock.mp3"
    scene 13_0979 with dis1
    pause 0.5
    nic "[whi]Come in."
    scene 13_0980 with dissolve
    mc "Hey."
    scene 13_0988 with dissolve
    mc "Feelin' better?"
    nic "Uhh... Yeah."
    scene 13_0989 with dissolve
    mc "If you don't mind me intruding, I'll take a proper look at your fan."
    nic "No, I don't mind."
    mc "Great.\nI'll go get my ladder."
    scene 13_0990 with Fade(1, 2, 1)
    mc "[whi]...That's it... Come on..."
    scene 13_0991 with Fade(1, 2, 1)
    scene 13_0992 with dis1
    scene 13_0993 with dis1
    scene 13_0994 with dis1
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e13/13_0994.webp", 1522, 259, True, "Springhaven_AF33")
        mct "Heh. I DO like that picture!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 13_0994
            hide screen imgMap
    else:
        if not EzModeActive:
            menu:
                "[wk_y]Ask about the school uniform":
                    call Springhaven_AF33
                "Don't":
                    pass
        elif Nicole.Has("EZ"):
            call Springhaven_AF33
    if not Nicole.Has("Uniform"):
        scene 13_0998 with dissolve
        hide screen imgMap
        nic "Need any help?"
        scene 13_0999 with dissolve
        mc "Nah, I'm good, thanks."
        nic "Okay."

    scene 13_1005 with Fade(1, 2, 1)
    mc "[whi]Hmmm... Hello there..."
    scene 13_1006 with Fade(1, 2, 1)
    $ t=5
    while t>0:
        scene 13_1008 with Dissolve(0.25)
        scene 13_1007 with Dissolve(0.25)
        scene 13_1006 with Dissolve(0.25)
        $ t-=1
    scene 13_1009 with dissolve
    nic "Oh, wow! You fixed it!"
    mc "Yep. It was just a loose connection."
    scene 13_1010 with dissolve
    nic "That's amazing! Thank you so much!"
    mc "My pleasure."
    scene 13_1011 with dissolve
    mc "Okay, I'll get outta your hair."
    if Nicole.Has("Uniform"):
        nic "Are you leaving now?"
        scene 13_1012 with dissolve
        mc "Not yet. Still have some work to finish off with the holes in the wall."
        nic "Ahh. Okay."
    else:
        mc "Enjoy the refreshing breeze!"
        nic "I will!"
    scene 13_1013 with dissolve
    nic "Thanks again, [mc]."
    mc "You're welcome."
return

label Springhaven_05_VisitSarahAgain:
    scene 13_1072 with Fade(2, 3, 2)
    pause
    play sound "knock.mp3"
    scene 13_1073 with Fade(0.25, 0.25, 0.5)
    pause 0.5
    scene 13_1074 with dis1
    if not Sarah.Has("Cell"):
        jump Springhaven_05_MeetSarahAgain
    mc "Hey."
    sar "Hi. Come in."
    scene 13_1089 with dissolve
    pause
    scene 13_1100 with dissolve
    sar "What's going on??"
    sar "Where the fuck is she, [mc]?"
    mc "Come on, sit down, and I'll go through it."
    scene 13_1101 with dissolve
    sar "Okay, I'm listening..."
    scene 13_1102 with Fade(2, 3, 2)
    sar "So it was real... The stalker?"
    mc "Possibly, yeah."
    scene 13_1103 with dissolve
    sar "I... I really thought she was just being paranoid.\nI feel terrible."
    mc "Why?\nEven if you {i}weren't{/i} sure, you were still there for her."
    sar "She's my best friend. I should never have doubted her."
    scene 13_1104 with dissolve
    sar "When are you going back there?"
    mc "In a day or two."
    sar "Take me with you.\nI need to see her. Please."
    scene 13_1105 with dissolve
    mc "It's not exactly comfortable there."
    mc "Middle of nowhere. Run-down old building. Overcrowded."
    sar "[mc], {b}I'm coming{/b}!"
    mc "Okay."
    if Sarah.L<4:
        scene 13_1106 with dissolve
        mc "I'll call you once I've made the arrangements."
        sar "Good. Thank you."
        scene 13_0537 with fade1
        pause
        jump Springhaven_05_TalkToAlison
    scene 13_1107 with fade1
    sar "I'm glad you came over."
    sar "Don't take this the wrong way, but I've missed you."
    scene 13_1108 with dissolve
    sar "Can you stay the night?"
    mc "Sorry, I'd love to, but can't.\nHave a lot goin' on."
    sar "Okay."
    scene 13_1109 with dissolve
    sar "Do we have time to make love before you leave?"
    $ tCh=Sarah.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]Yeah":
                $ tCh=True
            "No. Really don't have the time":
                $ tCh=False
    if tCh:
        call SaraReplay04
        scene 13_1232 with Fade(0,1,2)
        sar "[whi]Mhh."
        scene 13_1233 with dissolve
        sar "[whi]I'll see you in a day or two, then."
        mc "[whi]Yeah."
        scene 13_1232 with dissolve
        sar "[whi]..Mmmhh.."
        scene 13_1234 with fade
        sar "[whi]Bye, [mc]."
        mc "[whi]See ya."
    else:
        scene 13_1110 with dissolve
        mc "Yeah... But I really do have a lot to do."
        sar "Until next time then."
        scene 13_0537 with fade1
        pause
    scene 13_1235 with fade1
    scene 13_1236 with dis1
    scene 13_1237 with dis1
    scene 13_1238 with dis1
    scene 13_1239 with dis1
    scene 13_1240 with dis1
    scene 13_1241 with dis1
    jump Springhaven_05_TalkToAlison
return

label Springhaven_05_MeetSarahAgain:
    $ Sarah_name="Sarah"
    mc "Hi. Sarah?"
    sar "Yes. Can I help you?"
    scene 13_1075 with dissolve
    mc "Your friend Dawn asked me to stop by."
    sar "Dawn?!"
    sar "Where is she? Is she okay??\nI haven't been able to get a hold of her!"
    mc "She's fine."
    scene 13_1076 with dissolve
    sar "Who {i}are{/i} you? How do you know her?"
    sar "Why hasn't she returned my calls?"
    sar "WHERE IS SHE?? TELL ME!"
    scene 13_1077 with dissolve
    mc "Relax. I'll answer all your questions... Just, one at a time."
    sar "Don't tell me to {i}relax{/i}!"
    scene 13_1078 with dissolve
    sar "I've been worried sick about my friend!\nI've not heard from her in days, and now {b}you{/b} show up at my door."
    sar "Some random guy, telling me she's fine?"
    sar "Tell me where she is, right now, or I'm calling the police!"
    scene 13_1079 with dissolve
    mc "I can't do that."
    mc "But I can get her on the phone; you can talk to her yourself."
    sar "She's not answering her cell. Don't you think I've been trying?!"
    scene 13_1080 with dissolve
    mc "She doesn't have her phone."
    mc "She's with a friend of mine, I can call {i}her{/i}."
    sar "Fine. Go ahead. Let me speak to her."
    scene 13_1081 with dissolve
    mc "Can I come in?"
    sar "Make the call."
    mc "... Okay."
    scene 13_1082 with dissolve
    mc cell "Hey. It's me.\nPut Dawn on."
    scene 13_1083 with dissolve
    mc "Here."
    scene 13_1084 with dissolve
    sar cell "Dawn??"
    sar cell "..."
    sar cell "Where the hell have you been?!"
    sar cell "Wha--"
    sar cell "..."
    scene 13_1085 with dissolve
    sar cell "But--"
    sar cell "..."
    sar cell "Okay, explain!"
    scene 13_1086 with dissolve
    mc "Seriously?"
    scene black with fade1
    call CenterText ("15 minutes later...")
    scene 13_1087 with fade
    pause
    scene 13_1088 with dissolve
    sar "Sorry I left you out here."
    sar "Would you like to come in?"
    scene 13_1089 with dissolve
    if Sarah.Has("couch"):
        mct "Ahh, shit... Thought she seemed familiar.... She gave me the ride!..."
        mct "Don't think she recognized me, though... Not gonna say anything."
    else:
        pause
    scene 13_1090 with dissolve
    sar "So this whole time, the stalker thing was real?"
    mc "Possibly."
    sar "I wasn't sure... I thought she was just being paranoid.\nNow I feel terrible."
    scene 13_1091 with dissolve
    mc "Why?"
    mc "Dawn told me how you were supporting her through it.\nEven if you {i}didn't{/i} believe it, you were still there for her."
    scene 13_1092 with dissolve
    sar "She's okay? Really?"
    mc "Yeah.\nYou don't need to worry. She's in safe hands."
    scene 13_1093 with dissolve
    sar "Is she, though?\nI don't know you."
    sar "How do I know {b}you're{/b} not the stalker?"
    mc "That doesn't make sense. You just spoke to her!"
    scene 13_1094 with dissolve
    sar "There was someone else with her."
    sar "She could've been coerced into telling me she's okay!"
    mc "She wasn't."
    scene 13_1095 with dissolve
    sar "She said I can trust you, but I don't."
    sar "Dawn said you'd be going back to Lakeshore in a day or two.\nI'm going with you."
    mc "I know."
    sar "You know?"
    scene 13_1096 with dissolve
    mc "She told me you'd insist on seeing her in person."
    mc "Also said I'd be wasting my time arguing with you about it."
    mc "So, yeah, I know."
    scene 13_1097 with dissolve
    sar "Good."
    sar "And just so you know, I carry a taser in my purse.\nTry anything, and I'll zap you."
    mc "Noted."
    mc "If you give me your number, I'll let you know when I'm leaving."
    sar "Fine."
    scene 13_1098 with fade1
    sar "If I haven't heard from you within three days, I'll be calling the cops."
    scene 13_1099 with dissolve
    mc "Don't worry, I'll be in touch."
    scene 13_0537 with fade1
    pause
    jump Springhaven_05_TalkToAlison
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
