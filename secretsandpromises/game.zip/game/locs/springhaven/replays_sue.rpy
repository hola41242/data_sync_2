label SueReplay01_Part01:
    scene 03_0996 with dissolve
    call Emotion (sue, "Sigh", "This conversation has made me feel slightly anxious.")
    sue "I need relaxation."
    scene 03_0997 with dissolve
    call Emotion (sue, "Snaps fingers", "Kiyomi!")
    $ Kiyomi_name="Kiyomi"
    scene 03_0998 with dissolve
    pause 1.0
    scene 03_0999 with dissolve
    pause 1.0
    scene 03_1000 with dissolve
    mct "What the fuck?!"
    scene 03_1001 with dissolve
    pause 1.0
    scene 03_1002 with dissolve
    sue "Interesting choice."
    scene 03_1003 with dissolve
    play sound "vib2.mp3" loop
    sue "The photograph I gave you. It needs to be returned."
    scene 03_1004 with dissolve
    mc "Yeah, I figured you'd want it back. I have it with me."
    sue "Excellent."
    scene 03_1005 with dissolve
    sue "Our meeting has concluded. You're free to leave."
    if not _in_replay:
        $ tCh=None
        if not EzModeActive:
            menu:
                "Leave [wk_c]":
                    pass
                "[wk_y]Stay":
                    $ tCh=True
        if tCh or Sue.Has("EZ"):
            call SueReplay01_Part02
        else:
            call CloseCharacterPath (Sue, "Sue")
            scene 03_1006 with dissolve
            if Sue.Has("Toy"):
                sue "I saw you admiring my toys.\nWouldn't you like to see them being played with?"
                mc "I'm good, thanks."
            else:
                pause 0.5
            if helpedMel:
                scene 03_1008 with dissolve
                sue "Stop. There's one more issue to discuss..."
                mc "Can't it wait?"
                sue "It'll take but a moment."
                scene 03_1009 with dissolve
                sue "It seems you were correct about the cafe owner; she {b}has{/b} been overpaying."
                scene 03_1010 with dissolve
                sue "Douglas and Simon increased her payments without authorization and have been keeping the money for themselves."
                scene 03_1009 with dissolve
                mc "Douglas and Sim... Ohhh... Asshole 1 and Asshole 2.\nHmmm, and they seemed {i}so{/i} trustworthy! Damn."
                sue "Needless to say, the situation will be dealt with."
                scene 03_1011 with dissolve
                sue "[ss]Mmhh..."
                sue "You can inform Melanie that we have corrected the error, and her future payments will be reduced to reflect this."
                scene 03_1012 with dissolve
                mc "Okay.\nThanks for looking into it."
            else:
                scene 03_1007 with dissolve
                pause 0.5
                scene 03_1012 with dissolve
                sue "I'll be in touch."
                mc "Fine."
            scene black with Fade(3, 0, 0)
            stop sound
            return
return

label SueReplay01_Part02:
    call Unlocker ("SueReplay01_Part02")
    if _in_replay:
        call SueReplay01_Part01
    else:
        $ Sue.isSexual(True)
    scene 03_1013 with dissolve
    sue "You aren't leaving. Why?"
    scene 03_1014 with dissolve
    mc "I should get to know my boss better.\nSeeing how she chooses to relax would be a good start."
    scene 03_1015 with dissolve
    sue "Interesting."
    sue "I've never met a man who wasn't either intimidated or embarrassed about my relaxation methods."
    sue "..."
    sue "Come closer."
    scene 03_1016 with dissolve
    sue "If you wish to remain, then participate."
    mc "You want me to... masturbate?"
    scene 03_1017 with dissolve
    sue "Want?"
    sue "I insist."
    call Loop_Dissolve (5, True, False, "e03/03_1018.webp", "e03/03_1019.webp")
    call Loop_Dissolve (4, True, False, "e03/03_1020.webp", "e03/03_1021.webp")
    scene 03_1022 with dissolve
    sue "Allow me..."
    call Loop_Dissolve (3, True, False, "e03/03_1023.webp", "e03/03_1024.webp")
    call Loop_Dissolve (3, True, False, "e03/03_1025.webp", "e03/03_1026.webp")
    call Loop_Dissolve (2, True, False, "e03/03_1027.webp", "e03/03_1028.webp")
    call Loop_Dissolve (3, True, False, "e03/03_1029.webp", "e03/03_1030.webp")
    scene 03_1031 with dissolve
    sue "[ss]..Mmhhh.."
    scene 03_1032 with dissolve
    call Moan (sue)
    scene 03_1033 with dissolve
    sue "[ss]..OHHHH..."
    scene 03_1034 with dissolve
    sue "You {b}mustn't{/b} ejaculate on my furniture or flooring."
    scene 03_1035 with dissolve
    sue "Kiyomi."
    scene 03_1036 with dis1
    pause 0.5
    scene 03_1037 with dis1
    pause 0.5
    scene 03_1038 with dis1
    pause 1.0
    scene 03_1039 with dissolve
    mc "Uhh..."
    $ Sue.Add("L0")
    scene 03_1040 with dissolve
    mc "No."
    scene 03_1041 with dissolve
    sue "No??"
    mc "I'm not using some random maid."
    scene 03_1042 with dissolve
    mc "Open {b}your{/b} mouth."
    pause 2.0
    scene 03_1043 with dis1
    pause
    scene 03_1044 with dis1
    pause 0.5
    scene 03_1045 with dis1
    pause 0.5
    scene 03_1046 with dissolve
    pause 0.5
    scene 03_1047 with dis1
    pause 0.5
    call Loop_Dissolve (5, True, False, "e03/03_1048.webp", "e03/03_1049.webp")
    pause 0.5
    scene 03_1050 with dissolve
    mc "I want it {b}in{/b} your mouth."
    call Loop_Dissolve (5, True, False, "e03/03_1051.webp", "e03/03_1052.webp")
    scene 03_1053 with dissolve
    sue "[ss]..Mmhh.."
    image r_sue_01 = Movie(play="images/e03/03_1054.webm")
    show r_sue_01 with dissolve
    sue "[ss]..Mmhh.."
    scene 03_1055 with dissolve
    call Moan (sue)
    scene 03_1056 with dissolve
    sue "[ss]...MMMHHHHHHH...."
    call Loop_Dissolve (4, False, False, "e03/03_1057.webp", "e03/03_1056.webp")
    call CharCum ("e03/03_1056.webp", "e03/03_1058.webp", sue, "....OHHHHH!!....")
    call CharCum ("e03/03_1058.webp", "e03/03_1059.webp", sue, "....MMMMMMMHHHHHHH!!....")
    stop sound
    scene 03_1060 with dissolve
    mc "[ss]...fuuck..."
    scene 03_1061 with dissolve
    pause
    scene 03_1062 with dissolve
    pause
    call CharCum ("e03/03_1063.webp", "e03/03_1064.webp", mc, "..NNNGGGGGHHHH!!...")
    call CharCum ("e03/03_1064.webp", "e03/03_1065.webp", mc, "....nnnnhhhhh...")
    scene 03_1066 with dissolve
    pause 0.5
    scene 03_1067 with dissolve
    call Gulp (sue)
    scene 03_1068 with dissolve
    sue "Thank you."
    scene 03_1069 with dissolve
    sue "Now I feel incredibly relaxed."
    scene 03_1070 with dissolve
    sue "Kiyomi."
    scene 03_1071 with dissolve
    sue "We have no further business. You may go."
    scene 03_1072 with dissolve
    pause 0.5
    if _in_replay:
        scene black with ReplayFade
        return
    scene 03_1073 with dis1
    pause 0.5
    scene 03_1074 with dis1
    if helpedMel:
        sue "Oh, wait a moment. There {b}is{/b} one more issue to discuss..."
        scene 03_1075 with dissolve
        sue "It seems you were correct about the cafe owner; she {b}has{/b} been overpaying."
        scene 03_1076 with dissolve
        sue "Douglas and Simon increased her payments without authorization and have been keeping the money for themselves."
        scene 03_1075 with dissolve
        mc "Douglas and Sim... Ohhh... Asshole 1 and Asshole 2.\nHmmm, and they seemed {i}so{/i} trustworthy! Damn."
        sue "Needless to say, the situation will be dealt with."
        scene 03_1076 with dissolve
        sue "You can inform Melanie that we have corrected the error, and her future payments will be reduced to reflect this."
        scene 03_1077 with dissolve
        mc "Okay.\nThanks for looking into it."
    else:
        sue "I will be in touch."
        scene 03_1077 with dissolve
        mc "Great."
    scene 03_1078 with dissolve
    pause 1.0
    scene 03_1079 with dissolve
    $ persistent.KiyomiLocked=False
    ki "Wait."
    scene 03_1080 with dissolve
    ki "Why didn't you... 'use' me?"
    mc "Did you want me to?"
    ki "No! Of course not!"
    mc "That's why."
    mc "Why didn't you object?"
    scene 03_1081 with dissolve
    ki "I... I couldn't!"
    mc "Why?"
    scene 03_1082 with dissolve
    ki "I have no choice!"
    ki "I {b}have{/b} to obey her."
    scene 03_1083 with dissolve
    mc "Again, why??"
    ki "It's... complicated."
    scene 03_1084 with dissolve
    ki "As long as I do what I'm told, everything will be fine."
    mc "What happened to the broken English??"
    scene 03_1085 with dissolve
    ki "I'm from Northcrest! I speak perfectly good English."
    ki "She's a crazy bitch!"
    ki "She 'demands' I talk that way at all times, especially in front of guests."
    mc "Why not leave?"
    scene 03_1086 with dissolve
    ki "Do you seriously think I'm here by {i}choice{/i}?!"
    ki "If I walk out that door..."
    scene 03_1087 with dissolve
    call Emotion (ki, "Sigh", "It doesn't matter.")
    ki "I just wanted to thank you. For not doing... {i}that{/i}."
    scene 03_1088 with dissolve
    ki "I need return to Miss. Goodbye."
    scene 03_1089 with dissolve
    pause 1.0
    scene black with Fade(3,0,0)
return

label SueReplay02:
    call Unlocker ("SueReplay02")
    if not _in_replay:
        $ persistent.SueRP02Dat=([MiyukaDelivered, False])
        $ Sue.incSex()
    else:
        scene 05_0923 with Fade(0,0,3)
        sue "This conversation has already taxed me more than I can bear.\nWe can discuss things further once you've made your decision."
        sue "Now, I need to relax."
        scene 05_0924 with dissolve
        sue "Kiyomi!"
        scene 05_0925 with dissolve
        sue "You are excused."
    $ aaa="" + ("a" if not persistent.SueRP02Dat[0] else "")
    show expression "05_0930" + aaa with dissolve
    mc "Kiyomi, stop."
    show expression "05_0931" + aaa with dissolve
    mc "She won't be needing her toys."
    scene 05_0932 with dissolve
    sue "What's the meaning of this??"
    scene 05_0933 with dissolve
    mc "Come here, right now."
    show expression "05_0934" + aaa with dissolve
    pause 0.5
    show expression "05_0935" + aaa with dis1
    show expression "05_0936" + aaa with dis1
    show expression "05_0937" + aaa with dis1
    show expression "05_0938" + aaa with dis1
    show expression "05_0939" + aaa with dis1
    mc "Get on your knees."
    show expression "05_0940" + aaa with dis1
    mc "Good."
    scene 05_0941 with dissolve
    sue "Wha.."
    mc "NO.\nYou don't speak..."
    show expression "05_0942" + aaa with dissolve
    mc "You suck."
    show expression "05_0943" + aaa with dis1
    show expression "05_0944" + aaa with dis1
    scene 05_0945 with dissolve
    pause
    scene 05_0946 with dissolve
    image r_sue_02 = Movie(play="images/e05/05_0947.webm", loop=False, keep_last_frame=True)
    show r_sue_02
    pause
    show expression "05_0948" + aaa with dissolve
    pause
    scene 05_0949 with dissolve
    image r_sue_03 = Movie(play="images/e05/05_0950.webm")
    show r_sue_03
    mc "[whi]That's it, just like that."
    scene 05_0951 with dissolve
    image r_sue_04 = Movie(play="images/e05/05_0952.webm")
    show r_sue_04
    sue "[ss]..Mmhh..."
    show expression "05_0953" + aaa with dissolve
    show expression "05_0954" + aaa with dis1
    if not _in_replay:
        pause 0.5
        $ tCh=None
        if not EzModeActive:
            $ dia="Tell "+ ("the girls they " if persistent.SueRP02Dat[0] else "Kiyomi she ")+ "can leave"
            menu:
                "[wk_y][dia]":
                    $ tCh=True
                "Say nothing":
                    pass
        else:
            $ tCh=True
        if tCh:
            $ persistent.SueRP02Dat[1]=True
            mc "You are excused."
            $ Kiyomi.Add("Stay")
            if persistent.SueRP02Dat[0]:
                scene 05_0957 with dissolve
                pause 0.5
                scene 05_0958 with dissolve
                ki "No. We stay."
            else:
                scene 05_0956 with dissolve
                ki "No. I stay."
        else:
            $ persistent.SueRP02Dat[1]=False
    show expression "05_0955" + aaa with dis1
    pause
    show expression "05_0959" + aaa with dissolve
    sue "[ss]..Mmhh..."
    scene 05_0960 with dissolve
    image r_sue_05 = Movie(play="images/e05/05_0961.webm")
    show r_sue_05
    sue "[ss]..MMMmhh..."
    scene 05_0962 with dissolve
    mc "Enough."
    scene 05_0963 with dissolve
    mc "Stand."
    show expression "05_0964" + aaa with dissolve
    mc "Remove your dress."
    show expression "05_0965" + aaa with dis1
    show expression "05_0966" + aaa with dis1
    show expression "05_0967" + aaa with dissolve
    mc "Bend over."
    show expression "05_0968" + aaa with dissolve
    pause
    show expression "05_0969" + aaa with dissolve
    pause
    scene 05_0970 with dissolve
    image r_sue_06 = Movie(play="images/e05/05_0971.webm", loop=False, keep_last_frame=True)
    show r_sue_06
    pause
    scene 05_0972 with dissolve
    sue "[ss]..Ohhh.."
    show expression "05_0973" + aaa with dissolve
    pause
    scene 05_0974 with dissolve
    image r_sue_07 = Movie(play="images/e05/05_0975.webm")
    show r_sue_07
    call Moan (sue)
    show expression "05_0976" + aaa with dissolve
    if not persistent.SueRP02Dat[0]:
        image r_sue_08 = Movie(play="images/e05/05_0977a.webm")
        show r_sue_08
    else:
        image r_sue_09 = Movie(play="images/e05/05_0977.webm")
        show r_sue_09
    sue "[ss]..Ohhh.."
    show expression "05_0978" + aaa with dissolve
    pause
    scene 05_0979 with dissolve
    image r_sue_10 = Movie(play="images/e05/05_0980.webm")
    show r_sue_10
    sue "[ss]...Yes....Mmhhh....."
    scene 05_0981 with dissolve
    sue "[ss]...OHHH.....YES....."
    scene 05_0982 with dissolve
    sue "[ss].....OHHHHHHH......."
    scene 05_0983 with dissolve
    image r_sue_11 = Movie(play="images/e05/05_0984.webm")
    show r_sue_11
    sue "[ss].....YESS....MHHHHHH....."
    show expression "05_0985" + aaa with dissolve
    sue "[ss].....OHHH......YES....PLEASURE ME....."
    scene 05_0986 with dissolve
    image r_sue_12 = Movie(play="images/e05/05_0987.webm")
    show r_sue_12
    sue "[ss]...YES..YES...."
    sue "[ss]...{b}FUCK ME{/b}....OHHHHH...YES....."
    scene 05_0988 with dissolve
    sue "[ss].....OHHHHHHH......."
    scene 05_0989 with dissolve
    image r_sue_13 = Movie(play="images/e05/05_0990.webm")
    show r_sue_13
    sue "[ss]...OHHH....."
    sue "[ss]...YES....YES....."
    call CharCum ("e05/05_0989.webp", "e05/05_0991.webp", sue, "....OHHHHH!!....")
    call CharCum ("e05/05_0991.webp", "e05/05_0992.webp", sue, "....Mmmmmhhhhhhh....")
    scene 05_0993 with dissolve
    sue "[ss]..Mmhh..."
    scene 05_0994 with dissolve
    image r_sue_14 = Movie(play="images/e05/05_0995.webm")
    show r_sue_14
    mc "[ss]..Nnhh..."
    call CharCum ("e05/05_0994.webp", "e05/05_0996.webp", mc, "..NNNGGGGGHHHH!!...")
    $ Sue.incCm()
    show expression "05_0997" + aaa with dissolve
    pause
    show expression "05_0998" + aaa with dissolve
    mc "I think she's relaxed."
    ki "[whi][giggles]"
    show expression "05_0999" + aaa with fade
    sue "[whi]I shall be in touch."
    if _in_replay:
        scene black with ReplayFade
    elif persistent.SueRP02Dat[0]:
        scene 05_0929 with dissolve
        pause 0.5 
return

label SueReplay03:
    call Unlocker ("SueReplay03")
    if not _in_replay:
        $ Sue.incSex()
        scene 14_0289 with fade1
        sue "My bed."
        scene 14_0290 with dissolve
        sue "Do you have any {i}other{/i} demands before we can begin?"
        scene 14_0291 with dissolve
        mc "Just one."
        mc "Cut the bullshit."
        scene 14_0292 with dissolve
        mc "In {i}this{/i} room, I only want to see {b}you{/b}. The {i}real{/i} you."
        scene 14_0293 with dissolve
        mc "Stop hiding behind the mask."
        mc "You {b}can{/b} trust me."
        scene 14_0294 with dissolve
        sue "[whi]Can I?"
        scene 14_0295 with dissolve
        mc "[whi]You can."
        scene 14_0296 with dis1
        mc "[kiss]"
        scene 14_0297 with dis1
        sue "[whi]... Okay."
        scene 14_0298 with dis1
        sue "[ss]Mmh."
        scene 14_0299 with dissolve
    else:
        scene 14_0299 with Fade(0,0,2)
    pause 0.5
    scene 14_0300 with dis1
    sue "[ss]Mmh."
    $ aP(True)
    scene 14_0301 with dis1
    $ apause()
    scene 14_0302 with dis1
    $ apause()
    scene 14_0303 with dis1
    $ apause()
    scene 14_0304 with dis1
    $ apause(0.5, True)
    scene 14_0305 with dis1
    sue "[ss]..Mmmmh.."
    scene 14_0306 with dis1
    sue "[whi]I want to be naked with you."
    scene 14_0307 with fade1
    $ apause()
    scene 14_0308 with dis1
    scene 14_0309 with dis1
    $ apause()
    scene 14_0310 with dis1
    scene 14_0311 with dis1
    $ apause()
    scene 14_0312 with dis1
    $ apause()
    scene 14_0313 with dissolve
    sue "[ss]..Ohhh, God..."
    scene 14_0314 with dissolve
    sue "[ss]...Ohhhh..."
    scene 14_0315 with dissolve
    image SueR03_01 = Movie(play="images/e14/14_0316.webm")
    show SueR03_01
    pause
    scene 14_0317 with dissolve
    call Moan (sue)
    scene 14_0318 with dissolve
    pause 0.5
    scene 14_0319 with dis1
    sue "[ss]...Ohhh...That's so good..."
    scene 14_0320 with dissolve
    scene 14_0321 with dis1
    scene 14_0322 with dis1
    call Moan (sue)
    scene 14_0323 with dissolve
    sue ".[ss].OHHHHH.."
    scene 14_0324 with dissolve
    sue "[ss]...Fuck...."
    scene 14_0325 with dissolve
    call Moan (sue)
    scene 14_0326 with dissolve
    sue "[ss]Let me do you."
    scene 14_0327 with fadehold
    pause
    scene 14_0328 with dissolve
    pause
    scene 14_0329 with dis1
    scene 14_0330 with dis1
    scene 14_0331 with dis1
    sue "[ss]Nnh."
    scene 14_0332 with dissolve
    pause
    scene 14_0333 with dissolve
    image SueR03_02 = Movie(play="images/e14/14_0334.webm")
    show SueR03_02
    image SueR03_04 = Movie(play="images/e14/14_0336.webm")
    pause
    image SueR03_03 = Movie(play="images/e14/14_0335.webm", loop=False, keep_last_frame=True)
    show SueR03_03
    pause 1.0
    show SueR03_04
    sue "[ss]Mmmh."
    scene 14_0337 with dissolve
    image SueR03_05 = Movie(play="images/e14/14_0338.webm")
    show SueR03_05
    pause
    scene 14_0339 with dissolve
    image SueR03_06 = Movie(play="images/e14/14_0340.webm")
    show SueR03_06
    sue "[ss]..Mmmhh.."
    scene 14_0341 with dissolve
    pause
    scene 14_0342 with dissolve
    image SueR03_07 = Movie(play="images/e14/14_0343.webm")
    show SueR03_07
    sue "[ss]..Mmmhh.."
    scene 14_0344 with dissolve
    image SueR03_08 = Movie(play="images/e14/14_0345.webm")
    show SueR03_08
    mc "[whi]...Fuuck....Keep takin' it all...."
    sue "[ss]..Mhh.."
    scene 14_0346 with dissolve
    mc "[whi]...Goddamn, that feels good....."
    scene 14_0347 with dissolve
    sue "[ss]..Mmmhh.."
    scene 14_0348 with dissolve
    scene 14_0349 with dis1
    mc "[whi]Come here."
    scene 14_0350 with dis1
    scene 14_0351 with dis1
    scene 14_0352 with dis1
    sue "[ss]Mmmh."
    scene 14_0353 with dissolve
    image SueR03_09 = Movie(play="images/e14/14_0354.webm", loop=False, keep_last_frame=True)
    show SueR03_09
    pause 5.0
    sue "[ss]..Mmmhh.."
    scene 14_0355 with dissolve
    image SueR03_10 = Movie(play="images/e14/14_0356.webm")
    show SueR03_10
    pause
    scene 14_0357 with dissolve
    image SueR03_11 = Movie(play="images/e14/14_0358.webm")
    show SueR03_11
    call Moan (sue)
    scene 14_0359 with dissolve
    sue "[ss]..Mmmhh.."
    scene 14_0360 with dissolve
    image SueR03_12 = Movie(play="images/e14/14_0361.webm")
    show SueR03_12
    pause
    scene 14_0362 with dissolve
    call Moan (sue)
    scene 14_0363 with dissolve
    sue "[ss]..Mmmhh.."
    scene 14_0364 with dissolve
    image SueR03_13 = Movie(play="images/e14/14_0365.webm")
    show SueR03_13
    call Moan (sue)
    scene 14_0366 with dissolve
    sue "[ss]..Ohhhh.."
    scene 14_0367 with dissolve
    image SueR03_14 = Movie(play="images/e14/14_0368.webm")
    show SueR03_14
    sue "[ss].....Ohhh......"
    scene 14_0369 with dissolve
    image SueR03_15 = Movie(play="images/e14/14_0370.webm")
    show SueR03_15
    call Moan (sue)
    scene 14_0371 with dissolve
    image SueR03_16 = Movie(play="images/e14/14_0372.webm")
    show SueR03_16
    sue "[ss]....Ohhh......Yes......"
    scene 14_0373 with fadehold
    call Moan (sue, 7)
    scene 14_0374 with dissolve
    image SueR03_17 = Movie(play="images/e14/14_0375.webm")
    show SueR03_17
    sue "[ss]....YES......"
    sue "[ss]....Ohhh, [persistent.McName], yes......"
    scene 14_0376 with dissolve
    image SueR03_18 = Movie(play="images/e14/14_0377.webm")
    show SueR03_18
    call Moan (sue)
    scene 14_0378 with dissolve
    image SueR03_19 = Movie(play="images/e14/14_0379.webm")
    show SueR03_19
    pause
    scene 14_0380 with dissolve
    sue "[ss]....OHHH......"
    scene 14_0381 with dissolve
    image SueR03_20 = Movie(play="images/e14/14_0382.webm")
    show SueR03_20
    sue "[ss]....FUCK.......YES.......OHHHHHH...."
    scene 14_0383 with dissolve
    image SueR03_21 = Movie(play="images/e14/14_0384.webm")
    show SueR03_21
    call Moan (sue, 10)
    sue "[ss]....YES.....OHHH, [persistent.McName!u].......GOD......"
    scene 14_0385 with dissolve
    image SueR03_22 = Movie(play="images/e14/14_0386.webm")
    show SueR03_22
    call Moan (sue, 10)
    scene 14_0387 with dissolve
    image SueR03_23 = Movie(play="images/e14/14_0388.webm")
    show SueR03_23
    sue "[ss]....OHHHHH, YES...."
    sue "[ss]...YES........FUCK........OHHHHHHH..."
    call CharCum ("e14/14_0387.webp", "e14/14_0389.webp", sue, "....OHHHHH....")
    call CharCum ("e14/14_0389.webp", "e14/14_0390.webp", sue, "....Mmmmmhhhhhhh....")
    scene 14_0391 with dissolve
    image SueR03_24 = Movie(play="images/e14/14_0392.webm")
    show SueR03_24
    pause
    if persistent.Anal:
        call CmOpts (["Cum inside Sue", "Pull out", "Cum in her ass"])
    else:
        call CmOpts (["Cum inside Sue", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Sue.incCm()
        call CharCum ("e14/14_0391.webp", "e14/14_0394.webp", mc, "..NNNGGGGGHHH..")
        call CharCum ("e14/14_0394.webp", "e14/14_0395.webp", mc, "....Nnnnhhhh....")
        scene 14_0396 with dissolve
        mc "[whi]...Fuck..."
        sue "[whi]Mmhhh. Indeed."
        scene 14_0397 with dissolve
        pause
    elif Copt==2:
        scene 14_0402 with dis1
        scene 14_0403 with dis1
        sue "[whi]I just knew you were an {i}ass{/i} man."
        scene 14_0404 with dissolve
        image SueR03_25 = Movie(play="images/e14/14_0405.webm", loop=False, keep_last_frame=True)
        show SueR03_25
        pause 3.0
        sue "[ss]..Fuuuuck..."
        scene 14_0406 with dissolve
        image SueR03_26 = Movie(play="images/e14/14_0407.webm")
        show SueR03_26
        sue "[ss]..Ohhh.."
        scene 14_0408 with dissolve
        image SueR03_27 = Movie(play="images/e14/14_0409.webm")
        show SueR03_27
        pause
        scene 14_0410 with dissolve
        sue "[ss]Aaahhhh.....Fuck.....Yes...."
        scene 14_0411 with dissolve
        image SueR03_28 = Movie(play="images/e14/14_0412.webm")
        show SueR03_28
        pause
        scene 14_0413 with dissolve
        image SueR03_29 = Movie(play="images/e14/14_0414.webm")
        show SueR03_29
        sue "[ss]...NNNHHHH..."
        scene 14_0413 with dis1
        scene 14_0415 with dis1
        scene 14_0416 with dis1
        image SueR03_30 = Movie(play="images/e14/14_0417.webm")
        show SueR03_30
        sue "[ss]......FUCK......OHHHH....."
        scene 14_0418 with dissolve
        sue "[ss]....GOD....AAHHH......YES...."
        scene 14_0419 with dissolve
        image SueR03_31 = Movie(play="images/e14/14_0420.webm")
        show SueR03_31
        sue "[ss]...OHHHH....."
        pause
        call CharCum ("e14/14_0419.webp", "e14/14_0421.webp", mc, "..NNNGGGGGHHH..")
        call CharCum ("e14/14_0421.webp", "e14/14_0422.webp", mc, "....Nnnnhhhh....")
        scene 14_0423 with dissolve
        mc "[whi]...Fuck..."
        sue "[whi]Mmhhh. Indeed."
        scene 14_0424 with dissolve
        pause
    else:
        call CharCum ("e14/14_0391.webp", "e14/14_0398.webp", mc, "..NNNGGGGGHHH..")
        call CharCum ("e14/14_0399.webp", "e14/14_0400.webp", mc, "....Nnnnhhhh....")
        scene 14_0401 with dissolve
        mc "[whi]...Fuck..."
        sue "[whi]Mmhhh. Indeed."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
