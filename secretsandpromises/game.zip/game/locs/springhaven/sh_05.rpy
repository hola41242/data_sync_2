label Springhaven_PriorityAssignment:
    if Mary.isActive() or Mary.Has("Cell"):
        $ Plr.Add("MaryPath")
    elif Sarah.isActive() or Sarah.Has("Couch"):
        $ Plr.Add("SarahPath")
    scene 05_1009 with Fade(2, 3, 2)
    pause
    scene 09_0335 with fade
    pause 0.5
    scene 09_0336 with dissolve
    ki "Take a seat. She'll be one moment."
    mc "Thanks, Kiyomi.\nAny idea why I'm here?"
    ki "No."
    scene 09_0337 with dissolve
    if MiyukaDelivered:
        mc "How's your sister?"
        ki "She's okay.\nShe misses home. We both do."
    elif MiyukaEscaped:
        mc "Any news on your sister?"
        ki "No.\nHave you heard anything??"
        mc "No, sorry."
    else:
        mc "Did your sister arrive here okay?"
        ki "Yes. No thanks to you.\nShe was delivered like an animal - in a cage."
        mc "Shit, I'm sorry. I didn't know."
    if Sue.L<1:
        mc "I gotta ask... Why do you sometimes talk in broken English?"
        ki "I was {i}ordered{/i} to talk that way, especially in front of guests."
        ki "I'm from Northcrest! I speak English perfectly well."
    mc "Did you believe Sue when she said she wanted to help you?"
    scene 09_0338 with dissolve
    ki "I... don't know.\n{i}Why{/i} would she?"
    if not MiyukaDelivered and Sue.L<1:
        ki "She's the reason we're in this mess!\nShe's the one threatening our mother to work for her!"
        scene 09_0339 with dissolve
        mc "She's threatening your mom? What does she want her to do?"
        ki "I... I don't know."
    else:
        ki "{i}She's{/i} the reason we're in this mess!"
        scene 09_0339 with dissolve
        mc "I agree."
    mc "Be careful, Kiyomi. We can't trust her.\nThere's more to this than she's telling me."
    scene 09_0340 with dissolve
    ki "Yeah."
    scene 09_0341 with dissolve
    sue "One of our employees has been arrested."
    sue "I need you to go to the police station to pick him up and take him home."
    scene 09_0342 with dissolve
    mc "Are you kidding?!\nYou dragged me over here for {i}that{/i}??"
    mc "Send a cab to pick him up!"
    sue "It's an order, not a request."
    scene 09_0343 with dissolve
    sue "You will meet Mr Wilkinson at the station.\nHe will facilitate the release."
    mc "Mr Wilkinson?"
    scene 09_0344 with dissolve
    sue "He handed you the file you'd requested."
    mc "Right."
    mc "Can't you send someone else? I'm kinda busy."
    scene 09_0345 with dissolve
    sue "No one else is available at this time."
    sue "A situation has arisen that calls for the majority of our employees to attend."
    mc "But... not me?"
    scene 09_0346 with dissolve
    sue "Correct."
    sue "You have yet to prove yourself trustworthy to {i}us{/i}."
    scene 09_0347 with dissolve
    mc "What did this {i}employee{/i} do to get himself arrested?"
    sue "He assaulted a police officer."
    mc "And they're just gonna let him walk??"
    scene 09_0348 with dissolve
    sue "With assistance from Mr Wilkinson, yes."
    mc "So I just pick him up and take him home?"
    sue "Yes.\nContact me once you've escorted him home."
    scene 09_0349 with dissolve
    mc "Fine."
    sue "We need him back to work immediately."
    scene 09_0350 with Fade(2, 3, 2)
    pause
    scene 09_0351 with fade
    pause
    scene 09_0352 with dissolve
    call Emotion (mc, "Sigh")
    scene 09_0353 with dissolve
    mct "This is beyond a fuckin' joke now!"
    scene 09_0354 with dissolve
    mc "Officer, I've been sitting in that goddamn chair for hours!"
    mc "Did you tell Wilkinson I'm here??"
    cop "Yes. He's a busy guy."
    scene 09_0355 with dissolve
    mc "This is bullshit!"
    mc "Tell him again."
    cop "Take a seat, sir.\nHe knows you're here; he'll get to you as soon as he can."
    scene 09_0356 with dissolve
    mc "{b}It's fuckin' bullshit!"
    call CenterText ("Two hours later...", True)
    scene 09_0357 with Fade(0, 0, 2)
    pause
    play sound "text.mp3"
    pause 1.0
    scene 09_0358 with dissolve
    pause 0.5
    show screen CellPhone("Alysha")
    msg_nvl "What the hell are you doing at the station??"
    msg_nvl "I just saw you at the front desk!"
    msg_nvl "You're not looking for me, are you?"
    mc_nvl "No. Sue sent me here. Waiting on Wilks."
    msg_nvl "Why?"
    mc_nvl "One of her guys was arrested. wants me to get him out."
    msg_nvl "OK. Call me later, we'll talk."
    msg_nvl "Yeah."
    call CloseCell ()
    $ Wilks_name="Wilks"
    scene 09_0359 with fade1
    pause 0.5
    scene 09_0360 with dissolve
    wilks "Can you stop harassing the desk sergeant!"
    scene 09_0361 with dissolve
    mc "About damn time!\nI've been sittin' here all day!"
    mc "Where's the guy?"
    wilks "I'm workin' on it!"
    scene 09_0362 with dissolve
    wilks "He punched a fuckin' cop in the face!\nI can't just walk him outta here like it's nothin'."
    wilks "It's gonna take another hour."
    scene 09_0363 with dissolve
    wilks "Stay the fuck away from the desk!\nI'm movin' as fast as I can!"
    call CenterText ("Three hours later...", True)
    scene 09_0364 with Fade(0, 0, 2)
    pause
    scene 09_0365 with dissolve
    wilks "Make sure he doesn't come back any time soon..."
    wilks "It's {i}my{/i} ass on the line."
    scene 09_0366 with dissolve
    wilks "Get the hell outta here."
    if Plr.Has("MaryPath"):
        mc "[whi]You're shittin' me!"
    scene 09_0367 with dissolve
    bill "Where's my damn rig?"
    wilks "I've already told you!\nIt's been impounded; nothing I can do till tomorrow."
    bill "I ain't leavin' without my rig!"
    wilks "Bill, go home while you still can!"
    $ Bill_name="Bill"
    scene 09_0368 with dissolve
    wilks "Take him!"
    mc "Let's go, Bill."
    if Plr.Has("MaryPath"):
        bill "[mc]? What the hell you doin' here?"
    else:
        bill "Who the hell are you?"
    mc "I'm your ride."
    scene 09_0369 with dissolve
    if Plr.Has("MaryPath"):
        bill "Did Mary call you?\nHow'd she find out I was here??"
        mc "Mary didn't call me, Bill.\nSue did."
        scene 09_0370 with dissolve
        bill "Sue??\nHow the hell do you know {i}her{/i}?"
        mc "Same as you. She's my boss, too."
        scene 09_0371 with dissolve
        bill "Whoa! You're a crook?!\nI thought you were a good guy! I invited you into my home!"
        mc "I'm not a crook!\n{i}You're{/i} the one workin' for her, Bill!"
        bill "I don't work for her! I'm my own damn boss!"
        scene 09_0372 with dissolve
        bill "And didn't you just call her {i}your{/i} boss?"
        mc "... Yeah.\nIt's complicated. Come on."
    else:
        bill "You one of Sue's men?"
        mc "Yeah."
        scene 09_0370 with dissolve
        bill "You couldn't come earlier?"
        mc "Are you fuckin' serious?"
        mc "I've been sitting in there all damn day waitin' on you!"
        scene 09_0371 with dissolve
        bill "Whoa! Okay, Son.\nDidn't mean any offense."
        bill "My Mary's gonna be worried sick if I don't get home.\nLeft my cell in the rig, so can't even call her."
        mc "Don't worry. That's why I'm here - to take you home."
        scene 09_0372 with dissolve
        bill "You won't tell her where I was, will ya, Son?"
        mc "None of my business. Come on."
    scene 09_0373 with fade
    play sound "car_pull.mp3" volume 0.5
    pause 0.5
    scene 09_0374 with dis1
    scene 09_0375 with dis1
    scene 09_0376 with dis1
    scene 09_0377 with fade1
    if not Plr.Has("MaryPath"):
        jump Springhaven_MeetMaryAlt
    mc "Damn, Bill... Why the hell are you involved with Sue?"
    bill "Needed the money."
    scene 09_0378 with fade1
    bill "You comin' in, Son?\nSure Mary won't be as angry with me if she sees you!"
    mc "Yeah.\nSue wants me to call her when you're home."
    scene 09_0379 with fadehold
    bill "Good to be home!"
    scene 09_0380 with dissolve
    bill "C'mon, Son."
    scene 09_0381 with dissolve
    bill "Pumpkin, I'm home!"
    scene 09_0382 with dissolve
    bill "Mary? You givin' me the silent treatment again?"
    mar s "[whi]Yes."
    bill "Okay then."
    scene 09_0383 with dissolve
    bill "I'm sorry, {b}[mc]{/b}.\nMary isn't in the mood for company today..."
    bill "You'll have to come back some other time!"
    mar sh "{b}WHAT??"
    mar sh "You're lyin', Pops!"
    scene 09_0384 with dissolve
    mc h "Hi, Mary."
    scene 09_0385 with dissolve
    mar "[mc]! I didn't know you were comin' over!"
    scene 09_0386 with dissolve
    mar "I'm still mad at {i}you{/i}, Pops!"
    scene 09_0387 with dissolve
    bill "Just a little {i}less{/i} mad though, right, Pumpkin?"
    mar "... A little."
    scene 09_0388 with dissolve
    bill "[lol]"
    scene 09_0389 with dissolve
    mar "Are you staying over?"
    mc "No, not this time.\nI just wanted to make sure Bill got home."
    scene 09_0390 with dissolve
    mar "Oh."
    mar "Can you stay a little while, at least?"
    scene 09_0556 with dissolve
    mc "Sure.\nI need to make a phone call first."
    mar "Okay."
    scene 09_0557 with dissolve
    pause 0.5
    call Springhaven_CallSue
    scene 09_0411 with dissolve
    mc "Change of plan. Looks like I'm stayin'."
    scene 09_0412 with dissolve
    mar "You are?"
    bill "You're welcome to stay anytime, Son."
    scene 09_0413 with dissolve
    mc "Thanks, Bill."
    mar "I'll make you a coffee!"
    scene 09_0414 with dissolve
    mc "Sue told me I need to stay and keep an eye on you."
    bill "Keep an eye on {b}me{/b}??\nWhat the hell does she think I'm gonna do?"
    mc "Were you drunk when the cops pulled you over?\nShe seemed to think so... Needs you sober for a delivery in the morning."
    scene 09_0415 with dissolve
    bill "{b}Drunk??{/b} I wasn't drunk!"
    bill "It was my medication!\nI was in pain!"
    bill "I had to take a couple extra, and they made me a little light-headed! {b}Goddamn!!"
    scene 09_0416 with dissolve
    mc "Pain meds?\nShit, Bill... Are you okay?"
    mc "Can't you take a few days off?\nSue will just have to find someone else for her damn delivery."
    scene 09_0417 with dissolve
    bill "Don't worry about me, Son. I'm fine. Gettin' old, that's all."
    mc "Punchin' a cop in the face doesn't sound like summat an old man would do."
    scene 09_0418 with dissolve
    bill "Asshole deserved it!\nPulled me over and started accusin' me of being drunk!"
    bill "Tried tellin' him it was my medication... I'd never drink and drive!"
    bill "He wouldn't listen!"
    bill "I..."
    scene 09_0419 with dissolve
    call Emotion (bill, "Sigh", "Yeah, I lost my temper a little.")
    bill "I knew Mary would be worrying about me.\nJust wanted to get home."
    scene 09_0420 with dissolve
    mc "You know, you could've called me.\nI would've come over to keep her company 'till you got home."
    bill "Yeah. They wouldn't let me use my phone."
    mc "Why you even workin' for Sue?? She's not the kinda person you want to get involved with."
    scene 09_0421 with dissolve
    bill "Son, it wasn't outta choice.\nWork dried up, bills keep comin' in... and getting bigger."
    bill "She was my last throw of the dice.\nWithout her contract, I'd be finished."
    bill "Ain't doin' it for {i}me{/i}."
    scene 09_0422 with dissolve
    mc "Yeah, I get it."
    mc "But, please, do something for me - go rest.\nGet a good night's sleep...and keep the meds to a minimum."
    bill "Fair enough, Son. Can't argue with that."
    scene 09_0423 with dissolve
    mar "Here's your coffee!"
    mc "Thanks, Sweetie."
    scene 09_0424 with dissolve
    bill "Pumpkin, I'm gonna shower and lie down. Your old Pops needs some rest!"
    scene 09_0425 with dissolve
    mar "You okay, Pops?\nI'm not mad with you really!"
    bill "I know, Darlin'. I'm just tired."
    mar "Okay.\nGoodnight."
    scene 09_0426 with dissolve
    mar "Oh, shoot!\nI'd better go make up the bed!"
    scene black with Fade(1, 2, 1)
    call CenterText ("30 minutes later.")
    scene 09_0558 with dissolve
    mct "Sittin' around all day in that damned station. Fuckin' exhausting!"
    mct "Looks like Mary's gone to bed, too."
    mct "Might as well do the same."
    scene 09_0559 with dissolve
    mct "Sounds like it's gonna be an early start tomorrow."
    scene 09_0560 with dis1
    scene 09_0561 with dis1
    scene 09_0562 with dis1
    if not Mary.isSexual():
        jump Springhaven_MaryGoToSleep
    scene 09_0563 with dis1
    scene 09_0564 with dis1
    mar "Hi."
    scene 09_0565 with dissolve
    mc "Jesus!\nYou almost gave me a coronary!"
    scene 09_0566 with dissolve
    mar "Sorry!"
    scene 09_0567 with dissolve
    $ dia = "Can we have sex again" + (", Daddy?" if persistent.MaryDaddy else "?")
    mar "[whi][dia]"
    scene 09_0565 with dissolve
    pause 0.5
    $ tCh=True
    if not EzModeActive:
        menu:
            "Not with Bill in the house!":
                $ tCh=False
            "[wk_y]Damn straight we can!":
                pass
    if tCh:
        call MaryReplay04
    else:
        $ Mary.Add("Refused")
        scene 09_0568 with dissolve
        mar "Oh... Sorry."
        scene 09_0569 with dissolve
        mc "It's too risky with Bill here. I'm sorry, Mary."
        mar "[whi]Okay."
        jump Springhaven_MaryGoToSleep
    scene 09_0727 with Fade(0, 3, 3)
    mc "[whi]..Zzzz.."
    play sound "gunloading.mp3"
    pause 1.0
    scene 09_0728 with dissolve
    mc "[whi]What the fuck??"
    scene 09_0729 with dissolve
    bill "Get outta my house."
    scene 09_0730 with dissolve
    mc "Bill??"
    call Emotion (mar, "Groan", "", True)
    scene 09_0731 with dissolve
    mc "[whi]Ah fuck."
    bill "Won't tell ya again!"
    scene 09_0732 with dissolve
    mc "Okay, Bill... Take it easy. I'm leaving."
    scene 09_0733 with dissolve
    mar "{b}POPS?!{/b}" with vpunch
    bill "Go get dressed, Mary."
    scene 09_0734 with dissolve
    mc "I'm gettin' outta bed, Bill... Be careful with that thing."
    bill "SLOWLY."
    scene 09_0735 with dissolve
    mar "WHAT ARE YOU DOIN'??"
    bill "Protecting you, Pumpkin."
    scene 09_0736 with dissolve
    mar "Protecting me?!"
    mar "From what, Pops??\n[mc]?!"
    mar "Put down the gun!"
    scene 09_0737 with dissolve
    mc "Relax, Bill.\nI'm leavin', just like you want."
    mar "POPS! PUT THE GUN DOWN!"
    mar "I love him!"
    scene 09_0738 with dissolve
    bill "What the hell you talk--"
    scene 09_0739 with dissolve
    mc "Bill?"
    scene 09_0740 with dissolve
    call Emotion (bill, "Groan", "", True)
    scene 09_0741 with dissolve
    mc "Shit... I got you..."
    scene 09_0742 with dissolve
    mar "Pops?"
    scene 09_0743 with dissolve
    mc "Mary, call 9-1-1!\nHe's having a heart attack."
    mar "OH MY GOD!"
    jump Springhaven_BillHospital
return

label Springhaven_MeetMaryAlt:
    bill "I'm still gettin' paid, right?"
    mc "Sue told me to pick you up and take you home.\nThat's all I know."
    scene 09_0378 with fade1
    bill "Slow down, Son. The turn's just up ahead."
    scene 09_0379 with fadehold
    bill "You can pull up anywhere here."
    scene 09_0380 with dissolve
    bill "C'mon in."
    scene 09_0381 with dissolve
    bill "Pumpkin, I'm home!"
    scene 09_0382 with dissolve
    bill "You givin' me the silent treatment again?\nC'mon, don't be mad at me!"
    scene 09_0391 with dissolve
    bill "Look, I've brought a new friend home to meet you!"
    scene 09_0392 with dissolve
    bill "This is... err..."
    mc "[mc]."
    bill "Yeah!"
    scene 09_0393 with dissolve
    bill "[mc], this is my granddaughter, Mary."
    $ Mary.Activate("Mary")
    $ persistent.MaryLocked=False
    scene 09_0394 with dissolve
    mar "Hello, I'm very pleased to meet you, [mc]."
    mc "Nice to meet you."
    scene 09_0395 with dissolve
    mar "Would you like a beverage?"
    mc "Uh, no thank you."
    mc "I'm just gonna make a call, and I'll be outta here."
    scene 09_0396 with dissolve
    mar "Are you sure? It's no trouble!"
    bill "I'd like a coffee!"
    scene 09_0397 with dissolve
    mar "{i}You{/i} can make your own!\nI'm still mad at you, Pops!"
    bill "C'mon, Pumpkin!\nThe rig broke down!"
    scene 09_0398 with dissolve
    mar "You should've called!\nI've been callin' you all day, but you didn't pick up!"
    scene 09_0399 with dissolve
    bill "My cell died! I couldn't charge it!"
    scene 09_0400 with dissolve
    bill "Mary, I'm sorry."
    mar "I'm glad you're okay, and happy you're home, Pops."
    scene 09_0401 with dissolve
    mar "But I'm still mad at you."
    bill "I know, Pumpkin. I know."
    scene 09_0402 with dissolve
    mc "I'll, uhh, make that call."
    call Springhaven_CallSue
    scene 09_0411 with dissolve
    mc "I'll take that coffee if it's still on offer."
    scene 09_0412 with dissolve
    mar "It sure is!"
    bill "You ain't leavin'?"
    scene 09_0413 with dissolve
    mc "Nope.\nSue told me I have to stay and keep an eye on you."
    scene 09_0414 with dissolve
    bill "Why the hell do ya need to keep an eye on {b}me{/b}?\nWhat does she think I'm gonna do??"
    mc "Get drunk again.\nShe needs you sober so you can do a delivery in the morning."
    scene 09_0415 with dissolve
    bill "{b}Drunk??{/b} I wasn't drunk!"
    bill "It was my medication!\nI was in pain!"
    bill "I had to take a couple extra, and they made me a little light-headed! {b}Goddamn!!"
    scene 09_0416 with dissolve
    mc "Whatever. Driving high is just as dangerous as driving drunk."
    mc "Should've taken a few days off if you couldn't handle it."
    scene 09_0417 with dissolve
    bill "You sound just like the damn cop who pulled me!"
    mc "Is that why you punched him?\nDidn't like hearing the truth?"
    scene 09_0418 with dissolve
    bill "No!\n I was tryin' to get home to my Mary! She worries about me!"
    bill "I told him to just give me the ticket so I could be on my way, but he refused to let me drive!"
    bill "I..."
    scene 09_0419 with dissolve
    call Emotion (bill, "Sigh", "Yeah, I lost my temper.")
    bill "I just wanted to get home."
    scene 09_0420 with dissolve
    mc "If you're in pain, Bill, why not tell Sue you can't do the delivery?"
    mc "She can find someone else for the job."
    scene 09_0421 with dissolve
    bill "No, Son!\nDon't say a word to her!"
    bill "I need the money!\nWe're barely gettin' by as it is!"
    scene 09_0422 with dissolve
    mc "Fine.\nJust do me a favor - go rest.\nGet a good night's sleep...and keep the meds to a minimum."
    bill "Fair enough, Son. Can't argue with that."
    scene 09_0423 with dissolve
    mar "Here's your coffee!"
    mc "Thank you, Sweetie."
    scene 09_0424 with dissolve
    bill "Pumpkin, [mc]'s gonna stay over.\nCan you show him to the guest room when he's ready?"
    mar "Sure thing, Pops!"
    scene 09_0425 with dissolve
    bill "I'm gonna go get some rest. It's been a long day."
    mar "Night."
    scene 09_0426 with dissolve
    mar "Oh, shoot!\nI'd better go make up the bed!"
    scene black with Fade(1, 2, 1)
    call CenterText ("30 minutes later.")
    scene 09_0427 with dis1
    scene 09_0428 with dis1
    scene 09_0429 with dis1
    mar "Did you finish the coffee?\nI can show you to your room now."
    mc "Uhh, yeah. Thanks."
    scene 09_0430 with dissolve
    mar "This way, follow me."
    mc "Yes Ma'am."
    mar "[giggles]"
    scene 09_0431 with fadehold
    pause 0.5
    scene 09_0432 with fade
    mar "This is you.\nI'm across the hall, should you need anything."
    scene 09_0433 with dissolve
    mc "Thanks, Mary. I'll be fine."
    scene 09_0434
    mar "I don't know how comfortable the bed is.\nIt hasn't been slept on for a while."
    scene 09_0435 with dissolve
    mc "Better than a slab of rock in the desert, I bet."
    mar "Huh?"
    scene 09_0436 with dissolve
    mc "Ohh... I uh, I used to be in the military, slept in some rough places over the years."
    scene 09_0437 with dissolve
    if EzModeActive:
        call EzModeAsk ("Mary")
        if _return:
            $ Mary.Add("EZ")
    mar "My dad was a soldier!"
    mc "Oh yeah?"
    scene 09_0438 with dissolve
    mar "He died.\nIt was a long time ago."
    mar "I don't remember him too much."
    scene 09_0439 with dissolve
    mc "Damn, I'm sorry, Mary. That sucks."
    scene 09_0440 with dissolve
    mc "I'm sure he was a great guy."
    mar "Pops misses him a lot."
    mc "Bill takes care of you?"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e09/09_0441.webp", 1023, 620, True, "Springhaven_AF31") with dissolve
        mar "Yeah, I guess."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 09_0441
            hide screen imgMap
    else:
        scene 09_0441 with dissolve
        mar "Yeah, I guess."
        if not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    call Springhaven_AF31
                "Don't":
                    pass
        elif Mary.Has("EZ"):
            call Springhaven_AF31
    $ a=""
    if Mary.hasScore(1):
        $ a="a"
    show expression "09_0445" + a with dissolve
    mar "Mom stops by now and then, but she's never been the same since Dad... you know."
    mar "You have family?"
    scene 09_0446 with dissolve
    mc "Yeah, two daughters."
    mar "Aww, they're so lucky!\nDo they take good care of you?"
    scene 09_0447 with dissolve
    mar "A daughter should always take care of her Daddy!"
    mar "I bet you're a good dad! I can tell."
    mc "You can?"
    scene 09_0448 with dissolve
    mar "Heck yeah!"
    $ persistent.MaryDaddy= False
    if Mary.hasScore(1):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e09/09_0449.webp", 994, 630, True, "Springhaven_AF32") with dissolve
            mar "If you were {i}my{/i} daddy, I'd take good care of you!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 09_0449
                hide screen imgMap
                mc "You would?"
                mar h "Of course!"
        else:
            scene 09_0449 with dissolve
            mar "If you were {i}my{/i} daddy, I'd take good care of you!"
            if not EzModeActive:
                menu:
                    "[wk_y]Check her out again":
                        call Springhaven_AF32
                    "Don't":
                        mc "You would?"
                        mar h "Of course!"
            else:
                call Springhaven_AF32
    scene 09_0454 with dissolve
    mar "I'll leave you to get settled."
    if persistent.MaryDaddy:
        scene 09_0455 with dissolve
        mar "Goodnight..."
        scene 09_0456 with dissolve
        mar h "... Daddy."
        mc "Night, Mary."
        scene 09_0457 with dissolve
        mar "[kiss]"
    scene 09_0458 with dissolve
    if persistent.MaryDaddy:
        mar "See you in the morning!"
    else:
        mar "Night. See you in the morning."
    scene 09_0459 with Fade(1, 0.5, 0.5)
    mct "Sitting around all day waiting is so damn draining!"
    if not Mary.hasScore(1):
        jump Springhaven_MaryGoToSleep
    scene black with Fade(2, 1, 2)
    call CenterText ("An hour or so later...", False)
    scene 09_0461 with fade
    pause 1.0
    scene 09_0462 with dissolve
    mct "Ughh..."
    mct "... So tired, must've dozed off."
    play sound "creak.mp3" volume 0.5
    "{size=*0.5}*Creak* {w=0.5}{nw}"
    scene 09_0463 with dissolve
    mc "[whi]Huh?"
    scene 01_0409 with dissolve
    pause 0.5
    scene 01_0410 with dissolve
    mct "Was that... Mary?"
    $ tCh=Mary.Has("EZ")
    if not EzModeActive:
        menu:
            "Close the door and go to bed":
                $ tCh=False
            "[wk_y]Leave the door open and get undressed":
                $ tCh=True
    if not tCh:
        scene 01_0411 with dissolve
        pause 0.5
        scene 01_0412 with dissolve
        play sound "closedoor.mp3"
        pause 0.5
        jump Springhaven_MaryGoToSleep
    scene 09_0464 with dissolve
    pause 1.0
    scene 01_0414 with dissolve
    mct "She still there?"
    scene 09_0465 with dissolve
    pause 1.0
    scene 09_0466 with dissolve
    pause 1.0
    if not EzModeActive:
        menu:
            "Keep underwear on":
                scene 09_0470 with dissolve
                pause 1.0
                scene 09_0471 with dissolve
                mar "[whi]Hot damn."
                call Springhaven_MaryRun
                scene 01_0424 with dissolve
                mct "Night, Mary!"
                jump Springhaven_MaryGoToSleep
            "[wk_y]Remove underwear":
                pass
    scene 09_0467 with dissolve
    pause 1.0
    scene 09_0468 with dissolve
    pause
    scene 09_0467 with dissolve
    scene 09_0469 with dissolve
    mar "{size=*.6}{font=Vanilla.ttf}*{i}Gasp{/i}*"
    scene 09_0471 with dissolve
    mar "[whi]Oh, my..."
    scene 09_0472 with dissolve
    mct "Heh... What the hell am I doing?"
    scene 09_0473 with dissolve
    pause 1.0
    scene 09_0474 with dissolve
    pause
    scene 09_0472 with dissolve
    if not EzModeActive:
        menu:
            "Get into bed and sleep":
                jump Springhaven_MaryGoToSleep
            "[wk_y]Start masturbating":
                pass
    mct "Fuck it!\nIf she wants to peep, I'll give her a show..."
    scene 09_0475 with dissolve
    pause 0.5
    scene 09_0476 with dis1
    pause 0.5
    scene 09_0477 with dissolve
    mar "{size=*.6}{font=Vanilla.ttf}*{i}GASP{/i}*"
    if Mary.hasScore(3):
        call MaryReplay01_Part02 (True)
        if Mary.Has("Ran"):
            scene 01_0431 with dissolve
            mc "Guess not."
            mc "Oh well, may as well finish before going to sleep!"
    else:
        call Springhaven_MaryRun
        scene 01_0431 with dissolve
        mc "[lol] Probably took it too far!"
        mc "Oh well, may as well finish before going to sleep!"
    jump Springhaven_MaryGoToSleep
return

label Springhaven_MaryGoToSleep:
    scene 09_0460 with Fade(2, 1, 2)
    call Emotion (mc, "Snore", "...ZzzzZZzz...")
    jump Springhaven_WakeupBillsAlt
return

label Springhaven_CallSue:
    scene 09_0403 with Fade(1, 0.5, 1)
    mc cell "Sue, it's me."
    mc cell "Job's done."
    sue cell "Good."
    sue cell "Has William left for the next pick-up?"
    scene 09_0404 with dissolve
    mc cell "William? Oh... Bill."
    mc cell "No. I brought him home as you said."
    sue cell "Yes.\nTake him home, get him cleaned up, and get him back to work."
    scene 09_0405 with dissolve
    mc cell "Yeah... that's not gonna happen.\nHis rig's been impounded."
    mc cell "Wilks said it won't be released until tomorrow."
    sue cell "That's unacceptable!"
    scene 09_0406 with dissolve
    mc cell "There's nothin' I can do about it!"
    sue cell "William must complete his next delivery.\nMuch depends on it!"
    mc cell "Again, there's {b}nothing{/b} I can do, Sue!"
    scene 09_0404 with dissolve
    mc cell "The delivery will have to wait until tomorrow."
    sue cell "..."
    sue cell "Do not let that man out of your sight until he's back to work."
    scene 09_0407 with dissolve
    if Plr.Has("MaryPath"):
        mc cell "He doesn't need babysitting, Sue!"
    else:
        mc cell "I'm not babysitting him!\nHe's a grown-ass man, Sue! He can take care of himself!"
    sue cell "Police officers pulled him over because he was driving erratically and they suspected he was drunk."
    sue cell "He {b}must{/b} remain sober until his vehicle is returned."
    sue cell "He is now {b}your{/b} responsibility, [mc]."
    scene 09_0408 with dissolve
    sue cell "I must remind Mr Wilkinson that I do not tolerate failure."
    sue cell "William shall have his vehicle returned come sunrise."
    sue cell "Once he is on his way... only then is it, as you would say, {i}job done{/i}."
    sue cell "Do you understand?"
    scene 09_0409 with dissolve
    mc cell "{size=*0.8}{font=Vanilla.ttf}*{i}Sigh{/i}*{/font}{/size}Fine."
    scene 09_0410 with dissolve
    if Plr.Has("MaryPath"):
        mct "She treats everyone like goddamn children."
    else:
        mct "Goddamnit."
return

label Springhaven_WakeupBillsAlt:
    scene 09_0727 with Fade(2, 3, 3)
    mc "[whi]..Zzzz.."
    scene 09_0744 with dissolve
    bill "Wake up, Son! We gotta go!"
    scene 09_0745 with dissolve
    call Emotion (mc, "Groan", "", True)
    bill "We ain't got time for breakfast.\nWe can make a stop on the way to Northcrest."
    mc "[whi]Okay."
    scene 09_0746 with dissolve
    mc "Wait... What do you mean {i}on the way to Northcrest{/i}??"
    bill "Sue called.\nTold me I have to take you along."
    scene 09_0747 with dissolve
    bill "C'mon, get dressed.\nThe detective's waitin' on us to pick up my rig."
    mc "[whi]Goddamnit."
    scene 09_0748 with fade2
    mc cell "Sue?\nWhy's Bill tellin' me I have to go with him to Northcrest?"
    sue cell "Because you do."
    sue cell "We cannot have any further delays or mishaps.\nThe shipment must arrive without incident."
    scene 09_0749 with dissolve
    sue cell "I've been given {i}my{/i} orders, and now you have yours."
    sue cell "Follow them."
    sue cell "Mr Wilkinson is impatiently awaiting your arrival at the impound."
    scene 09_0750 with dissolve
    call Emotion (mc, "Sigh")
    jump Springhaven_PoliceImpound
return

label Springhaven_BillHospital:
    $ BillSick=True
    play music "hos.mp3" volume 1.5 loop fadein 4.0
    scene 09_0751 with Fade(3, 3, 2)
    pause 1.0
    play sound "vib.mp3"
    pause 2.0
    stop sound
    scene 09_0752 with dissolve
    sue cell "Why haven't you picked up William's vehicle yet?\nMr Wilkinson is rightly getting impatient!"
    mc cell "We're at the hospital. Bill..."
    scene 09_0753 with dissolve
    mc cell "Bill had an angina attack.\nThere's no way he's gonna be able to drive today."
    sue cell "This is unacceptable!"
    scene 09_0754 with dissolve
    mc cell "Jesus, Sue! It's not like he had it on purpose!"
    scene 09_0755 with dissolve
    sue cell "This is not {b}our{/b} problem!\nIf he's unfit to drive, he should have someone else do it in his place!"
    sue cell "Our contract states that he collects and delivers the shipments. No excuses!"
    sue cell "He has broken that contract. Repercussions {b}must{/b} follow."
    scene 09_0756 with dissolve
    mc cell "Sue, I swear - if you do anything to Bill--"
    scene 09_0757 with dissolve
    sue cell "Choose your next words {b}very carefully{/b}, [mc]."
    mc cell "..."
    scene 09_0758 with dissolve
    mc cell "{b}I'll{/b} do it.\nI've had some training driving large military vehicles; I'm sure I can manage his truck."
    scene 09_0759 with dissolve
    sue cell "..."
    sue cell "An unexpected suggestion."
    sue cell "Very well. If you think you can handle it, you have my permission."
    scene 09_0760 with dissolve
    mc cell "Fine."
    mc cell "But Sue... Bill still gets paid. And his contract with you stands."
    sue cell "Why are you negotiating? What concern is it of yours?"
    scene 09_0761 with dissolve
    mc cell "He's a good guy. Just give him a chance to recover."
    sue cell "Is this you asking me for a favor?"
    mc cell "This is me asking you to {i}return{/i} the favor I did you when I went to Lakeshore."
    sue cell "..."
    scene 09_0762 with dissolve
    sue cell "Accepted.\nWilliam's contract will remain intact."
    sue cell "Go at once. I will forward you the collection and delivery addresses."
    mc cell "Okay."
    scene 09_0763 with dissolve
    mct "It's been a while... Sure I can handle it, though..."
    play sound "knock.mp3" volume 0.5
    scene 09_0764 with dissolve
    pause 1.0
    scene 09_0765 with dissolve
    pause 1.0
    scene 09_0766 with dissolve
    mc "[whi]Mary."
    scene 09_0767 with dissolve
    mc "[whi]Can I talk to you for a minute?"
    scene 09_0768 with dissolve
    mc "How's he doing?"
    mar "He's sleeping."
    scene 09_0769 with dissolve
    mc "He's gonna be okay.\nThe nurse told me they just wanna keep him in for a while to monitor him."
    mc "How are {b}you{/b} doing?"
    mar "I..."
    scene 09_0770 with dissolve
    mar "Is this my fault?"
    mc "Absolutely {b}not{/b}!"
    scene 09_0771 with dissolve
    mc "I'm the one to blame for this, Sweetheart."
    mar "But... we didn't do anything wrong!"
    mc "I don't want you worrying about this, Mary."
    scene 09_0772 with dissolve
    mc "Once Bill's home and feeling better, I'll talk to him and apologize."
    scene 09_0773 with dissolve
    mc "Come here."
    scene 09_0774 with dissolve
    mc "Everything's gonna be okay."
    mar "I hope so."
    scene 09_0775 with dissolve
    mc "I'm sorry, Sweetie, but I need to go."
    scene 09_0776 with dissolve
    mar "Go?? Why?"
    mc "Bill was supposed to make a delivery today.\nIf it doesn't get done, he'll lose the contract, so I'm gonna do it."
    mc "I'll come and check on you both as soon as I'm back."
    mar "Okay."
    stop music fadeout 1.0
    jump Springhaven_PoliceImpound
return

label Springhaven_PoliceImpound:
    if not BillSick:
        scene 09_0778 with Fade(3, 2, 2)
        bill "There'd better not be a damn scratch on her!"
        wilks "Count yourself lucky that you're gettin' it back."
        scene 09_0779 with dissolve
        bill "There she is! My baby!"
        scene 09_0781 with dissolve
        wilks "You make sure to tell Sue I've done everything that was asked of me!"
        bill "C'mon, Son! Time to get the hell outta here."
        play sound "truckstart.mp3" volume 0.5
        scene 09_0784 with dissolve
        call Emotion (wilks, "Mumbling")
        scene 09_0787 with Fade(2, 1, 2)
        mc "So what is it we're picking up from Northcrest?"
        scene 09_0788 with dissolve
        bill "Son, I can't afford to ask those kinda questions."
        mc "You don't know??"
        bill "Nope. Don't {i}wanna{/i} know.\nI pick up and drop off. That's what I'm paid to do."
    else:
        scene 09_0777 with Fade(3, 2, 2)
        wilks "Can you hurry the fuck up?"
        mc "Relax! I'm right behind you."
        scene 09_0780 with dissolve
        wilks "You'd better be able to drive this thing outta here.\nI'm not coming back!"
        scene 09_0782 with dissolve
        wilks "You make sure to tell Sue I've done everything that was asked of me!"
        mc "Tell her yourself."
        scene 09_0783 with dissolve
        call Emotion (wilks, "Mumbling")
        scene 09_0785 with dissolve
        mct "Whatever you do, [mc]... don't fuck the truck up...\nBill already wants to kill you."
        scene 09_0786 with dissolve
        play sound "truckstart.mp3" volume 0.5
        mct "Okay.\nNorthcrest, here I come."
        scene 09_0787 with Fade(2, 1, 2)
        pause 0.5
    call CenterText ("A few hours later.", True)
    call Northcrest_Pickup
    call Brookvale_Delivery
    jump Springhaven_BackFromDelivery
return

label Springhaven_BackFromDelivery:
    call CenterText ("A long drive home later...", True)
    $ curLOC=springhaven_id
    if Plr.Has("GotPackage2"):
        call Springhaven_TakeMiyukaToSue
    scene 09_0965 with Fade(2, 1, 2)
    pause 1.0
    if BillSick:
        scene 09_0966 with dissolve
        mc cell "Hi Mary.\nSorry, I know it's late."
        mc cell "Just got back and wanted to check in on you."
        mar cell "We're still at the hospital.\nThe doctors said Pops can go home tomorrow."
        mc cell "That's great news."
        mc cell "Do you want me to come and keep you company?"
        mar cell "No, it's okay.\nMy mom's here with me."
        mc cell "Oh, okay... Good."
        mc cell "If there's anything you need, Sweetie, don't hesitate to call."
        mar cell "Okay."
        mc cell "I'll call you again tomorrow.\nNight, Mary."
        mar cell "Night."
        scene 09_0967 with dissolve
        pause 1.0
    if not MiyukaSpringhaven:
        scene 09_0966 with dissolve
        mc cell "Hi Sue.\nJust wanted to let you know I'm back."
        sue cell "The delivery was completed without complication?"
        mc cell "Yeah.\nJemma wasn't happy it was late."
        sue cell "The happiness of that vile woman is of no importance."
        if BillSick:
            sue cell "How is William?"
            mc cell "He'll be okay.\nJust needs to take it easy for a few days."
        else:
            sue cell "And William?"
            mc cell "Did his job without issue."
        sue cell "Excellent."
        sue cell "I'm required in Cedar Grove tomorrow, so you may take a personal day."
        mc cell "Cedar Grove? Why?"
        sue cell "None of your concern."
        sue cell "If there's nothing else..."
        if Miyuka.Has("NTC"):
            menu:
                "Tell Sue about Miyuka":
                    $ Plr.Add("ToldSue")
                    $ MiyukaSpringhaven=True
                    mc cell "There is one more thing..."
                    mc cell "Kiyomi's sister.\nI saw her in Northcrest.\nShe's with her mother."
                    sue cell "Not surprising.\nWe expected her to appear there eventually."
                    sue cell "Good work.\nI'll arrange her collection."
                    sue cell "Goodbye."
                "Say nothing":
                    mc cell "No."
        else:
            mc cell "No."
        scene 09_0967 with dissolve
        pause 1.0
    scene 09_0968 with dissolve
    pause 1.0
    scene black with Fade(2, 3, 1)
    call Bruises (True)
    jump Springhaven_DayOfRest
return

label Springhaven_TakeMiyukaToSue:
    $ MiyukaSpringhaven=True
    $ MiyukaDelivered=True
    $ Plr.Del("GotPackage2")
    scene 09_0948 with Fade(2, 1, 2)
    scene 09_0949 with dis1
    scene 09_0950 with dis1
    mi "{b}This{/b} is where Kiyomi lives??"
    mc "Yeah."
    play sound "doorbell.mp3"
    scene 09_0951 with dissolve
    pause 1.0
    scene 09_0952 with dissolve
    pause 0.5
    scene 09_0953 with dissolve
    ki "Miyuka!\nI'm so glad you're okay!\nI've missed you!"
    mi "I've missed you too, Ki."
    scene 09_0954 with dissolve
    mi "What are you wearing??"
    ki "Don't worry about it.\nCome on, I'll show you to your room and we can talk."
    scene 09_0955 with dissolve
    ki "She's waiting for you in her office."
    scene 09_0956 with dissolve
    mc "I couldn't leave her there, Kiyomi.\nIf they'd have found her with your mom..."
    ki "I know."
    scene 09_0957 with dissolve
    pause 0.5
    scene 09_0958 with dissolve
    sue "Splendid work today."
    mc "Thanks."
    scene 09_0959 with dissolve
    mc "I need you to keep your word. No harm comes to her {i}or{/i} her mother."
    sue "I gave my assurance when you called and told me you had found her.\nNothing has changed."
    scene 09_0960 with dissolve
    sue "The delivery was completed without complication?"
    mc "Yeah.\nJemma wasn't happy it was late."
    scene 09_0961 with dissolve
    sue "The happiness of that vile woman is of no importance."
    if BillSick:
        sue "How is William?"
        scene 09_0962 with dissolve
        mc "He'll be okay.\nJust needs to take it easy for a few days."
    else:
        sue "And William?"
        scene 09_0962 with dissolve
        mc "Did his job without issue."
    sue "Excellent."
    scene 09_0963 with dissolve
    sue "I'm required in Cedar Grove tomorrow, so you may take a personal day."
    mc "Cedar Grove? Why?"
    sue "None of your concern."
    sue "You are excused."
    scene 09_0964 with dissolve
    sue "Goodnight."
return

label Springhaven_DayOfRest:
    scene 10_0001 with Fade(2, 4, 2)
    mc "Morning, Guys."
    ali "Good morning.\nNot like you to sleep so late!"
    scene 10_0002 with dissolve
    mc "Was a long day yesterday, I was {i}so{/i} drained by the time I got back!"
    ali "Sit down, I'll get you a coffee."
    mc "Thanks."
    scene 10_0003 with dissolve
    car "It must've been really late when you got home!\nI tried to wait up for you."
    mc "Yeah, it was. Sorry, Pipsqueak."
    scene 10_0004 with dissolve
    mc "Why were you waiting for me? Everything okay?"
    car "Yeah! Just wanted to spend some time with you."
    if Cara.isSexual():
        scene 10_0005 with dissolve
        car "[whi]I haven't been able to stop thinking about what we did."
        scene 10_0006 with dissolve
        pause 0.5
        scene 10_0007 with dissolve
        pause 0.5
        scene 10_0008 with dissolve
        mc "[whi]Same!"
        scene 10_0009 with dissolve
        car "[whi]So when can we do it again?"
        scene 10_0010 with dissolve
        mc "[whi]Soon, Pipsqueak."
        scene 10_0011 with dis1
        scene 10_0012 with dis1
        car "[whi]I'm all yours, Dad."
        scene 10_0013 with dissolve
        car "[whi]Yours, and nobody else's."
        scene 10_0014 with dissolve
        car "[whi]You're the only man who will ever fuck me."
        scene 10_0015 with dissolve
        ali "It's lovely to see you two grow even closer day-by-day."
        scene 10_0016 with dissolve
        ali "I'm so relieved the truth is finally out."
        scene 10_0017 with dissolve
        mc "Me too."
        scene 10_0018 with dissolve
        mc "We should all do something today!\nYou know, hang out, like a family."
        scene 10_0019 with dissolve
        ali "Oh, sorry [mc], I'd love to, but I've got work.\nMy shift starts in an hour."
        car "I can hang with you, Dad!"
        scene 10_0020 with dissolve
        ali "You have a class this morning!"
        car "I can skip!"
        scene 10_0021 with dissolve
        ali "No, you can't!"
        scene 10_0022 with dissolve
        mc "Your mom's right, no skipping classes."
        scene 10_0023 with dissolve
        car "But Dad...!"
        mc "Your education's important, Pipsqueak.\nWe can hang out another time."
        scene 10_0024 with dissolve
        ali "Your dad's right, Sweetheart."
        scene 10_0025 with dissolve
        ali "We can all do something together soon."
        scene 10_0026 with dissolve
        car "Oh! Like a family vacation?"
        scene 10_0027 with dissolve
        ali "Like spend an afternoon somewhere together!"
        scene 10_0028 with dissolve
        ali "Gosh, a vacation {i}would{/i} be nice though!"
        scene 10_0029 with dissolve
        car "So let's do it!"
        scene 10_0030 with dissolve
        ali "If only life were that easy!"
        scene 10_0031 with dissolve
        car "It could be if you {i}wanted{/i} it to be!"
        ali "[lol] You're gonna be late, go get ready!"
        scene 10_0032 with dissolve
        car "What do you say, Dad?\nYou and me, on vacation.\nMom doesn't want to come."
        ali "You'd drive him crazy within a day!"
        scene 10_0033 with dissolve
        car h "I {i}already{/i} drive him crazy![giggles]"
    else:
        mc "We can hang out today if you like."
        car "I've got a class soon. Maybe later, though?"
        mc "Yeah, of course."
        scene 10_0034 with dissolve
        car "Great!\nI'd better go get ready, or I'll be late."
        mc "Okay."
        scene 10_0035 with dissolve
        mc "How about you, Ali?\nFancy doin' something today?"
        ali "Oh, sorry [mc], I'd love to, but I've got work.\nMy shift starts in an hour."
    scene 10_0036 with dissolve
    if Alison.Has("Knows"):
        ali "Why were you back so late last night?"
        ali "I hope you weren't doing anything illegal for those assholes."
        scene 10_0037 with dissolve
        mc "No, of course not!"
        mc "I was helping a guy out with deliveries.\nSpent hours on the road in an old rattling truck!"
        scene 10_0038 with dissolve
        ali "I {b}hate{/b} that you're working for them."
        scene 10_0039 with dissolve
        mc "Ali, I'm not working for {i}them{/i}!"
        ali "It's too dangerous, [mc]!\nYou should tell the cops to find someone else."
        mc "We're making progress; it won't be for much longer, and we can put this whole thing behind us."
        scene 10_0040 with dissolve
        ali "If anything were to happen to you, I'd never forgive myself for dragging you into it."
        scene 10_0041 with dissolve
        mc "It was {b}my{/b} decision to get involved.\nIf there was another way to protect you and Cara, I would've taken it."
        mc "But I won't walk away, Alison - Not until I know you're both safe from these animals."
        mc "And if that means helping the police take them down, so be it."
        scene 10_0042 with dissolve
        mc "Please, try not to worry."
        ali "But I do, [mc]!\nI can't just switch it off!"
        mc "I know.\nAnd if you could do anything to help me, you would, right?"
        scene 10_0036 with dissolve
        ali "Yes, of course I would! Anything at all!"
        scene 10_0043 with dissolve
        ali "Ohh, okay! Smart-ass!"
        ali "That's exactly what {b}you're{/b} doing for me."
        scene 10_0044 with dissolve
        mc "Sorry. Couldn't help myself."
        ali "I get your point. I'll lay off you."
        ali "And I {b}do{/b} appreciate what you're doing for us.\nI just wish there was another way, that's all."
    else:
        ali "Can I ask you something?"
        ali "It's just... I'm curious...\nEven though you live here, I barely see you."
        scene 10_0037 with dissolve
        ali "Where do you go all day?"
        menu:
            "Lie":
                scene 10_0039 with dissolve
                mc "I met an old guy. Name's Bill. He's a truck driver."
                mc "He was looking for some help, I figured, why not?\nBetter than sittin' around all day doing nothing."
                scene 10_0043 with dissolve
                ali "Oh, okay."
                ali "Now I feel terrible... I imagined you sitting at the bar in the local strip joint all day!"
                scene 10_0044 with dissolve
                mc "Well damn!\nIf I'd have known there was a strip joint in town..."
                ali "[lol]"
            "Tell her the truth":
                $ Alison.Add("KnowsAlt")
                scene 10_0039 with dissolve
                mc "I don't wanna lie to you, Alison, so I'm gonna tell you the truth, but I need you to stay calm."
                scene 10_0040 with dissolve
                ali "Jesus, [mc], this sounds serious... what's going on?"
                scene 10_0041 with dissolve
                mc "When I went out looking for information on the guys that had been threatening you, I met a cop...Alysha."
                mc "She's the one who helped me track them down."
                scene 10_0042 with dissolve
                mc "It was through her that I found out how dangerous these guys are."
                mc "And how many people, just like you, were suffering because of them."
                mc "So, we came up with a plan."
                scene 10_0038 with dissolve
                ali "A plan? To do what??"
                scene 10_0051 with dissolve
                mc "To take them down. All of them. For good."
                scene 10_0052 with dissolve
                ali "I don't understand."
                ali "Why would the police need {b}your{/b} help?\nSurely they could arrest them without involving you?"
                scene 10_0053 with dissolve
                mc "No."
                mc "They don't have anything actionable on them. They need solid proof."
                scene 10_0054 with dissolve
                ali "And that's where you come in??"
                ali "How are {i}you{/i} supposed to get proof if the police can't?"
                mc "Because... I'm working for them."
                scene 10_0055 with dissolve
                call Emotion (ali, "Gasp", "You're working for them??")
                mc "That's what {i}they{/i} think, at least.\nIt's more of an undercover job, helping the cops."
                mc "Alysha asked me to help her, and I agreed."
                scene 10_0056 with dissolve
                ali "Fuck, [mc]!"
                ali "You know what they've put me through! And now {b}you work for them{/b}??"
                scene 10_0057 with dissolve
                mc "It was the {b}only way{/b} to get them to write off your debt and leave you alone."
                mc "These motherfuckers need to pay for what they've done to you and Cara!\nFor what they're doing to other families!"
                scene 10_0058 with dissolve
                ali "So, {b}revenge{/b}??\nThat's what this is about?"
                scene 10_0059 with dissolve
                mc "No!\nIt's not revenge I want, Alison, it's security!"
                mc "I want my daughter to be safe!\nI want {b}you{/b} to be safe!"
                scene 10_0060 with dissolve
                ali "It's too damn dangerous, [mc]!\nLet the police find someone else to do it!"
                scene 10_0061 with dissolve
                mc "There is no one else!\nI'm already on the inside."
                mc "Alison, please. I don't want us to fight.\nIf there was {i}any{/i} other way, I would've chosen it."
                scene 10_0062 with dissolve
                ali "I hope you know what you're doing."
                ali "If anything happens to you, I'll never forgive myself for dragging you into this mess."
                scene 10_0053 with dissolve
                mc "Nothing's gonna happen to me. Don't worry."
                scene 10_0042 with dissolve
                ali "But I am worried, [mc]!\nI can't just switch it off!"
                mc "I know.\nAnd if you could do anything to help me, you would, right?"
                scene 10_0036 with dissolve
                ali "Yes, of course I would! Anything at all!"
                scene 10_0043 with dissolve
                ali "Ohh... Smart-ass!"
                ali "That's exactly what {b}you're{/b} doing for me, isn't it?"
                scene 10_0054 with dissolve
                ali "Okay, I get your point. I'll lay off you... for now."
                ali "I appreciate what you're doing for us, [mc], really.\nJust {b}please{/b}, be careful."
    scene 10_0045 with dissolve
    ali "Shoot! I'd better go, I don't wanna be late."
    mc "Do you know if Christina's working today?"
    ali "I don't think she is. Why?"
    mc "She has some repairs that need doing. Told her I'd take a look."
    scene 10_0046 with dissolve
    ali "Oh, yeah. Sorry, that's my fault.\nI told her you were good at things like that."
    mc "It's fine.\nCan you let her know I'll be over later?"
    ali "Sure."
    if Alison.isActive():
        scene 10_0047 with dissolve
        ali "See you later."
        mc "Yeah."
        scene 10_0048 with dissolve
        ali "[whi]Mmhh."
        scene 10_0049 with dissolve
        ali "[whi]..Mmmmhh.."
        scene 10_0050 with dissolve
        ali "Bye."
    else:
        scene 10_0050 with dissolve
        ali "See you later."
        mc "Yeah."
    scene 10_0063 with Fade(1, 0.5, 1)
    mct "Need to update Alysha."
    scene 10_0064 with dis1
    scene 10_0063 with dis1
    scene 10_0065 with dis1
    mc cell "Hey. It's me."
    aly cell "Where the hell have you been??\nYou were supposed to call me two days ago!"
    mc cell "Yeah, sorry... Didn't get a chance, had a lot going on."
    aly cell "Just glad you're okay, I was worried."
    scene 10_0066 with dissolve
    mc cell "Can we meet up somewhere?"
    aly cell "Uhh... Yeah.\nI can be at the cafe in about 30 minutes if that works for you?"
    aly cell "Don't worry, I'm off-duty. No uniform."
    scene 10_0065 with dissolve
    mc cell "Great. See you then."
    scene 10_0067 with dissolve
    pause 0.5
    jump Springhaven_DayOfRestCafe
return

label Springhaven_DayOfRestCafe:
    scene 10_0068 with fade2
    pause 0.5
    scene 10_0069 with dissolve
    mc "Hi, Gabby."
    scene 10_0070 with dissolve
    gab "Great."
    gab "I take it you're here as a customer; otherwise, you're still too early."
    mc "Yep. Coffee please."
    scene 10_0071 with dissolve
    gab "Take a seat, I'll bring it over."
    scene 10_0072 with fade1
    pause 0.5
    scene 10_0073 with fade1
    scene 10_0074 with dis1
    gab "Will that be all?"
    mc "Yeah, thanks."
    scene 10_0075 with dissolve
    mc "On your own today?"
    gab "Yep."
    scene 10_0076 with dissolve
    if Melanie.Has("TookBJ"):
        gab "Is that why you're here?\nLooking for another blowjob from my sister?"
        scene 10_0077 with dissolve
        mc "No!"
        mc "I'm here to meet a friend, jeez!"
        scene 10_0085 with dissolve
        gab "But if she {i}were{/i} here and offered you one, you'd take it, right?"
        if Gabby.Has("Watch"):
            mc "Depends."
            gab "On what?"
            scene 10_0080 with dissolve
            mc "Would you be watching?"
            scene 10_0079 with dissolve
            gab "I don't know. Maybe."
            gab "Would you want me to watch?"
            scene 10_0086 with dissolve
            mc "Yeah, I like you watching."
            scene 10_0087 with dissolve
            gab "Maybe you should convince Mel to let me come in next time, then, so I can {i}really{/i} watch."
            gab "I don't get to see a lot from behind the door."
            scene 10_0088 with dissolve
            mc "I very much doubt she'd listen to me!\nWhy don't {i}you{/i} ask her?"
            gab "I did. She said no."
            mc "You told her you'd been spying on us??"
            gab "Yeah.\nWe're sisters. We don't keep secrets."
            scene 10_0089 with dissolve
            gab "If you tell her that you like me watching, she may agree."
            mc "{i}Or{/i} she may stab me!"
            $ tCh=True
            if not EzModeActive:
                menu:
                    "[wk_y]Okay, I'll ask her":
                        pass
                    "No, I'm not asking her":
                        $ tCh=False
            if tCh:
                mc "Okay, I'll ask her."
                $ Gabby.Add("AskMel")
                scene 10_0090 with dissolve
                gab "Cool!"
            else:
                $ Gabby.Score(-1)
                scene 10_0090 with dissolve
                gab "Pussy!"
        else:
            mc "Maybe."
            scene 10_0082 with dissolve
            gab "Yeah, that's what I thought."
        scene 10_0091 with dissolve
        pause 0.5
    else:
        gab "Why didn't you take Mel up on her offer?"
        scene 10_0078 with dissolve
        mc "What offer?"
        gab "She offered you a blowjob, and you turned it down."
        mc "She told you??"
        scene 10_0079 with dissolve
        gab "We're sisters, we don't keep secrets."
        gab "You didn't answer."
        scene 10_0077 with dissolve
        if not EzModeActive:
            menu:
                "[wk_y]She isn't my type":
                    $ Melanie.L=-1
                    $ Gabby.Score(1)
                    scene 10_0079 with dissolve
                    gab "What is {i}your type{/i}?"
                    menu:
                        "None of your business[wk_c]":
                            call CloseCharacterPath (Gabby, "Gabby")
                            scene 10_0081 with dissolve
                            gab "Your answer tells me more than you think."
                            scene 10_0083 with dissolve
                            mc "What does it tell you?"
                            gab "[lol]"
                        "[wk_y]You":
                            $ Gabby.Score(1)
                            gab "So, if {b}I'd{/b} have made the offer instead, you would've taken it?"
                            scene 10_0080 with dissolve
                            mc "You didn't, so guess we'll never know."
                            scene 10_0081 with dissolve
                            gab "I didn't... {b}{i}yet{/i}{/b}."
                            scene 10_0082 with dissolve
                            gab "Never say never."
                            scene 10_0083 with dissolve
                            mct "You can bet your sweet little ass I would've taken it from you! Heh."
                "It was the wrong thing to do":
                    $ Gabby.Score(1)
                    scene 10_0081 with dissolve
                    gab "Wow!\nA guy with morals!"
                    scene 10_0083 with dissolve
                    gab "Good for you."
                "[wk_n]I'd prefer one from you":
                    $ Gabby.Score(-1)
                    scene 10_0084 with dissolve
                    gab "Dream on, old man."
                    scene 10_0083 with dissolve
                    gab "I'd spit in your coffee, but you'd probably like it."
        else:
            if not Gabby.Has("EZ"):
                mc "It was the wrong thing to do."
                scene 10_0081 with dissolve
                gab "Wow!\nA guy with morals!"
                scene 10_0083 with dissolve
                gab "Good for you."
                call CloseCharacterPath (Gabby)
            else:
                mc "She isn't my type."
                $ Gabby.Score(1)
                scene 10_0079 with dissolve
                gab "What is {i}your type{/i}?"
                mc "You."
                $ Gabby.Score(1)
                gab "So, if {b}I'd{/b} have made the offer instead, you would've taken it?"
                scene 10_0080 with dissolve
                mc "You didn't, so guess we'll never know."
                scene 10_0081 with dissolve
                gab "I didn't... {b}{i}yet{/i}{/b}."
                scene 10_0082 with dissolve
                gab "Never say never."
                scene 10_0083 with dissolve
                mct "You can bet your sweet little ass I would've taken it from you! Heh."
    scene 10_0092 with dissolve
    aly "Hey."
    scene 10_0093 with dissolve
    aly "Next time you tell me you're gonna call, please call!"
    mc "Yeah, sorry."
    scene 10_0094 with dissolve
    aly "I don't have many friends. I'm not used to worrying about people."
    mc "We're friends?"
    scene 10_0095 with dissolve
    aly "Aren't we?"
    mc "Uhh... yeah, I guess so."
    aly "I've been back in Springhaven for over six months, and you're the only person I've invited to my home.\nBelieve me, we're friends."
    scene 10_0096 with dissolve
    aly "So, what's been goin' on?"
    aly "The last place I expected to see you was at the police station!"
    scene 10_0097 with dissolve
    mc "A truck driver had been arrested. He's a contractor, so not directly involved with anything."
    mc "But there was a shipment stuck in Northcrest that Sue desperately wanted moved to Brookvale.\nSo she got Wilks to aid his release."
    aly "Any idea what was inside the shipment?"
    scene 10_0098 with dissolve
    mc "No."
    mc "We picked it up from an empty warehouse.\nI presumed it was just a drop-off point, but they had a lab built inside."
    aly "A lab?? So... Drugs?"
    mc "Yeah, that was my first thought too."
    aly "That would explain why they recruited Wilks!\nMakes things a whole lot easier if you have the head of narcotics in your pocket!"
    scene 10_0099 with dissolve
    aly "The shipment was taken to Brookvale?"
    if MiyukaDelivered or MiyukaEscaped:
        mc "Yeah, same place I picked up the girl from."
    else:
        mc "Yeah."
    mc "But that isn't its final destination. Just another drop-off point."
    mc "They don't want their drivers knowing too much.\nOne driver knows where it comes from, another driver knows where it ends up."
    scene 10_0100 with dissolve
    aly "We need to find out what's in those shipments."
    aly "If they're using {b}trucks{/b} to move drugs, it must be in massive quantities!"
    mc "I'm workin' on it."
    scene 10_0101 with dissolve
    mc "One more thing.\nA woman was staying in a trailer on the Northcrest property."
    mc "Her name's Mitsui. She's Kiyomi's mother."
    aly "Kiyomi?"
    mc "Sue's maid."
    mc "Long shot, but see what you can find out."
    aly "Okay."
    scene 10_0100 with dissolve
    aly "Everything go okay in Lakeshore?"
    scene 10_0101 with dissolve
    mc "Yeah.\nI've got someone keeping an eye on Melissa until we can extract her."
    aly "Good.\nIf there's any way I can help with that, let me know."
    scene 10_0102 with dissolve
    aly "So... Are you gonna buy your friend a coffee, or do I have to get my own?"
    mc "Oh... Yeah, sorry!"
    aly "[lol]"
    scene 10_0103 with Fade(1, 2, 1)
    aly "You punched him?! In front of your whole squad??"
    mc "Square on the nose.\nThere was blood everywhere!"
    scene 10_0104 with dissolve
    aly "You assaulted a superior officer, and they {i}didn't{/i} haul your ass into the brig?"
    aly "Nah, I call bullshit!"
    mc "It was brushed under the rug."
    scene 10_0105 with dissolve
    mc "I got a slap on the wrist."
    mc "He got another medal and a promotion!"
    aly "Wow! He was promoted?!\nAfter ordering you to shoot a group of unarmed civilians??"
    scene 10_0106 with dissolve
    aly "Shit, ain't that the way?!"
    aly "Always the damn same!"
    scene 10_0107 with dissolve
    pause 0.5
    play sound "text.mp3"
    pause 0.5
    scene 10_0108 with dissolve
    mc "Err, sorry..."
    show screen CellPhone("Christina")
    msg_nvl "Hi [mc], it's Christina.\nAlison gave me your number."
    msg_nvl "She told me you were hoping to come over today to take a look at the repairs."
    msg_nvl "I'm home at the moment, but won't be for much longer. Lots of errands to run."
    msg_nvl "Any chance you're free now?"
    mc_nvl "Sure."
    msg_nvl "Great."
    call CloseCell ()
    pause 0.5
    scene 10_0109 with dissolve
    mc "Sorry, I need to go."
    aly "Yeah, me too.\nKeep in touch."
    mc "I will."
    jump Springhaven_VisitChristina
return

label Springhaven_VisitChristina:
    scene 10_0110 with fade2
    pause 0.5
    play sound "knock.mp3"
    scene 10_0111 with dis1
    pause 0.5
    scene 10_0112 with dissolve
    cri "Hi! Come on in."
    call CenterText ("Christina walks you around her home pointing out the {b}many{/b} repairs.", True)
    scene 10_0113 with dissolve
    cri "Seriously, that leak has been driving me insane for months!"
    cri "That needs to go to the top of the list."
    scene 10_0114 with dissolve
    cri "I {i}think{/i} that's everything!"
    cri "Although it's probably not... there's so much that needs to be done, it's impossible to keep track!"
    scene 10_0115 with dissolve
    cri "Oh, wait! I almost forgot..."
    scene 10_0116 with dissolve
    cri "The holes that need to be filled!"
    scene 10_0117 with dissolve
    mc "Oh!"
    mc "You were talking about {i}actual{/i} holes!"
    scene 10_0118 with dissolve
    cri "Huh? Yeah."
    cri "What did you think I was talking about??"
    scene 10_0119 with dissolve
    mc "I, uhh... I thought you were... you know, I thought it was an innuendo!"
    cri "An innuendo?? For wha--"
    scene 10_0120 with dissolve
    cri "OH MY GOD! [lol]"
    cri "Are you serious?!"
    mc "It was the way you said it!\nYou made it sound like you were talking about..."
    cri "[lol]"
    scene 10_0121 with dissolve
    cri "Oh God! I'm {b}so{/b} sorry!\nI was hungover! My head was pounding... I could barely speak!"
    scene 10_0122 with dissolve
    cri "I swear, {i}these{/i} are the only holes I'm asking you to fill!"
    scene 10_0123 with dissolve
    cri "{i}How{/i} you fill them, I'll leave to you."
    mc "[lol]"
    mc "Not gonna let me forget this, are you?"
    cri "No chance!"
    scene 10_0124 with dissolve
    cri "Ohh! I just remembered, Nicole told me her ceiling fan had stopped working."
    scene 10_0125 with dissolve
    cri "Last thing, I promise!"
    play sound "cellring.mp3" volume 0.5 loop
    scene 10_0126 with dissolve
    cri "Damn... It's work.\nSorry, I need to take this."
    mc "Yeah, it's fine."
    stop sound
    scene 10_0127 with dissolve
    cri cell "Hi, give me a second..."
    scene 10_0128 with dissolve
    cri "Go ahead, [mc], that's Nic's room.\nCeiling fan."
    mc "Okay."
    scene 10_0129 with dissolve
    cri cell "Hey, I'm back."
    scene 10_0130 with dissolve
    pause 0.5
    scene 10_0131 with dissolve
    pause 0.5
    scene 10_0132 with dissolve
    pause 0.5
    scene 10_0133 with vpunch
    mc sh "FUCK! SORRY!"
    scene 10_0134 with dissolve
    mc "I DIDN'T KNOW YOU WERE IN HERE!"
    scene 10_0135 with dissolve
    mc "I'll just..."
    nic "Don't move! And don't turn around!\nLet me put my pants on!"
    scene 10_0136 with dissolve
    mc "Err... Okay. Not looking."
    scene 10_0137 with dissolve
    nic "I'll tell you when I'm done."
    scene 10_0138 with dissolve
    pause 0.5 
    scene 10_0139 with dissolve
    mc "I should've knocked first.\nI'm really sorry, Nicole."
    nic "It's okay."
    $ t=wk_n
    if Nicole.hasScore(4):
        $ t = wk_y
    $ tCh=None
    if not EzModeActive:
        menu:
            "[t]Peep again":
                $ tCh=True
            "Don't":
                pass
    elif Nicole.Has("EZ"):
        $ tCh=True
    if tCh:
        scene 10_0140 with dissolve
        if Nicole.hasScore(4):
            $ Nicole.Add("Peek")
            $ Nicole.Score(1)
            nic "Stop peeking!"
            scene 10_0139 with dissolve
            mc "Crap... Sorry, I couldn't resist!"
            scene 10_0141 with dissolve
            pause 0.5
            nic h "I can still see you! You're looking again!"
            mc "I can't stop myself! Sorry."
            scene 10_0142 with dissolve
            nic "You can turn around now."
        else:
            nic "Stop peeking!"
            $ Nicole.Score(-1)
            scene 10_0139 with dissolve
            mc "I'm not!"
            scene black with Fade(1, 2, 1)
            nic "You can turn around now."
    else:
        if not Nicole.hasScore(4):
            $ Nicole.Score(1)
        scene black with Fade(1, 2, 1)
        nic "You can turn around now."
    scene 10_0143 with dissolve
    mc "Your mom sent me in to take a look at the ceiling fan."
    scene 10_0144 with dissolve
    nic "Ughh, yeah... It stopped working months ago.\nIt gets so hot and stuffy in here now!"
    scene 10_0145 with dissolve
    mc "Do the lights still work?"
    nic "Yeah."
    mc "Hmmm... Could be the motor's fried."
    scene 10_0146 with dissolve
    nic "Can you fix it?"
    scene 10_0147 with dissolve
    mc "Maybe.\nI'd need to pull it down and take a closer look."
    scene 10_0148 with dissolve
    mc "Oh, wow! Cute picture!"
    scene 10_0149 with dissolve
    mc "Is that {i}Alex{/i} with you and Cara??"
    nic "[lol] Yeah!"
    scene 10_0150 with dissolve
    nic "Before she discovered tattoos and hair dye!"
    scene 10_0151 with dissolve
    mc h "Damn, you all look {i}fiiine{/i} in a school uniform![lol]"
    scene 10_0152 with dissolve
    nic "I still have it if you wanna borrow it!"
    if persistent.Incest and Cara.isActive():
        nic "Don't think it'd fit Cara, though."
    elif Alex.isSexual():
        nic "Don't think it'd fit Alex, though."
    else:
        nic "Probably won't fit your girlfriend, though."
    $ tCh=None
    if not EzModeActive:
        menu:
            "Nah, I'm good[wk_c]":
                call CloseCharacterPath (Nicole, "Nicole")
            "[wk_y]Does it still fit YOU?":
                $ tCh=True
    elif Nicole.Has("EZ"):
        $ tCh=True
        mc "Does it still fit YOU?"
    else:
        mc "Nah, I'm good."
    if tCh:
        scene 10_0153 with dissolve
        $ Nicole.Score(1)
        nic "I could probably still squeeze myself into it."
        scene 10_0154 with dissolve
        mc "Damn! Now that's a fight I'd pay to watch!"
        nic "[lol]"
    else:
        call CloseCharacterPath (Nicole, "Nicole")
    scene 10_0155 with dissolve
    cri "Oh, Nicole!\nI thought you'd already left?"
    nic "No, I don't have any classes until later."
    scene 10_0156 with dissolve
    cri "So, [mc], what do you think? Do we have a deal?"
    nic "Deal?"
    scene 10_0157 with dissolve
    cri "To fix up the house as part payment for the truck."
    scene 10_0158 with dissolve
    nic "Oh, cool. You're going to be over here a lot, then?"
    cri h "Slow down, Nic..."
    scene 10_0159 with dissolve
    cri "He hasn't agreed yet!"
    $ tCh=None
    if EzModeActive:
        call EzModeAsk ("Christina")
        if _return:
            $ Christina.Add("EZ")
            $ tCh=True
            mc "I have now!"
        else:
            if Nicole.Has("EZ"):
                $ tCh=True
                mc "I have now!"
    else:
        menu:
            "[wk_y]Take the deal":
                $ tCh=True
            "Decline the deal[wk_c]":
                pass
    if tCh:
        cri "Great!\nLet's have a coffee and sort everything out."
    else:
        call CloseCharacterPath (Christina, "Christina")
        $ ChFx = True
        mc "Sorry, there's just too much work involved."
        cri "Oh well.\nLet's have a coffee and discuss a cash price then."
    jump Springhaven_VisitAlyshaAgain
return

label Springhaven_VisitAlyshaAgain:
    scene 10_0160 with Fade(2, 3, 2)
    scene 10_0161 with dis1
    mct "Now the truck's officially mine, I won't feel so guilty the next time I drive it to Oakhill!"
    play sound "vib.mp3"
    pause 1.0
    scene 10_0162 with dissolve
    stop sound
    aly cell "Hey.\nI found something."
    aly cell "Can you come over?"
    mc cell "Uhh... Yeah, sure."
    scene black with Fade(1, 2, 0)
    play sound "knock.mp3"
    scene 10_0163 with Fade(0, 0, 1)
    pause 1.0
    scene 10_0164 with dissolve
    aly "Hey."
    scene 10_0165 with dissolve
    aly "Beer?"
    mc "Yeah, thanks."
    scene 10_0166 with dissolve
    pause 0.5
    if persistent.Incest and Pix_Hannah:
        play sound "text.mp3"
        pause 0.5
        scene 10_0167 with dissolve
        pause 0.5
        show screen CellPhone("Hannah")
        msg_nvl "Hey, Unc!"
        msg_nvl "I've been lying on my bed, bored outta my skull, taking a few selfies to pass the time."
        msg_nvl "I couldn't resist taking one for my pervy uncle! {image=/thumbs/cell/emoji/crylaugh.png}"
        mc_nvl "Send it! {image=/thumbs/cell/emoji/laugh.png}"
        call SendPhoto ("han_05")
        mc_nvl "Daammnn!"
        msg_nvl "Kinda fucked up that I wanted to take one for you, isn't it? {image=/thumbs/cell/emoji/confused.png}"
        msg_nvl "But the thought of sending it made me a little excited! {image=/thumbs/cell/emoji/devil.png}"
        msg_nvl "Love you xx {image=/thumbs/cell/emoji/kiss.png}"
        call CloseCell ()
        scene 10_0168 with dissolve
        aly "Wow, she's cute!"
        scene 10_0169 with dissolve
        mc "Shit, sorry."
        scene 10_0170 with dissolve
        aly "Girlfriend?"
        mc "Uhh, no. She's..."
        $ tCh=None
        if not EzModeActive:
            menu:
                "just a friend":
                    pass
                "[wk_y]my niece":
                    $ tCh=True
        elif Alysha.Has("EZ"):
            mc "She's my niece."
            $ tCh=True
        if tCh:
            scene 10_0171 with dissolve
            $ Alysha.Add("A00")
            aly "Your niece?? Damn!"
            mc "The picture, it's just, uhh, an inside joke."
            aly "Dude, you ain't the first uncle who's had a niece crushing on him!"
            aly "Don't be embarrassed.\nIt's sweet, and she's hot as hell! Take it as a compliment."
        else:
            mc "Just a friend."
            scene 10_0171 with dissolve
            aly "Does {i}she{/i} know that? [lol]"
        scene 10_0172 with dissolve
    else:
        scene 10_0172 with Fade(1, 2, 1)
    aly "So, I ran the name you gave me earlier - the woman from Northcrest."
    aly "Didn't take long to get a hit."
    scene 10_0173 with dissolve
    aly "Local PD got a call a few weeks back.\nHer co-workers were worried because she'd stopped showing up for work."
    aly "They asked for a welfare check."
    scene 10_0174 with dissolve
    aly "Officers went to her place.\nNo answer. Looked in through the windows - nothing obvious."
    aly "No signs of a struggle. No overturned furniture.\nNothing that raised immediate alarms."
    scene 10_0175 with dissolve
    aly "People vanish all the time. Usually it's nothing criminal.\nVisiting family. Running off with someone new. Deciding, overnight, to be someone else."
    aly "Plenty of reasons to disappear that don't involve foul play."
    scene 10_0176 with dissolve
    aly "She was never formally reported missing, so it stayed low priority."
    aly "Paperwork filed and forgotten."
    scene 10_0177 with dissolve
    aly "But the most interesting part?..."
    aly "The place she works - A {b}pharmaceutical laboratory{/b}."
    scene 10_0178 with dissolve
    aly "She's a chemist."
    scene 10_0179 with dissolve
    mc "Why would they need a lab and a chemist?"
    mc "I know next to nothing about the illegal drug trade, but doesn't that shit usually get imported?"
    scene 10_0180 with dissolve
    aly "You didn't see {i}anything{/i} in the lab that could help us figure out what they're up to?"
    scene 10_0181 with dissolve
    mc "Nah."
    mc "Door was locked. I barely got a glimpse through a window before I was busted."
    play sound "vib.mp3"
    pause 0.5
    scene 10_0182 with dissolve
    mc "It's Blaze."
    scene 10_0183 with dissolve
    stop sound
    blz cell "Hey, Boss."
    mc cell "Hey.\nHold on, I'll put you on speaker.\nI'm with Alysha, the cop I told you about."
    scene 10_0184 with dissolve
    blz cell "I've made contact with Melissa.\nYou've stumbled into quite the mess."
    blz cell "The guys guarding her - they work for her father."
    scene 10_0185 with dissolve
    mc cell "I thought her father was dead?"
    blz cell "No, that was her step-father.\nHer real daddy's alive and kicking."
    scene 10_0186 with dissolve
    blz cell "It gets worse."
    blz cell "He works for the same group as her mom."
    blz cell "He runs things here in Lakeshore."
    blz cell "From what I can tell, there's a little war raging between them with Melissa stuck in the middle."
    mc cell "Fuck."
    scene 10_0187 with dissolve
    mc cell "That complicates things."
    mc cell "We were counting on Melissa to be on {i}our{/i} side in this."
    mc cell "I'm not gonna kidnap a girl from her father against her will!"
    scene 10_0188 with dissolve
    blz cell "Yeah, that's the thing, Boss..."
    blz cell "She {b}is{/b} on our side.\nShe wants us to get her out."
    blz cell "She hates her father with a passion. Doesn't want anything to do with him."
    blz cell "Problem is... She feels the same way about her mom, too.\nShe doesn't want to go back to Springhaven."
    scene 10_0189 with dissolve
    mc cell "Goddamnit."
    mc cell "Keep workin' her, for now. Get as much intel as you can."
    mc cell "But don't be surprised if I call to abort."
    blz cell "Understood."
    scene 10_0190 with dissolve
    mc "[whi]Fuck."
    scene 10_0191 with dissolve
    aly "What you gonna do?"
    mc "Don't know."
    mc "Sure as shit not gonna extract her just to cut her loose, though."
    scene 10_0192 with dissolve
    aly "Sounds like you could do with another one."
    mc "Yeah, thanks."
    scene 10_0193 with dissolve
    aly "Why wouldn't Sue tell you about Melissa's father?\nShe must've known you'd eventually find out."
    mc "I'll let you know once I've asked her."
    scene 10_0194 with Fade(1,0.5, 1)
    aly "She'd potentially make a great witness."
    scene 10_0195 with dissolve
    mc "Who? Melissa??"
    scene 10_0196 with dissolve
    aly "Yeah.\nThink about it... If she wants a way out, maybe we can give her one."
    mc "You can't be serious?"
    scene 10_0197 with dissolve
    aly "She'd be a valuable asset. One we desperately need."
    aly "If she hates her parents as much as your friend says, she may be willing to help."
    scene 10_0198 with dissolve
    aly "All I'm saying is, it might be worth asking her."
    aly "Give her the option. If she says no... fair enough."
    scene 10_0199 with dissolve
    aly "But if she said yes, our odds of succeeding would increase substantially."
    scene 10_0200 with dissolve
    mc "Come on... Would you testify against {i}your{/i} parents??"
    aly "No.\nBut unlike Melissa, I loved my father dearly."
    aly "If I hated him and wanted payback? Who knows!"
    scene 10_0201 with dissolve
    pause 1.0
    scene 10_0202 with dissolve
    if Alysha.Has("A00"):
        aly "You and your niece must be pretty tight for her to be sending you topless selfies!"
        scene 10_0203 with dissolve
        mc "Err... Yeah, I guess.\nLike I said--"
        aly "Inside joke. Right."
        aly "Does she send them often?"
        mc "No!"
        scene 10_0204 with dissolve
        aly "But that wasn't the first one she's sent you."
        mc "Are you interrogating me?"
        aly "No!\nI'm just curious why you wouldn't tell her to stop."
        scene 10_0205 with dissolve
        aly "Sorry, I'm not trying to make you uncomfortable."
        scene 10_0206 with dissolve
        aly "Just a little jealous, I guess. I miss not having family."
        scene 10_0207 with dissolve
        mc "You don't have {b}any{/b}?"
    else:
        aly "I'm glad we're in this together."
        scene 10_0203 with dissolve
        mc "Must be tough - not being able to trust anyone at work."
        aly "Yeah, it can get pretty stressful."
        scene 10_0204 with dissolve
        mc "You know, if you ever wanna talk or vent, you can call me, right?"
        aly "See! We {b}are{/b} friends!"
        mc "Yeah, we are."
        scene 10_0205 with dissolve
        aly "You're a good guy, [mc]."
        scene 10_0206 with dissolve
        aly "Wish my pa was still here - he would've liked you."
        scene 10_0207 with dissolve
        mc "You have any other family around?"
    aly "No.\nIt was just me and Pa."
    scene 10_0208 with dissolve
    aly "When my mom was leaving him, she forced me to choose between them."
    aly "She knew I'd pick Pa - wasn't even a competition."
    aly "She walked out the door, and I never saw her again."
    scene 10_0209 with dissolve
    mc "Damn. That's rough."
    aly "Her loss.\nPa was better off without her. We both were."
    aly "Okay, your turn."
    mc "My turn?"
    scene 10_0210 with dissolve
    aly "Yeah. That was my story, now tell me {i}yours{/i}!"
    scene 10_0211 with Fade(1, 3, 1)
    mc "So, I figured, why not ask that friendly cop I'd met at the cemetery?"
    mc "Waited at Pete's grave for hours until you eventually showed up."
    aly "... And I almost pulled my gun on you![lol]"
    scene 10_0212 with dissolve
    aly "Sorry!"
    mc "Can hardly blame you!\nWhat was it I said? I was waiting there for you??\nSurprised you didn't shoot me on the spot!"
    aly "I'm glad I didn't!"
    mc "Me too!"
    scene 10_0213 with dissolve
    aly "[lol]"
    scene 10_0214 with dissolve
    aly "You have a nice story."
    aly "I'm happy things are working out between you and your family."
    aly "Don't ever take them for granted!\nBeing all alone in this world really sucks."
    $ tCh=Alysha.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]You're not alone":
                $ tCh=True
            "Yeah, I'm lucky [wk_c]":
                $ tCh=False
    if tCh:
        scene 10_0220 with dissolve
        mc "Hey. You're {b}not{/b} alone."
        aly "Sure feels that way."
        mc "Come here."
        scene 10_0221 with dissolve
        mc "I'm just a phone call away. Any time, any reason."
        aly "{i}Any{/i} reason?"
        scene 10_0222 with dissolve
        mc "[whi]Anything at all."
        $ Alysha.L=1
        scene 10_0223 with dis1
        pause
        scene 10_0224 with dis1
        aly "[ss]Mmh."
        scene 10_0225 with dis1
        scene 10_0226 with dis1
        aly "[ss]..Mmmhhh..."
        scene 10_0227 with dissolve
        aly "[ss]...Mmh..."
        scene 10_0228 with dissolve
        aly "[ss]..Mmmhhh..."
        scene 10_0229 with dissolve
        aly "[whi]Fuck... I'm sorry. We can't."
        aly "This is a bad idea, and we're both a little drunk."
        scene 10_0230 with dissolve
        aly "We {b}have{/b} to keep things professional between us."
        mc "Okay."
        scene 10_0231 with dissolve
        aly "I'm gonna go to bed... before I change my mind."
        mc "I'll call a cab."
        aly "Crash on the couch. Please."
        aly "I feel bad enough already, without having to kick you out!\nAnd it'll save you from having to come back for your truck in the morning."
        mc "Yeah, okay."
        scene 10_0232 with dissolve
        aly "[whi]God, I hate myself for stopping."
        aly "Once this case is over..."
        scene 10_0233 with dissolve
        aly "I'm gonna ride you so fuckin' hard."
        scene 10_0234 with dissolve
        aly "[ss]..Mmmhhh..."
        scene 10_0235 with dissolve
        aly "I'll get you a blanket."
    else:
        call CloseCharacterPath (Alysha, "Alysha")
        scene 10_0215 with dissolve
        aly "Looks like we've drunk all the beer."
        scene 10_0216 with dissolve
        aly "Good time to call it a night!"
        mc "Yeah.\nI'd better call a cab."
        scene 10_0217 with dissolve
        aly "Just crash on the couch!\nSaves having to come back for your truck in the morning."
        mc "True.\nOkay, thanks."
        scene 10_0218 with dissolve
        aly "I'll get you a blanket."
    scene 10_0219 with Fade(1, 2, 1)
    mc "[whi]...Zzz..."
    scene 10_0236 with Fade(2, 3, 2)
    pause 0.5
    aly "[mc!u]! GET UP!"
    scene 10_0237 with dissolve
    aly "I overslept! I'm {b}so{/b} late for work!"
    scene 10_0238 with dissolve
    call Emotion (mc, "Groan", "", True)
    aly "Move your ass, soldier!"
    scene 10_0239 with dissolve
    mc "[whi]Yes, Ma'am."
    aly "I'm gonna hit the shower."
    if Alysha.L==1:
        scene 10_0240 with dissolve
        aly "Hey. About last night... I'm really sorry.\nAre we okay?"
        mc "Yeah, of course we are!"
        aly "Okay. Good."
        scene 10_0241 with dissolve
        mc h "But remember, once the case is over..."
        mc h "I'm looking forward to holding on to that fine ass of yours when you're {i}riding me so fuckin' hard{/i}!"
        scene 10_0242 with dissolve
        aly "You and me both, Baby!"
    jump Springhaven_BlazeCall
return

label Springhaven_BlazeCall:
    scene 10_0243 with Fade(2, 3, 2)
    scene 10_0244 with dis1
    play sound "vib.mp3" loop
    scene 10_0245 with dis1
    scene 10_0246 with dis1
    stop sound
    scene 10_0247 with dissolve
    mc cell "Blaze? Wasn't expecting to hear from you so soon."
    blz cell "An opportunity has come up, but the window could be small."
    mc cell "I'm listening."
    scene 10_0248 with dissolve
    blz cell "Don't know the details, but most of these guys have just left town."
    blz cell "Melissa heard something was going down in Cedar Grove.\nShe doesn't know how long they'll be gone."
    blz cell "This could be our best chance, Boss.\nThey've left just one guy here to watch her."
    scene 10_0249 with dissolve
    mc cell "Shit."
    mc cell "We're not ready!"
    blz cell "We kinda are.\nI've already found a place for us to hide out."
    scene 10_0250 with dissolve
    mc cell "I'm not even sure we {b}should{/b} extract her, Blaze."
    blz cell "I know, but we might not get another chance like this."
    blz cell "It'd be quiet. Low risk.\nBut if we're gonna do it, it has to be now."
    scene 10_0251 with dissolve
    pause 1.0
    scene 10_0252 with dissolve
    mc cell "Green light.\nI'm on my way."
    blz cell "Yes, Sir."
    scene 10_0253 with dissolve
    mct "Fuck."
    scene 10_0246 with dissolve
    play sound "car_rev.mp3"
    scene 10_0245 with dis1
    scene 10_0244 with dis1
    scene 10_0243 with dis1
    jump Lakeshore_GetMelissa
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
