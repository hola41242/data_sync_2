label Springhaven_TimeToRunDoug:
    scene 05_0610 with Fade(2, 3, 2)
    mc "You know I just saved your life, right?"
    ah2 "[whi]She... She killed him!"
    ah2 "[whi]She fuckin' shot Simon!"
    mc "No... {i}She{/i} didn't."
    scene 05_0611 with dissolve
    ah2 "Huh??"
    mc "{b}James{/b} killed him."
    mc "He found out you were both stealing from the company..."
    scene 05_0612 with dissolve
    mc "Your friend wouldn't go down without a fight."
    mc "You both stormed James. Simon was shot."
    ah2 "That didn't..."
    mc "In the struggle, you managed to wrestle the gun from James and killed him in revenge."
    scene 05_0613 with dissolve
    ah2 "No! {i}SHE{/i} shot him!!"
    ah2 "She shot them both!"
    scene 05_0614 with dissolve
    mc "You think her bosses will believe that?"
    mc "Do you {i}really{/i} wanna take that chance?"
    ah2 "But..."
    scene 05_0615 with dissolve
    mc "I was with her all day; she was busy, working hard for the company as usual."
    mc "Do {i}you{/i} have a witness?"
    ah2 "FUCK! They'll kill me, man!"
    scene 05_0616 with dissolve
    ah2 "Why did you fuckin 'stop her??\nAt least it would've been quick!"
    ah2 "They'll torture me first!\nI've seen what they do!!"
    scene 05_0617 with dissolve
    mc "I'm giving you a chance."
    mc "First, you're gonna help me clean up, and then... you're gonna run."
    mc "Leave the state. They {b}will{/b} come after you. Keep moving."
    scene 05_0618 with dissolve
    ah2 "If I run... Fuck..."
    mc "Yeah."
    ah2 "And... If I don't?"
    scene 05_0619 with dissolve
    mc "They find your body instead."
    ah2 "I'LL RUN!!"
    scene 05_0620 with Fade(4, 3, 3)
    pause
    scene 05_0621 with dissolve
    ah2 "I'm sorry, Simon.\nIt wasn't supposed to end this way."
    mc "Come on, grab the other side."
    scene 05_0622 with dissolve
    ah2 "Where we takin' them?"
    mc "Just push!"
    scene 05_0626 with fade1
    pause
    scene 05_0627 with dissolve
    play sound "shutter.mp3"
    scene 05_0628 with dis1
    scene 05_0629 with dis1
    scene 05_0630 with dis1
    scene 05_0631 with dissolve
    mct "Where the hell are we??"
    scene 05_0632 with dissolve
    mct "Good. The truck's here."
    scene 05_0633 with dissolve
    mc "It's clear. Push."
    scene 05_0635 with dissolve
    mc "Do you know this place? Where are we?"
    ah2 "Yeah, been here before. We're about a mile outside the city."
    scene 05_0636 with fade1
    call Emotion (mc, "Breathing heavily", "Any idea where we can dump them?")
    call Emotion (ah2, "Breathing heavily", "I know a place.")
    scene black with Fade(3, 0, 0)
    jump Springhaven_ReturnHomeAfterDumping
return

label Springhaven_AnEveningAtHome:
    scene 05_0640 with Fade(2, 2, 3)
    pause
    scene 05_0641 with Fade(1, 0.5, 1)
    pause
    play sound "msg.mp3"
    pause 1.0
    scene 05_0642 with dissolve
    ali "It's from Cara."
    scene 05_0643 with dissolve
    ali "They've all decided to have a sleepover at Nicole's."
    scene 05_0644 with dissolve
    mc "Sounds like code for {i}having a party at Nicole's{/i}, heh."
    ali "God, I hope so![lol]"
    scene 05_0645 with dissolve
    ali "I've been so hard on her these last couple of years; she's barely had any freedom to have fun."
    ali "Now it's over, I want her to enjoy her life as much as she possibly can!"
    scene 05_0646 with dissolve
    ali "I don't know what would've happened if you hadn't shown up."
    mc "It's not something you need to worry about anymore."
    scene 05_0647 with dissolve
    ali "I've been thinking. Maybe it's time to tell her the truth."
    ali "She has a right to know she's your daughter.\nI don't think we should keep it from her any longer."
    scene 05_0648 with dissolve
    ali "If she hates us for keeping it from her, we'll just have to deal with it. She deserves to know."
    ali "{b}You{/b} deserve it, too."
    ali "What do you think?"
    scene 05_0649 with dissolve
    mc "You know what I think, Ali.\nI've always wanted her to know."
    ali "Yeah."
    ali "I want you to know, I've always been grateful for your understanding of my decision not to tell her."
    ali "I know how difficult it's always been for you."
    scene 05_0650 with dissolve
    ali "It's settled then.\nI'll take the day off work tomorrow and talk to her."
    mc "Do you want us to tell her together?"
    ali "No. It'll be easier if it's just her and me."
    mc "Okay."
    scene 05_0651 with dissolve
    if Alison.isActive():
        ali "I'm going to lock up and put my PJs on."
    else:
        ali "I'm going to lock up and head for bed. Think about how best to tell her."
    scene 05_0652 with dissolve
    mc "Hey."
    mc "Don't worry. She isn't going to hate us."
    scene 05_0653 with dissolve
    ali "God, I hope you're right."
    scene 05_0654 with Fade(1, 0.5, 1)
    mct "Wow. Big day tomorrow then."
    mct "I officially become a father again!"
    scene 05_0655 with dissolve
    mct "I'll need to go see Millie and Violet as soon as I can.\nThey need to hear it from ME."
    mct "Hope Cara's right about Millie being happy about it.\nViolet, though... Not looking forward to her reaction."
    if Alison.isActive():
        scene 05_0656 with Fade(2, 1, 1)
        pause 0.5
        scene 05_0657 with dis1
        scene 05_0658 with dis1
        scene 05_0659 with dis1
        ali "[whi][mc]."
        scene 05_0660 with dissolve
        mc "Oh, damn!"
        scene 05_0661 with dissolve
        ali "Wanna fool around?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Hell yeah!":
                    $ tCh=True
                "Nah, I'm tired":
                    pass
        elif Alison.Has("EZ"):
            mc "Hell yeah!"
            $ tCh=True
        if tCh:
            call AlisonReplay03
            scene 05_0775 with Fade(0, 1, 3)
            ali "This is nice."
            mc "Yeah."
            scene 05_0776 with dissolve
            ali "Want to sleep in my bed tonight?"
            mc "Sure."
            ali "Good.\nCome on, let's go snuggle up together."
        else:
            $ Alison.Add("Refused")
            scene 05_0662 with dissolve
            ali "Ohh... Uhh... Okay.\nMe too. I'm going to bed."
            scene 05_0663 with dissolve
            ali "Good night."
            mc "Night."
    else:
        mct "Tired. Think I'll call it a night, too."
    scene black with Fade(4, 0, 0)
    jump Springhaven_TheBigDay
return

label Springhaven_ReturnHomeAfterDumping:
    $ Alison.Add("Knows")
    scene 05_0849 with Fade(0, 0, 4)
    pause 0.5
    play sound "car2.mp3" 
    scene 05_0850 with dissolve
    scene 05_0851 with dissolve
    scene 05_0849 with dissolve
    scene 05_0852 with dissolve
    mct "Come on! Hope I'm not too late!"
    scene 05_0853 with dissolve
    mc "Damn it!"
    scene 05_0854 with dissolve
    pause 0.5
    scene 05_0813 with Fade(1, 0.5, 1)
    ali "We have to leave everything here??"
    aly "I'm sorry, we don't have time.\nWe need to move."
    mc "No, everything's fine."
    scene 05_0814 with dissolve
    ali "[mc!u]!{w=0.5}{nw}"
    scene 05_0815 with dissolve
    pause 0.5
    scene 05_0816 with dissolve
    mc "I'm okay."
    scene 05_0817 with dissolve
    play sound "slap.mp3"
    scene 05_0818 with vpunch
    scene 05_0819 with dissolve
    ali "You work for them??"
    ali "You said it was {b}over{/b}! But you're {i}working{/i} for them now??"
    scene 05_0820 with dissolve
    aly "I had to tell her.\nIt was the quickest way to get them out of here."
    scene 05_0821 with dissolve
    mc "I'm {b}not{/b} working for them. Not {i}really{/i}!"
    mc "Alysha's tryin' to take them down; she needed someone on the inside."
    mc "I want these fuckers gone!"
    scene 05_0822 with dissolve
    mc "They threatened to hurt you and Cara... I don't want them hurting anyone else, Alison!"
    scene 05_0823 with dissolve
    mc "Alysha, tell her."
    scene 05_0824 with dissolve
    aly "Err... Yeah..."
    aly "He's helping us with our investigation.\nIt's invaluable to have an inside man."
    scene 05_0825 with dissolve
    ali "But why does it have to be {b}you{/b}?"
    mc "I was in a position to help.\nMy background impressed their boss, thought I'd be a valuable asset."
    scene 05_0826 with dissolve
    mc "I had to make sure you and Cara were safe."
    scene 05_0827 with dissolve
    call Emotion (car, "GASP", "OH MY GOD!")
    scene 05_0828 with dissolve
    car "DAD!!"
    scene 05_0829 with dissolve
    pause 0.5
    scene 05_0830 with dissolve
    call Emotion (car, "Sobbing", "I WAS SO SCARED SOMETHING HAD HAPPENED TO YOU!")
    scene 05_0831 with dissolve
    mc "It's okay, Pipsqueak.\nI'm fine. Everything's fine."
    scene 05_0832 with dissolve
    ali "Dad?... You called him..."
    scene 05_0833 with dissolve
    car "[whi]What?"
    scene 05_0834 with dissolve
    ali "You... You called him... Dad."
    car "Uhh... No I didn't."
    ali "You know?!"
    scene 05_0835 with dissolve
    ali "I trusted you! You promised!"
    mc "What??\nHold on, I didn't tell her!"
    scene 05_0836 with dissolve
    aly "I... Err... I'm gonna go."
    mc "Uhh, yeah. Thanks, Alysha.\nI'll call you later."
    scene 05_0837 with dissolve
    car "He didn't tell me.\nI heard you and Grandma talking about it."
    ali "What??\nGrandma? When??"
    car "When she came to stay after Pete's funeral."
    scene 05_0838 with dissolve
    ali "{i}Pete's{/i} funeral? Oh Jesus."
    scene 05_0839 with dissolve
    car "What am I supposed to call him? {i}Uncle{/i} Pete??"
    car "He's {b}not{/b} my dad!"
    scene 05_0840 with dissolve
    mc "Come on, guys. Take a breath."
    car "He was {b}never{/b} my dad!"
    scene 05_0841 with dissolve
    car "You wanted your perfect little family, no matter the cost!"
    scene 05_0842 with dissolve
    ali "Cara!"
    car "LEAVE ME ALONE!"
    scene 05_0843 with dissolve
    ali "[whi]Fuck!"
    mc "Just give her a minute. Let her cool off."
    scene 05_0844 with dissolve
    ali "You knew!"
    scene 05_0845 with dissolve
    ali "All this time, you fuckin' knew!"
    scene 05_0844 with dissolve
    mc "What?! No!"
    mc "She only told me a few days ago!"
    scene 05_0845 with dissolve
    ali "And you never {b}once{/b} thought to tell me that she knew??"
    ali "You knew how I felt about it, [mc]!"
    mc "She asked me not to! She wanted to talk to you herself."
    scene 05_0846 with dissolve
    ali "Get the fuck out of my house!"
    mc "Ali! Come on!"
    scene 05_0847 with vpunch
    ali "{b}GET OUT!!"
    scene 05_0848 with dissolve
    mc "FINE!\nCall me once you've calmed down."
    scene 05_0855 with Fade(1, 0.5, 1)
    mct "Damn it."
    scene 05_0856 with dissolve
    mc "Alysha?"
    scene 05_0857 with dissolve
    aly "You blocked me in."
    mc "Ah, yeah... Sorry."
    scene 05_0858 with dissolve
    mc "You weren't gonna knock and ask me to move it?"
    aly "I figured you needed a few minutes."
    scene 05_0859 with dissolve
    aly "Why the hell didn't you call to tell me you were okay??"
    mc "I couldn't. They have my cell."
    aly "What happened?"
    mc "Nothing good."
    scene 05_0860 with dissolve
    mc "I... uhh... need you to do something."
    $ dia = "There" + (" are a couple of bodies" if Plr.Has("DR") else "'s a body") + " dumped at the edge of town..."
    mc "[dia]"
    aly "What the fuck?? You can't be serious?!"
    scene 05_0861 with dissolve
    mc "I didn't have a choice, Alysha!"
    $ dia = "It was " + ("them" if Plr.Has("DR") else "him") + " or me."
    mc "[dia]"
    scene 05_0862 with dissolve
    aly "Jesus, [mc]!\nAre you actually confessing to {b}a cop{/b} that you killed someone?"
    $ dia = "No! I didn't kill " + ("them!" if Plr.Has("DR") else "him!")
    mc "[dia]"
    aly "Good!\nBecause if you had, I'd be hauling your ass in right now!"
    scene 05_0863 with dissolve
    $ dia = "I need you to find the " + ("bodies" if Plr.Has("DR") else "body") + " and call it in."
    mc "[dia]"
    if Plr.Has("DR"):
        scene 05_0864 with dissolve
        mc "They're James and Simon."
        mc "James was Sue's right-hand man. Except he wasn't {i}her{/i} man.\nI think he was there to keep tabs on her."
        mc "Simon was just muscle.\nHe and another grunt, Douglas, got caught skimming."
        scene 05_0865 with dissolve
        aly "And where's this Douglas?"
        mc "I gave him James' van, told him to run and not look back."
        aly "Why would you do that?"
        mc "Because he's the one who pulled the trigger."
        scene 05_0866 with dissolve
        mc "Or at least, that's the story we need out there."
        aly "Hold on. If he didn't... then who {i}did{/i}?"
        mc "... Sue."
        scene 05_0867 with dissolve
        aly "Fuck!"
        aly "Then we've got her! I can slap the cuffs on her right now."
        scene 05_0868 with dissolve
        mc "NO!"
        scene 05_0869 with dissolve
        mc "She saved my life."
        mc "If she hadn't fired, I'd be dead."
        scene 05_0870 with dissolve
        mc "Take her off the board and we lose everything!"
        mc "She'll be replaced before sunrise. Everything we've done will mean nothing."
        scene 05_0871 with dissolve
        aly "So what are you asking me to do, [mc]? Because it sounds a hell of a lot like obstruction."
        scene 05_0872 with dissolve
        mc "Make sure the bodies are found.\nMake Douglas your only suspect."
        mc "I smeared some of his blood on them. Linking him won't be hard."
        scene 05_0873 with dissolve
        mc "Sue's husband... Michael, right?"
        aly "Uh, yeah... I think so."
        mc "I think James was involved in the carjacking.\nSue threw it in his face right before she pulled the trigger."
        mc "Might be worth digging deeper."
        scene 05_0874 with dissolve
        aly "Shit, [mc]! Do you hear yourself?\nYou're asking me to frame someone for murder."
        mc "No. I'm asking you to follow the trail that's already there."
        mc "Douglas is gone. You won't find him, and hopefully neither will they."
        scene 05_0875 with dissolve
        mc "I need to see Sue."
        mc "After everything that's happened, I think she's ready to trust me."
        scene 05_0876 with dissolve
        aly "Fuck.\nThis is insane. I don't like it. Not one bit."
        aly "I wanted to expose dirty cops! But... this??"
        mc "Meet me later.\nWe'll go through everything, build a plan that works."
        aly "... Fine. Yeah.\nBut if this blows back on me..."
        mc "It won't."
        aly "Okay...\nWhere are the bodies?"
        mc "Right... Head south out of town..."
    else:
        scene 05_0864 with dissolve
        mc "The dead guy... his name's James."
        mc "He was Sue's right-hand man. Except he wasn't {i}her{/i} man.\nI think he was there to keep tabs on her."
        scene 05_0865 with dissolve
        aly "Hold on. If you didn't... then who {i}did{/i}?"
        mc "... Sue."
        scene 05_0867 with dissolve
        aly "Fuck!"
        aly "Then we've got her! I can slap the cuffs on her right now."
        scene 05_0868 with dissolve
        mc "NO!"
        scene 05_0869 with dissolve
        mc "She saved my life."
        mc "If she hadn't fired, I'd be dead."
        scene 05_0870 with dissolve
        mc "Take her off the board and we lose everything!"
        mc "She'll be replaced before sunrise. Everything we've done will mean nothing."
        scene 05_0871 with dissolve
        aly "So what are you asking me to do, [mc]? Because it sounds a hell of a lot like obstruction."
        scene 05_0872 with dissolve
        mc "Make sure the body's found.\nMake it known that it looks like a drug deal gone bad."
        mc "I've made sure you won't find any evidence linking either me or Sue."
        scene 05_0873 with dissolve
        mc "Sue's husband... Michael, right?"
        aly "Uh, yeah... I think so."
        mc "I think James was involved in the carjacking.\nSue threw it in his face right before she pulled the trigger."
        mc "Might be worth digging deeper."
        scene 05_0874 with dissolve
        aly "Shit, [mc]! You're asking me to file a false report?!"
        mc "I'm asking you to make sure this doesn't point to Sue."
        scene 05_0875 with dissolve
        mc "I need to go."
        mc "After everything that's happened, I think she's ready to trust me."
        scene 05_0876 with dissolve
        aly "Fuck.\nThis is insane. I don't like it. Not one bit."
        aly "I wanted to expose dirty cops! But... this??"
        mc "Meet me later.\nWe'll go through everything, build a plan that works."
        aly "... Fine. Yeah.\nBut if this blows back on me..."
        mc "It won't."
        aly "Okay...\nWhere can I find the body?"
        mc "Right... Head south out of town..."
    scene black with Fade(3, 1, 0)
    jump Springhaven_VisitSue
return

label Springhaven_TheBigDay:
    pause 2.0
    call CenterText ("The next morning.")
    scene 05_0777 with Fade(0,0,2)
    pause
    scene 05_0778 with dissolve
    ali "Okay, I've managed to get the day off work."
    mc "You sure you don't want me here?"
    scene 05_0779 with dissolve
    ali "No, I'm fine!"
    mc "You are?"
    scene 05_0780 with dissolve
    ali "Yes! Why?"
    mc "You haven't stopped pacing around the house since you got out of bed."
    scene 05_0781 with dissolve
    ali "I'm just nervous!"
    ali "Once I sit her down and tell her... It'll be fine!"
    scene 05_0782 with dissolve
    mc "I know.\nDon't worry, it'll be okay!"
    play sound "text.mp3"
    pause 0.5
    scene 05_0783 with dissolve
    pause 0.5
    show screen CellPhone("Sue")
    msg_nvl "We need to have a private conversation."
    msg_nvl "Please visit me at my home as soon as possible."
    mc_nvl "Ok"
    call CloseCell ()
    scene 05_0784 with dissolve
    ali "Was that her? Is she on her way home?"
    mc "No, it was... Uhh, a friend. Wants to meet up."
    scene 05_0785 with dissolve
    ali "Oh, okay."
    mc "Relax, Ali!\nYou're pacing again."
    scene 05_0786 with dissolve
    ali "I'm fine!"
    scene 05_0787 with dissolve
    mc "Heh. Okay."
    scene 05_0788 with dissolve
    mct "Ughh, another private conversation with Sue?"
    scene 05_0789 with dissolve
    mct "Hope she isn't planning on sending me back to Lakeshore."
    car "Morning Dad!"
    scene 05_0790 with dissolve
    mc "Morning Pipsqueak!"
    scene 05_0791 with dissolve
    mc "Did you have fun at your sleepover?"
    car "Yeah!"
    scene 05_0792 with dissolve
    ali "What?..."
    scene 05_0793 with dissolve
    car "Mom!"
    scene 05_0794 with dissolve
    car "You're not at work??"
    scene 05_0795 with dissolve
    ali "What did you just call him?"
    scene 05_0796 with dissolve
    car "[whi]Umm..."
    ali "You {b}know{/b}??"
    scene 05_0797 with dissolve
    ali "{b}YOU ALREADY KNOW??"
    mc "Alison, calm down..."
    scene 05_0798 with dissolve
    ali "I'm so sorry, Sweetheart."
    scene 05_0799 with dissolve
    ali "I trusted you! You promised!"
    ali "You need to leave."
    scene 05_0800 with dissolve
    mc "Whoa! I didn't tell her!"
    ali "No one else knew!"
    scene 05_0801 with dissolve
    car "He didn't tell me, Mom."
    car "I heard you and Grandma talking about it."
    ali "Grandma? When??"
    scene 05_0802 with dissolve
    car "When she came to stay after Pete's funeral."
    ali "{i}Pete's{/i} funeral? Oh Jesus."
    scene 05_0803 with dissolve
    car "What am I supposed to call him? {i}Uncle{/i} Pete??"
    car "He's {b}not{/b} my dad!"
    scene 05_0804 with dissolve
    mc "Come on, guys. Take a breath."
    car "He was {b}never{/b} my dad!"
    scene 05_0805 with dissolve
    car "You wanted your perfect little family, no matter the cost!"
    scene 05_0806 with dissolve
    ali "Cara!"
    car "LEAVE ME ALONE!"
    scene 05_0807 with dissolve
    ali "[whi]Fuck!"
    mc "Just give her a minute. Let her cool off."
    scene 05_0808 with dissolve
    ali "You knew!"
    ali "All this time, you fuckin' knew!"
    mc "What?! No!"
    mc "She only told me a few days ago!"
    scene 05_0809 with dissolve
    ali "And you never {b}once{/b} thought to tell me that she knew??"
    ali "You knew how I felt about it, [mc]!"
    mc "She asked me not to! She wanted to talk to you herself."
    scene 05_0810 with dissolve
    ali "I've already told you once... You need to leave!"
    mc "Ali! Come on!"
    scene 05_0811 with vpunch
    ali "{b}GET OUT!!"
    scene 05_0812 with dissolve
    mc "FINE!\nCall me once you've calmed down."
    scene 05_0855 with Fade(1, 0.5, 1)
    mct "Damn it."
    jump Springhaven_VisitSue
return

label Springhaven_VisitSue:
    scene 05_0877 with Fade(1, 3, 3)
    pause
    play sound "doorbell.mp3"
    scene 05_0878 with dissolve
    pause 0.5
    scene 05_0879 with dis1
    scene 05_0880 with dis1
    ki "She's waiting for you in her office."
    mc "Thanks, Kiyomi."
    if MiyukaEscaped:
        call Springhaven_VisitSue_P0 (True)
    elif not MiyukaDelivered:
        call Springhaven_VisitSue_P0 (False)
    else:
        call Springhaven_VisitSue_P2
    scene 05_1007 with Fade(3, 2, 2)
    pause 1.0
    show screen CellPhone("Alysha")
    mc_nvl "Can we meet?"
    msg_nvl "Sorry, I can't."
    if MiyukaEscaped:
        msg_nvl "Things are too hectic here, since, you know..."
    else:
        msg_nvl "Things are hectic at work right now. I can't just leave."
    mc_nvl "Later then?"
    msg_nvl "Yeah."
    msg_nvl "If I send you my home address, we can meet there after I've finished work?"
    mc_nvl "Ok"
    call CloseCell ()
    scene 05_1008 with dissolve
    mct "Everything's going to shit."
    mct "Need to clear my head. Just drive around for a while."
    play sound "car_pull.mp3"
    scene 05_1009 with fade
    scene 05_1010 with dissolve
    scene 05_1011 with dissolve
    scene 05_1012 with dissolve
    scene 05_1013 with dissolve
    pause 0.5
    scene black with Fade(2, 0,0)
    jump Springhaven_VisitAlysha
return

label Springhaven_VisitSue_P0(run):
    scene 05_0883 with dissolve
    ki "He here, Miss."
    scene 05_0884a with dissolve
    sue "Please, take a seat."
    if run:
        call Springhaven_VisitSue_Plan (Plr.Has("DR"))
    scene 05_0886 with dissolve
    if run:
        sue "The girl you... misplaced."
        sue "Her name is Miyuka."
    else:
        sue "Your assignment to Brook Ridge was to pick up a girl and deliver her here."
        sue "The girl's name is Miyuka."
    scene 05_0926 with dissolve
    ki "[whi]What?"
    scene 05_0886 with dissolve
    sue "She is Kiyomi's sister."
    if run:
        sue "We need to locate her."
        scene 05_0887 with dissolve
        mc "I told you already.\nAfter she ran, I looked everywhere!"
        sue "Yes.\nWe know not her {i}current{/i} location, but her destination... I suspect she will attempt to return home."
        mc "And where's that?"
        scene 05_0888 with dissolve
        sue "That's not why you were summoned here."
        mc "Uh... Okay."
    else:
        sue "She will arrive here tomorrow.\nI'm positive she would have been more comfortable traveling with you, but what's done is done."
        mc "I already apologized, Sue! Jeez!"
        mc "Did you really drag me out here just to chew my ass again??"
        $ MiyukaSpringhaven=True
        scene 05_0888 with dissolve
    sue "I {b}need{/b} to trust you, [mc]."
    sue "We don't have the time to build that trust the way I'd prefer."
    sue "Hesitant though I am, I have no alternative other than to place my trust in you."
    scene 05_0889a with dissolve
    mc "Why?"
    sue "Collecting debts isn't the reason I asked for your service. Not the {i}real{/i} reason."
    mc "Okay."
    sue "I'm trapped in a situation I cannot escape - not without help."
    sue "Even speaking to you now puts us both in greater danger."
    scene 05_0890a with dissolve
    mc "Yet you're comfortable discussing it in front of an audience?"
    sue "Kiyomi will not betray us; she and her sister need your help as much as I do."
    scene 05_0892 with dissolve
    mc "I presume this also concerns your daughter?"
    mc "Seems the list of people depending on me keeps getting longer."
    sue "Indeed."
    mc "Alright. I'm listening."
    scene 05_0893a with dissolve
    call Emotion (sue, "Sigh", "Very well.")
    scene 05_0894a with dissolve
    sue "How much do you {i}already{/i} know about me?"
    scene 05_0895a with dissolve
    mc "You and your husband created a low-cost loan service."
    mc "Helping locals build businesses. Building the community."
    scene 05_0896a with dissolve
    sue "Yes."
    sue "At first, I thought Michael naïve - ready to be taken advantage of."
    sue "But instead, it flourished. Investors circled like vultures."
    scene 05_0897 with dissolve
    sue "One man in particular promised expansion across the entire state.\nMichael leaped at the chance."
    sue "It was the worst decision he ever made."
    scene 05_0898 with dissolve
    sue "One that ultimately cost him his life."
    scene 05_0899 with dissolve
    sue "The {i}investor{/i} was no investor. He was a parasite."
    sue "He slithered his way into our company, our lives, and dismantled everything from within."
    scene 05_0900 with dissolve
    sue "By the time we uncovered the truth, the trap was already sprung.\nWe tried to pull away, but..."
    scene 05_0901 with dissolve
    sue "That's when they decided to kill him."
    scene 05_0902 with dissolve
    sue "They spared Melissa and me - on one condition."
    mc "You became their puppet."
    scene 05_0903 with dissolve
    sue "Yes. Enabling them to remain hidden from view.\nThey stripped me of everything - every asset, every freedom."
    sue "Only this house remains, and even that feels like a prison."
    scene 05_0904 with dissolve
    sue "For years, I obeyed. No questions, no hesitation."
    sue "Meanwhile, the company grew into darker things."
    scene 05_0905a with dissolve
    sue "Last year, I tried to get Melissa out. I failed.\nThey grew suspicious. And then..."
    sue "... they sent James."
    scene 05_0906a with dissolve
    sue "Can you believe that?!\nThey put the {b}murderer of my husband{/b} in charge of watching me!"
    scene 05_0907 with dissolve
    if not run:
        mc "{i}James{/i} killed your husband? Damn."
    else:
        mc "Yeah, I figured that's why you pulled the trigger."
    sue "Others were sent to shadow Melissa at college. She's under constant surveillance."
    scene 05_0908 with dissolve
    if not run:
        sue "James can be a cruel man."
        sue "He taunts me. Dropping hints, implying harm has come to her."
    else:
        sue "James could be a cruel man."
        sue "He would taunt me. Drop hints, implying harm had come to her."
    scene 05_0909a with dissolve
    mc "That's why you sent me to Lakeshore."
    sue "Yes."
    mc "She looked fine when I saw her. Guarded, maybe, but unharmed."
    scene 05_0910 with dissolve
    mc "Okay... Let's say I believe you... what's the plan?"
    sue "The plan?"
    scene 05_0911 with dissolve
    sue "{b}YOU{/b} are the plan."
    scene 05_0912 with dissolve
    sue "When I was informed of the incident at the cafe, I was expected to order your punishment immediately."
    sue "To this day, I know not why I hesitated and requested additional background information first."
    scene 05_0913 with dissolve
    sue "When I saw your file... I knew. You were my chance. My last chance."
    sue "You've faced impossible odds before, and you chose civilians over orders."
    sue "That's rare. That's why I knew I could gamble everything on you."
    scene 05_0914a with dissolve
    mc "Great. So there is no plan. Just me.\nAnd why would I help you? After everything you've done?"
    sue "I..."
    scene 05_0915 with dissolve
    sue "Because it takes a certain kind of man to do what you've done.\nA soldier who risked his life for his country."
    sue "A man who protects the innocent."
    scene 05_0916 with dissolve
    sue "{i}My daughter{/i} is innocent."
    scene 05_0917a with dissolve
    sue "{i}Kiyomi{/i} is innocent. {i}Her sister{/i} is innocent."
    sue "{b}They{/b} are the ones I'm begging you to help, not me."
    scene 05_0918 with dissolve
    sue "Melissa should not pay for my sins."
    sue "That's my burden, and mine alone."
    scene 05_0919 with dissolve
    sue "Please, [mc]. Help them."
    scene 05_0920a with dissolve
    mc "You haven't told me how Kiyomi and her sister are involved.\nIf you want my help, I need {b}everything{/b}."
    sue "And you shall have it."
    if not run:
        sue "For now, know they'll be safe here. Melissa is not."
    else:
        sue "For now, Kiyomi is safe here, and once we recover her sister, she too will find safety here."
        sue "Melissa is {b}not{/b} safe."
    sue "She must be your priority."
    scene 05_0921a with dissolve
    mc "[whi]Fuck."
    sue "Indeed."
    scene 05_0922 with dissolve
    mc "I need to think about it."
    sue "An expected and natural response.\nBut please, don't linger too long.\nEvery moment of hesitation brings more risk."
    scene 05_0923 with dissolve
    sue "This conversation has already taxed me more than I can bear.\nWe can discuss things further once you've made your decision."
    sue "Now, I need to relax."
    scene 05_0924a with dissolve
    sue "Kiyomi!"
    scene 05_0925a with dissolve
    sue "You are excused."
    if Sue.isActive() and Sue.isSexual():
        $ tCh=Sue.Has("EZ")
        if not EzModeActive:
            menu:
                "Leave[wk_c]":
                    $ tCh=False
                "[wk_y]Stay":
                    $ tCh=True
        if tCh:
            call SueReplay02
            if run:
                scene 05_1000 with fade
                ki "Wait!"
                scene 05_1001 with dissolve
                ki "She told me to give you this."
                mc "Right, my cell. Thanks, Kiyomi."
            return
        else:
            call CloseCharacterPath (Sue, "Sue")
    else:
        call CloseCharacterPath (Sue)
    if run:
        scene 05_0927 with dissolve
        sue "One moment..."
        scene 05_0928 with dissolve
        sue "This belongs to you."
        mc "Right."
    else:
        scene 05_0927 with dissolve
        sue "I'm sorry you were dragged into this, [mc]."
        mc "No you're not."
    scene 05_0929 with fade
    pause 0.5
return

label Springhaven_VisitSue_P2:
    scene 05_0881 with dissolve
    mc "How's your sister?"
    ki "Okay."
    if Plr.Has("Mat_Hit") or Miyuka.Has("Food"):
        scene 05_0882 with dissolve
        ki "She told me what you did for her.\nThank you."
        mc "No problem."
    scene 05_0883 with dissolve
    ki "He here, Miss."
    scene 05_0884 with dissolve
    sue "Please, take a seat."
    scene 05_0885 with dissolve
    mc "She's your maid?"
    sue "For now."
    mc "Then why the hell was she locked in a cage, in another town?"
    sue "You ask too many questions."
    scene 05_0886 with dissolve
    if Plr.Has("Sue_MH"):
        sue "Yesterday, you brought up my husband.\nI did not indicate my marital status, so who gave you that information?"
        mc "You checked {i}my{/i} background. You didn't think I'd do the same?"
        sue "You implied I was responsible for his death. Why?"
        scene 05_0887 with dissolve
        mc "I don't think you killed him, but I also don't buy the story that he was killed for his car."
        mc "No. It looked like a message. A warning. Something bigger.."
    else:
        sue "Yesterday, you thought to threaten me with revealing particular information to James.\nInformation he already possesses."
        mc "Does he?"
        sue "Why wouldn't he?"
        scene 05_0887 with dissolve
        mc "You made sure I didn't take my cell along with me.\nJames is responsible for keeping you updated with my location, tracked through my cell."
        mc "You didn't want him to know I was in Lakeshore. Why?"
    scene 05_0888 with dissolve
    sue "I {b}need{/b} to trust you, [mc]."
    sue "We don't have the time to build that trust the way I'd prefer."
    sue "Hesitant though I am, I have no alternative other than to place my trust in you."
    mc "Why?"
    scene 05_0889 with dissolve
    sue "Collecting debts isn't the reason I asked for your service. Not the {i}real{/i} reason."
    mc "Okay."
    sue "I'm trapped in a situation I cannot escape - not without help."
    sue "Even speaking to you now puts us both in greater danger."
    scene 05_0890 with dissolve
    mc "Yet you're comfortable discussing it in front of an audience?"
    scene 05_0891 with dissolve
    sue "These girls will not betray us. They need your help as much as I do."
    scene 05_0892 with dissolve
    mc "I presume this also concerns your daughter?"
    mc "Seems the list of people depending on me keeps getting longer."
    sue "Indeed."
    mc "Alright. I'm listening."
    scene 05_0893 with dissolve
    call Emotion (sue, "Sigh", "Very well.")
    scene 05_0894 with dissolve
    sue "How much do you {i}already{/i} know about me?"
    scene 05_0895 with dissolve
    mc "You and your husband created a low-cost loan service."
    mc "Helping locals build businesses. Building the community."
    scene 05_0896 with dissolve
    sue "Yes."
    sue "At first, I thought Michael naïve - ready to be taken advantage of."
    sue "But instead, it flourished. Investors circled like vultures."
    scene 05_0897 with dissolve
    sue "One man in particular promised expansion across the entire state.\nMichael leaped at the chance."
    sue "It was the worst decision he ever made."
    scene 05_0898 with dissolve
    sue "One that ultimately cost him his life."
    scene 05_0899 with dissolve
    sue "The {i}investor{/i} was no investor. He was a parasite."
    sue "He slithered his way into our company, our lives, and dismantled everything from within."
    scene 05_0900 with dissolve
    sue "By the time we uncovered the truth, the trap was already sprung.\nWe tried to pull away, but..."
    scene 05_0901 with dissolve
    sue "That's when they decided to kill him."
    scene 05_0902 with dissolve
    sue "They spared Melissa and me - on one condition."
    mc "You became their puppet."
    scene 05_0903 with dissolve
    sue "Yes. Enabling them to remain hidden from view.\nThey stripped me of everything - every asset, every freedom."
    sue "Only this house remains, and even that feels like a prison."
    scene 05_0904 with dissolve
    sue "For years, I obeyed. No questions, no hesitation."
    sue "Meanwhile, the company grew into darker things."
    scene 05_0905 with dissolve
    sue "Last year, I tried to get Melissa out. I failed.\nThey grew suspicious. And then..."
    sue "... they sent James."
    scene 05_0906 with dissolve
    sue "Can you believe that?!\nThey put the {b}murderer of my husband{/b} in charge of watching me!"
    scene 05_0907 with dissolve
    mc "{i}James{/i} killed your husband? Damn."
    sue "Others were sent to shadow Melissa at college. She's under constant surveillance."
    scene 05_0908 with dissolve
    sue "James can be a cruel man."
    sue "He taunts me. Dropping hints, implying harm has come to her."
    scene 05_0909 with dissolve
    mc "That's why you sent me to Lakeshore."
    sue "Yes."
    mc "She looked fine when I saw her. Guarded, maybe, but unharmed."
    scene 05_0910 with dissolve
    mc "Okay... Let's say I believe you... what's the plan?"
    sue "The plan?"
    scene 05_0911 with dissolve
    sue "{b}YOU{/b} are the plan."
    scene 05_0912 with dissolve
    sue "When I was informed of the incident at the cafe, I was expected to order your punishment immediately."
    sue "To this day, I know not why I hesitated and requested additional background information first."
    scene 05_0913 with dissolve
    sue "When I saw your file... I knew. You were my chance. My last chance."
    sue "You've faced impossible odds before, and you chose civilians over orders."
    sue "That's rare. That's why I knew I could gamble everything on you."
    scene 05_0914 with dissolve
    mc "Great. So there is no plan. Just me.\nAnd why would I help you? After everything you've done?"
    sue "I..."
    scene 05_0915 with dissolve
    sue "Because it takes a certain kind of man to do what you've done.\nA soldier who risked his life for his country."
    sue "A man who protects the innocent."
    scene 05_0916 with dissolve
    sue "{i}My daughter{/i} is innocent."
    scene 05_0917 with dissolve
    sue "{i}These girls{/i} are innocent."
    sue "{b}They{/b} are the ones I'm begging you to help, not me."
    scene 05_0918 with dissolve
    sue "Melissa should not pay for my sins."
    sue "That's my burden, and mine alone."
    scene 05_0919 with dissolve
    sue "Please, [mc]. Help them."
    scene 05_0920 with dissolve
    mc "You haven't told me how these girls are involved.\nIf you want my help, I need {b}everything{/b}."
    sue "And you shall have it."
    sue "For now, know they're safe here. Melissa is not."
    sue "She must be your priority."
    scene 05_0921 with dissolve
    mc "[whi]Fuck."
    sue "Indeed."
    scene 05_0922 with dissolve
    mc "I need to think about it."
    sue "An expected and natural response.\nBut please, don't linger too long.\nEvery moment of hesitation brings more risk."
    scene 05_0923 with dissolve
    sue "This conversation has already taxed me more than I can bear.\nWe can discuss things further once you've made your decision."
    sue "Now, I need to relax."
    scene 05_0924 with dissolve
    sue "Kiyomi!"
    scene 05_0925 with dissolve
    sue "You are excused."
    if Sue.isActive() and Sue.isSexual():
        if not Sue.Has("EZ"):
            menu:
                "Leave[wk_c]":
                    call CloseCharacterPath (Sue, "Sue")
                "[wk_y]Stay":
                    call SueReplay02
                    return
        else:
            call SueReplay02
            return
    else:
        call CloseCharacterPath (Sue)
    scene 05_0927 with dissolve
    sue "I'm sorry you were dragged into this, [mc]."
    mc "No you're not."
    scene 05_0929 with fade
    pause 0.5
return

label Springhaven_VisitSue_Plan(SiDead):

    scene 05_1002 with dissolve
    mc "Have you informed your boss about James's no-show?"
    sue "Yes."
    mc "Good."
    $ dia = "The cops are about to find the " + ("bodies." if SiDead else "body.")
    mc "[dia]"
    scene 05_1003 with dissolve
    sue "Explain yourself!\nWe don't {i}usually{/i} allow the authorities to discover our mistakes!"
    mc "That's exactly why they {b}have{/b} to!"
    mc "Your boss would never expect James' body to be found if {i}you{/i} were involved."
    if SiDead:
        scene 05_1004 with dissolve
        sue "Why did you allow Douglas to live?"
        mc "We needed a suspect to remove any suspicion from you.\nNow we have one."
        sue "Suspect?? He witnessed the event!\nHe's a loose end that should've been dealt with!"
        sue "What if he talks?? Where is he?"
        scene 05_1005 with dissolve
        mc "Gone."
        mc "His blood is on both victims.\nHis prints are all over the gun, which I left at the scene."
        mc "He took James' van, and he's fled the state."
        sue "Why would he run? It makes him look guilty."
        mc "Exactly."
        mc "I gave him the choice: run, or die."
        scene 05_1006 with dissolve
        sue "Very well.\nYour plan may have bought us some time, nothing more."
        sue "They will hunt him down, and they {b}will{/b} find him."
    else:
        scene 05_1004 with dissolve
        sue "And how would you explain his death?"
        mc "I left the scene looking like a drug deal that went sideways."
        scene 05_1006 with dissolve
        sue "Very well.\nYour plan may have bought us some time, nothing more."
return

label Springhaven_VisitAlysha:
    $ Plr.Del("Sue_MD")
    $ Plr.Del("Sue_MH")
    scene black with Fade(3, 1, 0)
    call CenterText ("Later that evening.")
    play music "thunder_bg.mp3" loop
    scene 06_0001 with Fade(0, 0, 3)
    mct "134... 135..."
    scene 06_0002 with dissolve
    mct "Okay, 138."
    play sound "knock.mp3"
    scene 06_0003 with dissolve
    pause
    scene 06_0004 with dissolve
    aly "Hey.\nCome on in."
    mc "Thanks."
    scene 06_0005 with dissolve
    aly "Ignore what I'm wearing.\nJust got out of the shower."
    aly "Been a helluva day."
    play sound "closedoor.mp3"
    scene 06_0006 with dissolve
    if MiyukaEscaped:
        mc "Yeah, sorry."
    else:
        mc "Everything okay?"
        aly "Yeah."
    if MiyukaEscaped:
        scene 06_0007 with dissolve
        aly "I can't do this, [mc]."
        scene 06_0008 with dissolve
        aly "We've crossed a line."
        scene 06_0009 with dissolve
        aly "I'm withholding information in a murder investigation."
        aly "If this comes out, I'll end up in prison!"
        scene 06_0010 with dissolve
        aly "I'm a police officer!\nYou know what happens to cops in prison??"
        scene 06_0011 with dissolve
        aly "I'm {i}so{/i} fucked!"
        mc "You're {b}not{/b} going to prison!"
        mc "Listen to me..."
        scene 06_0012 with dissolve
        mc "Even if you told your superiors everything, you don't have {i}evidence{/i} to prove it!"
        scene 06_0013 with dissolve
        aly "I've got {b}you{/b}! You saw everything!"
        scene 06_0012 with dissolve
        mc "And it'd be my word against hers!"
        mc "That's not evidence, Alysha! You know that.\nYou're just panicking."
        scene 06_0014 with dissolve
        aly "Damn right I'm panicking!\nWhat the fuck are we supposed to do, [mc]?"
        scene 06_0015 with dissolve
        mc "The only thing we can do."
        mc "We take them down. ALL of them."
        scene 06_0016 with dissolve
        aly "And how exactly do we manage that?"
        mc "... I'm still working on it."
        aly "Perfect."
        scene 06_0017 with dissolve
        mc "Did everything go okay at the scene?"
        aly "Mhh-mmh."
        scene 06_0018 with dissolve
        if SimonD:
            aly "Prints on the gun came back to Douglas.\nDNA from the blood is still being processed."
            aly "Officers hit his last known address. Empty. He's gone."
        else:
            aly "Not sure how long anyone will buy the whole {i}drug deal-gone-bad{/i} thing, though."
            aly "He had a lot of cash on him, so that helped."
        scene 06_0019 with dissolve
        aly "Looks like your boss is free and clear."
        scene 06_0020 with dissolve
        mc "For now."
        mc "But she {b}will{/b} pay.\nI'll make sure of it, Alysha. I promise."
        scene 06_0021 with dissolve
        aly "She'd better.\nI'll get you a beer."
        mc "Thanks."
        scene 06_0022 with dissolve
        aly "Sounds rough out there."
        mc "Yeah, storms coming."
        aly "Kinda poetic."
        scene 06_0023 with dissolve
        mc "Who's the kid in the picture?"
        aly "Me, with my father."
        scene 06_0024 with dissolve
        mc "Wow!\nYou were cute! What happened?"
        aly "[lol] Fuck you!"
        scene 06_0025 with dissolve
        mc "{i}Now{/i} I get it."
        aly "Get what?"
        scene 06_0026 with dissolve
        mc "Why you're a cop."
        mc "And why you were so quick to help after I told you I was ex-military."
        scene 06_0027 with dissolve
        aly "Maybe I just have a thing for men in uniforms.[lol]"
        play music "rain.mp3" loop volume 0.3
        scene 06_0028 with dissolve
        aly "You meet with your boss?"
        mc "Yeah."
        aly "And??"
        mc "Okay..."
        call Springhaven_UpdateAlysha02
    else:
        scene 06_0007 with dissolve
        aly "What's up? Got an update for me?"
        scene 06_0017 with dissolve
        mc "Yeah.\nI had a meeting with Sue earlier, and wanted to fill you in."
        scene 06_0018 with dissolve
        aly "Okay, want a beer before you start?"
        mc "Yeah, sure."
        scene 06_0022 with dissolve
        aly "Sounds rough out there."
        mc "Yeah, storms coming."
        scene 06_0023 with dissolve
        mc "Who's the kid in the picture?"
        aly "Me, with my father."
        scene 06_0024 with dissolve
        mc "Wow!\nYou were cute! What happened?"
        aly "[lol] Fuck you!"
        scene 06_0025 with dissolve
        mc "{i}Now{/i} I get it."
        aly "Get what?"
        scene 06_0026 with dissolve
        mc "Why you're a cop."
        mc "And why you were so quick to help after I told you I was ex-military."
        scene 06_0027 with dissolve
        aly "Maybe I just have a thing for men in uniforms.[lol]"
        play music "rain.mp3" loop volume 0.3
        scene 06_0028 with dissolve
        aly "Okay, you met with your boss... Let's hear it."
        call Springhaven_UpdateAlysha02
    if Dawn.isActive():
        jump Springhaven_VisitSarah
    elif Mary.isActive():
        jump Springhaven_VisitMary
    scene 06_0046 with dissolve
    mc "Okay, I'll get outta your hair.\nNeed to find a motel before it gets too late."
    if MiyukaEscaped:
        aly "Alison still pissed at you?"
        mc "Yeah."
    else:
        aly "A motel??\nThought you lived with Alison?"
        mc "Yeah. Giving her space to... cool down."
    aly "That sucks."
    scene 06_0047 with dissolve
    aly "I only have one bed, but the couch is yours if you want it."
    scene 06_0042 with dissolve
    mc "Uhh, you don't mind?\nDon't really fancy scouring the city for a place to stay in this weather."
    aly "I wouldn't have offered if I didn't mean it."
    mc "Great. Thanks."
    scene 06_0048 with dissolve
    aly "And so there's no misunderstanding, it's not an invitation to fuck."
    aly "It's just the couch.\nWe need to keep things professional between us."
    scene 06_0049 with dissolve
    mc "I didn't think even for a minute it was anything but! Heh."
    aly "Good.[lol]"
    scene 06_0050 with dissolve
    aly "In that case, I'll fetch you some blankets, and then I'll hit the sack."
    aly "I'm exhausted and have the early shift tomorrow."
    scene 06_0051 with Fade(1, 2, 1)
    mc "[whi]...ZZzzzz..."
    stop music fadeout 5.0
    scene 06_0205 with Fade(3, 2, 3)
    mc "[whi]Zzzzz..."
    play sound "curtain.mp3" 
    scene 06_0206 with dissolve
    call Emotion (mc, "Groan")
    aly "Mornin', Princess."
    scene 06_0207 with dissolve
    mc "[whi]... Mornin'..."
    aly "Made you coffee."
    mc "[whi]Great."
    scene 06_0208 with dissolve
    aly "Sleep alright on there?"
    mc "Yeah, not as uncomfortable as it looks."
    scene 06_0209 with dissolve
    aly "Good.\nI need to get ready for work."
    mc "Okay."
    scene 06_0210 with Fade(1, 2, 1)
    mct "I need to visit Violet and Millie... Let them know the Cara news..."
    if Nettie.isActive():
        mct "Ahh shit... Nettie."
        mct "She should be told too.\nShe has a right to know her brother isn't Cara's father, no matter how she feels about him."
    mct "..."
    mct "Once I tell Sue I'm gonna help her, that'll require another trip to Lakeshore..."
    mct "Just need to figure out HOW I'm gonna help her..."
    pause 0.5
    play sound "text.mp3"
    pause 0.5
    scene 06_0211 with dissolve
    pause 0.75
    call Springhaven_AlisonMsgAfterFight
    scene 06_0212 with dissolve
    pause
    jump Springhaven_ReturnToAlisonsAfterFight
return

label Springhaven_UpdateAlysha02:
    call CenterText ("You share all the information learnt from Sue with Alysha.", True)
    scene 06_0029 with Fade(0,0,2)
    aly "Damn.\nAs soon as I read the report, I knew that carjacking story was bullshit!"
    aly "So... you believe her?"
    scene 06_0030 with dissolve
    mc "{i}Some{/i} of it."
    mc "I believe she's tellin' the truth about her daughter.\nShe's frightened, no doubt about that."
    scene 06_0031 with dissolve
    mc "A lot doesn't make sense, though..."
    mc "Why would they leave her in play?"
    scene 06_0032 with dissolve
    aly "Like she said, so she could be the face."
    aly "Any blowback hits her, not them."
    scene 06_0033 with dissolve
    mc "Okay, but why trust her to {b}actually{/b} run things?"
    mc "Wouldn't you want your {i}own{/i} people in control behind the curtain??"
    if JamesD:
        scene 06_0034 with dissolve
        mc "And the way she took out James."
        mc "I know she had good reason, but still... No hesitation."
        if SimonD:
            mc "Same with Simon. It was instant."
        scene 06_0035 with dissolve
        mc "She's killed before. I guarantee it."
    scene 06_0029 with dissolve
    aly "So, what do we do?"
    mc "Play along. Gather evidence."
    scene 06_0036 with dissolve
    aly "I trust you, [mc], I do..."
    mc "But?"
    aly "We need results. A win. Something!"
    scene 06_0037 with dissolve
    mc "Yeah, I know. I'm workin' on it."
    play sound "thunder01.mp3"
    mc "If I help Melissa, maybe she can give us some answers."
    aly "How can you help her if she's under guard?"
    mc "Not sure yet... I'm workin' on that, too."
    if Dawn.isActive() or Mary.isActive():
        if Dawn.isActive():
            scene 06_0038 with dissolve
            mc "In fact, gonna start right now."
            scene 06_0039 with dissolve
            pause 0.5
            call Springhaven_SarahMsgAtAleshas (Sarah.isActive())
            scene 06_0040 with dissolve
            if Sarah.isActive():
                mct "Need a place to stay the night anyway.\nStill not heard from Alison, guess she's still pissed."
            else:
                mct "Still not heard from Alison, guess she's still pissed."
                mct "Looks like I'll be sleepin' in the truck... Unless Sarah offers me her couch again."
        else:
            play sound "text.mp3"
            pause 0.5
            scene 06_0038 with dissolve
            mc "Uh, sorry..."
            scene 06_0039 with dissolve
            pause 0.5
            call Springhaven_MaryMsgAtAleshas
            scene 06_0040 with dissolve
            mct "Need a place to stay the night anyway.\nStill not heard from Alison, guess she's still pissed."
        scene 06_0041 with dissolve
        aly "Everything okay?"
        scene 06_0042 with dissolve
        mc "Yeah."
        scene 06_0043 with dissolve
        mc "So, are we good?"
        aly "Yes.\nBut results, [mc]. We {b}need{/b} results."
        mc "Understood."
        scene 06_0044 with dissolve
        mc "I'm gonna go. Thanks for the beer."
        aly "Any time."
        scene 06_0045 with dissolve
        aly "Please be careful, [mc].\nThese bastards are dangerous."
        mc "I will, don't worry."
return

label Springhaven_SarahMsgAtAleshas(isActive):
    show screen CellPhone("Sarah")
    $ dia = "Hey.\nSorry, I know it's kinda late but," + (" I'd like to see you." if isActive else " I need your help with something. Can I come over?")
    mc_nvl "[dia]"
    msg_nvl "Hi!\nNow?? Umm... okay, haha!"
    msg_nvl "I was about to get into bed, so don't expect me to look my usual glamorous self!"
    msg_nvl "{image=/thumbs/cell/emoji/crylaugh.png}"
    $ dia = ""+("You always look glamorous {image=/thumbs/cell/emoji/wink.png}"if isActive else "I'm sure you look fine! Haha")
    mc_nvl "[dia]"
    mc_nvl "See you soon"
    msg_nvl "Okay xx"
    call CloseCell ()
return

label Springhaven_MaryMsgAtAleshas:
    show screen CellPhone("Mary")
    msg_nvl "I'm so scared!! {image=/thumbs/cell/emoji/pleading.png}"
    mc_nvl "Mary? What's wrong??"
    msg_nvl "Can't you hear it??"
    mc_nvl "Ohh... the thunderstorm. Right."
    mc_nvl "Don't worry, it'll soon pass!"
    msg_nvl "I'm under my blanket, shaking."
    msg_nvl "I'm all alone again, but now there's thunder.\nI don't like it."
    msg_nvl "Can you come visit?"
    mc_nvl "Where's Bill?"
    msg_nvl "He was on his way home, but the truck broke down!"
    msg_nvl "Won't be fixed until morning.\nDon't think I can survive that long! {image=/thumbs/cell/emoji/sweat.png}"
    msg_nvl "Pleeeeeeeassssseee [mc]! {image=/thumbs/cell/emoji/pray.png}"
    mc_nvl "Okay, guess I can keep you company a while."
    mc_nvl "I'll be there as soon as I can."
    msg_nvl "OMG REALLY?! {image=/thumbs/cell/emoji/shock.png}"
    msg_nvl "{image=/thumbs/cell/emoji/heart sparkling.png}{image=/thumbs/cell/emoji/heart sparkling.png}{image=/thumbs/cell/emoji/heart sparkling.png}"
    call CloseCell ()
return

label Springhaven_VisitSarah:
    $ persistent.SarahRP03Dat=False
    scene black with Fade(3, 2, 3)
    $ renpy.music.set_volume(0.3)
    play sound "knock.mp3"
    scene 06_0213 with fade
    pause 0.5
    scene 06_0214 with dissolve
    sar "Hi."
    scene 06_0215 with Fade(1, 0.5, 1)
    sar "What's the emergency?"
    mc "Emergency?"
    scene 06_0216 with dissolve
    if Sarah.isSexual():
        sar "You don't strike me as the type of guy to make {i}booty calls{/i}!"
        mc "I like booty calls![lol]"
        sar "[lol] I stand corrected!"
        sar "But that's not what this is, right?"
    else:
        sar "It's late, I'm guessing whatever this is couldn't wait until tomorrow, so... emergency."
    scene 06_0217 with dissolve
    mc "I need to return to Lakeshore for a few days."
    mc "I was hoping I could crash at Dawn's place while I'm there?\nWould you mind asking her?"
    if Sarah.isSexual() and not Dawn.isSexual():
        mc "... Only if you're okay with it, of course."
    scene 06_0218 with dissolve
    sar "Oh my God, yes!\nThat's perfect!"
    mc "Uh... it is?"
    scene 06_0219 with dissolve
    sar "She's been begging me to go back!\nI'm so busy at work that it's just impossible right now..."
    sar "But {b}you{/b} can go and keep her company! She'll be so happy!"
    scene 06_0220 with dissolve
    mc "Why's she begging you to go back?\nDoes she still think someone's stalking her?"
    sar "Yes, and I believe her.\nThis isn't just her imagination."
    scene 06_0221 with dissolve
    sar "She even did as we suggested and called the police, but by the time they arrived, the man was gone."
    sar "I'm so worried for her, [mc]."
    scene 06_0222 with dissolve
    sar "Having you there, even if it's only for a couple of days..."
    sar "...It'll put her mind at rest. And honestly, mine too!"
    scene 06_0223 with dissolve
    sar "She likes you a lot, so I know she'll love to have you stay."
    sar "I'll message her tomorrow and let her know you'll be visiting."
    scene 06_0224 with dissolve
    mc "Great. Thanks, Sarah."
    sar "You're helping me, I should be thanking you!"
    if Sarah.isActive():
        scene 06_0227 with dissolve
        sar "Now that's sorted...\nWill you stop playing with my cat..."
        scene 06_0228 with dissolve
        sar "... and come play with my pussy instead?"
        mc "Yes Ma'am."
        call SaraReplay03
        stop music fadeout 5.0
        scene 06_0347 with Fade(2, 4, 2)
        scene 06_0348 with dissolve
        call Emotion (mc, "Groan")
    else:
        mc "Well, actually... There is {i}one{/i} more thing I wanted to ask..."
        mc "Any chance I can crash on your couch again?"
        scene 06_0225 with dissolve
        sar "Yes, of course."
        sar "Is everything okay?"
        mc "Long story, but yeah, everything's fine."
        sar "Okay. I'll get the blanket."
        scene 06_0226 with fade2
        mc "[whi]..Zzzzz.."
        stop music fadeout 5.0
        scene 06_0349 with Fade(2, 4, 2)
        scene 06_0350 with dissolve
        call Emotion (mc, "Groan")
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e06/06_0351.webp", 783, 452, True, "Springhaven_AF27") with Fade(2, 1, 1)
        pause
        $ _skipping = True
        scene 06_0351
        if renpy.get_screen("imgMap"):
            hide screen imgMap 
    else:
        scene 06_0351 with dissolve
        pause
        call Springhaven_AF27
        scene 06_0351 with dissolve
    mct "I need to visit Violet and Millie... Let them know the Cara news..."
    if Nettie.isActive():
        mct "Ahh shit... Nettie."
        mct "She should be told too.\nShe has a right to know her brother isn't Cara's father, no matter how she feels about him."
    mct "..."
    mct "Once I tell Sue I'm gonna help her, that'll require another trip to Lakeshore..."
    mct "Just need to figure out HOW I'm gonna help her..."
    play sound "text.mp3"
    pause 0.5
    scene 06_0353 with dissolve
    pause 0.75
    call Springhaven_AlisonMsgAfterFight
    scene 06_0354 with dissolve
    pause
    jump Springhaven_ReturnToAlisonsAfterFight
return

label Springhaven_VisitMary:
    play music "rain.mp3" loop volume 0.5
    scene 06_0052 with Fade(3, 2, 3)
    pause 0.5
    play sound "thunder01.mp3"
    scene 06_0053 with dissolve
    scene 06_0054
    pause 0.25
    scene 06_0053
    pause 0.25
    scene 06_0055 with dissolve
    mc "Mary?\nIt's [mc], I'm here."
    $ renpy.music.set_volume(0.2)
    scene 06_0056 with dissolve
    mc "HELLO?? MARY?"
    mar "[whi]I'm upstairs."
    scene 06_0057 with dis1
    play music "thunder_bg.mp3" loop volume 0.5
    scene 06_0058 with dis1
    mar "I'm so happy you're here! Thank you for coming!"
    mc "Heh. You're welcome."
    scene 06_0059 with dissolve
    mar "I've been sooo frightened here all alone!"
    scene 06_0060 with dissolve
    mar "Oh dear! You're soaking!\nI'll fetch you a towel."
    mc "Thanks."
    scene 06_0061 with fade
    mc "So Bill's broken down somewhere, huh?"
    mar "Yeah.\nHe was on his way home from Northcrest.\nSomething broke in the truck."
    mar "The mechanic said he won't be able to have it repaired until morning."
    mar "He'll just sleep in the cab."
    scene 06_0062 with dissolve
    mc "Damn, that sucks."
    mar "He'll be okay. He loves to sleep in that thing!"
    scene 06_0063 with dissolve
    mar "I feel so much better knowing you're here!"
    mar "I'll let you get some sleep."
    scene 06_0064 with dissolve
    mar "Goodnight."
    mc "Night, Mary."
    scene 06_0065 with fade2
    pause 1.0
    play sound "thunder01.mp3"
    scene 06_0066
    pause 0.25
    scene 06_0065 with dissolve
    mct "Damn. Poor Bill!"
    scene 06_0067 with dissolve
    mct "Lucky I'm not out there."
    play sound "thunder04.mp3" volume 0.5
    mct "Would've probably ended up sleepin' in the truck had Mary not asked me over."
    if Mary.isSexual():
        call MaryReplay03
    else:
        stop music fadeout 4.0
        scene black with Fade(3, 1, 0)
    scene 06_0183 with Fade(0, 1, 4)
    pause
    scene 06_0184 with dis1
    call Emotion (mc, "Groan")
    scene 06_0185 with Fade(2, 1, 2)
    mc "Mornin'."
    scene 06_0186 with dissolve
    mar "Good morning!"
    mar "Coffee?"
    mc "Yeah, thanks."
    scene 06_0187 with dissolve
    mar "Sleep well?"
    mc "Uh, yeah. You?"
    scene 06_0188 with dissolve
    if Mary.isSexual():
        mar h "Best sleep of my life!"
    else:
        mar "Yes, thank you.\nKnowing you were here helped a lot!"
    scene 06_0189 with dissolve
    mar "I got a message from Pops.\nThe truck's been repaired, and he's on his way home."
    mc "That's good to hear."
    scene 06_0190 with dissolve
    mar "He asked me to thank you on his behalf for coming to my rescue!"
    mc "Anytime."
    scene 06_0191 with dissolve
    mc "Thanks."
    scene 06_0192 with dissolve
    mar "Anytime.[giggles]"
    scene 06_0193 with dissolve
    mct "I need to visit Violet and Millie... Let them know the Cara news..."
    if Nettie.isActive():
        mct "Ahh shit... Nettie."
        mct "She should be told too.\nShe has a right to know her brother isn't Cara's father, no matter how she feels about him."
    mct "..."
    mct "Once I tell Sue I'm gonna help her, that'll require another trip to Lakeshore..."
    mct "Just need to figure out HOW I'm gonna help her..."
    play sound "text.mp3"
    pause 0.5
    scene 06_0194 with dissolve
    pause 0.75
    call Springhaven_AlisonMsgAfterFight
    scene 06_0195 with dissolve
    mar "Are you okay?"
    mc "Yeah.\nSorry, I, uh, need to go."
    scene 06_0196 with dissolve
    mar "Ohh.\nI was going to make breakfast."
    mc "Next time, I promise."
    mar "Okay."
    scene 06_0197 with Fade(1, 0.5, 1)
    mar "I'll see you again soon?"
    mc "Of course."
    if Mary.isSexual():
        scene 06_0198 with dissolve
        mar "And we... can have more sex?"
        mc "If that's what you'd like, then yeah, absolutely!"
        mar "I {b}would{/b} like that."
        if persistent.Preg:
            if Mary.getCumIns()>0:
                scene 06_0199 with dissolve
                mar "Last night...\nYou... Umm... don't think I'll be pregnant, do you??"
                mc "Err... No... I, uh, I doubt it."
                mc "You don't take birth control?"
                scene 06_0200 with dissolve
                mar "No.\nI've never had reason to."
                mar "Should I start taking it?"
            else:
                scene 06_0199 with dissolve
                mar "I should probably... umm... start taking birth control."
                mar "What do you think?"
            menu:
                "Yes, best to be safe":
                    $ Mary.Add("OnBC")
                "No, you don't need it":
                    $ Mary.Add("NoBC")
            scene 06_0201 with dissolve
            mar "Okay."
        scene 06_0202 with dissolve
        mar "[ss]Mmmhhh.."
        scene 06_0203 with dissolve
        mar "[ss]...Mmmmhh..."
    scene 06_0204 with fadehold
    $ dia = "Bye, "  + ("Daddy" if persistent.MaryDaddy else persistent.McName) + "."
    mar "[dia]"
    mc "Bye, Sweetheart."
    jump Springhaven_ReturnToAlisonsAfterFight
return

label Springhaven_AlisonMsgAfterFight:
    stop music
    show screen CellPhone("Alison")
    msg_nvl "[mc]..."
    msg_nvl "I'm sorry for overreacting yesterday."
    msg_nvl "Can you come home so we can talk?"
    mc_nvl "I'll come by later."
    msg_nvl "[mc], please."
    msg_nvl "I have to go to work soon.\nIt'll be on my mind all day, and I'll go crazy if we don't deal with it now."
    msg_nvl "Please, just come home and talk to me."
    call CloseCell ()
return

label Springhaven_ReturnToAlisonsAfterFight:
    scene 05_0212 with Fade(3, 2, 3)
    pause
    scene 06_0355 with dissolve
    mc "Hey."
    scene 06_0356 with dissolve
    ali "Hi."
    ali "Thanks for coming. I wasn't sure you would."
    scene 06_0357 with dissolve
    ali "Can I, uhh, get you a coffee?"
    mc "No, I'm good, thanks."
    scene 06_0358 with dissolve
    ali "I'm sorry for yesterday."
    mc "You were upset. In shock. Understandable."
    mc "You didn't need to kick me out, but I get it.\nLet's just forget about it and move on."
    scene 06_0359 with dissolve
    ali "Really?"
    ali "I was expecting you to be more pissed... furious even... with me."
    mc "What good would it do?"
    scene 06_0360 with dissolve
    mc "How's Cara? Have you talked about it together?"
    ali "Yes. She's fine. We're fine."
    scene 06_0361 with dissolve
    ali "More than fine, actually."
    ali "She understands why we... I... didn't want to tell her."
    scene 06_0362 with dissolve
    ali "I have {b}you{/b} to thank for that, too."
    ali "You told her it was a decision we had made {i}together{/i}."
    scene 06_0363 with dissolve
    mc "I didn't want her to put all the blame on you.\nYou had your reasons, some I even agreed with."
    ali "She also told me how you kept telling her that she should come clean to me about knowing."
    mc "She wanted to tell you, she was just waiting for the right opportunity, I guess."
    scene 06_0364 with dissolve
    ali "I'm glad she felt able to tell you and talk to you about it.\nI think it helped her a lot."
    ali "Can you forgive me?\nNot just for yesterday. I was wrong to keep it from her."
    mc "You were doing what you thought was best for our daughter.\nThere's nothing to forgive, Alison."
    scene 06_0365 with dissolve
    ali "You're a good man, [mc]. A good father too."
    if Alison.Has("Knows"):
        scene 06_0366 with dissolve
        ali "I'm worried for you, though."
        ali "I don't like that you're involved with those assholes."
        ali "Why didn't you tell me??"
        scene 06_0367 with dissolve
        mc "I didn't want you to worry!"
        mc "It was the only way to get them to write off your debt and leave you alone."
        mc "Alysha asked me to help her, and I agreed."
        scene 06_0368 with dissolve
        ali "Okay.\nI hope you know what you're doing."
    scene 06_0369 with dissolve
    ali "I need to get to work."
    mc "Need a ride?"
    ali "No, Christina's working the same shift, so I'll go in with her."
    scene 06_0370 with dissolve
    ali "I'll see you tonight?"
    scene 06_0371 with dissolve
    mc "Err, actually, I'm thinking about going to visit Millie again."
    mc "I need to tell her about Cara."
    scene 06_0372 with dissolve
    ali "Oh God, of course! Yes, you do!"
    ali "How do you think Violet's going to take the news??"
    mc "Honestly, I have no idea."
    scene 06_0373 with dissolve
    ali "I'm sure she'll be okay..."
    scene 06_0374 with dissolve
    ali "It'll be a surprise, that's for sure!"
    scene 06_0375 with dissolve
    ali "Are we okay?"
    mc "Yeah, we're good."
    ali "Great. I'll see you when you return home then."
    mc "Yeah."
    if Alison.isActive():
        scene 06_0376 with dissolve
        ali "[ss]Mmhhh."
    scene 06_0377 with dissolve
    ali "Bye. Drive safe."
    mc "See ya."
    scene 06_0378 with dissolve
    pause 0.5
    show screen CellPhone("Sue")
    mc_nvl "Ok, I'm in."
    mc_nvl "We need to talk."
    msg_nvl "Excellent."
    msg_nvl "Very well.\nI'm still at my residence."
    msg_nvl "Come at once."
    call CloseCell ()
    scene 06_0379 with dissolve
    pause
    jump Springhaven_SueImIn
return

label Springhaven_SueImIn:
    scene 05_1009 with Fade(3, 2, 3)
    pause
    scene 06_0380 with dissolve
    ki "Mister [mc] here, Miss."
    scene 06_0381 with dissolve
    sue "I appreciate your prompt arrival."
    scene 06_0382 with dissolve
    sue "And your decision to help."
    mc "How {b}do{/b} I help Melissa?"
    scene 06_0383 with dissolve
    sue "You will need to extract her from the college and find her a place of safety until she's able to return home."
    sue "It's imperative that her {i}companion{/i} not be aware of anything until it's too late and she's already safe."
    scene 06_0384 with dissolve
    mc "How many guys does she have guarding her?"
    sue "Unknown.\nI imagine at least two."
    mc "Is there a safe place in or around Lakeshore I can take her?"
    scene 06_0385 with dissolve
    sue "I cannot help you."
    sue "You must not reveal to me her location - for her own safety."
    sue "You have an ally in Lakeshore."
    scene 06_0386 with dissolve
    sue "One of Melissa's professors."
    sue "They offered to assist during our last attempt."
    sue "Melissa declined.\nShe was fearful of repercussions should we fail."
    scene 06_0387 with dissolve
    sue "A wise decision."
    scene 06_0388 with dissolve
    sue "I will forward you the professor's contact details."
    scene 06_0389 with dissolve
    mc "Okay. Good."
    mc "You mentioned a name before. The guy who you thought was guarding her."
    sue "Harry."
    mc "What can you tell me about him?"
    sue "Very little.\nHis name is Harry Watson. He's in our employment. That's it."
    scene 06_0384 with dissolve
    mc "I'm gonna need more than that."
    mc "Get in touch with your guys at the police station. I need his record."
    scene 06_0382 with dissolve
    sue "Very well.\nI'll have it in a day or two."
    scene 06_0390 with dissolve
    mc "No. I need it today. Now."
    mc "I need to get to Lakeshore as soon as possible.\nI can't come up with a plan from here."
    mc "Tell your guy to meet me at the south underpass with the files I need."
    scene 06_0391 with dissolve
    sue "That is not how we usually conduct our business.\nHe will not be amused."
    mc "He works for {b}you{/b}, doesn't he?\nHe takes your money, {b}so he can do as he's told{/b}."
    sue "Very well. You shall have the file."
    scene 06_0392 with dissolve
    mc "Okay."
    sue "Good luck, [mc]."
    scene 06_0393 with dissolve
    sue "Be aware, I'm not the only person who has access to your cell location information."
    scene black with Fade(3, 2, 0)
    call CenterText ("30 minutes later.")
    play sound "car3.mp3"
    scene 06_0394 with dissolve
    pause 0.5
    scene 06_0395 with dissolve
    scene 06_0396 with dissolve
    pause 0.5
    scene 06_0397 with dissolve
    wilks "You the asshole I was {i}ordered{/i} to meet?"
    mc "Guess so."
    scene 06_0398 with dissolve
    wilks "This is bullshit! It's not how we do things.\nI don't like being dragged out of my office like this!"
    mc "Take it up with the boss."
    scene 06_0399 with dissolve
    wilks "Here's your goddamn file.\nTake it so I can get the fuck outta here."
    scene 06_0400 with dissolve
    wilks "Are we done?"
    mc "We're done."
    play sound "car_rev.mp3"
    scene 06_0401 with fade
    scene 06_0402 with dissolve
    scene 06_0403 with dissolve
    scene 06_0404 with dissolve
    pause 0.5
    scene 06_0405 with dissolve
    mc "Clear."
    scene 06_0406 with dissolve
    mc "Did you get it?"
    scene 06_0407 with dissolve
    aly "Yeah."
    mc "Know him?"
    scene 06_0408 with dissolve
    aly "Not personally, but yeah. Wilks, head of narcotics."
    scene 06_0409 with dissolve
    mc "You'll need this too."
    aly "You're not gonna read it first?"
    mc "No. Doubt there's anything in there that'll help."
    aly "So why ask for it?"
    scene 06_0410 with dissolve
    mc "You wanted results. We just got one.\nWe know the identity of one of her dirty cops."
    aly "We have more than his identity.\nWe have proof!"
    aly "Nice job, [mc]."
    scene 06_0411 with dissolve
    mc "It's a start, but we have a long way to go."
    aly "Yeah.\nBe careful in Lakeshore."
    call UpdateMapInfos
    if Nettie.isActive():
        $ cedargrove_open=True
    $ oakhill_open=True
    if brookridge_ch==1:
        $ brookridge_open=True
    if brookvale_ch==1:
        $ brookvale_ch=2
        $ brookvale_open=False
    $ lakeshore_open=True
    stop music
    jump Springhaven_Leave
return

label Springhaven_Start4:
    scene 08_0485 with Fade(1,1,2)
    mc cell "Sue? Hey, I'm back."
    mc cell "I need to update you. Are you at home?"
    sue cell "No, the office."
    mc cell "Okay, I'm on my way."
    scene 09_0001 with Fade(2, 1, 0)
    if JamesD:
        mct "Damn... Was half-expecting to see James on guard."
    else:
        mct "Hmm... Quiet in here."
    play sound "knock.mp3"
    scene 09_0002 with dissolve
    pause 0.5
    scene 09_0003 with dissolve
    pause 0.5
    sue "[whi]Enter."
    scene 09_0004 with dissolve
    sue "[whi]I wasn't expecting your return so soon."
    scene 09_0005 with dissolve
    mc "Everything's under control in Lakeshore."
    mc "I've placed someone there to keep a close eye on Melissa."
    scene 09_0006 with dissolve
    sue "I'd prefer not to involve outsiders,but we're running out of time, so I'll trust your judgment."
    sue "Is the professor still willing to help?"
    scene 09_0007 with dissolve
    mc "Her name's Dawn. She's actually a lecturer, not a professor... but yeah, she's helping us."
    sue "Good."
    mc "You want me to walk you through the plan?"
    scene 09_0008 with dissolve
    sue "No.\nThe less I know, the better."
    scene 09_0009 with dissolve
    sue "I'm putting my faith in you, [mc]."
    sue "But I must warn you, if this plan of yours proves inadequate, there will be a heavy price to pay - for us all."
    scene 09_0010 with dissolve
    mc "[whi] ...Yeah, I know."
    if not Ruth.isActive():
        scene 09_0011 with dissolve
        mc "There is one thing you'll need to do..."
        mc "The Dean, Ruth...\nShe's demanding payment for her services."
        mc "She wants ten thousand.\nWe need her on our side. There's no other way."
        scene 09_0012 with dissolve
        sue "Surprising.\nVery well. I'll make the arrangements."
    if JamesD:
        scene 09_0013 with dissolve
        mc "Where we at with... {i}the James situation{/i}?"
        sue "Your ruse seems to be working."
        if Plr.Has("DR"):
            sue "As long as they don't find Douglas, we should remain unsuspected."
            mc "Good."
        else:
            sue "For now at least.\nIf they decide to investigate further, that will surely change."
            mc "Then let's hope they don't."
        sue "Luckily, my superiors are currently distracted by another matter.\nLong may it continue."
    else:
        scene 09_0011 with dissolve
        mc "Where's your guard dog today?"
        scene 09_0012 with dissolve
        sue "I presume you're referring to James."
        sue "He's been called away. He'll soon return."
        scene 09_0013 with dissolve
    mc "Okay. If there's nothing else, I'm gonna head home."
    scene 09_0014 with dissolve
    sue "Melissa..."
    sue "Did you see her? Is she well?"
    scene 09_0015 with dissolve
    mc "I didn't see her personally, but Dawn assured me she was fine."
    sue "Okay... {size=*.8}Thank you{/size}."
    scene 09_0016 with fadehold
    pause 0.5
    jump Springhaven_ReturnHome04
return

label Springhaven_ReturnHome04:
    scene 09_0017 with Fade(1, 2, 1)
    mct "Damn, I'm exhausted!\nThe last few days have really taken it out of me!"
    scene 09_0018 with Fade(1, 2, 1)
    "*Giggling*"
    scene 09_0019 with dissolve
    mc h "We havin' another sleepover?"
    car su "Dad! You're home!"
    scene 09_0020 with dissolve
    car "Yep, another sleepover!"
    car "Mom and Christina have gone to a 90's night at Smokey Joe's, so they'll be back late."
    scene 09_0021 with dissolve
    nic h "And probably drunk!"
    scene 09_0022 with dissolve
    mc h "Your mom isn't a {i}mean{/i} drunk, is she?\nI've been so busy that I still haven't spoken to her about the truck!"
    mc h "Should I stay out of her way?"
    nic h "No, you're fine. She's a sleepy drunk!"
    scene 09_0023 with dissolve
    mc "Wait... Have I spoiled your night by coming home?"
    scene 09_0024 with dissolve
    mc "I can sleep on the couch if you need my bed."
    mc h "The three of you in your bed will be a bit of a squeeze!"
    scene 09_0025 with dissolve
    car "No!\nAlex isn't staying the night; we're just hanging out watching a movie."
    scene 09_0026 with dissolve
    if Alex.isActive():
        alex h "Well... I {i}wasn't{/i} staying... but if there's room in your bed, maybe I'll reconsider!"
        scene 09_0027 with vpunch
        car su "Oh my God! You're such a slut!"
    else:
        alex h "Have you heard how loud she snores?!\nI couldn't stay in the same house as her! I'd never get any sleep!"
        scene 09_0027 with vpunch
        car su "Oh my God! You cheeky...!"
    scene 09_0028 with dissolve
    alex h "[lol]"
    scene 09_0029 with dissolve
    mc "Enjoy the movie, girls.\nI'm goin' for a much-needed shower."
    if Alex.isActive():
        scene 09_0030 with dissolve
        alex h "Want some company??"
        mc h "I'm good, thanks!"
        mct "If I thought you meant it, I might've taken you up on the offer."
    play sound "shower.mp3" fadein 2.0
    scene 09_0031 with Fade(2, 2, 1)
    play sound "shower.mp3"
    pause 2.0
    stop sound fadeout 2.0
    scene 09_0032 with Fade(2, 2, 1)
    mct "Wow... Feel so much better.\nNow for coffee, and I'll feel like a new man!"
    scene 09_0033 with fade1
    pause 0.5
    scene 09_0034 with dissolve
    mc "Movie over?"
    scene 09_0035 with dissolve
    alex "No.\nToo much chick-flick for me, so I excused myself to grab a drink."
    if Alex.isActive():
        scene 09_0036 with dissolve
        mc "Not a chick-flick kinda girl, huh?"
        alex "Nope."
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e09/09_0037.webp", 1160, 380, True, "Springhaven_AF28") with dissolve
            alex "All that lovey-dovey crap? Give me some action any day!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 09_0037
                hide screen imgMap
            else:
                call AlexReplay02
        else:
            scene 09_0037 with dissolve
            alex "All that lovey-dovey crap? Give me some action any day!"
            if not EzModeActive:
                menu:
                    "[wk_y]Grab her boob":
                        call Springhaven_AF28
                        call AlexReplay02
                    "Don't":
                        pass
            elif Alex.Has("EZ"):
                call Springhaven_AF28
                call AlexReplay02
    if Alex.L<3:
        call Springhaven_AlexKitchenAlt
    scene 09_0143 with Fade(2, 2, 1)
    pause 0.5
    scene 09_0144 with dissolve
    mc h "Hey.\nThought I might join you for a little while."
    car h "Yeah? Okay!"
    if not EzModeActive:
        menu:
            "Sit next to Cara":
                call Springhaven_LivingRoomMovie
            "[wk_y]Sit next to Nicole":
                $ Nicole.Score(1)
                call Springhaven_LivingRoomMovie ("a")
    elif Nicole.Has("EZ"):
        $ Nicole.Score(1)
        call Springhaven_LivingRoomMovie ("a")
    else:
        call Springhaven_LivingRoomMovie
    scene 09_0170 with Fade(2, 2, 1)
    mc "[whi]..Zzzzz.."
    if persistent.Incest and Cara.isActive():
        call CenterText ("Sometime later that night...", True)
        scene black with fade
        unk "[whi]Dad?"
        call Emotion (mc, "Groan", "", True)
        unk "Dad?"
        scene 09_0171 with dissolve
        mc "[whi]Mhh??"
        scene 09_0172 with dissolve
        mc "[whi]Cara?"
        scene 09_0173 with dissolve
        car "[whi]Sorry for waking you."
        mc "[whi]It's okay. What's up?"
        scene 09_0174 with dissolve
        car "Can I, umm... sleep in your bed?"
        mc "Huh?"
        car "Nic's been kicking hell out of me all night; I can't sleep!"
        scene 09_0175 with dissolve
        mc "Uhh... I don't know, Cara... Can't you sleep in your mom's bed?"
        car "No.\nThey came back {i}really{/i} drunk."
        scene 09_0176 with dissolve
        car "Christina could barely walk. They've both passed out in Mom's bed."
        car "Don't worry, I'll go back to my room way before anyone wakes up in the morning!"
        $ tCh=None
        if not EzModeActive:
            menu:
                "No. Sorry, but it's too risky":
                    pass
                "[wk_y]Okay":
                    $ tCh=True
        elif Cara.Has("EZ"):
            $ tCh=True
        if tCh:
            call CaraReplay04
        else:
            scene 09_0177 with dissolve
            car "Uh, okay.\nSorry. Good night."
            mc "Night, Pipsqueak."
    jump Springhaven_SoreHeads
return

label Springhaven_AlexKitchenAlt:
    if not Alex.isActive():
        mc "Not a chick-flick kinda girl, huh?"
        alex "Nope."
    scene 09_0038 with dissolve
    mc "Yeah, they're kinda lame."
    scene 09_0129 with dissolve
    mc "So what kinda movies {i}do{/i} you like?"
    alex "Give me an action flick over that lovey-dovey crap, anytime!"
    mc "Hell yeah!\nA girl after my own heart!"
    scene 09_0130 with dissolve
    nic "I thought you were getting us drinks?"
    scene 09_0131 with dissolve
    alex "Oh, yeah... Sorry.\nHad to take a break, thought I was gonna vomit with all that romance shit!"
    nic "You chose that movie!"
    alex "Only because I knew you both were dyin' to watch it!"
    scene 09_0132 with dissolve
    mc "Sorry, it's my fault!"
    mc "She was on her way back, but we got chatting."
    scene 09_0133 with dissolve
    nic "Is that why she only has {i}one{/i} bottle on the table?"
    mc "Oof! Knockout blow!"
    mc "Sorry, Alex, she has me there!"
    scene 09_0134 with dissolve
    nic "Yeah, I do!"
    nic "And your punishment should be to come and watch the movie with us."
    scene 09_0135 with dissolve
    mc "Damn, that's harsh!"
    mc "Not sure the punishment fits the crime!"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e09/09_0136.webp", 1507, 398, True, "Springhaven_AF29") with dissolve
        nic "Maybe, but I know Cara would like you to join us; she misses you when you leave town."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 09_0136
            hide screen imgMap
    else:
        scene 09_0136 with dissolve
        nic "Maybe, but I know Cara would like you to join us; she misses you when you leave town."
        if not EzModeActive:
            menu:
                "[wk_y]Take a closer look at her butt":
                    call Springhaven_AF29
                "Don't":
                    pass
        elif Nicole.Has("EZ"):
            call Springhaven_AF29
    scene 09_0138 with dissolve
    pause 0.5
    $ tCh=Nicole.Has("EZ")
    if not EzModeActive:
        menu:
            "Oh, okay.":
                $ tCh=False
            "[wk_y]And what about you? Is that what YOU want, too?":
                $ tCh=True
    if tCh:
        $ Nicole.Score(1)
        scene 09_0139 with dissolve
        nic "Yes... If it makes my best friend happy, why wouldn't I?"
        scene 09_0140 with dissolve
        mc "Fair enough.\nLet me have some coffee first."
        nic "Okay."
    else:
        mc "Fair enough.\nLet me have some coffee first."
return

label Springhaven_LivingRoomMovie(aaa=""):
    show expression "09_0145" + aaa with dissolve
    car "I'm glad you're home, Dad."
    mc h "Me too, Pipsqueak."
    if Alex.L==3:
        show expression "09_0146" + aaa with dissolve
        car h "Did you like the... {i}coffee{/i}?"
        mc "Huh?"
        show expression "09_0147" + aaa with dissolve
        car h "I heard you enjoyed it."
        mc h "Ohhhh...\nErr... Umm... Yeah, it was... very nice."
        if Cara.L==3:
            show expression "09_0148" + aaa with dissolve
            car h "But, Dad... Who makes the {b}best{/b} {i}coffee{/i}... Me, or Alex??"
            mc h "Oh, no chance! I ain't ever answering that!"
            show expression "09_0149" + aaa with dissolve
            car h "[lol]"
    show expression "09_0150" + aaa with fade1
    pause
    show expression "09_0151" + aaa with dissolve
    if oakhill_ch==4:
        car x "Ohh, Dad... Millie called."
        car h "Thank you for telling her about me."
        show expression "09_0152" + aaa with dissolve
        mc x "How was she?"
        car "Really happy!"
        car "She said she can't wait for us to get together again."
        show expression "09_0153" + aaa with dissolve
        mc "You should come with me sometime.\nHannah would like to meet you again, too. Now she knows that you're cousins!"
        car "Hannah?... Oh, that's your sister's daughter, right?"
        mc "Yeah, my sister, who's also your aunt!"
        show expression "09_0154" + aaa with dissolve
        car h "Oh yeah!"
        car h "Okay, I'll come with you one day so I can meet the family!"
        hide expression "09_0154" + aaa with dissolve
        mc h "Great."
    else:
        car "Did you see Millie? Have you told her?"
        show expression "09_0152" + aaa with dissolve
        mc "No, not yet.\nSorry, I didn't have the time to go to Oakhill."
        show expression "09_0153" + aaa with dissolve
        mc "But don't worry, I {b}will{/b} tell her."
        car "Okay."
    if aaa=="a":
        scene 09_0155 with dissolve
        mc "[whi]Uhh... Sorry."
        scene 09_0156 with dissolve
        nic "It's okay."
        $ tCh=True
        if not EzModeActive:
            menu:
                "Move your hand":
                    $ tCh=False
                "[wk_y]Don't move your hand":
                    pass
        if tCh:
            $ Nicole.Score(1)
            scene 09_0158 with dis1
            pause 0.5
            if not Nicole.hasScore(4):
                scene 09_0159 with dis1
                pause 0.5
                scene 09_0163 with dissolve
            else:
                scene 09_0160 with dis1
                scene 09_0161 with dissolve
                pause
                scene 09_0162 with dissolve
                pause
        else:
            scene 09_0157 with dis1
            pause 0.5
            scene 09_0162 with dissolve
            pause
    else:
        scene 09_0164 with fade1
        pause
    show expression "09_0165" + aaa with Fade(1, 2, 1)
    mc "{size=*1.25}...ZZZzzzzzzz...."
    show expression "09_0166" + aaa with vpunch
    car "{b}DAD!"
    mc sh "HUH?"
    show expression "09_0167" + aaa with dissolve
    mc x "{nw}"
    call Emotion (mc, "Groan")
    car "You're snoring! Really loudly!"
    alex h "At least we know where {i}you{/i} get it from now!"
    show expression "09_0168" + aaa with dissolve
    car h "Shut up! I {b}don't{/b} snore!"
    mc "Sorry, Pipsqueak... Think I'm gonna go to bed, I'm spent."
    scene 09_0169 with dissolve
    mc "Night, girls."
    car "Night, Dad."
return

label Springhaven_SoreHeads:
    scene 09_0304 with Fade(2, 3, 2)
    pause 1.0
    scene 09_0305 with dissolve
    call Emotion (mc, "Groan", "", True)
    scene 09_0306 with fade1
    pause
    if Millie.Has("GotPicsX"):
        $ Millie.Del("GotPicsX")
        $ Millie.Del("Taste")
        $ Millie.Del("Saw")
        $ Millie.Del("Top")
        $ Millie.Del("NewPics")
        $ Millie.Del("CaughtYou")
        $ Millie.Del("PBS")
        $ Millie.Del("SawPic")
        pause 0.5
        play sound "text.mp3"
        pause 1.0
        scene 09_0307 with dissolve
        pause 0.5
        nvl clear
        show screen CellPhone("Millie")
        msg_nvl "Good morning, Dad!"
        mc_nvl "Morning Sweetheart. You ok?"
        msg_nvl "Ye! All good here."
        msg_nvl "Hannah told me she'd sent u the photos we took at the lake and u wanted the topless ones!"
        mc_nvl "Yeah, I didn't think you'd mind me having them?"
        msg_nvl "Of course I don't mind, Daddy!"
        msg_nvl "But u could've asked me for them! I would've sent them to u!"
        mc_nvl "Ok, sorry sweetheart, you're right, I should've asked you."
        msg_nvl "I'm not mad, Dad!"
        msg_nvl "I {image=/thumbs/cell/emoji/heart.png} that u wanted them!"
        msg_nvl "I can take more for u if u want! {image=/thumbs/cell/emoji/smile hearts.png}"
        menu(nvl=True):
            "Of course I want!":
                $ Pix_Millie=True
                mc_nvl "Of course I want!"
                msg_nvl "Ok!"
                msg_nvl "I'm gonna take one right now for u! Hold on..."
                mc_nvl "Ok."
                $ nvl_thumb="thumbs/gal/01_m.jpg"
                call SendPhoto ("mil_09")
                mc_nvl "Wow!\nBeautiful Sweetheart."
                msg_nvl "{image=/thumbs/cell/emoji/blush smile.png}"
            "No, it's best you don't":
                mc_nvl "No, it's best you don't"
                msg_nvl "Okay, up2u."
        msg_nvl "gtg! Mom's calling me!"
        msg_nvl "Luv u Dad! Can't wait for ur next visit! {image=/thumbs/cell/emoji/smile hearts.png}{image=/thumbs/cell/emoji/smile hearts.png}"
        mc_nvl "Bye sweetie. Love you."
        call CloseCell ()
        scene 09_0308 with dissolve
        pause 0.5
    scene 09_0309 with Fade(1, 2, 1)
    call Emotion (cri, "Groaning", "", True)
    mc h "Morning."
    scene 09_0310 with dissolve
    cri "Ohh... Err... morning.\nAli didn't tell me you were home!"
    mc "Got back yesterday.\nYou were both already dancin' the night away by the time I got here."
    scene 09_0311 with dissolve
    cri "Ughhh... More drinking than dancing.\n{i}Waaay{/i} too much drinking."
    cri "Paying the price now with this darn hangover!"
    scene 09_0312 with dissolve
    cri "Coffee's fresh."
    mc "Great."
    scene 09_0313 with Fade(0.5, 1, 0.5)
    mc "Good night, then?"
    cri "It was so fun!"
    scene 09_0314 with dissolve
    cri "Never again, though!"
    mc h "Yeah, that's what we all say!"
    scene 09_0315 with dissolve
    mc "Sorry I haven't been in touch about the truck, I've been so busy with work..."
    cri "Oh, it's alright!\nAlison told me you've already made up your mind about it."
    mc "Yeah.\nIt's great, and if we can agree on a price, I'll take it."
    scene 09_0316 with dissolve
    cri "Super!"
    cri "In that case, I have a proposition for you."
    cri "Alison tells me you're good with your hands. Repairing things."
    scene 09_0317 with dissolve
    mc "Err... Yeah, I guess."
    cri "I've been divorced a long time.\nMy house is literally falling apart around me!"
    scene 09_0318 with dissolve
    cri "I'm not talking {i}major{/i} repairs. Just little things..."
    cri "{i}Lots{/i} of little things! Leaky roof, noisy pipes, squeaky doors..."
    scene 09_0319 with dissolve
    cri "Holes that need filling... Things like that."
    scene 09_0317 with dissolve
    mc "Okay..."
    cri "I neither have the time nor the patience to deal with some random repair guy fleecing me every time I need something fixed."
    scene 09_0320 with dissolve
    cri "So, how about {i}you{/i} do the work?"
    cri "Fix up my home, and I'll give you a price on that truck you won't even believe!"
    scene 09_0321 with dissolve
    mc "That's a, uhh... generous offer..."
    cri "I'm glad you think so."
    cri "So what do you say?"
    mc "I'll need to see what work needs to be done first.\nDon't want to promise you something now that I can't deliver later."
    scene 09_0322 with dissolve
    cri "Call around, and I'll show you what needs to be done."
    mc "Yeah, okay."
    scene 09_0323 with dissolve
    car "Morning!"
    scene 09_0324 with dissolve
    mc "Morning, Pipsqueak."
    cri "Did you guys have fun with your sleepover?"
    scene 09_0325 with dissolve
    if Cara.L==4:
        car "Best one yet!"
        scene 09_0326 with dissolve
        car h "[whi]Wasn't it, Dad?"
        mc "Yeah."
    else:
        car "Yeah!\nDad even watched a movie with us!"
        scene 09_0326 with dissolve
        car h "Well, some of it!"
    scene 09_0327 with dissolve
    car "Mom still in bed?"
    cri "Yeah.\nNot sure you'll see a lot of her today!"
    cri "She got wrecked last night!"
    scene 09_0328 with dissolve
    nic "Oh, my God, Mom! You were worse!"
    scene 09_0329 with dissolve
    nic "You couldn't walk!"
    nic "We had to help you up the stairs and into bed!"
    scene 09_0330 with dissolve
    cri "Really?! Jeez, I don't even remember that!\nNo wonder I feel so bad this morning!"
    car "Who wants breakfast?"
    play sound "text.mp3"
    scene 09_0331 with dissolve
    cri "Nothing for me, thanks.\nDon't think I could keep anything down."
    nic h "Have some bacon, Mom! Greasy, fatty bacon."
    scene 09_0332 with dissolve
    call Emotion (cri, "Sigh", "Please stop.")
    show screen CellPhone("Sue")
    msg_nvl "I have an assignment for you. Priority."
    msg_nvl "Report to my residence at once."
    call CloseCell ()
    scene 09_0333 with dissolve
    mct "Now what?!"
    scene 09_0334 with dissolve
    car "Dad? Breakfast?"
    mc "Uhh, sorry, Pipsqueak, I need to go out for a while."
    car "Oh... Okay."
    jump Springhaven_PriorityAssignment
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
