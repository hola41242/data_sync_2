label AlisonReplay01:
    call Unlocker ("AlisonReplay01")
    $ Alison.incSex()
    scene 01_0754 with Fade(2, 1, 1)
    pause 1.0
    scene 01_0755 with dissolve
    pause 1.0
    scene 01_0756 with dissolve
    mc "You sure about this?"
    scene 01_0757 with dissolve
    ali "We both know I married the wrong man."
    ali "I should've stuck with you when I..."
    scene 01_0758 with dissolve
    ali "[ss]Mmhhh."
    scene 01_0759 with dis1
    pause 0.5
    scene 01_0760 with dis1
    pause 0.5
    scene 01_0761 with dis1
    pause 0.5
    scene 01_0762 with dis1
    pause 0.5
    scene 01_0763 with dis1
    ali "[ss]...Mmmhh..."
    scene 01_0764 with dis1
    pause 0.5
    scene 01_0765 with dis1
    pause 0.5
    scene 01_0766 with dis1
    pause 0.5
    scene 01_0767 with dis1
    pause
    scene 01_0768 with dis1
    pause
    scene 01_0769 with dissolve
    pause
    scene 01_0770 with dis1
    pause
    scene 01_0771 with dis1
    mc "[whi]..Fuuuck.."
    scene 01_0772 with dissolve
    pause 0.5
    image r_ail_001 = Movie(play="images/e01/01_0773.webm")
    show r_ail_001
    ali "[ss]...Mmmhh..."
    scene 01_0774 with dissolve
    pause 0.5
    image r_ail_002 = Movie(play="images/e01/01_0775.webm")
    show r_ail_002
    ali "[ss]...Mmmmmhh..."
    scene 01_0776 with dissolve
    mc "[whi]Nnnhhh, that's good."
    scene 01_0777 with dissolve
    mc "[whi]Come here."
    scene 01_0778 with dis1
    pause 0.5
    scene 01_0779 with dis1
    pause 0.5
    scene 01_0780 with dis1
    pause 0.5
    scene 01_0781 with dis1
    pause 0.5
    scene 01_0782 with dis1
    pause 0.5
    scene 01_0783 with dis1
    pause 0.5
    scene 01_0784 with dis1
    pause 1.5
    scene 01_0785 with Fade(1, 0.5, 0.5)
    pause 1.5
    scene 01_0786 with dissolve
    mc "[whi]Damn, I've missed your pussy."
    scene 01_0787 with dis1
    ali "[ss]Believe me, It's missed you more, Sweetheart."
    if persistent.FootPlay:
        scene 01_0788 with dissolve
        ali su "[ss]Holy shit! You still remember? After all these years!"
        scene 01_0789 with dissolve
        ali "[ss]Ohhh, god....."
        scene 01_0790 with dissolve
        pause 1.0
        scene 01_0791 with dis1
        pause 1.0
        scene 01_0792 with dis1
        pause 1.0
        scene 01_0793 with dis1
        pause 1.0
        scene 01_0794 with dis1
        pause 1.0
        scene 01_0795 with dissolve
        ali "[ss]...Nnnhhhh..."
        scene 01_0796 with dissolve
        pause 1.0
        scene 01_0797 with dissolve
        pause 1.0
    scene 01_0798 with dissolve
    pause 1.0
    scene 01_0799 with dis1
    pause 1.0
    scene 01_0800 with dis1
    pause 1.0
    scene 01_0801 with dis1
    pause 1.0
    scene 01_0802 with dis1
    pause 0.5
    scene 01_0803 with dis1
    ali "[ss]...FUCK...OHHHH....."
    scene 01_0804 with dissolve
    ali "[ss]..Mmmhh...I'd forgotten how good that feels..."
    scene 01_0805 with dissolve
    ali "[ss].....Mmmmmhhhh..."
    scene 01_0806 with dissolve
    call Moan (ali)
    scene 01_0807 with dissolve
    ali "[ss]..OHHHHHHH..."
    scene 01_0808 with dissolve
    call Moan (ali)
    scene 01_0809 with dissolve
    ali "[ss]Fuck me, [persistent.McName]."
    scene 01_0810 with fade
    pause
    image r_ail_003 = Movie(play="images/e01/01_0811.webm", keep_last_frame=True, loop=False)
    show r_ail_003
    pause 2.0
    ali "[ss]Mmhhh...{w=1}{nw}"
    ali "{nw}"
    pause 1.0
    ali "[ss]...Ohhhh..."
    scene 01_0812 with dissolve
    pause 0.5
    image r_ail_004 = Movie(play="images/e01/01_0813.webm")
    show r_ail_004
    call Moan (ali)
    scene 01_0814 with dissolve
    ali "[ss]..Ohhhh..."
    scene 01_0815 with dissolve
    pause 0.5
    image r_ail_005 = Movie(play="images/e01/01_0816.webm")
    show r_ail_005
    ali "[ss]...Mhhhh...."
    ali "[ss]...Show me how much you've missed me...."
    scene 01_0817 with dissolve
    ali "[ss]..Mmmhhhh.."
    scene 01_0818 with dissolve
    call Moan (ali)
    scene 01_0819 with dissolve
    ali "[ss]...Mmhh..."
    scene 01_0820 with dissolve
    pause 0.5
    image r_ail_006 = Movie(play="images/e01/01_0821.webm")
    show r_ail_006
    pause
    scene 01_0822 with dissolve
    ali "[ss]..MMHHHHH...Yes, Baby....OHHHHH..."
    scene 01_0823 with dissolve
    ali "[ss]..Fuck me like only you can...."
    scene 01_0824 with dissolve
    call Moan (ali)
    scene 01_0825 with dissolve
    ali "[ss]..OHHH...YES....."
    scene 01_0826 with dissolve
    pause 0.5
    image r_ail_007 = Movie(play="images/e01/01_0827.webm")
    show r_ail_007
    call Moan (ali, 7)
    scene 01_0828 with dissolve
    ali "[ss]...Fuck, [persistent.McName]....Yes....YES....."
    ali "[ss]....Ohhh......Make me cum, Baby...."
    scene 01_0829 with dissolve
    pause 0.5
    image r_ail_008 = Movie(play="images/e01/01_0830.webm")
    show r_ail_008
    call Moan (ali, 10)
    call CharCum ("e01/01_0829.webp", "e01/01_0831.webp", ali, "OHHHHHHHHH!!", 1)
    scene 01_0832 with dissolve
    ali "[ss]....fuuuuck.....Mmmhhh...."
    call Loop_Punch (6, "e01/01_0834.webp", "e01/01_0833.webp")
    call CharCum ("e01/01_0833.webp", "e01/01_0835.webp", mc, "NNNGGGGGHHHH!!")
    scene 01_0836 with dissolve
    mc "[ss]...Fuuck...."
    scene 01_0837 with dissolve
    ali h "[whi]Admiring your work?"
    $ Alison.incCm()
    scene black with Fade(3, 1,1)
return

label AlisonReplay02:
    call Unlocker ("AlisonReplay02")
    $ Alison.incSex()
    scene 02_0091 with Fade(2, 1, 1)
    pause 1.0
    play sound "door.mp3" volume 0.1
    scene 02_0092
    ali "[ss]..Mmmhhh...{w=2.0}{nw}"
    scene 02_0093 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0094
    pause 1.0
    scene 02_0095 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0096 with Fade(1, 0.5, 1)
    ali "[ss]..Mmhhh..{w=1.0}{nw}"
    scene 02_0097 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0098 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0099 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0100 with dissolve
    ali "[ss]..Ohhh..."
    scene 02_0101 with dissolve
    ali "[ss]..Mmhhh.."
    scene 02_0102 with dissolve
    pause 1.0
    scene 02_0103 with dissolve
    ali "[ss]..OHHH...."
    scene 02_0104 with dissolve
    pause
    scene 02_0105 with dissolve
    if not _in_replay and Alison.getSex()<1:
        ali "[ss]..Mmmhh...I'd forgotten how good that feels..."
    else:
        ali "[ss]...Mmhhhh..."
    scene 02_0106 with dissolve
    ali "[ss]..Fuck.."
    scene 02_0107 with dissolve
    mc "[whi]Turn around."
    ali "[whi][giggles]"
    scene 02_0108 with Fade(1, 0.5, 1)
    ali "[ss]...OHHH...."
    scene 02_0109 with dissolve
    call Moan (ali)
    image r_ail_009 = Movie(play="images/e02/02_0110.webm")
    show r_ail_009
    ali "[ss]..Mmhhh.."
    scene 02_0111 with dissolve
    ali "[ss]Mmmmhhhh......That feels so good......"
    scene 02_0112 with dissolve
    ali "[ss]....Mmmhhh...."
    if persistent.Anal==True:
        $ Alison.Add("Anal")
        scene 02_0113 with dissolve
        ali "[whi]Whoa there, Soldier!\nYou're straying from the combat zone!"
        scene 02_0114 with dissolve
        mc "[whi]Yes, Ma'am.\nPermission to continue into uncharted territory?"
        scene 02_0115 with dissolve
        ali "[whi]Ummm...."
        scene 02_0116 with dissolve
        ali "[whi]... Permission granted."
        scene 02_0117 with dissolve
        pause 1.0
        scene 02_0118 with dissolve
        ali "[ss]...Ohh god!....."
        scene 02_0119 with dissolve
        ali "[ss]...OHHHHH......."
        scene 02_0120 with dissolve
        ali "[ss]..Mmhhh.."
        scene 02_0121 with dissolve
        call Moan (ali, 10)
    scene 02_0122 with Fade(1, 0.5, 1)
    ali "[ss]..Mmhhh.."
    scene 02_0123 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0124 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0125 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0126 with Fade(1, 0.5, 1)
    if not _in_replay and Alison.getSex()<1:
        ali "[whi]It's been a {b}long time{/b} since I've had your dick in my mouth!"
    else:
        pause 1.0
    scene 02_0127 with dissolve
    ali "[whi][kiss]"
    scene 02_0128 with dissolve
    pause 1.0
    scene 02_0129 with dissolve
    ali "[whi][kiss]"
    pause 0.5
    scene 02_0130 with dissolve
    pause 1.0
    scene 02_0131 with dissolve
    ali "[whi][kiss]"
    pause 0.5
    scene 02_0132 with dissolve
    pause 1.0
    scene 02_0133 with dissolve
    pause 1.0
    scene 02_0134 with dis1
    pause 0.5
    scene 02_0135 with dis1
    pause 0.5
    scene 02_0136 with dis1
    pause 0.5
    scene 02_0137 with dis1
    pause 0.5
    scene 02_0138 with dis1
    image r_ail_010 = Movie(play="images/e02/02_0139.webm")
    show r_ail_010
    ali "[ss]..Mmhhh.."
    scene 02_0140 with dissolve
    image r_ail_011 = Movie(play="images/e02/02_0141.webm")
    show r_ail_011
    ali "[ss]..Mmhhh.."
    scene 02_0142 with dissolve
    image r_ail_012 = Movie(play="images/e02/02_0143.webm")
    show r_ail_012
    ali "[ss]..Mmhhh.."
    scene 02_0144 with dissolve
    mc "[ss]...Fuck...."
    scene 02_0145 with fade
    ali "[ss]..Mhhh.."
    scene 02_0146 with fade
    ali "[ss]....Mmmhhh...."
    scene 02_0147 with fade
    pause 1.0
    scene 02_0148 with dissolve
    pause 0.5
    image r_ail_013 = Movie(play="images/e02/02_0149.webm", loop=False, keep_last_frame=True)
    show r_ail_013
    ali "[ss]..OHHH.."
    scene 02_0150 with dis1
    image r_ail_014 = Movie(play="images/e02/02_0151.webm")
    show r_ail_014
    call Moan (ali)
    scene 02_0152 with dissolve
    ali "[ss]..Mmmmhhhhh.."
    scene 02_0153 with fade
    ali "[ss]...Ohhhh....Yes......Mmmhhhh......"
    scene 02_0154 with dis1
    image r_ail_015 = Movie(play="images/e02/02_0155.webm")
    show r_ail_015
    call Moan (ali)
    scene 02_0156 with dissolve
    ali "[ss]...Fuck, that's so good.....Mmmhhh...."
    scene 02_0157 with fade
    ali "[ss]...Ohhhh....Yes, I'm close......."
    scene 02_0158 with dissolve
    ali "[ss]..Oh, god...Yes....Fuck me, [mc]......."
    scene 02_0159 with dissolve
    call Moan (ali, 7)
    scene 02_0160 with dis1
    image r_ail_016 = Movie(play="images/e02/02_0161.webm")
    show r_ail_016
    ali "[ss]...Yes...."
    ali "[ss]....OHHHH.....FUCK, BABY...."
    call Moan (ali, 10)
    ali "[ss]OHHHH, YES...YES...."
    call CharCum ("e02/02_0162.webp", "e02/02_0163.webp", ali, "OHHHHHHHHH!!")
    image r_ail_017 = Movie(play="images/e02/02_0164.webm")
    show r_ail_017 with dissolve
    ali "[ss]..Mmhh.."
    if persistent.Anal==True:
        scene 02_0167 with dissolve
        pause 1.0
        scene 02_0168 with dis1
        pause 0.5
        scene 02_0169 with dissolve
        ali "[ss]Whoa... Are you serious?"
        mc "[whi]Yup! Heh..."
        image r_ail_018 = Movie(play="images/e02/02_0170.webm", loop=False, keep_last_frame=True)
        show r_ail_018 with dissolve
        pause 3.5
        ali "[ss]{size=*2.0}FUCK!"
        scene 02_0171 with dis1
        image r_ail_019 = Movie(play="images/e02/02_0172.webm")
        show r_ail_019
        ali "[ss]..Ohhhhh.."
        scene 02_0173 with dis1
        image r_ail_020 = Movie(play="images/e02/02_0174.webm")
        show r_ail_020
        ali "[ss]...fuck..."
        call CmOpts (["Cum inside Alison", "Pull out"])
        $ Copt=_return
        if Copt==0:
            call CharCum ("e02/02_0173.webp", "e02/02_0175.webp", mc, "NNNGGGGGHHHH!!")
            scene 02_0180 with dissolve
            ali h "At least we know you won't get me pregnant from in there!"
        else:
            call AlisonReplay02_cum
            pause    
        scene 02_0182 with dissolve
        ali "You took my ass virginity!"
        mc "[lol]\nAnd?"
        scene 02_0183 with dissolve
        ali "I feel violated!"
        ali h "... But, in a nice way."
        scene 02_0184 with dissolve
        ali "Lover, you can violate my ass anytime."
    else:
        call CmOpts (["Cum inside Alison", "Pull out"])
        $ Copt=_return
        if Copt==0:
            $ Alison.incCm()
            call CharCum ("e02/02_0165.webp", "e02/02_0166.webp", mc, "NNNGGGGGHHHH!!")
            scene 02_0181 with dissolve
            pause
        else:
            call AlisonReplay02_cum
            ali h "You know you don't need to worry about getting me pregnant, right?\nWe're not teens anymore!"
    scene 02_0185 with Fade(1, 0, 1)
    ali "That was a lot of fun..."
    ali "But you know, shower sex is supposed to involve water, right?"
    mc "Damn it! I knew I'd forgotten something! [lol]"
    scene 02_0186 with Fade(1, 0, 1)
    play sound "shower.mp3" volume 0.5 loop
    pause
    scene black with Fade(3, 1,1)
    stop sound
return

label AlisonReplay02_cum:
    call CharCum ("e02/02_0176.webp", "e02/02_0177.webp", mc, "NNNGGGGGHHHH!!")
    call CharCum ("e02/02_0177.webp", "e02/02_0178.webp", mc, "...NNGGGHH!!...")
    scene 02_0179 with dissolve
return

label AlisonReplay03:
    call Unlocker ("AlisonReplay03")
    $ Alison.incSex()
    if _in_replay:
        scene 05_0656 with Fade(2, 1, 1)
        pause 0.5
        scene 05_0657 with dis1
        scene 05_0658 with dis1
        scene 05_0659 with dis1
        ali "[whi][persistent.McName]."
        scene 05_0660 with dissolve
        mc "Oh, damn!"
        scene 05_0661 with dissolve
        ali "Will you do something for me?"
        mc "Anything."
    scene 05_0664 with dissolve
    ali "Take off your clothes."
    if persistent.FootPlay:
        scene 05_0665 with Fade(1, 0.5, 1)
        ali "I want you to sit back and relax, Sweetheart..."
        scene 05_0666 with dissolve
        ali "... Let me do all the work."
        scene 05_0667 with dissolve
        ali "I'm sure my man's had a busy day..."
        scene 05_0668 with dissolve
        ali "... and deserves to be taken care of."
        scene 05_0669 with dissolve
        scene 05_0670 with dis1
        ali "[ss]Ohh."
        scene 05_0671 with dis1
        ali "[ss]....Ahhh...."
        scene 05_0672 with dis1
        scene 05_0673 with dis1
        scene 05_0674 with dissolve
        image r_ail_021 = Movie(play="images/e05/05_0675.webm")
        show r_ail_021
        pause
        scene 05_0676 with dissolve
        ali "[ss]Mmhhhh."
        scene 05_0677 with dissolve
        image r_ail_022 = Movie(play="images/e05/05_0678.webm")
        show r_ail_022
        pause
        scene 05_0679 with Fade(1, 0.5, 0.5)
        ali "I've been dreaming about you all day."
        scene 05_0680 with dissolve
        ali "Licking you. Sucking you. Sitting on you."
    else:
        scene 05_0679 with Fade(1, 0.5, 1)
        ali "I want you to sit back and relax, Sweetheart..."
        scene 05_0680 with dissolve
        ali "I'm sure my man's had a hard-working day...\nand deserves to be taken care of."
    scene 05_0681 with dissolve
    scene 05_0682 with dis1
    ali "[ss]Mmhhhh."
    scene 05_0683 with dissolve
    scene 05_0684 with dis1
    image r_ail_023 = Movie(play="images/e05/05_0685.webm")
    show r_ail_023
    ali "[ss]..Mmhh.."
    scene 05_0686 with dissolve
    mc "[whi]Fuck, that's good."
    scene 05_0687 with dissolve
    image r_ail_024 = Movie(play="images/e05/05_0688.webm")
    show r_ail_024
    ali "[ss]..Mmhh.."
    scene 05_0689 with dissolve
    image r_ail_025 = Movie(play="images/e05/05_0690.webm")
    show r_ail_025
    ali "[ss]..NNGGHHH.."
    scene 05_0691 with dissolve
    scene 05_0692 with dis1
    call Loop_Dissolve (4, True, False, "e05/05_0694.webp", "e05/05_0695.webp")
    scene 05_0693 with dissolve
    ali "[ss]..Mmhhhh.."
    scene 05_0696 with dissolve
    mc "Fuck... Take it all, Baby."
    scene 05_0697 with dissolve
    scene 05_0698 with dis1
    call Gag (ali)
    scene 05_0699 with dissolve
    pause 0.5
    scene 05_0700 with dissolve
    call Gag (ali)
    scene 05_0699 with dis1
    scene 05_0700 with dissolve
    call Gag (ali)
    scene 05_0701 with dissolve
    if persistent.Anal:
        scene 05_0702 with dis1
        scene 05_0703 with dis1
        scene 05_0704 with dis1
        call Moan (ali)
        scene 05_0705 with dissolve
    else:
        ali "[ss]..Mmhh.."
        scene 05_0706 with dissolve
    pause
    scene 05_0707 with fade
    ali "Permission to climb aboard, Soldier?"
    scene 05_0708 with dissolve
    mc "Yes, Ma'am."
    scene 05_0709 with Fade(2,1,1)
    ali "[ss]I love this part."
    scene 05_0710 with dissolve
    ali "[ss]Feeling your dick forcing its way inside me."
    scene 05_0711 with dissolve
    image r_ail_026 = Movie(play="images/e05/05_0712.webm", loop=False, keep_last_frame=True)
    show r_ail_026
    pause 3.0
    ali "[ss]..OHHH.."
    scene 05_0713 with dissolve
    ali "[ss]..OHHH.."
    scene 05_0714 with dissolve
    ali "[ss]Mmhh... I love fucking you, [persistent.McName]..."
    scene 05_0715 with dissolve
    ali "[ss]...Your hard dick makes me so wet...."
    scene 05_0716 with dissolve
    image r_ail_027 = Movie(play="images/e05/05_0717.webm")
    show r_ail_027
    call Moan (ali)
    scene 05_0718 with dissolve
    ali "[ss]..Ohhh.."
    scene 05_0719 with dis1
    pause 0.5
    scene 05_0720 with dissolve
    ali "[ss]Mmmhh."
    scene 05_0721 with dissolve
    ali "[ss]...Mmhhhh..."
    scene 05_0722 with dissolve
    mc "[whi]I think you've done enough work for one night, let me take over..."
    scene 05_0723 with Fade(2,1,1)
    ali "[ss]..OHH, BABY...."
    scene 05_0724 with dissolve
    call Moan (ali)
    scene 05_0725 with dissolve
    image r_ail_028 = Movie(play="images/e05/05_0726.webm")
    show r_ail_028
    ali "[ss]..Ohhh, Baby...Yes...."
    scene 05_0727 with dissolve
    ali "[ss]...Fuck, [persistent.McName], YES...."
    scene 05_0728 with dissolve
    image r_ail_029 = Movie(play="images/e05/05_0729.webm")
    show r_ail_029
    call Moan (ali)
    scene 05_0730 with dissolve
    ali "[ss]Take me from behind, Sweetheart."
    scene 05_0731 with Fade(2,1,1)
    ali "[ss]..OHH..."
    scene 05_0732 with dissolve
    ali "[ss]..YES BABY...."
    scene 05_0733 with dissolve
    image r_ail_030 = Movie(play="images/e05/05_0734.webm")
    show r_ail_030
    call Moan (ali, 6)
    scene 05_0735 with dissolve
    ali "[ss]..Ohhh.."
    scene 05_0736 with dissolve
    image r_ail_031 = Movie(play="images/e05/05_0737.webm")
    show r_ail_031
    call Moan (ali, 6)
    scene 05_0738 with dissolve
    ali "[ss]...Fuck...Yes... Make me cum, [persistent.McName]...."
    scene 05_0739 with dissolve
    image r_ail_032 = Movie(play="images/e05/05_0740.webm")
    show r_ail_032
    call Moan (ali, 8)
    ali "[ss]...OHHHH...."
    ali "[ss]....YES BABY...."
    ali "[ss]...YES....YES...."
    call CharCum ("e05/05_0739.webp", "e05/05_0741.webp", ali, "OHHHHHHHHH!!")
    scene 05_0742 with dissolve
    ali "[ss]...Fuck Baby, that was so good...."
    scene 05_0736 with dissolve
    show r_ail_031
    ali "[ss]...Mmhh...."
    if persistent.Anal:
        call CmOpts ([ "Cum inside Alison", "Pull out", "Cum in her mouth", "Cum on her face",  "Anal sex"])
    else:
        call CmOpts ([ "Cum inside Alison", "Pull out", "Cum in her mouth", "Cum on her face"])
    $ Copt=_return
    if Copt==0:
        $ Alison.incCm()
        call CharCum ("e05/05_0736.webp", "e05/05_0743.webp", mc, "NNNGGGGGHHHH!!")
        scene 05_0744 with dissolve
        mc "[whi]...Fuuck..."
        scene 05_0745 with dissolve
        ali "I think I'll encourage Cara to stay out more often!"
        call laugh (mc)
    elif Copt<4:
        call AlisonReplay03_cum (Copt-1)
    else:
        call AlisonReplay03_anal
    scene black with ReplayFade
return

label AlisonReplay03_anal:
    scene 05_0762 with dissolve
    ali "[ss]Mmmhh.... Yes Baby..."
    scene 05_0763 with dissolve
    ali "[ss]....You know I want it...."
    scene 05_0764 with dissolve
    image r_ail_033 = Movie(play="images/e05/05_0765.webm", loop=False, keep_last_frame=True)
    show r_ail_033
    pause 2.0
    ali "[ss]..Ohh..{w=1}{nw}"
    pause 0.5
    ali "[ss]..FUUUCK...."
    scene 05_0766 with dissolve
    ali "[ss]..OHHH..."
    scene 05_0767 with dissolve
    image r_ail_034 = Movie(play="images/e05/05_0768.webm")
    show r_ail_034
    ali "[ss]...Fuck...."
    ali "[ss]....Yes Baby..."
    ali "[ss]...It feels so good..."
    scene 05_0769 with dissolve
    ali "[ss]...Ohhhh....I love it when you fuck my ass, Sweetheart...."
    scene 05_0770 with dissolve
    image r_ail_035 = Movie(play="images/e05/05_0771.webm")
    show r_ail_035
    call Moan (ali, 8)
    ali "[ss]....Yes, Baby....Ohhhh....."
    call CmOpts ([ "Cum inside Alison", "Pull out", "Cum in her mouth", "Cum on her face"])
    $ Copt=_return
    if Copt==0:
        call CharCum ("e05/05_0770.webp", "e05/05_0772.webp", mc, "NNNGGGGGHHHH!!")
        scene 05_0773 with dissolve
        mc "[whi]...Fuuck..."
        scene 05_0774 with dissolve
        ali "I think I'll encourage Cara to stay out more often!"
        call laugh (mc)
    elif Copt==1:
        call AlisonReplay03_cum (0)
    elif Copt==2:
        call AlisonReplay03_cum (1, False)
    else:
        call AlisonReplay03_cum (2, False)
return

label AlisonReplay03_cum(opt, opt2=True):
    if opt==0:
        call CharCum ("e05/05_0736.webp", "e05/05_0746.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e05/05_0746.webp", "e05/05_0747.webp", mc, "...Nnnnhhhhh..")
        scene 05_0748 with dissolve
        ali "I think I'll encourage Cara to stay out more often!"
        mc "[lol]"
    else:
        $ aaa=""
        if not opt2:
            $ aaa="a"
        show expression "05_0749" + aaa with dissolve
        mc "Come here, Baby."
        scene 05_0750 with dissolve
        pause
        call Loop_Dissolve (6, False, False, "e05/05_0751.webp", "e05/05_0752.webp")
        call CharCum ("e05/05_0751.webp", ("e05/05_0753.webp" if opt==1 else "e05/05_0759.webp") , mc, "NNNGGGGGHHHH!!")
        call CharCum (("e05/05_0753.webp" if opt==1 else "e05/05_0759.webp"), ("e05/05_0754.webp" if opt==1 else "e05/05_0760.webp"), mc, "...Nnnnhhhhh..")
        if opt==1:
            scene 05_0755 with dissolve
            pause  
            scene 05_0756 with dissolve
            call Gulp (ali)
            scene 05_0757 with dissolve
            pause
            scene 05_0758 with dissolve
            ali "I've never forgotten how good you taste."
        else:
            scene 05_0761 with dissolve
            ali "I think I'll encourage Cara to stay out more often!"
            mc "[lol]"
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
