label Springhaven_AF01:
    scene 01_0168
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e01/01_0169.webp")
    sar "Did you... just check me out?"
    $ Sarah.Score(1)
    scene 01_0170 with dissolve
    mc "Err... sorry."
return

label Springhaven_AF02:
    $ Sarah.Score(1)
    scene 01_0175
    hide screen imgMap
    $ _skipping = True
    scene 01_0176 with dissolve
    mct "Damn..."
    scene 01_0177 with dissolve
    sar "Did you just..."
    sar h "Would you rather I wore something, uhh, a little... less revealing?"
    mc "Crap... Sorry... No, you don't need to do that."
return

label Springhaven_AF03:
    scene 01_0187
    hide screen imgMap
    $ _skipping = True
    scene 01_0188 with dissolve
    pause 0.5
    scene 01_0189 with dis1
    scene 01_0190 with dis1
    scene 01_0191 with dis1
    pause 0.5
    scene 01_0192 with dissolve
    mct "Nice."
    $ TmpChosen=None
    if not Sarah.Has("EZ"):
        menu:
            "[wk_y]Pull up the blanket and go back to sleep":
                $ TmpChosen=True
            "Touch[wk_c]":
                scene 01_0194 with dissolve
                mct "That asshole was right, it IS a sweet ass!"
                scene 01_0195 with dissolve
                sar sh "WHAT THE HELL??!"
                scene 01_0196 with dissolve
                sar a "WHAT ARE YOU DOING??"
                sar a "PLEASE GO BACK TO THE COUCH!"
                mc s "Ah, shit! I'm sorry, Sarah! I didn't..."
                scene 01_0197 with dissolve
                sar a "COUCH!"
                mc "Okay, okay. I'm going."
                call CloseCharacterPath (Sarah, "Sarah")
                $ Sarah.Add("couch")
                scene 01_0161 with Fade(2, 0.5, 1)
                call Emotion (mc, "Snore", "..Zzzzz..")
    if TmpChosen or Sarah.Has("EZ"):
        scene 01_0193 with dissolve
        $ Sarah.Score(1)
        pause 1.0 
return

label Springhaven_AF05:
    $ Mary.Score(1)
    scene 01_0385
    hide screen imgMap
    $ _skipping = True
    scene 01_0386 with dissolve
    pause 1.0
    scene 01_0387 with dissolve
    pause 1.0
    scene 01_0388 with dissolve
    pause 1.0
return

label Springhaven_AF06:
    $ Mary.Score(1)
    scene 01_0392
    hide screen imgMap
    $ _skipping = True
    scene 01_0387 with dissolve
    mc "You would, huh?"
    scene 01_0393 with dissolve
    mar h "Yeah."
    scene 01_0394 with dissolve
    mar "I'd be a {i}real{/i} good girl for you, {i}Daddy{/i}."
    menu:
        "I don't think you should call me that.":
            scene 01_0395 with dissolve
            $ Mary.Add("NoDaddy")
            $ Mary.Score(-1)
            $ persistent.MaryDaddy=False
            mar "Darn it! I'm sorry, I didn't mean to offend you.\nI was only being silly."
            mc "It's okay, you didn't offend me.\nI don't think it'd be appropriate, that's all."
        "[wk_y]I like you calling me Daddy!":
            $ persistent.MaryDaddy=True
            $ Mary.Score(1)
            scene 01_0396 with dissolve
            mar "Me too!"
return

label Springhaven_AF07:
    $ Mary.Score(1)
    scene 01_0511a
    hide screen imgMap
    $ _skipping = True
    mc "You're looking great this morning!"
    scene 01_0512 with dissolve
    mar "Aww! You're too sweet!"
return

label Springhaven_AF08:
    $ Alison.Score(-2)
    scene 01_0586
    hide screen imgMap
    $ _skipping = True
    scene 01_0587 with dissolve
    mct "Damn!\nShe's right, she's {b}not{/b} a kid anymore! Heh."
    scene 01_0588 with dissolve
    ali "Uhh, go put on some sweatpants, Sweetheart."
    if not Cara.hasScore(0):
        scene 01_0589 with dissolve
        car "I was {i}just{/i} about to, Mom."
    else:
        scene 01_0591 with dissolve
        car h "Ohh, Mom! It's only Uncle [mc]!\nI'm sure he doesn't mind seeing my ass!"
        ali "Go!"
        scene 01_0592 with dissolve
        car "UGGH!! Fine!"
return

label Springhaven_AF09:
    $ Alex.Score(1)
    scene 01_0679 with dissolve
    hide screen imgMap
    $ _skipping = True
    alex h "Wow. Straight to the boobs, huh?"
    scene 01_0678 with dissolve
    mc "Err, sorry."
    mc "{b}Cara{/b} said I was cute?"
return

label Springhaven_AF10:
    $ Alison.Score(1)
    scene 01_0740
    hide screen imgMap
    $ _skipping = True
    scene 01_0741 with dissolve
    ali h "Err... My eyes are up here!"
    scene 01_0740 with dissolve
    mc h "Crap. Busted!"
return

label Springhaven_AF11:
    $ Cara.Score(1)
    $ Cara.Add("B1")
    scene 01_0858
    hide screen imgMap
    $ _skipping = True
    scene 01_0859 with dissolve
    car "[whi]Umm..."
return

label Springhaven_AF12:
    $ Cara.Add("B2")
    scene 01_0901
    hide screen imgMap
    $ _skipping = True
    car "Are you looking down my top??!"
    scene 01_0902 with dissolve
    mc "What?! No!\nI'm studying your form!"
    car "Ohh, okay."
    mct "What the hell am I doing?!"
return

label Springhaven_AF13:
    $ Cara.Add("B3")
    scene 01_0910
    hide screen imgMap
    $ _skipping = True
    if Cara.Has("B2"):
        mct "Damn it! Why do I keep looking??!"
        scene 01_0911 with dissolve
        car "Are you looking down my top again??!"
        mc "Of course not!"
    else:
        scene 01_0911 with dissolve
        car "Are you looking down my top??!"
        mc "What?! No!\nI'm studying your form!"
        car "Uhh, okay."
return

label Springhaven_AF14:
    scene 01_0918
    hide screen imgMap
    $ _skipping = True
    if Cara.Has("B2") and Cara.Has("B3"):
        mct "They ARE nice boobs, but seriously, why can't I STOP LOOKING?!"
        scene 01_0919 with dissolve
        car "{b}Dude! AGAIN??!"
        mc "What?!"
        scene 01_0920 with dissolve
        car "You always stand {i}exactly{/i} where you can see right down my top!"
        mc "I'm just..."
        car "Studying my form? {i}Yeah, right{/i}!"
        scene 01_0921 with dissolve
        car "Jeez!"
        scene 01_0922 with dissolve
        car "Okay, how about this...."
        car "You {b}concentrate{/b} on teaching me, and I'll fuckin' show you my tits when we get home!"
        car "Deal?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Deal":
                    $ tCh=True
                "No deal[wk_c]":
                    pass
        if tCh or Cara.Has("EZ"):
            $ Cara.Add("Deal")
            mc "Uhh... Okay, fuck it! Deal."
        else:
            call CloseCharacterPath (Cara, "Cara")
            mc "No! What's wrong with you?!"
            scene 01_0923 with dissolve
            car "Crap! I thought you were perving!"
            car "I'm sorry!"
            mc "Just take the shot! [lol]"
    else:
        mct "Jeez! Wish she'd worn a different top! Heh."
return

label Springhaven_AF15:
    scene 02_0391
    hide screen imgMap
    $ _skipping = True
    $ Nicole.Score(-2)
    call ScanImage ("images/e02/02_0392.webp")
return

label Springhaven_AF16:
    scene 02_0558
    hide screen imgMap
    $ _skipping = True
    scene 02_0559 with dissolve
    mct "Hmmm, looks like they're planning something."
    mct "Is this a test?\nIs there a hidden camera somewhere?"
    menu:
        "[wk_y]Take a closer look":
            pass
        "Ignore the paperwork":
            return
    scene 02_0560 with fade
    mct "Definitely plans for... something."
    scene 02_0561 with dissolve
    mct "Looks like a big job, whatever it is."
    menu:
        "Sit back down":
            return
        "[wk_y]Take some snapshots and send them to Alysha":
            pass
    $ SentDocs=True
    $ Alysha.Score(2)
    scene 02_0562 with dissolve
    play sound "photo.mp3"
    pause 1.0
    play sound "photo.mp3"
    pause 0.5
return

label Springhaven_AF17:
    scene 02_0581
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e02/02_0582.webp")
    mct "I know I shouldn't be looking at her like that, but damn! I can't help myself!"
return

label Springhaven_AF18:
    scene 03_0372
    hide screen imgMap
    $ _skipping = True
    $ Mary.Score(1)
    scene 03_0373 with dissolve
    pause
    scene 03_0374 with dissolve
    pause 0.5
    scene 03_0375 with dissolve
    pause 0.5
    scene 03_0376 with dissolve
    $ dia = "Want me to leave it like that" + (", Daddy?" if persistent.MaryDaddy else "?")
    mar "[dia]"
    scene 03_0377 with dissolve
    mc "[whi]Hmm?"
    mc "What? Err... No.\nSorry, I shouldn't have..."
    mar "[giggles]"
return

label Springhaven_AF19:
    scene 03_0388
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e03/03_0389.webp")
return

label Springhaven_AF20:
    scene 03_0928
    hide screen imgMap
    $ _skipping = True
    $ Mary.Score(1)
    scene 03_0929 with dissolve
    pause 0.5
    scene 03_0930 with dis1
    mar "[ss]..Mmmmhhh..."
    scene 03_0931 with dissolve
    pause 
    scene 03_0932 with dissolve
    $ dia = "I get {i}even bigger{/i} butterflies when you touch me" + (", Daddy." if persistent.MaryDaddy else ".")
    mar "[dia]"
    play sound "horn.mp3"
    pause 1.0
    scene 03_0933 with dissolve
    mar "They're very impatient!"
    mc "Yeah. I'd better go."
return

label Springhaven_AF21:
    scene 03_0985
    hide screen imgMap
    $ _skipping = True
    mc "No. I was discreet."
    sue "Excellent."
    scene 03_0986 with dissolve
    mct "Nice decor. Heh."
    $ Sue.Add("Toy")
return

label Springhaven_AF22:
    scene 03_1135
    hide screen imgMap
    $ _skipping = True
    scene 03_1136 with dissolve
    pause
    scene 03_1137 with dissolve
    pause 0.5
    play sound "kick01.mp3" volume 0.5
    scene 03_1138 with hpunch
    pause 0.25
    scene 03_1139 with dissolve
    pause 0.5
    if Alison.isSexual():
        scene 03_1140 with dissolve
        mct "Oops! Busted! Heh."
    else:
        $ Alison.Score(-1)
        scene 03_1141 with dissolve
        mct "Crap."
return

label Springhaven_AF23:
    scene 05_0247
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e05/05_0248.webp", 2)
    mc "HOT DAMN!!"
return

label Springhaven_AF24:
    scene 05_0252
    hide screen imgMap
    $ _skipping = True
    scene 05_0253 with dissolve
    mc "Fuckin' love it! Heh."
return

label Springhaven_AF25:
    scene 05_0345
    hide screen imgMap
    $ _skipping = True
    scene 05_0346 with dissolve
    mct "Nice! Heh."
    gab "Enjoying the view, {i}old man{/i}?"
    scene 05_0347 with dissolve
    mc "[whi]Err, sorry."
    gab "Sorry for looking? Or for getting caught?"
    $ tCh=None
    if not EzModeActive:
        menu:
            "Looking":
                pass
            "[wk_y]Getting caught":
                $ tCh=True
    elif Gabby.Has("EZ"):
        $ tCh=True
    if tCh:
        mc "Getting caught."
        $ Gabby.Score(1)
        scene 05_0348 with dissolve
        if Gabby.Has("watch"):
            $ Gabby.Add("Look")
            gab "Don't be."
            gab "You let {i}me{/i} watch, so I'll allow {i}you{/i} to look."
        else:
            gab "Pervert."
    else:
        gab "Bullshit."
    gab "Why you asking about Mel?"
return

label Springhaven_AF26:
    scene 05_0374
    hide screen imgMap
    $ _skipping = True
    mc "Hey."
    scene 05_0375 with dissolve
    mc "You look good out of uniform."
    scene 05_0376 with dissolve
    aly "Shut up! [lol]"
    $ Alysha.Score(1)
return

label Springhaven_AF27:
    scene 06_0351
    hide screen imgMap
    $ _skipping = True
    scene 06_0352 with dissolve
    sar "Good morning! Sorry, had to leave early for work.\nDidn't want to wake you!\nHelp yourself to breakfast. xx"
return

label Springhaven_AF28:
    scene 09_0037
    hide screen imgMap
    $ _skipping = True
    scene 09_0039 with dissolve
    mc "I can give you some action..."
return

label Springhaven_AF29:
    scene 09_0136
    hide screen imgMap
    $ _skipping = True
    $ Nicole.Score(1)
    scene 09_0137 with dissolve
    mct "Nice."
return

label Springhaven_AF30:
    scene 09_0187
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e09/09_0188.webp", 2)
    pause
return

label Springhaven_AF31:
    $ Mary.Score(1)
    scene 09_0441
    hide screen imgMap
    $ _skipping = True
    scene 09_0442 with dissolve
    pause 1.0
    scene 09_0443 with dissolve
    pause 1.0
    scene 09_0444 with dissolve
    pause 1.0
return

label Springhaven_AF32:
    $ Mary.Score(1)
    scene 09_0449
    hide screen imgMap
    $ _skipping = True
    scene 09_0443 with dissolve
    mc "You would, huh?"
    scene 09_0450 with dissolve
    mar h "Yeah."
    scene 09_0451 with dissolve
    mar "I'd be a {i}real{/i} good girl for you, {i}Daddy{/i}."
    menu:
        "I don't think you should call me that.":
            scene 09_0452 with dissolve
            $ Mary.Score(-1)
            mar "Darn it! I'm sorry, I didn't mean to offend you.\nI was only being silly."
            mc "It's okay, you didn't offend me.\nI don't think it'd be appropriate, that's all."
        "[wk_y]I like you calling me Daddy!":
            $ persistent.MaryDaddy=True
            $ Mary.Score(1)
            scene 09_0453 with dissolve
            mar "Me too!"
return

label Springhaven_AF33:
    $ Nicole.Add("Uniform")
    scene 13_0994
    hide screen imgMap
    $ _skipping = True
    mc "Did it fit?"
    scene 13_0995 with dissolve
    nic "Huh?"
    mc "The school uniform! Did it still fit?"
    scene 13_0996 with dissolve
    nic "Oh!"
    nic "No."
    nic "I don't know, I couldn't find it."
    mc "Damn shame!"
    scene 13_0997 with dissolve
    nic "[lol]"
    scene 13_0998 with dissolve
    nic "The only one I found was one I'd bought for a party."
    scene 13_0999 with dissolve
    nic "School-themed fancy dress. We were all invited."
    nic "I didn't end up wearing it, though."
    mc "How come?"
    scene 13_1000 with dissolve
    nic "I don't know... When I came home and tried it on...\nI wasn't comfortable going out in it."
    nic "I just wore something else instead."
    scene 13_1001 with dissolve
    mc "So... you gonna put it on?"
    nic "No!"
    mc "Why not?!\nYou can't tell me that and {b}not{/b} show me!"
    scene 13_1002 with dissolve
    nic "[lol] No way!\nIt's too embarrassing!"
    nic "I don't even know why I kept it."
    scene 13_1003 with dissolve
    mc "Heh, okay, fair enough.\nI would never want to embarrass you."
    scene 13_1004 with dis1
return

label Springhaven_AF34:
    scene 13_1043
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e13/13_1044.webp", 5)
    mc "Whoa."
return

label Springhaven_AF35:
    scene 14_0198
    hide screen imgMap
    $ _skipping = True
    scene 14_0199 with dis1
    scene 14_0200 with dis1
    mar "[ss]..Mmmhh.."
    scene 14_0201 with dissolve
    mar "[ss]..Mmmmhhh..."
    scene 14_0202 with dissolve
    $ dia = "I get {i}even bigger{/i} butterflies when you touch me like that" + (", Daddy." if persistent.MaryDaddy else ".")
    mar "[dia]"
    scene 14_0203 with dissolve
    pause
    scene 14_0204 with dissolve
    mar "[ss]..Mmmhh.."
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
