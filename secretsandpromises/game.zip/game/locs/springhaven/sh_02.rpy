label Springhaven_Bedtime01:
    if Alison.isSexual():
        scene 01_0838 with dissolve
        ali h "[whi]Mmmhhh."
        scene 01_0839 with dissolve
        ali h "[whi]This is nice."
        scene 01_0840 with dissolve
        mc "[whi]You're about to kick me out of bed, aren't you?"
        ali "[whi]Yeah... Sorry!"
        scene 01_0841 with dissolve
        ali "[whi]I really don't want to!\nBut if Cara saw you in here..."
        mc h "[whi]Don't worry, I get it."
        scene black with Fade(2,1,0)
    else:
        scene 01_0751 with Fade(2, 1, 1)
        mct "What a fuckin' day. I'm exhausted!"
    scene 01_0752 with fade1
    mct "Goddamn you, Pete!\nWhy the fuck didn't you talk to me about all the shit you were in?!"
    scene 01_0753 with dissolve
    mct "Don't worry, Buddy.\nI'll clean up your mess. Just like I've always done."
    scene black with Fade(2, 1, 1)
    pause 2.0
    jump Springhaven_WakeUpAlisons
return

label Springhaven_WakeUpAlisons:
    scene 01_0842 with Fade(1, 1, 3)
    mc "[whi]...Zzzz..."
    scene 01_0843 with dissolve
    call Emotion (mc, "Groan", "")
    scene 01_0844 with Fade(2, 1, 1)
    car "You do! I'm just sayin'!"
    ali h "[giggles]"
    scene 01_0845 with dissolve
    ali "Morning, [mc]. Sleep okay?"
    mc "Yeah, fine thanks."
    scene 01_0846 with dissolve
    car "Don't forget about your {b}important{/b} mission later, Uncle [mc]!"
    mc h "You mean my {i}mission impossible{/i}?"
    car h "Shut up!"
    scene 01_0847 with dissolve
    ali "Breakfast?"
    mc "No thanks. I'm gonna head out."
    ali "Not even coffee?"
    scene 01_0848 with dissolve
    mc "There's someone I need to see, don't want to miss them."
    ali "Oh, okay."
    $ tCh=None
    if not EzModeActive:
        menu:
            "Leave":
                pass
            "[wk_y]Kiss them both goodbye":
                $ tCh=True
    if tCh or Cara.Has("EZ") or Alison.Has("EZ"):
        $ Alison.Score(1)
        $ Cara.Score(1)
        scene 01_0850 with dissolve
        mc "I'll be back later."
        ali "Okay."
        scene 01_0851 with dissolve
        ali "[kiss]"
        scene 01_0852 with dissolve
        $ tCh=Alison.Has("EZ")
        if not EzModeActive:
            menu:
                "[wk_y]Slide your hand down to her butt":
                    $ tCh=True
                "Keep your hand where it is":
                    $ tCh=False
        if tCh:
            scene 01_0853 with dissolve
            pause
            scene 01_0854 with dissolve
            $ Alison.Score(1)
            if Alison.Has("SaidNo"):
                ali "[whi]You had your chance last night."
                mc "[whi]It was difficult saying no, believe me!"
                ali "[whi]Next time, say yes."
            elif Alison.isSexual():
                ali "[whi]No regrets from last night, then?"
                mc "[whi]Of course not."
                ali "[whi]Me neither."
            else:
                ali "[whi]Umm... That's a little inappropriate!"
                mc h "[whi]Just sayin' hello to an old friend."
            scene 01_0855 with dissolve
            car "What are you two whispering about?"
        scene 01_0856 with dissolve
        car "Do I get one, too?"
        scene 01_0857 with dissolve
        mc "Would I {i}ever{/i} forget you?"
        if persistent.Incest:
            if persistent.UseFocus and not EzModeActive:
                $ _skipping = False
                show screen imgMap("images/e01/01_0858.webp", 1056, 763, True, "Springhaven_AF11") with dissolve
                car h "You'd better not!"
                $ _skipping = True
                if renpy.get_screen("imgMap"):
                    scene 01_0858
                    hide screen imgMap
                    mc h "[whi]Never!"
            else:
                scene 01_0858 with dissolve
                car h "You'd better not!"
                if not EzModeActive:
                    menu:
                        "[wk_y]Check her out":
                            call Springhaven_AF11
                        "Don't":
                            mc h "[whi]Never!"
                else:
                    if Cara.Has("EZ"):
                        call Springhaven_AF11
                    else:
                        mc h "[whi]Never!"
        scene 01_0860 with dissolve
        car "[kiss]"
        scene 01_0861 with dissolve
        ali h "Are you {i}blushing{/i}?"
        car "What? No!\nI was expecting a kiss on the head, not on my lips!"
        scene 01_0862 with dissolve
        ali h "Awww, that's so cute!"
        car h "Shut up!"
        ali "Bye, [mc]!"
    else:
        scene 01_0849 with dissolve
        mc "I'll be back later."
        ali "Bye."
    jump Springhaven_Cemetry02
return

label Springhaven_Cemetry02:
    scene 01_0863 with Fade(2, 2, 1)
    mc "[whi]What were you thinkin', Buddy?\nBorrowing from scumbags!"
    scene 01_0864 with dissolve
    mc "[whi]Were you {b}that{/b} desperate?!\nYou should've talked to me!"
    mc "[whi]We told each other everything!"
    scene 01_0865 with dissolve
    mc "[whi]... Well, {i}almost{/i} everything."
    scene 01_0866 with fade
    mc "[whi]Guess we all have our secrets."
    scene black with fade1
    if Sarah.Has("Cell") or Mary.Has("Cell"):
        call CenterText ("An hour or so later...")
        scene 01_0866_01 with fade1
        pause 0.5
        play sound "text.mp3"
        pause 0.5
        scene 01_0866_02 with dissolve
        pause 1.0
        if Sarah.Has("Cell"):
            show screen CellPhone("Sarah")
            msg_nvl "Hi."
            msg_nvl "You were on my mind. I hope your delivery went okay."
            msg_nvl "Dawn called me with another emergency, so I'll be heading back to Lakeshore in a few days."
            msg_nvl "Don't know why I told you that. But, if you want a ride."
            msg_nvl "You know, back to Lakeshore, I mean!"
            msg_nvl "I'm going to stop texting now! {image=/thumbs/cell/emoji/blush smile.png}"
            mc_nvl "Nice to hear from you. Delivery went... as expected."
            mc_nvl "Not sure of my plans, but thanks for the offer, haha. I'll let you know!"
        else:
            show screen CellPhone("Mary")
            msg_nvl "Hello!"
            msg_nvl "I'm checking to make sure I wrote down your number correctly!{image=/thumbs/cell/emoji/eyes.png}"
            mc_nvl "Hi Mary. Yep, you did."
            msg_nvl "Great! Pops wanted me to let you know that he'll be doing the Lakeshore run again in a few days."
            msg_nvl "I asked if he enjoys your company. He said the sound of your snoring soothes him."
            mc_nvl "Haha. Thanks. I'll let you know if I need to head that way."
            if Mary.Has("Stay"):
                msg_nvl "I had a dream about you last night!"
                msg_nvl "You were on the bed doing... that thing, again."
                msg_nvl "But in my dream, it wasn't YOU doing it, it was ME! {image=/thumbs/cell/emoji/oops.png}"
                msg_nvl "Have to go, Pops is calling!"
                msg_nvl "Hope to see you soon! {image=/thumbs/cell/emoji/heart.png}"
            else:
                msg_nvl "Ok. Hope to see you soon! {image=/thumbs/cell/emoji/heart.png}"
        call CloseCell ()
        pause 0.5
        scene black with fade1
        call CenterText ("Another hour passes...")
    else:
        call CenterText ("Over two hours later...")
    scene 01_0867 with fade
    pause 0.5
    scene 01_0868 with dis1
    pause 0.5
    scene 01_0869 with dis1
    pause 0.5
    scene 01_0870 with dis1
    if Alysha.Has("park"):
        aly "Please tell me you didn't sleep here!"
        mc "No. [lol]"
    else:
        aly "Hello.\nBack again?"
        mc "Yeah."
    scene 01_0871 with dissolve
    aly "It's ironic.\nI visit him more now than I ever did when he was alive."
    aly "Who are you visiting? If you don't mind me asking."
    scene 01_0872 with dissolve
    mc "I'm here to see you."
    scene 01_0873 with dissolve
    aly "Me?!"
    scene 01_0874 with dissolve
    mc "Whoa! Take it easy..."
    mc "... I was hoping you could help me find someone, that's all."
    scene 01_0875 with dissolve
    aly "That's far enough!"
    aly "You can file a report about a missing person at the station."
    scene 01_0876 with dissolve
    mc "The person I'm looking for isn't missing."
    aly "I can't help you, sir."
    mc "Please.\nI'm tryin' to help a friend who's in trouble."
    scene 01_0877 with dissolve
    mc "Her husband is buried right over there.\nHe died fighting for this country."
    mc "He died protecting me.\nNow I need to protect his family."
    scene 01_0878 with dissolve
    aly "You serve?"
    mc "Served."
    scene 01_0879 with dissolve
    aly "Okay, soldier..."
    aly "Why don't you tell me what this is about?"
    scene 01_0880 with dissolve
    mc "Before he died, he borrowed money from the wrong people. Bad people."
    mc "They want it back.\nPushed the debt onto his wife."
    mc "Threatening her and their daughter."
    scene 01_0881 with dissolve
    aly "You should come down to the station and report it."
    scene 01_0882 with dissolve
    mc "{b}Oh, come on!{/b}\nWe both know that won't do shit!"
    mc "You guys don't do anything until it's too late!\nI need to make this right, {b}now{/b}."
    scene 01_0883 with dissolve
    mc "I thought you may know of these assholes or where I might find them."
    aly "Sorry, no."
    scene 01_0884 with dissolve
    mc "Okay. Was worth a shot.\nSorry for bothering you."
    scene 01_0885 with dissolve
    aly "Wait."
    scene 01_0886 with dissolve
    aly "Give me your number."
    aly "I'll ask around at the station.\nSomeone there may know who they are."
    mc "Okay. Thanks."
    scene 01_0887 with dissolve
    aly "If you find these guys..."
    mc "Don't worry.\nI won't make life difficult for you, officer."
    aly "Alysha."
    $ Alysha_name="Alysha"
    $ Alysha.Activate("Alysha")
    $ persistent.AlyshaLocked=False
    scene 01_0888 with dissolve
    mc "Thanks, Alysha. I'm [mc]."
    aly "Nice to meet you, [mc]."
    scene 01_0889 with fade
    aly "Hey, Pa.\nSeems you're not the only soldier buried here!\nYou're in good company."
    scene black with Fade(2, 2, 1)
    scene 01_0890 with fade
    mct "Hope Alysha finds something out about these fuckin' guys."
    mct "Alison didn't tell me anything useful to help find them."
    play sound "text.mp3"
    pause 0.5
    scene 01_0891 with dissolve
    mct "Oh, jeez! Cue the music..."
    show screen CellPhone("Cara")
    msg_nvl "Where are you?"
    msg_nvl "I'm at the bar waiting for ya!{image=/thumbs/cell/emoji/halo.png}"
    mc_nvl "On my way!"
    call CloseCell ()
    play sound "mi.mp3" volume 0.5
    mct "Dun-dun, dun-dun-dun-dun! [lol]{w=2}{nw}"
    jump Springhaven_MissionImpossible
return

label Springhaven_MissionImpossible:
    scene 01_0893 with fade2
    play music "bar02.mp3" fadein 1.0 loop
    mc "Hey."
    scene 01_0894 with dissolve
    car "Great! You made it!"
    scene 01_0895 with dissolve
    car "Teach me everything you know, Master![giggles]"
    scene 01_0896 with dissolve
    mc h "Oh, boy... Think I'm gonna need a beer for this."
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Offer Cara a beer":
                $ tCh=True
            "Just one for yourself":
                pass
    if tCh or Cara.Has("EZ"):
        $ Cara.Score(1)
        mc "Want one?"
        car "Yeah! Thanks."
        scene 01_0897 with Fade(1, 0.5, 1)
        mc "Cheers."
        car "Cheers!"
    scene 01_0898 with Fade(1, 0.5, 1)
    mc "Okay, let's see what we've got to work with."
    car h "Prepare to be impressed!"
    scene 01_0899 with Fade(2, 1, 1)
    mc "Wow! She's {i}finally{/i} about to clear the table!"
    $ ab=False
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0900.webp", 751, 410, True, "Springhaven_AF12") with dissolve
            car "Shut up!!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0900
                hide screen imgMap
                mc "[lol]"
        else:
            scene 01_0900 with dissolve
            car "Shut up!!"
            $ tCh=None
            if not EzModeActive:
                menu:
                    "[wk_y]Look down her top":
                        $ ab=True
                        call Springhaven_AF12
                    "Don't":
                        mc "[lol]"
            elif Cara.Has("EZ"):
                $ ab=True
                call Springhaven_AF12
    else:
        car "Shut up!!"
    scene 01_0903 with fade
    car "So? What do you think?"
    mc "We have a {i}lot{/i} of work to do."
    car h "I wasn't {b}that{/b} bad!"
    scene 01_0904 with dissolve
    mc "Let's start with your grip."
    car "My grip??"
    mc "You're not holding the end of your cue naturally..."
    scene 01_0905 with dissolve
    mc "Now, let's pretend you're gonna hit me with it.\nPick it up."
    car h "Do we {i}have{/i} to pretend?"
    scene 01_0906 with dissolve
    car "Okay, I'm ready. Come at me!"
    mc "[lol]"
    mc "{i}That's{/i} your natural position. That's where you should grip it."
    mc "Don't grip it too tightly, or too loosely. It should just {i}feel{/i} natural."
    scene 01_0907 with dissolve
    car "Alright... I get it."
    mc "Great. Now let's talk about your stance..."
    call CenterText ("An hour or so later...")
    scene 01_0908 with dissolve
    mc "That's it..."
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0909.webp", 994, 429, True, "Springhaven_AF13") with dissolve
            mc "... Much better!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0909
                hide screen imgMap
        else:
            scene 01_0909 with dissolve
            mc "... Much better!"
            if ab:
                call Springhaven_AF13
    scene 01_0912 with dissolve
    play sound "ballhit.mp3"
    scene 01_0913 with dissolve
    scene 01_0914 with dissolve
    play sound "ballin.mp3"
    scene 01_0915 with dissolve
    scene 01_0916 with dissolve
    mc "Nice shot!"
    car h "It was!"
    call CenterText ("Another hour passes...")
    scene 01_0917 with fade
    mc "Tough shot, you sure you wanna go for it?"
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e01/01_0918.webp", 813, 597, True, "Springhaven_AF14") with dissolve
            car "Yep."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 01_0918
                hide screen imgMap
                mc "I like your confidence!"
        else:
            scene 01_0918 with dissolve
            car "Yep."
            if ab:
                call Springhaven_AF14
        $ Cara.Del("B2")
        $ Cara.Del("B3")
    else:
        car "Yep."
        mc "I like your confidence!"
    scene 01_0924 with dissolve
    play sound "ballhit.mp3"
    scene 01_0925 with dissolve
    scene 01_0926 with dissolve
    play sound "ballin.mp3"
    scene 01_0927 with dissolve
    car "YES!"
    mc "Nicely done!"
    scene 01_0928 with dissolve
    car "Holy shit!\nI've never made a shot like that before!"
    mc "Keep going! I'm gonna get another beer."
    scene 01_0929 with dissolve
    barman "Same again?"
    mc "Yeah."
    scene 01_0930 with dissolve
    barman "Nice to see the quiet one practicing!\nHer loud friend never seems to lose!"
    mc h "Yeah, that's what we're aiming to change."
    mc x "You must get all sorts in here, huh?"
    barman "Yeah."
    scene 01_0931 with dissolve
    mc "What about scumbag debt collectors?"
    barman "Huh?"
    mc "The type of guys who lend people money so they can extort them later."
    barman "Uhh, yeah. I've heard about guys like that.\nDon't come in here, though."
    mc "Where {i}do{/i} they go?"
    scene 01_0932 with dissolve
    barman "Don't know."
    barman "I know someone who might, though..."
    barman "A friend of mine, his kid purchased a cafe here in the city."
    barman "Made the mistake of borrowing cash for improvements.\nBeen tryin' to pay it back ever since."
    mc "Where can I find this cafe?"
    scene 01_0933 with dissolve
    barman "Other side of town. Rosie's. Can't miss it."
    mc "Thanks. Appreciate it."
    scene 01_0934 with dissolve
    barman "Be careful, friend."
    barman "They aren't the kind of guys you fuck around with."
    mc "Neither am I."
    scene 01_0935 with dissolve
    mc "Starting to look like a pro!"
    scene 01_0936 with Fade(2, 2, 1)
    car "Are you watching?"
    mc "Yep."
    play sound "ballhit.mp3"
    scene 01_0937 with dissolve
    scene 01_0938 with dissolve
    play sound "ballin.mp3"
    scene 01_0939 with dissolve
    scene 01_0940 with dissolve
    mc "Okay, you're ready for Alex."
    car "Yes! I can't wait!\nIt's gonna be so much fun beating her![lol]"
    mc "Come on, let's get outta here."
    stop music fadeout 2.0
    scene 01_0941 with Fade(2, 2, 1)
    car "Thanks, Uncle [mc]. That was a lot of fun."
    mc "Yeah, it was."
    scene 01_0942 with dissolve
    car "Can I ask you something... personal?"
    mc "Uh, okay..."
    car "Did you and Mom have sex last night?"
    if Alison.isSexual():
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Yes":
                    $ tCh=True
                "No":
                    mc "What?\nNo! Of course not!"
                    car "Oh. Sorry.\nShe seemed different this morning, I thought she'd been laid."
                "None of your business!":
                    $ Cara.Score(-1)
                    car "Uhh, okay. Sorry I asked!"
        if tCh or Cara.Has("EZ"):
            $ Cara.Score(1)
            mc "Err... Yeah."
            mc "I'm sorry..."
            scene 01_0943 with dissolve
            car h "Don't be!\nI'm glad she got laid!"
            mc "Oh, okay."
            scene 01_0944 with dissolve
            car "She's been sad for such a long time. Even before Dad..."
            car "She was like a different person at breakfast.\nSo happy! It was nice to see her like that."
        elif EzModeActive:
            mc "What?\nNo! Of course not!"
            car "Oh. Sorry.\nShe seemed different this morning, I thought she'd been laid."
    else:
        $ Cara.Score(1)
        mc "What?\nNo! Of course not!"
        car h "Oh. Sorry.\nShe seemed different this morning, I thought she'd been laid."
    scene 01_0945 with dissolve
    mc "Let's get you home. Before she sends out another search party."
    car "Don't worry, she's still at work!\nShe texted me about five minutes ago, checking in.[lol]"
    scene 01_0946 with Fade(2, 2, 1)
    car "Rosie's?\nThe cafe in town? Yeah, I know it."
    mc "Can you send me the location?"
    car "Sure.\nWe could've gone there before coming home if you'd mentioned it earlier!"
    scene 01_0947 with dissolve
    mc "There's someone there I need to talk to. Privately."
    car h "Oh, okay.\nI could've come home by myself. I didn't need an escort!"
    mc "Just wanted to be sure you were safe, Pipsqueak!"
    car "I'm safe. You're relieved of duty![lol]"
    scene 01_0948 with dissolve
    mc "I shouldn't be too long. See you later."
    car "Bye."
    if Cara.Has("Deal"):
        $ Cara.Del("Deal")
        scene 01_0949 with dissolve
        car "Oh, wait!"
        scene 01_0950 with dissolve
        car "Did you forget?"
        scene 01_0951 with dissolve
        car "Come on.\nA deal's a deal!"
        mc "Oh, right..."
        scene 01_0952 with dissolve
        mc h "You could show them to me here!"
        car h "And if Mom walks in?!"
        call CaraReplay01_Part01
    jump Springhaven_RosieCafe01
return

label Springhaven_RosieCafe01:
    scene 01_1016 with Fade(0, 0, 3)
    pause 0.5
    scene 01_1017 with dis1
    mct "Great. Still open."
    scene 01_1018 with dis1
    pause 0.5
    scene 01_1019 with dissolve
    pause 1.0
    scene 01_1020 with dissolve
    mc "Excuse me, do you own this place?"
    $ Melanie_name=""
    $ Gabby_name=""
    $ Ah1_name=""
    $ Ah2_name=""
    scene 01_1021 with dissolve
    mel "{b}FUCK!!"
    mc "Uhh, sorry. I didn't mean to startle you."
    mc "Are you the owner?"
    scene 01_1022 with dissolve
    mel "Please, can you come back tomorrow?"
    mel "I... I need more time! I don't have it!\nI'm begging you!"
    scene 01_1023 with dissolve
    gab "MEL? Are you okay??\nI heard you scream?!"
    mel "Yes, I'm fine!\nGet back in there!"
    scene 01_1024 with dissolve
    mel "{b}PLEASE GO!!"
    scene 01_1025 with dissolve
    mel "She has nothing to do with this. Please leave her alone!"
    scene 01_1026 with dissolve
    mc "Relax!"
    mc "I'm not here to... I'm not who you {i}think{/i} I am."
    scene 01_1027 with dissolve
    mel "What? Oh...\nI'm so sorry!"
    scene 01_1028 with dissolve
    mel "We're just about to close..."
    mc "Who are you expecting?"
    mel "Err... no one."
    scene 01_1029 with dissolve
    mel "[whi]Oh, no!"
    scene 01_1030 with dissolve
    mel "I'm sorry, we're closed."
    mel "You should leave."
    scene 01_1031 with dissolve
    ah1 "You heard her.\nWe're closed. Fuck off."
    scene 01_1032 with dissolve
    mc "Oh yeah. You're {i}definitely{/i} the assholes Alison described."
    ah1 "Wha'd you say, mother fucker?"
    scene 01_1033 with dissolve
    mc "You've been threatening a friend of mine. It stops now."
    ah1 "Oh, yeah? Who's your friend?"
    mc "Alison Henderson."
    scene 01_1034 with dissolve
    ah2 "That the bitch over on Parkview?"
    ah2 "The one with the sweet-ass daughter?"
    mc "Watch your fuckin' mouth, kid."
    scene 01_1035 with dissolve
    ah1 "No, tough guy... You'd better watch {i}yours{/i}!"
    ah1 "She owes a debt. She needs to pay."
    scene 01_1036 with dissolve
    mc "Her husband owes you!\nIt's got nothing to do with her."
    ah1 "Hah! You've gotta lot of balls, I'll give you that!"
    ah2 "That prick went off somewhere and died!\nWe still need payin'!"
    scene 01_1037 with dissolve
    mc "{b}One more fuckin' word..."
    scene 01_1038 with dissolve
    ah1 "... AND WHAT?\nWHAT YOU GONNA DO, BIG MAN?"
    scene 01_1039 with dissolve
    scene 01_1040 with dissolve
    play sound "hb.mp3"
    scene 01_1041 with dissolve
    scene 01_1042 with dissolve
    scene 01_1043 with dissolve
    play sound "kick01.mp3"
    scene 01_1044 with dissolve
    scene 01_1045 with dissolve
    mel "OH MY GOD! CALL THE POLICE!"
    gab "I already did! They're on the way!"
    scene 01_1046 with dissolve
    ah2 "You're fuckin' dead, Bitch!"
    scene 01_1047 with dissolve
    play sound "hit01.mp3"
    scene 01_1048 with dissolve
    scene 01_1049 with dissolve
    play sound "hit02.mp3"
    scene 01_1050 with dissolve
    scene 01_1051 with dissolve
    ah1 "You fuckin' cunt! I'm gonna kill..."
    scene 01_1052 with dissolve
    mc "Stay the hell away from Alison and her family!"
    scene 01_1053 with dissolve
    ah1 "OKAY!"
    scene 01_1054 with dis1
    scene 01_1055 with dissolve
    scene 01_1056 with dissolve
    mc "You need to understand..."
    scene 01_1057 with dissolve
    scene 01_1058 with dissolve
    play sound "stab.mp3"
    ah1 "{b}AAAAAHHHHHHH!!!!!"
    mc "... how fuckin' serious I am."
    scene 01_1059 with dissolve
    cop "HANDS ON YOUR HEAD!"
    scene 01_1060 with dissolve
    cop "DON'T YOU FUCKIN' MOVE!"
    scene 01_1061 with dissolve
    cop "Cuff him, Jim."
    call Emotion (ah1, "Moaning", "Call an ambulance!")
    scene black with Fade(5, 0, 1)
    jump Springhaven_WakeUpCell
return

label Springhaven_WakeUpCell:
    scene 02_0001 with Fade(0,0,2)
    pause
    scene 02_0002 with dissolve
    aly "Morning."
    aly "I take it you found who you were lookin' for?"
    mc "Yup."
    scene 02_0003 with dissolve
    aly "Didn't you say you {i}weren't{/i} going to cause trouble?"
    mc "I was defending myself."
    aly "I read the report."
    scene 02_0004 with dissolve
    aly "You stabbed him in the shoulder when he was already incapacitated!"
    mc "A flesh wound, heh."
    scene 02_0005 with dissolve
    aly "Jesus, [mc]!"
    aly "I'm not sure you realize how serious this is!"
    scene 02_0006 with dissolve
    mc "They won't press charges."
    mc "Guys like that never do.\nThey don't want the heat."
    aly "Yeah, you're right. They're not."
    scene 02_0007 with dissolve
    aly "I asked around as promised..."
    aly "I didn't get too far before I was completely shut down..."
    aly "This isn't just a couple of lowlife thugs we're talking about."
    scene 02_0008 with dissolve
    aly "They're a part of a gang that's into some deeply shady shit!"
    aly "I'm even starting to suspect one or two from this precinct are on their fuckin' payroll."
    aly "...and you've put yourself on their radar."
    scene 02_0009 with dissolve
    mc "Fuck 'em!"
    mc "I had no choice. Alison needed my help."
    aly "You may have put her in {i}more{/i} danger!"
    scene 02_0010 with dissolve
    mc "..."
    aly "Give me her address.\nI'll make sure to swing by the area when I'm out on patrol."
    mc "Thanks, Alysha."
    scene 02_0011 with dissolve
    aly "Come on, let's get you out of here."
    scene 02_0012 with fade2
    mc "Alison, I'm fine!"
    ali cell "I've been so worried!"
    scene 02_0013 with dissolve
    ali cell "You should've called to let me know you weren't coming home last night!"
    ali cell "I started thinking the worst!"
    scene 02_0014 with dissolve
    mc "I know, I'm sorry. I didn't mean to worry you."
    mc "I'll explain everything when I get back."
    scene 02_0015 with dissolve
    mc "I've got to go, I'll see you later."
    ali cell "Okay. Bye."
    $ James_name=""
    scene 02_0016 with dissolve
    jam "Get in."
    mc "You gonna shoot me? Outside a police station?"
    jam "Try me."
    scene 02_0017 with dissolve
    pause 1.0
    play sound "cardoor.mp3"
    scene 02_0018 with dissolve
    pause 1.0
    play sound "van.mp3"
    scene 02_0019 with dis1
    scene 02_0020 with dis1
    play sound "motor.mp3" loop
    scene 02_0021 with Fade(1, 0.5, 1)
    mc "Want to tell me where we're going?"
    scene 02_0022 with dissolve
    mc "Okay... Guess not."
    play sound "traffic.mp3"
    scene 02_0023 with dis1
    pause 0.5
    scene 02_0024 with dis1
    pause 0.5
    scene 02_0025 with dis1
    pause 0.5
    scene black with Fade(2, 1, 2)
    scene 02_0026 with fade
    pause 0.5
    scene 02_0027 with dis1
    pause 0.5
    scene 02_0028 with dis1
    pause 0.5
    scene 02_0029 with dissolve
    jam "Get out."
    mc "Really?\nWas kinda hoping we were going to a Burger King, I'm starving!"
    scene 02_0030 with dissolve
    jam "This way."
    scene 02_0031 with dissolve
    mc "That's a nice suit you're wearing!"
    scene 02_0032 with dissolve
    mc "Who's your tailor?"
    scene 02_0033 with dissolve
    jam "Don't give me a reason to ruin it with your blood."
    jump Springhaven_MeetSue
return

label Springhaven_MeetSue:
    scene 02_0034 with Fade(2, 1, 2)
    pause 0.5
    scene 02_0035 with dissolve
    jam "Come on."
    scene 02_0036 with dissolve
    ah2 "Yeah, that's him."
    scene 02_0037 with dissolve
    mc h "Where's your friend?"
    ah2 "Fuck you!"
    scene 02_0038 with dissolve
    ah2 "He's in surgery. And his name is Simon!"
    mc "Nah. His name's Asshole 1 and yours is Asshole 2."
    $ Ah1_name="Asshole 1"
    $ Ah2_name="Asshole 2"
    $ Sue_name=""
    scene 02_0039 with dissolve
    ah2 "I'M GONNA FUC..."
    scene 02_0040 with dissolve
    sue "Leave."
    scene 02_0041 with dissolve
    sue "Thank you, James."
    $ James_name="James"
    scene 02_0042 with dissolve
    sue "You assaulted two of my men. Why?"
    mc "They were threatening a friend of mine."
    sue "She refused to pay what she owed."
    scene 02_0043 with dissolve
    mc "{b}She{/b} doesn't owe you a damn thing!!\nHer {i}husband{/i} took your money, not her."
    sue "And he's... no longer with us?"
    mc "No."
    scene 02_0044 with dissolve
    sue "The debt remains.\nWhat would you have me do?"
    mc "Let it go. Write it off.\nLeave Alison and her family alone."
    scene 02_0045 with dissolve
    sue "What kind of message would that send?"
    sue "You know what happens when desperate people realize their families won't suffer for their debts?"
    sue "They take the easy way out. We'd have suicides spiking all over town."
    scene 02_0046 with dissolve
    sue "That isn't good for business."
    mc "I don't give a fuck about your business, lady!"
    scene 02_0047 with dissolve
    sue "Clearly!"
    sue "You assault my people, insult me, and expect me to cancel a valid contract out of the goodness of my heart?"
    sue "And don't call me 'lady'. My name's Sue. I'm {i}no one's{/i} lady."
    $ Sue_name="Sue"
    $ persistent.SueLocked=False
    $ Sue.Activate("Sue")
    scene 02_0048 with dissolve
    sue "I raise my left arm - James puts a bullet in your head."
    sue "Right arm - your friend dies..\nSo, how about you drop the macho act and watch your tone?"
    mc "What do you want?\nWhy did your lapdog drag me here?"
    scene 02_0049 with dissolve
    sue "Curiosity."
    sue "I wanted to know - are you brave... or just stupid?"
    sue "Turns out, a little of both."
    scene 02_0050 with dissolve
    sue "I'll forgive your... cafe incident. But your friend's debt still stands."
    mc "You {i}forgive{/i} me?"
    scene 02_0051 with dissolve
    sue "You meant well. And you didn't know what you were stepping into."
    sue "I believe you're new in town?"
    mc "Yeah."
    scene 02_0052 with dissolve
    sue "You see a couple of dirtbags hassling your friend, think it's a shakedown.\nYou jump in. Noble. Dumb."
    sue "Unfortunately, you've stumbled into something more than even you, with your background, can handle."
    mc "{i}My{/i} background?"
    scene 02_0053 with dissolve
    sue "Yes. Impressive.\nI don't impress easily."
    sue "Special forces.\nTrained in reconnaissance, counter-insurgency, sabotage, hostage rescue..."
    sue "Need me to go on?"
    scene 02_0054 with dissolve
    sue "I could use a guy like you."
    sue "You've got talent. And, conveniently, I've got a vacancy - thanks to you."
    scene 02_0055 with dissolve
    mc "You're kidding me, right?!"
    mc "Why the hell would I work for {b}you{/b}?"
    scene 02_0056 with dissolve
    sue "Because doing so clears Alison's debt - instantly."
    sue "You want to protect her? This is how you do it."
    scene 02_0057 with dissolve
    mc "Or, knowing {i}everything{/i} you do about me...you know I could just kill {i}you{/i}."
    scene 02_0058 with dissolve
    sue "[lol]"
    sue "You're still not getting it..."
    scene 02_0059 with dissolve
    sue "Killing me won't solve your problem. It'll make it worse."
    sue "My bosses would replace me before the blood dries."
    sue "Then they'll hunt you - and your friend - down."
    sue "No warnings. No deals. Just pain."
    scene 02_0060 with dissolve
    sue "You could run, but we'd find you."
    sue "We operate statewide, not just in this backwater town."
    scene 02_0061 with dissolve
    sue "I'm offering you a deal most people don't get."
    mc "I won't hurt innocent people for you."
    sue "You'll collect debts. {i}How{/i} you do it is up to you."
    scene 02_0053 with dissolve
    mc "And Alison's slate is clean? Today?"
    sue "You have my word."
    mc "How long would I have to work for you?"
    scene 02_0056 with dissolve
    sue "Three months. Then you're free."
    scene 02_0062 with dissolve
    sue "Who knows - you might even like it."
    scene 02_0063 with dissolve
    sue "Start by finishing what you interrupted at the cafe."
    sue "Take Douglas with you."
    scene 02_0064 with dissolve
    mc "Who's Douglas?"
    sue "I believe you called him {i}Asshole 2{/i}."
    mc "Not happening. If I do this, I work alone."
    sue "Fine. Your call."
    scene 02_0065 with dissolve
    sue "No backup, no leash."
    sue "Give James your cell before you leave."
    scene 02_0066 with Fade(2, 1, 1)
    mct "What the fuck have I gotten myself into?"
    mct "Better head to Alison's and tell her the good news."
    scene 02_0067 with Fade(2, 1, 1)
    mct "It's not like I had much of a choice!\nI can't protect them twenty-four hours a day!"
    scene 02_0068 with fade
    mct "I'll have to play along for now. Figure something out later."
    scene 02_0069 with fade
    mc "Hey."
    scene 02_0070 with dissolve
    ali h "Hey!\nHow was she?"
    mc "{i}She{/i}??"
    ali "You left the house early yesterday to go and meet someone..."
    scene 02_0071 with dissolve
    ali "... and then you stayed out all night!"
    ali "I'm guessing you got laid?"
    scene 02_0072 with dissolve
    mc "What?! No!"
    if Alison.isSexual():
        scene 02_0073 with dissolve
        ali "I'm not accusing you of cheating, [mc]!"
        ali "We fucked! We didn't get married!"
        scene 02_0074 with dissolve
        ali "You're a guy!\nIf you want to have sex with other women, go ahead."
        ali "Just, please! Don't bring any STIs back with you if you plan on fucking me again!"
    scene 02_0075 with dissolve
    mc "I was arrested. I spent the night in a cell!"
    scene 02_0076 with dissolve
    ali "Arrested?! Why??"
    mc "I found them - the two assholes who've been threatening you."
    scene 02_0077 with dissolve
    ali "Oh, fuck! What did you do, [mc]??"
    mc "It doesn't matter."
    mc "It's over, Alison. I've taken care of it."
    scene 02_0078 with dissolve
    mc "They agreed to wipe out your debt. You'll never see them again."
    ali "What?! Are you serious??"
    mc "Yeah."
    scene 02_0079 with dissolve
    ali "I... I... can't believe it!"
    scene 02_0080 with dissolve
    ali "But... why??\nWhy would they do that??"
    ali "[mc]! What did you do??\nWhy were you arrested?"
    scene 02_0081 with dissolve
    mc "There was a little scuffle - no big deal.\nI was released without charge."
    mc "Alison, none of that matters.\nYou can get on with your life without worrying about who's knocking on your door."
    scene 02_0082 with dissolve
    ali "It's {i}really{/i} over?"
    scene 02_0083 with dissolve
    mc "Yes."
    scene 02_0084 with dissolve
    call Emotion (ali, "Sobbing", "Oh my god!")
    scene 02_0085 with dissolve
    mc h "Ohh... I thought you'd be happy?"
    call Emotion (ali, "Sobbing and laughing")
    ali "Thank you, [mc]."
    scene 02_0086 with dissolve
    mc "You're welcome."
    scene 02_0087 with dissolve
    ali "[kiss]"
    if Alison.isSexual():
        scene 02_0089 with dissolve
        ali "[ss]Mmhhh."
    else:
        scene 02_0088 with dissolve
        pause 0.5
        if not EzModeActive:
            menu:
                "Kiss her":
                    scene 02_0089 with dissolve
                    ali "[ss]Mmhhh."
                "Don't kiss her[wk_c]":
                    call CloseCharacterPath (Alison, "Alison")
        else:
            call CloseCharacterPath (Alison)
    scene 02_0090 with dissolve
    mc "There's someone I need to go and see.\nOkay for me to jump in the shower real quick?"
    ali "Of course."
    if Alison.isActive():
        ali h "Want some company?"
        if Alison.Has("EZ"):
            mc "Absolutely."
            call AlisonReplay02
        else:
            menu:
                "[wk_y]Sure!":
                    call AlisonReplay02
                "Sorry, don't have the time.":
                    scene black with Fade(3, 1,1)
    jump Springhaven_RosieCafe02
return

label Springhaven_RosieCafe02:
    scene 02_0187 with Fade(0, 0, 3)
    mct "Didn't think I'd be coming back here so soon!"
    scene 02_0188 with dissolve
    mct "Good, it looks quiet in there."
    scene 02_0189 with dissolve
    mct "Hmmm, don't see the owner, hope she's here."
    scene 02_0190 with dissolve
    gab "I'll be right with yo..."
    scene 02_0191 with dissolve
    gab "Oh, shit! You're the guy from yesterday, right?"
    scene 02_0192 with dissolve
    mel "Yes, he is."
    scene 02_0193 with dissolve
    mel "If you've come to clean up the mess you made, you're too late."
    gab "Mel!"
    scene 02_0194 with dissolve
    gab "Ignore her!\nYou did us a favor getting rid of those guys!"
    gab h "And there wasn't a {i}lot{/i} of blood to clean up."
    if EzModeActive:
        call EzModeAsk ("Gabrielle")
        if _return:
            $ Gabby.Add("EZ")
    scene 02_0195 with dissolve
    mel "We both know they'll soon be back.\nWhat if they blame {b}us{/b} for what happened?"
    mc "Don't worry.\nThey're not coming back here."
    scene 02_0196 with dissolve
    mel "Really? And how would you know that?"
    mc "Uhh... Their boss sent {b}me{/b} to collect your payment."
    scene 02_0197 with dissolve
    mel "What?!"
    mel "You're here for the money?"
    mc "Yeah."
    scene 02_0198 with dissolve
    mel "Back room."
    gab "[whi]Okay."
    scene 02_0199 with dissolve
    mc "I'm not here to frighten you or hurt anyone."
    scene 02_0200 with dissolve
    mc "I know you've had to deal with those assholes 'till now, but {i}that{/i} isn't me."
    scene 02_0201 with dissolve
    mel "You expect me to believe that?"
    scene 02_0202 with dissolve
    call Emotion (mc, "Sigh", "No, I suppose not.")
    mc "Can we sit down and talk?"
    mel "Uhh, okay..."
    scene 02_0203 with Fade(1, 0.5, 1)
    mc "The first question I need to ask is... do you have the money?"
    scene 02_0204 with dissolve
    mel "Ummm... I... I have {i}most{/i} of it..."
    mel "I need twenty-four hours!\nPlease! Business has been slow this month!"
    scene 02_0205 with dissolve
    mc "[whi]Damn it."
    mc "Why the hell would you take money from these guys?!"
    mel "Why the hell are you {b}working{/b} for them??"
    scene 02_0206 with dissolve
    mc "I didn't have a lot of choice."
    mel "Neither did I!"
    scene 02_0207 with dissolve
    mel "My sister and I had already borrowed all we could from the bank to buy this place!"
    mel "They wouldn't give us any more."
    scene 02_0208 with dissolve
    mel "We got screwed over with the sale; more needed to be done to the place than we were led to believe."
    mel "We couldn't even open! I {b}had{/b} to get it from {i}somewhere{/i}!"
    scene 02_0209 with dissolve
    mel "Our dream turned into a goddamn nightmare."
    mel "We always wanted a little family-run cafe, so we bought this place.\nNamed it after our mom."
    mc "You're not Rosie?"
    scene 02_0210 with dissolve
    mel "No, I'm Melanie, and that was my sister, Gabrielle.\nEveryone calls her Gabby."
    $ Melanie_name="Melanie"
    $ Melanie.Activate("Melanie")
    $ persistent.MelanieLocked=False
    $ Gabby_name="Gabrielle"
    $ Gabby.Activate("Gabby")
    $ persistent.GabbyLocked=False
    scene 02_0211 with dissolve
    mc "I know the circumstances are shitty, but still, it's nice to meet you, Melanie."
    mc "I'm [mc]."
    scene 02_0212 with dissolve
    mel "Please, [mc].\nCan you give me a day?"
    mel "That's all I need, I swear!\nI'll have it for you by tomorrow."
    mc "Uhh, I dunno... Is there anyone else you can ask to help you out?"
    scene 02_0213 with dissolve
    mel "There isn't!\nDon't you think I've already tried that?!"
    scene 02_0214 with dissolve
    mel "Please, I'm begging you! I'm desperate!"
    scene 02_0215 with dissolve
    mc "Uhh...."
    mel "[whi]Fuck..."
    mel "Give me twenty-four hours... and..."
    scene 02_0216 with dissolve
    mel "... and, I'll..."
    scene 02_0217 with dissolve
    mel "...I'll... [whi]suck your dick."
    mc "You'll what?!"
    scene 02_0218 with dissolve
    mel "It... It's a fair trade. I get a day, you get a blowjob."
    mc "Is that what you did with the other guys??"
    scene 02_0219 with dissolve
    mel "{b}EWWW!! FUCK NO!"
    mel "You've seen them! They're disgusting pigs!!"
    scene 02_0220 with dissolve
    mel "You seem... different.\nA decent guy stuck in a bad situation, the same as us."
    mel "We can help each other."
    mel "So, what do you say?"
    mc "[whi]Damn..."
    if EzModeActive:
        call EzModeAsk ("Melanie")
        if _return:
            $ Melanie.Add("EZ")
    $ tCh=None
    if not EzModeActive:
        menu:
            "I'll give you a day, no blowjob necessary":
                pass
            "[wk_y]Okay, deal":
                $ tCh=True
    if tCh or Melanie.Has("EZ"):
        if Melanie.Has("EZ"):
            mc "Deal."
        $ Melanie.Add("TookBJ")
        scene 02_0224 with dissolve
        mel "Yeah?\nOkay, follow me."
        scene 02_0225 with dissolve
        mc "You ain't got a husband or boyfriend back there with a baseball bat waitin' for me, have you?"
        mel "[lol]"
        mel "I'm not married.\nThis place doesn't allow me time for a relationship!"
        call MelanieReplay01
    else:
        mc "That won't be necessary. I'll give you a day."
        $ Melanie.Score(5)
        scene 02_0221 with dissolve
        mel "Oh my god! Really?"
        mc "Yeah."
        scene 02_0222 with dissolve
        mel "I... I can't thank you enough, [mc]."
        mc "Please, make sure you have it for me tomorrow."
        mel "I will! I promise!"
        scene 02_0223 with dissolve
        mc "I'll be back in twenty-four hours."
        mel "Okay. Thank you!"
    jump Springhaven_ReturnHome
return

label Springhaven_ReturnHome:
    scene 02_0306 with Fade(3, 1, 2)
    mct "So, pick up the cash from Melanie tomorrow.\nDeliver it, then head to Cedar Grove to look for Nettie?"
    scene 02_0307 with dissolve
    mct "Maybe I could visit Millie on the way?"
    scene 02_0308 with dissolve
    mct "But how does that even work if I'm stuck here for three months?"
    scene 02_0309 with dissolve
    mct "Great. Now what?"
    scene 02_0310 with dissolve
    aly "I wanted to come by the area and keep an eye on things."
    mc "Thanks, but there's no need."
    scene 02_0311 with dissolve
    mc "The situation's been resolved."
    aly "I find that hard to believe."
    scene 02_0312 with dissolve
    aly "When has stabbing a guy in the shoulder {i}ever{/i} resolved a situation?"
    mc "I talked to their boss.\nWe... came to an understanding."
    scene 02_0313 with dissolve
    aly "Jesus, [mc]!\nWhat have you agreed to??"
    mc "It doesn't matter."
    aly "Of course it matters!"
    scene 02_0314 with dissolve
    aly "I don't wanna have to arrest you!"
    aly "...Or worse still, find you dead in some back alley!"
    aly "You came to {b}me{/b} for help!\nThe least you can do is be honest with me!"
    scene 02_0315 with dissolve
    mc "Okay, I guess you have a point..."
    mc "I've agreed to work for them for a while.\nIt was the only option I had."
    scene 02_0316 with dissolve
    aly "You're working for them?!"
    aly "Are you {b}fuckin' crazy{/b}?!"
    scene 02_0317 with dissolve
    mc "It's only temporary!"
    mc "And, I think you were right... About having cops in her pocket."
    mc "She knew {i}everything{/i} about my background.\nEven though most of that shit is classified."
    mc "No way she could access it without help."
    scene 02_0318 with dissolve
    aly "Can't say I'm surprised."
    aly "I only joined this precinct six months ago, but I know something's going on."
    scene 02_0319 with dissolve
    aly "Too much whispering in corners, the looks some of the guys give each other when certain names crop up."
    aly "I fuckin' hate dirty cops!"
    scene 02_0320 with dissolve
    aly "I hope you know what you're doing, [mc]."
    aly "... And if you happen to see any officers helping them, maybe let me know."
    mc "You wanna go after your crooked colleagues?\nDidn't you just call {i}me{/i} crazy?"
    scene 02_0321 with dissolve
    aly "Someone should!"
    aly "I can't look the other way and let them get away with it.\nWhat would that make me?"
    mc "If these people are as bad as you suggest..."
    aly "Then, help me!"
    scene 02_0322 with dissolve
    mc "Whoa! Hold on!"
    aly "With you on the inside, it gives us a {b}real{/b} chance!"
    mc "You {b}are{/b} crazy!"
    aly "How many other people are afraid, suffering, just like your friend?"
    scene 02_0323 with dissolve
    mc "I don't care!\nIt's too dangerous - for us {b}both{/b}!"
    aly "We have an opportunity to take these motherfuckers down, {b}that's{/b} your way out!"
    mc "You don't know how big this organization is! It's not just in this town; it's statewide!"
    aly "Bullshit! No way!"
    scene 02_0324 with dissolve
    aly "Is that what they told you??\nThey're tryin' to impress you, or frighten you!"
    aly "I'm going after them. With or without your help."
    aly "If I find you involved in any criminal activity, I won't hesitate to arrest you."
    scene 02_0325 with dissolve
    mc "I'm not gonna break the law for them.\nAll I have to do is pick up cash. In three months, I'm done."
    aly "You honestly believe they'll let you walk away??"
    mc "Yeah. That's the deal."
    scene 02_0326 with dissolve
    aly "Wow!"
    aly "I thought you were a smart guy... Guess I was wrong."
    scene 02_0327 with dissolve
    aly "Take care of yourself, [mc]."
    mc "Yeah, you too."
    play sound "car.mp3"
    scene 02_0328 with dis1
    scene 02_0329 with dis1
    pause 0.5
    scene 02_0330 with Fade(1, 0.5, 1)
    mct "She's out of her damn mind if she thinks I'm gonna be her mole!"
    mct "I'd be signing my own death warrant!"
    scene 02_0331 with Fade(1, 0.5, 1)
    pause 0.5
    scene 02_0332 with dissolve
    mc "Oh, hey.\nWhere are Cara and Alison?"
    alex "Alison isn't back from work yet.\nCara's upstairs, getting changed."
    scene 02_0333 with dissolve
    alex "I don't think you've met our friend, Nicole?"
    mc "Uh, no.\nHi, nice to meet you."
    alex "Nic, this is {i}Uncle{/i} [mc]!"
    nic "Hello."
    scene 02_0334 with dissolve
    alex "Maybe {b}you{/b} know?"
    mc "Know what?"
    alex "What's got into Cara?\nShe's {b}insisting{/b} we play pool again!"
    scene 02_0335 with dissolve
    mc h "Probably just an excuse to go to the bar and have a drink with her friends!"
    alex "Nope, that's not it!"
    alex "We can't even go to the bar!\nThey have an open-mic, so it's gonna be jammed, and they move the table out of the way."
    scene 02_0336 with dissolve
    nic "We're going to my house to play."
    nic "My dad built a man-cave in our basement, complete with a pool table!"
    mc h "Oh, nice!"
    scene 02_0337 with dissolve
    alex "I've always had to drag Cara to the table to play."
    alex "She's {i}never{/i} suggested we play... until today!"
    scene 02_0338 with dissolve
    alex "So, what's changed?!"
    mc h "I have no idea!"
    scene 02_0339 with dissolve
    car "Uncle [mc]!\nI didn't know you were home!"
    mc "Just got back."
    car "We're gonna play some pool!"
    mc h "Yeah, Alex was telling me."
    scene 02_0340 with dissolve
    car "You should come with us!"
    mc "What? Nah, you guys go and have fun.\nI think I'll chill here for a while. Heh."
    car "Awww... No!\nPlease come! I need a witness, to prove I beat her ass!"
    alex h "You're {b}not{/b} gonna beat me!"
    scene 02_0341 with dissolve
    if Alex.isActive():
        alex "But, yeah! You should come with us!"
    else:
        alex "You can come if you want to watch her lose."
    mc "I'm sure Nicole's dad doesn't want a stranger in his man-cave!"
    scene 02_0342 with dissolve
    nic h "Oh, it's not {i}his{/i} man-cave anymore!"
    nic "My parents divorced years ago.\nIt's {b}my{/b} man-cave now! And you're very welcome to join us."
    $ persistent.NicoleLocked=False
    $ Nicole.Activate("Nicole")
    if EzModeActive:
        call EzModeAsk ("Nicole")
        if _return:
            $ Nicole.Add("EZ")
    scene 02_0343 with dissolve
    car "Come on! Pleeeeasseee, Uncle [mc]!"
    if Alex.isActive():
        scene 02_0344 with dissolve
        alex "Yeah! Pleeeeasseee, {i}Uncle{/i} [mc]! [lol]"
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Okay, I'll come with you":
                $ tCh=True
            "No thanks, girls. But you have fun.":
                pass
    if tCh or Nicole.Has("EZ") or Cara.Has("EZ") or Alex.Has("EZ"):
        $ Cara.Score(1)
        $ Alex.Score(1)
        $ Cara.Add("WatchPl")
        scene 02_0345 with dissolve
        mc "Let's go kick her butt!"
        alex h "Not gonna happen!"
        call Springhaven_PoolMatch
        scene 02_0347 with Fade(2,1,2)
    else:
        mc "No. I'm too tired. But you girls have fun."
        $ Cara.Score(-1)
        scene 02_0346 with dissolve
        mc "Good luck!"
        alex h "He doesn't want to watch you lose!"
        car h "Shut up!"
        scene 02_0347 with fade
    mct "Finally, a little peace and quiet!"
    scene 02_0526 with Fade(2, 3, 3)
    mc "[whi]..Zzzz.."
    scene 02_0527 with dis1
    pause 1.0
    scene 02_0528 with dis1
    pause 1.0
    scene 02_0529 with dis1
    pause 0.5
    scene 02_0530 with dissolve
    pause 0.5
    scene 02_0531 with dissolve
    call Emotion (mc, "Groan")
    ali "Good morning."
    scene 02_0532 with dissolve
    mc "Huh? ...Morning??"
    ali "I tried to wake you last night, but you wouldn't wake up."
    scene 02_0533 with dissolve
    ali "So, I threw a blanket over you."
    mc "Damn...\nSorry, I must've nodded off."
    ali "I'm leaving for work. I made you coffee."
    mc "Thanks."
    scene 02_0534 with dissolve
    mc "Where {i}do{/i} you work? I just realized I don't even know."
    ali "At the hospital, records department. Mainly admin work. It's only part-time."
    ali "It sounds boring as hell, but I enjoy it!"
    scene 02_0535 with dissolve
    mc "I wanted to ask, err...\nIs it okay if I stick around for a while longer?"
    ali "Of course.\nIt's nice having you around, and I know Cara loves you being here."
    scene 02_0536 with dissolve
    ali "But... didn't you want to find Nettie?"
    mc "Yeah, I do. I will."
    ali "Okay."
    scene 02_0537 with dissolve
    ali "I'd better go, see you later!"
    mc "Bye."
    scene 02_0538 with dissolve
    mct "Glad she didn't ask {b}why{/b} I needed to stay longer!"
    mct "Okay... Shower... Breakfast... then, back to the cafe."
    jump Springhaven_PickUpComplete
return

label Springhaven_PickUpComplete:
    scene 02_0539 with Fade(2, 1, 2)
    pause 1.0
    scene 02_0540 with dissolve
    mc "Hi, Melanie."
    mel "Oh, [mc]. You're here."
    mc "Please tell me you have it."
    scene 02_0541 with dissolve
    mel "Yes, as promised!"
    scene 02_0542 with dissolve
    mel "I have it all for you."
    mc "Great."
    scene 02_0543 with dissolve
    mc "Can I ask you something? How much did you borrow?"
    mel "Umm... Fifteen thousand."
    scene 02_0544 with dissolve
    mc "And how much have you paid back?"
    mel "Oh... I'd have to check my records, but about half, I think."
    scene 02_0545 with dissolve
    mel "They keep adding interest, so the balance doesn't go down a lot."
    mel "The lady who offered me the loan was very charming, and everything was great."
    scene 02_0546 with dissolve
    mel "But those thugs, or guys just like them, started showing up, insisting I need to pay more and more."
    mel "The monthly payments we'd agreed on suddenly weren't enough; they just about covered the interest."
    scene 02_0547 with dissolve
    mel "Now, we're paying over double every month, and it's {b}still{/b} not enough for them!"
    show screen WlkGuide(wkg003)
    menu:
        "That sucks":
            hide screen WlkGuide
            mc "Once they have you, they'll never want to let you go."
        "[wk_y]I want to help you":
            hide screen WlkGuide
            $ Melanie.Score(3)
            $ helpedMel=True
            mc "I can't make any promises, but I'll see what I can do to help reduce your payments."
            scene 02_0548 with dissolve
            mel "Really?? You will??!\nI... I never expected you to say that!"
            mel "Thank you!"
    scene 02_0549 with dissolve
    mc "See you soon, Melanie."
    mel "Bye."
    scene 02_0550 with Fade(2, 1, 2)
    mct "Where the fuck is the place??"
    scene 02_0551 with dissolve
    mct "This {b}is{/b} the location James sent me... right?"
    scene 02_0552 with dissolve
    mct "I hate cellphones!"
    scene 02_0553 with dissolve
    mct "401..."
    scene 02_0554 with dissolve
    mct "Finally!"
    scene 02_0555 with dissolve
    pause 1.0
    scene 02_0556 with Fade(2, 1, 1)
    jam "Sit down, she'll be right in."
    mc "Why, thank you, good sir!"
    jam "I can't wait till I get to shoot you."
    scene 02_0557 with dissolve
    mct "Fancy place."
    if persistent.UseFocus:
        $ _skipping = False
        show screen imgMap("images/e02/02_0558.webp", 1205, 396, True, "Springhaven_AF16") with dissolve
        mct "Business must be booming."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 02_0558
            hide screen imgMap
    else:
        scene 02_0558 with dissolve
        mct "Business must be booming."
        call Springhaven_AF16
    scene 02_0563 with Fade(1, 0.5, 0.5)
    sue "Sorry for keeping you."
    scene 02_0564 with dissolve
    mc "No problem."
    sue "It's nice to see you again, [mc]."
    scene 02_0565 with dissolve
    sue "James said you wanted to speak with me?"
    mc "Yeah."
    scene 02_0566 with dissolve
    sue "I'm listening."
    mc "I need to leave town for a few days."
    sue "You've only just started to work for me, and you're asking for time off?"
    mc "Yeah, sorry."
    sue "What's so important?"
    scene 02_0567 with dissolve
    mc "It's a personal matter, and... complicated."
    sue "Maybe I can help?"
    mc "No thanks."
    scene 02_0568 with dissolve
    sue "You're concerned I'll ask for something in return?"
    mc "Something like that."
    scene 02_0569 with dissolve
    sue "Can you at least tell me where you're going?"
    mc "Why?"
    sue "I have contracts that need fulfilling all over the state."
    scene 02_0570 with dissolve
    sue "Maybe we {b}can{/b} help each other."
    sue "You get to go... wherever you need to go, and still do the job while you're there."
    mc "Uhh, I guess.\nI'm going to Cedar Grove."
    scene 02_0571 with dissolve
    sue "See. Now that wasn't too difficult, was it?"
    sue "James will send you the details of our jobs in Cedar Grove."
    scene 02_0572 with dissolve
    sue "[mc], come and see me when you return.\nThere's something else I want to discuss with you, in private."
    mc "Okay."
    scene 02_0573 with dissolve
    mc "Thanks."
    if helpedMel:
        scene 02_0574 with dissolve
        mc "Oh... There was one more thing..."
        scene 02_0575 with dissolve
        mc "The cafe owner..."
        mc "She's struggling to keep up with her payments."
        scene 02_0576 with dissolve
        sue "That's not our problem."
        mc "Can't you cut her some slack?\nShe's paying {b}double{/b} what was initially agreed!"
        sue "Careful, [mc]."
        scene 02_0577 with dissolve
        sue "Don't mistake my charity for weakness."
        sue "We came to an arrangement because you could prove useful to me."
        sue "Don't interfere with the business."
        scene 02_0578 with dissolve
        sue "I liked Melanie and her sister, Gabrielle."
        sue "But she {b}agreed{/b} to the loan."
        sue "And her payments {b}haven't{/b} doubled. She's playing you for a fool!"
        scene 02_0579 with dissolve
        mc "{b}You're{/b} the one she dealt with at the beginning?"
        sue "Yes."
        sue "Now, leave. You're becoming tiresome."
    scene 02_0580 with Fade(2, 1, 2)
    mct "Hopefully, there's a bus out of town today."
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e02/02_0581.webp", 960, 410, True, "Springhaven_AF17") with dissolve
            mct "Heh, don't think she heard me come in."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 02_0581
                hide screen imgMap
        else:
            scene 02_0581 with dissolve
            mct "Heh, don't think she heard me come in."
            if not EzModeActive:
                menu:
                    "[wk_y]Check her out":
                        call Springhaven_AF17
                    "Don't":
                        pass
            elif Cara.Has("EZ"):
                call Springhaven_AF17
        $ tCh=None
        if not EzModeActive:
            menu:
                "Sneak up and scare her":
                    pass
                "[wk_y]Sneak up and grab her ass":
                    $ tCh=True
        if tCh or Cara.Has("EZ"):
            scene 02_0583 with dissolve
            pause 0.5
            scene 02_0584 with dis1
            pause 0.5
            scene 02_0589 with dissolve
            pause 0.5
            scene 02_0590 with dissolve
            pause 1.0
            if not Cara.hasScore(4):
                scene 02_0591 with dissolve
                call Emotion (car, "GASP")
                scene 02_0586 with dissolve
                car "What the hell?!"
                mc "[lol]"
                scene 02_0587 with dissolve
                car "Oh my god! {b}You perv!{/b}\nYou scared the shit outta me!"
                scene 02_0588 with dissolve
                mc "I'm sorry, Pipsqueak!\nI couldn't resist!"
                car "I could've stabbed you!!"
            else:
                scene 02_0592 with dissolve
                car "What are you doing?"
                mc "Sorry, it was begging to be grabbed!"
                if Cara.Has("BoobPlay"):
                    scene 02_0593 with dissolve
                    car "You're such a perv."
                    mc "Nah.\nIf I {i}were{/i} a perv..."
                    mc "I'd do this..."
                    scene 02_0594 with dis1
                    car "[whi]Mmmhhh.... I guess lucky for me, you're not, then."
                    scene 02_0595 with dissolve
                    car "[ss]Mmhh.."
                    scene 02_0596 with dissolve
                    car "[ss]..Mmh...That feels nice..."
                    scene 02_0597 with dis1
                    mc "[kiss]"
                    scene 02_0598 with dis1
                    car "[kiss]"
                    scene 02_0599 with dis1
                    car "[ss]Mmmhhhh.."
                    scene 02_0600 with dis1
                    pause 1.0
                    scene 02_0601 with dis1
                    pause 0.5
                    scene 02_0602 with dissolve
                    car "[whi]You don't give up, do you?"
                    mc "[whi]Do you want me to?"
                    scene 02_0603 with dissolve
                    mc "[kiss]"
                    scene 02_0604 with dissolve
                    pause 0.5
        else:
            $ Cara.Score(1)
            scene 02_0583 with dissolve
            pause 0.5
            scene 02_0584 with dis1
            pause 0.5
            scene 02_0585 with dissolve
            call Emotion (mc, "ROAR")
            car "{size=*2.0}{b}AAAAAAAHHHHHHHH!!!!"
            scene 02_0586 with dissolve
            car "Holy shit! You asshole!!"
            mc "[lol]"
            scene 02_0587 with dissolve
            car "I almost wet myself![lol]"
            scene 02_0588 with dissolve
            mc "I'm sorry, Pipsqueak!\nI couldn't resist![lol]"
            car "I could've stabbed you!!"
    else:
        scene 02_0581 with dissolve
        mct "Heh, don't think she heard me come in."
        scene 02_0583 with dissolve
        pause 0.5
        scene 02_0584 with dis1
        pause 0.5
        scene 02_0585 with dissolve
        call Emotion (mc, "ROAR")
        car "{size=*2.0}{b}AAAAAAAHHHHHHHH!!!!"
        scene 02_0586 with dissolve
        car "Holy shit! You asshole!!"
        mc "[lol]"
        scene 02_0587 with dissolve
        car "I almost wet myself![lol]"
        scene 02_0588 with dissolve
        mc "I'm sorry, Pipsqueak!\nI couldn't resist![lol]"
        car "I could've stabbed you!!"
    scene 02_0605 with dissolve
    mc "I'm heading outta town for a couple of days.\nCan you let your mom know?"
    car "Where you going? You {b}are{/b} coming back, right??"
    mc "Don't worry..."
    scene 02_0606 with dissolve
    call Emotion (mc, "Arnold Schwarzenegger voice", "I'll be back.")
    scene 02_0607 with dissolve
    car "[lol] You're such a dick!"
    if not Cara.Has("WatchPl"):
        scene 02_0608 with dissolve
        car "Oh, I won, by the way!"
        car "The pool game, against Alex!"
        mc "I never doubted you, Pipsqueak!"
        mc "Good job!"
    scene 02_0609 with Fade(2, 1, 2)
    pause 1.0
    scene 02_0610 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0611 with fade
    bus "Where to?"
    $ cedargrove_open=True
    $ oakhill_open=True
    jump Springhaven_Leave
return

label Springhaven_Leave:
    scene black with fade1
    $ springhaven_open=False
    $ springhaven_ch+=1
    jump ShowMap
return

label Springhaven_PoolMatch:
    scene 02_0348 with Fade(2, 1, 2)
    alex "What aren't you telling me?"
    alex h "You've {i}never{/i} been this confident of beating me before!"
    scene 02_0349 with dissolve
    mc "Wow! This place is great, Nicole!"
    scene 02_0350 with dissolve
    nic "Thanks! It's my favorite place to hang!"
    mc "You don't go to the bar?"
    nic h "Not since I got busted with my fake ID!"
    scene 02_0351 with dissolve
    alex "We need to get you another one."
    nic "I hate that dump anyway!"
    scene 02_0352 with dissolve
    alex h "Ready for another whoopin'?"
    car "You're {i}so{/i} gonna lose!"
    mc h "[whi]Wow... Are they {i}always{/i} like this?"
    scene 02_0353 with dissolve
    nic "No!"
    nic "I've never seen Cara so confident about winning!"
    scene 02_0354 with dissolve
    car "Ready to watch me beat her ass, Uncle [mc]?"
    mc "Yup!"
    if Alex.isActive():
        scene 02_0355 with dissolve
        alex "I bet he's already thought about {i}beating{/i} my ass! Huh, {i}Uncle{/i} [mc]?"
        scene 02_0356 with dissolve
        alex "When you're alone in bed, have you ever thought about beating my ass?"
        if not EzModeActive:
            menu:
                "Nope":
                    $ Alex.Score(-1)
                    alex "[lol]"
                "[wk_y]Once or twice":
                    $ Alex.Score(1)
                    alex "Yeah, I knew it!"
        else:
            if Alex.Has("EZ"):
                mc "One or twice."
                $ Alex.Score(1)
                alex "Yeah, I knew it!"
            else:
                mc "Nope."
                $ Alex.Score(-1)
                alex "[lol]"
        scene 02_0357 with fade
        pause 1.0
        scene 02_0358 with dissolve
        pause
        scene 02_0359 with dissolve
        car "[whi]Stop perving!"
        scene 02_0360 with dissolve
        alex "Aww, Cara! Leave him be!\nIf he wants to look..."
        scene 02_0361 with dissolve
        alex "... Let him!"
        car h "Oh, my god.\nI don't know who's worse! Him or you!"
        car "Get on with it!"
    else:
        scene 02_0357 with fade
        pause 1.0
    scene 02_0362 with dissolve
    mc "[whi]Don't forget to get your grip right, it's the most important thing to remember!"
    car "Don't worry! I got this!"
    scene 02_0363 with dissolve
    alex "Whoa! Wait a minute!"
    alex "Has [mc] been giving you tips on how to beat me?!"
    car h "No!"
    if Cara.Has("ShowsBoobs") or Cara.Has("BoobPlay"):
        scene 02_0364 with dissolve
        alex "{b}That's{/b} why you showed him your boobs!! Isn't it?!"
        scene 02_0365 with dissolve
        mc "You, err... told her about that?"
        alex "We're all best friends!\nWe tell each other everything!"
        if Alex.Has("Flash"):
            scene 02_0366 with dissolve
            car "You showed him yours, too!"
            nic "You didn't tell me you showed him your boobs!?"
            scene 02_0367 with dissolve
            alex "I was drunk!"
            car h "{b}No you weren't!{/b}\nWe shared {b}one{/b} beer!"
            scene 02_0368 with dissolve
            alex "[lol]"
    scene 02_0369 with dissolve
    alex "Okay! {b}Game on{/b}!"
    scene 02_0370 with dissolve
    alex "What do I get when I win?"
    car h "Huh?"
    scene 02_0371 with dissolve
    alex "If we're having a real competition, there should be a prize for the winner!"
    car "Hmmm.... I don't know.\nWhat would you like to give me when {b}I{/b} win?"
    scene 02_0372 with dissolve
    alex h "You mean, when {b}I{/b} win, what would {i}you{/i} like to give me?"
    scene 02_0373 with dissolve
    nic "You could go old-school!"
    nic "The winner gives the loser a dare that they {b}have{/b} to complete!"
    car h "Oh, jeez! We're not kids anymore!"
    alex h "Oooh! I like that idea!"
    car "[lol]\nOkay, fine!"
    scene 02_0374 with dissolve
    car "[whi]I hope you're right about me beating her!\nI dread to think what she has planned if I don't!"
    mc h "[whi]You're ready."
    scene 02_0375 with dissolve
    play sound "ballhit.mp3"
    scene 02_0376 with dissolve
    mc "[whi]And what do {i}you{/i} have planned for her?"
    scene 02_0377 with dissolve
    car "[whi]Not saying... but, I think you'll like it!"
    alex "Your turn, hotshot."
    scene 02_0378 with fade
    if persistent.Incest and Alex.isActive():
        alex "Do you stare at {i}my{/i} ass like that, too?"
        if not EzModeActive:
            menu:
                "Don't know what you're talking about":
                    alex "Whatever! [lol]"
                "[wk_y]Yeah, I do!":
                    $ Alex.Score(1)
        else:
            if Alex.Has("EZ"):
                mc "Yeah, I do!"
                $ Alex.Score(1)
            else:
                mc "Don't know what you're talking about"
                alex "Whatever! [lol]"
    else:
        if not Cara.isActive() or not Cara.Has("B1"):
            alex "How much did you teach her?"
            mc "Enough... Hopefully! Heh."
        else:
            alex h "You're always staring at her ass!"
    play sound "ballhit.mp3"
    scene 02_0379 with dissolve
    play sound "ballin.mp3"
    alex "Wow! Nice shot!"
    scene 02_0380 with dissolve
    alex h "You {b}have{/b} been practicing!"
    scene 02_0381 with dissolve
    mc "[whi]Who's your money on?"
    nic "It {i}was{/i} Alex..."
    play sound "ballhit.mp3"
    scene 02_0382 with dissolve
    scene 02_0383 with dissolve
    play sound "ballin.mp3"
    scene 02_0384 with dissolve
    nic "But now..."
    scene 02_0385 with dissolve
    nic "... I'm not so sure!"
    scene 02_0386 with dissolve
    play sound "ballhit.mp3"
    scene 02_0387 with dissolve
    play sound "ballhit.mp3"
    scene 02_0388 with dissolve
    pause 0.5
    scene 02_0389 with fade
    mc "Mind if I sit down for a while?\nCall me when you have a couple of balls left."
    car h "We're not that bad!"
    nic "It's okay, I'll keep him company."
    scene 02_0390 with Fade(1, 0.5, 0.5)
    mc "How long have you and Cara been friends?"
    nic "Gosh!\nWhen did she move here? Must be about ten years ago, now?"
    mc "Long time, then."
    scene 02_0391 with dissolve
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e02/02_0391.webp", 1004, 438, False, "Springhaven_AF15") with dissolve
        nic "Yeah.\nAlex and I both grew up on this street and we've been besties for as long as I can remember!"
        $ _skipping = True
    else:
        scene 02_0391 with dissolve
        nic "Yeah.\nAlex and I both grew up on this street and we've been besties for as long as I can remember!"
        if not EzModeActive:
            menu:
                "Check her out":
                    call Springhaven_AF15
                "[wk_y]Don't":
                    pass
    if Nicole.hasScore(0):
        scene 02_0391
        hide screen imgMap
        nic "Once Cara moved into the neighborhood, we soon became a threesome!"
    else:
        scene 02_0393
        nic "Please don't look at me like that."
        mc "[whi]Err, sorry."
    scene 02_0394 with dissolve
    mc "I'm glad she has good friends like you and Alex."
    mc "I'm sure it helped having you guys around when her dad died."
    nic "Yeah. It was a difficult time for her.\nShe felt guilty all the time."
    scene 02_0395 with dissolve
    mc "Guilty?? Why??"
    nic "She thought she should've been more upset about it than she was."
    nic "But they'd never gotten on well together, and he was always out of town.\nShe barely knew him, really."
    scene 02_0396 with dissolve
    nic "Whenever her mom would say he's coming home for a few days..."
    nic "The first question she'd {b}always{/b} ask was '{i}Is Uncle [mc] coming, too?{/i}'"
    nic "I shouldn't say, but I always thought she loved {b}you{/b} more than she did her dad."
    scene 02_0397 with dissolve
    mc "Jeez. I didn't know things were so bad between them."
    nic "Don't tell her I said anything!"
    mc "No, of course."
    scene 02_0398 with Fade(1, 2, 1)
    nic "[lol]"
    mc "What else could I have done?! [lol]"
    scene 02_0399 with dissolve
    car h "Come on, guys.\nYou're about to witness history!"
    scene 02_0400 with fade
    pause 0.5
    play sound "ballhit.mp3"
    scene 02_0401 with dissolve
    play sound "ballin.mp3"
    scene 02_0402 with dissolve
    pause 0.5
    scene 02_0403 with dissolve
    car "You're goin' down!"
    alex h "It's not over, yet!"
    scene 02_0404 with fade
    pause 0.5
    play sound "ballhit.mp3"
    scene 02_0405 with dissolve
    play sound "ballin.mp3"
    scene 02_0406 with dissolve
    pause 0.5
    scene 02_0407 with dissolve
    car "{b}{size=*1.5}YES!!! {w=0.5}{nw}"
    scene 02_0408 with dissolve
    car "I BEAT YOU!!!"
    scene 02_0409 with dissolve
    alex "[lol]"
    alex "It's best out of three!!"
    car h "That wasn't the deal!"
    alex h "Best out of three!!"
    scene 02_0410 with dissolve
    car "You have to do your dare!"
    alex "Oh my god! Fine!!\nBut then it's best out of three!"
    scene 02_0411 with dissolve
    alex "What's the dare?"
    scene 02_0416 with dissolve
    car "You have to kiss Uncle [mc]!"
    scene 02_0417 with dissolve
    car "A {b}full{/b} kiss - with tongue!"
    scene 02_0418 with dissolve
    alex "OH! I thought it was gonna be a {i}punishment{/i}!"
    alex "If I'd known {i}that{/i} was the dare, I would've {b}let{/b} you win!"
    scene 02_0419 with dissolve
    car "No you wouldn't!"
    alex h "No, you're right... I wouldn't!"
    scene 02_0420 with dissolve
    mc "Why am I getting dragged into this?"
    scene 02_0421 with dissolve
    if not Alex.isActive():
        alex "[whi]Don't worry, I know you're not into me..."
        scene 02_0422 with dissolve
        alex "[whi]Just play along..."
        scene 02_0425 with dissolve
        alex h "[whi]They'll never know."
        scene 02_0425_01 with dissolve
        alex "[ss]Mmmhhh."
        scene 02_0425_02 with dissolve
        alex "[ss]..Mmhh.."
        scene 02_0431 with dissolve
        alex h "[whi]Shame. That would've been fun!"
    else:
        alex "Sorry, {i}Uncle{/i} [mc], but it's a dare..."
        scene 02_0422 with dissolve
        alex h "What choice do I have?"
        scene 02_0423 with dissolve
        alex "[kiss]"
        scene 02_0424 with dissolve
        alex "[kiss]"
        scene 02_0425 with dissolve
        pause 0.5
        scene 02_0424 with dissolve
        alex "[kiss]"
        scene 02_0426 with dis1
        pause 1.5
        scene 02_0427 with dis1
        alex "[ss]Mmmhhh."
        scene 02_0428 with dissolve
        car "More passion!"
        car h "Grab her ass, Uncle [mc]![giggles]"
        scene 02_0429 with dissolve
        car "That's more like it!"
        scene 02_0430 with dissolve
        car "[whi]Damn! She's really going for it!"
        nic "[lol]"
        scene 02_0431 with dissolve
        alex "[whi]Wow! You're a good kisser!"
        alex "[whi]Now I'm wondering what else you might be good at."
    scene 02_0432 with dissolve
    call Emotion (alex, "Phew", "Is it warm in here, or is it just me?")
    alex "Let's go! Round two!"
    scene 02_0433 with Fade(1, 0.5, 1)
    nic "You're a good sport, letting her kiss you like that."
    if not EzModeActive:
        menu:
            "I imagined it was you the whole time":
                $ Nicole.Score(-1)
                play sound "ballhit.mp3"
                scene 02_0434 with dissolve
                nic "[whi]Oh."
            "[wk_y]It's just a bit of fun, right?":
                $ Nicole.Score(1)
                play sound "ballhit.mp3"
                scene 02_0434 with dissolve
                nic h "Yeah!"
    else:
        if Nicole.Has("EZ"):
            $ Nicole.Score(1)
        mc "It's just a bit of fun, right?"
        play sound "ballhit.mp3"
        scene 02_0434 with dissolve
        nic h "Yeah!"
    call CenterText ("A little while later...")
    play sound "ballhit.mp3"
    scene 02_0435 with dissolve
    scene 02_0436 with dissolve
    play sound "ballin.mp3"
    scene 02_0437 with dissolve
    pause 0.5
    scene 02_0438 with dissolve
    alex "Yes! One-all!"
    alex h "Oooooh! Last game, winner takes all!"
    scene 02_0439 with dissolve
    car "Yeah, yeah. Rack 'em up."
    alex "Not so fast!"
    scene 02_0440 with dissolve
    alex "It's {b}your{/b} turn to do a dare!"
    scene 02_0441 with dissolve
    car "Oh, jeez! Okay..."
    car "You're gonna make me do something stupid, aren't you?"
    scene 02_0442 with dissolve
    alex "{b}You{/b} have to kiss {i}Uncle{/i} [mc]!"
    alex h "A full kiss - with tongue!"
    scene 02_0443 with dissolve
    car "Alex!"
    car h "I {b}knew{/b} you were gonna do that!"
    scene 02_0444 with dissolve
    alex h "Cara, I'm only teasing! You don't have to!"
    scene 02_0445 with dissolve
    pause 0.5
    scene 02_0446 with dissolve
    car "Sorry, Uncle [mc]. We need to kiss."
    if persistent.Incest:
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Kiss her":
                    $ tCh=True
                "Refuse the kiss[wk_c]":
                    pass
        if tCh or Cara.Has("EZ"):
            scene 02_0447 with dissolve
            car "[kiss]"
            scene 02_0448 with dissolve
            pause 1.0
            scene 02_0449 with dissolve
            car "[ss]Mmmhhhh."
            scene 02_0450 with dissolve
            alex h "Wow!\nI get the feeling she {i}wanted{/i} me to give her that dare!"
            scene 02_0451 with dissolve
            alex "More passion!"
            nic "Grab her ass, {i}Uncle{/i} [mc]![lol]"
            scene 02_0452 with dissolve
            car "[ss]..Mmmhhhh.."
            if Cara.Has("BoobPlay"):
                $ Cara.Add("Kiss")
                scene 02_0453 with dissolve
                car "[whi]The joke's on her.\nShe doesn't know how much I love kissing you."
                car "[whi]Now, I get to do it in front of my best friends."
                car "[whi]So, yeah... {i}Grab my ass, Uncle [mc]{i}."
                scene 02_0454 with dissolve
                car "[ss]..Mmhhhh.."
                scene 02_0455 with dissolve
                alex "Holy shit!\nWould you like us to leave?"
                scene 02_0456 with dissolve
                car "[ss]..Mmmmhhhh.."
                scene 02_0457 with dissolve
                alex "Okay, knock it off!\nYou're making us horny over here!"
                $ Nicole.Score(1)
                $ Alex.Score(1)
            scene 02_0458 with dissolve
            car h "Dare complete."
            scene 02_0459 with Fade(1, 0.5, 1)
            if Nicole.hasScore(1):
                nic h "That was quite... something!"
            else:
                pause 1.0
        else:
            call CloseCharacterPath (Cara)
            scene 02_0446_01 with dissolve
            mc "Pipsqueak, I love you, but there's no way I'm gonna kiss you like that!"
            car "I know."
            scene 02_0446_02 with dissolve
            car "But {i}I{/i} was willing, so {b}DARE COMPLETE{/b}!"
            alex h "Bah! Technicality! Not Fair!"
            scene 02_0459 with Fade(1, 0.5, 1)
            pause 1.0
    else:
        scene 02_0446_01 with dissolve
        mc "Pipsqueak, I love you, but there's no way I'm gonna kiss you like that!"
        car h "I know."
        scene 02_0446_02 with dissolve
        car "But {i}I{/i} was willing, so {b}DARE COMPLETE{/b}!"
        alex h "Bah! Technicality! Not Fair!"
        scene 02_0459 with Fade(1, 0.5, 1)
        pause 1.0
    play sound "ballhit.mp3"
    scene 02_0460 with Fade(1, 3, 2)
    alex "Game over, Cara!"
    car "Not till it goes in!"
    play sound "ballhit.mp3"
    scene 02_0461 with dissolve
    play sound "ballhit.mp3"
    scene 02_0462 with dissolve
    scene 02_0463 with dissolve
    alex "Fuck!"
    scene 02_0464 with fade
    pause 0.5
    play sound "ballhit.mp3"
    scene 02_0465 with dissolve
    play sound "ballin.mp3"
    scene 02_0466 with dissolve
    pause 0.5
    scene 02_0467 with dissolve
    pause 0.5
    scene 02_0468 with dissolve
    pause 0.5
    play sound "ballhit.mp3"
    scene 02_0469 with dissolve
    play sound "ballin.mp3"
    scene 02_0470 with dissolve
    pause 0.5
    scene 02_0471 with dissolve
    car "WINNER!"
    scene 02_0472 with dissolve
    call Emotion (mc, "Clapping", "Well done, Pipsqueak!")
    scene 02_0473 with dissolve
    alex "Yeah, well done!\nYou beat me, fair and square."
    alex h "... Well, with a {i}little{/i} bit of help."
    scene 02_0474 with dissolve
    nic "What's the dare?"
    car "She's right, Uncle [mc] did help, so... He should be rewarded!"
    scene 02_0475 with dissolve
    alex "Okay, I'm listening."
    if Nicole.hasScore(2):
        scene 02_0476 with dissolve
        nic "Oohh! Dare her to give him a blowjob!"
        car h "Nic! Oh my god!"
        scene 02_0475 with dissolve
    if not Alex.isActive():
        car "I dare you..."
        scene 02_0477 with dissolve
        car "To give Uncle [mc] a lap dance!"
        call Emotion (alex, "Gasp", "Hah! Okay!")
        scene 02_0478 with fade
        car "Sit down, Uncle [mc]."
        nic "I'll get the music!"
        scene 02_0479 with dissolve
        mc "What's going on?"
        car "Enjoy the show!"
        play music "lapd.mp3" volume 0.8 loop
        scene 02_0480 with fade
        alex "[whi]You should run, they want me to give you a lap dance!"
        scene 02_0425_03 with dissolve
        mc "Whoa! Hold up!"
        scene 02_0425_04 with dissolve
        mc "I'm outta here! See ya later, girls!"
        alex "[lol]"
        scene black with Fade(3, 1,1)
        stop music
    else:
        $ Alex.Add("Dnc")
        call AlexReplay01
        scene 02_0522 with fade
        alex h "That was fun!"
        scene 02_0523 with dissolve
        nic "I almost got pregnant just watching you both!"
        car "[lol]"
        scene 02_0524 with dissolve
        alex "If {i}someone{/i} hadn't stopped me, {b}I{/b} may have ended up pregnant, too!"
        scene 02_0525 with dissolve
        mc "I'm gonna go, before {b}any{/b} of you fall pregnant!"
        car "Okay, tell Mom I'll be home later."
return

label Springhaven_Start2:
    call CenterText ("Later that day.")
    if oakhill_ch==1:
        $ curLOC=oakhill_id
        $ springhaven_open=False
        jump OakHill_Start1
    elif cedargrove_ch==1:
        $ curLOC=cedargrove_id
        $ springhaven_open=False
        jump CedarGrove_Start1
    scene 03_0001 with fade
    mct "It's almost good to be back in Springhaven."
    if not Millie.Has("Taste") and Millie.hasScore(2):
        $ Millie.Add("Taste")
    if Cara.Has("BoobPlay"):
        $ Cara.Add("L1")
        $ Cara.Del("Kiss")
        $ Cara.Del("BoobPlay")
    elif Cara.Has("ShowsBoobs"):
        $ Cara.Add("L0")
    if Mary.Has("Daddy"):
        $ persistent.MaryDaddy=True
        $ Mary.Del("Daddy")
    jump Springhaven_DeliverPackage
return

label Springhaven_DeliverPackage:
    scene 03_0002 with fade1
    pause 1.0
    scene 03_0003 with fade
    mc "Hi, Little Puppy!\nShe put you in the naughty corner again?"
    call Emotion (jam, "Growl")
    scene 03_0004 with dissolve
    jam "Your new plaything is here. Want me to get rid of him?"
    sue "Send him in."
    scene 03_0005 with dissolve
    jam "[whi]Asshole."
    scene 03_0006 with dissolve
    mc "Your package."
    scene 03_0007 with dissolve
    scene 03_0008 with dissolve
    play sound "drop01.mp3" volume 0.5
    scene 03_0009 with dissolve
    scene 03_0010 with dissolve
    mc "I'm {b}not{/b} FedEx."
    scene 03_0011 with dissolve
    sue "You're {i}whatever{/i} I need you to be.\nDon't forget that."
    scene 03_0012 with dissolve
    mc "Before I left, you said there was something you wanted us to discuss."
    sue "Yes."
    scene 03_0013 with dissolve
    sue "But not here."
    sue "Is there a place we can meet that wouldn't be out of the ordinary for you to be seen there?"
    scene 03_0014 with dissolve
    mc "Why?"
    sue "..."
    mc "Uhh... Yeah."
    scene 03_0015 with dissolve
    mc "There's a bar across town... Smokey Joe's."
    sue "Good.\nBe there in one hour."
    call CenterText ("Two hours later.", True)
    $ renpy.music.set_volume(0.15)
    $ renpy.music.play("<from 10>bar03.mp3", fadein=1)
    scene 03_0016 with fade
    mct "Where the hell is she?"
    scene 03_0017 with dissolve
    mct "Finally!"
    scene 03_0018 with dissolve
    mc "You said an hour!"
    sue "I told {i}you{/i} to be here in one hour.\nI didn't say I would."
    sue "I can't afford to sit around in a place like... {i}this{/i}, waiting for {b}you{/b}."
    scene 03_0019 with dissolve
    mc "Uhh... Can I get you a drink?"
    sue "Amusing."
    sue "I have an assignment for you."
    scene 03_0020 with dissolve
    sue "A very important client's daughter attends college in Lakeshore."
    sue "He hasn't been able to contact her for a few days and is, naturally, starting to worry."
    sue "I need you to go and check up on her."
    scene 03_0021 with dissolve
    mc "I've just got back into town!\nCan't he phone the college to ask if she's been attending her classes?"
    sue "If only it were that simple."
    sue "No, he can't do that, for reasons I'm {i}not{/i} about to divulge to you."
    scene 03_0022 with dissolve
    sue "You don't have to leave right away, but as soon as possible."
    sue "It's an easy job. No contact. Simply confirm she's okay, and leave."
    mc "Can't you just send one of your goons?"
    sue "I am."
    scene 03_0023 with dissolve
    sue "I need you to be discreet.\nShe, or anyone around her, cannot know you're there."
    sue "My {i}other{/i} goons would stick out like a sore thumb."
    scene 03_0024 with dissolve
    call Emotion (mc, "Sigh", "Fine.")
    mc "Can you send me a picture so I know who I'm looking for?"
    scene 03_0025 with dissolve
    sue "No! {b}No phone!{/b}"
    sue "{b}DO NOT{/b} take your cellphone with you."
    scene 03_0026 with dissolve
    mc "Uhh... Okay..."
    scene 03_0027 with dissolve
    sue "Here's a recent photo of her."
    scene 03_0028 with dissolve
    pause
    scene 03_0029 with dissolve
    sue "Do you require any other information?"
    mc "Yeah."
    mc "Why couldn't you tell me this in your office?"
    scene 03_0030 with dissolve
    sue "It's a delicate situation, and none of your concern."
    sue "Do the job you're given and stop asking irrelevant questions."
    scene 03_0031 with dissolve
    sue "Report back to me, and {b}only{/b} me, on your return."
    scene 03_0032 with dissolve
    mc "Whatever you say."
    stop music
    scene 03_0033 with Fade(1, 0.5, 1)
    mct "Clearly, there's more to this than she's letting on."
    scene 03_0034 with dissolve
    mct "I guess it doesn't matter {b}who{/b} this girl is.\nDo the job and come home. Don't get involved."
    scene 03_0035 with Fade(1, 0.5, 1)
    mct "Ugghh... Alison's bound to ask me if I found Nettie.\nWhat the hell do I say to her?"
    if SentDocs:
        play sound "text.mp3"
        pause 0.5
        scene 03_0036 with dissolve
        pause 1.0
        show screen CellPhone("Alysha")
        msg_nvl "Thank you for the pictures."
        msg_nvl "Sorry it took a little while to get back to you. I've been trying to figure out if they're useful or not."
        mc_nvl "Are they?"
        msg_nvl "Yeah.\nAt least, I think so."
        msg_nvl "I'm not sure what we have yet; we need more pieces of the puzzle."
        mc_nvl "WE??"
        mc_nvl "I saw the plans, figured you'd be interested in them, sent you a couple of snaps, that's it."
        mc_nvl "There is no WE."
        msg_nvl "Oh."
        msg_nvl "I thought you'd changed your mind."
        mc_nvl "Sorry, but no. I can't take that risk."
        mc_nvl "and honestly, neither should you."
        call CloseCell ()
    scene 03_0037 with dissolve
    nic "Hi, [mc]!"
    car "Uncle [mc]! You're home!"
    mc "Hi, girls!\nYou both look great, off somewhere nice?"
    scene 03_0038 with dissolve
    nic "We're going to the cinema."
    car h "I {b}have{/b} to ask - What did you do to Mom?"
    mc "Uh, nothing that I'm aware of. Why?"
    scene 03_0039 with dissolve
    car "I can't remember the last time I had {b}this{/b} much freedom!"
    car "She always hated me leaving the house, checked up on me every five minutes, and went crazy if I came home late!"
    car "But now, she's the total opposite!"
    mc "Ahh, okay.\nNothing to do with me!"
    car "Yeah, right!"
    scene 03_0040 with dissolve
    car "Whatever you did, {b}thank you{/b}!"
    mc "You're welcome, Pipsqueak."
    if persistent.Incest and Cara.isActive() and Cara.Has("L1"):
        scene 03_0041 with dissolve
        car "[whi]I want to kiss you so badly, right now."
        scene 03_0042 with dissolve
        car "[whi]I know it's wrong, but I don't care."
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Kiss her":
                    $ tCh=True
                "Don't kiss her":
                    pass
        if tCh or Cara.Has("EZ"):
            scene 03_0044 with dissolve
            car "[ss]Mmmhhh."
            scene 03_0045 with dissolve
            nic "What the fuck are you doing?!"
            scene 03_0046 with dissolve
            nic "Your mom might see you, Cara!"
            mc "She's right."
            mc "Go and enjoy your freedom, Pipsqueak."
        else:
            scene 03_0043 with dissolve
            mc "You'd care if your mom saw us!"
            call Emotion (car, "Sigh", "Yeah. She'd kill us both.")
            mc "Go and enjoy your freedom, Pipsqueak."
    scene 03_0047 with dissolve
    car "See you later."
    mc "Bye."
    scene 03_0048 with Fade(1, 0.5, 1)
    mc "Hey."
    scene 03_0049 with dissolve
    ali "Welcome home!"
    scene 03_0050 with dissolve
    ali "So??"
    ali "Don't keep me in suspense! Did you find her?"
    mc "Yeah."
    ali "Great!"
    scene 03_0051 with dissolve
    ali "I know how important it was to you."
    ali "It wasn't just {i}a promise{/i} you wanted to honor; it was your best friend's memory, too."
    mc "Yeah.\nMy best friend. My brother."
    mc "The man I would've taken a bullet for."
    mc "The man I've looked up to my whole life."
    scene 03_0052 with dissolve
    mc "[whi]The man I {i}thought{/i} I knew, more than anyone else in this world."
    scene 03_0053 with dissolve
    ali "What's wrong? Did something happen?"
    mc "Er... No, I'm fine.\nJust tired."
    scene 03_0054 with dissolve
    ali "You know you can talk to me, right?\nI'm here for you."
    scene 03_0055 with dissolve
    mc "It's... Uhh..."
    mc "... [whi]Fuck."
    mc "Nettie told me... something...\n... and I acted like a complete fuckin' asshole."
    scene 03_0058 with dissolve
    ali "What did you do?"
    scene 03_0056 with dissolve
    mc "My reaction was {b}so{/b} inappropriate!"
    mc "I basically accused her of lying..."
    mc "I... I couldn't believe what she was telling me."
    scene 03_0057 with dissolve
    ali "But... now, you're not so sure?"
    mc "After she left, I thought about it a lot.\nI had time to process it."
    scene 03_0058 with dissolve
    ali "This is about their falling out, isn't it?"
    scene 03_0059 with dissolve
    mc "Err... yeah."
    mc "Do you... know??"
    ali "No.\nNot the whole story."
    scene 03_0060 with dissolve
    ali "I asked Pete many times to tell me what happened, but he never did."
    ali "... Until, one night.\nHe came home, and he was as drunk as I'd ever seen him."
    ali "We got into an argument, as usual."
    scene 03_0061 with dissolve
    ali "I don't remember why, but Nettie was mentioned.\nSo, I asked him again."
    ali "He started screaming at me about how he shouldn't have done it, but he could tell she wanted him to."
    ali "But that she'd been playing with him. Leading him on."
    scene 03_0062 with dissolve
    ali "He was like a madman! Screaming and shouting one minute and rambling the next."
    ali "I couldn't even make out half of the things he was saying."
    ali "Then, he collapsed into the chair and fell asleep."
    scene 03_0063 with dissolve
    ali "The next morning, I asked him to explain his outburst."
    ali "He just shrugged his shoulders and said he didn't even remember getting home."
    scene 03_0064 with dissolve
    ali "I had no way of reaching out to Nettie.\nAnd, in all honesty, I had enough of my own problems to deal with."
    ali "This all happened a few months before his death, so we'd already had conversations about divorcing."
    ali "The only time I've seen Nettie since was at the funeral.\nNot a good time or place to ask such awkward questions."
    scene 03_0065 with dissolve
    ali "I don't want to ask, because I'm scared I already know the answer, but..."
    mc "No. He didn't get {i}that{/i} far.\nShe fought him off."
    scene 03_0066 with dissolve
    ali "Ohh, thank God!\nI'd always feared the worst."
    scene 03_0067 with dissolve
    ali "So, she tells you all this, and you... accused her of lying??"
    scene 03_0068 with dissolve
    mc "No! I didn't call her a liar!"
    mc "I think I said something about him always joking around... and..."
    scene 03_0069 with dissolve
    mc "... Fuck... Yeah, I pretty much called her a liar."
    scene 03_0070 with dissolve
    mc "I... I just couldn't comprehend him doing something like that!\nThere {b}had{/b} to be another explanation!"
    mc "This is {b}Pete{/b} we're talking about!\nThe man I knew could never do that!"
    scene 03_0071 with dissolve
    ali "[mc], I'm sorry, but the man you knew was just the man he {i}wanted{/i} you to see."
    ali "The art of deception, blending in - it was a part of your training! And he had mastered it!"
    ali "He had us all fooled."
    scene 03_0072 with dissolve
    ali "Did Nettie accept the letter?"
    mc "Yeah.\nShe refused to read it, though. Said she was gonna burn it."
    scene 03_0073 with dissolve
    ali "Not a bad idea. Maybe I should do the same."
    mc "You didn't read yours?"
    scene 03_0072 with dissolve
    ali "Umm... No, not yet."
    ali "I'm sorry.\nI know you came a long way to bring it, and I feel terrible. I..."
    scene 03_0056 with dissolve
    mc "Hey, I promised to deliver his letters. I've done just that."
    mc "What you and Nettie decide to do with them is none of my business."
    mc "If you want to burn it, you go right ahead."
    scene 03_0074 with dissolve
    mc "I'm exhausted.\nIf it's okay with you, I'm gonna have a shower and an early night."
    ali "Of course!\nYou don't need to ask my permission every time you want to take a shower!"
    ali "What are you going to do about Nettie?"
    call Emotion (mc, "Sigh", "I don't know.")
    scene 03_0075 with dissolve
    mc "I definitely owe her an apology, though."
    if Mary.Has("Cell") or Sarah.Has("Cell"):
        scene 03_0076 with Fade(2, 1, 2)
        pause 1.5
        if Mary.Has("Cell"):
            show screen CellPhone("Mary")
            mc_nvl "Hi Mary!"
            mc_nvl "Turns out I do need to return to Lakeshore!"
            mc_nvl "When did you say Bill was doing his run there?"
            msg_nvl "Hi [mc]!!"
            msg_nvl "I'll go ask, give me one sex"
            msg_nvl "*sec!! OMG! {image=/thumbs/cell/emoji/shock.png}"
            mc_nvl "{image=/thumbs/cell/emoji/crylaugh.png}"
            msg_nvl "He said he's going tomorrow morning and again the same time next week."
            mc_nvl "Tomorrow will be great if I can ride along."
            mc_nvl "Mary?"
            mc_nvl "Hello?"
            msg_nvl "He said he'll pick you up in the same spot he dropped you last time. 8AM."
            mc_nvl "That's perfect. Thanks."
            msg_nvl "{image=/thumbs/cell/emoji/heart.png}"
        else:
            show screen CellPhone("Sarah")
            mc_nvl "Hi."
            mc_nvl "Turns out I do need to make a trip to Lakeshore.\nWas hoping the offer of a ride was still good?"
            msg_nvl "[mc]! Hi!"
            msg_nvl "Yes, of course!\nI'm supposed to be leaving first thing tomorrow morning, though!"
            msg_nvl "Does that work for you?\nI can message Dawn to stall the visit for a day, possibly two if needed?"
            mc_nvl "Actually, tomorrow will be perfect for me."
            msg_nvl "Oh, great!"
            msg_nvl "Remember where I live?\nI can pick you up if it's easier?"
            mc_nvl "I remember.\nI'll be there first thing. See you then."
            msg_nvl "Ok! Bye. x"
        call CloseCell ()
        mct "Great!"
    scene black with Fade(2, 1, 2)
    jump Springhaven_ConvoCara
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
