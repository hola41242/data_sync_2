label SaraReplay01:
    call Unlocker ("SaraReplay01")
    $ Sarah.incSex()
    if _in_replay:
        scene 01_0207 with Fade(1, 0, 2)
        $ aPs(1, True)
        scene 01_0208 with dis1
        $ aPs(1)
        scene 01_0209 with dissolve
        $ aPs(1)
        scene 01_0210 with dis1
        $ aPs(1)
        scene 01_0211 with dis1
        $ aPs(1)
        scene 01_0212 with dissolve
        $ aPs(0.1)
        scene 01_0213 with dissolve
        $ aPs(0.1)
        scene 01_0214 with dissolve
        $ aPs(0.1)
        scene 01_0215 with dissolve
        $ aPs(1)
    scene 01_0218 with dis1
    $ aPs(1, True)
    scene 01_0219 with dis1
    $ aPs(1)
    scene 01_0220 with dis1
    $ aPs(1)
    scene 01_0221 with dis1
    $ aPs(1)
    scene 01_0222 with dis1
    $ aPs(1)
    scene 01_0223 with dis1
    $ aPs(1)
    scene 01_0224 with dis1
    $ aPs(1)
    scene 01_0225 with dis1
    $ aPs(1)
    scene 01_0226 with dis1
    $ aPs(1)
    scene 01_0227 with dis1
    $ aPs(1, False, True)
    scene 01_0228 with dis1
    mc "[whi]..Err...Morning...."
    scene 01_0229 with dissolve
    sar "[whi]Hi.{w=1.0}{nw}"
    scene 01_0230 with dissolve
    sar "[ss]Mmhhh.."
    scene 01_0231 with dissolve
    sar "[ss]..Mmmhh.."
    scene 01_0232 with dissolve
    pause 0.5
    scene 01_0233 with dis1
    sar "[ss]..Mmhhh.."
    scene 01_0234 with fade
    $ aPs(1, True)
    scene 01_0235 with fade
    $ aPs(1)
    scene 01_0236 with dissolve
    $ aPs(1, False, True)
    image r_sar_001 = Movie(play="images/e01/01_0237.webm", keep_last_frame=True, loop=False)
    show r_sar_001 with dissolve
    pause 2.5
    sar "[ss]..Ohhh.."
    scene 01_0238 with dissolve
    sar "[ss]..Mmhhh.."
    scene 01_0239 with dissolve
    pause
    image r_sar_002 = Movie(play="images/e01/01_0240.webm")
    show r_sar_002 with dissolve
    call Moan (sar)
    scene 01_0241 with fade
    sar "[ss]..Mmhhh.."
    scene 01_0242 with dissolve
    call Moan (sar)
    scene 01_0243 with dissolve
    $ aPs(0, True)
    scene 01_0244 with dissolve
    $ aPs()
    scene 01_0245 with dissolve
    $ aPs(0, False, True)
    scene 01_0246 with dissolve
    sar "[ss]..Mmhhh.."
    scene 01_0247 with fade
    sar "[ss]Ohhh...that feels good..."
    scene 01_0248 with dissolve
    sar "[ss]..Mmhhh.."
    scene 01_0249 with dissolve
    $ aPs(0.25, True)
    scene 01_0250 with dissolve
    $ aPs(0.25)
    scene 01_0251 with dissolve
    $ aPs(0.25)
    scene 01_0252 with dissolve
    $ aPs(1, False, True)
    scene 01_0253 with dissolve
    pause
    scene 01_0254 with dissolve
    sar "[ss]Don't make me beg for it."
    scene 01_0255 with dissolve
    call Moan (sar)
    scene 01_0256 with dissolve
    sar "[ss]..Mmhhh.."
    image r_sar_003 = Movie(play="images/e01/01_0257.webm")
    show r_sar_003 with dissolve
    call Moan (sar)
    scene 01_0258 with dissolve
    sar "[ss]....Mmmmhhh...."
    scene 01_0259 with dissolve
    sar "[ss]....Mmhh....Fuck, yes....."
    image r_sar_004 = Movie(play="images/e01/01_0260.webm")
    show r_sar_004 with dissolve
    call Moan (sar)
    scene 01_0261 with dissolve
    sar "[ss]..OHHH.."
    image r_sar_005 = Movie(play="images/e01/01_0262.webm")
    show r_sar_005 with dissolve
    call Moan (sar, 7)
    scene 01_0263 with dissolve
    sar "[ss].....Fuck, Baby......Yess...."
    scene 01_0264 with dissolve
    call Moan (sar, 7)
    scene 01_0265 with dissolve
    sar "[ss]..OHHH.."
    scene 01_0266 with dissolve
    sar "[ss]....Yes, fuck.....MMMHHHH...."
    image r_sar_006 = Movie(play="images/e01/01_0267.webm")
    show r_sar_006 with dissolve
    call Moan (sar, 10)
    sar "[ss]OHHH....YES.....BABY...."
    call CharCum ("e01/01_0268.webp", "e01/01_0269.webp", sar, "Ohhhhhhh", 1)
    scene 01_0270 with dissolve
    sar "[ss]...Wow...Mmmmhhh...."
    call Loop_Punch (6, "e01/01_0271.webp", "e01/01_0272.webp")
    call CmOpts (["Cum inside Sarah", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Sarah.incCm()
        call CharCum ("e01/01_0271.webp", "e01/01_0273.webp", mc, "Nnnngghhhh.")
        scene 01_0274 with dissolve
        mc "[ss]....Fuuuck...."
        scene 01_0275 with dissolve
    else:
        call CharCum ("e01/01_0271.webp", "e01/01_0276.webp", mc, "Nnnngghhhh")
        call CharCum ("e01/01_0276.webp", "e01/01_0277.webp", mc, "...Nnnnhhhh..")
        scene 01_0278 with dissolve
        mc "[ss]....Fuuuck...."
        scene 01_0279 with dissolve
    sar "[ss]Wow!"
    mc "[whi]Was a helluva wake-up call!"
    if _in_replay:
        scene black with ReplayFade
return

label SaraReplay02_Part01:
    $ Sarah.incSex()
    scene 03_0620 with dissolve
    sar "It's a bit of a squeeze, but I'm sure we'll manage."
    scene 03_0622 with dissolve
    mc "I'm sure we will."
    scene 03_0623 with dissolve
    sar "[ss]Mmhh."
    scene 03_0661 with dissolve
    sar "[ss]..Mmmmhh.."
    scene 03_0662 with dissolve
    pause
    scene 03_0663 with dis1
    pause 0.5
    scene 03_0664 with dis1
    pause 0.5
    scene 03_0665 with dis1
    sar "[ss]..Mmhh.."
    scene 03_0666 with dis1
    pause 0.5
    scene 03_0667 with dis1
    pause 0.5
    scene 03_0668 with dis1
    pause
    scene 03_0669 with dis1
    pause 0.5
    scene 03_0670 with dis1
    pause 0.5
    scene 03_0671 with dis1
    sar "[ss]..Mmmmmhh.."
    scene 03_0672 with dissolve
    pause
    scene 03_0673 with dissolve
    sar "[ss]..Ohhh.."
    scene 03_0674 with dissolve
    pause 0.5
    scene 03_0675 with dis1
    pause 0.5
    scene 03_0676 with dis1
    pause 0.5
    scene 03_0677 with dissolve
    sar "[ss]..Mmmmmhh.."
    scene 03_0678 with dis1
    pause 0.5
    scene 03_0679 with dis1
    pause 0.5
    scene 03_0680 with dis1
    pause 0.5
    scene 03_0681 with dis1
    pause 0.5
    scene 03_0682 with dis1
    pause 0.5
    scene 03_0683 with dissolve
    pause 0.5
    scene 03_0684 with dis1
    pause
    scene 03_0685 with dissolve
    sar "[ss]..Nnnhh.."
    scene 03_0686 with dissolve
    pause
    scene 03_0687 with dis1
    pause 0.5
    scene 03_0688 with dis1
    sar "[ss]..Mmmmmhh.."
    scene 03_0689 with dissolve
    pause  
    scene 03_0690 with dissolve
    image r_sar_007 = Movie(play="images/e03/03_0691.webm")
    show r_sar_007 with dissolve
    sar "[ss]..Mmhh.."
    scene 03_0692 with dissolve
    pause 0.5
    scene 03_0693 with dissolve
    mc "[ss]..Fuuck.."
    scene 03_0694 with dissolve
    image r_sar_008 = Movie(play="images/e03/03_0695.webm")
    show r_sar_008 with dissolve
    sar "[ss]..Mmhh.."
    scene 03_0696 with dissolve
    image r_sar_009 = Movie(play="images/e03/03_0697.webm")
    show r_sar_009 with dissolve
    sar "[ss]..Mmmmhh.."
    scene 03_0698 with fade
    sar "[ss]..Mmhh.."
    scene 03_0699 with dis1
    pause 0.5
    scene 03_0700 with dis1
    pause 0.5
    scene 03_0701 with dis1
    pause 0.5
    scene 03_0702 with dis1
    pause
    scene 03_0703 with dissolve
    pause
    scene 03_0704 with dissolve
    sar "[ss]..Mmhh.."
    scene 03_0705 with dissolve
    sar "[ss]..Mmmmmhh.."
    scene 03_0706 with dissolve
    sar "[ss]..Ohhhh.."
    scene 03_0707 with dissolve
    sar "[ss]....Fuuck....."
    scene 03_0708 with dissolve
    call Moan (sar)
    scene 03_0709 with dissolve
    sar "[ss]..Mmmhhh...That's so...."
    scene 03_0710 with dissolve
    sar "[ss]..Ohhhhhh...Yes Baby, just like that...."
    scene 03_0711 with dissolve
    image r_sar_010 = Movie(play="images/e03/03_0712.webm")
    show r_sar_010 with dissolve
    call Moan (sar)
    scene 03_0713 with dissolve
    sar "[ss]..Ohhhh.....Yes....."
    scene 03_0714 with dissolve
    call Moan (sar)
    scene 03_0715 with dissolve
    sar "[ss]..Fuuuck, that feels nice......"
    scene 03_0716 with dissolve
    sar "[ss]...OHHHH..."
    if persistent.Anal==True:
        scene 03_0717 with dissolve
        sar "[ss]...Fuck, Baby...Mhhh...I'd love you to go lower for me..."
        scene 03_0718 with dissolve
        pause 1.0
        scene 03_0719 with dis1
        sar "[ss]...{size=*1.5}OHHHHHH{/size}....."
        scene 03_0720 with dis1
        sar "[ss]...OH GOD, [mc!u]...YES BABY...."
        scene 03_0721 with dissolve
        call Moan (sar, 7)
        scene 03_0722 with dissolve
        sar "[ss]..Ohhhh.."
    scene 03_0723 with dissolve
    call Moan (sar, 7)
    scene 03_0724 with dissolve
    sar "[ss]...I need you inside me...."
    scene 03_0725 with dissolve
    pause
    scene 03_0726 with dissolve
    pause
    scene 03_0727 with dissolve
    image r_sar_011 = Movie(play="images/e03/03_0728.webm", keep_last_frame=True, loop=False)
    show r_sar_011 with dissolve
    sar "[ss]...OHHHH..."
    scene 03_0729 with dissolve
    image r_sar_012 = Movie(play="images/e03/03_0730.webm")
    show r_sar_012 with dissolve
    sar "[ss]..Mmmhh.."
    scene 03_0731 with dissolve
    sar "[ss]Come here."
    scene 03_0732 with dissolve
    sar "[ss]..Mmmhh.."
    scene 03_0733 with dissolve
    image r_sar_013 = Movie(play="images/e03/03_0734.webm")
    show r_sar_013 with dissolve
    call Moan (sar, 7)
    scene 03_0735 with dissolve
    sar "[ss]....Mmhh...."
    scene 03_0736 with dissolve
    image r_sar_014 = Movie(play="images/e03/03_0737.webm")
    show r_sar_014 with dissolve
    sar "[ss]...OHHHH..."
    scene 03_0738 with dissolve
    sar "[ss]..Ohhhh.....Yes....."
    if not _in_replay:
        if persistent.GroupSex and persistent.Lez and Sarah.Has("L1") and Sarah.Has("3S") and Dawn.hasScore(1):
            call SaraReplay02_Part02B
        else:
            call SaraReplay02_Part02A
return

label SaraReplay02_Part02A:
    call Unlocker ("SaraReplay02_Part02A")
    if _in_replay:
        call SaraReplay02_Part01
    scene 03_0870 with dissolve
    image r_sar_015 = Movie(play="images/e03/03_0871.webm")
    show r_sar_015 with dissolve
    sar "[ss]...OHHHH..."
    sar "[ss]...YES BABY...."
    sar "[ss]...YES....YES!...."
    call CharCum ("e03/03_0870.webp", "e03/03_0748.webp", sar, "....OHHHHH!!....")
    call CharCum ("e03/03_0748.webp", "e03/03_0749.webp", sar, "..OHHHHH..")
    call Loop_Punch (6, "e03/03_0745.webp", "e03/03_0744.webp")
    call CmOpts (["Cum inside Sarah", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Sarah.incCm()
        call CharCum ("e03/03_0870.webp", "e03/03_0872.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e03/03_0872.webp", "e03/03_0873.webp", mc, "....nnnnhhhhh...")
        scene 03_0874 with dissolve
        sar "[ss]..Wow..."
    else:
        call CharCum ("e03/03_0870.webp", "e03/03_0875.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e03/03_0875.webp", "e03/03_0876.webp", mc, "....nnnnhhhhh...")
        scene 03_0877 with dissolve
        sar "[ss]..Wow..."
    scene 03_0878 with Fade(2, 2, 1)
    mc "[whi]...Zzzzz..."
return

label SaraReplay02_Part02B:
    scene 03_0739 with dissolve
    mc "[whi]Did she taste good?"
    scene 03_0740 with dissolve
    sar "[ss]What?"
    scene 03_0739 with dissolve
    mc "[whi]Dawn. Did her pussy taste good?"
    scene 03_0741 with dissolve
    sar "[ss]...Mmm-hmm......"
    call Loop_Punch (4, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0739 with dissolve
    mc "[whi]Did you make her wet?"
    scene 03_0742 with dissolve
    sar "[ss]..Mmmhhh.....Yes.....So wet......."
    call Loop_Punch (2, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0739 with dissolve
    mc "[whi]Did you like it? Making your best friend cum?"
    scene 03_0743 with dissolve
    sar "[ss]....Ohh....fuck.......YES...I loved it...."
    call Loop_Punch (3, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0739 with dissolve
    mc "[whi]Your tongue slowly, parting her soft lips and sliding into her warm, wet pussy."
    scene 03_0746 with dissolve
    call Moan (sar, 10)
    call Loop_Punch (2, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0739 with dissolve
    mc "[whi]You'd like to taste her again, wouldn't you?"
    scene 03_0747 with dissolve
    sar "[ss]Mmm-hmm...."
    scene 03_0739 with dissolve
    mc "[whi]Would you like her to join us?"
    call Loop_Punch (3, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0739 with dissolve
    mc "[whi]Would you like us all to fuck?"
    call CharCum ("e03/03_0739.webp", "e03/03_0748.webp", sar, "....OHHHHH!!....")
    call CharCum ("e03/03_0748.webp", "e03/03_0749.webp", sar, "...YES.....YES....OHHHHH....")
    call CharCum ("e03/03_0749.webp", "e03/03_0750.webp", sar, "....MMMHHHHHH....")
    call Loop_Punch (3, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0751 with dissolve
    sar "[ss]...You... You think she'd want to?..."
    scene 03_0739 with dissolve
    mc "[whi]I know she does."
    call Loop_Punch (2, "e03/03_0745.webp", "e03/03_0744.webp")
    scene 03_0751 with dissolve
    pause 0.5
    scene 03_0752 with dissolve
    sar "[ss]Then... Let's go fuck my best friend."
    if not _in_replay:
        call SaraReplay02_Part03
return

label SaraReplay02_Part03:
    call Unlocker ("SaraReplay02_Part03")
    if _in_replay:
        call SaraReplay02_Part01
        call SaraReplay02_Part02B
    call DawnReplay01
return

label SaraReplay03:
    call Unlocker ("SaraReplay03")
    $ Sarah.incSex()
    scene 06_0229 with fade2
    sar "I'm happy you called around tonight."
    mc "Me too."
    scene 06_0230 with dissolve
    sar "I like you, [persistent.McName]..."
    mc "I like you too."
    if not persistent.SarahRP03Dat:
        mc "Why do I feel there's a {b}but{/b} coming?"
        sar "But..."
        if _in_replay:
            mc "Don't worry, Sarah. I'm not gonna fall in love with you."
            sar "Oh! I guess you've had this conversation before?"
        else:
            scene 06_0231 with dissolve
            sar "I like {i}this{/i}. What we have {b}right now{/b}."
            sar "I'm worried you'll want more from me."
            scene 06_0232 with dissolve
            mc "I like what we have right now, too.\nAnd I'm not looking for anything else."
            mc "You once told me you're not into marriage; neither am I."
            mc "Been there, done that. Got the scars to prove it."
            scene 06_0233 with dissolve
            sar "So... We promise not to fall in love with each other?"
            mc "Promise."
            sar "I promise, too."
            scene 06_0234 with dissolve
            sar "And... I don't want us to be... exclusive."
            mc "You... want to sleep with other guys?"
            scene 06_0235 with dissolve
            sar "No. I'm more than happy on my own... with {b}just{/b} us."
            sar "I'm not interested in {i}other{/i} guys.\nTo be honest, {i}this{/i} has caught me by surprise!"
            sar "But I know it's... different... for guys.\nFor me, sex is always intimate, personal."
            scene 06_0236 with dissolve
            sar "For a guy, it can be... just sex."
            sar "I don't want to be your only choice.\nI don't want that commitment from you."
            scene 06_0237 with dissolve
            sar "Are you okay with that?"
            mc "Uhh... I..."
            mc "Is this a test? It feels like a test."
            scene 06_0238 with dissolve
            sar "[lol]"
            sar "It's not a test. I'm serious."
            mc "Okay."
            scene 06_0239 with dissolve
            sar "So when you're in Lakeshore with Dawn..."
            if Dawn.isSexual():
                sar "I know we all had sex together - which was great, by the way."
                sar "But I... I'm just saying...\nI don't {b}need{/b} to be there with you both..."
                sar "Should you want that to happen again."
                mc "Okay."
            else:
                sar "I know she likes you. She likes you a lot."
                scene 06_0240 with dissolve
                mc "Sarah, I wouldn't do that!"
                sar "Why?"
                mc "She's your best friend. I'd never!"
                sar "But you like her? You find her attractive?"
                mc "This {b}is{/b} a test!"
                scene 06_0241 with dissolve
                sar "It's not a test, [mc]."
                sar "It's more a... suggestion."
                sar "If you like her, you should have sex with her if that's what she wants too."
                mc "What? Why?"
                scene 06_0242 with dissolve
                sar "She's going through so much right now. She's sad {b}all the time{/b}."
                sar "I want her to have a little happiness.\nI want her to feel what I feel when I'm with you."
                mc "You're asking me to have sex with Dawn... to cheer her up??"
                scene 06_0243 with dissolve
                sar "I'm not asking you to sleep with her."
                sar "All I'm saying is, if you'd {i}like{/i} to sleep together, I'm fine with it."
                mc "Uhh... Okay."
                scene 06_0244 with dissolve
                sar "There {i}is{/i} one problem, though."
                mc "Problem?"
                sar "She knows {i}we're{/i}, like... together, so she won't sleep with you, no matter how much she'd like to."
                mc "Exactly.\nShe's not gonna go behind her best friend's back, is she?"
                mc "... So why are we even talkin' about it??"
                scene 06_0245 with dissolve
                sar "If you find yourself in the situation where... you both want it to happen, she'll refuse..."
                sar "I want you to tell her you're {i}my{/i} Barry."
                mc "{i}I'm your Barry{/i}?\nWhat the hell does that mean??"
                $ Plr.Add("Barry")
                scene 06_0246 with dissolve
                sar "[lol] Don't worry, she'll understand."
                mc "[lol] If you say so."
                sar "Now shut up and kiss me. You talk too much. [giggles]"
    scene 06_0247 with dissolve
    sar "[ss]Mmmhhh."
    scene 06_0248 with dissolve
    sar "[ss]...Mmhhhhh..."
    scene 06_0249 with dis1
    sar "[whi][kiss]"
    scene 06_0250 with dis1
    sar "[whi][kiss]"
    scene 06_0251 with dis1
    sar "[whi][kiss]"
    scene 06_0252 with dissolve
    sar "[whi][kiss]"
    scene 06_0253 with dis1
    sar "[whi][kiss]"
    scene 06_0255 with dis1
    image r_sar_016 = Movie(play="images/e06/06_0256.webm")
    show r_sar_016
    if not persistent.SarahRP03Dat:
        sar "[whi]I won't fall in love with you... But I may fall in love with your dick."
        scene 06_0254 with dissolve
        mc "[whi]I may fall in love with your cat."
        sar "[whi][lol]"
    else:
        sar "[whi]I like your dick, too."
        scene 06_0254 with dissolve
        mc "[whi]Yeah? It likes you more!"
        sar "[whi][lol]"
    scene 06_0257 with dissolve
    image r_sar_017 = Movie(play="images/e06/06_0258.webm", loop=False, keep_last_frame=True)
    image r_sar_018 = Movie(play="images/e06/06_0259.webm")
    show r_sar_017
    pause 12.0
    show r_sar_018 with dissolve
    sar "[ss]Mmmhhh..."
    scene 06_0260 with dissolve
    sar "[ss]...Mmmhhh..."
    scene 06_0261 with dissolve
    image r_sar_019 = Movie(play="images/e06/06_0262.webm")
    show r_sar_019
    sar "[ss]Mmhh.."
    scene 06_0263 with dissolve
    pause
    scene 06_0264 with dissolve
    image r_sar_020 = Movie(play="images/e06/06_0265.webm")
    show r_sar_020
    sar "[ss]Mmhh.."
    scene 06_0266 with dissolve
    mc "Why is your sweet pussy so far away from my tongue?"
    scene 06_0267 with dissolve
    sar "[whi]That's a great question!"
    scene 06_0268 with Fade(1, 0.5, 1)
    sar "[ss]..Ohhh..."
    scene 06_0269 with dissolve
    pause
    scene 06_0270 with dissolve
    image r_sar_021 = Movie(play="images/e06/06_0271.webm")
    show r_sar_021
    call Moan (sar)
    scene 06_0272 with dissolve
    sar "[ss]..Ohhh..."
    scene 06_0270 with dissolve
    image r_sar_022 = Movie(play="images/e06/06_0273.webm", loop=False, keep_last_frame=True)
    show r_sar_022
    pause
    scene 06_0274 with dissolve
    call Moan (sar)
    scene 06_0275 with dissolve
    image r_sar_023 = Movie(play="images/e06/06_0276.webm")
    show r_sar_023
    sar "[ss]...Mmmhhhh..."
    scene 06_0277 with dissolve
    image r_sar_024 = Movie(play="images/e06/06_0278.webm")
    show r_sar_024
    sar "[ss]..Mmhhh.."
    scene 06_0279 with Fade(1, 0.5, 1)
    sar "[ss]Mmmhh...I'm so wet for you, Baby...."
    scene 06_0280 with dissolve
    image r_sar_025 = Movie(play="images/e06/06_0281.webm", loop=False, keep_last_frame=True)
    show r_sar_025
    pause 4.0
    sar "[ss]..Ohhhh.."
    scene 06_0282 with dissolve
    image r_sar_026 = Movie(play="images/e06/06_0283.webm")
    show r_sar_026
    sar "[ss]..Mmhhh.."
    scene 06_0284 with dissolve
    image r_sar_027 = Movie(play="images/e06/06_0285.webm")
    show r_sar_027
    sar "[ss]..that feels so good...."
    scene 06_0286 with dissolve
    sar "[ss]...Mmmhhh....Fuck me, Baby....."
    scene 06_0289 with dissolve
    image r_sar_029 = Movie(play="images/e06/06_0290.webm")
    show r_sar_029
    sar "[ss]..Ohhh.....yes...."
    scene 06_0287 with dissolve
    image r_sar_028 = Movie(play="images/e06/06_0288.webm")
    show r_sar_028
    sar "[ss]..Fuck Baby, yes...Just like that....."
    scene 06_0291 with dissolve
    sar "[ss]...It feels so good when you're inside me...."
    scene 06_0292 with dissolve
    sar "[ss]..Mmhhh..."
    scene 06_0293 with dissolve
    image r_sar_030 = Movie(play="images/e06/06_0294.webm")
    show r_sar_030
    sar "[ss]...Mmmmhhh..."
    scene 06_0295 with dissolve
    pause 0.5
    scene 06_0296 with dis1
    scene 06_0297 with dis1
    image r_sar_031 = Movie(play="images/e06/06_0298.webm")
    show r_sar_031
    sar "[ss]...Mmhhh..."
    scene 06_0299 with dissolve
    image r_sar_032 = Movie(play="images/e06/06_0300.webm")
    show r_sar_032
    call Moan (sar, 6)
    scene 06_0301 with dissolve
    sar "[ss]...Mmmmhhh..."
    scene 06_0302 with dissolve
    sar "[ss].....Mmhhh....."
    call Loop_Punch (4, "e06/06_0304.webp", "e06/06_0303.webp")
    scene 06_0305 with dissolve
    pause 0.5
    scene 06_0306 with dis1
    scene 06_0307 with dis1
    image r_sar_033 = Movie(play="images/e06/06_0308.webm")
    show r_sar_033
    sar "[ss]...Mmhhh..."
    scene 06_0309 with dissolve
    image r_sar_034 = Movie(play="images/e06/06_0310.webm")
    show r_sar_034
    call Moan (sar, 8)
    scene 06_0311 with dissolve
    pause 0.5
    scene 06_0312 with dis1
    sar "[ss]...OHHH BABY...YES....."
    scene 06_0313 with dissolve
    image r_sar_035 = Movie(play="images/e06/06_0314.webm")
    show r_sar_035
    call Moan (sar, 10)
    scene 06_0315 with dissolve
    image r_sar_036 = Movie(play="images/e06/06_0316.webm")
    show r_sar_036
    call Moan (sar, 10)
    scene 06_0317 with dissolve
    image r_sar_037 = Movie(play="images/e06/06_0318.webm")
    show r_sar_037
    call Moan (sar, 10)
    sar "[ss]...Fuck Baby.....Ohhh...."
    sar "[ss]...YES.....OHHHH....."
    if persistent.Anal:
        sar "[ss]..Baby yes...Make me cum.....OHHHHHHH...."
        call CharCum ("e06/06_0317.webp", "e06/06_0319.webp", sar, "....OHHHHH!!....")
        call CharCum ("e06/06_0319.webp", "e06/06_0326.webp", sar, "...OHHHHHHHHHH!...")
        scene 06_0327 with dissolve
        sar "[ss]..Will you do something for me, Baby?"
        scene 06_0328 with dissolve
        sar "[ss]Fill my ass with your warm, sticky cum."
        scene 06_0329 with Fade(0.5, 0, 0.5)
        pause
        scene 06_0330 with dissolve
        image r_sar_038 = Movie(play="images/e06/06_0331.webm", loop=False, keep_last_frame=True)
        show r_sar_038
        pause 4.0
        sar "[ss]..Fuuck.."
        scene 06_0332 with dissolve
        sar "[ss]...NNNNNNHHHHHH...."
        scene 06_0333 with dissolve
        image r_sar_039 = Movie(play="images/e06/06_0334.webm")
        show r_sar_039
        sar "[ss]..OHHHHH.."
        scene 06_0335 with dissolve
        image r_sar_040 = Movie(play="images/e06/06_0336.webm")
        show r_sar_040
        sar "[ss]..OHHHHH.."
        scene 06_0337 with dissolve
        image r_sar_041 = Movie(play="images/e06/06_0338.webm")
        show r_sar_041
        sar "[ss]....FUCK...."
        sar "[ss]....It feels so good Baby...."
        scene 06_0339 with dissolve
        image r_sar_042 = Movie(play="images/e06/06_0340.webm")
        show r_sar_042
        sar "[ss]....OHHHHH...."
        scene 06_0341 with dissolve
        image r_sar_043 = Movie(play="images/e06/06_0342.webm")
        show r_sar_043
        sar "[ss]...That's it, Baby..."
        sar "[ss]....You're about to explode...I can feel it...."
        sar "[ss]....My little asshole's getting stretched even more...."
        sar "[ss]....Fill me up, Baby....Fill my ass...."
        call CharCum ("e06/06_0341.webp", "e06/06_0343.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e06/06_0343.webp", "e06/06_0344.webp", mc, "....nnnnhhhhh...")
        scene 06_0323 with dissolve
        sar "[ss]..Fuuuck..."
        scene 06_0345 with dissolve
        sar "[ss]...Mmmmhh..."
        scene 06_0325 with dissolve
        if not persistent.SarahRP03Dat:
            sar "[whi]I like booty calls too."
        else:
            pause
    else:
        sar "[ss]..Baby yes...I'm close.....OHHHHHHH...."
        sar "[ss]...Cum with me, Baby.....OHHHH....Together....."
        call CharCum ("e06/06_0317.webp", "e06/06_0319.webp", sar, "....OHHHHH!!....")
        call CharCum ("e06/06_0320.webp", "e06/06_0321.webp", mc, "..NNNGGGGGHHHH!!...")
        $ Sarah.incCm()
        scene 06_0322 with dissolve
        mc "[ss]..Fuuuck..."
        scene 06_0323 with dissolve
        sar "[ss]...Mmmmmmmmmhh..."
        scene 06_0324 with dissolve
        pause
        scene 06_0325 with dissolve
        if not persistent.SarahRP03Dat:
            sar "[whi]I like booty calls too."
        else:
            pause
    if _in_replay:
        scene black with ReplayFade
    else:
        scene 06_0346 with Fade(2, 2, 1)
        sar "[whi]..Zzzz.."
return

label SaraReplay04:
    call Unlocker ("SaraReplay04")
    $ Sarah.incSex()
    if _in_replay:
        scene 13_1109 with Fade(0,0,1)
        sar "Do we have time to make love before you leave?"
        mc "Yeah."
    scene 13_1111 with dissolve
    sar "[ss]Mmhh."
    scene 13_1112 with dissolve
    pause
    scene 13_1113 with dis1
    sar "[ss]..Mmmhh.."
    scene 13_1114 with dis1
    pause
    scene 13_1115 with dissolve
    sar "[whi]Shall we go to the bedroom?"
    mc "[whi]Nope."
    scene 13_1116 with dis1
    sar "[ss]..Mmmhh.."
    scene 13_1117 with dissolve
    pause
    scene 13_1118 with dissolve
    sar "[ss]..Mmhh.."
    scene 13_1119 with dissolve
    pause
    scene 13_1120 with dissolve
    pause
    scene 13_1121 with dis1
    scene 13_1122 with dis1
    scene 13_1123 with dis1
    scene 13_1124 with dis1
    scene 13_1125 with dis1
    sar "[ss]Ohhh."
    scene 13_1126 with dissolve
    image SarahR04_01 = Movie(play="images/e13/13_1127.webm")
    show SarahR04_01
    sar "[ss]..Mmmhhhh.."
    scene 13_1128 with dis1
    scene 13_1129 with dis1
    image SarahR04_02 = Movie(play="images/e13/13_1130.webm")
    show SarahR04_02
    call Moan (sar, 4)
    scene 13_1131 with dis1
    sar "[ss]..Mmhh.... That feels so good, Baby...."
    scene 13_1132 with dis1
    pause 0.5
    scene 13_1133 with dis1
    pause 0.5
    scene 13_1134 with dis1
    image SarahR04_03 = Movie(play="images/e13/13_1135.webm")
    show SarahR04_03
    sar "[ss]..Ohhh.."
    scene 13_1136 with dissolve
    call Moan (sar)
    scene 13_1137 with dissolve
    sar "[ss]...You're so damn good at that, Baby...."
    scene 13_1138 with dissolve
    sar "[ss]...I love the way your tongue gently massages my clit......Mmmhhh....."
    if persistent.Anal:
        scene 13_1139 with dissolve
        mc "[whi]I know what you love {i}more{/i}..."
        scene 13_1140 with dis1
        pause 0.5
        scene 13_1141 with dis1
        sar "[ss]..Ohhh, [persistent.McName]..."
        scene 13_1142 with dissolve
        call Moan (sar)
        scene 13_1143 with dissolve
        pause
    scene 13_1144 with dissolve
    sar "[ss]..OHHHH.."
    scene 13_1145 with dis1
    image SarahR04_04 = Movie(play="images/e13/13_1146.webm")
    show SarahR04_04
    call Moan (sar)
    scene 13_1147 with fade1
    sar "[ss]..Ohhhh.."
    scene 13_1148 with dissolve
    sar "[ss]...Fuck, Baby...."
    scene 13_1149 with dissolve
    sar "[ss]..Let me pleasure you, too...."
    scene 13_1150 with fade1
    pause
    scene 13_1151 with dis1
    pause 0.5
    scene 13_1152 with dis1
    pause 0.5
    scene 13_1153 with dis1
    pause 0.5
    scene 13_1154 with dis1
    image SarahR04_05 = Movie(play="images/e13/13_1155.webm")
    show SarahR04_05
    sar "[ss]Mmhh."
    scene 13_1156 with dissolve
    image SarahR04_06 = Movie(play="images/e13/13_1157.webm")
    show SarahR04_06
    pause
    scene 13_1158 with dissolve
    image SarahR04_07 = Movie(play="images/e13/13_1159.webm")
    show SarahR04_07
    sar "[ss]..Mmmmhh.."
    scene 13_1160 with dissolve
    pause
    scene 13_1161 with dissolve
    pause
    scene 13_1162 with fade1
    sar "[ss]Fuck me like I'm yours, Baby."
    scene 13_1163 with dissolve
    image SarahR04_08 = Movie(play="images/e13/13_1164.webm")
    show SarahR04_08
    sar "[ss]..Ohhhh.."
    mc "[whi]You {b}are{/b} mine."
    scene 13_1165 with dissolve
    call Moan (sar)
    scene 13_1166 with dissolve
    image SarahR04_09 = Movie(play="images/e13/13_1167.webm")
    show SarahR04_09
    pause
    scene 13_1168 with dissolve
    sar "[ss]..OHHHHH.."
    scene 13_1169 with dissolve
    image SarahR04_10 = Movie(play="images/e13/13_1170.webm")
    show SarahR04_10
    call Moan (sar, 6)
    scene 13_1171 with fade1
    sar "[ss]...Fuck.....Yes, [persistent.McName]...."
    scene 13_1172 with dissolve
    image SarahR04_11 = Movie(play="images/e13/13_1173.webm")
    show SarahR04_11
    call Moan (sar, 6)
    scene 13_1174 with dissolve
    sar "[ss]..OHHHHH, BABY......YES....."
    scene 13_1175 with dissolve
    pause
    scene 13_1176 with dissolve
    image SarahR04_12 = Movie(play="images/e13/13_1177.webm")
    show SarahR04_12
    call Moan (sar, 6)
    scene 13_1178 with dissolve
    sar "[ss]...MMMMHHH..."
    scene 13_1179 with fade1
    sar "[ss]....FUCK, BABY..."
    scene 13_1180 with dissolve
    image SarahR04_13 = Movie(play="images/e13/13_1181.webm")
    show SarahR04_13
    sar "[ss]...OHHHH...."
    sar "[ss]...YES....."
    scene 13_1183 with dissolve
    call Moan (sar, 7)
    scene 13_1184 with dissolve
    sar "[ss]....FUCK ME, BABY......OHH, YES....."
    scene 13_1185 with dissolve
    image SarahR04_14 = Movie(play="images/e13/13_1186.webm")
    show SarahR04_14
    call Moan (sar, 8)
    sar "[ss]...OHHHH, GOD....."
    sar "[ss]..YESS.."
    call CharCum ("e13/13_1184.webp", "e13/13_1187.webp", sar, "..Ohhhhhhh..")
    call CharCum ("e13/13_1187.webp", "e13/13_1188.webp", sar, "..Mmmmhh..")
    scene 13_1189 with dissolve
    image SarahR04_15 = Movie(play="images/e13/13_1190.webm")
    show SarahR04_15
    sar "[ss]....Mmmhhhh...."
    if persistent.Anal:
        scene 13_1201 with dis1
        scene 13_1202 with dis1
        scene 13_1203 with dissolve
        image SarahR04_16 = Movie(play="images/e13/13_1204.webm")
        show SarahR04_16
        sar "[ss]..Ohhhh.."
        scene 13_1205 with dissolve
        sar "[ss]..Ohh god, Baby.......Yes....."
        scene 13_1206 with dissolve
        image SarahR04_17 = Movie(play="images/e13/13_1207.webm")
        show SarahR04_17
        sar "[ss]..Fuck.."
        scene 13_1208 with dissolve
        sar "[ss]..Ahhhh...Yes, Baby.....Train my tight little asshole...."
        scene 13_1209 with dissolve
        image SarahR04_18 = Movie(play="images/e13/13_1210.webm")
        show SarahR04_18
        sar "[ss]...Aahhhhh...."
        pause
    call CmOpts (["Cum inside Sarah", "Pull out", "Cum on her face", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        if persistent.Anal:
            call CharCum ("e13/13_1209.webp", "e13/13_1211.webp", mc, "...Nnnggghh...")
            call CharCum ("e13/13_1211.webp", "e13/13_1192.webp", mc, "..Nnnnhhh..")
            scene 13_1195 with dissolve
            sar "[ss]Mmmhhh.... I love when you fill my ass up, Baby...."
            scene 13_1196 with dissolve
            pause
        else:
            $ Sarah.incCm()
            call CharCum ("e13/13_1189.webp", "e13/13_1191.webp", mc, "...Nnnggghh...")
            call CharCum ("e13/13_1191.webp", "e13/13_1192.webp", mc, "..Nnnnhhh..")
            scene 13_1193 with dissolve
            sar "[ss]Mmmhhh.... That was sooo good...."
            scene 13_1194 with dissolve
            pause
    elif Copt==1:
        if persistent.Anal:
            call CharCum ("e13/13_1209.webp", "e13/13_1212.webp", mc, "...Nnnggghh...")
            call CharCum ("e13/13_1212.webp", "e13/13_1213.webp", mc, "..Nnnnhhh..")
            scene 13_1199 with dissolve
            sar "[ss]Mmmhhh.... That was sooo good...."
            scene 13_1200 with dissolve
            pause 
        else:
            call CharCum ("e13/13_1189.webp", "e13/13_1197.webp", mc, "...Nnnggghh...")
            call CharCum ("e13/13_1197.webp", "e13/13_1198.webp", mc, "..Nnnnhhh..")
            scene 13_1199 with dissolve
            sar "[ss]Mmmhhh.... That was sooo good...."
            scene 13_1200 with dissolve
            pause 
    elif Copt==2:
        if persistent.Anal:
            scene 13_1214 with dissolve
        else:
            scene 13_1201 with dissolve
        mc "[whi]Turn around, Baby."
        scene 13_1215 with dissolve
        sar "[ss]You have a treat for me?"
        mc "[whi]Yes I do."
        scene 13_1226 with dissolve
        image SarahR04_20 = Movie(play="images/e13/13_1227.webm")
        show SarahR04_20
        pause
        call CharCum ("e13/13_1226.webp", "e13/13_1228.webp", mc, "...Nnnggghh...")
        call CharCum ("e13/13_1228.webp", "e13/13_1229.webp", mc, "..Nnnnhhh..")
        scene 13_1230 with dissolve
        sar "[ss]How do I look?"
        scene 13_1231 with dissolve
        mc "[whi]Damn beautiful, Baby."
    else:
        if persistent.Anal:
            scene 13_1214 with dissolve
        else:
            scene 13_1201 with dissolve
        mc "[whi]Turn around, Baby."
        scene 13_1215 with dissolve
        if persistent.Anal:
            sar "[ss]Ass to mouth?\nYou're gonna turn me into a naughty, dirty girl, Baby."
        else:
            sar "[ss]You have a treat for me?"
            mc "[whi]Yes I do."
        scene 13_1216 with dis1
        scene 13_1217 with dis1
        scene 13_1218 with dis1
        scene 13_1219 with dis1
        image SarahR04_19 = Movie(play="images/e13/13_1220.webm")
        show SarahR04_19
        sar "[ss]Mmmhh."
        call CharCum ("e13/13_1219.webp", "e13/13_1221.webp", mc, "...Nnnggghh...")
        call CharCum ("e13/13_1221.webp", "e13/13_1222.webp", mc, "..Nnnnhhh..")
        scene 13_1223 with dissolve
        pause
        scene 13_1224 with dis1
        call Gulp (sar)
        scene 13_1225 with dis1
        pause
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
