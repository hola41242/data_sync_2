label MelanieReplay01:
    call Unlocker ("MelanieReplay01")
    if _in_replay:
        scene 02_0226 with Fade(0, 0, 3)
    else:
        $ Melanie.isSexual(True)
        scene 02_0226 with dissolve
    mel "Gabby, can you work the counter?"
    mel "I, err... need to show [persistent.McName] some paperwork."
    scene 02_0227 with dissolve
    gab "Paperwork??"
    scene 02_0228 with dissolve
    gab "You never showed the {i}other losers{/i} any paperwork."
    mel "Just go!"
    gab "I'm going!"
    scene 02_0229 with dissolve
    mel "Close the door, please."
    gab "[whi]Jeez!"
    scene 02_0230 with dissolve
    mel "Do you want to sit?"
    mel "I'm not sure it'll support your weight, to be honest.\nIt's not a very good chair."
    mc "I'll... just stand."
    mel "[whi]Okay."
    scene 02_0231 with Fade(1, 0.5, 1)
    mel "Do you, umm... want to get it out?\nOr would you like me to?"
    mc "Help yourself."
    mel "Okay."
    scene 02_0232 with Fade(1, 0.5, 0.5)
    pause
    scene 02_0233 with dissolve
    mel "Don't cum in my mouth. I don't like it."
    scene 02_0234 with dissolve
    pause  
    scene 02_0235 with dissolve
    pause 
    scene 02_0236 with dissolve
    pause
    scene 02_0237 with dissolve
    pause
    scene 02_0238 with dissolve
    pause
    scene 02_0239 with dissolve
    pause 1.0
    scene 02_0240 with dis1
    pause 0.5
    scene 02_0241 with dis1
    pause 0.5
    image r_mel_01 = Movie(play="images/e02/02_0242.webm")
    show r_mel_01
    mel "[ss]..Mmmhhh.."
    scene 02_0243 with dissolve
    mc "[whi]Damn.... You're good at that...."
    scene 02_0244 with dissolve
    pause 0.5
    scene 02_0245 with dissolve
    pause 0.5
    scene 02_0246
    pause 0.5
    image r_mel_02 = Movie(play="images/e02/02_0247.webm")
    show r_mel_02 with dis1
    mel "[ss]..Mmmhhh.."
    scene 02_0248 with dissolve
    mc "[ss]....Fuuuck...."
    scene 02_0249 with dissolve
    pause
    scene 02_0250 with dissolve
    mc "[ss]...A little more...."
    scene 02_0251 with dissolve
    mc "[ss]...Keep going...."
    scene 02_0252 with dissolve
    call Gag (mel)
    scene 02_0253 with dissolve
    mc "[ss]...That's it...."
    image r_mel_03 = Movie(play="images/e02/02_0254.webm")
    show r_mel_03 with dissolve
    mel "[ss]....Mmmhhh...."
    scene 02_0255 with dissolve
    mc "[ss]...Nnhhh..."
    scene 02_0256 with dis1
    pause 0.5
    scene 02_0257 with dis1
    pause 0.5
    scene 02_0258 with dissolve
    mct "Shit."
    $ g_w=False
    $ tCh=None
    if not EzModeActive:
        menu:
            "Let Melanie know Gabbys watching":
                pass
            "[wk_y]Don't say anything":
                $ tCh=True
    if tCh or Gabby.Has("EZ"):
        $ Gabby.Score(1)
        $ g_w=True
        $ Gabby.Add("Watch")
        pause 0.5
        scene 02_0266 with dissolve
        pause 1.0 
        image r_mel_04 = Movie(play="images/e02/02_0267.webm")
        show r_mel_04 with dissolve
        mel "[ss]....Mmmhhh...."
        scene 02_0268 with dissolve
        pause
    else:
        $ Melanie.Score(1)
        scene 02_0259 with dissolve
        mc "[whi]Uhh, we have an audience."
        scene 02_0260 with dissolve
        mel "[whi]Huh?"
        scene 02_0261 with dissolve
        mel "Jesus, {b}Gabby{/b}!!\nCLOSE THE DOOR!!"
        scene 02_0262 with dissolve
        pause 0.5
        scene 02_0263
        pause 0.5
        scene 02_0264 with dissolve
        mel "[whi]Damn it."
        scene 02_0265 with dissolve
        mel "[whi]Hurry up, I need to get back to work."
    scene 02_0269 with fade
    mel "[ss]..Mmmmhhh.."
    scene 02_0270 with dissolve
    image r_mel_05 = Movie(play="images/e02/02_0271.webm")
    show r_mel_05
    mel "[ss]....Mmmhhh...."
    if g_w==True:
        scene 02_0272 with dissolve
        pause
        scene 02_0273 with dissolve
        pause
        show r_mel_05
        mel "[ss]....Mmmhhh...."
    call CmOpts (["Cum on Melanie's face", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        mc "[ss]Fuck.... I'm gonna cum..."
        call CharCum ("e02/02_0274.webp", "e02/02_0283.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e02/02_0283.webp", "e02/02_0284.webp", mc, "...NNGGGHH!!...")
        scene 02_0285 with dissolve
        mc "[ss]Sorry... Heh."
        if g_w==True:
            scene 02_0286 with dissolve
            pause 1.0
            scene 02_0287 with dissolve
            pause 0.5
        scene 02_0288 with dissolve
        mel "I know there's a towel in here... somewhere!"
        scene 02_0289 with dissolve
        mel h "I can't let Gabby see me like this!"
        mel "Go ahead, tell her I'll be out in a minute."
        scene 02_0290 with Fade(2, 1, 1)
        if _in_replay:
            return
        pause 1.0
        scene 02_0291 with dissolve
        gab "Where's Mel?"
        mc "She'll be right out."
        scene 02_0292 with dissolve
        mc "She's... err... finishing up the paperwork."
        gab h "Yeah, whatever!"
        scene 02_0293 with dissolve
        if g_w==False:
            mc "I'll be back tomorrow.\nI can't give you guys any longer than that."
            gab "Okay."
        else:
            gab "Was she good?"
            mc "Good?"
            scene 02_0294 with dissolve
            gab "At sucking dick?"
            mc "Uhh..."
            mc "Yeah."
            scene 02_0295 with dissolve
            mc "Did you enjoy watching?"
            gab "Yeah."
            scene 02_0296 with dissolve
            gab "Why didn't you tell her I was there?"
            mc "Did you want me to?"
            gab h "No! She would've killed me!"
            scene 02_0297 with dissolve
            gab "You didn't answer me.\nWhy didn't you tell her?"
            mc "I didn't want to get you into trouble."
            scene 02_0298 with dissolve
            gab "Bullshit!"
            scene 02_0299 with dissolve
            gab "You {i}liked{/i} me watching, didn't you?"
            if not _in_replay:
                if Gabby.Has("EZ"):
                    $ Gabby.Score(1)
                    mc "Yeah, maybe I did."
                else:
                    menu:
                        "[wk_y]Yeah":
                            $ Gabby.Score(1)
                            mc "Yeah, maybe I did."
                        "No":
                            pass
            scene 02_0300 with dissolve
            gab "You didn't force her to do that, did you?"
            mc "No! It was her idea!"
            scene 02_0301 with dissolve
            gab "Okay, sorry. I had to ask."
            gab "You aren't the same as those other losers that usually collect."
            gab "I hope we only have to deal with you from now on."
            scene 02_0302 with dissolve
            mc "As long as you keep making the payments, I can keep the assholes away."
            gab "Got it."
            scene 02_0303 with dissolve
            mel "You're still here?"
            mc "I was just leaving."
            scene 02_0304 with dissolve
            gab "He was telling me how much he enjoyed going through the paperwork with you."
            mc "I'll be back in twenty-four hours."
            scene 02_0305 with dissolve
            gab "Your skin looks radiant today, Mel!\nAre you using a new face cream?"
    else:
        $ Melanie.Score(-2)
        $ Melanie.Add("CM")
        call CharCum ("e02/02_0274.webp", "e02/02_0275.webp", mc, "NNNGGGGGHHHH!!")
        scene 02_0276 with dissolve
        call Emotion (mel, "Spitting and coughing")
        scene 02_0277 with dissolve
        call Emotion (mel, "Spitting")
        scene 02_0278 with dissolve
        mel "WHAT THE FUCK?!"
        mel "I TOLD YOU {b}NOT{/b} TO DO THAT!"
        menu:
            "Apologize":
                $ Melanie.Score(1)
                mc "Crap, I'm sorry... You did such a great job, I couldn't control it!"
            "Don't apologize":
                mc "Get used to it, Sweetheart."
                mel "Asshole!"
                if g_w==True:
                    $ Gabby.Score(-2)
                    scene 02_0279 with dissolve
                    pause 1.0
                    scene 02_0280 with dissolve
                    pause 0.5
        scene 02_0281 with dissolve
        mel "Are we good? Can I get back to work now?"
        mc "Yeah."
        if _in_replay:
            scene black with ReplayFade
            return
        scene 02_0282 with Fade(2, 1, 1)
        mc "See you tomorrow."
        mel "Yes. Bye."
return

label MelanieReplay02:
    call Unlocker ("MelanieReplay02")
    if _in_replay:
        scene 05_0388 with Fade(0,1,2)
    else:
        $ persistent.MelanieRP02Dat=([Melanie.Has("CM"), Gabby.Has("Watch"), False, False])
        scene 05_0388 with dissolve
    mel "Come through."
    scene 05_0389 with dissolve
    mel "Remember the rule?"
    scene 05_0390 with dissolve
    mc "Yep.\nDon't cum in your mouth."
    if persistent.MelanieRP02Dat[0]:
        mel "Will you stick to it this time?"
        mc "Heh."
        scene 05_0391 with dissolve
        mel "Maybe you didn't want to cum on my face last time?"
    else:
        scene 05_0391 with dissolve
        mel "You messed up my make-up last time!"
    mel "What if I give you somewhere else to... {i}put it{/i}?"
    mc "Where do you have in mind?"
    scene 05_0392 with dissolve
    scene 05_0393 with dis1
    scene 05_0394 with dis1
    mel "Here."
    scene 05_0395 with dissolve
    mel "Does that work for you?"
    scene 05_0396 with dissolve
    mc "Yep."
    scene 05_0397 with dissolve
    mel "[ss]Mmhh."
    scene 05_0398 with dissolve
    mel "Okay then."
    scene 05_0399 with Fade(1, 0.5, 1)
    image r_mel_06 = Movie(play="images/e05/05_0400.webm")
    show r_mel_06
    mel "[ss]..Mmmhhh.."
    scene 05_0401 with dissolve
    mel "[ss]..Mhh.."
    scene 05_0402 with dissolve
    image r_mel_07 = Movie(play="images/e05/05_0403.webm")
    show r_mel_07
    pause
    scene 05_0404 with dissolve
    mct "Damn, she's good!"
    if persistent.MelanieRP02Dat[1]:
        scene 05_0405 with dissolve
        mct "Shame. Was hoping Gabby might peep again, heh."
        scene 05_0406 with dissolve
        mel "[ss]..Mmmhhh.."
        scene 05_0407 with dis1
        pause 0.5
        scene 05_0408 with dis1
        mct "Ahh, there she is."
        scene 05_0409 with dissolve
        mct "Guess she couldn't resist, heh."
        scene 05_0410 with dissolve
        image r_mel_08 = Movie(play="images/e05/05_0411.webm")
        show r_mel_08
        pause
    scene 05_0412 with dissolve
    mel "[ss]..Mmmhhh.."
    scene 05_0413 with dis1
    scene 05_0414 with dis1
    mel "[ss]..Nnhh.."
    scene 05_0415 with dissolve
    mel "Would you like to fuck my mouth a little?"
    scene 05_0416 with dissolve
    mc "Fuck your mouth?"
    if not _in_replay:
        if not EzModeActive:
            menu:
                "[wk_y]I'd like to fuck YOU a little!":
                    $ persistent.MelanieRP02Dat[2]=True
                    $ Melanie.Score(1)
                "Sure!":
                    $ persistent.MelanieRP02Dat[2]=False
        else:
            mc "I'd like to fuck YOU a little!"
            $ persistent.MelanieRP02Dat[2]=True
            $ Melanie.Score(1)
    if persistent.MelanieRP02Dat[2]==True:
        if _in_replay:
            mc "I'd like to fuck {b}you{/b} a little!"
        scene 05_0417 with dissolve
        mel "Oh, Honey, tempting... but that wasn't the deal!"
    else:
        if _in_replay:
            mc "Sure!"
    scene 05_0418 with fade
    mel "[ss]..Mmhh.."
    scene 05_0419 with dissolve
    image r_mel_09 = Movie(play="images/e05/05_0420.webm")
    show r_mel_09
    pause
    scene 05_0421 with dissolve
    image r_mel_10 = Movie(play="images/e05/05_0422.webm")
    show r_mel_10
    mel "[ss]..Mmmhhh.."
    if persistent.MelanieRP02Dat[1]:
        scene 05_0418 with dissolve
        pause 0.5
        scene 05_0423 with dis1
        scene 05_0424 with dissolve
        pause
    scene 05_0425 with dissolve
    image r_mel_11 = Movie(play="images/e05/05_0426.webm")
    show r_mel_11
    mel "[ss]..Mmmhhh.."
    if persistent.MelanieRP02Dat[1]:
        scene 05_0427 with dissolve
        pause
        scene 05_0428 with dissolve
        pause 0.5
        scene 05_0429 with dis1
        pause 0.5
        scene 05_0430 with dis1
        pause 0.5
        scene 05_0431 with dis1
        pause 0.5
        scene 05_0432 with dis1
        gab "[ss]Mmhh."
        scene 05_0433 with dissolve
        mct "Damn!"
        scene 05_0434 with dissolve
        gab "[whi][giggles]"
    else:
        scene 05_0435 with dissolve
        mct "...Fuuck..."
    scene 05_0436 with dissolve
    image r_mel_12 = Movie(play="images/e05/05_0437.webm")
    show r_mel_12
    mel "[ss]..NNNGGGHHH.."
    $ tmpimg=""
    if persistent.MelanieRP02Dat[1]:
        scene 05_0438 with dissolve
        image r_mel_13 = Movie(play="images/e05/05_0439.webm")
        show r_mel_13
        mel "[ss]..NNNGGGHHH.."
        $ tmpimg="e05/05_0438.webp"
    else:
        scene 05_0440 with dissolve
        image r_mel_14 = Movie(play="images/e05/05_0441.webm")
        show r_mel_14
        mel "[ss]..NNNGGGHHH.."
        $ tmpimg="e05/05_0440.webp"
    if not _in_replay and persistent.MelanieRP02Dat[0]:
        call CmOpts (["Cum in Melanie's mouth", "Pull out"])
        $ Copt=_return
        if Copt==0:
            $ Melanie.Add("CM2")
            $ persistent.MelanieRP02Dat[3]=True
        else:
            $ persistent.MelanieRP02Dat[3]=False
    call MelanieReplay02_Cum (persistent.MelanieRP02Dat[3], tmpimg)
    if _in_replay:
        scene black with ReplayFade
return

label MelanieReplay02_Cum(mouth, a):
    if mouth:
        call CharCum (a, "e05/05_0442.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e05/05_0442.webp", "e05/05_0443.webp", mc, "...NNGGGHH!...")
        scene 05_0444 with dissolve
        mc "Don't you spit it out."
        mc "Swallow it."
        scene 05_0445 with dissolve
        call Gulp (mel)
        scene 05_0446 with dis1
        scene 05_0447 with dis1
        mc "Good girl."
        scene 05_0448 with dissolve
        mel "Asshole! I {i}knew{/i} you were going to do that!"
    else:
        call CharCum (a, "e05/05_0449.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e05/05_0449.webp", "e05/05_0450.webp", mc, "...NNGGGHH!...")
        scene 05_0451 with dissolve
        mel "That was fun!"
    scene 05_0452 with fade
    mel "I'll get cleaned up.\nTell Gabby I'll be out in a few minutes."
    mc "Okay."
return

label MelanieReplay03(g=False):
    call Unlocker ("MelanieReplay03")
    if not _in_replay:
        $ Melanie.incSex()
        $ persistent.MelanieRP03Dat=([Gabby.Has("Watch"), g])
    if persistent.MelanieRP03Dat[1] and persistent.GroupSex:
        call GabbyReplay01
        return
    scene 13_0326 with dissolve
    mel "Come on through."
    scene 13_0327 with dis1
    scene 13_0328 with dis1
    scene 13_0329 with dis1
    mel "She's right, you know."
    mel "I do want to suck your dick again. To hell with our deal."
    scene 13_0330 with hpunch
    $ apause(.25)
    scene 13_0331 with dissolve
    mel "[ss]Mmhh."
    scene 13_0332 with dis1
    $ apause(h=False)
    scene 13_0333 with dis1
    $ apause()
    scene 13_0334 with dis1
    $ apause()
    scene 13_0335 with dis1
    $ apause(h=True)
    scene 13_0336 with dis1
    mc "[whi]Nice desk."
    scene 13_0337 with dissolve
    mel "[whi]Thanks."
    scene 13_0338 with dis1
    $ apause(h=False)
    scene 13_0339 with dis1
    $ apause()
    scene 13_0340 with dis1
    $ apause(h=True)
    scene 13_0341 with dis1
    mel "[ss]Nnhhh."
    scene 13_0342 with dis1
    $ apause(h=False)
    scene 13_0343 with dis1
    $ apause(h=True)
    scene 13_0344 with dis1
    scene 13_0345 with dissolve
    mel "[ss]Mmhhh."
    scene 13_0346 with dissolve
    image MelanieR03_01 = Movie(play="images/e13/13_0347.webm")
    show MelanieR03_01
    mel "[ss]Mmhhh."
    if persistent.MelanieRP03Dat[0]:
        scene 13_0348 with dissolve
        pause
    scene 13_0349 with dissolve
    image MelanieR03_02 = Movie(play="images/e13/13_0350.webm")
    show MelanieR03_02
    mel "[ss]..Mmmhhh.."
    scene 13_0351 with dissolve
    $ apause(h=False)
    scene 13_0352 with dis1
    $ apause(h=True)
    scene 13_0353 with dis1
    image MelanieR03_03 = Movie(play="images/e13/13_0354.webm")
    show MelanieR03_03
    mel "[ss]..Mmmhhh.."
    if persistent.MelanieRP03Dat[0]:
        scene 13_0355 with dissolve
        pause
        scene 13_0356 with dissolve
        pause
        scene 13_0357 with dissolve
        image MelanieR03_04 = Movie(play="images/e13/13_0358.webm")
        show MelanieR03_04
        mel "[ss]..Mhhh.."
    scene 13_0359 with dissolve
    image MelanieR03_05 = Movie(play="images/e13/13_0360.webm")
    show MelanieR03_05
    mel "[ss]..Mmmmhhh.."
    scene 13_0361 with dissolve
    scene 13_0362 with dis1
    scene 13_0363 with dis1
    scene 13_0364 with dis1
    mel "[ss]..Mhhh.."
    scene 13_0365 with dis1
    scene 13_0366 with dis1
    scene 13_0367 with dis1
    scene 13_0368 with dis1
    mel "[ss]..Mmmmhhh.."
    if persistent.MelanieRP03Dat[0]:
        scene 13_0369 with dissolve
        pause
        scene 13_0370 with dissolve
    else:
        scene 13_0371 with dissolve
    mel "[ss]..Mhhh.."
    scene 13_0372 with dissolve
    scene 13_0373 with dis1
    scene 13_0374 with dis1
    scene 13_0375 with dis1
    scene 13_0376 with dis1
    scene 13_0377 with dis1
    scene 13_0378 with dis1
    scene 13_0379 with dis1
    scene 13_0380 with dis1
    scene 13_0381 with dis1
    $ apause()
    scene 13_0382 with dis1
    mel "[ss]Fuuck..."
    scene 13_0383 with dissolve
    mel "[ss]..Mhhh.."
    if persistent.MelanieRP03Dat[0]:
        scene 13_0384 with dissolve
        pause
        scene 13_0385 with dissolve
        $ apause(h=False)
        scene 13_0386 with dis1
        $ apause()
        scene 13_0387 with dis1
        $ apause(h=True)
        scene 13_0388 with dis1
        gab "[ss]Mmhh."
        scene 13_0389 with dissolve
        pause
    scene 13_0390 with dissolve
    image MelanieR03_06 = Movie(play="images/e13/13_0391.webm")
    show MelanieR03_06
    call Moan (mel, 4)
    scene 13_0392 with dissolve
    mel "[ss]..Ohhhhh.."
    scene 13_0393 with dissolve
    pause
    if persistent.MelanieRP03Dat[0]:
        scene 13_0398 with dissolve
    else:
        scene 13_0399 with dissolve
    call Moan (mel, 4)
    scene 13_0400 with fadehold
    pause
    scene 13_0402 with dissolve
    image MelanieR03_07 = Movie(play="images/e13/13_0403.webm", loop=False, keep_last_frame=True)
    show MelanieR03_07
    call Moan (mel, 4)
    scene 13_0406 with dissolve
    image MelanieR03_08 = Movie(play="images/e13/13_0407.webm")
    show MelanieR03_08
    call Moan (mel, 4)
    scene 13_0408 with dissolve
    mel "[ss]..Ohhhhh.."
    if persistent.MelanieRP03Dat[0]:
        scene 13_0410 with dissolve
        pause
    scene 13_0413 with dissolve
    mel "[ss]....Ohhhhhhh...."
    scene 13_0411 with dissolve
    image MelanieR03_09 = Movie(play="images/e13/13_0412.webm")
    show MelanieR03_09
    call Moan (mel)
    scene 13_0436 with dissolve
    image MelanieR03_10 = Movie(play="images/e13/13_0437.webm")
    show MelanieR03_10
    call Moan (mel)
    scene 13_0440 with dissolve
    image MelanieR03_11 = Movie(play="images/e13/13_0441.webm")
    show MelanieR03_11
    call Moan (mel)
    scene 13_0482 with dissolve
    mel "[ss]...Fuck......Yes....."
    scene 13_0483 with dissolve
    mc "[whi]Come here."
    call MelanieReplay03_P2
return

label MelanieReplay03_P2:
    scene 13_0484 with dissolve
    mel "[ss]Mmh."
    scene 13_0485 with dissolve
    $ apause()
    scene 13_0486 with dis1
    scene 13_0487 with dis1
    scene 13_0488 with dissolve
    image MelanieR03_12 = Movie(play="images/e13/13_0489.webm")
    show MelanieR03_12
    mel "[ss]..Ohhhhh.."
    scene 13_0490 with dissolve
    mel "[ss]..Ohhh....[persistent.McName], yes....."
    scene 13_0491 with dissolve
    image MelanieR03_13 = Movie(play="images/e13/13_0492.webm")
    show MelanieR03_13
    call Moan (mel)
    scene 13_0493 with dissolve
    mel "[ss]..I knew we'd end up fucking...."
    scene 13_0494 with dissolve
    mel "[ss]....From the moment I put your dick in my mouth, I've craved it..."
    scene 13_0495 with dissolve
    image MelanieR03_14 = Movie(play="images/e13/13_0496.webm")
    show MelanieR03_14
    mel "[ss]...FUCK......OHHHHH.......YESS..."
    scene 13_0497 with dissolve
    image MelanieR03_15 = Movie(play="images/e13/13_0498.webm")
    show MelanieR03_15
    call Moan (mel, 8)
    scene 13_0499 with dissolve
    image MelanieR03_16 = Movie(play="images/e13/13_0500.webm")
    show MelanieR03_16
    call Moan (mel, 8)
    scene 13_0501 with dissolve
    image MelanieR03_17 = Movie(play="images/e13/13_0502.webm")
    show MelanieR03_17
    mel "[ss]...GOD....YES...."
    mel "[ss]...OHHHH.....YESS...."
    call CharCum ("e13/13_0501.webp", "e13/13_0503.webp", mel, "..OHHHHH..")
    call CharCum ("e13/13_0503.webp", "e13/13_0504.webp", mel, "...Mmmmhhhhh...")
    scene 13_0505 with dissolve
    image MelanieR03_18 = Movie(play="images/e13/13_0506.webm")
    show MelanieR03_18
    mel "[ss]...Mmmmhh..."
    call CmOpts (["Cum inside Melanie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Melanie.incCm()
        call CharCum ("e13/13_0505.webp", "e13/13_0507.webp", mc, "...Nnnggghh...")
        call CharCum ("e13/13_0507.webp", "e13/13_0508.webp", mc, "..Nnnnhhh..")
        scene 13_0513 with dissolve
        pause
        scene 13_0514 with dissolve
        mel "Don't be angry, but... I lied to you - I {b}do{/b} have all the cash!"
        mc "Yeah, I know."
        scene 13_0515 with dissolve
    else:
        call CharCum ("e13/13_0505.webp", "e13/13_0509.webp", mc, "...Nnnggghh...")
        call CharCum ("e13/13_0509.webp", "e13/13_0510.webp", mc, "..Nnnnhhh..")
        scene 13_0511 with dissolve
        pause
        scene 13_0512 with dissolve
        mel "Don't be angry, but... I lied to you - I {b}do{/b} have all the cash!"
        mc "Yeah, I know."
        scene 13_0516 with dissolve
    mel "So, next time, we don't need to pretend this is just a part of our agreement?"
    mc "Right."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
