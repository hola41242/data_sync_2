label AlyshaReplay01:
    call Unlocker ("AlyshaReplay01")
    if _in_replay:
        scene 20_0372 with dissolve
        aly "Thanks for caring about me.\nI'd almost forgotten what that was like."
        mc "Of course I care about you!\nWe're partners... We're {b}friends{/b}, aren't we?!"
        scene 20_0373 with dissolve
    else:
        $ persistent.AlyshaRP01Dat=(Alysha.Has("A00") and persistent.Incest)
    aly "Yeah, {i}friends{/i}... for now."
    scene 20_0379 with dissolve
    aly "But the minute this is over...\nDamn, I hope you're planning to fuck me all night long."
    scene 20_0380 with dissolve
    aly "[whi]Mmh."
    scene 20_0381 with dissolve
    aly "[whi]..Mmmhh.."
    scene 20_0382 with dis1
    scene 20_0383 with dis1
    scene 20_0384 with dis1
    aly "[whi]Mmhhh."
    scene 20_0385 with dissolve
    aly "[whi]Mmh."
    scene 20_0386 with dissolve
    aly "[whi]..Mmmhh.."
    scene 20_0387 with dissolve
    call EmotionSml (aly, "Sigh", "Goddamn... You make me so fuckin' horny.")
    scene 20_0388 with dissolve
    aly "Wanna see my tits again?"
    mc "Hell yeah."
    scene 20_0389 with dis1
    scene 20_0390 with dis1
    scene 20_0391 with dis1
    scene 20_0392 with dis1
    aly "You like?"
    scene 20_0393 with dissolve
    mc "Like?"
    scene 20_0394 with dissolve
    mc "Nah..."
    scene 20_0395 with dis1
    mc "I love!"
    scene 20_0396 with dis1
    aly "[ss]Mhhh."
    scene 20_0397 with dissolve
    pause
    scene 20_0398 with dissolve
    pause
    scene 20_0399 with dissolve
    pause
    scene 20_0400 with dis1
    aly "[whi][kiss]"
    scene 20_0401 with dis1
    pause 0.5
    scene 20_0402 with dis1
    aly "[whi][kiss]"
    scene 20_0403 with dis1
    pause 0.5
    scene 20_0404 with dis1
    aly "[ss]Mmmhh.."
    scene 20_0405 with dissolve
    pause 0.5
    scene 20_0406 with dis1
    aly "[ss]Mhhh."
    scene 20_0407 with dissolve
    mc "[whi]Alysha... What you doin'?"
    mc "[whi]It's important to you that we don't have sex until we're done with the case... So stop.\nWe can wait."
    aly "[whi]We're not having sex, [persistent.McName]."
    aly "[whi]I {b}am{/b} gonna suck your dick, though."
    scene 20_0408 with dissolve
    aly "[whi]Today you showed me how much you care for me."
    aly "[whi]Now I'm gonna show you how much I care for you, too."
    scene 20_0409 with dissolve
    aly "[whi]Baby, I'm so horny for you right now.\nIf I don't put it in my mouth, it's gonna end up in my pussy."
    scene 20_0410 with dissolve
    aly "[ss]Mhhh."
    scene 20_0411 with dissolve
    image AlyshaR01_01 = Movie(play="images/e20/20_0412.webm")
    show AlyshaR01_01
    pause
    scene 20_0413 with dis1
    scene 20_0414 with dis1
    scene 20_0415 with dis1
    scene 20_0416 with dissolve
    pause
    scene 20_0417 with dissolve
    image AlyshaR01_02 = Movie(play="images/e20/20_0418.webm", loop=False, keep_last_frame=True)
    image AlyshaR01_03 = Movie(play="images/e20/20_0419.webm")
    pause
    show AlyshaR01_02
    pause 2.9
    show AlyshaR01_03
    aly "[ss]Mhhh."
    scene 20_0420 with dissolve
    image AlyshaR01_04 = Movie(play="images/e20/20_0421.webm")
    show AlyshaR01_04
    mc "[whi]Fuuck."
    scene 20_0422 with dissolve
    pause 0.5
    scene 20_0423 with dis1
    pause 0.5
    scene 20_0424 with dissolve
    image AlyshaR01_05 = Movie(play="images/e20/20_0425.webm")
    show AlyshaR01_05
    pause
    scene 20_0426 with dissolve
    image AlyshaR01_06 = Movie(play="images/e20/20_0427.webm")
    show AlyshaR01_06
    aly "[ss]..Mmmhhh.."
    scene 20_0428 with dissolve
    image AlyshaR01_07 = Movie(play="images/e20/20_0429.webm")
    show AlyshaR01_07
    pause
    scene 20_0430 with dissolve
    image AlyshaR01_08 = Movie(play="images/e20/20_0431.webm")
    show AlyshaR01_08
    call Moan (aly)
    scene 20_0432 with dissolve
    image AlyshaR01_09 = Movie(play="images/e20/20_0433.webm")
    show AlyshaR01_09
    aly "[ss]Mhhh."
    scene 20_0434 with dissolve
    aly "[ss]..Mmmhhh.."
    scene 20_0435 with dissolve
    image AlyshaR01_10 = Movie(play="images/e20/20_0436.webm")
    show AlyshaR01_10
    aly "[whi]I just realized I'm grinding against you like a dog in heat.\nYou don't mind, do you?"
    mc "[whi]Grind away, Sweetheart."
    if persistent.AlyshaRP01Dat:
        scene 20_0437 with dissolve
        aly "[whi]Your hot niece still sending you her pictures?"
        mc "[whi]Uhh... Yeah.\nWhy?"
        scene 20_0438 with dissolve
        aly "[whi]Just curious, Baby."
        scene 20_0439 with dissolve
        aly "[whi]Do you keep them, or delete them?"
        mc "[whi]Keep 'em."
        scene 20_0440 with dissolve
        aly "[whi]Nice."
        mc "[whi]What's with the questions?"
        aly "[whi]No reason. It's cute, that's all!"
        scene 20_0441 with dissolve
        aly "[whi]..."
        aly "[whi]Okay..."
        aly "[whi]If you want the truth... Don't judge me, but I find it hot."
        scene 20_0442 with dis1

        scene 20_0443 with dis1
        aly "[whi]... I used to do something similar."
        scene 20_0444 with dis1
        mc "[whi]You used to send photos to your uncle?"
    scene 20_0445 with dis1
    image AlyshaR01_11 = Movie(play="images/e20/20_0446.webm")
    show AlyshaR01_11
    aly "[ss]..Mmmhhh.."
    scene 20_0447 with dissolve
    image AlyshaR01_12 = Movie(play="images/e20/20_0448.webm")
    show AlyshaR01_12
    aly "[ss]Mmmhh."
    mc "[whi]Fuck... I'm gonna cum... Keep goin'..."
    scene 20_0449 with dissolve
    image AlyshaR01_13 = Movie(play="images/e20/20_0450.webm")
    show AlyshaR01_13
    aly "[ss]..Mmmhh.."
    call CharCum ("e20/20_0449.webp", "e20/20_0451.webp", mc, "..Nnnnnggghhhh...")
    call CharCum ("e20/20_0451.webp", "e20/20_0452.webp", mc, "...Nnnnhhh...")
    call Gag (aly)
    scene 20_0453 with dissolve
    call Gag (aly)
    scene 20_0454 with dissolve
    mc "[whi]Sorry... Got a little carried away."
    scene 20_0455 with dissolve
    aly "[whi]Oh Baby, don't apologize for enjoying my blowjob!"
    aly "[whi]You could choke me with your dick, and I'd die a happy girl."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
