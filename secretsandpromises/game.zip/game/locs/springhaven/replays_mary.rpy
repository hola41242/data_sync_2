label MaryReplay01_Part01:
    if _in_replay:
        scene black
        pause 1.0
        scene 01_0406 with fade
        pause 1.0
        scene 01_0407 with dissolve
        mct "Ughh..."
        mct "... So tired, must've dozed off."
        play sound "creak.mp3" volume 0.5
        "{size=*0.5}*Creak* {w=0.5}{nw}"
        scene 01_0408 with dissolve
        mc "[whi]Huh?"
        scene 01_0409 with dissolve
        pause 0.5
        scene 01_0410 with dissolve
        mct "Was that... Mary?"
        scene 01_0413 with dissolve
        pause 1.0
        scene 01_0414 with dissolve
        pause 2.0
        scene 01_0415 with dissolve
        pause 1.0
        scene 01_0416 with dissolve
        pause 1.0
        scene 01_0417 with dissolve
        pause 1.0
        scene 01_0418 with dissolve
        pause 1.0
        scene 01_0419 with dissolve
        mar "{size=*.6}{font=Vanilla.ttf}*{i}Gasp{/i}*"
        scene 01_0421 with dissolve
        mar "[whi]Oh, my..."
        scene 01_0425 with dissolve
        mct "What the hell am I doing?!"
        scene 01_0426 with dissolve
        pause 1.0
        scene 01_0427 with dissolve
        pause 1.0
        scene 01_0425 with dissolve
        mct "Fuck it!\nIf she wants to peep, I'll give her a show..."
        scene 01_0428 with dissolve
        pause 0.5
        scene 01_0429 with dis1
        pause 0.5
        scene 01_0430 with dissolve
        mar "{size=*.6}{font=Vanilla.ttf}*{i}GASP{/i}*"
    call Loop_Dissolve (4, True, False, "e01/01_0432.webp", "e01/01_0433.webp")
    scene 01_0434 with dissolve
    call Emotion (mar, "Breathing heavily", "")
    scene 01_0435 with dissolve
    mct "Damn! Knowing she's watching is turning me on!"
    scene 01_0436 with dissolve
    pause 2.0
    scene 01_0437 with dissolve
    pause 1.0
    scene 01_0438 with dis1
    pause 1.5
    scene 01_0439 with dissolve
    pause 1.0
    scene 01_0440 with dis1
    pause 1.0
    scene 01_0441 with dis1
    call Moan (mar)
    call Loop_Dissolve (4, True, False, "e01/01_0442.webp", "e01/01_0443.webp")
    scene 01_0444 with dissolve
    mct "Holy shit! Is she...?!"
    scene 01_0445 with dissolve
    pause 1.0
    scene 01_0446 with dis1
    pause 1.0
    scene 01_0447 with hpunch
    pause 0.5
    scene 01_0448 with dissolve
    pause 1.0
    if not _in_replay:
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]Don't say anything":
                    $ tCh=True
                "Ask her to join you on the bed":
                    pass
        if tCh or Mary.Has("EZ"):
            $ Mary.Add("stay")
            jump MaryReplay01_Part02
        else:
            $ Mary.Add("Ran")
            $ Mary.Score(-1)
            scene 01_0449 with dissolve
            mc "Wanna come and lie down with me?"
            scene 01_0450 with dissolve
            pause 0.5
            scene 01_0451 with dissolve
            pause 1.0
            return
return

label MaryReplay01_Part02(v=False):
    call Unlocker ("MaryReplay01_Part02")
    if _in_replay:
        scene black
        menu:
            "Play Original Version":
                call MaryReplay01_Part01
            "Play Re-Rendered Version":
                jump MaryReplay01_Redone
    else:
        if v:
            jump MaryReplay01_Redone
    call Loop_Dissolve (3, True, False, "e01/01_0452.webp", "e01/01_0448.webp")
    scene 01_0453 with dissolve
    pause 0.5
    scene 01_0454 with dis1
    pause 0.5
    scene 01_0455 with dis1
    pause 1.0
    call Loop_Dissolve (3, True, False, "e01/01_0456.webp", "e01/01_0457.webp")
    scene 01_0458 with dissolve
    pause 1.0
    scene 01_0459 with dis1
    pause 1.0
    scene 01_0460 with dis1
    pause 1.0
    call Loop_Dissolve (4, True, False, "e01/01_0461.webp", "e01/01_0462.webp")
    scene 01_0463 with dissolve
    pause 1.0
    scene 01_0464 with dis1
    pause 1.0
    scene 01_0465 with dis1
    pause 1.0
    scene 01_0466 with dissolve
    pause 1.0
    scene 01_0467 with dis1
    pause 1.0
    scene 01_0468 with dis1
    call Moan (mar)
    scene 01_0469 with dis1
    pause 1.0
    scene 01_0470 with dis1
    pause 1.0
    scene 01_0471 with dis1
    pause 0.5
    scene 01_0472 with dissolve
    pause 0.5
    scene 01_0473 with dis1
    pause 0.5
    scene 01_0474 with dis1
    pause 0.5
    scene 01_0475 with dis1
    mar "[mo]{size=*0.5}*Moan*{w=1.0}{nw}"
    call Loop_Dissolve (4, True, False, "e01/01_0476.webp", "e01/01_0477.webp")
    call Loop_Dissolve (6, False, False, "e01/01_0478.webp", "e01/01_0479.webp")
    scene 01_0480 with dis1
    scene 01_0481 with dis1
    scene 01_0482 with dissolve
    mar "[ss]..OHHHHHHHH..."
    scene 01_0483 with dissolve
    call Moan (mar)
    scene 01_0484 with dis1
    mar "[ss]....OHHHH....."
    call Loop_Dissolve (6, False, False, "e01/01_0485.webp", "e01/01_0486.webp")
    scene 01_0487 with dissolve
    call Moan (mar)
    scene 01_0488 with dissolve
    mar "[ss]....It feels so good....."
    scene 01_0489 with dissolve
    mar "[ss]..Ohh, I'm all wet..."
    scene 01_0490 with dis1
    pause 0.5
    scene 01_0491 with dis1
    pause 0.5
    scene 01_0492 with dis1
    mar "[ss]Mmmhhhh, it tastes nice....."
    scene 01_0493 with dissolve
    pause 0.5
    scene 01_0494 with dis1
    call CharCum ("e01/01_0494.webp", "e01/01_0495.webp", mc, "NNNGGGGGHHHH!!")
    call CharCum ("e01/01_0495.webp", "e01/01_0496.webp", mc, "...Fuuuck...")
    scene 01_0497 with dissolve
    mar "[whi][giggles]"
    scene 01_0498 with dissolve
    pause 0.5
    scene 01_0499 with dis1
    pause 0.5
    scene 01_0500 with dis1
    mar h "[whi]I've never seen a guy do that before!"
    scene 01_0501 with dis1
    mar "[kiss]"
    scene 01_0502 with dissolve
    mar "[whi]Night, Daddy."
    scene 01_0503 with dissolve
    mct "What the hell was that?!\nGuess I'd better clean up and get some sleep."
    scene black with Fade(2, 0, 0)
return

label MaryReplay02_Part01:
    if _in_replay:
        scene 03_0403 with Fade(0,0, 3)
    else:
        if Mary.Has("Cell"):
            $ persistent.MaryRP02Dat=True
        scene 03_0403 with dissolve
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    mar "Night."
    mc "Night, Mary."
    $ aP(True)
    scene 03_0404 with dissolve
    $ apause()
    scene 03_0405 with dissolve
    $ apause()
    scene 03_0406 with dis1
    $ apause(0.5, True)
    scene 03_0407 with dis1
    mct "Old TV... Given me a damn headache!"
    scene 03_0408 with dis1
    mct "Hmm, should probably close the door this time."
    $ aP(True)
    scene 03_0409 with dis1
    $ apause()
    scene 03_0410 with dis1
    if not _in_replay:
        $ apause()
        scene 03_0411 with dis1
        $ apause()
        if not Mary.isActive():
            scene 03_0359 with dissolve
            $ apause(1.0, True)
            return
        else:
            scene 03_0412 with dissolve
            $ aP(False)
            if not EzModeActive:
                menu:
                    "Close the door[wk_c]":
                        call CloseCharacterPath (Mary, "Mary")
                        scene 03_0359 with dissolve
                        $ apause(1.0)
                        return
                    "[wk_y]Leave the door open":
                        pass
    else:
        $ apause(0.5, False)
        scene 03_0411 with dis1
        mct "Or maybe..."
        scene 03_0412 with dissolve
        mct "... I'll leave it open."
    scene 03_0413 with dis1
    scene 03_0414 with dis1
    mct "Damn, she {b}does{/b} look good in her new nightie!"
    $ aP(True)
    scene 03_0415 with Fade(1, 0.5, 1)
    $ apause()
    scene 03_0416 with Fade(1, 0.5, 1)
    $ apause()
    scene 03_0417 with Fade(1, 0.5, 1)
    $ apause()
    scene 03_0418 with Fade(1, 0.5, 1)
    $ apause(1.0, True)
    scene 03_0420 with dissolve
    mct "Here we go again, heh."
    call Loop_Dissolve (6, True, False, "e03/03_0419.webp", "e03/03_0420.webp")
    scene 03_0421 with dis1
    $ apause(1.0, False)
    scene 03_0422 with dissolve
    $ apause()
    scene 03_0423 with dis1
    $ apause(1.0, True)
    scene 03_0424 with dissolve
    mar "[whi]Is it okay if I sit here?"
    mc "[whi]Yeah."
    call Loop_Dissolve (6, True, False, "e03/03_0425.webp", "e03/03_0426.webp")
    scene 03_0427 with dissolve
    mar "I love watching you do that. It makes me feel all tingly."
    call Loop_Dissolve (6, True, False, "e03/03_0428.webp", "e03/03_0429.webp")
    scene 03_0430 with dissolve
    mar "Can I lie down with you, [petn]?"
    mc "Sure."
    scene 03_0431 with dissolve
    $ apause(1.0, False)
    scene 03_0432 with dissolve
    $ apause()
    scene 03_0433 with dis1
    $ apause(1.0, True)
    call Loop_Dissolve (6, True, False, "e03/03_0434.webp", "e03/03_0435.webp")
    scene 03_0436 with dissolve
    if persistent.MaryDaddy:
        mar "[whi]Daddy..."
    mar "[whi]Can I... help?"
    mc "[whi]Okay."
    scene 03_0437 with dis1
    pause 
    $ aP(True)
    call Loop_Dissolve (5, True, False, "e03/03_0438.webp", "e03/03_0439.webp")
    call Loop_Dissolve (2, True, False, "e03/03_0437.webp", "e03/03_0440.webp")
    scene 03_0441 with dis1
    scene 03_0442 with dis1
    call Loop_Dissolve (3, True, False, "e03/03_0443.webp", "e03/03_0444.webp")
    scene 03_0445 with dis1
    scene 03_0446 with dis1
    call Loop_Dissolve (3, True, False, "e03/03_0447.webp", "e03/03_0448.webp")
    $ aP(False)
    scene 03_0449 with dissolve
    if persistent.MaryRP02Dat:
        mar "It's just like the dream I had!"
    else:
        mar "It feels funny!"
    scene 03_0450 with dissolve
    image r_mary_001 = Movie(play="images/e03/03_0451.webm")
    show r_mary_001
    pause
    if not _in_replay:
        if Mary.Has("L0"):
            call CharCum ("e03/03_0450.webp", "e03/03_0452.webp", mc, "Nnnnggghhh")
            call CharCum ("e03/03_0452.webp", "e03/03_0453.webp", mc, "..Nnnhhhh...")
            scene 03_0454 with dissolve
            mar "I made it explode!"
            scene 03_0455 with dissolve
            mar "Whoa! It's warm!"
            scene 03_0456 with dissolve
            mar "You're so much fun!"
            scene 03_0457 with dissolve
            mar "[kiss]"
            scene 03_0456 with dissolve
            mar "[giggles]"
            scene 03_0458 with dissolve
            "Night, [petn]."
            mc "Goodnight, Mary."
            scene 03_0459 with dissolve
            pause
            scene 03_0460 with dissolve
            mar "[whi]Mmmm."
        else:
            call MaryReplay02_Part02
    if not _in_replay:
        scene black with ReplayFade
return

label MaryReplay01_Redone:
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    if _in_replay:
        scene black
        pause 1.0
        scene 09_0461 with fade
        pause 1.0
        scene 09_0462 with dissolve
        mct "Ughh..."
        mct "... So tired, must've dozed off."
        play sound "creak.mp3" volume 0.5
        "{size=*0.5}*Creak* {w=0.5}{nw}"
        scene 09_0463 with dissolve
        mc "[whi]Huh?"
        scene 01_0409 with dissolve
        pause 0.5
        scene 01_0410 with dissolve
        mct "Was that... Mary?"
        scene 09_0464 with dissolve
        pause 1.0
        scene 01_0414 with dissolve
        mct "She still there?"
        scene 09_0465 with dissolve
        pause 1.0
        scene 09_0466 with dissolve
        pause 1.0
        scene 09_0467 with dissolve
        pause 1.0
        scene 09_0468 with dissolve
        pause
        scene 09_0467 with dissolve
        scene 09_0469 with dissolve
        mar "{size=*.6}{font=Vanilla.ttf}*{i}Gasp{/i}*"
        scene 09_0471 with dissolve
        mar "[whi]Oh, my..."
        scene 09_0472 with dissolve
        mct "Heh... What the hell am I doing?"
        scene 09_0473 with dissolve
        pause 1.0
        scene 09_0474 with dissolve
        pause
        scene 09_0472 with dissolve
        mct "Fuck it!\nIf she wants to peep, I'll give her a show..."
        scene 09_0475 with dissolve
        pause 0.5
        scene 09_0476 with dis1
        pause 0.5
        scene 09_0477 with dissolve
        mar "{size=*.6}{font=Vanilla.ttf}*{i}GASP{/i}*"
    call Loop_Dissolve (4, True, False, "e09/09_0478.webp", "e09/09_0479.webp")
    scene 09_0480 with dissolve
    call Emotion (mar, "Breathing heavily", "")
    call Loop_Dissolve (3, True, False, "e09/09_0481.webp", "e09/09_0482.webp")
    mct "Damn... Knowing she's watching is turning me on."
    scene 09_0483 with dissolve
    pause
    scene 09_0481 with dissolve
    pause 1.0
    scene 09_0484 with dis1
    pause 1.0
    scene 09_0485 with dis1
    pause 1.0
    scene 09_0486 with dis1
    pause 1.0
    scene 09_0487 with dissolve
    pause
    scene 09_0488 with dis1
    pause 0.5
    scene 09_0489 with dis1
    pause 0.5
    scene 09_0490 with dis1
    call Moan (mar)
    call Loop_Dissolve (4, True, False, "e09/09_0491.webp", "e09/09_0492.webp")
    scene 09_0493 with dissolve
    mct "Holy shit! Is she...?!"
    scene 09_0494 with dissolve
    pause 1.0
    scene 09_0495 with dis1
    pause 1.0
    scene 09_0496 with hpunch
    pause 0.5
    scene 09_0497 with dissolve
    pause 1.0
    if not _in_replay and not EzModeActive:
        menu:
            "[wk_y]Don't say anything":
                $ Mary.Add("stay")
            "Ask her to join you on the bed":
                $ Mary.Add("Ran")
                $ Mary.Score(-1)
                scene 01_0449 with dissolve
                mc "Wanna come and lie down with me?"
                scene 01_0450 with dissolve
                pause 0.5
                scene 01_0451 with dissolve
                pause 1.0
                return
    $ Mary.isSexual(True)
    call Loop_Dissolve (3, True, False, "e09/09_0498.webp", "e09/09_0497.webp")
    scene 09_0496 with dissolve
    pause 0.5
    scene 09_0499 with dis1
    pause 0.5
    call Loop_Dissolve (4, True, False, "e09/09_0500.webp", "e09/09_0501.webp")
    scene 09_0502 with dissolve
    pause 1.0
    scene 09_0503 with dis1
    pause 1.0
    scene 09_0504 with dis1
    pause 1.0
    scene 09_0505 with dis1
    pause 1.0
    scene 09_0506 with dissolve
    image r_mary_026 = Movie(play="images/e09/09_0507.webm")
    show r_mary_026
    pause
    scene 09_0508 with dissolve
    pause
    scene 09_0509 with dis1
    pause 1.0
    scene 09_0510 with dis1
    pause 1.0
    scene 09_0511 with dis1
    call Moan (mar)
    scene 09_0512 with dissolve
    image r_mary_027 = Movie(play="images/e09/09_0513.webm")
    show r_mary_027
    mar "[ss]..Ohh.."
    scene 09_0511 with dissolve
    pause 1.0
    scene 09_0514 with dis1
    pause 1.0
    scene 09_0515 with dis1
    scene 09_0516 with dis1
    scene 09_0517 with dis1
    pause 0.5
    scene 09_0518 with dis1
    pause 0.5
    scene 09_0519 with dis1
    pause 0.5
    scene 09_0520 with dis1
    scene 09_0521 with dis1
    image r_mary_028 = Movie(play="images/e09/09_0522.webm")
    show r_mary_028
    call Moan (mar)
    scene 09_0523 with dis1
    image r_mary_029 = Movie(play="images/e09/09_0524.webm")
    show r_mary_029
    mar "[ss]..MMMHHHH.."
    scene 09_0525 with dissolve
    image r_mary_030 = Movie(play="images/e09/09_0526.webm")
    show r_mary_030
    call Moan (mar)
    scene 09_0527 with dissolve
    mar "[ss]..OHHHHHHHH..."
    scene 09_0528 with dissolve
    scene 09_0529 with dis1
    pause 0.5
    call Loop_Dissolve (6, True, False, "e09/09_0530.webp", "e09/09_0531.webp")
    call Moan (mar)
    scene 09_0532 with dissolve
    mar "[ss]....It feels good, [petn]....."
    scene 09_0533 with dissolve
    mar "[ss]..Gosh, I'm sooo wet..."
    scene 09_0534 with dis1
    pause 0.5
    scene 09_0535 with dis1
    pause 0.5
    scene 09_0536 with dis1
    mar "[ss]Mmmhhhh, I taste nice....."
    scene 09_0537 with dissolve
    pause 0.5
    call CharCum ("e09/09_0538.webp", "e09/09_0539.webp", mc, "..Fuuuck..")
    call CharCum ("e09/09_0539.webp", "e09/09_0540.webp", mc, "..Nnnggghhh..")
    scene 09_0541 with dissolve
    mar h "Holy cow!"
    scene 09_0542 with dissolve
    pause 0.5
    scene 09_0543 with dis1
    mar h "I've never seen a guy do that before!"
    scene 09_0544 with dis1
    mar "[whi]Goodnight, [petn]."
    scene 09_0545 with dissolve
    mar "[kiss]"
    scene 09_0546 with dis1
    scene 09_0547 with dis1
    scene 09_0548 with dis1
    scene 09_0549 with dis1
    scene 09_0550 with dis1
    scene 09_0551 with dis1
    pause
    scene 09_0552 with dissolve
    mar "[whi]Mmmm."
    scene 09_0553 with dissolve
    mar h "You taste nice, too!"
    scene 09_0554 with dissolve
    pause 0.5    
    scene 09_0555 with dissolve
    mct "What the hell was that?\nGuess I'd better clean up and get some sleep."
    scene black with Fade(2, 0, 0)
return

label MaryReplay02_Part02:
    call Unlocker ("MaryReplay02_Part02")
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    if _in_replay:
        call MaryReplay02_Part01
    scene 03_0461 with dissolve
    $ Mary.isSexual(True)
    mar "I saw a video clip once... My friend showed it to me."
    scene 03_0462 with dissolve
    mar "The girl in it was... kissing, uhh..."
    scene 03_0463 with dissolve
    mar "{i}This{/i}."
    scene 03_0464 with dissolve
    mar "She was lying on top of the boy, and {i}he{/i} was kissing her... umm..."
    scene 03_0465 with dissolve
    mar "I'm not sure why, really... But it looked kinda fun."
    mc "Uhh... Did {i}you{/i} want to try that?"
    scene 03_0466 with dissolve
    mar "What? No! I wasn't asking you to kiss {i}my{/i}... "
    mar "..."
    scene 03_0467 with dissolve
    mar "I, uhh... don't think you'll want to, [petn]. It's a bit... wet."
    mc "Let's try it anyway."
    scene 03_0468 with dissolve
    mar "[whi]Okay."
    scene 03_0469 with fade
    mar "Umm... So, I have to... climb on top of you..."
    scene 03_0470 with dis1
    scene 03_0471 with dis1
    mar "I think it was something like this."
    scene 03_0472 with dissolve
    scene 03_0473 with dis1
    mc "Looks perfect to me."
    scene 03_0474 with dissolve
    pause
    scene 03_0475 with dissolve
    mar "This feels weird."
    $ aP(True)
    scene 03_0476 with dissolve
    $ apause()
    scene 03_0477 with dis1
    mc "[kiss]"
    scene 03_0478 with dissolve
    $ apause()
    scene 03_0479 with dis1
    $ apause(0.5, True)
    scene 03_0480 with dis1
    call Emotion (mar, "GASP")
    scene 03_0481 with dissolve
    mar "[ss]Holy F......... iddlesticks!"
    scene 03_0482 with dissolve
    pause
    scene 03_0483 with dissolve
    mar "[ss]..OHHH..."
    scene 03_0484 with dissolve
    mar "[ss]..OHH MY!..."
    scene 03_0485 with dissolve
    call Moan (mar)
    call Loop_Dissolve (6, False, False, "e03/03_0486.webp", "e03/03_0487.webp")
    scene 03_0488 with dissolve
    call Moan (mar)
    scene 03_0489 with dissolve
    mar "[ss]Mmmhhh."
    $ aP(True)
    scene 03_0490 with dis1
    $ apause()
    scene 03_0491 with dis1
    $ apause()
    scene 03_0492 with dis1
    $ apause()
    scene 03_0493 with dis1
    mar "[kiss]"
    scene 03_0494 with dis1
    $ apause()
    scene 03_0495 with dis1
    mar "[kiss]"
    scene 03_0496 with dis1
    $ apause()
    scene 03_0497 with dis1
    mar "[kiss]"
    scene 03_0498 with dis1
    $ apause()
    scene 03_0499 with dis1
    $ apause(1.0)
    scene 03_0500 with dissolve
    $ apause(0.5, True)
    scene 03_0501 with dis1
    mar "[ss]Nnnhhh.."
    scene 03_0502 with dis1
    scene 03_0503 with dis1
    scene 03_0504 with dis1
    image r_mary_002 = Movie(play="images/e03/03_0505.webm")
    show r_mary_002
    mar "[ss]Mmhh.."
    scene 03_0506 with dissolve
    image r_mary_003 = Movie(play="images/e03/03_0507.webm")
    show r_mary_003
    mar "[ss]..Mmmmhhhh.."
    scene 03_0508 with dissolve
    image r_mary_004 = Movie(play="images/e03/03_0509.webm")
    show r_mary_004
    call Moan (mar)
    scene 03_0510 with dissolve
    mar "[ss]Nnnhhh.."
    scene 03_0511 with dissolve
    mar "[ss]..Ohhhh.."
    call CharCum ("e03/03_0511.webp", "e03/03_0512.webp", mar, "OHHHHHHHHH!!")
    scene 03_0513 with dissolve
    mar "[ss]..Mmmmhhhh.."
    scene 03_0514 with dissolve
    mar "[whi]Wow!"
    scene 03_0515 with dissolve
    image r_mary_005 = Movie(play="images/e03/03_0516.webm")
    show r_mary_005
    mar "[ss]Mmhh.."
    scene 03_0517 with dissolve
    mct "Fuck.... about to cum...."
    scene 03_0515 with dissolve
    mc "[whi]Mary... Take it out..."
    scene 03_0518 with dissolve
    mar "[ss]..Mmhh.."
    call CharCum ("e03/03_0518.webp", "e03/03_0519.webp", mc, "NNNGGGGGHHHH!!")
    call CharCum ("e03/03_0519.webp", "e03/03_0520.webp", mc, "..Nnnhhhh..")
    $ aP(True)
    scene 03_0521 with dissolve
    $ apause(1.0)
    scene 03_0522 with dissolve
    call Gulp (mar)
    scene 03_0523 with dissolve
    $ apause(0.5, True)
    scene 03_0524 with dissolve
    mar "[ss]Mmhh.."
    scene 03_0525 with dissolve
    mar "[whi]I didn't think it would be {i}that much{/i} fun!"
    scene 03_0526 with dissolve
    call laugh (mc)
    scene 03_0527 with Fade(1, 0.5, 1)
    mar "I love our sleepovers!"
    mc "Me, too."
    scene 03_0528 with dissolve
    mar "Goodnight."
    mc "Night."
    scene 03_0529 with dissolve
    mar "[kiss]"
    scene 03_0530 with dissolve
    pause 1.0
    scene 03_0531 with dissolve
    mar "I'd like to kiss you again, [petn]."
    scene 03_0532 with dissolve
    mar "{size=*.8}{font=Vanilla.ttf}*Mwwah*{/font}{/size}{w=1.5}{nw}"
    scene 03_0533 with dis1
    mar "[ss]Mmmmhh.."
    scene 03_0534 with dissolve
    mar "[ss]...Mmhhh..."
    scene 03_0535 with dissolve
    mar "[ss]..Mmmmhhh.."
    scene 03_0536 with dissolve
    mar "[whi]Night."
    scene 03_0537 with dissolve
    mc "[whi]Goodnight, Sweetheart."
    scene black with Fade(3,0,0)
return

label MaryReplay03(mp=True):
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    call Unlocker ("MaryReplay03")
    if _in_replay:
        scene 06_0065 with fade2
        pause 1.0
        play sound "thunder01.mp3"
        scene 06_0066
        pause 0.25
        scene 06_0065 with dissolve
        mct "Damn. Poor Bill!"
        scene 06_0067 with dissolve
        mct "Glad I ain't out there."
        play sound "thunder04.mp3" volume 0.5
        mct "Woah."
    else:
        $ persistent.MaryRP03Dat=(JamesD and mp)
        $ Mary.incSex()
    scene 06_0068 with Fade(2, 1, 0)
    play sound "doorslam.mp3"
    mar "OH MY GOD!"
    scene 06_0069 with dissolve
    mar "C.. C... Can I stay in here with you?"
    mar "It's so loud!!\nI'm scared in my room all alone!"
    mc "Uh... sure."
    scene 06_0070 with dissolve
    mar "Can we leave the light on?\nI don't like being in the dark in a storm!"
    mc "Yeah, of course we can."
    scene 06_0071 with Fade(1, 0.5, 1)
    mar "I'm sorry, [petn]...\nI know I'm being silly!"
    mc "It's fine.\nCome on, get in here."
    $ aaa="" + ("a" if persistent.MaryRP03Dat else "")
    show expression "06_0072" + aaa with dissolve
    mar "You're sooo sweet!"
    if persistent.MaryRP03Dat:
        scene 06_0073 with dissolve
        mar "Oh my gosh!"
        mar "What happened to you??"
        scene 06_0074 with dissolve
        mc "Oh... Err... nothing."
        mc "Tripped over and fell down a few steps, that's all.\nLooks worse than it is, heh."
    show expression "06_0075" + aaa with dissolve
    mar "[whi]I feel so safe in your arms."
    scene 06_0076 with fade
    pause 0.5
    play sound "thunder02.mp3" volume 0.5
    pause 0.5
    scene 06_0077 with vpunch
    mar "AAHH!!"
    scene 06_0078 with dissolve
    mc "Whoa, you're okay."
    scene 06_0079 with dissolve
    mar "I'm sorry."
    mc "We {i}could{/i} try taking your mind off the storm?"
    mar "How??"
    scene 06_0080 with dis1
    mar "[whi]Ummm... I know what might help..."
    scene 06_0081 with dis1
    mar "[kiss]"
    scene 06_0080 with dis1
    pause 0.5
    scene 06_0082 with dis1
    mar "[kiss]"
    scene 06_0083 with dissolve
    mar "[kiss]"
    scene 06_0084 with dis1
    mar "[whi]A {i}big{/i} kiss might help even more."
    scene 06_0085 with dissolve
    scene 06_0086 with dissolve
    mar "[ss]Mmhh."
    scene 06_0087 with dissolve
    play sound "thunder01.mp3" volume 0.5
    pause 0.5
    scene 06_0088 with vpunch
    pause 0.5
    show expression "06_0089" + aaa with dissolve
    mc "[whi]You're okay, just concentrate on kissing me."
    show expression "06_0090" + aaa with dissolve
    mar "[ss]..Mmhh.."
    pause 0.5
    play sound "thunder02.mp3" volume 0.5
    pause 0.5
    show expression "06_0091" + aaa with vpunch
    mar "[ss]Mmmmhh."
    show expression "06_0092" + aaa with dissolve
    pause 0.5
    show expression "06_0093" + aaa with dis1
    pause 0.5
    show expression "06_0094" + aaa with dis1
    pause 0.5
    show expression "06_0095" + aaa with dis1
    pause 0.5
    scene 06_0096 with dis1
    pause 0.5
    scene 06_0097 with dissolve
    pause 0.5
    scene 06_0098 with dis1
    mar "[ss]..Mmhh.."
    scene 06_0099 with dis1
    pause 0.5
    scene 06_0100 with dis1
    pause 0.5
    scene 06_0101 with dis1
    pause 0.5
    scene 06_0102 with dis1
    mar "[ss]..Mmhh.."
    scene 06_0103 with dissolve
    image r_mary_006 = Movie(play="images/e06/06_0104.webm", loop=False, keep_last_frame=True)
    show r_mary_006
    mar "[ss]Mmhh.."
    scene 06_0105 with dissolve
    pause 0.5
    scene 06_0106 with dis1
    call Moan (mar, 4)
    scene 06_0107 with dissolve
    play sound "thunder01.mp3" volume 0.3
    scene 06_0108 with dis1
    pause 0.5
    scene 06_0109 with dis1
    pause 0.5
    scene 06_0110 with dis1
    scene 06_0111 with dissolve
    image r_mary_007 = Movie(play="images/e06/06_0112.webm")
    show r_mary_007
    mar "[ss]..Mmhh.."
    scene 06_0113 with dissolve
    scene 06_0114 with dis1
    mar "[ss]..Ohhhhhh, [petn].... That feels so nice..."
    scene 06_0115 with dissolve
    image r_mary_008 = Movie(play="images/e06/06_0116.webm")
    show r_mary_008
    pause
    scene 06_0117 with dissolve
    mar "[ss]..Mmmmmhhh.."
    mar "[ss].... [petn].."
    mar "[ss]......Push it in."
    scene 06_0115 with dissolve
    image r_mary_009 = Movie(play="images/e06/06_0118.webm", loop=False, keep_last_frame=True)
    show r_mary_009
    pause 9.0
    scene 06_0119 with dissolve
    mar "[ss]..OHH.."
    scene 06_0120 with dissolve
    image r_mary_010 = Movie(play="images/e06/06_0121.webm", loop=False, keep_last_frame=True)
    show r_mary_010
    pause 6.0
    scene 06_0122 with dissolve
    mar "[ss]..OHHHH [petn!u]...."
    scene 06_0123 with dissolve
    image r_mary_011 = Movie(play="images/e06/06_0124.webm")
    show r_mary_011
    mar "[ss]..OHHHHHHH.."
    scene 06_0126 with dissolve
    image r_mary_012 = Movie(play="images/e06/06_0127.webm")
    show r_mary_012
    mar "[ss]..OHHH.."
    scene 06_0125 with dissolve
    mar "[ss]......OHHHHHHH...."
    scene 06_0128 with dissolve
    mar "[ss]...Ohhh, it feels so good...."
    scene 06_0129 with dissolve
    play sound "thunder01.mp3" volume 0.3
    mar "[ss]Keep doing that, [petn]."
    scene 06_0130 with dissolve
    mar "[ss]..Mmmmmhhh.."
    scene 06_0131 with dissolve
    image r_mary_013 = Movie(play="images/e06/06_0132.webm")
    show r_mary_013
    mar "[ss]..Mmmhh.."
    scene 06_0133 with dissolve
    mar "[ss]..Mmmmmhhh.."
    scene 06_0134 with dis1
    pause 0.5
    scene 06_0135 with dis1
    pause 0.5
    scene 06_0136 with dissolve
    image r_mary_014 = Movie(play="images/e06/06_0137.webm")
    show r_mary_014
    mar "[ss]..OHHH.."
    scene 06_0138 with dissolve
    mar "[ss]......OHHHHHHH...."
    scene 06_0139 with dissolve
    image r_mary_015 = Movie(play="images/e06/06_0140.webm")
    show r_mary_015
    call Moan (mar)
    play sound "thunder02.mp3" volume 0.3
    scene 06_0141 with dissolve
    image r_mary_016 = Movie(play="images/e06/06_0142.webm")
    show r_mary_016
    mar "[ss]..OHHH.."
    scene 06_0143 with dissolve
    call Moan (mar)
    scene 06_0144 with dissolve
    mar "[ss]......OHHHHHHH...."
    scene 06_0145 with dissolve
    image r_mary_017 = Movie(play="images/e06/06_0146.webm")
    show r_mary_017
    mar "[ss]..Mmmmmhhh.."
    scene 06_0147 with dissolve
    mar "[ss]..Mmmhh.."
    scene 06_0148 with dissolve
    image r_mary_018 = Movie(play="images/e06/06_0149.webm")
    show r_mary_018
    mar "[ss]..Mmmmmhhh.."
    scene 06_0150 with dissolve
    image r_mary_019 = Movie(play="images/e06/06_0151.webm")
    show r_mary_019
    mar "[ss]..Mmmmmhhh.."
    scene 06_0152 with dissolve
    image r_mary_020 = Movie(play="images/e06/06_0153.webm")
    show r_mary_020
    mar "[ss]......OHHHHHHH...."
    scene 06_0154 with dissolve
    pause
    scene 06_0155 with dissolve
    play sound "thunder03.mp3" volume 0.3
    mar "[ss]....Ohhhhh..."
    scene 06_0156 with dissolve
    image r_mary_021 = Movie(play="images/e06/06_0157.webm")
    show r_mary_021
    mar "[ss]..Mmmmmhhh.."
    scene 06_0158 with dissolve
    image r_mary_022 = Movie(play="images/e06/06_0159.webm")
    show r_mary_022
    mar "[ss]....Ohhhh, [petn]...."
    mar "[ss]..I.....I feel tingly all over...."
    mar "[ss]....Like I'm about to.....burst....."
    mc "[whi]Then burst, Sweetie."
    scene 06_0160 with dissolve
    call Moan (mar, 6, True)
    scene 06_0161 with dissolve
    image r_mary_023 = Movie(play="images/e06/06_0162.webm")
    show r_mary_023
    mar "[ss]......OHHHHHHH...."
    mar "[ss]...YES......GOD......OHHH..."
    mar "[ss]....[petn!u]....YES..."
    call CharCum ("e06/06_0161.webp", "e06/06_0163.webp", mar, "....OHHHH!!...OHHHHHHHH!!...")
    call CharCum ("e06/06_0163.webp", "e06/06_0165.webp", mar, "...OHHHHH!!...")
    scene 06_0164 with dissolve
    mar "[ss]....Ohhhhh..."
    scene 06_0166 with dissolve
    mar "[ss]...Holy fiddlesticks!..."
    scene 06_0167 with dissolve
    mar "[ss]It's your turn to burst, [petn]."
    scene 06_0168 with dissolve
    image r_mary_024 = Movie(play="images/e06/06_0169.webm")
    show r_mary_024
    mar "[ss]..Mmmhhh.."
    scene 06_0170 with dissolve
    image r_mary_025 = Movie(play="images/e06/06_0171.webm")
    show r_mary_025
    pause
    call CmOpts (["Cum inside Mary", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Mary.incCm()
        call CharCum ("e06/06_0170.webp", "e06/06_0172.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e06/06_0172.webp", "e06/06_0173.webp", mc, "..Nnnhhhh..")
        scene 06_0174 with dissolve
        pause
        scene 06_0178 with dissolve
        mar "[ss]..Mmmhhh.."
    else:
        call CharCum ("e06/06_0170.webp", "e06/06_0175.webp", mc, "NNNGGGGGHHHH!!")
        call CharCum ("e06/06_0175.webp", "e06/06_0176.webp", mc, "..Nnnhhhh..")
        scene 06_0177 with dissolve
        mar "[ss]..Mmmhhh.."
    scene 06_0179 with dissolve
    mar "[ss]..Wow...That was.....Mmmhhh...."
    mar "[ss]I thought it would hurt more, but... it was amazing!"
    scene 06_0180 with dissolve
    mc "[whi]I tried to be gentle."
    play sound "thunder01.mp3" volume 0.3
    scene 06_0181 with dissolve
    mar "[whi]You were."
    mar "[whi]It was perfect, [petn]."
    scene 06_0182 with Fade(2, 2, 1)
    play sound "thunder03.mp3" volume 0.2
    mc "[whi]...ZZzzzz...."
    scene black with Fade(4, 1, 0)
    stop music
return

label MaryReplay04:
    call Unlocker ("MaryReplay04")
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    if _in_replay:
        scene 09_0562 with dis1
        scene 09_0563 with dis1
        scene 09_0564 with dis1
        mar "Hi."
        scene 09_0565 with dissolve
        mc "Jesus!\nYou almost gave me a coronary!"
        scene 09_0566 with dissolve
        mar "Sorry!"
        scene 09_0567 with dissolve
        mar "[whi]Can we have sex again, [petn]?"
        scene 09_0565 with dissolve
    else:
        $ Mary.incSex()
    scene 09_0570 with dis1
    scene 09_0571 with dis1
    play sound "doorclose.mp3"
    scene 09_0572 with dis1
    scene 09_0573 with dis1
    pause 0.5
    scene 09_0574 with fadehold
    pause 0.5
    scene 09_0575 with dis1
    pause 0.5
    scene 09_0576 with dis1
    pause 0.5
    scene 09_0577 with dis1
    mar "[ss]OHHHH!"
    scene 09_0578 with dissolve
    mar "[whi][petn], you're going to make it all sticky and wet again!"
    scene 09_0579 with dissolve
    mc "That's how I like it, Sweetie!"
    scene 09_0580 with dissolve
    mar "[ss]..Ohhhhh.."
    scene 09_0581 with dissolve
    scene 09_0582 with dis1
    pause
    scene 09_0583 with dissolve
    mar "[ss]..Ohhh.."
    scene 09_0584 with dissolve
    mar "[ss]..Mmmmhhh.."
    scene 09_0585 with dis1
    mar "[ss]....OHHHHH...."
    scene 09_0586 with dissolve
    image MaryR04_01 = Movie(play="images/e09/09_0587.webm")
    show MaryR04_01
    mar "[ss]Mmhh.."
    scene 09_0588 with dissolve
    call Moan (mar)
    scene 09_0586 with dissolve
    scene 09_0589 with dis1
    scene 09_0590 with dis1
    scene 09_0591 with dis1
    pause 0.5
    scene 09_0592 with dissolve
    mar "[ss]OHHHHH!"
    scene 09_0593 with dissolve
    mar "[ss]Mmhh.."
    scene 09_0594 with dissolve
    mct "Damn... I could eat her pussy all night!"
    if persistent.Anal:
        scene 09_0595 with dissolve
        mct "Then again..."
        scene 09_0596 with dissolve
        scene 09_0597 with dis1
        mar "{size=*0.8}{font=Vanilla.ttf}*{i}Gasp{/i}*{/font}{/size} [petn]!" with hpunch
        mar "Tha.. That's my... butt!"
        scene 09_0598 with dissolve
        mc "I know."
        mc "If you don't like it, I can stop."
        scene 09_0599 with dissolve
        mar "[whi]Ohh."
        scene 09_0600 with dissolve
        mar "Can you, uhh.... do it again?"
        scene 09_0601 with dissolve
        mar "[whi]It tickles!"
        scene 09_0602 with dissolve
        mar "[ss]Mmmhh... It's nice, though..."
        mar "[ss]... I like it..."
        scene 09_0603 with dissolve
        mar "[ss]...Ohhhh...I like it a lot..."
        scene 09_0604 with dissolve
        image MaryR04_02 = Movie(play="images/e09/09_0605.webm")
        show MaryR04_02
        mar "[ss]..Mmmhhh..."
        scene 09_0606 with dissolve
        scene 09_0607 with dis1
        mar "[ss]...OHHHHH..."
        scene 09_0608 with dissolve
        call Moan (mar)
        scene 09_0609 with dissolve
        scene 09_0610 with dis1
    scene 09_0611 with dis1
    scene 09_0612 with dis1
    call Moan (mar, 7)
    scene 09_0613 with dissolve
    mar "[ss]...Ohhhh..."
    scene 09_0614 with dissolve
    mar "[ss]...OHH..."
    mar "[ss]..[petn]...Stop...."
    scene 09_0615 with dissolve
    mar "[ss]...I'm ... I'm... going to....."
    scene 09_0616 with dissolve
    image MaryR04_03 = Movie(play="images/e09/09_0617.webm", loop=False, keep_last_frame=True)
    show MaryR04_03
    mar "[ss]...Ohhhhhh...{w=2}{nw}"
    pause 3.5
    mar "..OHHH..{w=0.5}{nw}" with Fade(.1, 0.0, .5, color="#fff")
    mar "{font=Lemon.ttf}{size=*0.8}OHHHHHHHHH{w=1}{nw}" with Move((0, 15), (0, -15), .10, bounce=True, repeat=True, delay=1)
    mar "{font=Lemon.ttf}{size=*0.8}OHHHHHHHHH"
    call CharCum ("e09/09_0618.webp", "e09/09_0619.webp", mar, "..OHHHH!!..")
    scene 09_0620 with dissolve
    mar "Ohh [petn], you made me burst. I wanted us to..."
    mc "It's okay! You can burst again!"
    scene 09_0621 with dissolve
    mar "Ohh, Really?!"
    scene 09_0622 with dissolve
    mar "Okay!\nBut, I'd like to put {i}that{/i} in my mouth again, first."
    scene 09_0623 with dissolve
    mar "Can I, [petn]?"
    mc h "We can do anything you want, Sweetie."
    scene 09_0624 with dissolve
    pause
    scene 09_0625 with dissolve
    scene 09_0626 with dis1
    pause
    scene 09_0627 with dissolve
    scene 09_0628 with dis1
    scene 09_0629 with dis1
    image MaryR04_04 = Movie(play="images/e09/09_0630.webm")
    show MaryR04_04
    mar "[ss]..Mmmhhh..."
    scene 09_0631 with dissolve
    scene 09_0632 with dis1
    mc "[ss]..Fuck.."
    scene 09_0633 with dis1
    image MaryR04_05 = Movie(play="images/e09/09_0634.webm")
    show MaryR04_05
    mar "[ss]Mmhhh..."
    scene 09_0635 with dis1
    image MaryR04_06 = Movie(play="images/e09/09_0636.webm")
    show MaryR04_06
    mar "[ss]...Mmmmhhh..."
    scene 09_0637 with dissolve
    pause
    scene 09_0638 with dis1
    image MaryR04_07 = Movie(play="images/e09/09_0639.webm")
    show MaryR04_07
    mar "[ss]...Mmmmhhh..."
    scene 09_0640 with dis1
    mc "You'd better stop... Unlike you, I can only burst once."
    scene 09_0641 with dissolve
    mar "That doesn't seem fair!"
    mc "Right?!"
    scene 09_0642 with dissolve
    mar "Are you going to... sex... me now?"
    mc "Yeah."
    mc "Wanna turn around for me?"
    scene 09_0643 with dissolve
    mar "We going to do the dog??"
    mc "Yeah, heh."
    scene 09_0644 with dissolve
    mar "My friend showed me a video! It looked so fun!"
    scene 09_0645 with dis1
    mar "Like this, right?"
    scene 09_0646 with dissolve
    mc "Yep..."
    scene 09_0647 with dissolve
    mc "... Perfect."
    scene 09_0648 with dissolve
    pause
    scene 09_0649 with dissolve
    image MaryR04_08 = Movie(play="images/e09/09_0650.webm", loop=False, keep_last_frame=True)
    show MaryR04_08
    pause 3.0
    mar "[ss]...Ohhhhh..."
    scene 09_0651 with dissolve
    mar "[ss]...Ohhh, [petn]..."
    scene 09_0652 with dissolve
    image MaryR04_09 = Movie(play="images/e09/09_0653.webm")
    show MaryR04_09
    mar "[ss]...Ohhhhh..."
    scene 09_0654 with dissolve
    image MaryR04_10 = Movie(play="images/e09/09_0655.webm")
    show MaryR04_10
    mar "[ss]..Ohhh.."
    scene 09_0656 with dissolve
    image MaryR04_11 = Movie(play="images/e09/09_0657.webm")
    show MaryR04_11
    call Moan (mar)
    scene 09_0658 with dissolve
    mar "[ss]....Ohhhh...."
    scene 09_0659 with dissolve
    pause
    scene 09_0660 with dissolve
    image MaryR04_12 = Movie(play="images/e09/09_0661.webm")
    show MaryR04_12
    mar "[ss]..OHHH.."
    scene 09_0662 with dissolve
    mar "[ss]..AAHHHHHH.."
    scene 09_0663 with dissolve
    image MaryR04_13 = Movie(play="images/e09/09_0664.webm")
    show MaryR04_13
    call Moan (mar, 7)
    scene 09_0665 with dissolve
    mar "[ss]....Ohhhh...."
    scene 09_0666 with fade
    mar "[ss]...OHHHHH, YES [petn!u]....LIKE THAT...."
    scene 09_0667 with dissolve
    image MaryR04_14 = Movie(play="images/e09/09_0668.webm")
    show MaryR04_14
    call Moan (mar, 7)
    scene 09_0669 with dissolve
    image MaryR04_15 = Movie(play="images/e09/09_0670.webm")
    show MaryR04_15
    call Moan (mar, 7)
    scene 09_0671 with dissolve
    mar "[ss]....Ohhhh...."
    scene 09_0672 with dissolve
    mar "[ss]..Mmhhhhh.."
    if persistent.Anal:
        scene 09_0673 with dis1
        scene 09_0674 with dis1
        scene 09_0675 with dis1
        image MaryR04_16 = Movie(play="images/e09/09_0676.webm")
        show MaryR04_16
        pause
        scene 09_0677 with dissolve
        mar "[ss]...Ohhh, [petn]..."
        scene 09_0678 with dis1
        pause 0.5
        scene 09_0679 with dis1
        pause
        scene 09_0680 with dissolve
        call Emotion (mar, "Gasp", "", True)
        scene 09_0681 with dissolve
        mar "[ss]Ohhhh....Fiddlesticks....."
    scene 09_0682 with dissolve
    image MaryR04_17 = Movie(play="images/e09/09_0683.webm")
    show MaryR04_17
    call Moan (mar, 7)
    scene 09_0684 with fade
    mar "[ss]..OHHH.."
    scene 09_0685 with fade
    image MaryR04_18 = Movie(play="images/e09/09_0686.webm")
    show MaryR04_18
    mar "[ss].Mmmhhh."
    scene 09_0687 with dissolve
    mar "[ss]...Mmhhhhh..."
    scene 09_0688 with fade
    image MaryR04_19 = Movie(play="images/e09/09_0689.webm")
    show MaryR04_19
    mar "[ss].Mmmhhh."
    scene 09_0690 with dissolve
    image MaryR04_20 = Movie(play="images/e09/09_0691.webm")
    show MaryR04_20
    mar "[ss]..Mhhh.."
    scene 09_0692 with dissolve
    mar "[ss].Mmmhhh."
    scene 09_0693 with dis1
    scene 09_0694 with dis1
    scene 09_0695 with dis1
    image MaryR04_21 = Movie(play="images/e09/09_0696.webm")
    show MaryR04_21
    mar "[ss]..Ohhhhhh.."
    scene 09_0697 with dissolve
    image MaryR04_22 = Movie(play="images/e09/09_0698.webm")
    show MaryR04_22
    mar "[ss]..Mhhh.."
    mar "[ss]....Ohhh......I'm about ready to burst again....."
    scene 09_0699 with dissolve
    call Moan (mar)
    scene 09_0700 with dissolve
    image MaryR04_23 = Movie(play="images/e09/09_0701.webm")
    show MaryR04_23
    mar "[ss]..OHHHHH.."
    scene 09_0702 with dissolve
    image MaryR04_24 = Movie(play="images/e09/09_0703.webm")
    show MaryR04_24
    call Moan (mar, 8)
    scene 09_0704 with dissolve
    image MaryR04_25 = Movie(play="images/e09/09_0705.webm")
    show MaryR04_25
    call Moan (mar, 8)
    call CharCum ("e09/09_0704.webp", "e09/09_0706.webp", mar, "..OHHHHHHH..")
    call CharCum ("e09/09_0706.webp", "e09/09_0707.webp", mar, "....Ohhhhhhhh....")
    scene 09_0708 with dissolve
    mar "[whi]...Wow, [petn]...That was even better than the first time!"
    mar "[whi]It's your turn to burst!"
    call CmOpts (["Burst in Mary's mouth", "Burst on Mary's face", "Burst inside Mary"])
    $ Copt=_return
    if Copt==0:
        scene 09_0716 with fade
        pause 
        scene 09_0717 with dissolve
        image MaryR04_27 = Movie(play="images/e09/09_0718.webm")
        show MaryR04_27
        pause
        call CharCum ("e09/09_0717.webp", "e09/09_0719.webp", mc, "..Nnnhhhhh..")
        call CharCum ("e09/09_0719.webp", "e09/09_0720.webp", mc, ".....Nnnhhh.....")
        call Loop_Dissolve (3, True, False, "e09/09_0721.webp", "e09/09_0720.webp")
        scene 09_0721 with dissolve
        mar "[ss]..Mhhh.."
        scene 09_0722 with dissolve
        mar "[whi]You're soooo delicious, [petn]!"
    elif Copt==1:
        scene 09_0716 with fade
        pause 
        scene 09_0717 with dissolve
        image MaryR04_27 = Movie(play="images/e09/09_0718.webm")
        show MaryR04_27
        pause 
        call CharCum ("e09/09_0717.webp", "e09/09_0723.webp", mc, "..Nnnhhhhh..")
        call CharCum ("e09/09_0723.webp", "e09/09_0724.webp", mc, ".....Nnnhhh.....")
        scene 09_0725 with dissolve
    else:
        scene 09_0709 with dissolve
        image MaryR04_26 = Movie(play="images/e09/09_0710.webm")
        show MaryR04_26
        mar "[ss]..Mhhh.."
        call CharCum ("e09/09_0709.webp", "e09/09_0711.webp", mc, "..Nnnhhhhh..")
        call CharCum ("e09/09_0711.webp", "e09/09_0712.webp", mc, ".....Nnnhhh.....")
        $ Mary.incCm()
        scene 09_0713 with fade
        mar "[whi]I wish you could stay over and do that {b}every night{/b}!"
        scene 09_0714 with dissolve
        mc "[whi]Me too, Sweetie, me too."
        scene 09_0715 with dissolve
    mar "Can we have some kisses and cuddles before I go back to my room?"
    mc "Of course we can!"
    scene 09_0726 with Fade(2, 1, 1)
    mar "[ss]Mmhh."
    scene black with ReplayFade
return

label MaryReplay05:
    call Unlocker ("MaryReplay05")
    if _in_replay:
        scene 13_0687 with Fade(0,1,2)
        mar "Can you stay with me for a little while, at least?"
        mar "I'm getting sticky and wet again, just how you like it!"
    else:
        $ persistent.MaryRP05Dat= Mary.getCumIns()
        $ Mary.incSex()
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    scene 13_0692 with dissolve
    mc "Now I think of it, I {i}do{/i} have some time to spare..."
    scene 13_0693 with dissolve
    mar "That mean we can have a big kiss now?"
    mc "Yeah."
    scene 13_0694 with dissolve
    mar "[ss]Mmhh."
    scene 13_0695 with dissolve
    image MaryR05_01 = Movie(play="images/e13/13_0696.webm")
    show MaryR05_01
    mar "[ss]...Mmmmhh..."
    scene 13_0697 with dissolve
    image MaryR05_02 = Movie(play="images/e13/13_0698.webm")
    show MaryR05_02
    mar "[whi]I love playin' with it!"
    mar "[whi]It's so much fun!"
    scene 13_0699 with dissolve
    mar "[whi]Know what else I love, [petn]?"
    scene 13_0700 with dissolve
    if persistent.MaryRP05Dat>0:
        mar "[whi]When you burst inside me."
        mar "[whi]It fills my insides up, and my belly gets all warm and fuzzy."
    else:
        mar "[whi]The feel of it when it's inside me."
    scene 13_0701 with dissolve
    mar "[whi]It's the best feelin' in the world."
    scene 13_0702 with dissolve
    mc "[whi]I love it, too."
    scene 13_0703 with dissolve
    mar "[ss]Mmhh."
    scene 13_0704 with dis1
    $ apause(h=False)
    scene 13_0705 with dis1
    $ apause()
    scene 13_0706 with dis1
    $ apause()
    scene 13_0707 with dis1
    $ apause()
    scene 13_0708 with dis1
    $ apause()
    scene 13_0709 with dis1
    $ apause(h=True)
    scene 13_0710 with dis1
    mar "[ss]..Mmhh.."
    scene 13_0712 with dissolve
    pause
    scene 13_0711 with dissolve
    mar "[ss]...Mmmmhh..."
    scene 13_0713 with dissolve
    pause
    scene 13_0714 with dissolve
    mar "[ss]..Mmhh.."
    scene 13_0715 with dissolve
    pause
    scene 13_0716 with dis1
    $ apause()
    scene 13_0717 with dis1
    scene 13_0718 with dis1
    pause
    scene 13_0719 with dissolve
    call Moan (mar, 4)
    scene 13_0720 with dissolve
    mar "[ss]..Ohhhhh.."
    scene 13_0721 with dissolve
    call Moan (mar, 4)
    scene 13_0722 with dis1
    $ apause(h=False)
    scene 13_0723 with dis1
    $ apause()
    scene 13_0724 with dis1
    $ apause()
    scene 13_0725 with dis1
    $ apause()
    scene 13_0726 with dis1
    $ apause(h=True)
    scene 13_0727 with dis1
    pause
    scene 13_0728 with dissolve
    pause
    scene 13_0729 with dissolve
    mar "[ss]..OHHH.."
    scene 13_0730 with dissolve
    image MaryR05_03 = Movie(play="images/e13/13_0731.webm")
    show MaryR05_03
    call Moan (mar)
    scene 13_0732 with dissolve
    image MaryR05_04 = Movie(play="images/e13/13_0733.webm")
    show MaryR05_04
    pause
    scene 13_0734 with dissolve
    mar "[ss]...OHHHHH...."
    scene 13_0735 with dis1
    scene 13_0736 with dis1
    scene 13_0737 with dis1
    pause 0.5
    scene 13_0738 with dissolve
    mar "[ss]..Ohhhhhhh.."
    scene 13_0739 with dissolve
    call Moan (mar)
    if persistent.Anal:
        scene 13_0740 with dis1
        scene 13_0741 with dis1
        mar "[ss]..Ohh, god.... I really like it when you lick me there, [petn]...."
        scene 13_0742 with dissolve
        pause
        scene 13_0743 with dissolve
        mar "[ss]...Ohhhh..... It feels soooo nice......"
        scene 13_0744 with dissolve
        mar "[ss]...OHHHHHHH...F...FFF....."
        scene 13_0745 with dissolve
        mar "[ss]....Fuuuuck....."
        scene 13_0746 with dissolve
        call Moan (mar)
    scene 13_0747 with dissolve
    call Moan (mar)
    scene 13_0748 with dissolve
    mar "[ss]..Ohhhhhhh.."
    scene 13_0749 with dis1
    scene 13_0750 with dis1
    scene 13_0751 with dis1
    scene 13_0752 with dis1
    scene 13_0753 with dis1
    scene 13_0754 with dissolve
    pause
    scene 13_0755 with dissolve
    pause
    scene 13_0756 with dissolve
    image MaryR05_05 = Movie(play="images/e13/13_0757.webm", loop=False, keep_last_frame=True)
    show MaryR05_05
    pause 2.0
    mar "[ss]Mmhh..{w=2}{nw}"
    pause 1.0
    mar "[ss]...Ohhhhh...{w=2}{nw}"
    mar "[ss]Ahhhhh."
    scene 13_0758 with dissolve
    image MaryR05_06 = Movie(play="images/e13/13_0759.webm")
    show MaryR05_06
    call Moan (mar)
    scene 13_0760 with dissolve
    mar "[ss]..Ohhhhhhh.."
    scene 13_0761 with dissolve
    image MaryR05_07 = Movie(play="images/e13/13_0762.webm")
    show MaryR05_07
    call Moan (mar)
    scene 13_0763 with dissolve
    pause
    scene 13_0764 with dissolve
    image MaryR05_08 = Movie(play="images/e13/13_0765.webm")
    show MaryR05_08
    mar "[ss]..Am I sticky enough for you, [petn]?"
    mc "[whi]Perfect, Baby."
    scene 13_0766 with dissolve
    image MaryR05_09 = Movie(play="images/e13/13_0767.webm")
    show MaryR05_09
    call Moan (mar)
    scene 13_0768 with dissolve
    mar "[ss]...Ohhhhh..."
    scene 13_0769 with dissolve
    image MaryR05_10 = Movie(play="images/e13/13_0770.webm")
    show MaryR05_10
    call Moan (mar)
    scene 13_0771 with dissolve
    pause 0.5
    scene 13_0772 with dis1
    scene 13_0773 with dis1
    mar "[ss]Mmhh."
    scene 13_0774 with dissolve
    image MaryR05_11 = Movie(play="images/e13/13_0775.webm")
    show MaryR05_11
    mar "[ss]..Mmmhhhh.."
    scene 13_0776 with dissolve
    pause
    scene 13_0777 with dissolve
    mar "[ss]..Mmhh.."
    scene 13_0778 with dissolve
    scene 13_0779 with dis1
    scene 13_0780 with dis1
    scene 13_0781 with dis1
    scene 13_0782 with dis1
    image MaryR05_12 = Movie(play="images/e13/13_0783.webm")
    show MaryR05_12
    mar "[ss]..Ohhhh.."
    scene 13_0784 with dissolve
    image MaryR05_13 = Movie(play="images/e13/13_0785.webm")
    show MaryR05_13
    call Moan (mar)
    scene 13_0786 with dissolve
    image MaryR05_14 = Movie(play="images/e13/13_0787.webm")
    show MaryR05_14
    mar "[ss]..Ohhhhhh.."
    scene 13_0788 with dissolve
    call Moan (mar)
    scene 13_0789 with dissolve
    mar "[ss]....Ohhhh [petn]...."
    scene 13_0790 with dissolve
    call Moan (mar, 7)
    scene 13_0791 with dissolve
    image MaryR05_15 = Movie(play="images/e13/13_0792.webm")
    show MaryR05_15
    mar "[ss]..Ohhhhhh.."
    scene 13_0793 with dis1
    scene 13_0794 with dis1
    scene 13_0795 with dis1
    scene 13_0796 with dis1
    image MaryR05_16 = Movie(play="images/e13/13_0797.webm")
    show MaryR05_16
    mar "[ss]....OHHHHHH, GOD.....[petn!u]!!.......YES...."
    scene 13_0798 with dissolve
    mar "[ss].....YES.......AHHHHHHH....."
    mar "[ss]....YESSS [petn!u]!......"
    scene 13_0799 with dissolve
    image MaryR05_17 = Movie(play="images/e13/13_0800.webm")
    show MaryR05_17
    call Moan (mar, 7)
    scene 13_0801 with dissolve
    image MaryR05_18 = Movie(play="images/e13/13_0802.webm")
    show MaryR05_18
    mar "[ss]....OHHHHHH....YES......"
    mar "[ss]..YOU'RE GONNA MAKE ME BURST, [petn!u]......"
    scene 13_0803 with dissolve
    image MaryR05_19 = Movie(play="images/e13/13_0804.webm")
    show MaryR05_19
    call Moan (mar, 7)
    scene 13_0805 with dissolve
    image MaryR05_20 = Movie(play="images/e13/13_0806.webm")
    show MaryR05_20
    mar "[ss]......OHHHHHH.......YESSSSS....."
    mar "[ss].....[petn!u]!!......"
    call CharCum ("e13/13_0805.webp", "e13/13_0807.webp", mar, "..OHHHHHHH..")
    call CharCum ("e13/13_0807.webp", "e13/13_0808.webp", mar, "....Ohhhhhhhh, "+petn+"......")
    scene 13_0809 with dissolve
    image MaryR05_21 = Movie(play="images/e13/13_0810.webm")
    show MaryR05_21
    mar "[ss]....Mmmmhhhh...."
    mar "[ss]..Goshdarnit, [petn]....I love sex!......"
    call CmOpts (["Pull out", "Cum inside Mary"])
    $ Copt=_return
    if Copt==0:
        call CharCum ("e13/13_0809.webp", "e13/13_0815.webp", mc, "..Nnnhhhhh..")
        call CharCum ("e13/13_0815.webp", "e13/13_0816.webp", mc, ".....Nnnhhh.....")
        scene 13_0817 with dissolve
        mar "[ss]Dang! I never knew it could shoot so far!"
    else:
        $ Mary.incCm()
        call CharCum ("e13/13_0809.webp", "e13/13_0811.webp", mc, "..Nnnhhhhh..")
        call CharCum ("e13/13_0811.webp", "e13/13_0812.webp", mc, ".....Nnnhhh.....")
        scene 13_0813 with dissolve
        mar "[ss]Do you like having sex with me, [petn]?"
        scene 13_0814 with dissolve
        mc "[whi]Yeah, I love it, Sweetie."
    scene black with ReplayFade
return

label MaryReplay06:
    call Unlocker ("MaryReplay06")
    $ Mary.incSex()
    $ petn=("Daddy" if persistent.MaryDaddy else persistent.McName)
    scene 17_0460 with fade1
    mar "I can't believe it's still here!\nPretty great, huh?!"
    mc "Yeah."
    scene 17_0461 with dissolve
    mc "And you say no one else knows about this place??"
    mar "Nope! It's all mine."
    scene 17_0462 with dissolve
    mc "You sure about that?\nPlaces like this are usually quite popular!"
    mar "Not this one!"
    scene 17_0463 with dissolve
    mar "Don't worry, [petn]. It's {b}our{/b} secret garden."
    scene 17_0464 with dissolve
    mar "We're all alone out here."
    scene 17_0465 with dissolve
    mc "Good."
    image MaryR06_01 = Movie(play="images/e17/17_0467.webm", loop=False, keep_last_frame=True)
    image MaryR06_02 = Movie(play="images/e17/17_0468.webm")
    scene 17_0466 with dissolve
    mc "Here you go, Princess."
    show MaryR06_01
    pause 2.1
    show MaryR06_02
    mc "That's my girl."
    scene 17_0469 with dissolve
    image MaryR06_03 = Movie(play="images/e17/17_0470.webm")
    show MaryR06_03
    mar "[ss].Mmmhhh."
    scene 17_0471 with dissolve
    image MaryR06_04 = Movie(play="images/e17/17_0472.webm")
    show MaryR06_04
    pause
    scene 17_0473 with dissolve
    image MaryR06_05 = Movie(play="images/e17/17_0474.webm")
    show MaryR06_05
    mar "[ss]Mmmhh."
    scene 17_0475 with dissolve
    scene 17_0476 with dis1
    scene 17_0477 with dis1
    scene 17_0478 with dis1
    scene 17_0479 with dis1
    scene 17_0480 with dis1
    scene 17_0481 with dis1
    scene 17_0482 with dis1
    scene 17_0483 with dis1
    scene 17_0484 with dis1
    image MaryR06_06 = Movie(play="images/e17/17_0485.webm")
    show MaryR06_06
    pause
    scene 17_0486 with dissolve
    image MaryR06_07 = Movie(play="images/e17/17_0487.webm")
    show MaryR06_07
    mar "[ss]Mmhhh."
    scene 17_0488 with dissolve
    mc "[whi]...Let me fuck your throat, Princess....."
    scene 17_0489 with dissolve
    image MaryR06_08 = Movie(play="images/e17/17_0490.webm")
    show MaryR06_08
    mc "[whi]That's it..."
    scene 17_0491 with dissolve
    image MaryR06_09 = Movie(play="images/e17/17_0492.webm")
    show MaryR06_09
    mar "[ss]..Mmmhhh.."
    scene 17_0493 with dissolve
    scene 17_0494 with dissolve
    call Gag (mar)
    if persistent.MaryDaddy:
        mc "[whi]...Fuck...Good girl, take it all for Daddy...."
    else:
        mc "[whi]...Fuck...Good girl, take it all...."
    $ i=0
    while i<3:
        scene 17_0493 with dissolve
        scene 17_0494 with dissolve
        call Gag (mar)
        $ i+=1
    scene 17_0495 with dissolve
    call Gag (mar)
    scene 17_0496 with dis1
    scene 17_0497 with dis1
    scene 17_0498 with dis1
    mar "[ss]Mmmhhh."
    scene 17_0499 with dis1
    scene 17_0500 with dis1
    scene 17_0501 with dis1
    scene 17_0502 with dis1
    scene 17_0503 with dissolve
    mar "[ss]...Mmhhh..."
    scene 17_0504 with dissolve
    mar "[whi]I like it when you call me Princess."
    mc "[whi]Yeah?\nGood, because that's what you are, Sweetie!"
    if persistent.MaryDaddy:
        mc "[whi]You're Daddy's little princess!"
        mc "[whi]And right now Daddy's hungry for some little princess pussy."
    else:
        mc "[whi]You're my little princess!"
        mc "[whi]And right now I'm hungry for some little princess pussy."
    scene 17_0505 with dissolve
    if persistent.Anal:
        mar "[whi]Can you do that thing with... my butt... again?"
        mc "[whi]You liked that, huh?"
        mar "[whi]I love {i}everything{/i} you do to me."
    else:
        mar "[whi]It's sticky and wet for you, [petn]."
    scene 17_0506 with dissolve
    mar "[ss]...Mmhhh..."
    scene 17_0507 with dis1
    scene 17_0508 with dis1
    scene 17_0509 with dis1
    scene 17_0510 with dis1
    scene 17_0511 with dis1
    pause 0.5
    scene 17_0512 with dissolve
    image MaryR06_10 = Movie(play="images/e17/17_0513.webm", loop=False, keep_last_frame=True)
    show MaryR06_10
    mar "[ss]Ohhhh."
    scene 17_0514 with dissolve
    image MaryR06_11 = Movie(play="images/e17/17_0515.webm")
    show MaryR06_11
    pause
    scene 17_0516 with dissolve
    mar "[ss]..Ohhh.."
    scene 17_0517 with dissolve
    pause
    scene 17_0518 with dissolve
    mar "[ss]....Ohh, [petn]......"
    scene 17_0519 with dissolve
    call Moan (mar)
    scene 17_0520 with dissolve
    mar "[ss]...Ohhhhhh...."
    scene 17_0521 with dissolve
    pause
    call Loop_Dissolve (3, True, False, "e17/17_0522.webp", "e17/17_0523.webp")
    scene 17_0524 with dis1
    mc "Come on, you should go on top... The ground's too hard for me to lie on top of you."
    mar "[whi]Okay."
    if persistent.Anal:
        $ Mary.Add("Anal")
        scene 17_0525 with dissolve
        mar "[petn], wait... Didn't you forget something?"
        mc "No, I don't think so?"
        mar "You said you'd do my butt!"
        mc "Oh, that's right! I did, didn't I? Heh."
        mc "Well then, you'd better turn around and spread those beautiful cheeks for me, Princess!"
        scene 17_0526 with dissolve
        mar "Like this?"
        mc "Yep, just like that."
        scene 17_0527 with dissolve
        mar "[giggles]"
        scene 17_0528 with dissolve
        mar "It feels sooo funny, but... Gosh, I like it!"
        call Loop_Dissolve (5, False, False, "e17/17_0529.webp", "e17/17_0530.webp")
        scene 17_0531 with dissolve
        pause
        scene 17_0532 with dissolve
        mar "[ss]..Ohhhhhh.."
        scene 17_0533 with dissolve
        pause 0.5
        scene 17_0534 with dis1
        scene 17_0535 with dis1
        pause 0.5
        scene 17_0536 with dissolve
        pause 0.5
        scene 17_0537 with dis1
        image MaryR06_12 = Movie(play="images/e17/17_0538.webm", loop=False, keep_last_frame=True)
        show MaryR06_12
        pause 2.0
        mar "[ss]Mmmhhh..{w=3}{nw}"
        pause 4.0
        mar "[ss]Nhhh.{w=2}{nw}"
        pause 3.0
        mar "[ss]AHHHH!"
        scene 17_0539 with dissolve
        mar "HOLY FIDDLESTICKS, [petn!u]!\nWHAT YOU LOOKIN' FOR IN THERE?!"
        scene 17_0540 with dissolve
        image MaryR06_13 = Movie(play="images/e17/17_0541.webm")
        show MaryR06_13
        mc "Don't you like it?"
        mar "I didn't say that!"
        mc "Good, 'cause I'm preparing it, Princess."
        mar "[whi]For what??"
        mc "Heh. You'll see."
        scene 17_0542 with dis1
        mar "{b}THAT{/b} ain't never gonna fit!"
        scene 17_0543 with dissolve
        image MaryR06_14 = Movie(play="images/e17/17_0544.webm", loop=False, keep_last_frame=True)
        show MaryR06_14
        pause 4.0
        mar "AAHHHH!!"
        scene 17_0545 with dissolve
        image MaryR06_15 = Movie(play="images/e17/17_0546.webm")
        show MaryR06_15
        mar "[ss]..Ohhhhhh.."
        mc "[whi]Just say the word and I'll stop."
        scene 17_0547 with dissolve
        mar "[ss]No... Keep going..."
        scene 17_0548 with dissolve
        image MaryR06_16 = Movie(play="images/e17/17_0549.webm")
        show MaryR06_16
        mar "[ss]..Ohhhh.."
        scene 17_0550 with dissolve
        pause
        scene 17_0551 with dis1
        image MaryR06_17 = Movie(play="images/e17/17_0552.webm")
        show MaryR06_17
        mar "[ss]..Ohhhh.."
        scene 17_0553 with dis1
        image MaryR06_18 = Movie(play="images/e17/17_0554.webm")
        show MaryR06_18
        mar "[ss]..Mmmhhh.."
        scene 17_0555 with dissolve
        mar "[ss]...Ahhh..."
        scene 17_0556 with dissolve
        pause 0.5
        scene 17_0557 with dis1
        mc "[whi]Wow. You did good!\nHow was it?"
        scene 17_0558 with dissolve
        mar "[whi]It was nice once it stopped hurtin'!"
        scene 17_0559 with dissolve
        mc "[whi]It'll be easier next time... If you {i}want{/i} there to be a next time."
        mar "[whi]Heck yeah!"
        scene 17_0560 with dissolve
        mar "[whi]Should we clean it first?"
        mc "[whi]Yeah, pass me my shirt."
        scene 17_0561 with dissolve
        mar "[whi]It's okay, [petn]..."
        scene 17_0562 with dissolve
        mar "[whi]I can do it."
        scene 17_0563 with dis1
        image MaryR06_19 = Movie(play="images/e17/17_0564.webm")
        show MaryR06_19
        pause
        scene 17_0565 with dissolve
        image MaryR06_20 = Movie(play="images/e17/17_0566.webm")
        show MaryR06_20
        mar "[ss]..Mmmhhh.."
        scene 17_0567 with dissolve
        mar "[whi]Okay, it's clean!"
    scene 17_0568 with fade1
    pause
    scene 17_0569 with dissolve
    image MaryR06_21 = Movie(play="images/e17/17_0570.webm", loop=False, keep_last_frame=True)
    show MaryR06_21
    pause 2.5
    mar "[ss]Ohh..{w=1.0}{nw}"
    pause 0.5
    mar "[ss]..Aahhh.."
    scene 17_0571 with dissolve
    image MaryR06_22 = Movie(play="images/e17/17_0572.webm")
    show MaryR06_22
    mar "[ss]..Ohhh.."
    scene 17_0573 with dissolve
    image MaryR06_23 = Movie(play="images/e17/17_0574.webm")
    show MaryR06_23
    call Moan (mar)
    scene 17_0575 with dissolve
    mar "[ss]..Ohhh.."
    scene 17_0576 with dissolve
    image MaryR06_24 = Movie(play="images/e17/17_0577.webm")
    show MaryR06_24
    pause
    scene 17_0578 with dissolve
    call Moan (mar)
    scene 17_0579 with dissolve
    image MaryR06_25 = Movie(play="images/e17/17_0580.webm")
    show MaryR06_25
    mar "[ss]..Ohhh... Do you like watching me sex you, [petn]?..."
    call Moan (mar)
    mar "[ss]... I like you watching.... It makes me even stickier and wetter..."
    scene 17_0581 with dissolve
    image MaryR06_26 = Movie(play="images/e17/17_0582.webm")
    show MaryR06_26
    call Moan (mar)
    scene 17_0583 with dissolve
    mar "[ss]...Mhhhh... God, I wanna go faster..."
    mc "[whi]Go ahead, Princess."
    scene 17_0584 with dissolve
    image MaryR06_27 = Movie(play="images/e17/17_0585.webm")
    show MaryR06_27
    call Moan (mar, 8)
    scene 17_0586 with dissolve
    image MaryR06_28 = Movie(play="images/e17/17_0587.webm")
    show MaryR06_28
    mar "[ss]..OHHH, GOD....YES...."
    scene 17_0588 with dissolve
    image MaryR06_29 = Movie(play="images/e17/17_0589.webm")
    show MaryR06_29
    mar "[ss].....OHHH....."
    scene 17_0590 with dissolve
    image MaryR06_30 = Movie(play="images/e17/17_0591.webm")
    show MaryR06_30
    call Moan (mar, 8)
    call CharCum ("e17/17_0590.webp", "e17/17_0592.webp", mar, "..OHHHHHHH..")
    call CharCum ("e17/17_0592.webp", "e17/17_0593.webp", mar, "....Ohhhhhhhh....")
    scene 17_0594 with dissolve
    mar "[ss]Sorry, [petn], I burst too quickly!\nI couldn't stop myself."
    mc "[whi]You can burst whenever you want, Princess."
    scene 17_0595 with dissolve
    mar "[ss]Mmmhh."
    scene 17_0596 with dissolve
    mar "[ss]..Mmhhhh.."
    scene 17_0597 with dissolve
    image MaryR06_31 = Movie(play="images/e17/17_0598.webm")
    show MaryR06_31
    mar "[ss]Mmmhh."
    scene 17_0599 with dissolve
    mar "[whi]Wanna do the dog again?"
    mc "[whi]It's like you read my mind."
    scene 17_0600 with fade
    mar "[ss].....OHHH....."
    scene 17_0601 with dissolve
    image MaryR06_32 = Movie(play="images/e17/17_0602.webm")
    show MaryR06_32
    pause
    scene 17_0603 with dissolve
    image MaryR06_33 = Movie(play="images/e17/17_0604.webm")
    show MaryR06_33
    call Moan (mar)
    pause
    call CmOpts (["Cum inside Mary", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Mary.incCm()
        call CharCum ("e17/17_0603.webp", "e17/17_0605.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e17/17_0605.webp", "e17/17_0606.webp", mc, "..Nnnhhhh..")
        scene 17_0607 with dissolve
        pause
        scene 17_0608 with dissolve
        mar "[ss]..Mmmhhh.. My whole body trembles when you burst inside me. I love it!"
    else:
        call CharCum ("e17/17_0603.webp", "e17/17_0609.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e17/17_0609.webp", "e17/17_0610.webp", mc, "..Nnnhhhh..")
        scene 17_0611 with dissolve
        mar "[ss]..Mmmhhh.."
        scene 17_0612 with dissolve
        pause
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
