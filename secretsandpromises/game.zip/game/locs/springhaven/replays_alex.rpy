label AlexReplay01:
    call Unlocker ("AlexReplay01")
    if _in_replay:
        scene 02_0475 with Fade(1,0,2)
    car "I dare you..."
    scene 02_0477 with dissolve
    car "To give Uncle [persistent.McName] a lap dance!"
    call Emotion (alex, "Gasp", "Hah! Okay!")
    scene 02_0478 with fade
    car "Sit down, Uncle [persistent.McName]."
    nic "I'll get the music!"
    scene 02_0479 with dissolve
    mc "What's going on?"
    car h "Enjoy the show!"
    play music "lapd.mp3" volume 0.8 loop
    scene 02_0480 with fade
    pause 2.0
    scene 02_0481 with fade
    pause 2.0
    scene 02_0482 with dis1
    pause 2.0
    scene 02_0483 with dis1
    pause 2.0
    scene 02_0484 with dis1
    pause 2.0
    scene 02_0485 with fade
    pause 2.0
    scene 02_0486 with fade
    pause 2.0
    scene 02_0487 with fade
    pause 2.0
    scene 02_0488 with dis1
    pause 2.0
    scene 02_0489 with dis1
    pause 2.0
    scene 02_0490 with dis1
    pause 2.0
    scene 02_0491 with dis1
    pause 2.0
    scene 02_0492 with dis1
    pause 1.0
    scene 02_0493 with dis1
    car "ALEX! [giggles] {w=1.5}{nw}"
    scene 02_0494 with dis1
    pause 2.0
    scene 02_0495 with dis1
    pause 2.0
    scene 02_0496 with dis1
    pause 2.0
    scene 02_0497 with dis1
    pause 1.0
    scene 02_0498 with dis1
    pause 0.5
    scene 02_0499 with dis1
    alex "[kiss]"
    scene 02_0500 with dis1
    alex "[ss]Mmmhhh. {w=2.0}{nw}"
    scene 02_0501 with dis1
    alex "[ss]..Mmhhhh.. {w=2.0}{nw}"
    scene 02_0502 with dis1
    pause 2.0
    scene 02_0503 with dis1
    pause 2.0
    scene 02_0504 with dis1
    pause 2.0
    scene 02_0505 with dis1
    nic h "[whi]Who's enjoying it more, do you think?"
    car h "[whi]Her. Definitely her!"
    scene 02_0506 with fade
    pause 2.0
    scene 02_0507 with fade
    pause 2.0
    scene 02_0508 with dis1
    pause 2.0
    scene 02_0509 with dis1
    pause 1.0
    scene 02_0510 with dis1
    pause 1.0
    scene 02_0511 with dis1
    pause 1.0
    scene 02_0512 with dis1
    pause 1.0
    scene 02_0513 with dis1
    pause 2.0
    scene 02_0514 with dis1
    pause 2.0
    scene 02_0515 with dis1
    alex "[whi]How am I doing, {i}Uncle{/i} [mc]?\nEnjoying your dance?"
    scene 02_0516 with dis1
    alex "[whi]You don't need to answer, I can {i}feel{/i} how much you like it!"
    scene 02_0517 with dis1
    pause 2.0
    scene 02_0518 with dis1
    pause 2.0
    scene 02_0519 with dis1
    alex "[ss]..MMmmmhhh.."
    scene 02_0520 with dissolve
    car "{size=*2.0}{b}WHOA!!{/b}"
    scene 02_0521 with dissolve
    car "SHOW'S OVER!!"
    car "Time to put your clothes back on!"
    scene black with Fade(3, 1,1)
    stop music
return

label AlexReplay02:
    call Unlocker ("AlexReplay02")
    if _in_replay:
        scene 09_0033 with fade1
        pause 0.5
        scene 09_0034 with dissolve
        mc "Movie over?"
        scene 09_0035 with dissolve
        alex "No.\nToo much chick-flick for me, so I excused myself to grab a drink."
        scene 09_0036 with dissolve
        mc "Not a chick-flick kinda girl, huh?"
        alex "Nope."
        scene 09_0037 with dissolve
        alex "All that lovey-dovey crap? Give me some action any day!"
        scene 09_0039 with dissolve
        mc "I can give you some action..."
    else:
        $ persistent.AlexRP02Dat=[False, 0, False, Alex.Has("Dnc")]
        $ Alex.L=3
        $ Alex.isSexual(True)
    scene 09_0040 with dissolve
    alex su "Not the kinda action I was talking about!"
    scene 09_0041 with dis1
    scene 09_0042 with dis1
    mc "But the kind you want, right?"
    scene 09_0043 with dissolve
    alex "I didn't say that."
    scene 09_0044 with dissolve
    mc "You sure?"
    scene 09_0045 with dissolve
    mc "Because that's all I've heard you say since the day we met."
    scene 09_0046 with dissolve
    alex "I think you're mistaken."
    scene 09_0047 with dissolve
    mc "No, I don't think I am."
    scene 09_0048 with dissolve
    scene 09_0049 with dis1
    mc "[kiss]"
    scene 09_0050 with dissolve
    pause
    scene 09_0051 with dissolve
    alex "[ss]Mmhh.."
    scene 09_0052 with dis1
    pause 0.5
    scene 09_0053 with dis1
    pause 0.5
    scene 09_0054 with dis1
    pause 0.5
    scene 09_0055 with dis1
    pause 0.5
    scene 09_0056 with dissolve
    pause
    scene 09_0057 with dissolve
    pause
    scene 09_0058 with dissolve
    alex "[ss]..Mmmmhh.."
    scene 09_0059 with dissolve
    pause 0.5
    scene 09_0060 with dis1
    pause 0.5
    scene 09_0061 with dis1
    pause 0.5
    scene 09_0062 with dis1
    alex "[ss]Mmhh.."
    scene 09_0063 with dissolve
    mc "Your turn."
    alex sh "[whi]Huh?"
    scene 09_0064 with dissolve
    alex sh "{nw}"
    call Emotion (alex, "Gasp", "", False)
    scene 09_0065 with dissolve
    mc h "It's what you've been askin' for... Here you go."
    alex sh "[whi]Uhhh..."
    scene 09_0066 with dissolve
    mc "What are you waiting for?"
    alex sh "[whi]Ummm.... I..."
    scene 09_0067 with dissolve
    pause 0.5
    scene 09_0068 with dissolve
    alex "[whi]... I was only..."
    scene 09_0069 with dissolve
    alex "[whi]... It was just a bit of fun!"
    mc h "Hah! So you {b}are{/b} just a tease."
    scene 09_0070 with dissolve
    alex "No! ... It's just... I've never..."
    scene 09_0071 with dissolve
    alex "[whi]... You know..."
    mc "You're kiddin' me??"
    scene 09_0072 with dissolve
    alex "No!"
    alex "I know I flirt 'n shit... But it's... it's just... Nicole and Cara find it hilarious."
    if persistent.AlexRP02Dat[3]:
        scene 09_0073 with dissolve
        alex "When I danced for you ... and I moved your hand down to my..."
        alex "I don't know why I did that! I don't know what came over me!"
        alex "... It was the first time I've ever let anyone touch me {i}there{/i}."
        scene 09_0074 with dissolve
        alex h "The dancing... I just got carried away! It made me {i}really{/i} horny!"
        alex "I was relieved when Cara stopped me because I didn't know what might've happened next!"
    scene 09_0075 with dissolve
    alex "But... {i}you already knew{/i}... didn't you?"
    mc h "Yeah, I had my suspicions."
    mc h "Wanted to see what you'd do when I pulled my dick out, though!"
    scene 09_0076 with dissolve
    alex su "Yeah... {i}That{/i}, I wasn't expecting!"
    mc "You're tempted, aren't you?"
    scene 09_0077 with dissolve
    mc "It's okay..."
    scene 09_0078 with dis1
    scene 09_0079 with dis1
    mc h "You can try it..."
    scene 09_0080 with dissolve
    image AlexR02_01 = Movie(play="images/e09/09_0081.webm")
    show AlexR02_01
    mc "There you go."
    alex "[ss]Mmhh.."
    scene 09_0082 with dissolve
    pause
    scene 09_0083 with dissolve
    image AlexR02_02 = Movie(play="images/e09/09_0084.webm")
    show AlexR02_02
    alex "[ss]Mmhh.."
    scene 09_0085 with dissolve
    pause 0.5
    scene 09_0086 with dissolve
    pause 0.5
    scene 09_0087 with dissolve
    nic su "{nw}"
    call Emotion (nic, "Gasp")
    scene 09_0088 with dissolve
    nic "Uhh... Sorry... I didn't know you two were... busy... in here.\nSoda... We wanted soda."
    if not _in_replay:
        if not EzModeActive:
            menu:
                "Ask her if she'd like a go":
                    $ Nicole.Score(-1)
                    $ persistent.AlexRP02Dat[2]=True
                "[wk_y]apologize to her":
                    $ Nicole.Score(1)
                    $ persistent.AlexRP02Dat[0]=True
                    $ persistent.AlexRP02Dat[2]=False
        else:
            $ Nicole.Score(1)
            $ persistent.AlexRP02Dat[0]=True
            $ persistent.AlexRP02Dat[2]=False
        $ persistent.AlexRP02Dat[1]=Nicole.sc
    if persistent.AlexRP02Dat[0]:
        mc "Fuck! I'm {b}so{/b} sorry, Nicole!\nWe thought you'd be busy watching the movie."
        if persistent.AlexRP02Dat[1]>0:
            scene 09_0090 with dissolve
            nic "It's okay."
            if persistent.AlexRP02Dat[1]==4:
                scene 09_0091 with dissolve
                nic h "Carry on."
                scene 09_0092 with dissolve
                nic h "Pretend I'm not here."
            scene 09_0093 with dissolve
        else:
            scene 09_0089 with dissolve
            nic "Well, you were wrong!"
            scene 09_0094 with dissolve
    else:
        scene 09_0089 with dissolve
        nic a "{b}Ewww! No, I would not!{/b}"
        scene 09_0094 with dissolve
    alex "[ss]Mmhh.."
    scene 09_0095 with dissolve
    image AlexR02_03 = Movie(play="images/e09/09_0096.webm")
    show AlexR02_03
    alex "[ss]..Mmmmhh.."
    scene 09_0097 with dissolve
    mc "This {i}really{/i} your first time doin' that??"
    alex "[ss]Mh-mhh."
    mc "Damn! Not bad! Not bad at all."
    if persistent.AlexRP02Dat[2] or persistent.AlexRP02Dat[1]<1:
        scene 09_0098 with dissolve
        pause 0.5
        scene 09_0100 with dissolve
        pause 0.5
    else:
        scene 09_0099 with dissolve
        pause 0.5
        scene 09_0101 with dissolve
        pause 0.5
    scene 09_0102 with dissolve
    pause 0.5
    scene 09_0103 with dissolve
    pause 0.5
    scene 09_0104 with dissolve
    image AlexR02_04 = Movie(play="images/e09/09_0105.webm")
    show AlexR02_04
    alex "[ss]..Mmmmhh.."
    if persistent.AlexRP02Dat[1]==4:
        scene 09_0106 with dissolve
    else:
        scene 09_0107 with dissolve
    alex "[ss]..Mmhhh.."
    scene 09_0108 with dissolve
    alex "[ss]..Mmmmhhh.."
    scene 09_0109 with dissolve
    pause
    scene 09_0110 with dissolve
    image AlexR02_05 = Movie(play="images/e09/09_0111.webm")
    show AlexR02_05
    alex "[ss]Mmmhh..."
    call CmOpts (["Cum in her mouth", "Cum on her face", "Cum on her chest"])
    $ Copt=_return
    if Copt==0:
        pause 1.0
        call CharCum ("e09/09_0110.webp", "e09/09_0111.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e09/09_0111.webp", "e09/09_0112.webp", mc, "....nnnnhhhhh...")
        scene 09_0113 with dissolve
        mc "So, what's it gonna be? Spit... or swallow?"
        scene 09_0114 with dissolve
        call Gulp (alex)
        scene 09_0115 with dissolve
        mc h "Good girl."
        scene 09_0116 with fade
        alex h "You thought I was good? For real?"
        if _in_replay:
            mc "Yeah, you were great!"
        else:
            scene 09_0038 with dissolve
            mc "Yeah, you were great!"
            scene 09_0129 with dissolve
            mc h "Did {i}you{/i} enjoy it?"
            alex h "It was fun!"
            scene 09_0141 with dissolve
            alex "I'd better get back to the movie."
            alex "You should join us.\nCara misses you when you leave town."
            scene 09_0142 with dissolve
            mc "Yeah?"
            mc "Okay, let me have some coffee first."
    elif Copt==1:
        pause 1.0
        call CharCum ("e09/09_0110.webp", "e09/09_0117.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e09/09_0117.webp", "e09/09_0118.webp", mc, "....nnnnhhhhh...")
        scene 09_0119 with dissolve
        alex h "Jeez! That startled me!"
        scene 09_0120 with dissolve
        alex "You got some in my mouth, too. I can taste it... not bad!"
        scene 09_0121 with dissolve
        alex h "You thought I was good? For real?"
        mc "Yep!"
        scene 09_0122 with dissolve
        alex "I'll go clean up..."
        mc "Okay... I'm gonna make coffee."
    else:
        pause 1.0
        call CharCum ("e09/09_0110.webp", "e09/09_0124.webp", mc, "..NNNGGGGGHHHH!!...")
        call CharCum ("e09/09_0124.webp", "e09/09_0125.webp", mc, "....nnnnhhhhh...")
        scene 09_0126 with dissolve
        alex h "Jeez! That startled me!"
        scene 09_0127 with dissolve
        alex "Wow! There's so much!"
        scene 09_0128 with dissolve
        alex h "You thought I was good? For real?"
        mc "Yep!"
        scene 09_0123 with dissolve
        alex "I'll go clean up, it's going... {i}everywhere{/i}!"
        mc "Okay... I'm gonna make coffee."
    if _in_replay:
        scene black with ReplayFade
return

label AlexReplay03:
    call Unlocker ("AlexReplay03")
    $ Alex.incSex()
    scene 19_0116 with fade1
    mc "[whi]Mmhh.... That's really good."
    alex "Yeah?"
    scene 19_0117 with dissolve
    alex "I'm not going too deep for you?"
    mc "[whi]Nah, it's perfect."
    scene 19_0118 with dis1
    scene 19_0119 with dis1
    scene 19_0120 with dis1
    scene black with fade1
    call CenterText ("10 minutes later...")
    scene 19_0121 with fade1
    $ aPs(0, True)
    scene 19_0122 with dis1
    $ aPs()
    scene 19_0123 with dis1
    $ aPs(0, False, True)
    scene 19_0124 with dis1
    alex "You want to turn over?"
    scene 19_0125 with dissolve
    mc "Do {i}you{/i} want me to turn over?"
    alex "I think... we {i}both{/i} know why we really came up here."
    scene 19_0126 with dissolve
    alex "I've just been building up the courage to commit."
    alex "Yeah, I'd like you to turn over."
    scene 19_0127 with dis1
    scene 19_0128 with dis1
    scene 19_0129 with dis1
    pause 0.5
    scene 19_0130 with dissolve
    pause
    scene 19_0131 with dis1
    $ aPs(0, True)
    scene 19_0132 with dis1
    $ aPs()
    scene 19_0133 with dis1
    $ aPs()
    scene 19_0134 with dis1
    $ aPs()
    scene 19_0135 with dis1
    $ aPs()
    scene 19_0136 with dis1
    $ aPs()
    scene 19_0137 with dis1
    $ aPs(0)
    image AlexR03_02 = Movie(play="images/e19/19_0140.webm")
    scene 19_0138 with dis1
    image AlexR03_01 = Movie(play="images/e19/19_0139.webm", loop=False, keep_last_frame=True)
    show AlexR03_01
    pause 6.25
    $ aPs(-1, False, True)
    show AlexR03_02
    alex "[ss]Mmmh."
    scene 19_0141 with dissolve
    image AlexR03_03 = Movie(play="images/e19/19_0142.webm")
    show AlexR03_03
    alex "[ss]..Mmmhhh.."
    scene 19_0143 with dissolve
    $ aPs(0, True)
    scene 19_0144 with dis1
    $ aPs()
    scene 19_0145 with dis1
    $ aPs()
    scene 19_0146 with dis1
    scene 19_0147 with dis1
    scene 19_0148 with dis1
    scene 19_0149 with dis1
    $ aPs()
    scene 19_0150 with dis1
    $ aPs()
    scene 19_0151 with dis1
    $ aPs()
    scene 19_0152 with dis1
    $ aPs()
    scene 19_0153 with dis1
    $ aPs(0, False, True)
    scene 19_0154 with dissolve
    alex "[ss]Mmmhhh."
    scene 19_0155 with dissolve
    image AlexR03_04 = Movie(play="images/e19/19_0156.webm")
    show AlexR03_04
    alex "[ss]..Mmmhhh.."
    scene 19_0157 with dissolve
    alex "[ss]Mmhhh."
    scene 19_0158 with dissolve
    scene 19_0159 with dis1
    scene 19_0160 with dis1
    mc "[whi]Get up here."
    scene 19_0161 with dis1
    scene 19_0162 with dis1
    scene 19_0163 with dis1
    scene 19_0164 with dis1
    scene 19_0165 with dis1
    pause 0.5
    scene 19_0166 with dis1
    pause 0.5
    scene 19_0167 with dissolve
    pause
    scene 19_0168 with dis1
    image AlexR03_05 = Movie(play="images/e19/19_0169.webm")
    show AlexR03_05
    pause
    scene 19_0170 with dissolve
    alex "[ss]...Ohhhh.."
    scene 19_0171 with dissolve
    call Moan (alex)
    scene 19_0172 with dissolve
    image AlexR03_06 = Movie(play="images/e19/19_0173.webm")
    image AlexR03_07 = Movie(play="images/e19/19_0174.webm", loop=False, keep_last_frame=True)
    image AlexR03_08 = Movie(play="images/e19/19_0175.webm")
    show AlexR03_06
    alex "[ss]..Mmmhhh.."
    show AlexR03_07
    pause 0.9
    show AlexR03_08
    alex "[ss]Mmhh."
    scene 19_0176 with dissolve
    image AlexR03_09 = Movie(play="images/e19/19_0177.webm")
    show AlexR03_09
    alex "[ss]..Mmmhhh.."
    scene 19_0178 with dissolve
    call Moan (alex)
    scene 19_0179 with dissolve
    alex "[ss]God.... I didn't think that would feel {b}THIS{/b} good!"
    if persistent.Incest and Cara.isSexual():
        alex "[ss]I thought Cara was exaggerating!"
    scene 19_0180 with dissolve
    pause
    scene 19_0181 with dis1
    pause
    scene 19_0182 with dis1
    pause
    scene 19_0183 with dissolve
    alex "[ss]..Ohhh, man...."
    scene 19_0184 with dis1
    alex "[ss]..Mmmhhh.."
    scene 19_0185 with dis1
    scene 19_0186 with dis1
    scene 19_0187 with dis1
    scene 19_0188 with dis1
    scene 19_0189 with dis1
    call Moan (alex)
    scene 19_0190 with dissolve
    alex "[ss]..Fuuck...."
    scene 19_0191 with dissolve
    alex "[ss]God... I have an overwhelming urge to have you inside me right now..."
    scene 19_0192 with dissolve
    mc "Well don't {i}fight{/i} it... Get naked!"
    alex "[lol]"
    scene 19_0193 with fade1
    pause
    scene 19_0194 with dissolve
    mc "[whi]Ready?"
    alex "[whi]Hell yeah."
    scene 19_0195 with dissolve
    image AlexR03_10 = Movie(play="images/e19/19_0196.webm", loop=False, keep_last_frame=True)
    show AlexR03_10
    pause 5.0
    alex "[ss]Aaahhh."
    scene 19_0197 with dissolve
    image AlexR03_11 = Movie(play="images/e19/19_0198.webm")
    show AlexR03_11
    alex "[ss]..Fuck.."
    mc "[whi]Okay?"
    alex "[ss]Yeah."
    scene 19_0199 with dissolve
    mc "[whi]I'm not going too deep for you?"
    alex "[ss]No, perfect."
    scene 19_0200 with dissolve
    image AlexR03_12 = Movie(play="images/e19/19_0201.webm")
    show AlexR03_12
    pause
    scene 19_0202 with dissolve
    image AlexR03_13 = Movie(play="images/e19/19_0203.webm")
    show AlexR03_13
    call Moan (alex)
    scene 19_0204 with dissolve
    alex "[ss]God...It feels good."
    mc "[whi]It gets better."
    scene 19_0205 with dis1
    image AlexR03_14 = Movie(play="images/e19/19_0206.webm")
    show AlexR03_14
    alex "[ss]Mmmhh."
    scene 19_0207 with dissolve
    image AlexR03_15 = Movie(play="images/e19/19_0208.webm")
    show AlexR03_15
    alex "[ss]...Mmmmhhhh..."
    scene 19_0209 with dissolve
    image AlexR03_16 = Movie(play="images/e19/19_0210.webm")
    show AlexR03_16
    alex "[ss]..Mhhhh.."
    scene 19_0211 with dissolve
    pause 0.5
    scene 19_0212 with dis1
    alex "[ss]..Fuuck.."
    scene 19_0213 with dissolve
    image AlexR03_17 = Movie(play="images/e19/19_0214.webm")
    show AlexR03_17
    alex "[ss]Ohhhh."
    scene 19_0215 with dissolve
    image AlexR03_18 = Movie(play="images/e19/19_0216.webm")
    show AlexR03_18
    pause
    scene 19_0217 with dissolve
    image AlexR03_19 = Movie(play="images/e19/19_0218.webm")
    show AlexR03_19
    call Moan (alex)
    scene 19_0219 with dissolve
    alex "[ss]..Fuck.......Yes....."
    scene 19_0220 with dissolve
    image AlexR03_20 = Movie(play="images/e19/19_0221.webm")
    show AlexR03_20
    alex "[ss]...OHHHHH GOD, YES...."
    scene 19_0222 with dissolve
    image AlexR03_21 = Movie(play="images/e19/19_0223.webm")
    show AlexR03_21
    alex "[ss]..OHHHH....IT'S SO GOOD......"
    scene 19_0224 with dissolve
    pause 0.5
    scene 19_0225 with dis1
    scene 19_0226 with dis1
    image AlexR03_22 = Movie(play="images/e19/19_0227.webm")
    show AlexR03_22
    call Moan (alex, 7)
    scene 19_0228 with dissolve
    image AlexR03_23 = Movie(play="images/e19/19_0229.webm")
    show AlexR03_23
    alex "[ss]..OHHHH, GOD.....[mc!u], YESSS...."
    alex "[ss].....FUUCK........YESSSS....."
    scene 19_0230 with dissolve
    image AlexR03_24 = Movie(play="images/e19/19_0231.webm")
    show AlexR03_24
    alex "[ss]...OHHHHHH..."
    scene 19_0232 with dissolve
    image AlexR03_25 = Movie(play="images/e19/19_0233.webm")
    show AlexR03_25
    pause
    scene 19_0234 with dissolve
    image AlexR03_26 = Movie(play="images/e19/19_0235.webm")
    show AlexR03_26
    call Moan (alex, 7)
    scene 19_0236 with dissolve
    alex "[ss]..OHHHH..."
    scene 19_0237 with dissolve
    pause 0.5
    scene 19_0238 with dis1
    scene 19_0239 with dis1
    call Moan (alex, 7)
    scene 19_0240 with dissolve
    image AlexR03_27 = Movie(play="images/e19/19_0241.webm")
    show AlexR03_27
    alex "[ss]...FUUUCK...."
    scene 19_0242 with dissolve
    image AlexR03_28 = Movie(play="images/e19/19_0243.webm")
    show AlexR03_28
    alex "[ss]....OH MY GOD.....YES...."
    alex "[ss]....OHHHHHH......[mc!u]......."
    alex "[ss]...YES.........YESSS........OHHHHHHH....."
    call CharCum ("e19/19_0242.webp", "e19/19_0244.webp", alex, "....OHHHHHHHHH....")
    call CharCum ("e19/19_0244.webp", "e19/19_0245.webp", alex, "...Ohhhhhh..")
    scene 19_0246 with dissolve
    image AlexR03_29 = Movie(play="images/e19/19_0247.webm")
    show AlexR03_29
    alex "[ss]...Holy fuck..."
    call Emotion (alex, "Breathing heavily")
    alex "[ss]Wow."
    scene 19_0248 with dissolve
    image AlexR03_30 = Movie(play="images/e19/19_0249.webm")
    show AlexR03_30
    call Moan (alex, 4)
    scene 19_0250 with dissolve
    alex "[ss]Mmmmh.....That was awesome...."
    scene 19_0251 with dissolve
    alex "[ss]You want to cum in my pussy?"
    alex "[ss]You can if you'd like to."
    if persistent.Incest and Cara.isSexual() and Cara.getCumIns()>0:
        scene 19_0252 with dissolve
        alex "[ss]Cara said she let you cum in her pussy."
        alex "[ss]You can cum inside mine, too."
    scene 19_0253 with dissolve
    image AlexR03_31 = Movie(play="images/e19/19_0254.webm")
    show AlexR03_31
    call Moan (alex, 4)
    call CmOpts (["Pull out", "Cum inside Alex"])
    $ Copt=_return
    if Copt==1:
        $ Alex.incCm()
        call CharCum ("e19/19_0253.webp", "e19/19_0255.webp", mc, "..NNNGGGGGHHHH..")
        call CharCum ("e19/19_0255.webp", "e19/19_0256.webp", mc, "....Nnnnhhhhh....")
        scene 19_0257 with dis1
        scene 19_0258 with dis1
        alex "[ss]Fuck."
        scene 19_0259 with dissolve
        pause
        scene 19_0260 with dissolve
        pause
        scene 19_0267 with dissolve
    else:
        call CharCum ("e19/19_0253.webp", "e19/19_0261.webp", mc, "..NNNGGGGGHHHH..")
        call CharCum ("e19/19_0261.webp", "e19/19_0262.webp", mc, "....Nnnnhhhhh....")
        scene 19_0263 with dissolve
        alex "[ss]Wow."
        scene 19_0264 with dissolve
        pause
        scene 19_0265 with dissolve
        pause
        scene 19_0266 with dissolve
    alex "[whi]Can I use your bathroom again?\nDon't want to go home to take a shower."
    mc "[whi]Yeah, of course."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
