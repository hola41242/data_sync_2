default persistent.milfork_active = False
default milfork_id = "MF"
default milfork_ch = 1
default milfork_open = False
default milfork_info = [""]

label UpdateMilforkData:
    if len(milfork_info)<=1:
        $ milfork_info.insert(1, "Need to convince a smuggler to help Sue and Melissa leave the country. No chance I can let that actually happen, but I need Sue to believe it.")
    if len(milfork_info)<=2:
        $ milfork_info.insert(2, "Got the proof of life that Priya demanded. Let's hope it's good enough for her.")
return

default persistent.PriyaLocked = True
default Priya_name = ""
define pry = Character("[Priya_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="priya")
image side pry cell = side+"priya_c.png"
default Priya = Stats()


screen Milfork_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "mlf", "priya", Priya_Replay, persistent.PriyaLocked, "The smuggler.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
