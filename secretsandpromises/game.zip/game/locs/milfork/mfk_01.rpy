label Milfork_Start1:
    $ persistent.milfork_active=True
    scene 16_0120 with Fade(2,2,3)
    scene 16_0121 with dis1
    scene 16_0122 with dis1
    scene 16_0123 with dis1
    scene 16_0120 with dis1
    scene 16_0124 with fade1
    call Emotion ("Sat Nav", "You have reached your destination.")
    mc "Are you shitting me?!\nYou've brought me to the middle-of-nowhere!"
    scene 16_0125 with dissolve
    mc "It's a road... has to lead {i}somewhere{/i}."
    call CenterText ("A few minutes later...")
    $ renpy.music.set_volume(0.75)
    $ renpy.music.play("<from 5>rockm.mp3", channel='music', fadein=2)
    scene 16_0126 with fade1
    pause 0.5
    scene 16_0127 with dis1
    scene 16_0128 with dis1
    pause 0.5
    $ renpy.music.set_volume(0.3)
    scene 16_0129 with dissolve
    mct "{b}Not{/b} what I was expecting."
    $ renpy.music.set_volume(0.75)
    scene 16_0130 with dissolve
    scene 16_0131 with dis1
    scene 16_0132 with dis1
    $ renpy.music.set_volume(0.4)
    scene 16_0133 with dissolve
    mct "Damn. Nice place!"
    scene 16_0134 with dis1
    scene 16_0135 with dis1
    pause 0.5
    $ renpy.music.set_volume(0.75)
    scene 16_0136 with dissolve
    mc "HELLO?"
    scene 16_0137 with dissolve
    mc "[whi]Damn it..."
    scene 16_0138 with dissolve
    mc "{size=*1.2}{b}HEY! HELLOOO??{/b}"
    scene 16_0139 with dis1
    scene 16_0140 with dis1
    scene 16_0141 with dissolve
    pause
    scene 16_0142 with dissolve
    mc "WHAT?? I CAN'T HEAR--"
    mc "...CAN YOU TURN DOWN THE MUSIC??"
    scene 16_0143 with dis1
    stop music
    scene 16_0142 with dis1
    pry "I said you must be lost.\nTown's fifteen miles south."
    pry "I suggest you get back in your vehicle and head that way."
    scene 16_0144 with dissolve
    mc "I'm not lost."
    mc "You're Priya, right?\nSue gave me your location, told me to come here."
    $ Priya_name="Priya"
    $ persistent.PriyaLocked=False
    $ Priya.Activate("Priya")
    scene 16_0145 with dissolve
    pry "Who the hell's that? I Don't know a Sue."
    pry "You have thirty seconds to get off my property before I open fire."
    scene 16_0146 with dissolve
    mc "Well, she knows {i}you{/i}.\nShe sent me here to secure your services."
    mc "She has a job for you. Said that you sometimes work for them."
    pry "Twenty seconds left."
    scene 16_0147 with dissolve
    mc "C'mon, Priya!\nYou must know who I'm talking about!"
    mc "Sue, from Springhaven. Hank from Cedar Grove!"
    scene 16_0148 with dissolve
    pry "Ten... Nine... Eight..."
    pry "Better start running..."
    scene 16_0149 with dissolve
    mc "SHE HAS SOMETHING YOU WANT!"
    mc "SHE SAID SHE WOULD GIVE IT TO YOU...."
    scene 16_0150 with dissolve
    pry "He's still alive??"
    mc "Uhh... Yeah."
    scene 16_0151 with dissolve
    pry "Where is he?"
    mc "You know I can't tell you that."
    pry "This had better not be more bullshit."
    mc "It's not. I give you my word."
    scene 16_0152 with dissolve
    pry "I don't know you. Your word doesn't mean shit to me."
    mc "Fair enough."
    scene 16_0153 with dissolve
    pry "I want proof of life."
    mc "Okay."
    scene 16_0154 with dissolve
    pry "What's the cargo size?"
    mc "Uhh, adult."
    scene 16_0155 with dissolve
    pry "{i}Adult{/i}? You want me to smuggle {b}a person{/b} into the country??"
    mc "No.\nWe want you to smuggle {i}two{/i} people {b}out{/b} of the country."
    scene 16_0156 with dis1
    mc "So??"
    pry "Come on."
    scene 16_0157 with dis1
    scene 16_0158 with dis1
    pause 0.5
    scene 16_0159 with dis1
    scene 16_0160 with dis1
    scene 16_0161 with dis1
    pry "Come in."
    scene 16_0162
    mc "Thanks."
    scene 16_0163 with dis1
    scene 16_0164 with dis1
    pry "I don't usually smuggle {i}people{/i}."
    scene 16_0165 with dis1
    pry "They've never wanted me to take something {b}out{/b} of the country before, either."
    scene 16_0166 with dis1
    mc "Is that gonna be a problem?"
    pry "For you? No.\nIt'll be more expensive, though."
    scene 16_0167 with dissolve
    mc "Sue will pay your fee - whatever it is."
    pry "Let me be crystal clear - I'm {b}not{/b} dealing with {i}that{/i} woman."
    pry "If you want to hire me - fine - but I deal with you, not her."
    mc "Right... So you {i}do{/i} know her."
    scene 16_0168 with dissolve
    pry "Count yourself lucky I didn't pull the trigger the second you said {i}her{/i} name."
    scene 16_0169 with dissolve
    pry "Your cargo - What's the destination?"
    scene 16_0170 with dissolve
    mc "Doesn't really matter. Distance is more important.\nAs is discretion."
    pry "You're joking, right?"
    scene 16_0171 with dissolve
    pry "If I weren't discreet, I wouldn't be the best at what I do."
    scene 16_0172 with dissolve
    mc "This one needs to be {i}extra{/i} discreet."
    pry "What does {i}that{/i} mean?"
    scene 16_0173 with dissolve
    mc "The circle needs to stay small - You, me, and Sue - That's it. Nobody else can know."
    pry "The more you tell me, the less I like it."
    scene 16_0174 with dissolve
    pry "There's only one reason I'll do this."
    pry "Proof of life first, then we can talk."
    mc "A photo good enough?"
    scene 16_0175 with dissolve
    pry "How would I know it was recent?"
    pry "{b}You{/b} need to be in it, too."
    scene 16_0176 with dissolve
    pry "I want a photograph of you, with Bruno."
    pry "Cover one of your eyes with a spoon."
    pry "... And pull on his ear."
    scene 16_0177 with dissolve
    mc "{i}Pull on his ear{/i}??"
    pry "Those are my terms."
    scene 16_0178 with dissolve
    mc "Then we have ourselves a deal."
    pry "Don't try to screw me over. I'll know if the picture's fake."
    scene 16_0179 with dissolve
    pry "And tell them {b}never{/b} to contact me again."
    pry "After this, I'm out. Permanently."
    scene 16_0180 with dissolve
    mc "You sure that's wise?"
    mc "I heard they don't let people like us walk away."
    scene 16_0181 with dissolve
    pry "Hank knows I have an insurance policy. They won't come after me."
    pry "It's why they took Bruno, and I won't make that same mistake again."
    scene 16_0182 with dissolve
    pry "Sorry, but you need to leave."
    pry "I have somewhere to be, and thanks to you, I'm behind schedule."
    scene 16_0183 with dissolve
    mc "Right... Sorry."
    scene 16_0184 with dissolve
    pry "Bring me the picture, and we can discuss your contract."
    mc "Can't I just send it to you?"
    scene 16_0185 with dissolve
    pry "No.\nI want {b}you{/b} to deliver it personally."
    pry "If it's real - we can talk.\nIf not... I have a pretty spot out by the river where I'll bury you."
    scene 16_0186 with fade
    pry "You never told me your name."
    mc "[mc]."
    scene 16_0187 with dissolve
    pry "Nice to meet you, [mc].\nDon't come back without the photo."
    mc "Understood."
    scene 16_0188 with dis1
    pause 0.5
    scene 16_0189 with fade
    scene 16_0190 with dis1
    scene 16_0191 with dis1
    jump Milfork_Leave
return

label Milfork_Leave:
    scene black with Fade(3, 2, 0)
    $ milfork_open=False
    $ milfork_ch+=1
    call CheckShOpen
    jump ShowMap
return

label Milfork_Start2:
    scene 19_0286 with Fade(0, 2, 3)
    pause 0.5
    scene 19_0287 with dis1
    scene 19_0288 with dis1
    play sound "knock.mp3" volume 0.5
    scene 19_0289 with dissolve
    pause
    scene 19_0290 with dissolve
    play sound "knock.mp3" volume 1.0
    scene 19_0291 with dis1
    scene 19_0290 with dis1
    pause 0.5
    scene 19_0292 with dissolve
    mc "You shouldn't sneak up on people."
    scene 19_0293 with dissolve
    pry "A girl can't be too careful."
    pry "You should've called first."
    scene 19_0294 with dissolve
    mc "You didn't give me your number."
    scene 19_0295 with dissolve
    mc "You gonna point a gun at me {i}every{/i} time we meet?"
    pry "Probably."
    scene 19_0296 with dissolve
    pry "Do you have it?"
    mc "I wouldn't have come back if I didn't."
    scene 19_0297 with dissolve
    pry "Show me."
    scene 19_0298 with dissolve
    mc "See? Pulling on his ear, just like you wanted."
    scene 19_0299 with dissolve
    pry "Where's the spoon?\nI said cover your eye with a spoon."
    mc "I didn't have one, and didn't have time to go searching."
    scene 19_0300 with dissolve
    mc "If you swipe to the next photo, you'll see I closed one of my eyes instead..."
    mc "It was the best I could do under the circumstances."
    scene 19_0301 with dissolve
    pry "[whi]Bruno."
    pry "He's lost weight."
    scene 19_0302 with dissolve
    pry "The plane doesn't take off until he's been returned safe and well."
    mc "Okay."
    pry "That's non-negotiable.\nNo Bruno, no flight."
    mc "Understood."
    scene 19_0303 with dissolve
    pry "Come on."
    scene 19_0304 with dis1
    scene 19_0305 with dis1
    pause 0.5
    scene 19_0306 with dissolve
    pry "What little you've told me about this job is already enough for me to normally decline the contract."
    pry "Too many red flags."
    scene 19_0307 with dissolve
    pry "I need more information if we're to work together."
    pry "{b}Who{/b} are the passengers? And who are they running from?"
    scene 19_0308 with dissolve
    mc "What makes you think they're running? I didn't say that."
    pry "Yeah, you did."
    pry "You told me destination wasn't important, only distance and discretion."
    scene 19_0309 with dissolve
    pry "Don't need to be a genius to figure out why."
    pry "I need to know if this is going to come back and bite me in the ass."
    pry "So {b}who{/b} are they running from?"
    scene 19_0310 with dissolve
    menu:
        "[wk_y]Answer honestly":
            $ Priya.Score(1)
            $ Priya.Add("A00")
            scene 19_0311 with dissolve
            mc "Anton the Axe."
            scene 19_0312 with dissolve
            pry "Fuck."
            pry "What the hell did they do to piss {i}him{/i} off?"
            scene 19_0313 with dissolve
            mc "I take it you know him... So you'll know it doesn't take a lot."
            pry "Yeah.\nYou make his ledger - you'd {b}better{/b} run."
            scene 19_0314 with dissolve
            pry "I don't want my name to be next on his list."
            mc "It won't be.\nNo one knows you're helping, and it'll stay that way."
            scene 19_0315 with dissolve
            pry "You can't guarantee that."
            pry "You really expect me to trust your boss?"
            scene 19_0316 with dissolve
            mc "I'm guessing in your line of work you don't trust anyone."
            mc "So I'm not here to try and convince you to trust me {i}or{/i} Sue."
        "Answer vaguely":
            scene 19_0311 with dissolve
            mc "An abusive husband and father."
            scene 19_0312 with dissolve
            pry "People don't usually need to be smuggled out of the country for that."
            pry "Who is he?"
            scene 19_0313 with dissolve
            mc "Just someone who holds on to a grudge. He'll never let them go."
            pry "I've known guys like that. They're a fuckin' nightmare."
            scene 19_0314 with dissolve
            pry "Still... Isn't leaving the country a bit of an overreaction??"
            pry "And why me? Why not go to any airport and jump on the first flight out?"
            mc "They don't have the required documention."
            scene 19_0315 with dissolve
            pry "Your boss could get them {i}any{/i} documents they need."
            pry "What aren't you telling me?"
            scene 19_0316 with dissolve
            mc "Nothing you need to know to get the job done."
            mc "I've already told you more than I should."
    mc "Bottom line is you want Bruno back and this job helps you achieve that."
    scene 19_0317 with dissolve
    pry "How do you know I won't just shoot you once Bruno's home?"
    mc "I don't.\nBut I keep my word and I'm hoping you'll do the same."
    scene 19_0318 with dissolve
    pry "Who {i}are{/i} you, [mc]?"
    pry "You don't strike me as the usual type of idiot your boss normally hires."
    scene 19_0319 with dissolve
    mc "Was that a compliment??"
    pry "I wouldn't go {i}that{/i} far."
    mc "Nope, I'm taking it as a compliment."
    scene 19_0320 with dissolve
    pry "[lol]{w=0.5}{nw}"
    scene 19_0321 with dissolve
    pry "Okay, I take it back... You {i}are{/i} an idiot."
    scene 19_0322 with dissolve
    mc "You haven't shot me or kicked me out, so I guess we have a deal?"
    if Priya.Has("A00"):
        pry "Fifty thousand, cash. Per passenger. Upfront."
        mc "Damn! That's steep!"
        scene 19_0323 with dissolve
        pry "You're asking me to take a huge risk.\nThere's a reason why no one fucks with Anton."
        pry "Anything goes wrong and your clients aren't the only ones who'll need to disappear."
        pry "Your boss {i}knows{/i} that.\nThe only reason I'm not charging {b}more{/b} is Bruno."
    else:
        pry "Ten thousand, cash. Per passenger. Upfront."
        mc "Done."
    scene 19_0324 with dissolve
    mc "Looks like we have ourselves an agreement."
    scene 19_0325 with dissolve
    mc "If we exchange numbers I'll be in touch.\nOnce they're ready to leave it'll need to happen quickly."
    scene 19_0326 with dissolve
    pry "{i}Nothing{/i} happens until {b}after{/b} I've had Bruno and the cash."
    pry "You pay in advance."
    mc "And how do I know you'll be there when we need you?\nIf you already have the dog and the cash..."
    scene 19_0327 with dissolve
    pry "Guess you'll need to {i}keep{/i} hoping I'm good for my word."
    scene 19_0328 with dissolve
    pry "Those are my terms. Take it or leave it."
    scene 19_0329 with dissolve
    mc "Guess I have no choice {i}but{/i} to take it."
    pry "I'll get you my number."
    scene 19_0330 with fade1
    pry "Don't come back without my dog."
    scene 19_0331 with dissolve
    mc "It wasn't Sue, you know..."
    scene 19_0332 with dissolve
    mc "Is that why you refuse to even say her name?\nYou blame {i}her{/i} for taking Bruno?"
    pry "So who was it?"
    menu:
        "I can't tell you that":
            scene 19_0333 with dissolve
            pry "You can't, or you {b}won't{/b}?"
            pry "It doesn't matter. They'll pay for what they've done eventually."
        "[wk_y]It was Jemma":
            $ Priya.Score(1)
            $ Priya.Add("A01")
            scene 19_0333 with dissolve
            pry "I know.\nShe didn't even {i}try{/i} to hide from my security cameras."
            pry "She {b}wanted{/b} me to know it was her."
            scene 19_0334 with dissolve
            pry "I didn't expect that you'd tell me, though. Thank you."
            pry "You know they'd kill you for that if they ever found out.\nThey take loyalty very seriously."
            scene 19_0335 with dissolve
            mc "Fuck 'em.\nI'm only loyal to the people I care about."
            pry "That's a dangerous moral to have in your position."
    scene 19_0336 with dissolve
    pry "Anyway, that's not the reason for me hating {i}that woman{/i}."
    mc "Okay. So what is?"
    pry "She's responsible for the murder of a close friend."
    scene 19_0337 with dissolve
    mc "Oh. I'm sorry."
    mc "I don't mean to sound insensitive, but is working with her going to be a problem for you?"
    scene 19_0338 with dissolve
    pry "No, because I won't be working with her. {i}You{/i} work for her."
    pry "My contract is with {b}you{/b}."
    pry "Where you get the money to pay my fee is none of my business."
    scene 19_0339 with dissolve
    pry "But if you don't want to pay in cash, you're welcome to bring me her head."
    pry "That'll be a more than acceptable alternative."
    scene 19_0340 with dissolve
    mc "Yeah, let's stick with cash."
    scene 19_0341 with dissolve
    pry "Your call."
    mc "I'll be in touch."
    scene 19_0342 with dis1
    scene 19_0343 with dis1
    scene 19_0344 with dis1
    scene 19_0345 with dis1
    jump Milfork_Leave
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
