label LucyReplay01:
    call Unlocker ("LucyReplay01")
    $ Lucy.incSex()
    scene 22_0196 with fade1
    luc "Mmhh.\nYou can't deny this is lovely."
    scene 22_0197 with dissolve
    luc "Thanks, [persistent.McName]. I know I'm being silly.\nI just miss this!"
    mc "Anytime."
    scene 22_0198 with dissolve
    luc "What's that smell?? Is that your t-shirt?!"
    mc "Uhh, yeah... sorry.\nWent horse riding earlier."
    scene 22_0199 with dissolve
    luc "Oh God, take it off! It stinks!"
    mc "Jeez, okay!"
    scene 22_0200 with dissolve
    luc "Your jeans, too. They're probably just as bad, and they scratch against my skin."
    scene 22_0201 with dissolve
    mc "Seriously?"
    luc "You have underwear on, don't you?"
    mc "Uhh..."
    scene 22_0202 with dissolve
    mc "Yep, guess I do."
    luc "You weren't sure??"
    scene 22_0203 with fade1
    mc "Better?"
    luc "Yes. Much!"
    scene 22_0204 with dissolve
    luc "I didn't mean to be so bossy. Sorry."
    mc "I kinda liked it. It was a bit of a turn-on!"
    scene 22_0205 with dissolve
    luc "[lol] Do bossy women turn you on, [persistent.McName]?"
    mc "Only if she's my sister."
    scene 22_0206 with dissolve
    luc "You're {i}so{/i} weird."
    mc "Yeah, you keep telling me."
    scene 22_0207 with dis1
    mc "[kiss]"
    scene 22_0208 with dis1
    pause 0.5
    scene 22_0209 with dis1
    luc "[ss]Mmh."
    scene 22_0210 with dissolve
    pause
    scene 22_0211 with dissolve
    luc "[ss]Mmhhh."
    scene 22_0212 with dis1
    luc "I also told you {i}that's{/i} not how brothers kiss their sisters."
    mc "I'm rewriting that rule."
    scene 22_0213 with dissolve
    mc "Because I intend to always kiss you like that from now on."
    scene 22_0214 with dis1
    luc "[ss]Mmhhh."
    scene 22_0215 with dissolve
    luc "[ss]..Mmhhh.."
    scene 22_0216 with dis1
    pause 0.5
    scene 22_0217 with dis1
    luc "[ss]Mhhh."
    scene 22_0218 with dissolve
    luc "[ss]..Mmhhh.."
    scene 22_0219 with dissolve
    pause 0.5
    scene 22_0220 with dis1
    pause 0.5
    scene 22_0221 with dis1
    pause 0.5
    scene 22_0222 with dis1
    pause 0.5
    scene 22_0223 with dis1
    pause 0.5
    scene 22_0224 with dissolve
    luc "[whi][persistent.McName]... Don't."
    scene 22_0225 with dissolve
    image LucyR01_01 = Movie(play="images/e22/22_0226.webm", loop=False, keep_last_frame=True)
    show LucyR01_01
    pause 3.0
    luc "[whi]Fuuck."
    scene 22_0227 with dissolve
    image LucyR01_02 = Movie(play="images/e22/22_0228.webm")
    show LucyR01_02
    luc "[ss]..Ohh..."
    luc "[whi]...God, we can't do this... It's not right..."
    scene 22_0229 with dissolve
    mc "[whi]Do you want me to go?"
    call Moan (luc)
    scene 22_0230 with dissolve
    luc "[whi]... I want you to stay."
    scene 22_0231 with dis1
    luc "[ss]Mmhh."
    scene 22_0232 with dissolve
    image LucyR01_03 = Movie(play="images/e22/22_0233.webm")
    show LucyR01_03
    luc "[ss]..Mmmhh.."
    scene 22_0234 with dissolve
    image LucyR01_04 = Movie(play="images/e22/22_0235.webm")
    show LucyR01_04
    pause
    scene 22_0236 with dissolve
    luc "[ss]Mmhh."
    scene 22_0237 with dis1
    scene 22_0238 with dis1
    scene 22_0239 with dis1
    scene 22_0240 with dis1
    image LucyR01_05 = Movie(play="images/e22/22_0241.webm")
    show LucyR01_05
    luc "[ss]..Ohhhhh..."
    scene 22_0242 with dissolve
    luc "[ss]..Ohh god, it shouldn't feel this good......."
    scene 22_0243 with dissolve
    image LucyR01_06 = Movie(play="images/e22/22_0244.webm")
    show LucyR01_06
    call Moan (luc)
    scene 22_0245 with dissolve
    luc "[whi]...Fuck, [persistent.McName]... What are we doing?..."
    luc "[ss]..Mmhh.."
    luc "[whi]..This is {b}so{/b} wrong.."
    scene 22_0246 with dissolve
    call Moan (luc)
    luc "[whi]..I can't stop, though...."
    luc "[whi].... I don't {i}want{/i} to stop...."
    scene 22_0247 with dis1
    luc "[ss]..Mmhh.."
    scene 22_0249 with dis1
    call Moan (luc)
    scene 22_0250 with dissolve
    image LucyR01_07 = Movie(play="images/e22/22_0251.webm")
    show LucyR01_07
    call Moan (luc)
    scene 22_0252 with dis1
    luc "[ss]..Mmmhh.."
    scene 22_0253 with dissolve
    pause 0.5
    scene 22_0254 with dis1
    scene 22_0255 with dis1
    scene 22_0256 with dis1
    image LucyR01_08 = Movie(play="images/e22/22_0257.webm")
    show LucyR01_08
    luc "[ss]...OH GOD.... YES...."
    scene 22_0258 with dissolve
    image LucyR01_09 = Movie(play="images/e22/22_0259.webm")
    show LucyR01_09
    call Moan (luc)
    luc "[ss]....OHH [persistent.McName!u]..... YES....."
    scene 22_0260 with dissolve
    image LucyR01_10 = Movie(play="images/e22/22_0261.webm")
    show LucyR01_10
    call Moan (luc, 6)
    scene 22_0262 with dissolve
    luc "[ss]...OH GOD..."
    scene 22_0263 with dissolve
    image LucyR01_11 = Movie(play="images/e22/22_0264.webm")
    show LucyR01_11
    luc "[ss]....OHH....YES....."
    luc "[ss]..OHHHH.......FUCK ME, [persistent.McName!u]....."
    luc "[ss]...YES....OHHHHH.....FUCK ME......."
    scene 22_0265 with dissolve
    image LucyR01_12 = Movie(play="images/e22/22_0266.webm")
    show LucyR01_12
    call Moan (luc, 8)
    luc "[ss]...OHHHH, [persistent.McName!u].....YOU'RE GOING TO MAKE ME ORGASM......I'M CLOSE......GOD......."
    scene 22_0267 with dissolve
    image LucyR01_13 = Movie(play="images/e22/22_0268.webm")
    show LucyR01_13
    call Moan (luc, 8)
    luc "[ss]...OHHH, [persistent.McName!u]....YES...."
    luc "[ss]....{b}YES!{/b}.....{b}YEEESS!{/b}......"
    call Moan (luc, 9)
    call CharCum ("e22/22_0267.webp", "e22/22_0269.webp", luc, "...OHHHHHH...")
    call CharCum ("e22/22_0269.webp", "e22/22_0270.webp", luc, "..Fuck..")
    image LucyR01_14 = Movie(play="images/e22/22_0271.webm")
    show LucyR01_14
    luc "[ss]...Ohhhh..."
    pause
    call CmOpts (["Cum inside Lucy", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Lucy.incCm()
        call CharCum ("e22/22_0270.webp", "e22/22_0272.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e22/22_0272.webp", "e22/22_0273.webp", mc, "....Nnnhhhh....")
        scene 22_0277 with dis1
        scene 22_0278 with dis1
        call EmotionSml (mc, "Breathing heavily", "..Fuck..")
        scene 22_0280 with dissolve
        luc "[whi]God. What have we done, [persistent.McName]?"
        mc "[whi]Something we {i}both{/i} wanted to do."
        scene 22_0281 with dissolve
        luc "I'm your {i}sister{/i}!"
        scene 22_0283 with dissolve
        mc "So?"
        mc "Tell me you didn't enjoy it?"
        luc "That's not the point!"
        scene 22_0284 with dissolve
    else:
        call CharCum ("e22/22_0270.webp", "e22/22_0274.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e22/22_0274.webp", "e22/22_0275.webp", mc, "....Nnnhhhh....")
        scene 22_0276 with dis1
        scene 22_0279 with dis1
        call EmotionSml (mc, "Breathing heavily", "..Fuck..")
        scene 22_0280 with dissolve
        luc "[whi]God. What have we done, [persistent.McName]?"
        mc "[whi]Something we {i}both{/i} wanted to do."
        scene 22_0281 with dissolve
        luc "But I'm your {i}sister{/i}!"
        scene 22_0282 with dissolve
        mc "So?"
        mc "Tell me you didn't enjoy it?"
        luc "That's not the point!"
        scene 22_0285 with dissolve
    luc "Jesus, we're {i}so{/i} gonna regret this tomorrow when we're sober!"
    mc "Lucy, I'm not drunk. I only had a couple of beers."
    scene 22_0286 with dissolve
    luc "Don't be ridiculous! Of course you are.\nWe both are!"
    luc "Now, I'm going to get cleaned up, and then you can cuddle me to sleep - as you promised."
    mc "Fine."
    scene 22_0287 with fade1
    luc "[whi]..Zzzzz.."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
