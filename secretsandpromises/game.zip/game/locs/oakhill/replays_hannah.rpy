label HannahReplay01:
    call Unlocker ("HannahReplay01")
    if not _in_replay:
        $ persistent.HannahRP01Dat= Hannah.Has("Knows")
    $ Hannah.isSexual(True)
    scene 15_0031 with dis1
    scene 15_0032 with dis1
    scene 15_0033 with dis1
    scene 15_0034 with dis1
    han "What you doing, Unc??"
    mc "Don't worry, Jane. I got you!\nI'll put her off from this side, and you can kick her butt from that side!"
    scene 15_0035 with dissolve
    han "[lol]"
    scene 15_0036 with dissolve
    han "Game on!"
    scene 15_0037 with dissolve
    han "[whi]And just so you know..."
    han "[whi]I {i}refuse{/i} to lose again."
    scene 15_0038 with dissolve
    scene 15_0039 with dis1
    mc "Is that so?"
    han "Yep."
    scene 15_0040 with dissolve
    pause 0.5
    scene 15_0041 with dis1
    scene 15_0042 with dis1
    scene 15_0043 with dis1
    han "Won't work!"
    scene 15_0044 with dissolve
    han "I kinda enjoyed it the last time, so {i}that{/i} won't distract me."
    scene 15_0045 with dissolve
    han "Huh?\nNo... I was talking to my uncle."
    scene 15_0046 with dissolve
    han "Sorry, but... he ain't doin' a very good job at helping you!"
    scene 15_0047 with dissolve
    han "No, he's failing!"
    scene 15_0048 with dissolve
    pause 0.5
    if persistent.FootPlay:
        call AutoA ()
        scene 15_0049 with dis1
        $ apause()
        scene 15_0050 with dissolve
        $ apause()
        scene 15_0051 with dis1
        $ apause()
        scene 15_0052 with dis1
        $ apause()
        scene 15_0053 with dis1
        $ apause()
        scene 15_0054 with dis1
        $ apause()
        scene 15_0055 with dis1
        $ apause()
        scene 15_0056 with dis1
        $ apause(0.5, True)
        scene 15_0057 with dissolve
        han "Awww, bless... He's {i}really{/i} tryin' now!"
    scene 15_0058 with dissolve
    han "He should probably just give up... if that's all he's got."
    scene 15_0059 with dissolve
    pause
    call AutoA ()
    scene 15_0060 with dis1
    mc "[kiss]"
    scene 15_0061 with dis1
    $ apause()
    scene 15_0062 with dis1
    $ apause()
    scene 15_0063 with dis1
    $ apause()
    scene 15_0064 with dis1
    $ apause()
    scene 15_0065 with dis1
    $ apause(0.5, True)
    scene 15_0066 with dissolve
    han "[whi]Damn it!"
    han "... Yeah."
    scene 15_0067 with dissolve
    han "I know... Me too."
    scene 15_0068 with dissolve
    han "He's definitely gonna give up before I do!"
    scene 15_0069 with dissolve
    han "Nah, he's bluffing."
    scene 15_0070 with dissolve
    han "Right, Unc?\nYou can say it, there's no shame in taking the L!"
    scene 15_0071 with dissolve
    mc "Not a chance!"
    scene 15_0072 with dissolve
    mc "We both know {i}you'll{/i} fold before I do, so now's a good time to say those words."
    scene 15_0073 with dissolve
    han "..."
    scene 15_0074 with dissolve
    mc "[whi]You'll fold..."
    scene 15_0075 with dissolve
    mct "I know you will."
    call AutoA ()
    scene 15_0074 with dissolve
    $ apause()
    scene 15_0076 with dis1
    $ apause(0.5, True)
    scene 15_0077 with dis1
    scene 15_0078 with dissolve
    han "AAHHH!!{w=0.5}{nw}"
    scene 15_0079 with dissolve
    han "[lol]"
    scene 15_0080 with dissolve
    pause 0.5
    scene 15_0081 with dis1
    han "..."
    mct "Wow... Expected her to quit then!"
    scene 15_0082 with dis1
    mct "Looks like she finally has me..."
    scene 15_0083 with dissolve
    mct "I'll have to call it!"
    scene 15_0082 with dissolve
    pause 0.5
    scene 15_0081 with dis1
    pause 0.5
    scene 15_0082 with dis1
    mct "Fuck it... Just a little closer and she'll quit."
    scene 15_0084 with dis1
    mc "[kiss]"
    scene 15_0085 with dis1
    mc "[kiss]"
    scene 15_0086 with dis1
    mc "[whi]Did you say something, Han?"
    scene 15_0087 with dis1
    scene 15_0088 with dis1
    scene 15_0089 with dis1
    han "[whi]Nope."
    scene 15_0090 with dissolve
    mct "Damn! Heh, guess I lose this round!"
    scene 15_0091 with dissolve
    mct "No, [persistent.McName]... Don't do it! Just give her the win!"
    mct "..."
    mct "Nah..."
    scene 15_0092 with dis1
    mc "[kiss]"
    scene 15_0091 with dis1
    pause 0.5
    scene 15_0093 with dis1
    scene 15_0094 with dis1
    scene 15_0091 with dis1
    scene 15_0095 with dissolve
    mc "Okay... Maybe we call this one a draw?"
    scene 15_0096 with dissolve
    han "Say the words, Unc."
    scene 15_0097 with dis1
    scene 15_0098 with dis1
    han "Or we keep playing."
    scene 15_0099 with dis1
    scene 15_0100 with dissolve
    mc "[whi]Hannah... You know I won't quit."
    scene 15_0101 with dissolve
    han "[whi]So we keep going 'til one of us does."
    mc "[whi]What about your friend?"
    scene 15_0102 with dissolve
    han "[whi]She already left."
    scene 15_0103 with dissolve
    mc "[whi]..."
    han "[whi]..."
    scene 15_0104 with dis1
    pause 0.5
    scene 15_0105 with dissolve
    pause 0.5
    scene 15_0106 with dis1
    scene 15_0107 with dis1
    pause 0.5
    scene 15_0108 with dissolve
    han "[whi]Shit... I wasn't sure you'd actually do it!"
    scene 15_0109 with dissolve
    image HannahR01_01 = Movie(play="images/e15/15_0110.webm")
    show HannahR01_01
    pause
    scene 15_0111 with dissolve
    if persistent.HannahRP01Dat:
        han "[ss]God, Millie was right... It feels so damn nice!...."
    else:
        han "[ss]God, I didn't think it would feel this damn nice!...."
    scene 15_0112 with dissolve
    scene 15_0113 with dis1
    scene 15_0114 with dis1
    mct "She tastes so damn good."
    scene 15_0115 with dissolve
    han "[ss]...Fuck...."
    scene 15_0116 with dissolve
    han "[ss]..Ohhhh.."
    scene 15_0117 with dissolve
    scene 15_0118 with dis1
    scene 15_0119 with dis1
    pause 0.5
    scene 15_0120 with dissolve
    han "[ss].....Holy shit....."
    scene 15_0121
    luc "[whi]HANNAH?" with hpunch
    luc "[whi]Is Uncle [persistent.McName] up there with you?\nHis truck's parked out front."
    scene 15_0122 with dissolve
    han "[whi]FUCK!!"
    scene 15_0123 with dissolve
    han "UHH... YEAH, MOM...."
    mc "HI, SIS... I'LL BE RIGHT DOWN."
    luc "[whi]Okay."
    scene 15_0124 with dissolve
    han "[whi]Jesus, that was close!"
    scene 15_0125 with dissolve
    han "I thought she was about to walk in on us!"
    scene 15_0126 with dissolve
    mc "I'd better go see her."
    han "Yeah."
    scene 15_0127 with dissolve
    han "Hey Unc, might wanna wipe your chin first... It's a little... wet."
    mc "Heh, thanks."
    if _in_replay:
        scene black with fade1
        scene 15_0262 with dissolve
        han "Sorry about the smell in there. I have a gross pig for a brother."
        scene 15_0263 with dissolve
        mc "Heh. I didn't even notice."
        mc "Some of the barracks I've had to stay at... The smell would make your eyes water! You'd be horrified!"
        han "[lol]"
        han "Okay, goodnight Unc."
        mc "Night Sweetheart."
        scene 15_0264 with dis1
        scene 15_0265 with dissolve
        mct "Hah... Course I noticed!"
        scene 15_0266 with dissolve
        mct "Seriously... What the hell {b}has{/b} he been doing in here??"
        call HannahReplay01_P2
return

label HannahReplay01_P2:
    scene 15_0270 with dissolve
    han "Oh, wait, there {i}was{/i} something else..."
    scene 15_0271 with dissolve
    han "... No one has won yet."
    scene 15_0272 with dissolve
    han "Which means..."
    scene 15_0273 with dissolve
    han "... The round isn't over."
    scene 15_0274 with dissolve
    mc "Han..."
    han "She's asleep."
    scene 15_0275 with dissolve
    han "I went in to say goodnight, and she's already snoring."
    scene 15_0276 with dissolve
    han "We both know the rules, Unc."
    scene 15_0277 with dissolve
    han "It's not over until one of us quits."
    scene 15_0278 with dissolve
    han "I didn't say the words yet..."
    han "And I know {i}you{/i} haven't."
    scene 15_0279 with dissolve
    han "So, unless you want to say them now..."
    scene 15_0280 with dissolve
    han "... you'll have to finish eating me."
    scene 15_0281 with dissolve
    han "Anything you want to say to me, Uncle [persistent.McName]?"
    mc "..."
    scene 15_0282 with dissolve
    pause
    scene 15_0283 with dissolve
    mc "[whi]...Rules are rules..."
    scene 15_0284 with dissolve
    pause
    scene 15_0285 with dissolve
    image HannahR01_02 = Movie(play="images/e15/15_0286.webm")
    show HannahR01_02
    pause
    scene 15_0287 with dissolve
    han "[ss]...God..."
    scene 15_0288 with dissolve
    image HannahR01_03 = Movie(play="images/e15/15_0289.webm")
    show HannahR01_03
    han "[ss]..Fuuck, Unc...."
    scene 15_0285 with dissolve
    image HannahR01_04 = Movie(play="images/e15/15_0290.webm")
    show HannahR01_04
    pause
    scene 15_0291 with dissolve
    han "[ss]...OHH MY GOD..."
    scene 15_0292 with dissolve
    call Moan (han, 4)
    scene 15_0293 with dis1
    scene 15_0294 with dis1
    scene 15_0295 with dis1
    han "[ss]...Ohhhh..."
    scene 15_0296 with dissolve
    han "[ss]...Holy shit..."
    scene 15_0297 with dissolve
    call Moan (han)
    scene 15_0298 with dissolve
    image HannahR01_05 = Movie(play="images/e15/15_0299.webm")
    show HannahR01_05
    pause
    scene 15_0300 with dissolve
    han "[ss]....Ohhhhh...."
    scene 15_0301 with dis1
    scene 15_0302 with dissolve
    scene 15_0303 with dis1
    scene 15_0304 with dis1
    scene 15_0305 with dis1
    scene 15_0306 with dis1
    scene 15_0307 with dis1
    call Moan (han)
    scene 15_0308 with dissolve
    han "[ss]...Ohhh, God, Unc........Yes, keep doing that......"
    scene 15_0309 with dissolve
    pause 0.5
    scene 15_0310 with dis1
    call Moan (han)
    scene 15_0311 with dissolve
    han "[ss]..Ohhh.."
    scene 15_0312 with dissolve
    call Moan (han)
    scene 15_0313 with dissolve
    pause
    scene 15_0314 with dissolve
    scene 15_0315 with dis1
    scene 15_0316 with dis1
    call Loop_Dissolve (6, False, False, "e15/15_0317.webp", "e15/15_0318.webp")
    if persistent.Anal:
        scene 15_0319 with dis1
        scene 15_0320 with dis1
        scene 15_0321 with dis1
        scene 15_0322 with dis1
        scene 15_0323 with dis1
        pause
        scene 15_0324 with dissolve
        han "DUDE!!"
        scene 15_0325 with dissolve
        mc "Got anything to say, Han?"
        scene 15_0326 with dis1
        scene 15_0327 with dis1
        han "[whi]Nope."
        scene 15_0328 with dis1
        han "[ss]Mhhh."
        scene 15_0329 with dissolve
        han "[ss]It's a weird sensation..."
        han "[ss]... Not gonna lie, though... I kinda like it!...."
        call Loop_Dissolve (4, False, False, "e15/15_0330.webp", "e15/15_0331.webp")
        scene 15_0332 with dissolve
        pause
        scene 15_0333 with dissolve
        han "[ss]....Fuuuck...."
    else:
        scene 15_0329 with dissolve
        han "[ss]...Ohhhhh..."
    scene 15_0334 with dissolve
    mct "This is so damn hot... Need to..."
    scene 15_0335 with dis1
    scene 15_0336 with dis1
    scene 15_0337 with dis1
    image HannahR01_06 = Movie(play="images/e15/15_0338.webm")
    show HannahR01_06
    call Moan (han)
    scene 15_0339 with dissolve
    pause
    scene 15_0340 with dissolve
    scene 15_0341 with dis1
    han "[ss]..Ohhh.."
    scene 15_0342 with dis1
    scene 15_0343 with dis1
    han "[ss]..Mmmhh.."
    scene 15_0344 with dis1
    scene 15_0345 with dis1
    han "[whi]Unc..."
    scene 15_0346 with dis1
    scene 15_0347 with dissolve
    han "[whi]I'll do that."
    scene 15_0348 with dis1
    scene 15_0349 with dis1
    scene 15_0350 with dis1
    scene 15_0351 with dis1
    image HannahR01_07 = Movie(play="images/e15/15_0352.webm")
    show HannahR01_07
    pause
    scene 15_0353 with dissolve
    image HannahR01_08 = Movie(play="images/e15/15_0354.webm")
    show HannahR01_08
    call Moan (han)
    scene 15_0355 with dissolve
    han "[ss]...Ohhhhh.....Yes......"
    han "[ss]......I'm so close........Ohhhhhhh......"
    scene 15_0356 with dissolve
    image HannahR01_09 = Movie(play="images/e15/15_0357.webm")
    show HannahR01_09
    han "[ss]...Fuck..... Yes...."
    han "[ss]...OHHHHH...."
    call CharCum ("e15/15_0356.webp", "e15/15_0358.webp", han, "...Ohhhhhhhhhh...")
    call CharCum ("e15/15_0358.webp", "e15/15_0359.webp", mc, "..Nnnnggghhhh..")
    call CharCum ("e15/15_0359.webp", "e15/15_0360.webp", han, "..Mmmmhhhh..")
    call CharCum ("e15/15_0360.webp", "e15/15_0361.webp", mc, "...Nnnhhhh...")
    scene 15_0362 with dissolve
    han "[ss]Mmhhh."
    han "[ss]Holy shit. That was the best!"
    scene 15_0363 with dissolve
    mc "[whi]Yeah, it was."
    scene 15_0364 with dissolve
    han "[whi]Guess you were right, we'll have to call it a draw."
    scene 15_0366 with dissolve
    mc "[whi][kiss]"
    scene 15_0364 with dissolve
    mc "[whi]I can live with that."
    scene 15_0367 with fadehold
    han "Night, Unc."
    mc "Goodnight, Han."
    scene 15_0368 with dis1
    scene 15_0369 with dis1
    scene black with ReplayFade
return

label HannahReplay02:
    call Unlocker ("HannahReplay02")
    $ Hannah.incSex()
    scene 18_0142 with Fade(0,1,2)
    pause 0.5
    scene 18_0143 with dissolve
    pause 0.5
    scene 18_0144 with dis1
    scene 18_0145 with dis1
    han "[whi]Unc. Wake up."
    call Emotion (mc, "Groan", "", True)
    scene 18_0146 with dissolve
    mc "[whi]Hannah?"
    han "[whi]I found something in my room. I need your help."
    mc "[whi]Uhh... Okay... Gimme a minute."
    scene 18_0147 with dissolve
    han "[whi]Come on."
    scene 18_0148 with dissolve
    call EmotionSml (mc, "Sigh", "...I'm comin'.")
    scene 18_0149 with dis1
    scene 18_0150 with dis1
    scene 18_0151 with dis1
    scene 18_0152 with dis1
    mc "Okay... What did you find?"
    scene 18_0153 with dissolve
    han "Alone time."
    scene 18_0154 with dissolve
    mc "You wanna risk it with your mom in the house?"
    scene 18_0155 with dissolve
    han "Did you see how many empty beer bottles there are downstairs?\nShe's out for the count."
    scene 18_0156 with dis1
    scene 18_0157 with dis1
    mc "She thought you were staying over at Millie's tonight."
    scene 18_0158 with dissolve
    han "I was... But I made an excuse to come home."
    mc "Why?"
    han "Aunt Vi told us you'd decided to stay overnight."
    scene 18_0159 with dissolve
    han "And I don't like draws, so we have a game to finish."
    scene 18_0160 with dissolve
    han "So, {i}say the words{/i}, Unc, or..."
    mc "I'm never gonna say them."
    scene 18_0161 with dissolve
    han "Guess I'll have to put {i}this{/i} in my mouth then, 'cause neither will I."
    scene 18_0162 with dis1
    han "[kiss]"
    scene 18_0163 with dis1
    scene 18_0164 with dis1
    pause 0.5
    scene 18_0165 with dissolve
    han "[ss]Mmh."
    scene 18_0166 with dissolve
    image HannahR02_01 = Movie(play="images/e18/18_0167.webm")
    show HannahR02_01
    han "[ss]..Mmmhh.."
    scene 18_0168 with dissolve
    mc "[whi]You {b}sure{/b} you wanna do this?"
    han "[whi]Yeah. You?"
    scene 18_0169 with dissolve
    scene 18_0170 with dissolve
    scene 18_0171 with dissolve
    scene 18_0172 with dissolve
    scene 18_0173 with dissolve
    mc "[whi]Fuck yeah."
    scene 18_0174 with dissolve
    image HannahR02_02 = Movie(play="images/e18/18_0175.webm", loop=False, keep_last_frame=True)
    image HannahR02_03 = Movie(play="images/e18/18_0176.webm")
    show HannahR02_02
    pause 7.8
    show HannahR02_03
    han "[ss]..Mmmhh.."
    scene 18_0177 with dissolve
    image HannahR02_04 = Movie(play="images/e18/18_0178.webm")
    show HannahR02_04
    mc "[whi]Fuuck, Han..."
    han "[ss]Mmh."
    scene 18_0179 with dis1
    $ aPs(0, True)
    scene 18_0180 with dis1
    scene 18_0181 with dis1
    scene 18_0182 with dis1
    scene 18_0183 with dis1
    scene 18_0184 with dis1
    scene 18_0185 with dis1
    $ aPs(0, False, True)
    scene 18_0186 with dis1
    pause
    call Loop_Dissolve (5, False, False, "e18/18_0187.webp", "e18/18_0188.webp")
    scene 18_0189 with dis1
    pause
    scene 18_0190 with dissolve
    han "[ss]Mmmh."
    scene 18_0191 with dis1
    han "[whi]How fucked up is it that I love my pervy uncle sucking my tits?"
    scene 18_0192 with dis1
    mc "[whi]About as fucked up as me loving my pervy niece's shaved pussy."
    scene 18_0193 with dis1
    han "[whi]{i}Waxed{/i}."
    scene 18_0194 with dis1
    han "[whi]I started doing it after you got home."
    scene 18_0195 with dis1
    han "[whi]It hurt like hell..."
    scene 18_0196 with dis1
    han "[whi]But, I thought you were worth it."
    scene 18_0197 with dis1
    scene 18_0198 with dis1
    mc "[whi]I'm glad you thought so..."
    scene 18_0199 with dissolve
    mc "[whi]And I most definitely appreciate it."
    scene 18_0200 with dis1
    han "[whi]Prove it."
    scene 18_0201 with dissolve
    han "[whi]Eat it again for me, Unc."
    scene 18_0202 with dis1
    han "[ss]..Ohhhhh.."
    scene 18_0203 with dis1
    image HannahR02_05 = Movie(play="images/e18/18_0204.webm")
    show HannahR02_05
    han "[ss]..Fuck.."
    scene 18_0205 with dissolve
    call Moan (han)
    scene 18_0206 with dissolve
    image HannahR02_06 = Movie(play="images/e18/18_0207.webm")
    show HannahR02_06
    pause
    scene 18_0208 with dissolve
    han "[ss]...Ohhh..."
    scene 18_0209 with dissolve
    han "[ss]...Fuck... I love you doin' that.... Mmmhhhh...."
    scene 18_0210 with dissolve
    call Moan (han)
    scene 18_0211 with dis1
    han "[whi]Come up here, Unc."
    scene 18_0212 with dis1
    scene 18_0213 with dis1
    image HannahR02_07 = Movie(play="images/e18/18_0214.webm", loop=False, keep_last_frame=True)
    image HannahR02_08 = Movie(play="images/e18/18_0215.webm")
    show HannahR02_07
    han "[ss]Mmhh.{w=4}{nw}"
    pause 7.0
    han "[ss]..Mmhhhhh..{w=4}{nw}"
    pause 1.5
    han "[ss]..Ohh..{w=2}{nw}"
    pause 1.0
    han "[ss]..God, yes...{w=2}{nw}"
    pause 3.0
    han "[ss]..Fuuck..{w=2}{nw}"
    pause 3.15
    show HannahR02_08
    han "[ss]..Aahhhh.."
    scene 18_0216 with dissolve
    han "[ss]....Ohhhhh...."
    scene 18_0217 with dissolve
    image HannahR02_09 = Movie(play="images/e18/18_0218.webm")
    show HannahR02_09
    pause
    scene 18_0219 with dissolve
    image HannahR02_10 = Movie(play="images/e18/18_0220.webm")
    show HannahR02_10
    call Moan (han)
    scene 18_0221 with dissolve
    han "[ss]..Ohhh.."
    scene 18_0222 with dissolve
    pause
    scene 18_0223 with dissolve
    image HannahR02_11 = Movie(play="images/e18/18_0224.webm")
    show HannahR02_11
    call Moan (han)
    scene 18_0225 with dissolve
    mc "[whi]You okay?"
    han "[ss]Yeah."
    scene 18_0226 with dis1
    han "[ss]..Mmhhh.."
    scene 18_0227 with dissolve
    image HannahR02_12 = Movie(play="images/e18/18_0228.webm")
    show HannahR02_12
    han "[ss]..Mmhhh.."
    scene 18_0229 with dissolve
    image HannahR02_13 = Movie(play="images/e18/18_0230.webm")
    show HannahR02_13
    call Moan (han)
    scene 18_0231 with dissolve
    image HannahR02_14 = Movie(play="images/e18/18_0232.webm", loop=False, keep_last_frame=True)
    image HannahR02_15 = Movie(play="images/e18/18_0233.webm")
    show HannahR02_14
    han "[ss]..Mmhhh..{w=2}{nw}"
    han "[ss]..Ohhhh....You're gonna make me cum, Uncle [mc]...{w=3}{nw}"
    pause 0.5
    show HannahR02_15
    call Moan (han, 8)
    han "[ss]..Ohh....Unc......Yes......"
    han "[ss]...OHHH.....YES...."
    han "[ss]......OHHHHHH....."
    call CharCum ("e18/18_0234.webp", "e18/18_0235.webp", han, "...Ohhhhhhhhhh...")
    call CharCum ("e18/18_0235.webp", "e18/18_0236.webp", han, "..Ohhhhh..")
    scene 18_0237 with dissolve
    han "[ss]Holy shit, Unc..."
    scene 18_0238 with dissolve
    han "[ss]..Mmmmhhh.. That was intense...."
    scene 18_0239 with dis1
    scene 18_0240 with dis1
    scene 18_0241 with dissolve
    image HannahR02_16 = Movie(play="images/e18/18_0242.webm")
    show HannahR02_16
    han "[ss]..Mmhhh.."
    scene 18_0243 with dissolve
    image HannahR02_17 = Movie(play="images/e18/18_0244.webm")
    show HannahR02_17
    pause
    scene 18_0245 with dissolve
    call Moan (han)
    scene 18_0246 with dissolve
    image HannahR02_18 = Movie(play="images/e18/18_0247.webm")
    show HannahR02_18
    han "[ss]..Ohhhh.."
    pause
    call CmOpts (["Cum inside Hannah", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Hannah.incCm()
        call CharCum ("e18/18_0246.webp", "e18/18_0248.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e18/18_0248.webp", "e18/18_0249.webp", mc, "....Nnnhhhh....")
        scene 18_0250 with dissolve
        call EmotionSml (han, "Breathing heavily", "Wow.")
        scene 18_0251 with dissolve
        call EmotionSml (han, "Breathing heavily", "I loved doing that, Unc.")
        mc "[whi]Me too, Han."
        scene 18_0252 with dissolve
        han "[whi]I'm so glad you didn't nut inside me!\nI didn't get the chance to tell you I'm not on the pill!"
        mc "[whi]Uhhh.... what??"
        scene 18_0253 with dissolve
        han "Dude... Why you lookin' at me like that?"
        mc "Err.."
        scene 18_0254 with dissolve
        han "Holy fuck, Uncle [mc]! You didn't, did you??"
        mc "Shit, I'm sorry, Han! I thought... Fuck..."
        scene 18_0255 with dissolve
        han "[lol]\nAnd we have a winner! I got you!"
        scene 18_0256 with dissolve
        call laugh (mc, "You asshole!")
        han "[lol]"
    else:
        call CharCum ("e18/18_0246.webp", "e18/18_0257.webp", mc, "..Nnnnggghhhh..")
        call CharCum ("e18/18_0257.webp", "e18/18_0258.webp", mc, "....Nnnhhhh....")
        scene 18_0259 with dissolve
        call EmotionSml (han, "Breathing heavily", "Wow.")
        scene 18_0260 with dissolve
        call EmotionSml (han, "Breathing heavily", "I loved doing that, Unc.")
        mc "[whi]Me too, Han."
        scene 18_0261 with dissolve
        han "[whi]I'm annoyed that you didn't nut inside me though."
        mc "[whi]Uhhh.... why??"
        scene 18_0262 with dissolve
        han "How else are we gonna make a baby together, Unc?!"
        mc "What??"
        scene 18_0263 with dissolve
        han "Mom's gonna make a great grandma, don't you think?"
        mc "Jesus, Han! We can't!\nShe'd murder us both!! What the fuck?!"
        scene 18_0264 with dissolve
        han "[lol]\nAnd we have a winner! I got you!"
        scene 18_0265 with dissolve
        call laugh (mc, "You asshole!")
        han "[lol]"
    if _in_replay:
        scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
