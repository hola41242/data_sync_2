label OakHill_HorseRiding:
    call CenterText ("Some time later.", True)
    scene 07_0153 with fade
    mil "WOOOHOOO!!!"
    scene 07_0154 with dissolve
    mil "COME ON![lol]"
    scene 07_0155 with dissolve
    pause 0.5
    scene 07_0156 with dissolve
    pause
    scene 07_0157 with dissolve
    mct "Goddamn!"
    scene 07_0158 with dissolve
    mct "I don't remember riding being this uncomfortable!"
    scene 07_0159 with dissolve
    mct "Hope they're not too far ahead!"
    mc "Come on, horse! {b}YAH!{/b}"
    scene 07_0160 with dissolve
    pause 0.5
    scene 07_0161 with Fade(1, 2, 1)
    mct "Good... They've decided to slow down... Let the old guy catch up, heh."
    scene 07_0162 with dissolve
    mil "[whi][lol]"
    if persistent.Incest:
        mct "Sounds like they're up to no good, heh.\nWhat are they plotting?"
    else:
        mct "Sounds like they're having fun."
    scene 07_0163 with dissolve
    mil "Come on, Dad!\nThe lake's just up ahead."
    han "Thought we'd lost you back there, Unc![lol]"
    mc "Heh. Yeah, almost!"
    scene 07_0164 with Fade(1, 2, 1)
    han "Woo! We made it!"
    scene 07_0165 with dissolve
    mc "Whoa. You're right - it {b}is{/b} beautiful."
    scene 07_0166 with dissolve
    mil "It's my most favorite place in the world!\nSo peaceful."
    scene 07_0167 with dissolve
    mc "So, what do you usually do here?"
    han "Watch a movie on our phones."
    scene 07_0168 with dissolve
    mc "You're kidding me??\nYou come all the way out here... and you watch movies?!"
    scene 07_0169 with dissolve
    han "[lol]"
    scene 07_0170 with dissolve
    mil "We just like to hang out.\nChill, and talk about stuff."
    scene 07_0171 with dissolve
    han "But on a gorgeous day like today?"
    scene 07_0172 with dissolve
    han "We sunbathe!"
    scene 07_0173 with dissolve
    mil "You can too!"
    mc "Nah, I'm good thanks. Heh."
    scene 07_0174 with Fade(1, 2, 1)
    mil "Dad, what are you doing?"
    mc "Just checking on the horses."
    han "Sit with us!"
    scene 07_0175 with dissolve
    mil "Come on Dad, don't be shy!"
    scene 07_0176 with dissolve
    han "Take your top off, Unc!\nChill with us!"
    scene 07_0177 with dissolve
    mc "Damn!\nI'd forgotten how much of a pain in the ass you are![lol]"
    han "You always give in to me eventually! May as well just do it now."
    mc "Fine! Scoot over."
    scene 07_0178 with dissolve
    mil "No Dad! Come next to me!"
    han "Didn't you tell me that you wanted to be less possessive of him?"
    scene 07_0179 with dissolve
    mil "Fine... He can go in the middle."
    $ aaa = ""
    call Bruises ()
    if Plr.Has("Bruises"):
        $ aaa="a"
    scene 07_0180 with Fade(1, 2, 1)
    mil "See? Isn't this better?"
    show expression "07_0181" + aaa with dissolve
    mc "Yeah, Sweetie. Heh."
    if aaa=="a":
        scene 07_0182 with dissolve
        mil "OH MY GOD!"
        mil "What happened to you?"
        mc "Uhh... nothing.\nTripped up and fell down a few steps. I'm fine."
        scene 07_0183 with dissolve
        han "HOLY SHIT!"
        han "Fell down the stairs??"
        scene 07_0184 with dissolve
        han "You don't expect us to buy that, do you?"
        han "Who did you beat up?"
        mc "No one!"
        scene 07_0185 with dissolve
        han "Was there a damsel in distress that needed rescuing?"
        mc "Shut up!"
        han "[lol]"
    scene 07_0186 with Fade(1, 2, 1)
    pause
    show expression "07_0187" + aaa with dissolve
    mct "Wow. Didn't realize how much I needed this."
    show expression "07_0188" + aaa with dissolve
    mct "Feels like I haven't had the chance to kick back since I've been home."
    show expression "07_0189" + aaa with dissolve
    mil "Dad, you should tell Hannah about Cara."
    han "Who's Cara?"
    show expression "07_0190" + aaa with dissolve
    mil "You know, Cara, from Springhaven!\nYou've met her before."
    han "Oh, yeah. I think I remember her.\nWhat about her?"
    show expression "07_0191" + aaa with dissolve
    mc "She's, uhh... your cousin."
    scene 07_0192 with dissolve
    mil "She's my sister!"
    show expression "07_0193" + aaa with dissolve
    han "Uncle [mc]! You dirty dog![lol]"
    mc "[lol]"
    show expression "07_0194" + aaa with dissolve
    han "I think I've only met her once or twice, years ago!\nShe seemed nice. You should bring her with you next time!"
    mil "Yes Dad!"
    show expression "07_0195" + aaa with dissolve
    mil "I haven't seen her for ages either!\nIt'll be fun to get together again!"
    mc "Yeah, I'm sure we could arrange something."
    show expression "07_0196" + aaa with dissolve
    han "Jeez, it's so hot out here!"
    show expression "07_0197" + aaa with dissolve
    han "Who's up for getting wet?"
    mil "Me!"
    show expression "07_0198" + aaa with dissolve
    mil "You comin', Dad?"
    mc "Nah, I'm good here."
    if persistent.Incest and Millie.hasScore(2) and Hannah.hasScore(1):
        call OakHill_Swimming (aaa)
    else:
        scene 07_0199 with fade
        han "Wooo!"
        mil "[giggles]"
        scene black with Fade(2, 2, 1)
        call CenterText ("You spend a couple of hours relaxing.")
    scene 07_0230 with fade1
    mc "C'mon slowpokes! I'll race ya back!"
    mil "Oh my god, he's such a dork sometimes.[lol]"
    han "[lol]"
    scene black with Fade(2, 2, 0)
    jump OakHill_VisitLucy
return

label OakHill_Swimming(aaa):
    scene 07_0200 with fade
    call Emotion (han, "Whispering")
    mil "[whi]No, you![giggles]"
    scene 07_0201 with dissolve
    mct "Heh, always scheming together."
    scene 07_0202 with dissolve
    mil "Dad, you don't mind if we swim topless, do you?"
    han "[giggles]"
    mc "Uhh, no. If that's what you wanna do."
    scene 07_0203 with dissolve
    han "Great!\nHow about skinny-dipping?"
    $ tCh=True
    if not EzModeActive:
        menu:
            "[wk_y]No!":
                pass
            "Sure!":
                $ tCh=False
    if tCh:
        mc "No way!"
        $ Hannah.Score(1)
        $ Hannah.Add("Won")
        scene 07_0204 with dissolve
        han "[lol] YES!"
        scene 07_0205 with dissolve
        han "I finally got you!\nI called {b}your{/b} bluff!!"
    else:
        scene 07_0205 with dissolve
        han "Damn it, Uncle [mc]!!\nLet me beat you for once![lol]"
    scene 07_0206 with dis1
    scene 07_0207 with dis1
    mil "Sure you don't want to come in with us?"
    scene 07_0208 with dissolve
    mc "Maybe later."
    mil "Okay."
    if Millie.L>1:
        scene 07_0209 with dissolve
        mct "Damn, heh."
    scene 07_0210 with fade
    han "Wooo!"
    mil "[lol]"
    scene black with Fade(2, 4, 1)
    mil "[whi]Dad?"
    scene 07_0211 with fade
    pause 0.25
    scene black with fade
    scene 07_0212 with fade
    pause 0.25
    scene black with fade
    scene 07_0213 with fade
    pause 0.25
    scene 07_0214 with fade
    han "Are you okay?"
    show expression "07_0215" + aaa with dissolve
    mc "Yeah. Must've nodded off for a minute, heh."
    show expression "07_0216" + aaa with dissolve
    mil "We should start heading back.\nThe horses need to be returned."
    mc "Okay."
    show expression "07_0217" + aaa with dissolve
    han "Wait! We should get some pics before we leave!\nI'll get my phone!"
    mil "Oh Yeah! Good idea, Han!"
    show expression "07_0218" + aaa with dissolve
    mil "I don't have any recent pictures of you, Dad.\nI'd like some new ones!"
    mc "Of course, Sweetheart!"
    scene 07_0219 with fade1
    han "Got it!"
    show expression "07_0220" + aaa with dissolve
    mil "You don't need your t-shirt on, Dad!\nWe'll take them as we are!"
    mil "No one else is gonna see them! They're just for us!"
    mc "Heh. Okay."
    $ Millie.Add("NewPics")
    if aaa=="a":
        $ Millie.Add("PBS")
    show expression "07_0221" + aaa with fade1
    play sound "photo.mp3"
    pause 0.5
    han "Hug him, Milz!"
    show expression "07_0222" + aaa with fade
    play sound "photo.mp3"
    pause 0.5
    han "Got it.\nI'd like one, too!"
    scene 07_0223 with fade
    play sound "photo.mp3"
    pause 0.5
    mil "Okay, done."
    show expression "07_0224" + aaa with dissolve
    han "Want me to send you a copy, Unc?"
    mc "Yeah, that'd be great."
    han "Want me to censor it first?\nPut some {i}carefully placed{/i} emojis on top?"
    $ tCh=None
    if not EzModeActive:
        menu:
            "Yeah, that would be more appropriate":
                pass
            "[wk_y]Hell no!":
                $ tCh=True
    elif Hannah.Has("EZ"):
        $ tCh=True
        mc "Hell no!"
    else:
        mc "Yeah, that would be more appropriate."
    if tCh:
        $ Plr.Add("HPic")
        $ Hannah.Score(1)
        scene 07_0225 with dissolve
        han "You want it with me topless?"
        mc "Yeah, if you don't mind."
        scene 07_0226 with dissolve
        han "[whi]Okay."
        if Hannah.hasScore(2):
            show expression "07_0227" + aaa with dissolve
            han "I can send you some others as well, if you'd like?"
            mc "Yeah?"
            show expression "07_0228" + aaa with dissolve
            if Hannah.Has("Won"):
                han "[lol]"
                show expression "07_0229" + aaa with dissolve
                han "Wow! Got you again!\nTwice in one day? I'm on fire!"
            else:
                han "[lol] YES!"
                show expression "07_0229" + aaa with dissolve
                han "I finally got you!!"
            mc "[lol]"
    else:
        han "Okay."
        $ Plr.Add("HPicx")
    $ Hannah.Del("Won")
return

label OakHill_VisitLucy:
    scene 07_0231 with Fade(0, 1, 3)
    pause
    scene 07_0232 with fade1
    pause 0.5
    scene 07_0233 with dissolve
    han "I'm back, Mom."
    luc "Hi, Sweetheart.\nHow was your uncle?"
    han "You can ask him yourself; he's here.[lol]"
    scene 07_0234 with dissolve
    mc "Hey Sis."
    luc "Wow, I'm honored. Another visit!"
    scene 07_0235 with dissolve
    han "We'll be in my room."
    scene 07_0236 with dissolve
    luc "It was kind of you to take her out today. Thank you."
    mc "Millie wanted her to come along."
    luc "Yes, but you could've said no."
    scene 07_0237 with dissolve
    luc "It's okay to want to spend time with your niece, [mc].\nIt's not a weakness; stop being defensive."
    luc "I didn't expect you to visit Violet and Millie again so soon.\nGood for you."
    mc "Neither did I, to be honest."
    scene 07_0238 with dissolve
    mc "I had to come back to share some information with them that they should've known from the start."
    mc "I have another daughter."
    scene 07_0239 with dissolve
    luc "Cara? Yes, I know."
    luc "Violet already told me years ago."
    mc "What?"
    scene 07_0240 with dissolve
    luc "She was desperate, [mc]. She needed to talk to {i}someone{/i} about it!"
    luc "She was upset that you'd never discuss it with her.\nAll she wanted to do was help you."
    scene 07_0241 with dissolve
    luc "Don't you dare give her a hard time for telling me!"
    luc "She knew she could trust me to keep it to myself."
    scene 07_0242 with dissolve
    mc "I suppose I deserved that little jab."
    mc "I'm glad you were there for her, Sis.\nShould've been me, I know, but still - Thank you."
    scene 07_0243 with dissolve
    luc "Was that sarcasm or sincerity?\nI can never tell with you."
    scene 07_0242 with dissolve
    mc "I'm being serious, Lucy."
    mc "I was just as bad at being a husband as I was a brother."
    scene 07_0238 with dissolve
    mc "Violet deserved so much better than I gave her, and I'm tryin' to make things right."
    mc "I want to do the same with you.\nI'd like us to be a family, a {i}real{/i} family."
    scene 07_0244 with dissolve
    luc "Wow! Aren't you full of surprises?"
    luc "I can see why Vi thinks you've changed."
    scene 07_0245 with dissolve
    luc "I was always here, [mc]. You're the one who left, not me."
    scene 07_0246 with dissolve
    mc "Be honest, Sis - You didn't care that I left. Not then."
    mc "But as you said before - we're all we've got now.\nSo let's {b}be{/b} a family."
    scene 07_0247 with dissolve
    luc "I'd like that, [mc]. Really."
    luc "And yes, it's wrong of me to blame you.\nWe're both responsible for the state of our relationship."
    if Helen.isActive():
        call OakHill_TellLucyAboutDad (1)
    scene 07_0257 with dissolve
    mc "Okay. I'd better get Millie home."
    luc "It's good to see you again, [mc]."
    scene 07_0258 with dissolve
    luc "I hope we'll see more of you from now on."
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Offer her a hug":
                $ tCh=True
            "Leave":
                pass
    elif Lucy.Has("EZ"):
        $ tCh=True
    if tCh:
        $ Lucy.Score(1)
        scene 07_0260 with dissolve
        mc "Wanna hug your brother?"
        scene 07_0261 with dissolve
        luc "Sure."
        scene 07_0262 with dissolve
        luc "[whi]Mmhh, this is nice."
        scene 07_0263 with dissolve
        mc "Yeah, it is."
    else:
        scene 07_0259 with dissolve
        mc "You will. See you later, Sis."
        luc "Bye [mc]."
    scene black with Fade(3, 2, 0)
    jump OakHill_StayOver
return

label OakHill_TellLucyAboutDad(c):
    $ Lucy.Add("DadNews")
    $ sc = "" + ("07_0248" if c==1 else "12_0209")
    show expression "[sc]" with dissolve
    if c==2:
        mc "I need to tell you something..."
    mc "I, uhh... went to the address you sent me."
    mc "Sorry Lucy, but he died a long time ago."
    $ sc = "" + ("07_0249" if c==1 else "12_0210")
    show expression "[sc]" with dissolve
    luc "[whi]Oh."
    luc "At least we know now, I suppose."
    $ sc = "" + ("07_0250" if c==1 else "12_0193")
    show expression "[sc]" with dissolve
    luc "I appreciate you going, [mc]."
    luc "I know you didn't want to, so thanks."
    $ sc = "" + ("07_0251" if c==1 else "12_0189")
    show expression "[sc]" with dissolve
    mc "I met his wife."
    mc "She seemed nice enough.\nWelcomed me in."
    mc "We talked a little."
    mc "She invited me to visit again sometime."
    $ sc = "" + ("07_0252" if c==1 else "12_0191")
    show expression "[sc]" with dissolve
    luc "What did you say?"
    $ sc = "" + ("07_0242" if c==1 else "12_0194")
    show expression "[sc]" with dissolve
    mc "Told her I wasn't sure.\nI was there more for you than for me."
    mc "Said I'd discuss it with you."
    $ sc = "" + ("07_0253" if c==1 else "12_0211")
    show expression "[sc]" with dissolve
    luc "For me, it was all about meeting our father and giving him a chance."
    luc "But if he's dead already..."
    luc "I should've listened to you and just left it."
    $ sc = "" + ("07_0254" if c==1 else "12_0193")
    show expression "[sc]" with dissolve
    luc "What do you think?"
    $ sc = "" + ("07_0236" if c==1 else "12_0209")
    show expression "[sc]" with dissolve
    mc "Honestly? Not sure."
    mc "Probably best to just forget about the whole thing."
    $ sc = "" + ("07_0255" if c==1 else "12_0212")
    show expression "[sc]" with dissolve
    luc "Yeah, I'm leaning that way, too."
    luc "I'll leave it up to you, [mc]. I won't push either way."
    $ sc = "" + ("07_0256" if c==1 else "12_0213")
    show expression "[sc]" with dissolve
    luc "I'm happy to focus on the brother I already have."
return

label OakHill_StayOver:
    scene 07_0264 with Fade(0, 0, 3)
    mil "And then, we raced back to the stables!"
    scene 07_0265 with dissolve
    mil "Dad had a head start but {i}still{/i} lost![lol]"
    scene 07_0266 with dissolve
    mc "Only 'cause I got lost!\nI took a wrong turn!"
    scene 07_0267 with dissolve
    mil "[lol]"
    mc "It's true![lol]"
    scene 07_0268 with dissolve
    vi "Sounds like you all had lots of fun!"
    mil "It was the best!"
    scene 07_0269 with dissolve
    mil "I'm gonna get changed. I smell of horse."
    vi "Okay Sweetheart."
    scene 07_0270 with fade1
    vi "Well done, [mc].\nYou handled the situation well."
    vi "I'm proud of you."
    scene 07_0271 with dissolve
    mc "Thanks, Vi.\nIt was only because I knew you had my back."
    vi "Of course I do!"
    scene 07_0272 with dissolve
    vi "And in the spirit of {i}having your back{/i}..."
    vi "You should go shower.\nYou stink of horse, too![lol]"
    scene 07_0273 with dissolve
    mc "[lol] Fair enough."
    mc "Afterward, how about we all go out?"
    mc "Maybe get some food, and take Millie to the movies?"
    scene 07_0274 with dissolve
    vi "Great. I'd love to."
    scene 07_0275 with dissolve
    vi "It's been a good day.\nI'm glad you came, [mc]."
    mc "Me too."
    if persistent.Incest and Millie.L==3:
        vi "Let Millie know our plans while you're up there."
        mc "Okay."
        call MillieReplay03A
        scene 07_0324 with dissolve
        mc "Now get dressed. We're all going out to eat soon."
        mil "Okay."
    else:
        call CloseCharacterPath (Millie)
    scene 07_0325 with Fade(3, 2, 1)
    mct "Don't remember these old jeans being so tight, heh."
    call Bruises ()
    if Plr.Has("HPicx") or Plr.Has("HPic"):
        play sound "text.mp3"
        pause 1.0
        scene 07_0326 with dissolve
        pause 0.5
        scene 07_0327 with dissolve
        pause 0.5
        nvl clear
        show screen CellPhone("Hannah")
        msg_nvl "Hey Unc!"
        msg_nvl "Bet you thought I'd forgotten!"
        msg_nvl "Here you go {image=/thumbs/cell/emoji/kiss.png}"
        if Plr.Has("HPicx"):
            call SendPhoto ("han_01")
            mc_nvl "Thanks."
        else:
            call SendPhoto ("han_02")
            msg_nvl "Uncensored as promised! {image=/thumbs/cell/emoji/wink.png}"
            mc_nvl "Nice!"
        msg_nvl "Did you want the ones of Millie too?"
        menu(nvl=True):
            "[wk_y]Sure":
                mc_nvl "Sure{nw}"
                msg_nvl "Ok"
                if Plr.Has("HPic"):
                    msg_nvl "Censored... right? {image=/thumbs/cell/emoji/devil.png}"
                    menu(nvl=True):
                        "Of course!":
                            mc_nvl "Of course!{nw}"
                            call OakHill_SendPics (True)
                        "[wk_y]Nope!":
                            $ Hannah.Score(1)
                            $ Millie.Add("GotPicsX")
                            mc_nvl "Nope!{nw}"
                            msg_nvl "UNC!! You dog! {image=/thumbs/cell/emoji/flushed.png}"
                            msg_nvl "{image=/thumbs/cell/emoji/devil.png}{image=/thumbs/cell/emoji/devil.png}{image=/thumbs/cell/emoji/devil.png}"
                            call OakHill_SendPics (False)
                            msg_nvl "I know she wouldn't mind you having them. {image=/thumbs/cell/emoji/smile hearts.png}"
                            msg_nvl "{image=/thumbs/cell/emoji/wink.png}"
                else:
                    call OakHill_SendPics (True)
                mc_nvl "Thanks."
            "No thanks":
                mc_nvl "No thanks"
                msg_nvl "Ok"
        msg_nvl "See ya, Unc!{image=/thumbs/cell/emoji/kiss.png}"
        menu(nvl=True):
            "[wk_y]Have any more of you?":
                mc_nvl "Have any more of you?"
                msg_nvl "Me?"
                mc_nvl "You sent 2 of Millie, but only 1 of you!"
                msg_nvl "We only took 1 at the lake."
                msg_nvl "Ok, gimme a sec..."
                call SendPhoto ("han_03")
                msg_nvl "Happy now? {image=/thumbs/cell/emoji/crylaugh.png}"
                menu(nvl=True):
                    "Yup!":
                        msg_nvl "Yup!"
                    "[wk_y]Nope, I wanted a topless one! HAHAHA":
                        mc_nvl "Nope, I wanted a topless one! HAHAHA"
                        msg_nvl "OMG! Ur such a perv! {image=/thumbs/cell/emoji/monkey hiding.png}"
                        msg_nvl "And nobody types HAHA!"
                        msg_nvl "Use emojis or just type LOL!{image=/thumbs/cell/emoji/crylaugh.png}"
                        msg_nvl "You really want a topless one?{image=/thumbs/cell/emoji/devil.png}"
                        mc_nvl "Yup."
                        msg_nvl "K... wait a sec.\nI'll take one just for my fav pervy uncle! {image=/thumbs/cell/emoji/tongue.png}"
                        call SendPhoto ("han_04")
                        mc_nvl "That's better! HAHA"
                        mc_nvl "I mean... LOL"
                        msg_nvl "Damn Unc! You got me feeling naughty now!\nMaybe I'll send you another one later.{image=/thumbs/cell/emoji/wink.png}"
                        msg_nvl "...If you want me to? {image=/thumbs/cell/emoji/devil.png}{image=/thumbs/cell/emoji/devil.png}{image=/thumbs/cell/emoji/devil.png}"
                        menu(nvl=True):
                            "Hell yeah!":
                                $ Pix_Hannah=True
                                mc_nvl "Hell yeah!"
                                msg_nvl "{image=/thumbs/cell/emoji/kiss.png}"
                            "Nah, I'm good":
                                mc_nvl "Nah, I'm good"
                                msg_nvl "K"
            "Bye":
                mc_nvl "Bye"
        msg_nvl "Love u! Xx"
        call CloseCell ()
        $ Plr.Del("HPicx")
        $ Plr.Del("HPic")
        $ Plr.Del("HanPics")
    scene 07_0328 with dissolve
    mct "Damn... I'm starving!"
    scene black with Fade(2, 3, 0)
    play music "bgm01.mp3" volume 1.0
    scene 07_0329 with Fade(0, 0, 1)
    pause 0.5
    scene 07_0330 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0331 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0332 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0333 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0334 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0335 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0336 with Fade(2, 3, 3)
    pause 0.5
    scene 07_0337 with Fade(2, 3, 3)
    pause 0.5
    stop music fadeout 4.0
    scene 07_0338 with dis1
    scene 07_0339 with dis1
    scene 07_0340 with dis1
    vi "That was such a fun evening!"
    mil "Yeah!\nI'm going straight to bed, I'm exhausted!"
    scene 07_0341 with dissolve
    mil "Night Mom."
    vi "Goodnight Sweetie."
    scene 07_0342 with dissolve
    mil "Night Dad."
    mc "Night Sweetheart."
    scene 07_0343 with dissolve
    vi "Think I'll do the same.\nThis is a late night for me these days!"
    mc "Yeah, getting old kinda sucks! Heh."
    scene 07_0344 with dissolve
    vi "Goodnight [mc]."
    if Violet.isActive():
        scene 07_0345 with dissolve
        vi "[whi]Unless you'd like to join me?"
        $ tCh=True
        if not EzModeActive:
            menu:
                "[wk_y]What do you think?":
                    pass
                "Not tonight, I'm tired":
                    $ tCh=False
        if tCh:
            scene 07_0346 with dissolve
            vi "[giggles]"
            scene 07_0349 with dissolve
            vi "[whi]Come on."
            call VioletReplay02
        else:
            $ Violet.Add("Refused")
            scene 07_0347 with dissolve
            vi "Oh, okay."
            jump OakHill_WakeUpAlt
    else:
        jump OakHill_WakeUpAlt
    call Bruises (True)
    $ aaa=""
    if Plr.Has("Bruises"):
        $ aaa="a"
    scene 07_0461 with Fade(0, 2, 3)
    pause
    scene 07_0462 with dissolve
    call Emotion (mc, "Groan")
    scene 07_0463 with dissolve
    vi "Perfect timing!\nI've just finished cleaning your clothes."
    show expression "07_0464" + aaa with dissolve
    mc "Thanks. Appreciate it."
    show expression "07_0465" + aaa with dissolve
    vi "Sleep well?"
    mc "Yeah, like a baby."
    show expression "07_0466" + aaa with dissolve
    vi "[kiss]"
    show expression "07_0467" + aaa with dissolve
    vi "I'll make breakfast."
    show expression "07_0468" + aaa with dissolve
    if persistent.Incest and Millie.isSexual():
        mc "Violet, wait."
        show expression "07_0469" + aaa with dissolve
        mc "We need to talk about last night."
        show expression "07_0470" + aaa with dissolve
        vi "Okay."
        show expression "07_0471" + aaa with dissolve
        mc "It got outta hand... We let things go too far."
        vi "Why?"
        show expression "07_0472" + aaa with dissolve
        mc "{i}Why{/i}?? Are you kidding me?!"
        mc "Millie sucked my dick, Vi!"
        show expression "07_0473" + aaa with dissolve
        vi "She {i}wanted{/i} to!"
        mc "It doesn't matter!\nWe should've stopped her! It's wrong."
        scene 07_0474 with dissolve
        vi "I {i}know{/i} it's a little fucked up, Honey."
        vi "But you haven't seen her yet this morning!"
        scene 07_0475 with dissolve
        vi "She's so happy!"
        vi "She's literally walking on air!"
        scene 07_0476 with dissolve
        vi "How can {i}that{/i} be wrong?"
        show expression "07_0477" + aaa with dissolve
        mc "I..."
        vi "You only learned about all this recently.\nI've been dealing with it for months, [mc]."
        vi "I've had more time to come to terms with everything.\nTo accept it, understand it."
        scene 07_0478 with dissolve
        vi "When I saw you together in her room... I thought you had accepted it too."
        scene 07_0479 with dissolve
        vi "I'm sorry. I shouldn't have pushed it."
        vi "It wasn't planned. I didn't know she was spying on us.\nI... I got a little carried away, I guess."
        vi "I thought it was something you {i}both{/i} wanted."
        mc "And what about you, Vi? What do {i}you{/i} want?"
        scene 07_0480 with dissolve
        vi "I want you, [mc]."
        vi "I want my husband back."
        vi "I want our daughter to be happy.\nI want our family to be happy."
        show expression "07_0481" + aaa with dissolve
        mc "Come on, Violet. Be honest with me; it's more than that."
        scene 07_0482 with dissolve
        vi "What do you want me to tell you, [mc]?"
        vi "How excited I became when you told me Millie was watching us fuck?"
        scene 07_0483 with dissolve
        vi "How I orgasmed almost immediately when you told me you'd thought about licking her?"
        scene 07_0484 with dissolve
        vi "That I almost fainted with joy when she held your dick in her hand??"
        scene 07_0485 with dissolve
        vi "How I've never felt {b}so turned on{/b} as I watched her sucking her dad's dick??"
        scene 07_0486 with dissolve
        vi "Yes... it's all true."
        vi "I'm not proud of it."
        scene 07_0487 with dissolve
        vi "I thought it was just a fantasy."
        vi "That seeing it for real would be very different..."
        scene 07_0488 with dissolve
        vi "But when I saw you both in her bedroom... It was like... Fuuck!"
        scene 07_0489 with dissolve
        vi "I came straight in here to... masturbate."
        scene 07_0490 with dissolve
        vi "God, I barely touched myself... I climaxed {i}so{/i} damn fast!"
        scene 07_0491 with dissolve
        vi "But none of that was the reason I called her in here last night."
        vi "I wanted to show you - both of you - that I was okay with it."
        scene 07_0492 with dissolve
        vi "... That I could even be part of it - if you both wanted."
        vi "I wasn't trying to push... I was trying to be supportive."
        scene 07_0493 with dissolve
        vi "But if you don't want it, or you're uncomfortable with it, Honey, then yes - you should stop."
        show expression "07_0494" + aaa with dissolve
        vi "I'll talk to Millie. Let her down gently."
        show expression "07_0495" + aaa with dissolve
        mc "Wait..."
        show expression "07_0496" + aaa with dissolve
        mc "What if I... {i}didn't{/i}... want to stop?"
        scene 07_0497 with dissolve
        vi "Then don't."
        mc "Don't say anything to her... for now."
        scene 07_0498 with dissolve
        vi "Okay. If you're sure."
        scene 07_0499 with dissolve
        vi "I love you, Baby."
        show expression "07_0500" + aaa with dissolve
        vi "I'll go make that breakfast."
    else:
        mc "Thanks, Vi."
    if Plr.Has("Bruises"):
        scene 07_0501 with dissolve
        mc "How come you haven't asked about the bruises?\nYou must've noticed them."
        scene 07_0502 with dissolve
        vi "Sweetheart, I was married to you long enough to know not to ask questions I don't want the answer to."
        mc "Heh, fair enough."
    scene 07_0507 with fade2
    call Emotion (mc, "Yawn", "Jeez... Could've done with another couple of hours in bed!")
    scene 07_0508 with dissolve
    mil "Hey, Dad!"
    mc "Mornin' Sweetheart."
    scene 07_0509 with dissolve
    mil "Mom sent me to get you; she thought you'd probably fallen back to sleep."
    if persistent.Incest and Millie.isSexual():
        scene 07_0511 with dissolve
        mc "Almost did! Heh."
        mc "Are you, uhh... okay, Sweetie?"
        scene 07_0512 with dissolve
        mil "You're worried about last night, aren't you?"
        mc "... Yeah. I just-"
        scene 07_0513 with dissolve
        mil "When I woke up this morning, it took me a minute to believe it had {i}actually{/i} happened."
        mil "Then Mom woke up and asked me how I was."
        scene 07_0514 with dissolve
        mil "We came down here and talked.\nShe told me that she'd known for ages."
        mil "It was kinda awkward at first, but we had a really good chat."
        scene 07_0515 with dissolve
        mil "I've never felt closer to her - or you!"
        scene 07_0516 with dissolve
        mil "So yes, Dad - I'm great!"
        scene 07_0517 with dissolve
        mil "And I hope you are, too..."
        mil "Because I'd like to do {i}that{/i} again and again."
        mc "[whi]... Okay."
        scene 07_0518 with dissolve
        mil "[whi]I love you, Dad."
        mc "[whi]I love you too, Sweetheart."
        scene 07_0519 with dissolve
        mil "Mom said you thought about using your tongue yesterday..."
        mil "I was secretly wishing you would, too!"
        mil "So... Maybe next time?"
        scene 07_0520 with dissolve
        mc "You bet your sweet little ass!"
        mil "[giggles]"
        scene 07_0521 with dissolve
        mil "You haven't had a taste today."
        scene 07_0522 with dis1
        mil "[ss]Mmhhh."
        mc "[whi]Damn... Are you {i}always{/i} this wet??"
        scene 07_0523 with dissolve
        mil "[whi]Only when I'm around you, Daddy."
        scene 07_0524 with dissolve
        pause 0.5
        scene 07_0525 with dis1
        pause 0.5
        scene 07_0527 with dis1
        pause 0.5
        scene 07_0525 with dis1
        scene 07_0526 with dis1
        scene 07_0528 with dis1
        mil "[whi]Now lick my lips."
        scene 07_0529 with dissolve
        pause 0.5
        scene 07_0530 with dissolve
        scene 07_0531 with dis1
        scene 07_0532 with dis1
        scene 07_0533 with dis1
        scene 07_0534 with dis1
        scene 07_0535 with dis1
        pause 0.5
        scene 07_0536 with dissolve
        mil "[ss]..Mmhh.."
        scene 07_0537 with dissolve
        mil "[ss]....Mmmmhh...."
        scene 07_0538 with dissolve
        mil "[ss]..Mhh.."
        scene 07_0539 with dissolve
        vi "C'mon you two, breakfast is getting cold!"
        vi "You're never gonna beat the rush hour traffic at this rate![lol]"
        scene 07_0540 with dissolve
        mc "We're coming. Heh."
    else:
        scene 07_0510 with dissolve
        mc "Almost did! Heh."
        mil "Hope you're hungry, she's cooked you a massive breakfast!"
        mc "Starving!"
        scene 07_0540 with dissolve
        vi "Come on! You're never gonna beat the rush hour traffic at this rate![lol]"
        mc "We're coming. Heh."
    jump OakHill_Leave
return

label OakHill_WakeUpAlt:
    scene 07_0348 with dissolve
    mc "Night Vi."
    call Bruises (True)
    $ aaa=""
    if Plr.Has("Bruises"):
        $ aaa="a"
    scene 07_0503 with Fade(3, 5, 4)
    mc "[whi]..Zzzz.."
    scene 07_0504 with dissolve
    call Emotion (mc, "Groan")
    scene 07_0505 with dissolve
    vi "Perfect timing!\nI've just finished cleaning your clothes."
    mc "Thanks. Appreciate it."
    scene 07_0506 with dissolve
    vi "Breakfast will be ready in five."
    mc "Great."
    vi "Don't go back to sleep!\nYou'll need to leave soon if you want to beat the rush hour traffic!"
    jump OakHill_Leave
return

label OakHill_SendPics(Cen):
    if Cen:
        if Plr.Has("Bruises"):
            call SendPhoto ("mil_02")
            call SendPhoto ("mil_06")
        else:
            call SendPhoto ("mil_04")
            call SendPhoto ("mil_08")
    else:
        if Plr.Has("Bruises"):
            call SendPhoto ("mil_01")
            call SendPhoto ("mil_05")
        else:
            call SendPhoto ("mil_03")
            call SendPhoto ("mil_07")
return

label OakHill_Leave:
    if oakhill_ch==3:
        call UpdateMapInfos
    scene black with Fade(1,0.5, 1)
    $ oakhill_open=False
    $ oakhill_ch+=1
    call CheckShOpen
    jump ShowMap
return

label OakHill_Start4:
    scene 07_0001 with Fade(0,0,5)
    call AutoA
    play sound "knock.mp3" volume 0.5
    scene 12_0001 with dissolve
    $ apause(2)
    call AutoA (False)
    mct "Damn it."
    mct "Should've warned them I was coming..."
    play sound "knock.mp3" volume 1.0
    scene 12_0002 with dissolve
    pause 0.5
    scene 12_0001 with dissolve
    mct "Wanted to surprise them."
    mct "Looks like it's backfired!"
    scene 12_0003
    mct "... or maybe not."
    scene 12_0004 with dissolve
    mil "DAD!"
    mil "Mom didn't tell me you were visiting today!"
    mc "Hi, Sweetie!\nShe doesn't know; thought I'd surprise you both!"
    scene 12_0005 with dissolve
    mil "Mission accomplished!"
    scene 12_0006 with dissolve
    mc "She not home?"
    mil "No. She went to the market with Aunt Lucy."
    scene 12_0007 with dissolve
    mil "I just need to finish tidying my room.\nHelp yourself to coffee!"
    mc "Okay, Sweetheart. Take your time, I'm not going anywhere."
    call CenterText ("Fifteen minutes later.")
    scene 12_0008 with Fade(0,0,2)
    pause 0.5
    mil "[whi]DAD!"
    scene 12_0009 with dissolve
    mc "YEAH?"
    mil "[whi]CAN YOU COME HERE FOR A MINUTE? I NEED YOUR HELP."
    scene 12_0010 with dissolve
    mc "COMING..."
    scene 12_0011 with fade1
    pause 0.5
    scene 12_0012 with dissolve
    mc "What's up, Sweetheart?"
    scene 12_0013 with dissolve
    mil "Can you reach that box?"
    mc "Uh, yeah... sure."
    scene 12_0014 with dissolve
    mil "It's been up there for ages, and I have no idea what it is!"
    scene 12_0015 with dissolve
    mc "Hmm... You take after your mom!\nShe used to hold on to old junk, too."
    mil "Is that why she took so long to divorce you?"
    mc "WOW! [lol]"
    scene 12_0016 with dissolve
    mil "[lol]I'm sorry, Daddy! I'm only teasing!"
    scene 12_0017 with dissolve
    mil "I wonder what's inside? It's like Christmas!"
    mc "Am I crazy, or did you change your clothes?!"
    scene 12_0018 with dissolve
    mil "You're {i}not{/i} crazy.\nI don't wear my good clothes when I'm tidying!"
    mc "Ah, okay, heh."
    scene 12_0019 with dissolve
    mc "Okay, I'll leave you to it, Sweetie.\nI'll be downstairs if you need me."
    scene 12_0020 with dissolve
    mil "NO WAY!"
    mil "Dad, wait! LOOK!"
    scene 12_0021 with dissolve
    mil "We used to play this all the time!"
    mc "Damn! You still have that?!"
    scene 12_0022 with dissolve
    mil "Let's play!"
    mc "What? Now?!"
    mil "Yeah!"
    scene 12_0023 with dissolve
    mil "Pleeeease, Daddy!"
    mil "It'll be fun!"
    scene 12_0024 with dissolve
    mc "Beats sitting downstairs doin' nothing!\nBut {b}this{/b} time - when I win, no sulking!"
    mil "I'm in charge of the spinner! You always cheated!"
    mc "[lol]"
    scene 12_0025 with fade1
    call AutoA
    $ apause(1)
    scene 12_0026 with fade1
    $ apause(1)
    scene 12_0027 with fade1
    $ apause(1)
    call AutoA (False)
    if persistent.Incest and Millie.L>2:
        scene 12_0028 with dissolve
        mct "Glad I agreed to play! Heh."
        scene 12_0029 with dissolve
        mct "Yep! Definitely beats sitting on the sofa!"
    scene 12_0030 with fade1
    mc "Damn! This is getting painful!"
    scene 12_0031 with dissolve
    mc "Now I remember why I stopped playin' this game... You had an unfair advantage!"
    mil "How so?"
    mc "You used to do gymnastics! You're... stretchy!"
    scene 12_0032 with dissolve
    mil "{i}Used to{/i}? I {b}still{b} go!"
    mil "And... {i}stretchy{/i}?"
    scene 12_0033 with dissolve
    mil "[lol]"
    scene 12_0034 with fade1
    mc "Okay, now you're just showing off!"
    mil "[lol]"
    if persistent.Incest and Millie.L>2:
        scene 12_0035 with dissolve
        mct "Can't help it... Just a little peek...heh."
        scene 12_0036 with dissolve
        mct "Damn! No panties... She's playin' commando! Nice!"
        mct "Yeah... She knew what was in the box all along, heh."
    scene 12_0037 with fade1
    mil "Your left foot on red."
    mc "Jeez."
    scene 12_0038 with dissolve
    mc "... Okay... Got it."
    scene 12_0039 with fade1
    mc "C'mon! Not sure how much longer I can hold this!"
    mil "[lol] Right hand, green."
    mc "Are you kiddin' me?!"
    if not persistent.Incest or not Millie.L>2:
        scene 12_0040 with vpunch
        mc "Damn it!"
        mil "[lol] YES!"
        scene 12_0041 with dissolve
        mil "VICTORY!"
        mc "Yeah, yeah... You were cheating!"
        scene 12_0042 with dissolve
        mil "I learned from the best!"
        mc "[lol]"
        scene 12_0043 with dissolve
        mil "Want to try again?"
        mc "No! My body's aching!\nI need another coffee."
        scene 12_0044 with dissolve
        mil "Such a sore loser!"
        scene black with Fade(3, 2, 0)
        call CenterText ("A little while later...")
        scene 12_0131 with fade
        vi "[mc]! What a lovely surprise!\nI {i}thought{/i} that was your truck out front."
        mc "Hey, Vi."
        scene 12_0132 with dissolve
        vi "Everything okay?"
        mc "Yeah, fine.\nWas in the area and thought I'd drop by to say hello."
        scene 12_0133 with dissolve
        vi "Great!\nI'm gonna make coffee, want another?"
        mc "No, I'm good, thanks."
        scene 12_0134 with dissolve
        vi "Where's Millie?"
        mc "In her room."
        scene 12_0137 with fade1
    else:
        call MillieReplay05
        $ Millie.L = 5
        scene 12_0135 with fade1
        vi "Hi, [mc]! This is a lovely surprise.\nCan I get you some coffee?"
        mc "No, I'm good, thanks."
        scene 12_0136 with dissolve
        vi "Everything okay?"
        mc "Yeah, fine.\nWas in the area and thought I'd drop by to say hello."
        vi "Great!\nI bet Millie was thrilled to see you!"
        scene 12_0137 with dissolve
    vi "So, you wanna tell me why you're {i}really{/i} here?"
    mc "No reason.\nI just wanted to see you both!"
    scene 12_0138 with dissolve
    vi "And?"
    mc "Okay... I told Lucy I'd try to be a better brother, so I'm here, trying!"
    scene 12_0139 with dissolve
    vi "Baby, that's great!"
    vi "She told me you'd said that, but, honestly, I don't think she believes you."
    vi "I could tell she desperately wants to, though.\nShe'd love for you both to be closer."
    scene 12_0140 with dissolve
    mc "I'm willing to try, but she needs to make the effort, too."
    mc "Every time I've been around to see her, she's as cold as ice with me."
    scene 12_0141 with dissolve
    vi "What do you expect?"
    vi "She's waiting for you to vanish and leave us to pick up the pieces."
    vi "She doesn't want to be hurt, Honey."
    scene 12_0142 with dissolve
    mc "Wait... {i}You{/i} don't think that, do you?"
    mc "Vi, are you waiting for me to cut and run?"
    scene 12_0143 with dissolve
    vi "No."
    vi "I truly believe you're here for the long haul."
    vi "But when you first showed up?... Yeah, I kinda did."
    scene 12_0144 with dissolve
    vi "She's going to need time.\nTime to see how much you've grown as a man."
    vi "I don't think she even believes {b}me{/b} when I tell her how much you've changed."
    vi "She can only see the brother you used to be."
    scene 12_0145 with dissolve
    vi "So, show her, [mc]. Show her the brother you {b}can{/b} be."
    vi "When she sees you - the {i}real{/i} you - she'll be the sister you want {i}her{/i} to be."
    scene 12_0146 with dissolve
    mc "Wow!"
    mc "It's like I'm talking to an old, wise sage!"
    scene 12_0147 with dissolve
    vi "[lol]"
    scene 12_0148 with dissolve
    vi "Less of the {b}old{/b}, thank you very much!"
    mc "[lol]"
    mc "Sorry, I meant a beautiful, wise sage!"
    vi "Better!"
    scene 12_0149 with dissolve
    vi "So why's Millie upstairs in her room and not down here, clinging to her Dad, as usual?"
    scene 12_0150 with dissolve
    mc "She was tidying up her bedroom."
    mc "She found that game she used to love, err... the twisty, spinner thing?\nShe challenged me."
    vi "Oh, good."
    scene 12_0151 with dissolve
    vi "Did you still have to cheat?"
    mc "She's a gymnast! Of course I did!"
    vi "[lol]"
    if persistent.Incest and Violet.isActive() and Millie.isSexual():
        $ tCh=True
        if not EzModeActive:
            menu:
                "[wk_y]Tell Violet what happened":
                    pass
                "Say nothing":
                    $ tCh=False
        if tCh:
            $ Violet.Add("Told")
            scene 12_0152 with dissolve
            mc "She, uhh... ended up kinda on top of me."
            mc "... She wasn't wearing underwear."
            scene 12_0153 with dissolve
            call Emotion (vi, "Gasp")
            vi "Did you have sex with her??"
            scene 12_0154 with dissolve
            mc "No!"
            scene 12_0155 with dissolve
            mc "I don't get it, Vi."
            mc "You're the one who encouraged me to be close with her, but now you're angry about it?"
            scene 12_0156 with dissolve
            vi "Sweetheart, I'm not angry!\nYou caught me a little off-guard, that's all!"
            vi "I haven't had the chance to discuss it with her yet.\nI need to know it's something she really wants to do, and that she's ready."
            scene 12_0157 with dissolve
            vi "I'm pretty sure she's still a virgin. She has no experience, and I don't want her rushing into it."
            if persistent.GroupSex:
                vi "... and..."
                call Emotion (vi, "Sigh", "", True)
                scene 12_0158 with dissolve
                mc "And {i}what{/i}?"
                vi "And..."
                vi "... I know it's selfish of me, but..."
                scene 12_0159 with dissolve
                vi "I was hoping to be there.\nTo watch you fuck our daughter for the first time."
                scene 12_0160 with dis1
                vi "I'd hold her hand and watch her Daddy's throbbing dick squeeze inside her little pussy."
                vi "Her hand would grip mine... tighter and tighter, as you gently push your way in."
                scene 12_0161 with dis1
                vi "She'd moan in delight as you gently thrust fully inside her."
                scene 12_0162 with dis1
                vi "She's so happy... At last, Daddy's fucking her, as {b}only{/b} her Daddy could."
                scene 12_0163 with dis1
                vi "She never wants it to end... But she's {b}so{/b} turned on, she can't hold back... She orgasms so damn hard, so damn fast..."
                scene 12_0164 with dis1
                vi "You, too... Fucking your little girl feels so good, and you explode uncontrollably inside her."
                scene 12_0165 with dis1
                vi "Her daddy's cum slowly drips out of her hot, swollen pussy."
                scene 12_0166 with dissolve
                vi "Crap... Sorry."
                scene 12_0168 with dissolve
                mc "Fuckin' hell, Violet!"
                vi "I got carried away."
                scene 12_0167 with dissolve
                vi "I shouldn't have said any of that. Ignore me."
                scene 12_0169 with dissolve
                mc "Well, you're right about one thing: she {b}is{/b} a virgin."
                mc "And, she asked if I would take it when she's ready."
            else:
                scene 12_0169 with dissolve
                mc "She is."
                vi "She told you?"
                mc "Yeah. And, she asked if I would take it when she's ready."
            scene 12_0170 with dissolve
            vi "Ohhh, that's so sweet!"
            scene 12_0171 with dissolve
            vi "I hope you agreed!"
            mc "Yeah."
            scene 12_0172 with dissolve
            vi "That's a relief!\nShe would've been devastated had you refused!"
            scene 12_0173 with dissolve
            vi "Thank you, [mc].\nI appreciate you telling me."
            vi "Now, go visit Lucy."
            scene 12_0174 with dissolve
            vi "I'd better have that conversation with our horny little minx before it's too late."
            scene 12_0175 with dissolve
            mc "You ain't gonna tell her what we've talked about, are you?"
            vi "No! Of course not!"
            scene 12_0176 with dissolve
            mc "Okay. I'll see you later."
            vi "Good luck with the Ice Queen!"
            jump OakHill_04_VisitLucy
    scene 12_0175 with dissolve
    vi "So, why are you still sitting here with me?"
    mc "Huh?"
    vi "Stop stalling and go visit your sister!"
    scene 12_0176 with dissolve
    mc "Okay, okay. I'm goin'."
    vi "Good luck with the Ice Queen!\nSee you later!"
    jump OakHill_04_VisitLucy
return

label OakHill_04_VisitLucy:
    scene 12_0177 with Fade(3, 2, 3)
    mct "Probably should've called first."
    scene 12_0178 with dissolve
    play sound "knock.mp3"
    mct "It always annoyed her when I'd show up unannounced."
    scene 12_0179 with dissolve
    luc "You're back... Again."
    mc "Great to see you, too, Sis."
    scene 12_0180 with dissolve
    luc "I wasn't expecting company.\nCome in."
    scene 12_0181 with fade
    luc "Let me guess.\nYou're in trouble with Violet and had to come all this way to apologize."
    mc "What? No!"
    scene 12_0182 with dissolve
    luc "Oh, please tell me you didn't let Millie down again?"
    mc "What are you talking about? No!"
    scene 12_0183 with dissolve
    luc "What other reason is there for being back here so soon after your last visit?"
    mc "Do I need a reason?\nI wanted to come visit my sister!"
    scene 12_0184 with dissolve
    luc "Why?\n[mc], I've seen more of you in the last two weeks than I have in the last ten years."
    mc "And that's a bad thing??"
    luc "It's not like you, so... probably, yes."
    scene 12_0185 with dissolve
    call Emotion (mc, "Sigh", "You know what?")
    scene 12_0186 with dissolve
    mc "This was a bad idea. Just forget it."
    luc "[mc]!?"
    scene 12_0187 with dissolve
    luc "Okay! Wait! ...I'm sorry."
    scene 12_0188 with dissolve
    luc "Stop being so dramatic and sit."
    luc "Please."
    scene 12_0189 with fade
    luc "Violet usually tells me when you're visiting."
    luc "You're training her well."
    mc "Damn it, Lucy. Come on.\nVi didn't know I was coming."
    scene 12_0190 with dissolve
    mc "It was a spur-of-the-moment decision, and I wanted to surprise everyone."
    mc "Starting to wish I hadn't bothered!"
    luc "Don't say that."
    scene 12_0191 with dissolve
    luc "Jeez..."
    luc "I apologize."
    luc "I've been in a bad mood all day, and I shouldn't take it out on you."
    scene 12_0192 with dissolve
    mc "Take {i}what{/i} out on me? What's wrong?"
    luc "Nothing in particular.\nI'm just having one of those {i}down{/i} days."
    luc "Everybody gets them."
    scene 12_0193 with dissolve
    luc "I just..."
    luc "Sometimes, I feel {i}so{/i} lonely.\nThat makes me sad, and I get a little depressed."
    luc "It's hard to snap myself out of it."
    scene 12_0194 with dissolve
    mc "Lonely? You're single?"
    luc "Yes. Ever since my divorce."
    scene 12_0195 with dissolve
    mc "Wow."
    luc "Why does that surprise you?"
    scene 12_0196 with dissolve
    mc "You're a beautiful woman!\nFigured there'd be a queue of guys wanting to take you out."
    scene 12_0197 with dissolve
    luc "You find this amusing, don't you?"
    mc "Not at all!"
    scene 12_0198 with dissolve
    luc "Even if there were a man, I wouldn't want to."
    luc "I have no interest in meeting strangers. Trying to get to know them."
    scene 12_0199 with dissolve
    luc "That awkward fumbling around, the first time you sleep with someone you don't even know very well!"
    luc "It's humiliating! I'm too old for that shit."
    scene 12_0200 with dissolve
    mc "Ohhh, okay. Now I get it.\nIt's not companionship you miss, it's sex!"
    scene 12_0201 with dissolve
    mc "You're horny, and your lady-toy just doesn't cut it for you anymore!"
    scene 12_0202 with dissolve
    luc "My {i}Lady-toy{/i}?"
    scene 12_0203 with dissolve
    luc "[lol]"
    scene 12_0204 with dissolve
    luc "You're a jackass!"
    scene 12_0205 with dissolve
    luc "And no! It's not {i}just{/i} sex.\nIt's intimacy, the touch of a loving man."
    luc "It's..."
    scene 12_0206 with dissolve
    luc "Wait a minute... {b}What{/b} am I doing?!"
    scene 12_0207 with dissolve
    luc "I'm not having a conversation about my non-existent sex life with my {b}brother{/b}!"
    mc "Aww, why not?? [lol]"
    scene 12_0192 with dissolve
    mc "Feeling lonely, alone...."
    mc "Is {i}that{/i} the reason you asked me to go see about our father?"
    luc "No!"
    scene 12_0208 with dissolve
    call Emotion (luc, "Sigh", "I don't know.")
    luc "...Maybe it was?"
    if Helen.isActive() and not Lucy.Has("DadNews"):
        call OakHill_TellLucyAboutDad (2)
        scene 12_0214 with dissolve
        luc "You came to see me, and all I can do is complain."
    else:
        luc "It doesn't matter.\nI need to stop wallowing in self-pity."
        scene 12_0214 with dissolve
        luc "My brother's here to see me, and I'm moaning."
    scene 12_0215 with dissolve
    luc "It {i}is{/i} good to see you, [mc], and I'm pleased you thought to visit."
    scene 12_0216 with dissolve
    luc "I was about to make dinner. Would you like to join us?"
    mc "I'd love to, Sis."
    mc "I should give Violet a call, let her know I'll be here a while."
    scene 12_0217 with dissolve
    luc "I can tell her. I need to call her, anyway.\nI owe her an apology for being a little snappy while we were out earlier."
    luc "Why don't you go say hello to Hannah? She's in her room."
    mc "Yeah, okay."
    call OakHill_04_VisitHannah
    scene 12_0316 with Fade(1, 3, 2)
    mc "Looks great, Sis."
    luc "Thank you."
    han "[whi]Suck up.[giggles]"
    scene 12_0317 with dissolve
    luc "It wouldn't kill {i}you{/i} to compliment your mother once in a while."
    luc "And you couldn't dress more appropriately since we have a guest?"
    scene 12_0318 with dissolve
    if persistent.Incest:
        han "Uncle [mc] likes my top."
        han "Gives him easy access to my boobies."
        scene 12_0319 with dissolve
        luc "HANNAH!"
        luc "Don't be so vulgar!"
    else:
        han "Jeez, Mom! It's only Uncle [mc]."
        scene 12_0319 with dissolve
        luc "Watch your tone, young lady."
    scene 12_0320 with dissolve
    mc "So, Lucy... You still work at the hotel?"
    scene 12_0321 with dissolve
    luc "Yes.\nBut I'm no longer {i}at{/i} the hotel.\nI was promoted. I'm now the area manager."
    luc "I have an office at their main headquarters."
    mc "Oh, nice! Congratulations!"
    luc "Thank you."
    scene 12_0322 with dissolve
    luc "How are you and Violet getting along?"
    mc "Great... I think.\nAlthough you probably know better than I do."
    luc "She's very grateful to have you back in her life.\nI haven't seen her this happy in a long time."
    luc "Don't screw it up, [mc]. She deserves better."
    scene 12_0323 with dissolve
    mc "I'm tryin', Sis.\nI want to make it work, I really do."
    mc "And not {i}just{/i} with her. I want {b}us{/b} to be close, too."
    scene 12_0324 with dissolve
    luc "I admit, I was apprehensive to begin with."
    luc "But you sound sincere, and I'm inclined to take you at your word."
    scene 12_0325 with dissolve
    mc "Good! Because it's the truth, Sis."
    mc "I don't want to go back to how it used to be."
    mc "I can't live like that anymore."
    scene 12_0326 with dissolve
    mc "Besides..."
    if persistent.Incest:
        mc "What would I do without easy access to Hannah's boobies?!"
    else:
        mc "I missed Hannah's awesome tone!"
    scene 12_0327 with dissolve
    luc "[mc]!"
    scene 12_0328 with dissolve
    luc "There's no denying you two are family!"
    scene 12_0329 with dissolve
    luc " You're like a double act! Always have been!"
    scene 12_0330 with dissolve
    han "[lol]"
    scene 12_0331 with Fade(2, 3, 2)
    mc "Thanks, Lucy. That was great!"
    luc "Would you like another piece of cake?"
    mc "I'm stuffed! Couldn't eat another bite."
    han "Yeah, thanks, Mom. It was nice."
    scene 12_0332 with dissolve
    luc "Thank you, and you're welcome, Sweetheart."
    scene 12_0333 with dissolve
    luc "Can you stay a little while longer?"
    luc "I thought maybe we could all watch a movie."
    mc "Sure. Why not?"
    scene 12_0334 with dissolve
    han "Yay!"
    scene 12_0335 with Fade(2, 3, 2)
    mct "So far, so good.\nHaven't spent so much time together since we were kids."
    mct "It's been nice."
    if Chloe.Has("SndPic"):
        play sound "text.mp3"
        pause 1.0
        scene 12_0336 with dissolve
        pause 0.5
        call Msg_Chloe03
        $ Chloe.Del("SndPic")
        scene 12_0337 with dissolve
        pause 0.5
    scene 12_0338 with dissolve
    luc "Hannah's just putting on some pajamas."
    scene 12_0339 with dissolve
    mc "I'm the last guy who should be giving parenting advice, but you should try go easy on her, Sis."
    luc "What do you mean?"
    mc "She was upset earlier.\nFeels like you're always taking your bad moods out on her."
    luc "Ohh, she's just exaggerating!"
    scene 12_0340 with dissolve
    mc "Okay. If that's all it is, fair enough."
    mc "But I know how tough being a single parent can be.\nI remember how Mom struggled with us."
    scene 12_0341 with dissolve
    mc "I just don't want Hannah ending up feeling the same way we did - Jeez, we couldn't wait to leave home!"
    scene 12_0342 with dissolve
    luc "I'm not {i}that{/i} bad!"
    scene 12_0343 with dissolve
    mc "No one's saying you're a bad mom, Sis!\nI've always thought you were great at it!"
    mc "All I'm tryin' to say is, it's easy to take your frustrations out on the ones you love, believe me - I know better than most!"
    mc "It cost me years of pain and misery. I'm lucky to have a second chance."
    scene 12_0344 with dissolve
    call Emotion (luc, "Sigh")
    luc "[whi]She's right..."
    luc "I suppose I {i}have{/i} been laying into her for stupid shit."
    luc "I don't mean to. I just get so annoyed sometimes."
    mc "Come here."
    scene 12_0345 with dissolve
    mc "Next time you feel like you're about to snap, just pick up the phone and call your brother."
    mc "He's used to taking shit from you. You can scream and shout at him all you like, and he'll still love you."
    scene 12_0346 with dissolve
    luc "Like the old days, huh?"
    mc "Yeah!... But maybe don't punch me in the nose again."
    scene 12_0347 with dissolve
    luc "You deserved it!"
    mc "No! That kid was an asshole, and you were {i}way{/i} too young to have a boyfriend!"
    scene 12_0348 with dissolve
    luc "[lol]"
    scene 12_0349 with dissolve
    han "What's so funny?"
    luc "Nothing, Sweetheart. I'm just happy your Uncle [mc] is here."
    scene 12_0350 with dissolve
    han "Yeah, me too!"
    scene 12_0351 with dissolve
    han "When you gonna move back in with Aunt Vi and Millie?\nIt'll be fun to have you around more!"
    mc "You're gonna be seeing a lot more of me regardless of where I live, Han. You can count on that!"
    scene 12_0352 with dissolve
    han "I'd better!\nI love you just as much as Millie, and don't you forget it!"
    scene 12_0353 with fade1
    pause 2.0
    if persistent.Incest and Hannah.hasScore(5):
        scene 12_0354 with Fade(2, 1, 2)
        call AutoA
        $ apause(1)
        scene 12_0355 with dis1
        $ apause(1)
        call AutoA (False)
        scene 12_0356 with dissolve
        pause
        scene 12_0357 with dissolve
        pause
        scene 12_0356 with dissolve
        pause 1.0
        scene 12_0358 with dissolve
        pause
        scene 12_0359 with dis1
        pause
    scene 12_0360 with Fade(2, 4, 2)
    han "Bye, Unc."
    mc "I'll see you soon, Sweetheart."
    scene 12_0361 with dissolve
    han "Night, Mom."
    luc "Goodnight, Honey."
    scene 12_0362 with dissolve
    luc "Thank you for a lovely evening, [mc]."
    mc "My pleasure, Sis.\nI enjoyed it, too."
    scene 12_0363 with dissolve
    luc "Let's do it again, soon."
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e12/12_0363.webp", 818, 611, True, "OakHill_AF08")
            mc "Absolutely."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 12_0363
                hide screen imgMap 
        else:
            mc "Absolutely."
            if not EzModeActive:
                menu:
                    "[wk_y]Slide your hand down":
                        call OakHill_AF08
                    "Don't":
                        pass
            elif Lucy.Has("EZ"):
                call OakHill_AF08
    scene 12_0371 with dissolve
    luc "Bye."
    mc "See ya."
    jump OakHill_04_BackToViolets
return

label OakHill_04_VisitHannah:
    scene 12_0218 with Fade(1, 2, 1)
    call AutoA
    play sound "knock.mp3"
    scene 12_0219 with dissolve
    $ apause()
    scene 12_0220 with dissolve
    $ apause()
    call AutoA (False)
    call Emotion (han, "Sigh", "Yeah?", True)
    scene 12_0221 with dissolve
    mc "Hey.\nCan I come in?"
    scene 12_0222 with dissolve
    han "Depends."
    han "Is my mother hiding behind you?"
    mc "Uhh, no."
    han "Then, sure."
    scene 12_0223 with dissolve
    mc "What's up? She givin' you a hard time?"
    han "Doesn't she always?"
    scene 12_0224 with dissolve
    han "You come up here to get away from her, too?"
    mc "No, I came to see my favorite niece!"
    scene 12_0225 with dissolve
    han "Not much of a compliment since I'm your only one!"
    scene 12_0226 with dissolve
    mc "Sweetie, I could have a {b}thousand{/b}, and you'd {i}still{/i} be my favorite!"
    han "If you say so."
    scene 12_0227 with dissolve
    mc "You're not surprised to see me?"
    han "No, Millie told me you were here."
    mc "Ah, right."
    scene 12_0228 with dissolve
    mc "C'mon, cheer up! Uncle [mc]'s here!"
    scene 12_0229 with dissolve
    han "Yeah, for the usual ten minutes!\nJust long enough for Mom to piss you off and make you want to leave again."
    mc "Hah, see - you're wrong! I'm staying for dinner."
    if persistent.Incest and Millie.isSexual():
        scene 12_0230 with dissolve
        han "Haven't you already eaten?"
        mc "Not yet, and I'm starving!"
    scene 12_0231 with dissolve
    han "She's been in a foul mood all day. You {i}sure{/i} you wanna stay?"
    scene 12_0232 with dissolve
    mc "You don't seem much happier, Han!\nIs everything okay?"
    han "I'm just sick of her shit!\nShe takes everything out on me!"
    scene 12_0233 with dissolve
    han "She had a go at me earlier because {i}I left a dirty cup on the coffee table{/i}!"
    han "I was still drinking from it!"
    scene 12_0234 with dissolve
    mc "Ahh, so you had a fight, huh?"
    han "Not really. I washed the cup and came up here to escape."
    scene 12_0235 with dissolve
    mc "Well, you're in luck! The best uncle in the world's in town!"
    mc "Come down and eat with us, and I promise, I'll protect you from the wicked witch."
    scene 12_0236 with dissolve
    mc "And if she starts shooting lightning bolts from her fingers, I'll dive in front of you heroically and sacrifice myself!"
    scene 12_0237 with dissolve
    han "[lol]"
    $ i =True
    if not persistent.Incest:
        $ i =False
    else:
        scene 12_0239 with dissolve
        scene 12_0240 with dissolve
        scene 12_0241 with dis1
        han "You're an idiot."
        mc "So I've been told!"
        if Hannah.hasScore(1):
            if not EzModeActive:
                menu:
                    "[wk_y]Try to call her bluff":
                        pass
                    "Let go":
                        $ i =False
            elif not Hannah.Has("EZ"):
                $ i =False
        else:
            $ i =False
    if not i:
        scene 12_0238 with dissolve
        han "Fine. I'll come down to eat!"
        han "But I'm doing it to spend time with {b}you{/b}, not her."
        mc "Fair enough."
        scene 12_0315 with dissolve
        mc "Come on."
        han "I'm comin'."
        return
    $ Hannah.Score(2)
    scene 12_0242 with dissolve
    mc "Wow, what cute little toes you have!"
    han "Ehh?"
    scene 12_0243 with dissolve
    mc "[kiss]"
    scene 12_0244 with dissolve
    han "[lol] What the hell was that?!"
    scene 12_0245 with dissolve
    han "It'll take more than a toe kiss to make everything better."
    mc "I'm not done yet."
    scene 12_0246 with dissolve
    han "Ohh, my bad. What else you got?"
    if persistent.FootPlay:
        $ Hannah.Add("Toe")
        scene 12_0247 with dissolve
        pause 0.5
        scene 12_0248 with dis1
        mc "[whi]Mhh."
        scene 12_0249 with dissolve
        han "Ewww! Unc! That's gross!"
        scene 12_0254 with dissolve
        han "Feels quite nice, though!"
        scene 12_0251 with dissolve
        call AutoA
        $ apause()
        scene 12_0252 with dis1
        $ apause()
        scene 12_0253 with dis1
        $ apause()
        call AutoA (False)
    else:
        scene 12_0253 with dissolve
        pause
    scene 12_0250 with dissolve
    han "If you're gonna use your tongue, I can think of better places."
    scene 12_0255 with dissolve
    call AutoA
    mc "[kiss]"
    scene 12_0256 with dis1
    $ apause()
    scene 12_0257 with dis1
    mc "[kiss]"
    scene 12_0258 with dis1
    mc "[kiss]"
    call AutoA (False)
    scene 12_0259 with dissolve
    han "That's it, you're getting warmer!"
    scene 12_0260 with dissolve
    mc "[kiss]"
    scene 12_0261 with dissolve
    han "I know what you're doing!"
    scene 12_0262 with dissolve
    mc "[kiss]"
    scene 12_0263 with dis1
    mc "[kiss]"
    scene 12_0264 with dissolve
    mc "Anything to say?"
    scene 12_0265 with dissolve
    han "You want me to say it, but I'm not gonna!"
    scene 12_0266 with dissolve
    han "You're bluffing!\nYou ain't winning this time!"
    scene 12_0267 with dissolve
    mc "You {i}sure{/i} about that?"
    han "One hundred percent!"
    scene 12_0268 with dis1
    pause 0.5
    scene 12_0269 with dis1
    mc "Okay, guess we'll find out!"
    scene 12_0270 with dis1
    call AutoA
    mc "[kiss]"
    scene 12_0271 with dis1
    $ apause()
    scene 12_0272 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0273 with dis1
    han "Whoa!"
    mc "Say the words, Han!"
    scene 12_0274 with dissolve
    han "I'm sayin' {i}nothing{/i}! {b}You{/b} say them!"
    scene 12_0275 with dissolve
    mc "{i}Okay then{/i}..."
    scene 12_0276 with dis1
    call Emotion (han, "GASP")
    scene 12_0277 with dissolve
    han "[lol]"
    scene 12_0278 with dissolve
    han "You're {i}so{/i} funny, Unc!"
    scene 12_0279 with dis1
    han "Still not sayin' it, though."
    scene 12_0280 with dissolve
    call AutoA
    $ apause(1)
    scene 12_0281 with dissolve
    $ apause(1)
    scene 12_0282 with dis1
    mc "[kiss]"
    $ apause()
    scene 12_0283 with dis1
    $ apause(1)
    scene 12_0284 with dis1
    mc "[kiss]"
    $ apause()
    scene 12_0285 with dis1
    mc "[kiss]"
    $ apause()
    scene 12_0286 with dis1
    $ apause(1)
    scene 12_0287 with dis1
    $ apause()
    scene 12_0288 with dis1
    $ apause()
    scene 12_0289 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0290 with dis1
    han "AAAHHHH! {b}OKAY{/b}!"
    scene 12_0291 with dissolve
    han "[lol] DAMN IT! YOU WIN!"
    scene 12_0292 with fade
    han "I {i}really{/i} didn't think you'd go that far!"
    mc "You kiddin' me?\nI wouldn't have stopped 'till you were pregnant!"
    han "[lol]"
    scene 12_0293 with dissolve
    mc "Anyway, you started it!"
    mc "You could've stopped me {i}waaay{/i} before you did!"
    scene 12_0294 with dissolve
    han "I know."
    scene 12_0295 with dissolve
    han "But I wanted to see how far {b}I'd{/b} let you go."
    scene 12_0296 with dissolve
    mc "Oh, right!"
    mc "And?"
    scene 12_0297 with dissolve
    han "You got further than I thought!"
    if Millie.isSexual():
        $ Hannah.Add("Knows")
        scene 12_0299 with dissolve
        han "But, apparently, not as far as you did with Millie!"
        scene 12_0300 with dissolve
        mc "[whi]Uhh... What?"
        han "What was {i}that{/i} like, Unc? Eating out your {b}daughter{/b}?"
        mc "[whi]Hannah..."
        scene 12_0301 with dissolve
        han "Relax! Your secret's safe with me."
        han "I'm not gonna tell anyone."
        scene 12_0302 with dissolve
        mc "So... Millie, uhh... told you?"
        han "That she sixty-nine'ed her dad? Yeah. She couldn't wait to tell me!"
        mc "It just kinda... It wasn't planned..."
        scene 12_0303 with dissolve
        han "Uncle [mc]! Chill!"
        han "I think it's awesome!"
        scene 12_0304 with dissolve
        mc "You... do??"
        han "She's infatuated with you!\nShe has been for as long as I can remember."
        han "Waaay before you even came back!"
        scene 12_0305 with dissolve
        han "Do you know how many times we've had a conversation about your dick?"
        han "I don't! I've lost count!"
        han "We never thought for one minute it'd actually happen, though!"
        scene 12_0306 with dissolve
        han "You gonna have sex with her?"
        mc "Err..."
        scene 12_0307 with dissolve
        han "Unc! You have to!"
        han "You can't nut in her mouth, and then say no to sex!"
        scene 12_0308 with dissolve
        han "She'd be crushed!"
        scene 12_0309 with dissolve
        han "Give her what she wants, Dude!"
        han "Isn't it your job to make your daughter happy?"
        scene 12_0310 with dissolve
        mc "It's not that simple, though, is it, Han?"
        han "Why?"
        han "If you both want to do it, who gives a fuck?\nIt's nobody else's business!"
        scene 12_0311 with dissolve
        han "You do have {i}one{/i} big problem, though."
        mc "I do?"
        scene 12_0312 with dissolve
        han "Yep."
        han "You can never beat me at bluff again, or I'll tell on you!"
        scene 12_0313 with dissolve
        mc "That's blackmail!"
        han "[lol]"
        scene 12_0314 with dissolve
        han "I could never do that to my favorite pervy uncle!"
    else:
        scene 12_0298 with dissolve
        mc "[lol]"
    scene 12_0315 with dissolve
    mc "Come on, let's go eat."
    han "I'm comin'."
    if Hannah.Has("Knows"):
        mc "{i}That's what she said!"
        han "Who? Millie? [lol]"
        mc "[lol]"
return

label OakHill_04_BackToViolets:
    scene 12_0372 with fade2
    pause
    scene 12_0373 with fade1
    mct "Hmm, guess they've gone to bed already."
    mct "I should do the same. Got a long drive home tomorrow."
    $ gr=False
    if Violet.isActive():
        menu:
            "Sleep in Violet's bed":
                if persistent.Incest and persistent.GroupSex and Millie.isSexual():
                    $ persistent.MillieRP06Dat=1
                else:
                    $ persistent.MillieRP06Dat=0
            "Sleep in the guest room":
                $ gr=True
                if persistent.Incest and Millie.isSexual():
                    $ persistent.MillieRP06Dat=2
                else:
                    $ persistent.MillieRP06Dat=-1
    else:
        $ gr=True
        if persistent.Incest and Millie.isSexual():
            $ persistent.MillieRP06Dat=2
        else:
            $ persistent.MillieRP06Dat=-1
    if persistent.MillieRP06Dat<0:
        scene 12_0374 with fade1
        mc "[whi]...Zzzz..."
    else:
        if persistent.MillieRP06Dat==0:
            call VioletReplay03
        else:
            call MillieReplay06
    call OakHill_04_WakeUp (gr)
    scene 12_0783 with dissolve
    mil "It's afternoon, Dad!"
    scene 12_0784 with dissolve
    mc "You're kidding??"
    mil "No!"
    scene 12_0785 with dissolve
    mc "Damn!\nAnd I was planning on leaving early!"
    scene 12_0786 with dissolve
    mil "We tried to wake you!"
    vi "At least have something to eat, or a coffee before you leave."
    mc "Yeah, coffee sounds great."
    scene 12_0787 with dissolve
    mil "I'll get you one, Dad."
    mc "Thanks, Sweetheart."
    if Violet.Has("R3"):
        scene 12_0788 with dissolve
        vi "How wonderful was last night?"
        mc "It was the best!"
        scene 12_0789 with dissolve
        vi "God, it was!"
        vi "I've never experienced anything like it!"
        scene 12_0790 with dissolve
        vi "I'm going to be masturbating to the memory of you taking her virginity for months!"
        if mAndV:
            vi "... And, when she kissed me!"
            vi "God, I hope I never forget the taste of her soft lips!"
            scene 12_0791 with dissolve
            mc "You could always kiss her again."
            vi "You mean, without you here?"
            vi "No, I couldn't.\nIt was a very special moment, but it wouldn't feel right without you, Baby."
        else:
            scene 12_0791 with dissolve
        mc "How's she feeling about it this morning?"
        scene 12_0792 with dissolve
        vi "Don't worry, she has no regrets!"
        vi "In fact, she was tempted to wake you and do it again, but she was feeling a bit sore!"
        scene 12_0793 with dissolve
        mc "Damn! Was I too rough??\nI tried to take it easy with her."
        vi "No! You didn't do anything wrong. It's natural!"
    elif Violet.Has("R1") and Violet.Has("Told"):
        scene 12_0788 with dissolve
        vi "How was it?"
        mc "She told you?"
        vi "I waited up with her for you to get home!"
        scene 12_0789 with dissolve
        vi "As soon as she heard you come in, she ran down to you!"
        vi "She woke me up {i}so{/i} early this morning!\nBrimming with excitement, she couldn't wait to tell me every detail!"
        scene 12_0790 with dissolve
        vi "I'm going to be masturbating to the description she gave me of you taking her virginity for months!"
        scene 12_0791 with dissolve
        mc "How's she feeling about it this morning?"
        scene 12_0792 with dissolve
        vi "Don't worry, she has no regrets!"
        vi "In fact, she was tempted to wake you and do it again, but she was feeling a bit sore!"
        scene 12_0793 with dissolve
        mc "Damn! Was I too rough??\nI tried to take it easy with her."
        vi "No! You didn't do anything wrong. It's natural!"
    else:
        scene 12_0788 with dissolve
        vi "How did things go with Lucy last night?"
        mc "Good!"
        mc "I think she's actually starting to believe that I want us to be closer."
        scene 12_0789 with dissolve
        vi "I'm so happy for you both!\nIt would be nice to have one big happy family again!"
    scene 12_0794 with dissolve
    mil "Here you go, Dad."
    mc "Ahh, thanks, Sweetie."
    scene black with Fade(3, 2, 0)
    if (Violet.Has("R1") and Violet.Has("Told")) or Violet.Has("R3"):
        scene 12_0796 with Fade(0,0,2)
        mil "[ss]Mmhhh."
        scene 12_0797 with dissolve
        mil "[ss]..Mmmhhh.."
        scene 12_0798 with dissolve
        mil "Bye, Dad.\nI always hate this part."
        mc "Me, too.\nI'll be back soon, though."
    else:
        scene 12_0795 with Fade(0,0,2)
        mil "Bye, Dad.\nI always hate this part."
        mc "Me, too."
    if Violet.isSexual():
        scene 12_0799 with dissolve
        vi "[ss]Mmmhh."
        scene 12_0800 with dissolve
        vi "[whi]You'd think I'd be used to saying goodbye to you by now."
        vi "[whi]It still breaks my heart, though."
        mc "[whi]I'll be back as soon as I can."
    scene 12_0801 with fade1
    mc "Bye, guys."
    mil "Bye, Daddy!"
    $ springhaven_open=True
    jump OakHill_Leave
return

label OakHill_04_WakeUp(gr):
    if gr:
        scene 12_0719 with Fade(3, 3, 2)
        pause
        scene 12_0720 with dis1
        call Emotion (mc, "Groan", "", True)
        scene 12_0782 with fade1
    else:
        scene 12_0721 with Fade(3, 3, 2)
        pause
        scene 12_0722 with dis1
        call Emotion (mc, "Groan", "", True)
        scene 12_0781 with fade1
    vi "Wow! Look who's {b}finally{/b} decided to wake up!"
    mc "Mornin'."
return

label OakHill_Start5:
    scene 15_0001 with Fade(2,3,4)
    play sound "knock.mp3" volume 0.5
    pause
    scene 15_0002 with dissolve
    mct "Well, shit."
    mct "I've done it again.\nI {b}really{/b} need to start telling them beforehand when I decide to visit."
    scene 15_0003 with dissolve
    mc cell "Hey, Sweetie!"
    mil cell "Hi Daddy!"
    mc cell "Where you at?"
    mil cell "Grandma's. Why?"
    scene 15_0004 with dissolve
    mc cell "Ahh, shit."
    mc cell "I'm in Oakhill!"
    mil cell "OHH, DAD!\nWHY DIDN'T YOU TELL US YOU WERE VISITING?!"
    mc cell "Yeah, I know.\nWanted to surprise you again."
    mil cell "We were planning on staying overnight.\nI'll go ask Mom to bring us home, hold on."
    mc cell "No Sweetie, it's okay."
    scene 15_0005 with dissolve
    mc cell "It's a long drive."
    mil cell "But I won't see you!"
    mc cell "You're back tomorrow?"
    mil cell "Yeah."
    scene 15_0006 with dissolve
    mc cell "I can make that work, Sweetheart. I'll stay at Aunt Lucy's tonight."
    mil cell "Promise you'll still be there when we get back, Daddy?"
    mc cell "Yeah."
    scene 15_0007 with dissolve
    mil cell "Okay.\nSee you tomorrow then, Dad."
    mc cell "Bye Sweetheart."
    scene 15_0008 with dissolve
    mct "Sure Lucy won't mind me crashing for one night."
    scene 15_0009 with Fade(2,2,2)
    play sound "knock.mp3" volume 0.5
    scene 15_0010 with dis1
    scene 15_0009 with dis1
    pause
    play sound "knock.mp3"
    scene 15_0010 with dis1
    scene 15_0009 with dis1
    pause
    mct "Damn it."
    scene 15_0011 with dis1
    mct "Come back later."
    scene 15_0012 with dis1
    han "Uncle [mc]?"
    scene 15_0013 with dissolve
    mc "Oh, hey."
    han "What you doin' here?\nMillie and Aunt Vi are out of town!"
    mc "Yeah, I kno--"
    scene 15_0014 with dissolve
    han "Sorry, can't talk. Busy!\nCome on in."
    scene 15_0015 with dissolve
    mc "Uhh.... Thanks."
    scene 15_0016 with fade
    mc "Han??"
    han "[whi]Upstairs."
    scene 15_0017 with dis1
    pause 0.5
    scene 15_0018 with fade
    pause 0.5
    scene 15_0019 with dis1
    han "[whi]Okay, I'm back."
    scene 15_0020 with dissolve
    han "It was just my uncle."
    scene 15_0021 with dissolve
    han "No, it's cool, we can finish this round."
    scene 15_0022 with dissolve
    han "You just don't want me to kick your butt again."
    scene 15_0023 with dissolve
    han "Sorry Unc. We won't be long."
    han "Say hi to my friend Jane!"
    scene 15_0024 with dissolve
    mc "HI JANE!"
    han "She said hey."
    scene 15_0025 with dissolve
    mc "So where's your mom?"
    han "Out."
    scene 15_0026 with dissolve
    han "DUDE! What the hell was that?!!"
    scene 15_0027 with dissolve
    han "You don't have to wait up here, Unc.\nGo make yourself a coffee."
    han "Mom'll be back any minute."
    scene 15_0028 with dissolve
    mc "You kickin' me outta your room?"
    han "No!"
    han "I just can't concentrate with you staring at me!"
    scene 15_0029 with dissolve
    mc "Hah. Okay..."
    if persistent.Incest and Hannah.hasScore(3):
        if not EzModeActive:
            menu:
                "Leave [wk_c]":
                    call CloseCharacterPath (Hannah, "Hannah")
                "[wk_y]Stay":
                    pass
        elif not Hannah.Has("EZ"):
            call CloseCharacterPath (Hannah)
    else:
        call CloseCharacterPath (Hannah)
    if not Hannah.isActive():
        scene 15_0030 with dissolve
        han "I'll come down and sit with you as soon as we've finished."
        mc "Nah, it's fine.\nEnjoy your game, Sweetheart."
        jump OakHill_05_WaitingForLucy
    call HannahReplay01
    scene 15_0155 with fade1
    mc "Hey."
    scene 15_0156 with dissolve
    luc "Let me guess... You didn't let anyone know you were coming... again!"
    mc "Yeah, you'd think I'd have learned my lesson by now, huh?"
    scene 15_0157 with dissolve
    luc "If it were anyone else, I'd agree."
    scene 15_0158 with dissolve
    luc "Violet's away visiting her mother."
    mc "Yeah, I know."
    scene 15_0159 with dissolve
    luc "Had you called first, you wouldn't have wasted your time."
    scene 15_0160 with dissolve
    mc "It's not a waste of time; I still get to see you and Hannah."
    if persistent.Incest and Lucy.hasScore(2):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e15/15_0160.webp", 907, 759, True, "OakHill_AF10")
            luc "I suppose."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 15_0160
                hide screen imgMap
                mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
                luc "Yes, of course."
        else:
            luc "I suppose."
            if not EzModeActive:
                menu:
                    "[wk_y]Move your hand down":
                        call OakHill_AF10
                    "Leave it where it is":
                        mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
                        luc "Yes, of course."
            elif Lucy.Has("EZ"):
                call OakHill_AF10
            else:
                mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
                luc "Yes, of course."
    else:
        call CloseCharacterPath (Lucy)
    scene 15_0169 with dissolve
    luc "I'm going to get changed."
    mc "Changed? Why?"
    scene 15_0170 with dissolve
    luc "It's a beautiful day, and I intend to make the most of what's left of it."
    jump OakHill_05_RelaxWithLucy
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
