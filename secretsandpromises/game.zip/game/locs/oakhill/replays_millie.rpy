label MillieReplay01:
    call Unlocker ("MillieReplay01")
    scene 04_0278 with dissolve
    mct "You have fantasies about me, huh? Heh."
    scene 04_0279 with dissolve
    mct "I wonder... What do you imagine us doing?"
    scene 04_0280 with dissolve
    mct "What do you do to Daddy..."
    scene 04_0281 with dissolve
    mct "... with these sweet..."
    scene 04_0282 with dissolve
    mct "... soft lips?"
    scene 04_0283 with dissolve
    mct "Do you kiss something for Daddy?"
    scene 04_0284 with dissolve
    mct "Do you suck something for Daddy?"
    scene 04_0285 with dissolve
    mil "[whi]..Mhhhh.."
    scene 04_0286 with dissolve
    mct "Heh. Good girl."
    scene 04_0287 with dissolve
    mct "Damn! Giving me an erection!"
    scene 04_0288 with dissolve
    pause 1.0
    scene 04_0289 with Dissolve(2)
    scene 04_0290 with Dissolve(2)
    scene 04_0291 with dissolve
    pause 0.5
    scene 04_0292 with Dissolve(2)
    scene 04_0293 with Dissolve(2)
    scene 04_0294 with Dissolve(2)
    scene 04_0295 with Dissolve(2)
    call Emotion (mil, "Mumbles", "", True)
    scene 04_0296 with dissolve
    pause 1.0
    scene 04_0297 with Dissolve(2)
    scene 04_0298 with Dissolve(2)
    mct "Does Daddy's dick feel good between your legs, Sweetie?"
    call Loop_Dissolve (5, True, False, "e04/04_0299.webp", "e04/04_0298.webp")
    mct "Does it feel nice rubbing up against your pussy?"
    scene 04_0300 with dissolve
    pause 1.0
    scene 04_0301 with dis1
    scene 04_0302 with dis1
    scene 04_0303 with dis1
    mct "Does Daddy play with these in your dreams?"
    call Loop_Dissolve (6, True, False, "e04/04_0304.webp", "e04/04_0305.webp")
    scene 04_0306 with dissolve
    call Moan (mil, 4)
    scene 04_0307 with dissolve
    mct "You like that, Sweetheart?"
    call Loop_Dissolve (5, True, False, "e04/04_0308.webp", "e04/04_0307.webp")
    scene 04_0309 with dis1
    scene 04_0310 with dis1
    scene 04_0311 with dis1
    scene 04_0312 with dis1
    mil "[ss]..Mmhhh..."
    scene 04_0313 with dis1
    pause 0.5
    scene 04_0314 with dissolve
    mct "Damn, you have a cute ass."
    scene 04_0315 with dissolve
    call Moan (mil, 4)
    scene 04_0316 with dissolve
    image r_mil_01 = Movie(play="images/e04/04_0317.webm")
    show r_mil_01
    call Moan (mil)
    scene 04_0318 with dissolve
    call Emotion (mil, "Groan", "", True)
    scene 04_0319 with dissolve
    mil "[ss]..Mmmhh..."
    scene 04_0320 with dissolve
    mct "FUCK!!"
    scene 04_0321 with dissolve
    call Emotion (mil, "Yawn")
    scene 04_0322 with dissolve
    mil "[whi]Huh?"
    scene 04_0323 with dissolve
    call Emotion (mil, "GASP", "", True)
    scene 04_0324 with dissolve
    mc "[whi]..Zzzz.."
    scene 04_0325 with dissolve
    mil "[whi]Dad?"
    call Emotion (mc, "Mumbles", "", True)
    scene 04_0326 with dis1
    mc "[whi]...Zzz..."
    scene 04_0327 with dissolve
    pause 0.5
    scene 04_0328 with dis1
    image r_mil_02 = Movie(play="images/e04/04_0329.webm")
    show r_mil_02
    mil "[ss]..Mmhhh..."
    mct "Oh shit! Not good... She's gonna make me cum!"
    scene 04_0330 with dissolve
    mil "[ss]..Ohhh..."
    scene 04_0331 with dissolve
    mil "[ss]..Oh, Daddy....Mmhh..."
    call Loop_Dissolve (5, True, False, "e04/04_0332.webp", "e04/04_0333.webp")
    scene 04_0334 with dissolve
    call Moan (mil)
    call Loop_Dissolve (6, False, False, "e04/04_0332.webp", "e04/04_0333.webp")
    call CharCum ("e04/04_0332.webp", "e04/04_0335.webp", mil, "...OHHHHHH...")
    call CharCum ("e04/04_0335.webp", "e04/04_0336.webp", mil, "...FFFFFFFF...")
    mct "Fuck..."
    call CharCum ("e04/04_0336.webp", "e04/04_0337.webp", mc, ".....")
    call CharCum ("e04/04_0337.webp", "e04/04_0338.webp", mc, ".....")
    scene 04_0339 with dissolve
    mct "Shiiiit..."
    scene 04_0340 with dissolve
    pause 1.0
    scene 04_0341 with dissolve
    pause
    scene 04_0342 with dissolve
    pause
    scene 04_0343 with dissolve
    pause
    scene 04_0344 with dissolve
    mil "[whi]Nhhhh.."
    scene 04_0345 with dissolve
    mil "[whi][giggles]"
    scene 04_0346 with dissolve
    pause 1.0
    scene 04_0347 with dissolve
    mil "[whi]Love you, Dad."
    scene 04_0348 with dissolve
    mil "[whi][kiss]"
    scene 04_0347 with dissolve
    pause 1.0
    scene 04_0349 with dissolve
    pause 0.5
    scene 04_0350 with dis1
    pause 0.5
    scene 04_0351 with dis1
    pause 0.5
    scene 04_0352 with dissolve
    pause 1.0
    scene 04_0353 with dis1
    pause 0.5
    scene 04_0354 with dissolve
    mct "Love you too, Sweetie. Heh."
    scene black with Fade(3, 0, 0)
return

label MillieReplay02:
    call Unlocker ("MillieReplay02")
    if _in_replay:
        call CenterText ("Millie fingers compilation")
        scene 02_0712 with fade1
        pause 1.0
        scene 02_0713 with dissolve
        scene 02_0714 with dissolve
        mct "Fuck!\nShould've knocked first!"
        scene 02_0715 with dissolve
        mil "[ss]..Mmhh.."
        mct "Close the door and knock, you idiot!"
        scene 02_0716 with dissolve
        play sound "knock.mp3"
        pause 1.5
        mil "[whi]Err... {b}Just a minute!"
        pause 1.0
        mil "[whi]Okay, Mom. Come in."
        scene 02_0717 with dissolve
        mc "Uhh, it's not your mom."
        mil "DAD!"
        scene 02_0718 with dissolve
        pause 0.5
        scene 02_0719 with dissolve
        call Emotion (mil, "Sobbing", "I'm so sorry I was mean to you!")
        scene 02_0720 with dissolve
        call Emotion (mil, "Sobbing", "I didn't mean the things I said!")
        mc "I know. I'm sorry, too."
        scene 02_0721 with dissolve
        mc "Please don't cry, Sweetheart!"
        mc "I know I fucked it up, but I'd really like to be your dad again."
        mil "I'd like that, too."
        scene 02_0722 with dissolve
        mc "I've missed you so much."
        mil "I've missed you too, Daddy.\nMore than you can ever know!"
        scene 02_0723 with dissolve
        mc "Damn! Look how much you've grown!"
        scene 02_0724 with dissolve
        mil "And {i}you've{/i} grown... {b}old{/b}![giggles]"
        scene 02_0725 with dissolve
        mct "Is that the faint scent of her pussy I can smell on her fingers?"
        scene 02_0726 with dis1
        scene 02_0727 with dis1
        pause 0.5
        scene 02_0728 with dissolve
        mil "[whi]What... are you doing?!"
        scene 02_0729 with dissolve
        mc "Shit, I'm Sorry!"
        mc "I don't know what's wrong with me lately!\nIt sometimes feels like someone else is controlling me!"
        mc "I guess... They smell nice! I wanted to see if they taste nice, too."
        mil "[whi]... Umm... okay?"
        scene 02_0730 with dissolve
        mil "[whi]......{size=*.8}do they?"
        mc "Yeah."
        scene 02_0732 with dissolve
        pause 0.5 
        scene 02_0733 with dissolve
        mil "Cara told me you were home."
        mil "She said you might come and see me.\nI didn't believe her for a second!"
        scene 02_0734 with dissolve
        mil "But... HERE YOU ARE!!"
        scene 02_0735 with dissolve
        mil "Umm... I just remembered... I'm not wearing pants!"
        mc "[lol] I'll let you get dressed."
        scene 04_0016 with Fade(2, 1, 2)
        mc "In my defense, though, I didn't know you were still friends!\nI would've asked you not to say anything![lol]"
        scene 04_0017 with dissolve
        vi "Friends?"
        scene 04_0018 with dissolve
        vi "We're more than friends, [mc]!\nWe're like sisters!"
        scene 04_0019 with dissolve
        mil "You're here!!"
        scene 04_0020 with dis1
        scene 04_0021 with dis1
        mc "Hi, Sweetheart!"
        scene 04_0022 with dissolve
        mil "I've been excited {b}all{/b} morning waiting for you to arrive!"
        scene 04_0023 with dissolve
        vi "Coffee?"
        mc "Yeah, I'd love one! Thanks."
        scene 04_0024 with dissolve
        mil "When you promised to come back, I didn't expect it to be so soon!"
        mc "Yeah, me neither.[lol]"
        scene 04_0025 with dissolve
        mil "Oh... You, umm..."
        scene 04_0026 with dissolve
        mil "... have something on your lip..."
        scene 04_0027 with dissolve
        pause 0.5
        scene 04_0028 with dis1
        pause 0.5
        scene 04_0029 with dis1
        pause 0.5
        scene 04_0030 with dis1
        pause 0.5
        scene 04_0031 with dissolve
        mil "... [whi]Oops, sorry."
        scene 04_0032 with dissolve
        mc "[whi]Mmm..."
        scene 04_0033 with dissolve
        mil "[whi]That's better, it's gone now!"
        mct "Jesus! Her fingers have the same taste as before!\nDid she do that deliberately??"
        scene 04_0034 with dissolve
        mil "Mom said you're staying for the night again?"
        mc "Yep!"
        scene 04_0035 with dissolve
        vi "Sorry Sweetie, but you'll need to let go of him so he can drink his coffee."
        scene 07_0097 with Fade(2, 1, 2)
        mil "You don't need to leave!"
        mil "I'm only changing into jeans.\nYou've already seen me in my underwear!"
        scene 07_0099 with dissolve
        mil "Good. I want to keep my eye on you."
        scene 07_0100 with dissolve
        mil "Make sure you don't sneak off..."
        scene 07_0101 with dissolve
        mil "...because you're too frightened to ride a horse.[lol]"
        mc "Hah! I'll have you know - I'm a pro at riding!"
        scene 07_0102 with dissolve
        mil "We'll see."
        call OakHill_AF07
        scene 07_0106 with dissolve
        mil "Actually, Dad... Should we invite Hannah?\nI bet she'd love to come with us."
        mc "Uh... I thought you wanted {i}us{/i} to spend time together?"
        mil "I do!"
        scene 07_0107 with dissolve
        mil "But, she's always telling me how she'd like to spend more time with you, too."
        scene 07_0108 with dissolve
        mil "I need to stop being selfish and learn to share you a bit.[lol]"
        scene 07_0109 with dissolve
        mc "What if I want to be selfish and have {b}you{/b} all to myself?"
        scene 07_0110 with dissolve
        mil "Well... Once you live closer, you can have me whenever you want!"
        scene 07_0109 with dissolve
        mc "Sweetheart, this is your day.\nIf you'd like to invite Hannah along, then of course, I don't mind."
        scene 07_0111 with dissolve
        mil "Great. I'll call her from the car!"
        scene 07_0112 with dissolve
        pause
        mil "Dad..."
        mil "Can I ask you something... kinda weird?"
        mc "Sure."
        scene 07_0112_01 with dissolve
        mil "Remember when you told me you liked the taste of my fingers?..."
        mc "Uhh... Yeah."
        mil "Did you... Umm..."
        mil "... did you know... what you were tasting?"
        mc "Yeah, I knew exactly what I was tasting."
    scene 07_0112_03 with dissolve
    mil "Yeah?"
    mil "And you {i}really{/i} liked it?"
    mc "I did."
    scene 07_0112 with dissolve
    mil "Would you...ummm..."
    mil "... like to taste them again?"
    mc "Yeah."
    scene 07_0113 with dis1
    pause 0.5
    scene 07_0114 with dis1
    pause 0.5
    scene 07_0115 with dis1
    pause 0.5
    scene 07_0116 with dissolve
    mil "I'd like you to taste them again, too."
    scene 07_0117 with dissolve
    pause
    scene 07_0118 with dissolve
    mil "[whi]Open for me, Daddy."
    scene 07_0119 with dissolve
    mct "Damn... I shouldn't encourage this..."
    scene 07_0120 with dissolve
    mct "... Can't help myself though."
    scene 07_0121 with dis1
    pause
    scene 07_0122 with dis1
    pause
    scene 07_0123 with dis1
    pause
    scene 07_0124 with dis1
    pause
    scene 07_0125 with dissolve
    mil "[ss]Mmhh."
    scene 07_0126 with dissolve
    mil "[ss]..Mmhh.."
    scene 07_0127 with dissolve
    mil "[ss]Mmhh."
    call Loop_Dissolve (3, True, False, "e07/07_0128.webp", "e07/07_0127.webp")
    scene 07_0129 with dissolve
    mil "[giggles]"
    mil "I'll finish getting dressed."
    scene 07_0130 with dissolve
    mc "Heh. Okay."
return

label MillieReplay03A:
    scene 07_0276 with dissolve
    mct "Vi's right, it {b}has{/b} been a good day!"
    scene 07_0277 with dissolve
    mct "Hmm... Left the door open for once."
    scene 07_0278 with dissolve
    mct "Damn, is she at it again? Heh."
    scene 07_0279 with dissolve
    mct "The picture we took at the lake."
    mct "Is this why she wanted more photos of me?"
    scene 07_0280 with dissolve
    mil "I know you're there, Dad. I heard your footsteps."
    mc "Sorry... Just wanted to tell-"
    scene 07_0281 with dissolve
    mil "[whi]You can come in."
    if not _in_replay:
        if not EzModeActive:
            menu:
                "[wk_y]Enter":
                    call MillieReplay03
                "Leave[wk_c]":
                    call CloseCharacterPath (Millie, "Millie")
                    mc "Uhh, it's okay.\nJust wanted to let you know we're going out to grab food soon."
                    mil "Okay."
                    scene 07_0282 with dissolve
                    mct "Needed to put an end to that."
        else:
            call MillieReplay03
return

label MillieReplay03:
    call Unlocker ("MillieReplay03")
    if _in_replay:
        call MillieReplay03A
    else:
        $ persistent.MillieRP03Dat=Violet.isActive()
        $ Millie.isSexual(True)
    scene 07_0283 with dissolve
    mil "Are you here to taste my fingers again, Daddy?"
    scene 07_0284 with dissolve
    mil "Or maybe... you'd like to taste your own."
    scene 07_0285 with dissolve
    mc "Damn, Millie... You know we shouldn't be doing this, right??"
    scene 07_0286 with dissolve
    mil "Yeah. But I don't care. It can be our little secret."
    scene 07_0287 with dissolve
    mil "You don't have to touch me if you don't want to, Daddy..."
    scene 07_0288 with dissolve
    mil "Just stay.\nKnowing you're here, next to me, watching...\nIt's making me so excited!"
    scene 07_0289 with dissolve
    mil "[ss]Mhh."
    scene 07_0290 with dis1
    pause
    scene 07_0291 with dis1
    pause
    scene 07_0292 with dissolve
    pause 0.5
    scene 07_0293 with dis1
    pause
    scene 07_0303 with dissolve
    mil "[ss]...I've dreamed about you touching me so many times....."
    scene 07_0295 with dissolve
    image r_mil_03 = Movie(play="images/e07/07_0296.webm")
    show r_mil_03
    call Moan (mil, 4)
    scene 07_0297 with dissolve
    mil "[ss]...Ohh, Daddy..."
    scene 07_0298 with dis1
    pause 0.5
    scene 07_0299 with dis1
    pause 0.5
    scene 07_0300 with dis1
    pause 0.5
    scene 07_0301 with dis1
    pause 0.5
    scene 07_0302 with dis1
    pause
    scene 07_0294 with dissolve
    mil "[ss]...Ohh.... yes ...."
    scene 07_0304 with dissolve
    image r_mil_04 = Movie(play="images/e07/07_0305.webm")
    show r_mil_04
    call Moan (mil, 4)
    if persistent.MillieRP03Dat:
        scene 07_0307 with dissolve
        mil "[ss]..Mmmhh.."
        $ Violet.Add("Saw")
        scene 07_0308 with dissolve
        pause
        scene 07_0309 with dissolve
        call Moan (mil)
        scene 07_0310 with dissolve
        pause
    else:
        scene 07_0309 with dissolve
        call Moan (mil)
    scene 07_0311 with dissolve
    mil "[ss]...Ohhhh....."
    scene 07_0312 with dissolve
    image r_mil_05 = Movie(play="images/e07/07_0313.webm")
    show r_mil_05
    mil "[ss]..Ohhh, Dad..."
    mil "[ss]....Keep going...I'm close already...."
    scene 07_0314 with dissolve
    image r_mil_06 = Movie(play="images/e07/07_0315.webm")
    show r_mil_06
    mil "[ss]..OHHHH..."
    mil "[ss]....YES...."
    scene 07_0316 with dissolve
    mil "[ss]...I'm so close, Daddy..."
    mil "[ss]...OHHH.....I want to cum for you....."
    scene 07_0317 with dissolve
    image r_mil_07 = Movie(play="images/e07/07_0318.webm")
    show r_mil_07
    mil "[ss]..OHHHH....YES...."
    mil "[ss]..MMHHHH..KEEP GOING....."
    mil "[ss].....OHHH DAD....YES...."
    mil "[ss]...YES......{b}YESSS{/b}...."
    call CharCum ("e07/07_0317.webp", "e07/07_0319.webp", mil, "OHHHHHHHHH!!")
    call CharCum ("e07/07_0319.webp", "e07/07_0320.webp", mil, "...OHHHHH!!...")
    scene 07_0321 with dissolve
    mil "[ss]...God..."
    scene 07_0322 with dissolve
    mil "[ss]BEST.ORGASM.EVER!"
    scene 07_0323 with dissolve
    mil "[whi]I love you, Dad."
    mc "[whi]I love you too, Sweetheart."
    if _in_replay:
        scene black with ReplayFade
return

label MillieReplay04:
    call Unlocker ("MillieReplay04")
    if not _in_replay:
        $ Millie.isSexual(True)
        scene 07_0405 with dissolve
    else:
        scene 07_0405 with Fade(0, 0, 2)
    vi "[whi]Is she still peeping?"
    mc "[whi]Think so."
    scene 07_0406 with dissolve
    vi "Millie?"
    mc "[whi]Vi! What are you doing??"
    scene 07_0407 with dissolve
    mil "[whi]Ummm... Sorry, Mom... I, umm... heard a noise..."
    vi "It's okay, Sweetie. Come in."
    scene 07_0408 with dissolve
    mil "I wasn't spying."
    vi "It's fine! Come sit with us for a minute."
    scene 07_0409 with dissolve
    vi "I think we've all caught our parents having sex at least once![giggles]"
    mil "I didn't mean to..."
    scene 07_0410 with dissolve
    vi "It's okay, Sweetie!"
    scene 07_0411 with dissolve
    vi "There's nothing to be embarrassed about!"
    scene 07_0412 with dissolve
    mil "[whi]..."
    vi " Beautiful, isn't it? [giggles]"
    scene 07_0413 with dissolve
    vi "Would you like to touch it, Sweetheart?"
    mil "[whi]What?... Ummm.... No..."
    scene 07_0414 with dissolve
    vi "Want to watch {i}me{/i} play with it?"
    mil "[whi]..."
    scene 07_0415 with dissolve
    mil "[whi]...okay."
    scene 07_0416 with dissolve
    image r_vi_017 = Movie(play="images/e07/07_0417.webm")
    show r_vi_017
    mct "Fuck.... What are we doin' here?..."
    mct "... Damn that feels good..."
    mct "....Need to stop thinkin' about Millie watching, or I'm gonna explode!..."
    scene 07_0418 with dissolve
    vi "[whi]Wanna have a little try, Sweetie?"
    scene 07_0419 with dissolve
    mil "[whi]Umm.... Can I? [giggles]"
    vi "[whi]Yeah!"
    scene 07_0420 with fade
    pause 0.5
    scene 07_0421 with dis1
    vi "[whi]That's it."
    mil "[whi]It's so stiff!"
    vi "[whi]That means your dad likes you holding it!"
    vi "[whi]... Now move your hand slowly up and down."
    scene 07_0422 with dissolve
    image r_vi_018 = Movie(play="images/e07/07_0423.webm")
    show r_vi_018
    mct "...Fuuck..."
    scene 07_0424 with dissolve
    mil "[whi]Am I doing it right, Daddy?"
    mc "[whi]Perfect, Sweetheart."
    scene 07_0425 with dissolve
    mil "[whi]Does it feel nice?"
    mc "[whi]Yeah, it does."
    scene 07_0426 with dissolve
    image r_vi_019 = Movie(play="images/e07/07_0427.webm")
    show r_vi_019
    vi "[whi]That's it, Millie, just like that."
    scene 07_0428 with dissolve
    pause 0.5
    scene 07_0429 with dis1
    vi "[whi]You can put it in your mouth if you like, Sweetheart.\nHe'd love it![giggles]"
    scene 07_0430 with dis1
    scene 07_0431 with dissolve
    vi "[ss]..Mmhhh.."
    scene 07_0432 with dissolve
    image r_vi_020 = Movie(play="images/e07/07_0433.webm", loop=False, keep_last_frame=True)
    show r_vi_020
    pause 11.5
    scene 07_0434 with dissolve
    mc "[ss]...FUCK..."
    scene 07_0435 with dissolve
    image r_vi_021 = Movie(play="images/e07/07_0436.webm")
    show r_vi_021
    vi "[whi]Good girl, Millie![giggles]"
    scene 07_0437 with dissolve
    image r_vi_022 = Movie(play="images/e07/07_0438.webm")
    show r_vi_022
    mil "[ss]Mmhh."
    scene 07_0439 with dissolve
    vi "[whi]That's it, Baby... A little faster.."
    scene 07_0440 with dissolve
    image r_vi_023 = Movie(play="images/e07/07_0441.webm")
    show r_vi_023
    mil "[ss]..Mmmhhhh.."
    scene 07_0442 with dissolve
    mil "[ss]....Mmhhh...."
    scene 07_0443 with dissolve
    vi "[whi]If you'd like to make your daddy cum, you can use your hand as well, Sweetie."
    scene 07_0444 with dissolve
    image r_vi_024 = Movie(play="images/e07/07_0445.webm")
    show r_vi_024
    mil "[ss]..Mmmhhhh.."
    scene 07_0446 with dissolve
    mc "[ss]..Millie...stop...I'm gonna..."
    vi "[whi]That's what she wants, Honey."
    scene 07_0447 with dissolve
    image r_vi_025 = Movie(play="images/e07/07_0448.webm")
    show r_vi_025
    mil "[ss]..Mmhhh.."
    scene 07_0449 with dissolve
    image r_vi_026 = Movie(play="images/e07/07_0450.webm")
    show r_vi_026
    mil "[ss]..Mmmmhhhhh.."
    call CharCum ("e07/07_0449.webp", "e07/07_0451.webp", mc, "NNNNNGGGGHHHHH!!")
    call CharCum ("e07/07_0451.webp", "e07/07_0452.webp", mc, "...NNGHHHH....")
    scene 07_0453 with dissolve
    vi "[whi]Good job, Sweetie!\nYou can spit it out in the bathroom."
    scene 07_0454 with dissolve
    call Gulp (mil)
    scene 07_0455 with dissolve
    scene 07_0456 with dissolve
    scene 07_0457 with dissolve
    vi "[whi]Wow!"
    scene 07_0458 with dissolve
    vi "[whi]Well done, Millie! I'm impressed!"
    scene 07_0459 with dissolve
    vi "[whi]Wasn't this fun?[giggles]"
    if not _in_replay:
        scene 07_0460 with Fade(2, 1, 2)
        mc "[whi]..Zzzz.."
    else:
        scene black with Fade(2, 1, 0)
return

label MillieReplay05:
    call Unlocker ("MillieReplay05")
    if _in_replay:
        scene 12_0020 with Fade(0,0,3)
        mil "NO WAY!"
        mil "Dad, wait! LOOK!"
        scene 12_0021 with dissolve
        mil "We used to play this all the time!"
        mc "Damn! You still have that?!"
        scene 12_0022 with dissolve
        mil "Let's play!"
        mc "What? Now?!"
        mil "Yeah!"
        scene 12_0023 with dissolve
        mil "Pleeeeasse, Daddy!"
        mil "It'll be fun!"
        scene 12_0024 with dissolve
        mc "Beats sitting downstairs doin' nothing!\nBut {b}this{/b} time - when I win, no sulking!"
        mil "I'm in charge of the spinner! You always cheated!"
        mc "[lol]"
        scene 12_0025 with fade1
        call AutoA
        $ apause(1)
        scene 12_0027 with fade1
        $ apause(1)
        call AutoA (False)
        scene 12_0028 with dissolve
        mct "Glad I agreed to play! Heh."
        scene 12_0029 with dissolve
        mct "Definitely beats sitting on the sofa!"
        scene 12_0034 with fade1
        mc "Okay, now you're just showing off!"
        mil "[lol]"
        scene 12_0035 with dissolve
        mct "Can't help it... Just a little peek...heh."
        scene 12_0036 with dissolve
        mct "Damn! No panties... She's playin' commando! Nice!"
        mct "Yeah... She knew what was in the box all along, heh."
        scene 12_0037 with fade1
        mil "Your left foot on red."
        mc "Jeez."
        scene 12_0038 with dissolve
        mc "... Okay... Got it."
        scene 12_0039 with fade1
        mc "C'mon! Not sure how much longer I can hold this!"
        mil "[lol] Right hand, green."
        mc "Are you kiddin' me?!"
    else:
        $ persistent.MillieRP05Dat = Millie.isSexual()
        $ Millie.isSexual(True)
    scene 12_0045 with vpunch
    mc "Damn it!"
    mil "You did it! Your hand's on green!"
    mil "My turn."
    scene 12_0046 with dissolve
    mil "Left foot... blue."
    scene 12_0047 with dissolve
    mil "There's only one I can reach."
    scene 12_0048 with dissolve
    mil "Got it!"
    scene 12_0049 with dissolve
    mil "Enjoying the game, Dad?"
    scene 12_0050 with dissolve
    mc "Very much, Sweetie."
    scene 12_0051 with dissolve
    mc "But, to be certain you're not cheating, I'm gonna pick your next move."
    mil "Uh, okay."
    mc "Left hand, red."
    call AutoA
    scene 12_0052 with dissolve
    $ apause(1)
    call AutoA (False)
    scene 12_0053 with dissolve
    mil "Easy peasy!"
    scene 12_0054 with dissolve
    mil "Your move, Daddy."
    scene 12_0055 with dissolve
    mc "Yes, it is..."
    scene 12_0056 with dis1
    scene 12_0057 with dis1
    scene 12_0058 with dis1
    pause
    scene 12_0059 with dissolve
    pause
    scene 12_0060 with dissolve
    mil "[ss]..Ohhhh.."
    scene 12_0061 with dissolve
    image MillieR05_01 = Movie(play="images/e12/12_0062.webm")
    show MillieR05_01
    pause
    scene 12_0063 with dissolve
    mil "[ss]...Ohhhh....Yes...."
    mil "[ss]...I've waited so long to feel your tongue, Daddy...."
    scene 12_0064 with dissolve
    call AutoA
    $ apause()
    scene 12_0065 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0066 with dis1
    mc "[ss]Mmhhhh."
    scene 12_0067 with dissolve
    mil "[ss]...OHHHHH...."
    scene 12_0068 with dissolve
    image MillieR05_02 = Movie(play="images/e12/12_0069.webm")
    show MillieR05_02
    call Moan (mil, 6)
    scene 12_0070 with dissolve
    mct "Been wanting to do this since the day I first tasted her fingers."
    mct "...Can't get enough of her..."
    scene 12_0071 with dissolve
    mil "[ss]...Ohhh..."
    scene 12_0072 with dis1
    mil "[ss]...Mmhhh..."
    scene 12_0073 with dis1
    mil "[ss]..Ohhh....Dad....."
    scene 12_0074 with dis1
    if not persistent.MillieRP05Dat:
        mil "[ss]...Please don't stop me......"
    else:
        mil "[ss]...Please don't stop......"
    scene 12_0075 with dis1
    call AutoA
    $ apause()
    scene 12_0076 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0077 with dis1
    mil "[ss]Nnhhh."
    scene 12_0078 with dissolve
    if not persistent.MillieRP05Dat:
        mct "Oh Sweetheart, I've no intention of stopping you... I Don't give a fuck how wrong it is...."
    else:
        mct "....I've no intention of stopping, Sweetheart..."
    scene 12_0079 with dissolve
    call AutoA
    $ apause()
    scene 12_0080 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0081 with dis1
    mil "[ss]..Mmmhhhhh..."
    image MillieR05_03 = Movie(play="images/e12/12_0083.webm", loop=False, keep_last_frame=True)
    scene 12_0082 with dis1
    mil "[whi][kiss]"
    show MillieR05_03
    image MillieR05_04 = Movie(play="images/e12/12_0085.webm")
    pause 8.8
    show MillieR05_04
    mil "[ss]..Mmmhhh.."
    scene 12_0086 with dissolve
    image MillieR05_05 = Movie(play="images/e12/12_0087.webm")
    show MillieR05_05
    mct "I'm in fuckin' Heaven right now."
    scene 12_0088 with dissolve
    image MillieR05_06 = Movie(play="images/e12/12_0089.webm")
    show MillieR05_06
    mc "[ss]..Mmmhh.."
    scene 12_0090 with dissolve
    image MillieR05_07 = Movie(play="images/e12/12_0091.webm")
    show MillieR05_07
    mil "[ss]..Mmmhhh.."
    scene 12_0094 with dissolve
    mct "Damn... She's soaking wet with excitement....."
    mct "... Sweetie, you make Daddy just as horny...."
    scene 12_0092 with dissolve
    image MillieR05_08 = Movie(play="images/e12/12_0093.webm")
    show MillieR05_08
    mil "[ss]..Mmhh."
    scene 12_0095 with dissolve
    mc "[ss]..Mmmmhh.."
    mct "...God, I'd love to fuck her. My hot, beautiful daughter...."
    scene 12_0096 with dissolve
    image MillieR05_09 = Movie(play="images/e12/12_0097.webm")
    show MillieR05_09
    mil "[ss]...Mmmmmmhhhh..."
    scene 12_0098 with dissolve
    mc "[ss]..Mmhh."
    call CharCum ("e12/12_0098.webp", "e12/12_0099.webp", mil, "....Ohhhh, Daddy.....")
    call CharCum ("e12/12_0099.webp", "e12/12_0100.webp", mil, "..Mmmmhhhh..")
    scene 12_0101 with dissolve
    mil "[whi]{b}THAT{/b} was the best orgasm ever!"
    scene 12_0102 with dissolve
    mc "[ss]..Mmhh."
    scene 12_0096 with dis1
    show MillieR05_09
    mil "[ss]...Mmmmhhhh..."
    call CharCum ("e12/12_0096.webp", "e12/12_0103.webp", mc, "Nnnnnggghhhhh.")
    call CharCum ("e12/12_0103.webp", "e12/12_0104.webp", mc, "...Nnnhhhh...")
    scene 12_0105 with dissolve
    call AutoA
    $ apause()
    scene 12_0106 with dissolve
    call Gulp (mil)
    scene 12_0107 with dissolve
    $ apause()
    scene 12_0108 with dissolve
    $ apause()
    call AutoA (False)
    scene 12_0109 with dissolve
    pause
    scene 12_0110 with dissolve
    mil "[whi]Mmhhh... I think you won this round, Dad."
    mc "[whi]Certainly feels like it, Sweetheart."
    if _in_replay:
        scene black with ReplayFade
        return
    scene 12_0111 with fade1
    mil "I don't remember the game ever being {b}that{/b} good!"
    mc "Well, you never played panty-less before!"
    scene 12_0112 with dissolve
    mil "[lol]"
    scene 12_0113 with dissolve
    mil "I have a question..."
    mc "Okay?"
    scene 12_0114 with dissolve
    mil "It's more a request really."
    scene 12_0115 with dissolve
    mil "When I'm ready, I want {b}you{/b} to take my virginity, Dad."
    scene 12_0116 with dissolve
    mc "Oh, Millie, Sweetheart, I'd be honored."
    mc "It's a big step though, and there's no rush."
    scene 12_0117 with dissolve
    mc "Just be sure you're ready, and it's really what you want before you take it."
    scene 12_0118 with dissolve
    mil "When I take it, it'll be with {b}you{/b}.\nYou're {i}going{/i} to fuck me, Daddy."
    mil "Now kiss me to seal the deal."
    scene 12_0119 with dissolve
    mc "[whi][kiss]"
    scene 12_0120 with dissolve
    call AutoA
    $ apause()
    scene 12_0121 with dis1
    $ apause()
    scene 12_0122 with dis1
    $ apause()
    scene 12_0123 with dis1
    $ apause()
    scene 12_0124 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0125 with dissolve
    mil "[ss]Mmhhh."
    scene 12_0126 with dissolve
    mil "[ss]..Mmmhhhh..."
    scene 12_0127 with dissolve
    mc "[whi]Damn!"
    mc h "[whi]You ready yet??"
    mil h "[whi]Keep kissing me like that, and I may just say yes!"
    scene 12_0126 with dissolve
    mil "[ss]..Mmmmmhhhh..."
    scene 12_0128 with dissolve
    vi "[whi]MILLIE!\nI'M HOME!"
    vi "[whi]IS THAT YOUR DAD'S TRUCK OUT FRONT?"
    scene 12_0127 with dissolve
    mc "[whi]I'd better go say hello."
    mil "[whi]Yeah."
    scene 12_0126 with dissolve
    mil "[ss]Mmhhh.."
    scene 12_0129 with dissolve
    mc "[whi]You coming?"
    mil "[whi]I already did, thanks to you."
    scene 12_0130 with dissolve
    mc "[lol]"
    mil "I'll be down in a minute."
return

label MillieReplay06:
    if persistent.MillieRP06Dat==1:
        call MillieReplay06_01
    elif persistent.MillieRP06Dat==2:
        call MillieReplay06_02
return

label MillieReplay06_01:
    call Unlocker ("MillieReplay06_01")
    if not _in_replay:
        $ Violet.incSex()
        $ Millie.incSex()
    scene 12_0375 with Fade(0, 0, 2)
    mct "Wonder if Vi's still awake?"
    scene 12_0376 with dissolve
    mct "Tired... but a little horny, too!"
    scene 12_0377 with dissolve
    vi "Hi, Baby."
    scene 12_0378 with dissolve
    mil "Hi, Daddy."
    mc "Hey."
    scene 12_0380 with dissolve
    mc "What's goin' on?"
    vi "She's been waiting patiently for you to come home."
    scene 12_0381 with dissolve
    mil "I'm ready, Dad."
    scene 12_0382 with dissolve
    mc "Sweetheart, are you {b}sure{/b}?\nI don't want you to have any regrets."
    mil "I'm sure."
    scene 12_0383 with dissolve
    vi "We've had a long discussion, [mc].\nIf she's telling you she's ready, believe me - she's ready."
    vi "She's nervous, so I offered to stay and support her. I hope that's okay with you."
    scene 12_0384 with dissolve
    mc "Millie..."
    mil "I swear, Dad, I've thought about it a lot, and I want to do it."
    scene 12_0385 with dissolve
    mil "Please, Daddy..."
    scene 12_0386 with dissolve
    mil "I want to feel you inside me."
    scene 12_0387 with fade1
    pause
    scene 12_0388 with dissolve
    mc "We'll take it as slow as you want, Sweetie."
    mil "Can I suck your dick again?"
    mc "Uhh... sure."
    scene 12_0389 with dissolve
    mc "Oh, okay... straight to it, huh?"
    scene 12_0390 with dissolve
    call AutoA
    $ apause(1)
    scene 12_0391 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0392 with dis1
    mil "[ss]Mmhh."
    scene 12_0393 with dis1
    call AutoA
    $ apause()
    scene 12_0394 with dis1
    $ apause()
    scene 12_0395 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0396 with dis1
    mil "[ss]Mmmhh."
    scene 12_0397 with dissolve
    image MillieR06_01 = Movie(play="images/e12/12_0398.webm")
    show MillieR06_01
    pause
    scene 12_0399 with dissolve
    image MillieR06_02 = Movie(play="images/e12/12_0400.webm")
    show MillieR06_02
    mil "[ss]...Mmmhhhh..."
    scene 12_0401 with dissolve
    pause 0.5
    scene 12_0402 with dis1
    mc "[whi]Damn, Millie. I love watching you do that."
    vi "[whi]So do I!"
    scene 12_0403 with dis1
    scene 12_0404 with dis1
    scene 12_0405 with dis1
    scene 12_0406 with dis1
    scene 12_0407 with dis1
    scene 12_0408 with dis1
    scene 12_0409 with dis1
    scene 12_0410 with dis1
    call Loop_Dissolve (4, True, False, "e12/12_0411.webp", "e12/12_0412.webp")
    mil "[ss]...Mmmmhhhhh..."
    scene 12_0413 with dis1
    scene 12_0414 with dis1
    call Loop_Dissolve (6, False, False, "e12/12_0415.webp", "e12/12_0416.webp")
    call Moan (mil, 4)
    scene 12_0417 with dissolve
    mc "Take off her panties for me, Honey."
    vi "Of course, Baby."
    scene 12_0418 with dis1
    pause 0.5
    scene 12_0419 with dis1
    mc "[whi]That's better."
    scene 12_0420 with dissolve
    image MillieR06_03 = Movie(play="images/e12/12_0421.webm")
    show MillieR06_03
    call Moan (mil)
    scene 12_0422 with dissolve
    mil "[ss]...Ohhhh.....I love it when you touch me, Dad...."
    scene 12_0420 with dissolve
    call AutoA
    $ apause()
    scene 12_0423 with dis1
    scene 12_0424 with dis1
    scene 12_0425 with dis1
    $ apause()
    scene 12_0426 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0427 with dis1
    call Moan (mil)
    scene 12_0428 with dissolve
    mil "[ss]..Mmmhhh.."
    scene 12_0429 with dissolve
    if not _in_replay and persistent.Lez and mAndV==None:
        call Encourage ("Millie", "Violet")
        $ mAndV=_return
        $ persistent.MilandVi=mAndV
    if persistent.MilandVi:
        call AutoA
        $ apause()
        scene 12_0430 with dis1
        $ apause()
        scene 12_0431 with dis1
        $ apause()
        call Loop_Dissolve (1, False, False, "e12/12_0432.webp", "e12/12_0433.webp")
        scene 12_0434 with dissolve
        $ apause()
        scene 12_0435 with dis1
        $ apause(1.5)
        scene 12_0436 with dis1
        $ apause()
        scene 12_0437 with dis1
        $ apause()
        call AutoA (False)
        scene 12_0438 with dis1
        vi "[ss]Mhh."
        scene 12_0439 with dissolve
        vi "[ss]...Mmmmhhhhhh..."
        scene 12_0440 with dissolve
    else:
        pause 0.5
        scene 12_0440 with dis1
    mc "[whi]Come here, Honey."
    scene 12_0441 with dis1
    vi "[ss]Mmhhh."
    scene 12_0442 with dissolve
    mil "[ss].....Mmhhh......"
    scene 12_0443 with dissolve
    mc "[whi]Wanna help your daughter suck her daddy's dick?"
    vi "[whi]Fuck yeah, I do!"
    scene 12_0444 with fade1
    image MillieR06_04 = Movie(play="images/e12/12_0445.webm")
    show MillieR06_04
    mil "[ss]..Mmhhh.."
    scene 12_0446 with dissolve
    image MillieR06_05 = Movie(play="images/e12/12_0447.webm")
    show MillieR06_05
    mil "[ss]...Mmmmhhhhh..."
    scene 12_0448 with dissolve
    vi "[whi]God, you look {b}so{/b} beautiful with Daddy's dick in your mouth, Sweetie."
    scene 12_0449 with dissolve
    mil "[whi]Can I see it in {i}your{/i} mouth, Mom?"
    scene 12_0450 with dis1
    call AutoA
    $ apause()
    scene 12_0451 with dis1
    $ apause()
    scene 12_0452 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0453 with dis1
    vi "[ss]Mmhhh."
    scene 12_0454 with dissolve
    image MillieR06_07 = Movie(play="images/e12/12_0455.webm")
    show MillieR06_07
    vi "[ss]...Mmmhh..."
    scene 12_0456 with dissolve
    call AutoA
    $ apause()
    scene 12_0457 with dis1
    scene 12_0458 with dis1
    call AutoA (False)
    scene 12_0459 with dis1
    mil "[ss]..Mmhhh.."
    scene 12_0460 with dissolve
    mil "[ss]..Mmhhh.."
    scene 12_0461 with dissolve
    image MillieR06_08 = Movie(play="images/e12/12_0462.webm")
    show MillieR06_08
    vi "[ss]....Mmmmmhh....."
    scene 12_0463 with dissolve
    call AutoA
    $ apause()
    scene 12_0464 with dis1
    $ apause()
    scene 12_0465 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0466 with dis1
    mil "[ss]..Mmhhh.."
    scene 12_0467 with dissolve
    if persistent.MilandVi:
        mc "[whi]Can you do something for me, Sweetie?"
        mil "[whi]I'll do anything for you, Dad."
        scene 12_0468 with dissolve
        mc "[whi]Go back down there and kiss your mom like you just kissed me."
        scene 12_0469 with dissolve
        call AutoA
        $ apause(1)
        scene 12_0470 with dissolve
        mil "[whi][kiss]"
        scene 12_0471 with dissolve
        scene 12_0472 with dis1
        call AutoA (False)
        scene 12_0473 with dis1
        vi "[ss]..Mmhhh.."
        scene 12_0474 with dissolve
        scene 12_0475 with dis1
        mil "[ss]....Mmmmhhh...."
        scene 12_0476 with dis1
        call AutoA
        $ apause()
        scene 12_0477 with dis1
        $ apause()
        scene 12_0478 with dis1
        $ apause()
        scene 12_0479 with dis1
        $ apause()
        scene 12_0480 with dis1
        $ apause()
        scene 12_0481 with dis1
        $ apause()
        scene 12_0482 with dis1
        $ apause()
        scene 12_0483 with dis1
        $ apause()
        call AutoA (False)
        scene 12_0484 with dis1
        mil "[ss]Mmhhh."
        scene 12_0485 with dissolve
        mc "[whi]That's my girls."
        scene 12_0486 with dissolve
        vi "[ss]..Mmhhh.."
        scene 12_0487 with dissolve
        mil "[ss]...Mmmmhhhh..."
        scene 12_0488 with dissolve
        mc "[whi]Lie on the bed, Sweetie."
    else:
        mc "[whi]Lie on the bed, Sweetie."
        mil "[whi]Yes, Daddy."
    scene 12_0489 with fade1
    vi "[whi]You're a lucky man, [persistent.McName]."
    mc "[whi]Yes, I am."
    scene 12_0490 with dissolve
    mc "[whi]Take off your nightie and lie next to her."
    vi "[whi]Why? I'm only here to support her."
    scene 12_0491 with dissolve
    if persistent.Anal:
        mc "[whi]Because, after I've taken her virginity, I'm gonna take yours."
        scene 12_0492 with dissolve
        call AutoA
        $ apause()
        scene 12_0493 with dis1
        $ apause(1)
        call AutoA (False)
        scene 12_0494 with dissolve
        call Emotion (vi, "Gasp", "", True)
        vi "[ss]I'm so damn horny right now that I just might let you."
    else:
        mc "[whi]Because, after I've fucked our daughter, I'm gonna fuck my wife."
    scene 12_0495 with fade
    vi "[whi]She's waiting for you, Baby."
    call AutoA
    scene 12_0496 with dis1
    $ apause()
    scene 12_0497 with dis1
    $ apause()
    scene 12_0498 with dis1
    $ apause()
    scene 12_0499 with dis1
    $ apause()
    call AutoA (False)
    scene 12_0500 with dis1
    vi "[whi]Ready, Sweetie?"
    mil "[whi]Mmh-hmm."
    scene 12_0501 with dissolve
    image MillieR06_09 = Movie(play="images/e12/12_0502.webm", loop=False, keep_last_frame=True)
    show MillieR06_09
    pause 2.0
    mil "[ss]Mmmhh.{w=1}{nw}"
    pause 3.0
    mil "[ss]Ohh..{w=2}{nw}"
    pause 5.0
    mil "[ss]...Aahhhh..."
    scene 12_0503 with dissolve
    image MillieR06_10 = Movie(play="images/e12/12_0504.webm")
    show MillieR06_10
    mil "[ss]..Aaahh..."
    scene 12_0505 with dissolve
    mil "[ss]....Ohhhh..."
    scene 12_0506 with dissolve
    vi "[whi]Well done, Millie!\nThe most painful part is over; relax now, Sweetie."
    scene 12_0507 with dissolve
    image MillieR06_11 = Movie(play="images/e12/12_0508.webm")
    show MillieR06_11
    mil "[ss]..Ahhhhh..."
    scene 12_0509 with dissolve
    mil "[ss]...Mmhh..."
    scene 12_0510 with dissolve
    image MillieR06_12 = Movie(play="images/e12/12_0511.webm")
    show MillieR06_12
    mil "[ss]....Mmmmmhh....."
    mil "[ss]..Ohhh, Daddy..."
    mil "[ss]....I love it....."
    scene 12_0512 with dissolve
    image MillieR06_13 = Movie(play="images/e12/12_0513.webm")
    show MillieR06_13
    vi "[whi]So does he, Sweetie."
    mil "[ss]....Ohhhhhh....."
    scene 12_0514 with dissolve
    image MillieR06_14 = Movie(play="images/e12/12_0515.webm")
    show MillieR06_14
    pause
    if persistent.MilandVi:
        scene 12_0516 with dissolve
        scene 12_0517 with dis1
        scene 12_0518 with dis1
        scene 12_0519 with dis1
        scene 12_0520 with dis1
        image MillieR06_15 = Movie(play="images/e12/12_0521.webm")
        show MillieR06_15
        mil "[ss]....Ohhhhhh....."
    scene 12_0522 with dissolve
    scene 12_0523 with dis1
    scene 12_0524 with dis1
    scene 12_0525 with dis1
    call Loop_FDissolve (4, "e12/12_0526.webp", "e12/12_0527.webp", "e12/12_0528.webp")
    scene 12_0529 with dissolve
    vi "[ss]...Ohhhhh..."
    call Loop_Dissolve (4, True, False, "e12/12_0530.webp", "e12/12_0531.webp")
    scene 12_0530 with dis1
    call Moan (vi)
    if persistent.Anal:
        scene 12_0532 with dis1
        scene 12_0533 with dis1
        scene 12_0534 with dis1
        scene 12_0535 with dissolve
        vi "[ss]..Nnnhhh....Fuck...."
    if persistent.MilandVi:
        scene 12_0536 with dissolve
    else:
        scene 12_0537 with dissolve
    vi "[ss]Why don't we give Millie a little rest, Baby."
    vi "[ss]This is just too damn hot, and I'm about ready to climax."
    mc "[whi]I think she's earned a little hug from her mom."
    scene 12_0538 with fade1
    image MillieR06_16 = Movie(play="images/e12/12_0539.webm")
    show MillieR06_16
    vi "[ss]....Ohhhhhh....."
    scene 12_0540 with dissolve
    vi "[ss]..Ohhh, Baby....Yes....."
    scene 12_0541 with dissolve
    image MillieR06_17 = Movie(play="images/e12/12_0542.webm")
    show MillieR06_17
    vi "[ss]..Ohhh..."
    scene 12_0543 with dissolve
    vi "[ss].....Ohhh, [persistent.McName].....Yes.......Fuck me, Baby......."
    scene 12_0544 with dissolve
    image MillieR06_18 = Movie(play="images/e12/12_0545.webm")
    show MillieR06_18
    call Moan (vi)
    if persistent.MilandVi:
        scene 12_0546 with dissolve
        scene 12_0547 with dis1
        scene 12_0548 with dis1
        vi "[ss]..Mmhh.."
        scene 12_0549 with dis1
        scene 12_0550 with dis1
        vi "[kiss]"
        scene 12_0551 with dis1
        scene 12_0552 with dis1
        mil "[ss]..Mmmhhh.."
        scene 12_0553 with dissolve
        image MillieR06_19 = Movie(play="images/e12/12_0554.webm")
        show MillieR06_19
        vi "[ss]..Mmmhh.."
    scene 12_0555 with dissolve
    image MillieR06_20 = Movie(play="images/e12/12_0556.webm")
    show MillieR06_20
    call Moan (vi, 7)
    if persistent.MilandVi:
        scene 12_0557 with dissolve
        vi "[ss]...Mmmmhhhh..."
    else:
        scene 12_0560 with dissolve
        call Moan (vi)
    call CharCum (("e12/12_0557.webp" if persistent.MilandVi else "e12/12_0560.webp"), "e12/12_0558.webp", vi, "....Ohhhhhh....")
    scene 12_0559 with dissolve
    vi "[ss]...Mmmhhhhhhh...."
    scene 12_0561 with dissolve
    vi "[ss]...That was so amazing.....Mmhh....."
    if persistent.Anal:
        $ Violet.Add("Anal")
        mc "[whi]It's not over yet, Sweetheart."
        scene 12_0562 with dissolve
        vi "[whi]Damn, I was hoping he'd forgotten about that."
        mil "[whi][giggles]"
        scene 12_0563 with dissolve
        image MillieR06_21 = Movie(play="images/e12/12_0564.webm", loop=False, keep_last_frame=True)
        show MillieR06_21
        pause 4.0
        vi "[ss]NNNGGHHH."
        scene 12_0565 with dissolve
        vi "[whi]Fuuuuuck!"
        scene 12_0566 with dissolve
        image MillieR06_22 = Movie(play="images/e12/12_0567.webm")
        show MillieR06_22
        vi "[ss]...Nnnngghhhh..."
        scene 12_0568 with dissolve
        vi "[ss]...Ohhhh..."
        scene 12_0569 with dissolve
        image MillieR06_23 = Movie(play="images/e12/12_0570.webm")
        show MillieR06_23
        pause
        scene 12_0571 with dissolve
        vi "[ss]Fuck, Baby....I can't take it for much longer!...."
        mc "[whi]Okay, Honey."
    scene 12_0572 with dissolve
    mil "[ss]I'm ready again, Daddy."
    scene 12_0573 with fade1
    call Moan (mil)
    scene 12_0574 with dissolve
    image MillieR06_24 = Movie(play="images/e12/12_0575.webm")
    show MillieR06_24
    pause
    scene 12_0576 with dissolve
    image MillieR06_25 = Movie(play="images/e12/12_0577.webm")
    show MillieR06_25
    call Moan (mil)
    scene 12_0578 with dissolve
    mil "[ss]Can we have sex every time you visit, Dad?"
    mc "[ss]Whenever you want, Sweetie."
    scene 12_0579 with dis1
    mil "[ss]..Mmhhh.."
    scene 12_0580 with dissolve
    image MillieR06_26 = Movie(play="images/e12/12_0581.webm")
    show MillieR06_26
    call Moan (mil)
    scene 12_0582 with dissolve
    vi "[ss]You two are so goddamn cute together."
    scene 12_0583 with dissolve
    mil "[ss]..Mmmmmhhh.."
    scene 12_0584 with dissolve
    image MillieR06_27 = Movie(play="images/e12/12_0585.webm")
    show MillieR06_27
    call Moan (mil, 7)
    scene 12_0586 with dissolve
    vi "[ss]That's it, Honey... Give our beautiful little girl a wonderful orgasm."
    vi "[ss]She's wanted her daddy's big, hard dick deep inside her for so long."
    scene 12_0587 with dissolve
    mil "[ss]...OHHHH, DAD...."
    scene 12_0588 with dissolve
    image MillieR06_28 = Movie(play="images/e12/12_0589.webm")
    show MillieR06_28
    call Moan (mil, 10)
    scene 12_0590 with dissolve
    image MillieR06_29 = Movie(play="images/e12/12_0591.webm")
    show MillieR06_29
    call Moan (mil, 10)
    scene 12_0592 with dissolve
    image MillieR06_30 = Movie(play="images/e12/12_0593.webm")
    show MillieR06_30
    mil "[ss]...OHHHHHH...."
    scene 12_0594 with dissolve
    image MillieR06_31 = Movie(play="images/e12/12_0595.webm")
    show MillieR06_31
    call Moan (mil, 10)
    scene 12_0596 with dissolve
    mil "[ss]...OHHHH...."
    scene 12_0597 with dissolve
    image MillieR06_32 = Movie(play="images/e12/12_0598.webm")
    show MillieR06_32
    mil "[ss]...OHHHHHHH....."
    mil "[ss]........YES, DADDY.......YESS........."
    call CharCum ("e12/12_0596.webp", "e12/12_0599.webp", mil, "....Ohhhhhhhhhh....")
    call CharCum ("e12/12_0599.webp", "e12/12_0600.webp", mil, "....Mmmhhhhhhhhh....")
    scene 12_0601 with dissolve
    image MillieR06_33 = Movie(play="images/e12/12_0602.webm")
    show MillieR06_33
    mil "[ss]...Mmhhhhh..."
    vi "[ss]Well done, Sweetie!\nWas it as good as you hoped?"
    call Emotion (mil, "Breathing heavily")
    mil "[ss]Better."
    mil "[ss]... Waaaay better."
    pause
    call CmOpts (["Cum inside Millie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Millie.incCm()
        call CharCum ("e12/12_0601.webp", "e12/12_0605.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0605.webp", "e12/12_0606.webp", mc, "..Nnhhhhh..")
        scene 12_0608 with dissolve
        mil "[ss]Did I do okay, Daddy?"
        scene 12_0609 with dissolve
        mc "[whi]You were perfect, Sweetheart."
        scene 12_0610 with dissolve
        mc "[whi]Absolutely perfect."
        scene 12_0614 with dissolve
    else:
        call CharCum ("e12/12_0601.webp", "e12/12_0603.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0603.webp", "e12/12_0604.webp", mc, "..Nnhhhhh..")
        scene 12_0607 with dissolve
        mil "[ss]Did I do okay, Daddy?"
        scene 12_0611 with dissolve
        mc "[whi]You were perfect, Sweetheart."
        scene 12_0612 with dissolve
        mc "[whi]Absolutely perfect."
        scene 12_0613 with dissolve
    vi "[whi]You were {b}both{/b} perfect."
    scene 12_0615 with fade1
    mc "[whi]..Zzz.."
    $ Violet.Add("R3")
    scene black with Fade(2, 1, 0)
return

label MillieReplay06_02:
    call Unlocker ("MillieReplay06_02")
    $ Millie.incSex()
    scene 12_0616 with fade1
    mct "Glad things are working out with Lucy."
    scene 12_0617 with dissolve
    mil "[whi]Hi, Dad."
    mc "Hey.\nThought you were in bed."
    scene 12_0618 with dissolve
    mil "[whi]I was.\nI've been waiting for you to come home."
    mc "Is everything okay, Sweetie?"
    mil "[whi]Yeah.\nI wanted to tell you something."
    scene 12_0619 with dissolve
    mil "[whi]I'm ready, Daddy."
    scene 12_0620 with dissolve
    mc "Sweetheart, are you {b}sure{/b}?"
    scene 12_0621 with dissolve
    mc "I don't want you to have any regrets."
    mil "I'm sure."
    scene 12_0622 with dissolve
    mc "Millie..."
    mil "I swear, Dad, I've thought about it a lot, and I'm ready to do it."
    scene 12_0623 with dissolve
    mil "So take off your pants and let me put your dick in my mouth."
    mil "Then, I want to feel it inside me."
    scene 12_0624 with fade1
    mil "[whi]Whoa."
    scene 12_0625 with dissolve
    mil "[whi]Is it {b}always{/b} hard??"
    mc "[whi]When you're around, yeah."
    scene 12_0626 with dissolve
    mc "[whi]Oh, okay... straight to it, huh?"
    call AutoA
    scene 12_0627 with dissolve
    $ apause(1)
    scene 12_0628 with dis1
    $ apause()
    scene 12_0629 with dis1
    call AutoA (False)
    mil "[ss]Mmhh."
    call AutoA
    scene 12_0630 with dis1
    $ apause()
    scene 12_0631 with dis1
    $ apause()
    scene 12_0632 with dis1
    $ apause()
    scene 12_0633 with dis1
    $ apause()
    scene 12_0634 with dis1
    call AutoA (False)
    image MillieR06_34 = Movie(play="images/e12/12_0635.webm")
    show MillieR06_34
    mil "[ss]Mmmhh."
    scene 12_0636 with dissolve
    mc "[whi]Damn, Millie. I love watching you do that."
    scene 12_0637 with dis1
    mc "[whi]Love your sexy little ass, too."
    scene 12_0638 with dissolve
    image MillieR06_35 = Movie(play="images/e12/12_0639.webm")
    show MillieR06_35
    mil "[ss]...Mmmhhhh..."
    scene 12_0640 with dissolve
    scene 12_0641 with dis1
    scene 12_0642 with dis1
    scene 12_0643 with dis1
    scene 12_0644 with dis1
    scene 12_0645 with dis1
    scene 12_0646 with dis1
    scene 12_0647 with dis1
    mil "[ss]...Mmmmmhhhhhhh..."
    scene 12_0648 with dissolve
    image MillieR06_36 = Movie(play="images/e12/12_0649.webm")
    show MillieR06_36
    call Moan (mil, 4)
    scene 12_0650 with dissolve
    mil "[ss]...Ohhhh.....I love it when you touch me, Dad...."
    scene 12_0651 with dissolve
    call AutoA
    $ apause()
    scene 12_0652 with dis1
    scene 12_0653 with dis1
    scene 12_0654 with dis1
    call AutoA (False)
    call Moan (mil)
    scene 12_0655 with dissolve
    mil "[ss]...Ohhhh..."
    scene 12_0656 with dissolve
    call Moan (mil)
    scene 12_0657 with dissolve
    mil "[whi]Ohh, Dad, I'm so excited... and a little nervous.\nCan we just do it, right now?"
    mc "[whi]Whatever you want, Sweetheart."
    scene 12_0658 with fade1
    mc "[whi]Ready, Sweetie?"
    mil "[whi]Mmh-hmm."
    scene 12_0659 with dissolve
    mc "[whi]If you want me to stop at any point, just say the word, okay?"
    mil "[whi]I'm not going to change my mind, so quit stalling."
    scene 12_0660 with dissolve
    mil "[ss]I want us to fuck."
    mil "[ss]So put it in and fuck me, Daddy."
    scene 12_0661 with dissolve
    image MillieR06_37 = Movie(play="images/e12/12_0662.webm", loop=False, keep_last_frame=True)
    show MillieR06_37
    pause 2.0
    mil "[ss]Mmmhh.{w=1}{nw}"
    pause 3.0
    mil "[ss]Ohh..{w=2}{nw}"
    pause 5.0
    mil "[ss]...Aahhhh..."
    scene 12_0663 with dissolve
    image MillieR06_38 = Movie(play="images/e12/12_0664.webm")
    show MillieR06_38
    mil "[ss]..Aaahh..."
    scene 12_0665 with dissolve
    mil "[ss]....Ahhhhhhhhh..."
    scene 12_0666 with dissolve
    mil "[ss]...Ohhhhh..... It hurts, Daddy.... But it's a nice hurt...."
    scene 12_0667 with dissolve
    image MillieR06_39 = Movie(play="images/e12/12_0668.webm")
    show MillieR06_39
    mil "[ss]..Ahhhhh..."
    scene 12_0669 with dissolve
    mil "[ss]...Mmhh..."
    scene 12_0670 with dissolve
    image MillieR06_40 = Movie(play="images/e12/12_0671.webm")
    show MillieR06_40
    mil "[ss]....Mmmmmhh....."
    mil "[ss]..Ohhh, Daddy..."
    mil "[ss]....I love it....."
    scene 12_0672 with dissolve
    call Moan (mil, 4)
    scene 12_0673 with dissolve
    image MillieR06_41 = Movie(play="images/e12/12_0674.webm")
    show MillieR06_41
    mil "[ss]....Ohhhhhh....."
    scene 12_0675 with dissolve
    image MillieR06_42 = Movie(play="images/e12/12_0676.webm")
    show MillieR06_42
    pause    
    scene 12_0677 with dissolve
    image MillieR06_43 = Movie(play="images/e12/12_0678.webm")
    show MillieR06_43
    mil "[ss]....Ohhh........It's so good......"
    scene 12_0679 with dissolve
    image MillieR06_44 = Movie(play="images/e12/12_0680.webm")
    show MillieR06_44
    call Moan (mil)
    scene 12_0681 with dissolve
    mil "[ss]I want us to fuck every time you visit, Daddy."
    mc "[ss]Whatever you want, Sweetie."
    scene 12_0682 with dis1
    mil "[ss]..Mmhhh.."
    scene 12_0683 with dissolve
    image MillieR06_45 = Movie(play="images/e12/12_0684.webm")
    show MillieR06_45
    call Moan (mil)
    scene 12_0685 with dissolve
    mil "[ss]..Mmmmmhhh.."
    scene 12_0686 with dissolve
    image MillieR06_46 = Movie(play="images/e12/12_0687.webm")
    show MillieR06_46
    call Moan (mil, 7)
    scene 12_0688 with dissolve
    mil "[ss]...OHHHH, DAD...."
    scene 12_0689 with dissolve
    image MillieR06_47 = Movie(play="images/e12/12_0690.webm")
    show MillieR06_47
    call Moan (mil, 10)
    scene 12_0691 with dissolve
    image MillieR06_48 = Movie(play="images/e12/12_0692.webm")
    show MillieR06_48
    call Moan (mil, 10)
    scene 12_0693 with dissolve
    image MillieR06_49 = Movie(play="images/e12/12_0694.webm")
    show MillieR06_49
    call Moan (mil, 10)
    scene 12_0695 with dissolve
    mil "[ss]...OHHHH...."
    scene 12_0696 with dissolve
    image MillieR06_50 = Movie(play="images/e12/12_0697.webm")
    show MillieR06_50
    mil "[ss]...OHHHHHHH....."
    scene 12_0698 with dissolve
    image MillieR06_51 = Movie(play="images/e12/12_0699.webm")
    show MillieR06_51
    mil "[ss]........YES, DADDY........"
    mil "[ss]......YESSSS........."
    scene 12_0700 with dissolve
    image MillieR06_52 = Movie(play="images/e12/12_0701.webm")
    show MillieR06_52
    call Moan (mil, 10)
    scene 12_0702 with dissolve
    mil "[ss]...Ohhh, Dad..."
    call CharCum ("e12/12_0702.webp", "e12/12_0703.webp", mil, "....Ohhhhhhhhhh....")
    call CharCum ("e12/12_0703.webp", "e12/12_0704.webp", mil, "....Mmmhhhhhhhhh....")
    scene 12_0705 with dissolve
    image MillieR06_53 = Movie(play="images/e12/12_0706.webm")
    show MillieR06_53
    call Emotion (mil, "Breathing heavily")
    mil "[ss]...Mmhhhhh..."
    pause
    call CmOpts (["Cum inside Millie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Millie.incCm()
        call CharCum ("e12/12_0705.webp", "e12/12_0709.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0709.webp", "e12/12_0710.webp", mc, "..Nnhhhhh..")
        scene 12_0712 with dissolve
        mil "[ss]Did I do okay, Daddy?"
        scene 12_0715 with dissolve
        mc "[whi]You were perfect, Sweetheart."
        scene 12_0716 with dissolve
        mc "[whi]Absolutely perfect."
    else:
        call CharCum ("e12/12_0705.webp", "e12/12_0707.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0707.webp", "e12/12_0708.webp", mc, "..Nnhhhhh..")
        scene 12_0711 with dissolve
        mil "[ss]Did I do okay, Daddy?"
        scene 12_0713 with dissolve
        mc "[whi]You were perfect, Sweetheart."
        scene 12_0714 with dissolve
        mc "[whi]Absolutely perfect."
    scene 12_0717 with dissolve
    mil "[ss]So were you, Dad."
    scene 12_0718 with fade1
    mc "[whi]..Zzz.."
    $ Violet.Add("R1")
    scene black with Fade(2, 1, 0)
return

label MillieReplay07:
    call Unlocker ("MillieReplay07")
    if _in_replay:
        scene 15_0485 with Fade(0,0,1)
        mil "Oh my god!"
        mil "Okay, I didn't know it was gonna be {b}this{/b} scary!"
        call laugh (mc)
    else:
        $ persistent.MillieRP07Dat=Violet.isSexual()
        $ Violet.Add("SawYou")
    $ Millie.incSex()
    scene 15_0492 with dissolve
    mc "Oh no you don't!\nThat's cheating! You gotta watch it!"
    mil "[lol] I am!"
    scene 15_0493 with dissolve
    mc "Good!\nSo put your hands down and stop hiding behind them!"
    scene 15_0494 with dissolve
    mil "What you talking about?\nMy hands have been down the whole time!"
    call laugh (mc)
    scene 15_0495 with dissolve
    mct "Should concentrate on the movie, but... damn, it's tough."
    scene 15_0496 with dis1
    scene 15_0497 with dis1
    scene 15_0498 with dis1
    mc "[whi]Sorry.\nCouldn't resist wanting to see a little more of my hot daughter."
    mil "[whi]Okay."
    scene 15_0499 with dissolve
    pause
    scene 15_0500 with dis1
    mil "That's touching, not looking."
    mc "Am I not allowed to touch?"
    scene 15_0501 with dissolve
    mil "You're allowed to touch me anywhere, anytime, Daddy."
    scene 15_0502 with dis1
    mil "[ss]Mmhh."
    scene 15_0503 with dissolve
    mil "[ss]...Mmmmhh..."
    scene 15_0504 with dis1
    $ apause()
    scene 15_0505 with dis1
    $ apause()
    scene 15_0506 with dis1
    image MillieR07_01 = Movie(play="images/e15/15_0507.webm")
    show MillieR07_01
    mil "[ss]Mmmhh."
    scene 15_0508 with dissolve
    image MillieR07_02 = Movie(play="images/e15/15_0509.webm")
    show MillieR07_02
    mil "[ss]Mmmhh."
    scene 15_0510 with dissolve
    mil "[whi]Can I suck it again, Daddy?"
    mc "[whi]Sweetheart, you can suck it anytime, anywhere."
    scene 15_0511 with fadehold
    pause 0.5
    image MillieR07_03 = Movie(play="images/e15/15_0514.webm", loop=False, keep_last_frame=True)
    image MillieR07_04 = Movie(play="images/e15/15_0515.webm")
    scene 15_0512 with dis1
    mil "[whi][kiss]"
    scene 15_0511 with dis1
    scene 15_0512 with dis1
    mil "[whi][kiss]"
    scene 15_0513 with dissolve
    show MillieR07_03
    pause 5.3
    show MillieR07_04
    mil "[ss]Mmmhh."
    scene 15_0516 with dissolve
    image MillieR07_05 = Movie(play="images/e15/15_0517.webm")
    show MillieR07_05
    mil "[ss]..Mmhhhh.."
    scene 15_0518 with dissolve
    image MillieR07_06 = Movie(play="images/e15/15_0519.webm")
    show MillieR07_06
    mc "[whi]Damn, Sweetie. You're getting good at doing that."
    mil "[ss]..Mmmmhh.."
    scene 15_0520 with dis1
    scene 15_0521 with dis1
    scene 15_0522 with dis1
    scene 15_0523 with dis1
    image MillieR07_07 = Movie(play="images/e15/15_0524.webm")
    show MillieR07_07
    mil "[ss]..Mmmmhh.."
    scene 15_0525 with dissolve
    mc "[whi]..Fuuck.."
    scene 15_0526 with dissolve
    image MillieR07_08 = Movie(play="images/e15/15_0527.webm")
    show MillieR07_08
    mil "[ss]..Mmhh.."
    scene 15_0528 with dissolve
    image MillieR07_09 = Movie(play="images/e15/15_0529.webm")
    show MillieR07_09
    mil "[ss]..Mmmmhh.."
    scene 15_0530 with dissolve
    scene 15_0531 with dis1
    mc "[whi]Stand up, Sweetie."
    $ aP()
    scene 15_0532 with dis1
    $ apause(0, True)
    scene 15_0533 with dis1
    mc "[whi]Damn, you're beautiful."
    scene 15_0534 with dis1
    scene 15_0535 with dis1
    scene 15_0536 with dis1
    pause 0.5
    scene 15_0537 with dissolve
    mil "[whi]You didn't get your taste today yet, Daddy."
    scene 15_0538 with dissolve
    mc "[whi]You're right! We should fix that right now, huh?"
    mil "[whi]Mhh-mhh."
    scene 15_0539 with dis1
    mil "[ss]Mhh."
    scene 15_0540 with dissolve
    pause
    scene 15_0541 with dissolve
    mil "[ss]..Ohhh.."
    if persistent.MillieRP07Dat:
        scene 15_0543 with dissolve
        call Moan (mil, 4)
        scene 15_0544 with dissolve
        mil "[ss]...Ohhh, Dad..."
        scene 15_0547 with dis1
        scene 15_0548 with dis1
        pause
        $ aP()
        scene 15_0549 with dissolve
        $ apause()
        scene 15_0550 with dissolve
        vi "[whi][kiss]"
        scene 15_0551 with dissolve
        $ apause()
        scene 15_0549 with dissolve
        $ apause()
        scene 15_0552 with dissolve
        $ apause()
        scene 15_0553 with dissolve
        $ apause(0, True)
        scene 15_0554 with dis1
    else:
        scene 15_0542 with dissolve
        call Moan (mil, 4)
        scene 15_0545 with dissolve
        mil "[ss]...Ohhh, Dad..."
        scene 15_0546 with dissolve
        call Moan (mil)
        scene 15_0554 with dissolve
    mil "[ss]...God, Daddy....Yes...."
    scene 15_0555 with dis1
    image MillieR07_10 = Movie(play="images/e15/15_0556.webm")
    show MillieR07_10
    call Moan (mil)
    scene 15_0557 with dis1
    scene 15_0558 with dis1
    scene 15_0559 with dis1
    mil "[ss]..Ohhh.."
    scene 15_0560 with dissolve
    call Moan (mil)
    scene 15_0561 with dissolve
    image MillieR07_11 = Movie(play="images/e15/15_0562.webm")
    show MillieR07_11
    pause
    scene 15_0563 with dissolve
    call Moan (mil)
    scene 15_0564 with dissolve
    mil "[ss]Fuck me, Dad."
    scene 15_0565 with dissolve
    pause 0.5
    scene 15_0566 with dis1
    scene 15_0567 with dis1
    scene 15_0568 with dis1
    scene 15_0569 with dis1
    scene 15_0570 with dis1
    scene 15_0571 with dis1
    scene 15_0572 with dis1
    mc "[whi]Take your time, Sweetheart. Nice and slow."
    scene 15_0573 with dissolve
    image MillieR07_12 = Movie(play="images/e15/15_0574.webm", loop=False, keep_last_frame=True)
    show MillieR07_12
    pause 5.0
    mil "[ss]..Ohhhh..{w=2}{nw}"
    pause 1.0
    mil "[ss]..Aaahhhh..."
    scene 15_0575 with dissolve
    mc "[whi]That's it, gently does it."
    scene 15_0576 with dissolve
    image MillieR07_13 = Movie(play="images/e15/15_0577.webm")
    show MillieR07_13
    mil "[ss]...Ohhh..."
    scene 15_0578 with dissolve
    image MillieR07_14 = Movie(play="images/e15/15_0579.webm")
    show MillieR07_14
    pause
    scene 15_0580 with dissolve
    mil "[ss]God, I love the feeling of you inside me, Daddy."
    scene 15_0581 with dissolve
    mil "[ss]Mmmhh."
    scene 15_0582 with dissolve
    image MillieR07_15 = Movie(play="images/e15/15_0583.webm")
    show MillieR07_15
    mil "[ss]...Mmmhhhh..."
    scene 15_0584 with dissolve
    image MillieR07_16 = Movie(play="images/e15/15_0585.webm")
    show MillieR07_16
    pause
    scene 15_0586 with dissolve
    mil "[ss]Mmmhh."
    scene 15_0587 with dissolve
    image MillieR07_17 = Movie(play="images/e15/15_0588.webm")
    show MillieR07_17
    pause
    scene 15_0589 with dissolve
    mil "[ss]...Mmmhhhh..."
    scene 15_0590 with dissolve
    image MillieR07_18 = Movie(play="images/e15/15_0591.webm")
    show MillieR07_18
    call Moan (mil)
    scene 15_0592 with dissolve
    mil "[ss]..Ohhh.."
    scene 15_0593 with dissolve
    image MillieR07_19 = Movie(play="images/e15/15_0594.webm")
    show MillieR07_19
    call Moan (mil)
    scene 15_0595 with dissolve
    mil "[ss]....Ohhh, Daddy....."
    scene 15_0596 with dissolve
    pause
    scene 15_0597 with dis1
    pause
    scene 15_0598 with dissolve
    mil "[ss]....Fuck, Dad.... You make me so excited, I'm soaking......"
    scene 15_0599 with dissolve
    call Moan (mil)
    scene 15_0600 with dissolve
    image MillieR07_20 = Movie(play="images/e15/15_0601.webm")
    show MillieR07_20
    mil "[ss]...OHHH..."
    scene 15_0602 with dissolve
    call Moan (mil)
    scene 15_0603 with dissolve
    mil "[ss]...OHHHHHH....."
    scene 15_0604 with dissolve
    image MillieR07_21 = Movie(play="images/e15/15_0605.webm")
    show MillieR07_21
    mil "[ss]......OHHH, DAD........YES....."
    scene 15_0606 with dis1
    scene 15_0607 with dis1
    scene 15_0608 with dis1
    image MillieR07_22 = Movie(play="images/e15/15_0609.webm")
    show MillieR07_22
    call Moan (mil)
    scene 15_0610 with dissolve
    image MillieR07_23 = Movie(play="images/e15/15_0611.webm")
    show MillieR07_23
    mil "[ss]...OHHHHHH....."
    mil "[ss]...God, Dad....I love fucking you...."
    scene 15_0612 with dissolve
    image MillieR07_24 = Movie(play="images/e15/15_0613.webm")
    show MillieR07_24
    call Moan (mil)
    scene 15_0614 with dissolve
    image MillieR07_25 = Movie(play="images/e15/15_0615.webm")
    show MillieR07_25
    mil "[ss]......OHHH.......YES....."
    call Moan (mil, 7)
    mil "[ss].........OHH, DAD.........YES....."
    scene 15_0616 with dissolve
    image MillieR07_26 = Movie(play="images/e15/15_0617.webm")
    show MillieR07_26
    mil "[ss].........OHH, DADDY...."
    call Moan (mil, 7)
    mil "[ss]....YOU'RE GONNA MAKE ME CUM SO HARD......."
    mil "[ss]...OHHH.......YES....."
    scene 15_0618 with dissolve
    image MillieR07_27 = Movie(play="images/e15/15_0619.webm")
    show MillieR07_27
    mil "[ss].........OHHHHH..."
    mil "[ss].....MAKE ME CUM, DADDY...."
    mil "[ss].....FUCK...."
    mil "[ss].......DAD..........OHHH GOD..........YES.........."
    mil "[ss]...OHHHHH......"
    call CharCum ("e15/15_0620.webp", "e15/15_0621.webp", mil, "....YESSSSS...OHHHHHHH....")
    call CharCum ("e15/15_0621.webp", "e15/15_0622.webp", mil, "...Ohhhhhhhhhhh....")
    scene 15_0623 with dissolve
    image MillieR07_28 = Movie(play="images/e15/15_0624.webm")
    show MillieR07_28
    mil "[ss]...Mmmmhhhh..."
    mil "[ss]...God....That was amazing....."
    mil "[ss]..Mmhhhh.."
    scene 15_0625 with dissolve
    mil "[ss]Would you like to cum in my mouth again, Daddy?"
    call CmOpts (["Cum inside Millie", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        mc "[whi]No, Sweetie.\nDaddy's cum belongs deep inside you."
        mil "[ss]I couldn't agree more."
        scene 15_0626 with dissolve
        mil "[ss]Mmhhhh."
        scene 15_0627 with dissolve
        image MillieR07_29 = Movie(play="images/e15/15_0628.webm")
        show MillieR07_29
        mil "[ss]..Mmhhh.."
        pause
        $ Millie.incCm()
        call CharCum ("e15/15_0627.webp", "e15/15_0629.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0629.webp", "e15/15_0630.webp", mc, "..Nnhhhhh..")
        scene 15_0631 with dissolve
        mil "[ss]..Mmhhhh.."
        scene 15_0632 with dissolve
        mil "[ss]Wow, that was even better than the first time, Dad."
        scene 15_0633 with dissolve
        mil "[ss]I wish I could keep you inside me forever!"
        scene 15_0631 with dissolve
        mil "[ss]Mmhhhh."
        scene 15_0634 with dissolve
        pause
    else:
        scene 15_0635 with fadehold
        image MillieR07_30 = Movie(play="images/e15/15_0636.webm")
        show MillieR07_30
        mc "[whi]...Fuuck..."
        mil "[ss]..Mmhhh.."
        scene 15_0637 with dissolve
        image MillieR07_31 = Movie(play="images/e15/15_0638.webm")
        show MillieR07_31
        mil "[ss]Mmmmhhh."
        call CharCum ("e15/15_0637.webp", "e15/15_0639.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0639.webp", "e15/15_0640.webp", mc, "..Nnhhhhh..")
        scene 15_0641 with dissolve
        pause 0.5
        scene 15_0642 with dissolve
        call Gulp (mil)
        scene 15_0643 with dissolve
        mil "[ss]Daddy cum is so damn delicious!"
    scene 15_0644 with fade1
    mil "[ss]Mmhhhh."
    scene 15_0645 with dissolve
    mil "[ss]..Mmhh.."
    scene 15_0646 with dissolve
    mil "[whi]Wanna get dressed and watch the rest of the movie?"
    mc "[whi]Sure."
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
