label MillieReplay08:
    call Unlocker ("MillieReplay08")
    if _in_replay:
        scene 18_0344 with Fade(0,0,1)
    else:
        $ Millie.incSex()
        $ Cara.incSex()
        scene 18_0344 with dissolve
    $ aPs(0, True)
    scene 18_0345 with dis1
    $ aPs()
    scene 18_0346 with dis1
    $ aPs()
    scene 18_0347 with dis1
    $ aPs()
    scene 18_0348 with dis1
    $ aPs()
    scene 18_0349 with dis1
    $ aPs()
    scene 18_0350 with dis1
    $ aPs(0, False, True)
    scene 18_0351 with dissolve
    car "[whi]..Zzz.."
    scene 18_0352 with dis1
    scene 18_0353 with dis1
    scene 18_0354 with dis1
    call EmotionSml (car, "Groan")
    mc "[whi]Mornin' Pipsqueak."
    scene 18_0355 with dis1
    car "[whi]Hi Daddy."
    scene 18_0356 with dis1
    mc "[whi]What you been getting up to in here with your sister?"
    car "[whi]Mmhh."
    car "[whi]Just sleeping."
    scene 18_0357 with dissolve
    car "[whi]Mom slept in Millie's room, and we stayed here 'cause the bed's bigger."
    scene 18_0358 with dis1
    call Loop_Dissolve (4, True, False, "e18/18_0359.webp", "e18/18_0360.webp")
    scene 18_0361 with dissolve
    car "[whi]Mmhhh."
    scene 18_0362 with dis1
    mc "[whi]You gonna wake up for me, Sweetie?"
    car "[whi]Mh-mhh."
    scene 18_0363 with dis1
    $ aPs(0, True)
    scene 18_0364 with dis1
    $ aPs()
    scene 18_0365 with dis1
    $ aPs(0, False, True)
    scene 18_0366 with dis1
    car "[whi]Mmmmhh."
    scene 18_0367 with dissolve
    $ aPs(0, True)
    scene 18_0368 with dis1
    $ aPs()
    scene 18_0369 with dis1
    $ aPs()
    scene 18_0370 with dis1
    $ aPs()
    scene 18_0371 with dis1
    $ aPs()
    scene 18_0372 with dis1
    $ aPs()
    scene 18_0373 with dis1
    $ aPs(0, False, True)
    scene 18_0374 with dis1
    image MillieR08_01 = Movie(play="images/e18/18_0375.webm")
    show MillieR08_01
    car "[ss]...Mmhhhhh..."
    scene 18_0376 with dissolve
    image MillieR08_02 = Movie(play="images/e18/18_0377.webm")
    show MillieR08_02
    car "[ss]Mmhhh."
    scene 18_0378 with dis1
    scene 18_0379 with dis1
    scene 18_0380 with dis1
    scene 18_0381 with dis1
    scene 18_0382 with dis1
    scene 18_0383 with dis1
    scene 18_0384 with dis1
    scene 18_0385 with dis1
    pause 0.5
    scene 18_0386 with dissolve
    mil "[whi]..Zzzzz.."
    scene 18_0387 with dis1
    scene 18_0388 with dis1
    mil "[whi]Good morning Daddy."
    mc "[whi]Morning, Beautiful."
    scene 18_0389 with dis1
    mil "[ss]Mmmhh."
    scene 18_0390 with dissolve
    car "[whi]When we all live together, you should wake us up like this {i}every{/i} morning."
    scene 18_0391 with dissolve
    mil "[whi]God, I would {b}love{/b} that!"
    scene 18_0392 with dis1
    scene 18_0393 with dis1
    scene 18_0394 with dis1
    scene 18_0395 with dis1
    pause 0.5
    scene 18_0396 with dis1
    scene 18_0397 with dis1
    scene 18_0398 with dis1
    scene 18_0399 with dis1
    scene 18_0400 with dis1
    scene 18_0401 with dis1
    pause 0.5
    scene 18_0402 with dissolve
    mc "Perfect."
    scene 18_0403 with dis1
    scene 18_0404 with dis1
    pause 0.5
    scene 18_0405 with dissolve
    pause 0.5
    scene 18_0406 with dissolve
    mil "[ss]Mmmhh."
    scene 18_0407 with dis1
    mil "[ss]..Mmhh.."
    scene 18_0408 with dissolve
    image MillieR08_03 = Movie(play="images/e18/18_0409.webm")
    show MillieR08_03
    mil "[ss]Mmmhh."
    scene 18_0410 with dissolve
    call Moan (mil)
    scene 18_0411 with dissolve
    mil "[ss]...Ohhhh..."
    car "[whi]I thought my whole body was gonna explode the first time Dad did that to me!"
    scene 18_0412 with dissolve
    mil "[whi]God, I'll {b}never{/b} forget that moment he licked it for the first time."
    scene 18_0413 with dis1
    call Moan (mil)
    scene 18_0414 with dissolve
    pause
    scene 18_0415 with dissolve
    mil "[ss]...Ohhhh..."
    scene 18_0416 with dissolve
    call Moan (mil)
    scene 18_0417 with dis1
    scene 18_0418 with dis1
    scene 18_0419 with dis1
    scene 18_0420 with dis1
    car "[ss]Ohhhh..."
    scene 18_0421 with dissolve
    car "[ss]Mmmhh."
    scene 18_0422 with dissolve
    image MillieR08_04 = Movie(play="images/e18/18_0423.webm")
    show MillieR08_04
    call Moan (car)
    scene 18_0424 with dissolve
    car "[ss]Ohhhh..."
    scene 18_0425 with dissolve
    call Moan (car)
    scene 18_0426 with dis1
    scene 18_0427 with dis1
    image MillieR08_05 = Movie(play="images/e18/18_0428.webm")
    show MillieR08_05
    mil "[ss]...Ohhhh..."
    scene 18_0429 with dissolve
    call Moan (car)
    scene 18_0430 with dissolve
    call Moan (mil)
    scene 18_0431 with dissolve
    car "[whi]Daddy, come and lie down with us."
    scene 18_0432 with dissolve
    scene 18_0433 with dis1
    scene 18_0434 with dis1
    scene 18_0435 with dissolve
    pause 0.5
    scene 18_0436 with dis1
    car "[ss]Mmmhh."
    scene 18_0437 with dissolve
    car "[ss]..Mmhh.."
    scene 18_0438 with dis1
    scene 18_0439 with dis1
    mil "[ss]Mmhhh."
    scene 18_0440 with dis1
    mc "You know what I'd like to see right now?"
    mil "Your daughters giving you a blowjob?"
    if not _in_replay and persistent.Lez and miAndCa==None:
        call Encourage ("Millie", "Cara")
        $ miAndCa=_return
        $ persistent.MilandCar=miAndCa
    $ Lez=False
    if persistent.Lez and persistent.MilandCar:
        $ Lez=True
    if Lez:
        $ Cara.Add("A01")
        $ Millie.Add("A01")
        mc "Well, yeah..."
        mc "But first, I'd love to see you eat out your sister."
        scene 18_0441 with dissolve
        car "Dad!"
        mc "You not gonna let your sister lick your pussy for Daddy, Pipsqueak?"
        scene 18_0442 with dissolve
        car "You can't just ask someone straight like that!\nWhat if she doesn't want to?!"
        mc "Hmm, you didn't say no."
        scene 18_0443 with dissolve
        mil "I'll do {b}anything{/b} for Dad, Sis!"
        car "Even... {i}that{/i}??"
        mil "Yeah."
        scene 18_0444 with dissolve
        mc "Okay, if you're not comfortable, I won't push it."
        mc "But how about just a little kiss?"
        mc "You ever thought about kissing another girl, Pipsqueak?"
        scene 18_0445 with dissolve
        car "Actually, I already have!"
        scene 18_0446 with dissolve
        car "My friend Nicole. It was ages ago when we were still at school."
        car "Only once. We wanted to see what it was like to kiss someone."
        mil "Me and Hannah did the same!"
        scene 18_0447 with dissolve
        car "I guess since we've both done it before... It's not a big deal then, huh?"
        mil "No, not really."
        car "... And I'd do anything for Daddy, too."
        scene 18_0448 with dis1
        car "[kiss]"
        scene 18_0449 with dis1
        mil "[ss]Mmhh."
        scene 18_0450 with dissolve
        car "[ss]..Mmmhh.."
        scene 18_0451 with dis1
        pause
        scene 18_0452 with dissolve
        pause 0.5
        scene 18_0453 with dis1
        car "[ss]Mmhhhh."
        scene 18_0454 with dissolve
        call Moan (car)
        scene 18_0455 with dissolve
        pause 0.5
        scene 18_0456 with dis1
        car "[ss]..Mmhhhh.."
        scene 18_0457 with dis1
        mil "[kiss]"
        scene 18_0458 with dis1
        mil "[kiss]"
        scene 18_0459 with dis1
        call Moan (car)
        scene 18_0460 with dissolve
        pause
        scene 18_0461 with dis1
        mil "[ss]Mmhh."
        scene 18_0462 with dissolve
        car "[ss]..Ohhhh.."
        scene 18_0463 with dis1
        $ aPs(0, True)
        scene 18_0464 with dis1
        $ aPs()
        scene 18_0465 with dis1
        $ aPs()
        scene 18_0466 with dis1
        $ aPs(0, False, True)
        scene 18_0467 with dissolve
        image MillieR08_06 = Movie(play="images/e18/18_0468.webm")
        show MillieR08_06
        call Moan (car)
        scene 18_0469 with dis1
        mil "[kiss]"
        scene 18_0470 with dis1
        mil "[kiss]"
        scene 18_0471 with dis1
        mil "[kiss]"
        scene 18_0472 with dis1
        mil "[kiss]"
        car "[ss]..Ohhhh.."
        image MillieR08_08 = Movie(play="images/e18/18_0475.webm")
        scene 18_0473 with dis1
        mil "{size=*.8}{font=Vanilla.ttf}*{i}Kiss{/i}*{/font}{/size}"
        image MillieR08_07 = Movie(play="images/e18/18_0474.webm", loop=False, keep_last_frame=True)
        show MillieR08_07
        pause 2.0
        show MillieR08_08
        call Moan (car)
        scene 18_0476 with dissolve
        car "[ss]..Ohhhh.."
        scene 18_0477 with dissolve
        mc "That's my girls."
        scene 18_0478 with dis1
        scene 18_0479 with dis1
        image MillieR08_10 = Movie(play="images/e18/18_0482.webm")
        pause
        scene 18_0480 with dissolve
        image MillieR08_09 = Movie(play="images/e18/18_0481.webm", loop=False, keep_last_frame=True)
        show MillieR08_09
        pause 6.2
        show MillieR08_10
        pause
        scene 18_0483 with dissolve
        mil "[ss]..Ohhhh.."
        scene 18_0484 with dis1
        mil "[ss]Mmhhh."
        scene 18_0485 with dissolve
        image MillieR08_11 = Movie(play="images/e18/18_0486.webm")
        show MillieR08_11
        call Moan (car)
        scene 18_0487 with dissolve
        mc "[whi]Damn, I love how wet you get, Milz."
        scene 18_0488 with dis1
        scene 18_0489 with dis1
        scene 18_0490 with dis1
        mc "[whi]Hey, Pipsqueak."
        scene 18_0491 with dissolve
        mc "[whi]You gonna have a little taste of your sister for me?\nShe's all over my dick."
        scene 18_0492 with dis1
        pause 0.5
        scene 18_0493 with dis1
        pause 0.5
        image MillieR08_13 = Movie(play="images/e18/18_0496.webm")
        scene 18_0494 with dissolve
        mc "[whi]Good girl."
        image MillieR08_12 = Movie(play="images/e18/18_0495.webm", loop=False, keep_last_frame=True)
        show MillieR08_12
        pause 1.35
        show MillieR08_13
        car "[ss]..Mmmmhh.."
        mc "[whi]She taste good?"
        car "[whi]Mh-mhh."
        car "[ss]...Mmhhhhh..."
        scene 18_0497 with dissolve
        pause
        scene 18_0498 with dissolve
        mil "I wanna suck it, too!"
    else:
        $ Cara.Add("A00")
        $ Millie.Add("A00")
        mc "Yep!"
    scene 18_0499 with fade1
    pause
    image MillieR08_15 = Movie(play="images/e18/18_0502.webm")
    scene 18_0500 with dissolve
    pause
    image MillieR08_14 = Movie(play="images/e18/18_0501.webm", loop=False, keep_last_frame=True)
    show MillieR08_14
    pause 17.0
    show MillieR08_15
    mil "[ss]Mhhhh."
    scene 18_0503 with dissolve
    mil "[ss]..Mmmhhh.."
    scene 18_0504 with dissolve
    mc "[whi]...Fuuuck..."
    scene 18_0505 with dissolve
    image MillieR08_16 = Movie(play="images/e18/18_0506.webm")
    show MillieR08_16
    pause
    scene 18_0507 with dissolve
    car "[ss]Mhhhh."
    scene 18_0508 with dis1
    scene 18_0509 with dis1
    scene 18_0510 with dis1
    scene 18_0511 with dis1
    scene 18_0512 with dis1
    mil "[ss]..Ohhhh.."
    scene 18_0513 with dis1
    scene 18_0514 with dis1
    scene 18_0515 with dis1
    scene 18_0516 with dis1
    call Moan (mil)
    scene 18_0517 with dissolve
    image MillieR08_17 = Movie(play="images/e18/18_0518.webm", loop=False, keep_last_frame=True)
    show MillieR08_17
    pause 1.5
    car "[ss]Mmmhh{w=2}{nw}"
    pause 2.0
    car "[ss]..Ohhhh.."
    scene 18_0519 with dissolve
    image MillieR08_18 = Movie(play="images/e18/18_0520.webm")
    show MillieR08_18
    car "[ss]..Ohhhh.."
    scene 18_0521 with dissolve
    image MillieR08_19 = Movie(play="images/e18/18_0522.webm")
    show MillieR08_19
    call Moan (car)
    scene 18_0523 with dissolve
    car "[ss]...Ohhh..."
    scene 18_0524 with dissolve
    pause
    scene 18_0525 with dissolve
    mil "[ss]Ohhhhh."
    scene 18_0526 with dissolve
    image MillieR08_20 = Movie(play="images/e18/18_0527.webm")
    show MillieR08_20
    call Moan (car)
    scene 18_0528 with dissolve
    pause 0.5
    scene 18_0529 with dis1
    scene 18_0530 with dis1
    scene 18_0531 with dis1
    scene 18_0532 with dis1
    scene 18_0533 with dis1
    scene 18_0534 with dis1
    call Moan (car)
    scene 18_0535 with dissolve
    pause 0.5
    scene 18_0536 with dis1
    scene 18_0537 with dis1
    mil "[ss]Mmmhh."
    scene 18_0538 with dissolve
    image MillieR08_21 = Movie(play="images/e18/18_039.webm")
    show MillieR08_21
    call Moan (car)
    scene 18_0540 with dissolve
    pause
    scene 18_0541 with dissolve
    image MillieR08_22 = Movie(play="images/e18/18_0542.webm")
    show MillieR08_22
    car "[ss]..Ohhhhh.."
    scene 18_0543 with dissolve
    car "[whi]Sorry Milz, I didn't mean to hog him!\nYour turn."
    if Lez:
        scene 18_0544 with dis1
        scene 18_0545 with dis1
        scene 18_0546 with dis1
        image MillieR08_23 = Movie(play="images/e18/18_0547.webm")
        show MillieR08_23
        car "[ss]..God.."
        scene 18_0548 with dissolve
        mil "[ss]Mmmhh."
        scene 18_0549 with dissolve
        car "[ss]..Ohhhhh.."
        scene 18_0550 with dissolve
        call Moan (car)
        scene 18_0551 with dis1
        scene 18_0552 with dis1
        car "[ss]..Mmhhhh.."
        scene 18_0553 with dissolve
        mil "[ss]..Mmmmmhh.."
        scene 18_0554 with dissolve
        pause 0.5
        scene 18_0555 with dis1
        scene 18_0556 with dis1
        scene 18_0559 with dis1
    else:
        scene 18_0557 with dis1
        scene 18_0558 with dis1
        scene 18_0559 with dissolve
    image MillieR08_24 = Movie(play="images/e18/18_0560.webm")
    show MillieR08_24
    call Moan (mil)
    scene 18_0561 with dissolve
    image MillieR08_25 = Movie(play="images/e18/18_0562.webm")
    show MillieR08_25
    pause
    scene 18_0563 with dissolve
    image MillieR08_26 = Movie(play="images/e18/18_0564.webm")
    show MillieR08_26
    mil "[ss]..Ohhh.."
    scene 18_0565 with dissolve
    pause
    scene 18_0566 with dissolve
    car "[ss]..Mmmhhh.."
    scene 18_0567 with dissolve
    call Moan (mil)
    scene 18_0568 with dissolve
    car "[whi]Daddy, stop.\nI'm so close, but I wanna cum while you're fucking me."
    mil "[whi]And my legs need a rest!"
    scene 18_0569 with fade1
    car "[ss]...OHHHH..."
    scene 18_0570 with dissolve
    image MillieR08_27 = Movie(play="images/e18/18_0571.webm")
    show MillieR08_27
    car "[ss]...OHHHHHH..."
    scene 18_0572 with dissolve
    image MillieR08_28 = Movie(play="images/e18/18_0573.webm")
    show MillieR08_28
    call Moan (mil)
    scene 18_0574 with dissolve
    mil "[ss]..Ohhhh.."
    scene 18_0575 with dissolve
    image MillieR08_29 = Movie(play="images/e18/18_0576.webm")
    show MillieR08_29
    car "[ss]..Ohhhh God, Daddy....Yes...."
    car "[ss]...OHHHH..."
    scene 18_0577 with dissolve
    car "[ss]..OHH, DAD.....YESS....."
    call CharCum ("e18/18_0577.webp", "e18/18_0578.webp", car, "..Ohhhhhhhhhh..")
    call CharCum ("e18/18_0578.webp", "e18/18_0579.webp", car, "...Ohhhhh...")
    scene 18_0580 with dissolve
    car "[ss]..Mmmhhh.."
    scene 18_0581 with dis1
    scene 18_0582 with dis1
    image MillieR08_30 = Movie(play="images/e18/18_0583.webm")
    show MillieR08_30
    mil "[ss]..Ohhhh.."
    scene 18_0584 with dissolve
    image MillieR08_31 = Movie(play="images/e18/18_0585.webm")
    show MillieR08_31
    mil "[ss]..Ohh, Daddy......Yes......Fuck me....."
    mil "[ss]...OHHHH..."
    scene 18_0586 with dissolve
    car "[ss]Mmmmmhhh."
    scene 18_0587 with dissolve
    call Moan (mil)
    scene 18_0588 with dissolve
    image MillieR08_32 = Movie(play="images/e18/18_0589.webm")
    show MillieR08_32
    mil "[ss]..OHHH, YES..."
    mil "[ss].....DAD.......YES.......OHHHHHH..."
    scene 18_0590 with dissolve
    image MillieR08_33 = Movie(play="images/e18/18_0591.webm")
    show MillieR08_33
    mil "[ss]..OHHHHH...."
    mil "[ss]....YES, DADDY.....YESSSS....."
    call CharCum ("e18/18_0590.webp", "e18/18_0592.webp", mil, "..Ohhhhhhh..")
    call CharCum ("e18/18_0592.webp", "e18/18_0593.webp", mil, "......Ohhh.....")
    scene 18_0594 with dissolve
    mil "[ss]...Mmmhhhhh..."
    scene 18_0595 with dissolve
    image MillieR08_34 = Movie(play="images/e18/18_0596.webm")
    show MillieR08_34
    pause
    call CmOpts (["Cum inside Millie", "Cum inside Cara", "Cum on their faces"])
    $ Copt=_return
    if Copt==0:
        $ Millie.incCm()
        $ Millie.Add("A02")
        call CharCum ("e18/18_0595.webp", "e18/18_0597.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e18/18_0597.webp", "e18/18_0598.webp", mc, "..Nnhhhhh..")
        scene 18_0599 with dissolve
        mil "[ss]..Aahhh.."
        scene 18_0600 with dissolve
        pause
        scene 18_0601 with dissolve
        pause
        scene 18_0602 with dissolve
        mil "[ss]Mmmhhh."
    elif Copt==1:
        $ Cara.incCm()
        $ Cara.Add("A02")
        scene 18_0603 with dis1
        scene 18_0604 with dis1
        scene 18_0605 with dis1
        scene 18_0606 with dis1
        image MillieR08_35 = Movie(play="images/e18/18_0607.webm")
        show MillieR08_35
        car "[ss]..Ohhh.."
        scene 18_0608 with dissolve
        car "[ss]Mmmhhh."
        scene 18_0606 with dissolve
        show MillieR08_35
        pause
        call CharCum ("e18/18_0606.webp", "e18/18_0609.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e18/18_0609.webp", "e18/18_0610.webp", mc, "..Nnhhhhh..")
        scene 18_0611 with dissolve
        car "[ss]..Aahhh.."
        scene 18_0612 with dissolve
        pause
        scene 18_0613 with dissolve
        pause
        scene 18_0614 with dissolve
        car "[ss]Mmmhhh."
    else:
        scene 18_0615 with dissolve
        mc "[whi]Turn around, girls."
        scene 18_0616 with dis1
        pause
        scene 18_0617 with dissolve
        image MillieR08_36 = Movie(play="images/e18/18_0618.webm")
        show MillieR08_36
        pause
        call CharCum ("e18/18_0617.webp", "e18/18_0619.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e18/18_0619.webp", "e18/18_0620.webp", mc, "..Nnhhhhh..")
        scene 18_0621 with dissolve
        pause
        scene 18_0622 with dis1
        scene 18_0623 with dissolve
        car "I {b}love{/b} our new alarm clock!"
        scene 18_0624 with dissolve
        mil "Me too![giggles]"
    scene black with ReplayFade
return

label MillieReplay09:
    call Unlocker ("MillieReplay09")
    $ Millie.incSex()
    scene 21_0793 with fade1
    mil "It's been so great hanging out with Cara again."
    mil "Sorry I gave you a hard time when you told me you were her dad."
    mc "Sweetheart, you have nothing to apologize for!"
    scene 21_0794 with dissolve
    mil "I don't even know why I reacted like that. It's the second-best thing that ever happened!"
    mc "Second-best? What's the first?"
    scene 21_0795 with dissolve
    mil "You taking my virginity."
    mc "Yeah..."
    scene 21_0796 with dissolve
    mc "That was very special, Millie. I'll never forget it."
    mil "Neither will I."
    scene 21_0797 with dis1
    pause 0.5
    scene 21_0798 with dissolve
    mil "[whi]Mmhh."
    scene 21_0799 with dissolve
    pause 0.5
    scene 21_0800 with dis1
    scene 21_0801 with dis1
    mil "[whi]..Mmmhh.."
    scene 21_0802 with dissolve
    pause
    scene 21_0803 with dissolve
    pause 0.5
    scene 21_0804 with dis1
    scene 21_0805 with dis1
    scene 21_0806 with dis1
    mil "[ss]Mmhh."
    scene 21_0807 with dis1
    mil "[ss]..Ohhh.."
    mil "[whi]They made it kinda obvious by going for a walk so quickly, huh?"
    mc "[whi]Yeah. I'm glad, though."
    mc "[whi]All the way here, I was thinking, how do I get you alone for a while?"
    scene 21_0808 with dissolve
    mil "[whi]It was Cara's idea.\nThat's why we invited Hannah. I didn't want to leave her on her own."
    mil "[whi]She really is the best sister."
    scene 21_0809 with dissolve
    call Moan (mil)
    scene 21_0810 with dissolve
    pause
    scene 21_0811 with dissolve
    mil "Want me to take off my jeans?"
    mc "Sweetie, I want you to take off {i}everything{/i}."
    scene 21_0812 with dis1
    scene 21_0813 with dis1
    scene 21_0814 with dis1
    scene 21_0815 with dis1
    scene 21_0816 with dis1
    scene 21_0817 with dis1
    mil "Better?"
    scene 21_0818 with dissolve
    mc "Perfect."
    scene 21_0819 with dissolve
    mc "My perfect, beautiful daughter."
    scene 21_0820 with dis1
    pause 0.5
    scene 21_0821 with dis1
    mil "And you're my perfect dad."
    scene 21_0822 with dis1
    mil "[ss]Mmhh."
    scene 21_0823 with dissolve
    image MillieR09_01 = Movie(play="images/e21/21_0824.webm")
    show MillieR09_01
    call Moan (mil)
    scene 21_0825 with dissolve
    pause
    scene 21_0826 with dissolve
    pause 0.5
    scene 21_0827 with dis1
    pause 0.5
    scene 21_0828 with dis1
    pause 0.5
    scene 21_0829 with dis1
    pause 0.5
    scene 21_0830 with dis1
    pause 0.5
    scene 21_0831 with dis1
    pause 0.5
    scene 21_0832 with dissolve
    pause
    scene 21_0833 with dissolve
    image MillieR09_02 = Movie(play="images/e21/21_0834.webm")
    show MillieR09_02
    mil "[ss]Mmhh."
    scene 21_0835 with dissolve
    image MillieR09_03 = Movie(play="images/e21/21_0836.webm")
    show MillieR09_03
    pause
    scene 21_0837 with dissolve
    pause
    scene 21_0838 with dissolve
    image MillieR09_04 = Movie(play="images/e21/21_0839.webm")
    show MillieR09_04
    pause
    scene 21_0840 with dissolve
    mil "[ss]Mmhh."
    scene 21_0841 with dissolve
    pause 0.5
    scene 21_0842 with dis1
    scene 21_0843 with dis1
    image MillieR09_05 = Movie(play="images/e21/21_0844.webm")
    show MillieR09_05
    pause
    scene 21_0845 with dissolve
    pause
    scene 21_0846 with dissolve
    image MillieR09_06 = Movie(play="images/e21/21_0847.webm")
    show MillieR09_06
    mil "[ss]..Mmmmhh.."
    scene 21_0848 with dissolve
    pause
    scene 21_0849 with dissolve
    image MillieR09_07 = Movie(play="images/e21/21_0850.webm")
    show MillieR09_07
    mil "[ss]..Mmmmhh.."
    scene 21_0851 with dissolve
    pause 0.5
    scene 21_0852 with dis1
    scene 21_0853 with dis1
    scene 21_0854 with dis1
    scene 21_0855 with dis1
    scene 21_0856 with dis1
    scene 21_0857 with dis1
    scene 21_0858 with dis1
    scene 21_0859 with dissolve
    image MillieR09_08 = Movie(play="images/e21/21_0860.webm", loop=False, keep_last_frame=True)
    image MillieR09_09 = Movie(play="images/e21/21_0861.webm")
    show MillieR09_08
    pause 3.0
    mil "[ss]..Ohhhh..{w=1.5}{nw}"
    show MillieR09_09
    mil "[ss]Ohh."
    scene 21_0862 with dissolve
    image MillieR09_10 = Movie(play="images/e21/21_0863.webm")
    show MillieR09_10
    call Moan (mil)
    scene 21_0864 with dissolve
    mil "[ss]..Ohhhh...."
    scene 21_0865 with dissolve
    image MillieR09_11 = Movie(play="images/e21/21_0866.webm")
    show MillieR09_11
    pause
    scene 21_0867 with dissolve
    image MillieR09_12 = Movie(play="images/e21/21_0868.webm")
    show MillieR09_12
    pause
    scene 21_0869 with dissolve
    image MillieR09_13 = Movie(play="images/e21/21_0870.webm")
    show MillieR09_13
    pause
    scene 21_0871 with dissolve
    mil "[ss]..God, Daddy.....Nothing compares to having your dick inside me....."
    scene 21_0872 with dissolve
    call Moan (mil)
    scene 21_0873 with dissolve
    mil "[ss]..Ohhhh...."
    scene 21_0874 with dissolve
    pause
    scene 21_0875 with dissolve
    image MillieR09_14 = Movie(play="images/e21/21_0876.webm")
    show MillieR09_14
    pause
    scene 21_0877 with dissolve
    image MillieR09_15 = Movie(play="images/e21/21_0878.webm")
    show MillieR09_15
    pause
    scene 21_0879 with dissolve
    mil "[ss]..Ohhhh...."
    scene 21_0880 with dissolve
    image MillieR09_16 = Movie(play="images/e21/21_0881.webm")
    show MillieR09_16
    pause
    scene 21_0882 with dissolve
    mil "Wanna take over, Daddy?"
    mil "I love riding you, but I love it even more when {i}you're{/i} in control."
    scene 21_0883 with dissolve
    mil "When you're ramming your big, daddy dick into my tight pussy from behind, it makes me orgasm so fast!"
    scene 21_0884 with fade1
    image MillieR09_17 = Movie(play="images/e21/21_0885.webm")
    show MillieR09_17
    mil "[ss]Ohhhh, Daddy.....Yes...Just like that...."
    scene 21_0886 with dissolve
    image MillieR09_18 = Movie(play="images/e21/21_0887.webm")
    show MillieR09_18
    mil "[ss]...OHHH..."
    scene 21_0888 with dissolve
    image MillieR09_19 = Movie(play="images/e21/21_0889.webm")
    show MillieR09_19
    call Moan (mil)
    scene 21_0890 with dissolve
    image MillieR09_20 = Movie(play="images/e21/21_0891.webm")
    show MillieR09_20
    call Moan (mil)
    scene 21_0892 with dissolve
    mil "[ss]...OHHHH, YES DADDY......FUCK ME......MAKE ME CUM..."
    scene 21_0893 with dissolve
    image MillieR09_21 = Movie(play="images/e21/21_0894.webm")
    show MillieR09_21
    mil "[ss]...OHHH..."
    scene 21_0895 with dissolve
    image MillieR09_22 = Movie(play="images/e21/21_0896.webm")
    show MillieR09_22
    pause
    call CharCum ("e21/21_0895.webp", "e21/21_0897.webp", mil, "..OHHHHHHH..")
    call CharCum ("e21/21_0897.webp", "e21/21_0898.webp", mil, "....Ohhhhhhhh....")
    scene 21_0899 with dissolve
    image MillieR09_23 = Movie(play="images/e21/21_0900.webm")
    show MillieR09_23
    mil "[ss]...Mmhhh..."
    scene 21_0901 with dissolve
    image MillieR09_24 = Movie(play="images/e21/21_0902.webm")
    show MillieR09_24
    pause
    call CmOpts (["Cum inside Millie", "Pull out"])
    $ Copt=_return
    if Copt==0:
        $ Millie.incCm()
        call CharCum ("e21/21_0901.webp", "e21/21_0903.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0903.webp", "e21/21_0904.webp", mc, "..Nnnhhhh..")
        scene 21_0908 with dissolve
        pause
        scene 21_0909 with dissolve
        pause
    else:
        call CharCum ("e21/21_0901.webp", "e21/21_0905.webp", mc, "..Nnnngggghhh..")
        call CharCum ("e21/21_0905.webp", "e21/21_0906.webp", mc, "..Nnnhhhh..")
        scene 21_0907 with dissolve
        pause
    scene 21_0910 with fade1
    pause
    if _in_replay:
        scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
