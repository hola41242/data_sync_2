default persistent.oakhill_active = False
default oakhill_id = "OH"
default oakhill_ch = 1
default oakhill_open = False
default oakhill_info = ["","I should visit my daughter, Millie.\nCara says she'd be happy to see me, I kinda doubt it though.","""I'm excited to see Millie again!
It's a strange feeling, but I'm kinda looking forward to seeing Violet again, too.Guess I'll have to visit my sister while I'm in town, just to keep the peace."""]
label UpdateOakhillData(id=0):
    if len(oakhill_info)<=3:
        $ oakhill_info.insert(3, "Millie needs to know she has a sister!\nCara thinks she'll be happy with the news... Not sure how Violet will take it, though.")
    if len(oakhill_info)<=4:
        $ oakhill_info.insert(4, "I promised my Lucy I'd try to be a better brother.\nGood an excuse as any to visit the town, I guess!")
    if len(oakhill_info)<=5:
        $ oakhill_info.insert(5, "Hanging out with Lucy and Hannah was more enjoyable than I thought. Wonder if they'd like to do it again?")
    if len(oakhill_info)<=6:
        $ oakhill_info.insert(6, "Time to collect Alison and Cara from Violet's and bring them home. I hope they had a good time!")
return

default persistent.MilandVi = False
default persistent.MilandCar = False
default persistent.milAndHan = False
default persistent.CarAndHan = False
default persistent.MillieLocked = True
default Millie_name = "Millie"
define mil = Character("[Millie_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="millie")
image side millie cell = side+"millie_c.png"
image side millie h = side+"millie_hp.png"
image side millie s = side+"millie_sd.png"
image side millie a = side+"millie_an.png"
image side millie sh = side+"millie_sh.png"
image side millie su = side+"millie_su.png"
default Millie = Stats()
default persistent.MillieRP03Dat = False
default persistent.MillieRP05Dat = 0
default persistent.MillieRP06Dat = -1
default persistent.MillieRP07Dat = False
default MillieNextPic = 9
default mAndV = None
default miAndCa = None
default miAndHan = None
default persistent.VioletLocked = True
default Violet_name = "Violet"
define vi = Character("[Violet_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="violet")
image side violet cell = side+"violet_c.png"
image side violet h = side+"violet_hp.png"
image side violet s = side+"violet_sd.png"
image side violet a = side+"violet_an.png"
image side violet sh = side+"violet_sh.png"
image side violet su = side+"violet_su.png"
default Violet = Stats()
default persistent.ViRP2D = ([False, False, False])
default persistent.VioletRP04Dat = False
default persistent.VioletRP04BDat = 0

default persistent.LucyLocked = True
default Lucy_name = "Lucy"
define luc = Character("[Lucy_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="lucy")
image side lucy cell = side+"lucy_c.png"
image side lucy h = side+"lucy_hp.png"
image side lucy s = side+"lucy_sd.png"
image side lucy a = side+"lucy_an.png"
image side lucy sh = side+"lucy_sh.png"
image side lucy su = side+"lucy_su.png"
default Lucy = Stats()

default persistent.HannahLocked = True
default Hannah_name = "Hannah"
define han = Character("[Hannah_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="hannah")
image side hannah cell = side+"hannah_c.png"
image side hannah h = side+"hannah_hp.png"
image side hannah s = side+"hannah_sd.png"
image side hannah a = side+"hannah_an.png"
image side hannah sh = side+"hannah_sh.png"
image side hannah su = side+"hannah_su.png"
default Hannah = Stats()
default persistent.HannahRP01Dat = False

screen OakHill_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        if persistent.Incest:
            use ReplayItemBtn(next_x, next_y, "okh", "hannah", Hannah_Replay, persistent.HannahLocked, "Lucy's daughter.\n[persistent.McName]'s niece.")
            python:
                next_x, next_y=IncreaseXY(next_x,next_y)

            use ReplayItemBtn(next_x, next_y, "okh", "lucy", Lucy_Replay, persistent.LucyLocked, "[persistent.McName]'s sister.\nHannah's mom.")
            python:
                next_x, next_y=IncreaseXY(next_x,next_y)

            use ReplayItemBtn(next_x, next_y, "okh", "millie", Millie_Replay, persistent.MillieLocked, "Violet and [persistent.McName]'s daughter.")
            python:
                next_x, next_y=IncreaseXY(next_x,next_y)

        use ReplayItemBtn(next_x, next_y, "okh", "violet", Violet_Replay, persistent.VioletLocked, "[persistent.McName]'s ex-wife.\nMillie's mom.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y) 
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
