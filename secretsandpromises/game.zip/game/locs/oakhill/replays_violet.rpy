label VioletReplay01:
    call Unlocker ("VioletReplay01")
    $ Violet.incSex()
    scene 04_0195 with Fade(2, 1, 2)
    pause 2.0
    scene 04_0196 with dissolve
    pause 1.0
    scene 04_0197 with dissolve
    vi "[ss]Mmhh."
    scene 04_0198 with dissolve
    vi "[ss]..Mmmhhhh.."
    scene 04_0199 with dissolve
    pause 0.5
    scene 04_0200 with dis1
    pause 0.5
    scene 04_0201 with dis1
    pause 0.5
    scene 04_0202 with dis1
    pause 0.5
    scene 04_0203 with dissolve
    vi "Why am I on the chair?"
    if Violet.Has("Kick"):
        mc "I didn't eat dessert yet!"
    else:
        mc "I'm still hungry."
    scene 04_0204 with dissolve
    vi "[lol]"
    scene 04_0205 with dissolve
    pause
    scene 04_0206 with dissolve
    pause 1.0
    scene 04_0207 with dis1
    vi "[whi]It's been a while, huh?"
    scene 04_0208 with dissolve
    mc "Way too long, Honey."
    scene 04_0209 with dissolve
    vi "[ss]..Ohhhh..."
    scene 04_0210 with dissolve
    vi "[ss]..Fuck, I've missed you doing that..."
    scene 04_0211 with dissolve
    vi "[ss]..OHH..."
    scene 04_0212 with dissolve
    vi "[ss]..God, yes..."
    image r_vi_001 = Movie(play="images/e04/04_0213.webm")
    show r_vi_001 with dissolve
    call Moan (vi)
    scene 04_0214 with dissolve
    vi "[ss]..Ohhh....[persistent.McName].......Yes..."
    scene 04_0215 with dissolve
    vi "[ss]..OHHHHHH..."
    scene 04_0216 with dissolve
    vi "[ss]..That's it, Baby, eat your wife's pussy...."
    scene 04_0217 with dissolve
    vi "[ss]...Make me wet, [persistent.McName]...Make me wet for your gorgeous, hard cock....."
    scene 04_0218 with dissolve
    call Moan (vi)
    scene 04_0219 with dissolve
    vi "[ss]..Mmmhhh..."
    scene 04_0220 with dissolve
    vi "[ss]..Ohhh..."
    scene 04_0221 with dissolve
    call Moan (vi)
    scene 04_0222 with dissolve
    vi "[ss]..Oh, god..."
    scene 04_0223 with dissolve
    vi "[ss]..Ohhh....Baby, stop...."
    scene 04_0224 with dissolve
    vi "[ss]You're going to make me cum!"
    vi "[ss]I don't want to... yet."
    scene 04_0225 with dissolve
    vi "[ss]We always cum together."
    scene 04_0226 with fade1
    vi "[ss]Nnnhhh..."
    scene 04_0227 with dissolve
    pause
    scene 04_0228 with dissolve
    pause 1.0
    scene 04_0229 with dis1
    pause 0.5
    scene 04_0230 with dis1
    pause 0.5
    scene 04_0231 with dis1
    pause 0.5
    image r_vi_002 = Movie(play="images/e04/04_0232.webm")
    show r_vi_002 with dissolve
    vi "[ss]Mmmhhh..."
    scene 04_0233 with dissolve
    vi "[ss]...Mmhh...."
    scene 04_0234 with dissolve
    image r_vi_003 = Movie(play="images/e04/04_0235.webm")
    show r_vi_003
    vi "[ss]Mmmhhh..."
    scene 04_0236 with fade1
    pause
    image r_vi_004 = Movie(play="images/e04/04_0237.webm", keep_last_frame=True, loop=False)
    show r_vi_004 with dissolve
    pause 3.0
    vi "[ss]...Ohhhhh..."
    scene 04_0238 with dissolve
    vi "[ss]..Ohh, Baby......Yes..."
    scene 04_0239 with dissolve
    vi "[ss]...Mmhh...."
    scene 04_0240 with dissolve
    image r_vi_005 = Movie(play="images/e04/04_0241.webm")
    show r_vi_005
    call Moan (vi)
    scene 04_0242 with dissolve
    vi "[ss]...God, I've missed you...."
    scene 04_0243 with dissolve
    vi "[ss]...Ohhhhh..."
    scene 04_0244 with dissolve
    vi "[ss]..I've missed having your dick inside me...."
    scene 04_0243 with dissolve
    vi "[ss]...Mmmhh..."
    scene 04_0242 with dissolve
    vi "[ss]..I've missed you making me cum...."
    scene 04_0246 with dissolve
    vi "[ss]...Mmmhh..."
    scene 04_0247 with dissolve
    vi "[ss].Mmhh.."
    scene 04_0248 with dissolve
    vi "[ss].OHHH.."
    scene 04_0249 with dissolve
    image r_vi_006 = Movie(play="images/e04/04_0250.webm")
    show r_vi_006
    call Moan (vi)
    vi "[ss]...YES BABY..."
    vi "[ss]...OHHH..."
    scene 04_0251 with dissolve
    vi "[ss]...FUCK ME BABY...YES...."
    scene 04_0252 with dissolve
    image r_vi_007 = Movie(play="images/e04/04_0253.webm")
    show r_vi_007
    vi "[ss]...OHHH...I'M SO CLOSE...YES....."
    call Moan (vi, 10)
    vi "[ss]...OHHH, [persistent.McName!u]...YES.....YES...."
    call CharCum ("e04/04_0254.webp", "e04/04_0255.webp", vi, "OHHHHHHHHH!!")
    call CharCum ("e04/04_0256.webp", "e04/04_0257.webp", mc, "NNNNNGGGGHHHHH!!")
    $ Violet.incCm()
    scene 04_0258 with dissolve
    mc "[whi]...Fuuuck..."
    vi "[ss]..Mmhhh.."
    scene 04_0259 with dissolve
    vi "[whi]I love you, Baby."
    scene 04_0260 with dissolve
    vi "[whi]God, I needed that."
    scene 04_0261 with dissolve
    mc "[whi]You and me both, Honey..."
    scene 04_0262 with dissolve
    mc "[whi]You and me both."
    scene 04_0263 with Fade(2, 1, 2)
    mc "[whi]..Zzzzz..."
    scene black with Fade(3, 0,0)
return

label VioletReplay02:
    call Unlocker ("VioletReplay02")
    $ Violet.incSex()
    if not _in_replay:
        $ persistent.ViRP2D=([(persistent.Incest and Millie.isActive() and Millie.L==3 and Violet.Has("Saw")), Plr.Has("Bruises"), False])
    scene 07_0350 with Fade(2,2,2)
    vi "[ss]..Mhh.."
    scene 07_0351 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 07_0352 with dissolve
    image r_vi_008 = Movie(play="images/e07/07_0353.webm")
    show r_vi_008
    call Moan (vi)
    scene 07_0354 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 07_0355 with dissolve
    vi "[ss]..Fuck, that feels good, Honey..."
    if persistent.ViRP2D[0]:
        vi "[ss]...I imagine Millie was in Heaven when you were doing it to her....."
        mc "[whi]Uhh... what?\nVi... I-"
        scene 07_0356 with dissolve
        vi "[whi]It's alright, Baby!"
        vi "[whi]I understand why you did it."
        scene 07_0357 with dissolve
        vi "[whi]You gave her what she desperately wanted, what she needed."
        scene 07_0358 with dissolve
        vi "[whi]Not many fathers would have. You're an amazing dad, [persistent.McName]!"
        scene 07_0359 with dissolve
        mc "[whi]I, uh... I thought..."
        scene 07_0360 with dissolve
        vi "[whi]It was so beautiful to witness!"
        scene 07_0361 with dissolve
        vi "[whi]And did you see how happy she was tonight?\nThat was because of YOU!"
        vi "[whi]I just wanted you to know that it's not something you have to hide from me, Honey."
        scene 07_0354 with dissolve
        vi "[ss]...Mmmhhh..."
    scene 07_0362 with dissolve
    call Moan (vi, 4)
    scene 07_0363 with fade1
    pause
    scene 07_0364 with dissolve
    image r_vi_009 = Movie(play="images/e07/07_0365.webm")
    show r_vi_009
    vi "[ss]...Mmmhhh..."
    scene 07_0366 with dissolve
    vi "[ss].....Mmhhhhh....."
    scene 07_0367 with dissolve
    image r_vi_010 = Movie(play="images/e07/07_0368.webm")
    show r_vi_010
    vi "[ss]...Mmhhh..."
    scene 07_0369 with dissolve
    call Moan (vi, 4)
    if persistent.ViRP2D[1]:
        scene 07_0370a with dissolve
    else:
        scene 07_0370 with dissolve
    pause
    scene 07_0371 with dissolve
    image r_vi_011 = Movie(play="images/e07/07_0372.webm")
    show r_vi_011
    vi "[ss]...Mmhhh..."
    scene 07_0373 with dissolve
    call Moan (vi, 4)
    scene 07_0374 with dissolve
    vi "[ss]...Ohhh..."
    scene 07_0375 with dissolve
    vi "[ss]..Nnhh.."
    scene 07_0376 with dissolve
    pause
    scene 07_0377 with fade1
    image r_vi_012 = Movie(play="images/e07/07_0378.webm")
    show r_vi_012
    vi "[ss]...Ohhh..."
    scene 07_0379 with dissolve
    call Moan (vi)
    scene 07_0380 with dissolve
    image r_vi_013 = Movie(play="images/e07/07_0381.webm")
    show r_vi_013
    vi "[ss]...Ohhh..."
    scene 07_0382 with dissolve
    vi "[ss]...Mmhhh, yes...fuck your wife, Baby....."
    scene 07_0383 with dissolve
    image r_vi_014 = Movie(play="images/e07/07_0384.webm")
    show r_vi_014
    vi "[ss]...Ohhhhhh..."
    scene 07_0385 with dissolve
    vi "[ss]...Fuck, [persistent.McName].....Yes....."
    if persistent.ViRP2D[0]:
        scene 07_0386 with dissolve
        vi "[ss]...Ohhh..."
        scene 07_0387 with dissolve
        pause
        scene 07_0388 with dissolve
        if not _in_replay:
            if not EzModeActive:
                menu:
                    "[wk_y]Let Violet know Millie's peeping":
                        $ persistent.ViRP2D[2] = True
                    "Don't say anything":
                        $ persistent.ViRP2D[2] = False
            else:
                $ persistent.ViRP2D[2] = True
        if persistent.ViRP2D[2]:
            mc "[whi]Don't look, but... I think Millie's watching us."
            vi "[ss]Mmmhhh.... Let her watch."
            scene 07_0389 with dissolve
            vi "[ss]..Show her how much you love me...."
        else:
            vi "[ss]...Mmhhh.."
    else:
        scene 07_0388 with dissolve
        vi "[ss]...Mmhhh.."
    scene 07_0390 with dissolve
    image r_vi_015 = Movie(play="images/e07/07_0391.webm")
    show r_vi_015
    vi "[ss]...Ohh......Yes Baby....."
    scene 07_0392 with dissolve
    vi "[ss]...I want to ride you so much right now...."
    scene 07_0393 with fade1
    call Moan (vi)
    scene 07_0394 with dissolve
    image r_vi_016 = Movie(play="images/e07/07_0395.webm")
    show r_vi_016
    vi "[ss]...Ohhhh..."
    if persistent.ViRP2D[2]:
        vi "[ss]...Is she still there?..."
        scene 07_0396 with dissolve
        mc "[whi]Yeah."
        scene 07_0394 with dissolve
        show r_vi_016
        vi "[ss]Did you use your tongue on her?"
        mc "[whi]No."
        vi "[ss]..Mmmmhhh......Did you want to?"
        mc "[whi]Vi.."
        vi "[ss]It's okay, Baby....tell me...."
        mc "[whi]I couldn't help but think about it, yeah."
        vi "[ss]..Fuck...I bet she would've loved it....."
        vi "[ss]...Next time....you should do it....."
        mc "[whi]... Next time?"
        vi "[ss]....Mmmhhhhh......"
        vi "[ss]....I bet she got sooo excited and wet for you..."
        mc "[whi]Yeah, she was pretty wet."
        vi "[ss]...Fuck, [persistent.McName]...I'm gonna cum....."
        call CharCum ("e07/07_0394.webp", "e07/07_0397.webp", vi, "OHHHHHHHHH!!")
        scene 07_0403 with dissolve
        vi "[whi]Sorry Baby! We usually cum together!\nI got carried away!"
        mc "[whi]Heh, it's okay, that's more your thing than mine."
        scene 07_0404 with dissolve
        vi "[whi]Yeah, maybe let's not do that anymore."
        call MillieReplay04
    else:
        vi "[ss]..Mmmhhh.....It's so good...."
        vi "[ss]....I love riding your hard cock, [persistent.McName]..."
        vi "[ss]....OHHHH....YES.....CUM WITH ME, BABY...."
        vi "[ss]....MHHHHH......"
        vi "[ss]...YES....YES...."
        call CharCum ("e07/07_0394.webp", "e07/07_0397.webp", vi, "OHHHHHHHHH!!")
        call CharCum ("e07/07_0397.webp", "e07/07_0398.webp", mc, "NNNNNGGGGHHHHH!!")
        $ Violet.incCm()
        scene 07_0399 with dissolve
        vi "[ss]Mmmhhh... I love feeling you cum inside me."
        scene 07_0400 with dissolve
        mc "[whi]Me too."
        scene 07_0401 with dissolve
        if persistent.Anal:
            mc "[whi]You know, I still haven't given up on cumming in this sweet ass of yours one day. Heh."
            vi "[whi]No chance![lol]"
            vi "[whi]You can cum in my mouth next time though, if you want."
        else:
            vi "[whi]I know cumming together is my thing, but we don't have to, Honey.\nIf you want to cum in my mouth next time, just say."
        mc "[whi]Heh, okay."
        scene 07_0402 with fade1
        vi "[whi]..Zzzz.."
    scene black with Fade(2, 1, 0)
return

label VioletReplay03:
    call Unlocker ("VioletReplay03")
    $ Violet.incSex()
    scene 12_0375 with Fade(0, 0, 2)
    mct "Wonder if Vi's still awake?"
    scene 12_0376 with dissolve
    mct "Tired... but a little horny, too!"
    scene 12_0377 with dissolve
    vi "Hi, Baby."
    scene 12_0379 with dissolve
    mc "Hey."
    vi "I was just thinking about you."
    vi "I was touching myself at the same time..."
    scene 12_0723 with dissolve
    vi "Fancy a quickie to finish the job for me?"
    scene 12_0724 with fade1
    pause
    scene 12_0725 with dissolve
    vi "[ss]Fuck your loving wife, Baby."
    scene 12_0726 with dissolve
    image VioletR03_01 = Movie(play="images/e12/12_0727.webm", loop=False, keep_last_frame=True)
    show VioletR03_01
    pause 2.0
    vi "[ss]Mmmhhh.{w=1}{nw}"
    pause 1.0
    vi "[ss]Ohhhh."
    scene 12_0728 with dissolve
    call Moan (vi, 4)
    scene 12_0729 with dissolve
    image VioletR03_02 = Movie(play="images/e12/12_0730.webm")
    show VioletR03_02
    vi "[ss]...Ohh...."
    scene 12_0731 with dissolve
    call Moan (vi)
    scene 12_0732 with dissolve
    vi "[ss]Oh, Baby.... Yes...."
    scene 12_0733 with dissolve
    image VioletR03_03 = Movie(play="images/e12/12_0734.webm")
    show VioletR03_03
    vi "[ss]...Ohh...."
    scene 12_0735 with fade1
    vi "[ss]..Mmmhhh.."
    scene 12_0736 with dissolve
    image VioletR03_04 = Movie(play="images/e12/12_0737.webm")
    show VioletR03_04
    vi "[ss].....Mmhhh....."
    scene 12_0738 with dissolve
    image VioletR03_05 = Movie(play="images/e12/12_0739.webm")
    show VioletR03_05
    call Moan (vi)
    scene 12_0740 with dissolve
    vi "[ss]Mmhhh."
    scene 12_0741 with dissolve
    vi "[ss]....Fuck, Baby......That's so good....."
    scene 12_0742 with dissolve
    image VioletR03_06 = Movie(play="images/e12/12_0743.webm")
    show VioletR03_06
    vi "[ss]....Ohhhhh....."
    scene 12_0744 with dissolve
    call Moan (vi)
    scene 12_0745 with dissolve
    image VioletR03_07 = Movie(play="images/e12/12_0746.webm")
    show VioletR03_07
    pause
    scene 12_0747 with dissolve
    image VioletR03_08 = Movie(play="images/e12/12_0748.webm")
    show VioletR03_08
    vi "[ss]..OHH, [persistent.McName!u]........YES, BABY......."
    scene 12_0749 with dissolve
    image VioletR03_09 = Movie(play="images/e12/12_0750.webm")
    show VioletR03_09
    call Moan (vi, 8)
    vi "[ss]...OHHHHH......"
    vi "[ss]......YES.....YES......"
    scene 12_0751 with dissolve
    vi "[ss]..OHH, BABY.....I'M ALMOST THERE........YES......"
    show VioletR03_09
    call Moan (vi, 8)
    vi "[ss]...YES..."
    vi "[ss]...OHHHHHH..........YESSSS, BABY......"
    call CharCum ("e12/12_0749.webp", "e12/12_0752.webp", vi, "...Ohhhhhhhhhhhh...")
    call CharCum ("e12/12_0752.webp", "e12/12_0753.webp", vi, "...Mmmmhhhhh...")
    scene 12_0754 with dissolve
    vi "[ss]..Mmmmmmhhhhhh.."
    scene 12_0755 with dissolve
    image VioletR03_10 = Movie(play="images/e12/12_0756.webm")
    show VioletR03_10
    call Moan (vi, 4)
    pause
    $ Copt=0
    if persistent.Anal:
        call CmOpts (["Cum inside Violet", "Pull out", "Request anal"])
    else:
        call CmOpts (["Cum inside Violet", "Pull out"])
    $ Co=_return
    if Co==0:
        $ Violet.incCm()
        $ Copt=1
    elif Co==2:
        $ Violet.Add("Anal")
        scene 12_0757 with dissolve
        mc "[whi]Damn, Vi!\nYour little asshole looks so inviting right now."
        scene 12_0758 with dissolve
        mc "[whi]It's just begging to be stretched by my dick."
        scene 12_0759 with dissolve
        vi "[ss]If it's begging... you should give it what it wants, Baby."
        scene 12_0760 with dissolve
        mc "[whi]Did you just agree to anal??"
        vi "[ss]Be quick, before I change my mind!"
        scene 12_0563 with dissolve
        image VioletR03_11 = Movie(play="images/e12/12_0564.webm", loop=False, keep_last_frame=True)
        show VioletR03_11
        pause 4.0
        vi "[ss]NNNGGHHH."
        scene 12_0761 with dissolve
        vi "[whi]Fuuuuuck!"
        scene 12_0762 with dissolve
        image VioletR03_12 = Movie(play="images/e12/12_0763.webm")
        show VioletR03_12
        vi "[ss]...Nnnnhhhh..."
        scene 12_0764 with dissolve
        pause
        scene 12_0765 with dissolve
        image VioletR03_13 = Movie(play="images/e12/12_0766.webm")
        show VioletR03_13
        call Moan (vi, 4)
        vi "[ss]Fuck, Baby....I can't take it for much longer!...."
        mc "[whi]Okay, Honey."
        scene 12_0767 with dissolve
        image VioletR03_14 = Movie(play="images/e12/12_0768.webm")
        show VioletR03_14
        call Moan (vi, 4)
        pause
        call CmOpts (["Cum inside Violet", "Pull out"])
        $ Co=_return
        if Co==0:
            $ Copt=2
        else:
            $ Copt=0
    else:
        pass
    if Copt==1:
        call CharCum ("e12/12_0769.webp", "e12/12_0770.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0770.webp", "e12/12_0771.webp", mc, "..Nnhhhhh..")
        scene 12_0778 with dissolve
        vi "[ss]Mmhhh."
        scene 12_0779 with dissolve
        pause
    elif Copt==2:
        call CharCum ("e12/12_0769.webp", "e12/12_0770.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0770.webp", "e12/12_0771.webp", mc, "..Nnhhhhh..")
        scene 12_0776 with dissolve
        vi "[ss]Mmhhh."
        scene 12_0777 with dissolve
        pause
    else:
        call CharCum ("e12/12_0769.webp", "e12/12_0772.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e12/12_0772.webp", "e12/12_0773.webp", mc, "..Nnhhhhh..")
        if Violet.Has("Anal"):
            scene 12_0774 with dissolve
        else:
            scene 12_0775 with dissolve
        vi "[ss]Mmhhh."
    scene 12_0780 with fade1
    mc "[whi]..Zzz.."
    scene black with Fade(2, 1, 0)
return

label VioletReplay04A:
    call Unlocker ("VioletReplay04A")
    $ Violet.incSex()
    $ Millie.incSex()
    $ Lez=persistent.MilandVi and persistent.Lez
    if _in_replay:
        scene 15_0782 with fade1
    else:
        scene 15_0782 with Fade(1, 3, 1)
    vi "Ready for us, Baby?"
    mc "Yep!"
    scene 15_0783 with dis1
    mil "Morning Daddy!"
    mc "Morning Sweetheart."
    scene 15_0784 with dis1
    $ aPs(0, True)
    scene 15_0785 with dis1
    $ aPs(0, False, True)
    scene 15_0786 with dis1
    vi "[ss]Not too fast, Millie. He gets so excited when {b}you{/b} do that!"
    scene 15_0787 with dissolve
    mil "[ss]Nnh."
    scene 15_0788 with dis1
    image VioletR04_21 = Movie(play="images/e15/15_0789.webm")
    show VioletR04_21
    mil "[ss]...Mmmmhh..."
    scene 15_0790 with dissolve
    image VioletR04_22 = Movie(play="images/e15/15_0791.webm")
    show VioletR04_22
    vi "[ss]Mmhhh... I get so turned on watching you suck Daddy's dick..."
    mil "[ss]...Mmhh..."
    scene 15_0792 with dissolve
    pause
    call Loop_Dissolve (4, False, False, "e15/15_0793.webp", "e15/15_0794.webp")
    scene 15_0795 with dis1
    pause
    scene 15_0796 with dissolve
    vi "[ss]..Ohhhh..."
    scene 15_0797 with dissolve
    image VioletR04_23 = Movie(play="images/e15/15_0798.webm")
    show VioletR04_23
    mil "[ss]...Mmhh..."
    scene 15_0799 with dissolve
    vi "[ss]Can I watch you ride him, Sweetie?"
    scene 15_0800 with dissolve
    mil "[whi]If you insist!"
    scene 15_0801 with dis1
    scene 15_0802 with dis1
    pause
    scene 15_0803 with dissolve
    image VioletR04_24 = Movie(play="images/e15/15_0804.webm", loop=False, keep_last_frame=True)
    show VioletR04_24
    pause 5.0
    mil "[ss]...Ohhh...{w=2}{nw}"
    pause 2.0
    mil "[ss]..Aaaahhhh..."
    scene 15_0805 with dissolve
    image VioletR04_25 = Movie(play="images/e15/15_0806.webm")
    show VioletR04_25
    mil "[ss]...Ohhh..."
    scene 15_0807 with dissolve
    if Lez:
        vi "[ss]Fuck, I'd love to kiss you right now...."
        mil "[ss]Daddy likes it when we kiss, so what are you waiting for?"
        mil "[ss]Kiss me, Mom."
        scene 15_0808 with dis1
        vi "[ss]...Mmhh..."
        scene 15_0809 with dissolve
        image VioletR04_26 = Movie(play="images/e15/15_0810.webm")
        show VioletR04_26
        mil "[ss]..Mmhhhh.."
    else:
        mil "[ss].....It feels so good, Mom.......Ohhhh...."
        vi "[ss]I know, Sweetie. For your dad too."
    scene 15_0811 with dissolve
    image VioletR04_27 = Movie(play="images/e15/15_0812.webm")
    show VioletR04_27
    call Moan (mil)
    if Lez:
        scene 15_0813 with dissolve
        mil "[ss]..Mmhhhh.."
    scene 15_0814 with dissolve
    mil "[whi]Can I watch {i}you{/i} ride him, Mom?\nWe can swap."
    mil "[whi]I love it when Daddy licks me.\nEspecially when he does that thing with his tongue!"
    scene 15_0815 with dissolve
    scene 15_0816 with dis1
    vi "[whi]Don't move, Baby."
    scene 15_0817 with dis1
    scene 15_0818 with dis1
    scene 15_0819 with dis1
    image VioletR04_28 = Movie(play="images/e15/15_0820.webm")
    show VioletR04_28
    vi "[ss]..Ohhh.."
    scene 15_0821 with dissolve
    call Moan (mil)
    scene 15_0822 with dissolve
    call Moan (mil)
    scene 15_0823 with dissolve
    vi "[ss]..Ohhh.."
    scene 15_0824 with dissolve
    image VioletR04_29 = Movie(play="images/e15/15_0825.webm")
    show VioletR04_29
    pause
    scene 15_0826 with dissolve
    image VioletR04_30 = Movie(play="images/e15/15_0827.webm")
    show VioletR04_30
    call Moan (mil)
    vi "[ss]..Mmmhhhh.."
    scene 15_0828 with dissolve
    scene 15_0829 with dis1
    scene 15_0830 with dis1
    scene 15_0831 with dis1
    vi "[ss]God, I love watching you eat out our daughter, Baby."
    scene 15_0832 with dis1
    scene 15_0833 with dis1
    scene 15_0834 with dis1
    scene 15_0835 with dis1
    mc "[whi]Then let me give you a better view, Honey."
    scene 15_0836 with dis1
    mil "[ss]..Ohhhh.."
    scene 15_0837 with dissolve
    vi "[ss]Such a beautiful sight."
    scene 15_0838 with dissolve
    mil "[ss]..Ohhh, Daddy...I love watching you, too..."
    scene 15_0839 with dissolve
    image VioletR04_31 = Movie(play="images/e15/15_0840.webm")
    show VioletR04_31
    call Moan (mil)
    scene 15_0841 with dissolve
    vi "[ss]..It's so fuckin' hot, Baby...I don't think I've ever been this turned on..."
    $ ft=False
    if not _in_replay and persistent.Lez and mAndV==None:
        $ ft=True
        call Encourage ("Millie", "Violet")
        $ mAndV=_return
        $ persistent.MilandVi=mAndV
        $ Lez=mAndV
    if Lez:
        $ Violet.Add("AteM")
        $ Millie.Add("AteV")
        scene 15_0842 with dissolve
        mc "[whi]Me too."
        mc "[whi]But watching {b}you{/b} eat her would turn me on even more."
        vi "[whi][persistent.McName], no..."
        if not ft:
            vi "[whi]Kissing is one thing... but... this??"
        scene 15_0843 with dissolve
        mc "[whi]It's okay, Vi. I know you want to!\nDon't fight it."
        scene 15_0844 with dissolve
        mc "[whi]You can enjoy our daughter as much as I do."
        mc "[whi]Try it, Baby. Give her a little lick, for me."
        scene 15_0845 with dis1
        pause 0.25
        scene 15_0846 with dissolve
        vi "[ss]Mmhh."
        scene 15_0847 with dis1
        scene 15_0848 with dis1
        image VioletR04_32 = Movie(play="images/e15/15_0849.webm", loop=False, keep_last_frame=True)
        image VioletR04_33 = Movie(play="images/e15/15_0850.webm")
        show VioletR04_32
        pause 20.0
        show VioletR04_33
        vi "[ss]Mmhh."
        scene 15_0851 with dissolve
        call Moan (mil)
        scene 15_0852 with dissolve
        image VioletR04_34 = Movie(play="images/e15/15_0853.webm")
        show VioletR04_34
        vi "[ss]..Mmmmhhhh.."
        scene 15_0854 with dissolve
        vi "[ss]Mmmhhh."
        scene 15_0855 with dis1
        scene 15_0856 with dis1
        mc "[whi]That's it, Baby. Keep going."
        scene 15_0857 with dis1
        scene 15_0858 with dis1
        scene 15_0859 with dis1
        scene 15_0860 with dis1
        vi "[ss]..Mmmhhh.."
        scene 15_0861 with dis1
        mc "[whi]Here you go, Sweetie."
        scene 15_0862 with dis1
        mil "[ss]Mmhh."
        scene 15_0863 with dissolve
        image VioletR04_35 = Movie(play="images/e15/15_0864.webm")
        show VioletR04_35
        mil "[ss]..Mmmhh.."
        scene 15_0865 with dissolve
        image VioletR04_36 = Movie(play="images/e15/15_0866.webm")
        show VioletR04_36
        mil "[ss]...Mmhh..."
        scene 15_0867 with dissolve
        pause
        scene 15_0868 with dissolve
        mil "[ss]..Mmmhh.."
        scene 15_0869 with dissolve
        image VioletR04_37 = Movie(play="images/e15/15_0870.webm")
        show VioletR04_37
        mc "[whi]..Fuck...That's it, Millie.... Suck Daddy's dick while Mommy eats your pussy..."
        scene 15_0871 with dissolve
        scene 15_0872 with dis1
        scene 15_0873 with dis1
        mc "[whi]Relax your throat for me, Sweetie."
        scene 15_0874 with dissolve
        image VioletR04_38 = Movie(play="images/e15/15_0875.webm")
        show VioletR04_38
        mc "[whi]Good girl."
        mil "[ss]..Mmmhh.."
        scene 15_0876 with dissolve
        image VioletR04_39 = Movie(play="images/e15/15_0877.webm")
        show VioletR04_39
        vi "[ss]..Nnhhh.."
        scene 15_0878 with dissolve
        image VioletR04_40 = Movie(play="images/e15/15_0879.webm")
        show VioletR04_40
        mil "[ss]..Mmmhh.."
        scene 15_0880 with dissolve
        image VioletR04_41 = Movie(play="images/e15/15_0881.webm")
        show VioletR04_41
        mil "[ss]...Mmhh..."
        scene 15_0899 with dissolve
        pause
        scene 15_0900 with dis1
        scene 15_0901 with dis1
        scene 15_0902 with dis1
        mc "[whi]That's better."
        scene 15_0903 with dis1
        mc "[whi]Hey, Beautiful."
        mil "[ss]Hi Daddy."
        scene 15_0904 with dissolve
        mc "[whi]Can you do something for me?"
        scene 15_0905 with dissolve
        mil "[ss]..I know what you're gonna ask.."
        scene 15_0906 with dissolve
        mil "[ss]Nnhh."
        mc "[whi]That's my girl."
        scene 15_0907 with dissolve
        mil "[ss]Nnnhh.."
        scene 15_0908 with dissolve
        mc "[whi]Vi...Just so you're aware, that's your daughter's tongue licking you, not mine."
        scene 15_0909 with dissolve
        vi "[ss]...Fuuuuck, Baby..."
        scene 15_0910 with dissolve
        vi "[ss]God, Millie....You're gonna make me orgasm like never before..."
        scene 15_0911 with dissolve
        call Moan (mil)
        scene 15_0912 with dissolve
        mc "[whi]Beautiful."
        scene 15_0913 with dissolve
        image VioletR04_47 = Movie(play="images/e15/15_0914.webm")
        show VioletR04_47
        mil "[ss]...Mmhh..."
        call Moan (vi)
        scene 15_0915 with dissolve
        vi "[ss]...Nnnhh..."
        scene 15_0916 with dissolve
        mil "[ss]..Nhhhhh.."
        scene 15_0917 with dissolve
        mc "[whi]Nice work, Millie!\nYou've got your mom right on the edge..."
        scene 15_0918 with dissolve
        mc "[whi]Mind if I take over?"
        scene 15_0919 with dissolve
        mil "[ss]Can I stay here?"
        mc "[whi]Of course, Sweetie!"
        scene 15_0897 with dissolve
    else:
        vi "[whi]I've fantasized about watching you do this a lot, but actually seeing it... Fuck.."
        scene 15_0882 with dissolve
        mc "[whi]Yeah?\nWhat else did you imagine us doing in your fantasies?"
        vi "[whi]God! SO many things, Baby."
        mc "[whi]Like?"
        vi "[whi]One thing that always gets me {i}so{/i} wet is when I think about you deep-throating her!"
        scene 15_0883 with dissolve
        vi "[whi]That makes me orgasm every time!"
        vi "[whi]Fuck... Even just thinking about it..."
        scene 15_0884 with dissolve
        vi "[whi]She's not ready though. It's too soon, Baby."
        scene 15_0885 with dissolve
        mil "[whi]No it isn't, Mom.\nDaddy, I'm ready to try {b}anything{/b} with you."
        mc "[whi]Only if you want to, Milz."
        mil "[whi]I do."
        mc "[whi]Then let's make your mom's fantasy a reality."
        scene 15_0886 with fade1
        vi "[whi]If it gets too much, let go of my hand and your dad will stop, okay, Baby?"
        mil "[ss]Mhh-mhh."
        scene 15_0887 with dissolve
        mc "[whi]Relax your throat for me, Sweetie."
        image VioletR04_42 = Movie(play="images/e15/15_0888.webm")
        show VioletR04_42
        pause
        scene 15_0889 with dissolve
        vi "[ss]Wow, Millie! You're taking the whole thing!"
        vi "[ss]That's so incredible! And so damn hot!"
        scene 15_0878 with dissolve
        image VioletR04_44 = Movie(play="images/e15/15_0879.webm")
        show VioletR04_44
        mil "[ss]...Mmmmhh..."
        scene 15_0890 with dissolve
        image VioletR04_45 = Movie(play="images/e15/15_0891.webm")
        show VioletR04_45
        mil "[ss]...Mmhh..."
        vi "[ss]...Ohhh...God, Millie....You and Daddy have made me so wet....."
        scene 15_0880 with dissolve
        image VioletR04_41 = Movie(play="images/e15/15_0881.webm")
        show VioletR04_41
        mil "[ss]...Mmhh..."
        scene 15_0892 with dissolve
        vi "[ss]Mmmhhh..... Fuck...."
        scene 15_0893 with dissolve
        vi "[ss]Sorry, Baby... I can't control it any longer...."
        vi "[ss]I'm gonna climax!... I need you to fuck me right now!.."
        scene 15_0894 with dissolve
        mc "[whi]I'm sure Millie won't mind letting her Mom have some attention for a bit!"
        scene 15_0895 with dissolve
        mc "[whi]Have a rest, Sweetie."
        scene 15_0896 with dissolve
        vi "[ss]This won't take long, Baby."
        scene 15_0897 with dis1
    image VioletR04_46 = Movie(play="images/e15/15_0898.webm")
    show VioletR04_46
    vi "[ss]...Ohhhhh......Yes Baby........God..."
    if Lez:
        scene 15_0920 with dis1
        vi "[ss]..Mmmhhh.."
        call Moan (mil)
    scene 15_0921 with dissolve
    image VioletR04_48 = Movie(play="images/e15/15_0922.webm")
    show VioletR04_48
    call Moan (vi, 7)
    if Lez:
        scene 15_0923 with dissolve
        call Moan (mil)
        scene 15_0924 with dissolve
        vi "[ss]...Fuck, Baby.......Yes...."
    scene 15_0925 with dissolve
    image VioletR04_49 = Movie(play="images/e15/15_0926.webm")
    show VioletR04_49
    call Moan (vi, 7)
    vi "[ss]...OHHHH.......YES....."
    vi "[ss]...YESSS....."
    call CharCum ("e15/15_0925.webp", "e15/15_0927.webp", vi, "...Ohhhhhhhhhhhh...")
    call CharCum ("e15/15_0927.webp", "e15/15_0928.webp", vi, ".....ohhh.......mmhhhhhh...")
    scene 15_0929 with dissolve
    image VioletR04_50 = Movie(play="images/e15/15_0930.webm")
    show VioletR04_50
    vi "[ss]....Mmmhhhhhh...."
    pause
    call CmOpts (["Cum inside Violet", "Cum in Millie's mouth", "Fuck Millie"])
    $ Copt=_return
    if Copt==0:
        $ Violet.incCm()
        call CharCum ("e15/15_0929.webp", "e15/15_0931.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0931.webp", "e15/15_0932.webp", mc, "..Nnhhhhh..")
        scene 15_0933 with dissolve
        mc "[whi]....Wow...."
        scene 15_0934 with dis1
        pause 0.5
        scene 15_0935 with dissolve
        mc "[whi]That was awesome."
        scene 15_0936 with dissolve
        mil "[ss]Yeah!"
        scene 15_0937 with dissolve
        vi "[ss]It was AMAZING!"
        scene 15_0938 with dissolve
        pause
    elif Copt==1:
        scene 15_0939 with dissolve
        mc "[whi]Open your mouth, Sweetie."
        call Loop_Dissolve (4, True, False, "e15/15_0940.webp", "e15/15_0941.webp")
        call CharCum ("e15/15_0940.webp", "e15/15_0942.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0942.webp", "e15/15_0943.webp", mc, "..Nnhhhhh..")
        scene 15_0944 with dissolve
        mc "[whi]Nnhh.."
        scene 15_0945 with dissolve
        pause 0.5
        scene 15_0946 with dissolve
        call Gulp (mil)
        scene 15_0947 with dissolve
        mc "[whi]Good girl."
    else:
        scene 15_0948 with dissolve
        vi "[ss]Mmhhhhh.... Don't forget about Millie, Baby..."
        mc "[whi]Never."
        scene 15_0949 with dis1
        scene 15_0950 with dis1
        scene 15_0951 with dis1
        scene 15_0952 with dis1
        scene 15_0953 with dissolve
        mc "[whi]Goddamn. I love this sexy little ass of yours!"
        scene 15_0954 with dissolve
        mil "[ss]...OHHHHH, DADDY..."
        scene 15_0955 with dissolve
        image VioletR04_51 = Movie(play="images/e15/15_0956.webm")
        show VioletR04_51
        call Moan (mil)
        scene 15_0957 with dissolve
        image VioletR04_52 = Movie(play="images/e15/15_0958.webm")
        show VioletR04_52
        call Moan (mil)
        scene 15_0959 with dissolve
        vi "[whi]Does Daddy's dick feel good inside you, Baby?"
        mil "[ss]God... SO good, Mom...."
        vi "[whi]That's because it's where it belongs, Sweetheart."
        scene 15_0960 with dissolve
        image VioletR04_53 = Movie(play="images/e15/15_0961.webm")
        show VioletR04_53
        mil "[ss]....Ohhhhh...."
        call Moan (mil, 6)
        scene 15_0962 with dissolve
        vi "[whi]I could watch you two fuck all day!"
        scene 15_0963 with dissolve
        call Moan (mil, 6)
        scene 15_0964 with dissolve
        image VioletR04_54 = Movie(play="images/e15/15_0965.webm")
        show VioletR04_54
        mil "[ss].....Ohhhhh, Daddy....Yes......"
        scene 15_0966 with dissolve
        image VioletR04_55 = Movie(play="images/e15/15_0967.webm")
        show VioletR04_55
        call Moan (mil, 6)
        scene 15_0968 with dissolve
        image VioletR04_56 = Movie(play="images/e15/15_0969.webm")
        show VioletR04_56
        mil "[ss]....Fuck, Dad....Yes....."
        mil "[ss]......Ohh....God.....YES....."
        scene 15_0970 with dissolve
        image VioletR04_57 = Movie(play="images/e15/15_0971.webm")
        show VioletR04_57
        call Moan (mil, 6)
        mil "[ss]...OHHH....DADDY....."
        mil "[ss]......YES....."
        scene 15_0972 with dissolve
        image VioletR04_58 = Movie(play="images/e15/15_0973.webm")
        show VioletR04_58
        vi "[whi]She's almost there, Baby!"
        call Moan (mil, 6)
        vi "[whi]Your daughter's about cum all over her daddy's big, hard dick."
        mil "[ss]...OHHH..."
        scene 15_0974 with dissolve
        image VioletR04_59 = Movie(play="images/e15/15_0975.webm")
        show VioletR04_59
        mil "[ss]...OHHH....YES DADDY...."
        mil "[ss]......YES....."
        call Moan (mil, 8)
        mil "[ss]...OHH, DAD........YES....."
        call CharCum ("e15/15_0974.webp", "e15/15_0976.webp", mil, "...OHHHHHH...")
        call CharCum ("e15/15_0976.webp", "e15/15_0977.webp", mil, "...mmhhhhhh...")
        scene 15_0978 with dissolve
        image VioletR04_60 = Movie(play="images/e15/15_0979.webm")
        show VioletR04_60
        mil "[ss]...Mmmhhhh..."
        if not _in_replay:
            $ persistent.VioletRP04BDat=Millie.getCumIns()
        if persistent.VioletRP04BDat==0:
            mil "[ss]Leave it in, Daddy."
            mil "[ss]I want to feel you cum inside me for once.\nMom said it feels magical."
        else:
            mil "[ss]Cum inside me again, Daddy... God, I love that feeling..."
        pause
        call CmOpts (["Cum inside Millie", "Pull out"])
        $ Copt=_return
        if Copt==0:
            $ Millie.incCm()
            call CharCum ("e15/15_0978.webp", "e15/15_0980.webp", mc, "...Nnnngggghhhhh..")
            call CharCum ("e15/15_0980.webp", "e15/15_0981.webp", mc, "..Nnhhhhh..")
            scene 15_0982 with dissolve
            mc "[whi]..Fuuck...Sorry, Sweetheart... Hope I didn't hurt you then."
            mil "[ss]Mmmhhh.... Best.Feeling.Ever!"
            scene 15_0983 with dissolve
            mc "[whi]Hell yeah, it is."
            scene 15_0984 with dissolve
            mc "[whi]Nothing beats blowing your load inside your daughter!"
            scene 15_0985 with dissolve
            mil "[ss]Mmhh, I don't know, Daddy... Being the daughter feels pretty damn great too!"
        else:
            call CharCum ("e15/15_0978.webp", "e15/15_0986.webp", mc, "...Nnnngggghhhhh..")
            call CharCum ("e15/15_0986.webp", "e15/15_0987.webp", mc, "..Nnhhhhh..")
            scene 15_0988 with dissolve
            mc "[whi]..Fuuck..."
            scene 15_0989 with dissolve
            vi "[whi]Maybe next time, Sweetheart."
    scene 15_0990 with fade1
    mil "[whi]God, I love this."
    vi "[whi]So do we, Milz. So do we!"
    scene black with ReplayFade
return

label VioletReplay04B:
    call Unlocker ("VioletReplay04B")
    $ Violet.incSex()
    if _in_replay:
        scene 15_0689 with fade
        $ aPs(0, True)
        scene 15_0690 with dis1
        $ aPs()
        scene 15_0692 with dis1
        $ aPs(0, False, True)
    scene 15_0696 with dissolve
    vi "[ss]Nnh."
    scene 15_0697 with dis1
    $ aPs(0, True)
    scene 15_0698 with dis1
    $ aPs()
    scene 15_0699 with dis1
    $ aPs(0, False, True)
    scene 15_0700 with dis1
    image VioletR04_01 = Movie(play="images/e15/15_0701.webm")
    show VioletR04_01
    vi "[ss]...Mmmhhh..."
    scene 15_0702 with dissolve
    vi "[ss]Mmhhh."
    scene 15_0703 with dis1
    scene 15_0704 with dis1
    image VioletR04_02 = Movie(play="images/e15/15_0705.webm")
    show VioletR04_02
    vi "[ss]Mmhhh."
    scene 15_0706 with dissolve
    image VioletR04_03 = Movie(play="images/e15/15_0707.webm")
    show VioletR04_03
    vi "[ss]..Mmhh.."
    scene 15_0708 with dissolve
    image VioletR04_04 = Movie(play="images/e15/15_0709.webm")
    show VioletR04_04
    mc "[whi]...Fuuck....That's good, Baby..."
    scene 15_0710 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 15_0711 with dis1
    scene 15_0712 with dis1
    mc "[whi]Keep going, Baby..."
    scene 15_0713 with dis1
    call Gag (vi)
    scene 15_0712 with dis1
    scene 15_0714 with dissolve
    image VioletR04_05 = Movie(play="images/e15/15_0715.webm")
    show VioletR04_05
    mc "[whi]...Fuuuuck..."
    scene 15_0716 with dissolve
    vi "[whi]I thought you wanted to fuck me, not kill me."
    mc "[whi]Oh Baby, I do..."
    scene 15_0717 with dissolve
    scene 15_0718 with dis1
    scene 15_0719 with dis1
    scene 15_0720 with dis1
    scene 15_0721 with dis1
    vi "[ss]..Mmhh.."
    scene 15_0722 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 15_0723 with dissolve
    pause
    scene 15_0724 with dissolve
    image VioletR04_06 = Movie(play="images/e15/15_0725.webm")
    show VioletR04_06
    call Moan (vi)
    scene 15_0726 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 15_0727 with dissolve
    $ aPs(0, True)
    scene 15_0728 with dis1
    $ aPs()
    scene 15_0729 with dis1
    $ aPs(0, False, True)
    scene 15_0730 with dis1
    image VioletR04_07 = Movie(play="images/e15/15_0731.webm")
    show VioletR04_07
    vi "[ss]..Mmhh.."
    scene 15_0732 with dissolve
    image VioletR04_08 = Movie(play="images/e15/15_0733.webm")
    show VioletR04_08
    call Moan (vi)
    scene 15_0734 with dissolve
    vi "[ss]...Mmmhhh..."
    scene 15_0735 with dissolve
    pause
    scene 15_0736 with dissolve
    image VioletR04_09 = Movie(play="images/e15/15_0737.webm")
    show VioletR04_09
    vi "[ss]...Ohhh..."
    scene 15_0738 with dissolve
    vi "[ss]....Ohhhh, Baby.... That's so good....."
    scene 15_0739 with dissolve
    $ aPs(0, True)
    scene 15_0740 with dis1
    $ aPs()
    scene 15_0741 with dis1
    $ aPs()
    scene 15_0742 with dis1
    $ aPs()
    scene 15_0743 with dis1
    $ aPs(0, False, True)
    scene 15_0744 with dis1
    image VioletR04_10 = Movie(play="images/e15/15_0745.webm")
    show VioletR04_10
    vi "[ss]..Mmhh.."
    scene 15_0746 with dissolve
    image VioletR04_11 = Movie(play="images/e15/15_0747.webm")
    show VioletR04_11
    call Moan (vi)
    scene 15_0748 with dissolve
    vi "[ss].....Fuck......I love riding you, Baby......"
    scene 15_0749 with dissolve
    image VioletR04_12 = Movie(play="images/e15/15_0750.webm")
    show VioletR04_12
    vi "[ss]...Ohhh..."
    scene 15_0751 with dis1
    $ aPs(0, True, True)
    scene 15_0752 with dis1
    image VioletR04_13 = Movie(play="images/e15/15_0753.webm")
    show VioletR04_13
    vi "[ss]...FUCK...."
    vi "[ss].....OHHH, GOD.......YES...."
    scene 15_0754 with dis1
    image VioletR04_14 = Movie(play="images/e15/15_0755.webm")
    show VioletR04_14
    vi "[ss]...OHHHHH, BABY......YES......"
    scene 15_0756 with dissolve
    image VioletR04_15 = Movie(play="images/e15/15_0757.webm")
    show VioletR04_15
    vi "[ss].....OHHHHH....YES.....YES......"
    scene 15_0758 with dissolve
    image VioletR04_16 = Movie(play="images/e15/15_0759.webm")
    show VioletR04_16
    vi "[ss].....BABY.......OHHHH...."
    vi "[ss]...YESS.......YESSSSS....."
    call CharCum ("e15/15_0758.webp", "e15/15_0760.webp", vi, "...Ohhhhhhhhhhhh...")
    call CharCum ("e15/15_0760.webp", "e15/15_0761.webp", vi, "...Mmmmhhhhh...")
    scene 15_0762 with dissolve
    image VioletR04_17 = Movie(play="images/e15/15_0763.webm")
    show VioletR04_17
    vi "[ss]..Fuuck.......You make me orgasm so fast......"
    vi "[ss]...Now it's your turn, Honey..."
    vi "[ss]...You can cum in my mouth for a change if you like....I'll even swallow it for you...."
    call CmOpts (["Cum inside Violet", "Cum in her mouth"])
    $ Copt=_return
    if Copt==0:
        $ Violet.incCm()
        image VioletR04_18 = Movie(play="images/e15/15_0764.webm")
        show VioletR04_18
        vi "[ss]Mmmhhh....Cum for me, Baby...."
        vi "[ss]...Fill your wife with your love........"
        call CharCum ("e15/15_0762.webp", "e15/15_0765.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0765.webp", "e15/15_0766.webp", mc, "..Nnhhhhh..")
        scene 15_0767 with fade
        vi "[whi]Mhhhh."
        scene 15_0768 with dissolve
        pause
        scene 15_0769 with dissolve
        pause
    else:
        scene 15_0770 with fade
        image VioletR04_19 = Movie(play="images/e15/15_0771.webm")
        show VioletR04_19
        vi "[ss]..Mmhh.."
        scene 15_0772 with dissolve
        image VioletR04_20 = Movie(play="images/e15/15_0773.webm")
        show VioletR04_20
        vi "[ss]...Mmmmhh..."
        call CharCum ("e15/15_0772.webp", "e15/15_0774.webp", mc, "...Nnnngggghhhhh..")
        call CharCum ("e15/15_0774.webp", "e15/15_0775.webp", mc, "..Nnhhhhh..")
        scene 15_0776 with dis1
        scene 15_0777 with dissolve
        mc "[whi]You gonna swallow it, like you said?"
        scene 15_0778 with dissolve
        scene 15_0779 with dis1
        call Gulp (vi)
        scene 15_0780 with dis1
        vi "I wasn't expecting {i}that{/i} much!"
        scene 15_0781 with dissolve
        vi "Still too salty for my taste!"
    scene black with ReplayFade
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
