label OakHill_Start1:
    $ persistent.oakhill_active=True
    call CenterText ("A long bus ride later...", True)
    scene 02_0678 with Fade(2, 1, 4)
    mct "Hard to believe it's been over four years since I last saw her."
    scene 02_0679 with dissolve
    mct "Not sure this was a good idea."
    mct "I should've called her first, but she probably blocked my number."
    scene 02_0680 with dissolve
    mct "The last thing she said to me was that she never wanted to see me again..."
    mct "And here I am... about to knock on her door."
    scene 02_0681 with dissolve
    mct "What could possibly go wrong?!"
    scene 02_0682 with dissolve
    mct "I'm sure her mom'll be delighted to see me, too! Hah!"
    scene 02_0683 with dissolve
    call Emotion (mc, "Deep Breath", "Okay... Here we go...")
    play sound "knock.mp3"
    scene 02_0684 with dissolve
    pause 1.5
    scene 02_0685 with dissolve
    pause 1.0
    scene 02_0686 with dissolve
    mc "Hi, Violet."
    vi "I don't believe it!"
    vi "[mc!u]!"
    $ persistent.VioletLocked=False
    $ Violet.Activate("Violet")
    scene 02_0687 with dissolve
    vi "Wow! It's {b}so{/b} good to see you!!"
    mc "[whi]Uhh... What?"
    scene 02_0688 with dissolve
    vi "It seems like it's been {i}forever{/i}!"
    if EzModeActive:
        call EzModeAsk ("Violet")
        if _return:
            $ Violet.Add("EZ")
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e02/02_0689.webp", 1447, 697, True, "OakHill_AF01") with dissolve
        vi "Come in! Come in!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 02_0689
            hide screen imgMap
            scene 02_0691 with dissolve
            mc "Thanks."
    else:
        scene 02_0689 with dissolve
        vi "Come in! Come in!"
        if not EzModeActive:
            menu:
                "[wk_y]Check her out":
                    call OakHill_AF01
                "Don't":
                    mc "Thanks."
        elif Violet.Has("EZ"):
            call OakHill_AF01
    scene 02_0692 with dissolve
    vi "God! How long {i}has{/i} it been??"
    scene 02_0693 with dissolve
    vi "Oh, I was sorry to hear about Pete."
    vi "I can only imagine how tough a time that was for you."
    vi "I wanted to reach out, but... well, you know."
    scene 02_0694 with dissolve
    vi "Sit down! I'll make us some coffee."
    mc "Err, thanks."
    scene 02_0695 with Fade(1, 0.5, 0.5)
    mct "What the fuck?!\nHave I walked into a parallel universe?"
    scene 02_0696 with Fade(2, 0.5, 1.0)
    vi h "I had to pinch myself in the kitchen to make sure I wasn't dreaming!"
    vi "But, no! You {b}are{/b} here!"
    vi "How long are you back for?"
    mc "For good.\nI did something you once said I could never do. I quit!"
    scene 02_0697 with dissolve
    vi "[lol]"
    vi "Fuck off... You're so full of shit!"
    scene 02_0698 with dissolve
    mc "I'm not kidding!\nI'm done with it. No going back."
    scene 02_0699 with dissolve
    vi "Are you playin' with me?"
    mc "You once told me there was only {i}so{/i} much death and destruction a man could take."
    mc "Turns out you were right."
    scene 02_0700 with dissolve
    vi "Jesus! You're serious, aren't you?\nYou {i}really{/i} left!"
    mc "Yeah."
    vi "Wow.\nI don't know if I should be happy or sad."
    mc "Why sad?"
    scene 02_0701 with dissolve
    vi "Sad that it took this long."
    vi "If you'd have done it years ago, maybe we'd still have a marriage."
    scene 02_0702 with dissolve
    vi "I loved you with all my heart, [mc]. I always will.\nBut I couldn't take our family being the {i}second{/i} most important thing in your life."
    vi "Anytime the phone would ring when you were away, I'd always have to hold my breath. Was this gonna be the call to tell me I was a widow?"
    scene 02_0703 with dissolve
    mc "I know I put our family through hell; I'm sorry, Vi.\nBut I don't understand..."
    mc "I wasn't expecting this kinda welcome.\nLast time we spoke, didn't you say you wanted to dance on my grave?"
    scene 02_0704 with dissolve
    vi "Yeah, not my proudest moment!"
    scene 02_0705 with dissolve
    vi "I was so angry with you!"
    vi "I've had plenty of time to think things through.\nWe {b}both{/b} made mistakes, [mc]. It wasn't {i}all{/i} on you."
    vi "It was just {b}easier{/b} to blame you for everything."
    scene 02_0706 with dissolve
    vi "I'm sorry for doing that.\nI'd really like us to be friends again."
    scene 02_0707 with dissolve
    mc "You would?"
    mc "Any chance you can convince Millie not to hate me, too?"
    scene 02_0708 with dissolve
    vi "She doesn't hate you!"
    vi "She misses you like crazy!"
    vi "You know what she's like!\nShe's so damn stubborn! You both are!"
    scene 02_0709 with dissolve
    vi "She wanted you to call and forgive her for what she said, but she'd {i}never{/i} call you to ask for it!"
    vi "And because you didn't, she thinks {i}you{/i} hate her!"
    mc "Shit.\nI never called because I was worried I'd fuck things up even more!"
    scene 02_0710 with dissolve
    vi "See! You're as bad as each other!"
    vi "She's in her room. Go and talk to her."
    scene 02_0711 with dissolve
    vi "She'll have the surprise of her life when her Dad walks in!"
    call OakHill_MeetMillie
    scene 02_0736 with fade1
    vi "So you live with Alison now??"
    mc "I'm not {i}living{/i} with her!\nJust staying there for a little while."
    scene 02_0737 with dissolve
    vi h "Weren't you a couple, way back?"
    vi "Watch yourself, [mc]! Before you know it, you'll be married again!"
    scene 02_0738 with dissolve
    mc "That was a {b}long{/b} time ago!"
    mc "She needed my help. What was I supposed to do?"
    scene 02_0739 with dissolve
    vi "[lol] I'm kidding!"
    scene 02_0740 with dissolve
    mil "Where are you going to live? Now that you're home for good!"
    mc "I haven't thought too much about it, to be honest."
    mil "You {i}could{/i} live here."
    scene 02_0741 with dissolve
    vi "Whoa!\nI'm happy your dad and I are friends again. Not sure I'm ready to {b}live{/b} with him, though!"
    scene 02_0742 with dissolve
    mil h "I don't mean {i}here{/i}, in this house!"
    mil "I mean here, {b}Oakhill{/b}!"
    mc "Yeah, maybe.\nIt's something to think about."
    scene 02_0743 with dissolve
    mc "Damn, I'd better get going."
    mil "Ohh! Dad! Can't you stay a {i}bit{/i} longer? Please!"
    scene 02_0744 with dissolve
    mc "I'd like to, Sweetheart, but I'll miss my bus if I don't leave now."
    scene 02_0745 with dissolve
    vi "Do you {b}have{/b} to leave today, [mc]?"
    vi "If you want to spend time with your daughter, you can stay in the guestroom and leave in the morning."
    scene 02_0746 with dissolve
    mil "Please, Dad! Say you'll stay!"
    mc h "If that's what you want, how can I say no?"
    mil "Yes! We can have a movie night!"
    scene 02_0747 with Fade(2, 2, 1)
    pause 2.0
    scene 02_0748 with Fade(2, 2, 1)
    pause 2.0
    scene 02_0749 with Fade(2, 2, 1)
    pause 2.0
    scene 02_0750 with Fade(2, 2, 1)
    pause 2.0
    scene 02_0751 with Fade(2, 2, 1)
    mil "Ready for a movie?"
    mc "Yeah, if you are."
    scene 02_0752 with dissolve
    mil "I'm gonna put my PJs on first."
    mc "Okay."
    scene 02_0753 with dissolve
    vi "It's nice hearing her laugh so much!"
    vi "I haven't seen her this happy in a long time!"
    scene 02_0754 with dissolve
    vi "I'm sorry I was such a bitch to you, [mc]."
    mc "Damn, Vi, I gave you plenty of reasons!"
    scene 02_0755 with dissolve
    vi "You were doing your job.\nA job whose terms I'd agreed to when I said {i}I do.{/i}"
    vi "I thought I could handle it, but I had no idea how tough it would be."
    vi "How lonely I'd become when you were out of the country for months at a time."
    scene 02_0756 with dissolve
    vi "It got even tougher when Millie was born."
    vi "When I begged you to quit the service and you refused, my sadness and loneliness turned into anger and hate."
    scene 02_0757 with dissolve
    mc "You're right, though; I {b}did{/b} always put the job first."
    mc "I should never have let that happen. I'm sorry."
    vi "Let this be a new chapter. Leave the past where it belongs."
    mc "I'll drink to that!"
    scene 02_0758 with fade
    mc "Cheers!"
    scene 02_0759 with dissolve
    pause 0.5
    play sound "text.mp3"
    pause 1.0
    scene 02_0760 with dissolve
    mc "Uhh, sorry."
    vi "It's okay, go ahead!\nI think Millie has the right idea; I'm going to get into my PJs, too."
    scene 02_0761 with dissolve
    pause 1.0
    show screen CellPhone("Sue")
    msg_nvl "Why are you in Oakhill?"
    mc_nvl "Detour."
    mc_nvl "Wait. How do you know where I am??"
    msg_nvl "James installed a tracker when you gave him your cell."
    msg_nvl "I need to know where my employees are at all times."
    mc_nvl "Wow, that's bullshit!"
    msg_nvl "No, it's necessary."
    msg_nvl "Since you're there, I need you to pick up a package and bring it back with you."
    msg_nvl "I'll forward you the location."
    mc_nvl "What's the package?"
    msg_nvl "No need for concern, nothing illegal."
    mc_nvl "Okay."
    if cedargrove_ch==1:
        mc_nvl "Thought James would be dealing with stuff like this, not you."
        msg_nvl "Yes, typically, he would."
        msg_nvl "But I've decided to take a personal interest in you."
        msg_nvl "James has enough on his plate, having to deal with all our other idiots."
        msg_nvl "You will be dealing with me directly."
        mc_nvl "Whatever."
    call CloseCell ()
    scene 02_0762 with dissolve
    mct "I'm her damn errand boy now?"
    scene 02_0763 with fade
    mil "I can barely even remember our last movie night!"
    mc h "That's hardly surprising! You always fell asleep!"
    scene 02_0764 with fade
    vi "You guys ready?"
    mil "Yeah, we're waiting for you!"
    scene 02_0765 with Fade(1, 0.5, 1)
    play sound "movie.mp3" volume 0.5
    pause 4.0
    scene 02_0766 with Fade(1, 0.5, 1)
    play sound "scary01.mp3" volume 0.5
    pause 4.0
    scene 02_0767 with Fade(1, 0.5, 1)
    play sound "scary02.mp3" volume 0.5
    pause 4.0
    scene 02_0768 with dissolve
    if Millie.Has("Taste"):
        mct "Wow, I've never noticed how smooth her skin is before."
        scene 02_0769 with dissolve
        pause 0.5
    else:
        mct "Damn! Can't believe how lucky I am."
    scene 02_0770 with dissolve
    if Millie.Has("Taste"):
        mct "So soft, too!"
        mct "She's concentrating so much on the movie, I don't think she even knows my hand is there. Heh."
        mct "Let's see how high I get before she realizes! Heh."
        scene 02_0771 with dissolve
        mct "Damn! My pinkie's almost touching her pussy! How has she not noticed?!"
    else:
        mct "Never in a million years did I expect my day to end like this."
    scene 02_0772 with dissolve
    mil "[whi]It's so scary!"
    if Millie.Has("Taste"):
        mc "[whi]Yeah."
    else:
        mc "[whi]Heh. Don't worry, I'll protect you!"
    if Millie.Has("Taste"):
        scene 02_0773 with dissolve
        mct "What the hell is wrong with me?\nI shouldn't be excited by this, but I've got a raging hard-on!"
    scene 02_0774 with Fade(1, 0.5, 1)
    play sound "scary03.mp3" volume 0.5
    vi "Damn, Millie! Why do you always make me watch scary movies?"
    mil "Cause I know how much you love them![lol]"
    scene 02_0775 with Fade(1, 0.5, 1)
    play sound "scary04.mp3" volume 0.25
    pause 5.0
    scene 02_0776 with Fade(1, 0.5, 1)
    play sound "scary05.mp3" volume 0.25
    pause 2.0
    scene 02_0777 with Fade(1, 0.5, 1)
    play sound "scary06.mp3" volume 0.25
    pause 5.0
    scene 02_0778 with Fade(1, 0.5, 1)
    mct "Stepping off the bus earlier, I would never have guessed I'd be sitting here like this!"
    mct "My money was on shouting and screaming - Lots of shouting and screaming."
    scene 02_0779 with dissolve
    mct "She looks good!\nBarely aged a day since I last saw her. Lost a little weight, too."
    scene 02_0780 with dissolve
    mct "It hurt, staying away for so long.\nBut maybe it was the right thing to do, after all."
    scene 02_0781 with Fade(1, 0.5, 1)
    pause 2.0
    scene 02_0782 with dissolve
    vi "I'm not gonna be able to sleep after watching that!"
    scene 02_0783 with dissolve
    vi "Did you enjoy it, Millie?"
    mc "Yeah, she's asleep."
    scene 02_0784 with dissolve
    vi "Jeez! Has she {i}ever{/i} stayed awake for a whole movie?!"
    vi h "Are you still able to carry her to bed?\nOr are you an old man now?"
    mc "Hah, I think I can manage!"
    scene 02_0785 with fade
    mc "[whi]Damn! She's heavier than she looks!"
    vi h "Don't let her hear you say that!"
    scene 02_0786 with Fade(1, 0.5, 1)
    pause 1.0
    scene 02_0787 with dis1
    pause 1.0
    scene 02_0788 with dis1
    pause 0.5
    scene 02_0789
    pause 1.0
    scene 02_0790 with fade
    pause 1.0
    scene 02_0791 with dis1
    call Emotion (mil, "Groan", "", True)
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e02/02_0792.webp", 920, 571, True, "OakHill_AF02") with dissolve
            mct "So beautiful."
            if renpy.get_screen("imgMap"):
                scene 02_0792
                hide screen imgMap
            $ _skipping = False
            show screen imgMap("images/e02/02_0797.webp", 587, 630, True, "OakHill_AF03") with dissolve
            mct "Night, Sweetheart."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 02_0797
                hide screen imgMap
        else:
            scene 02_0792 with dissolve
            mct "So beautiful."
            if not EzModeActive:
                menu:
                    "[wk_y]Lift her top":
                        call OakHill_AF02
                    "Don't":
                        pass
            elif Millie.Has("EZ"):
                call OakHill_AF02
            scene 02_0797 with dissolve
            mct "Night, Sweetheart."
            call OakHill_AF03
    scene 02_0800 with dissolve
    pause 1.0 
    scene 02_0801 with dissolve
    pause 1.0
    scene 02_0802 with Fade(2, 1, 2)
    vi "It's been lovely spending time as a family again."
    mc "Yeah."
    scene 02_0803 with fade
    vi "Millie's right, you know..."
    vi "You {i}should{/i} move to Oakhill.\nShe'd love to have you back in her life full-time!"
    scene 02_0804 with dissolve
    mc "What about you?"
    mc "Could {b}you{/b} cope with me living so close?"
    scene 02_0805 with dissolve
    vi "It's not about me!"
    scene 02_0806 with dissolve
    vi h "But yeah, I'd manage - For her sake!"
    mc h "Not sure I would, though!"
    scene 02_0807 with dissolve
    vi "{size=*0.8}{font=Vanilla.ttf}*{i}GASP{/i}*{/font}{/size} You cheeky...! [lol]"
    scene 02_0808 with dissolve
    vi "Joking aside, think about it."
    $ tCh=None
    if not EzModeActive:
        menu:
            "Push her leg off[wk_c]":
                pass
            "[wk_y]Massage her foot":
                $ tCh=True
    if tCh or Violet.Has("EZ"):
        $ Violet.Score(1)
        scene 02_0809 with dissolve
        mc "Yeah, I will."
        scene 02_0813 with dissolve
        vi "[whi]Mmhhh... You've not done {i}that{/i} in a while!"
        scene 02_0814 with dissolve
        vi "[whi]That feels amazing...."
        scene 02_0815 with dissolve
        vi h "[whi]You should stop, though... You {i}know{/i} what it does to me!"
        scene 02_0816 with dissolve
        mc "[whi]I do?"
        vi "[whi]Yes!"
        scene 02_0817 with dissolve
        vi "[whi]And it's a terrible idea."
        mc h "[whi]It was worth a shot."
        scene 02_0818 with dissolve
        vi "[whi]It's nice to know you're still interested, but we can't."
        mc "[whi]Ohh... Is there someone else? I'm sorry, I didn't think."
        scene 02_0819 with dissolve
        vi "[whi]There's no one else."
        vi "[whi]I'm not saying never.\nI'm saying {i}not yet{/i}."
        vi "[whi]I don't want us rushing in again."
        scene 02_0820 with dissolve
        vi "[whi]It can't be like it was before. Neither of us was happy."
        mc "[whi]Okay."
        vi "[whi]I'm sorry, [mc]. I need a little time, it's confusing."
        mc "[whi]I can give you time."
        scene 02_0812 with dissolve
        vi "It's late; I should get some sleep."
        vi "You remember where the guestroom is, right?"
        mc "Yeah."
        vi "Okay. Goodnight."
    else:
        call CloseCharacterPath (Violet, "Violet")
        scene 02_0809 with dissolve
        pause 0.5
        scene 02_0810 with dissolve
        mc "Yeah, I will."
        scene 02_0811 with dissolve
        vi "It's late; I should get some sleep."
        scene 02_0812 with dissolve
        vi "You remember where the guestroom is, right?"
        mc "Yeah."
        vi "Great. Goodnight."
    call CenterText ("The next morning", True)
    scene 02_0821 with fade
    mil "It sucks that you have to leave so early!"
    mc "I know, Sweetheart."
    mil "Will you come back {b}soon{/b}?"
    mc "Yeah, of course!"
    scene 02_0822 with dissolve
    mil "Promise?"
    mc "I promise."
    if Millie.hasScore(2):
        scene 02_0823 with dissolve
        mil h "[whi]If you come back, I'll let you taste my fingers again!"
        mc h "Wow. Now you won't be able to keep me away!"
        mil "[giggles]"
    scene 02_0824 with dissolve
    vi "Thanks for coming, [mc]."
    vi "I'm glad we're friends again."
    mc "Me too."
    scene 02_0825 with fade
    mil "Bye, Daddy! Love you!"
    scene 02_0826 with dissolve
    mct "That went better than I ever could've imagined!"
    scene 02_0827 with dissolve
    mct "Should have enough time to quickly pick up Her Majesty's package before catching the early bus out of here."
    scene 02_0828 with Fade(3,3,2)
    pause 2.0
    if cedargrove_ch==2:
        $ springhaven_open=True
    jump OakHill_Leave
return

label OakHill_MeetMillie:
    scene 02_0712 with fade1
    pause 1.0
    scene 02_0713 with dissolve
    if persistent.Incest:
        if not EzModeActive:
            menu:
                "[wk_y]Open door":
                    scene 02_0714 with dissolve
                    mct "Fuck!\nShould've knocked first!"
                    $ Millie.Add("Saw")
                    scene 02_0715 with dissolve
                    mil "[ss]..Mmhh.."
                    mct "Close the door and knock, you idiot!"
                "Knock door":
                    pass
        else:
            scene 02_0714 with dissolve
            mct "Fuck!\nShould've knocked first!"
            scene 02_0715 with dissolve
            mil "[ss]..Mmhh.."
            mct "Close the door and knock, you idiot!"
            $ Millie.Add("Saw")
    scene 02_0716 with dissolve
    play sound "knock.mp3"
    pause 1.5
    mil "[whi]Err... {b}Just a minute!"
    pause 1.0
    mil "[whi]Okay, Mom. Come in."
    scene 02_0717 with dissolve
    mc "Uhh, it's not your mom."
    mil "DAD!"
    $ persistent.MillieLocked=False
    $ Millie.Activate("Millie")
    scene 02_0718 with dissolve
    pause 0.5
    scene 02_0719 with dissolve
    call Emotion (mil, "Sobbing", "I'm so sorry I was mean to you!")
    scene 02_0720 with dissolve
    call Emotion (mil, "Sobbing", "I didn't mean the things I said!")
    mc "I know. I'm sorry, too."
    scene 02_0721 with dissolve
    mc "Please don't cry, Sweetheart!"
    mc "I know I fucked it up, but I'd really like to be your dad again."
    mil "I'd like that, too."
    scene 02_0722 with dissolve
    mc "I've missed you so much."
    mil "I've missed you too, Daddy.\nMore than you can ever know!"
    if EzModeActive:
        call EzModeAsk ("Millie")
        if _return:
            $ Millie.Add("EZ")
        else:
            $ Millie.Del("Saw")
    scene 02_0723 with dissolve
    mc "Damn! Look how much you've grown!"
    if Millie.Has("Saw"):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e02/02_0724.webp", 1289, 410, True, "OakHill_AF04") with dissolve
            mil "And {i}you've{/i} grown... {b}old{/b}![giggles]"
        else:
            scene 02_0724 with dissolve
            mil "And {i}you've{/i} grown... {b}old{/b}![giggles]"
            if not EzModeActive:
                menu:
                    "[wk_y]Investigate her hand":
                        call OakHill_AF04
                    "Don't":
                        pass
            elif Millie.Has("EZ"):
                call OakHill_AF04
    else:
        scene 02_0724 with dissolve
        mil "And {i}you've{/i} grown... {b}old{/b}![giggles]"
    $ _skipping = True
    if renpy.get_screen("imgMap"):
        scene 02_0724
        hide screen imgMap
    scene 02_0733 with dissolve
    mil "Cara told me you were home."
    mil "She said you might come and see me.\nI didn't believe her for a second!"
    scene 02_0734 with dissolve
    mil "But... HERE YOU ARE!!"
    scene 02_0735 with dissolve
    mil h "Umm... I just remembered... I'm not wearing pants!"
    mc h "I'll let you get dressed."
return

label OakHill_Start2:
    if cedargrove_ch==2:
        call CenterText ("A long, but incredibly smooth ride later...", True)
    else:
        call CenterText ("A relaxing drive later...", True)
    scene 04_0003 with fade
    pause 1.0
    scene 04_0004 with dis1
    pause 0.5
    play sound "knock.mp3"
    scene 04_0005 with dissolve
    pause 0.5
    scene 04_0006 with dissolve
    pause 1.0
    scene 04_0007 with dissolve
    pause 1.0
    scene 04_0008 with dissolve
    vi "Great! You made it!"
    scene 04_0009 with dissolve
    vi "[kiss]"
    scene 04_0010 with dissolve
    vi "I was beginning to think you weren't coming."
    mc "It's a long drive!"
    scene 04_0011 with dissolve
    vi "Oh, shoot!\nBefore I forget... I owe you an apology!"
    mc "Damn! That's a sentence I didn't think I'd {b}ever{/b} hear you say![lol]"
    scene 04_0012 with dissolve
    vi "[lol] Fuck you!"
    scene 04_0013 with dissolve
    vi "And I was only being polite!\nIt's really {i}your{/i} fault, not mine!"
    mc "Of course!\nI don't even know what we're talking about, but yeah... I'm {b}sure{/b} it's my fault![lol]"
    scene 04_0014 with dissolve
    vi "You {i}may{/i} be in a little trouble with your sister."
    vi "I thought you would've called in on her when you were last here!\nSo I... asked her about it."
    scene 04_0015 with dissolve
    mc "Yeah, don't worry. I've already felt her wrath for it."
    mc "There wasn't time to see her."
    scene 04_0016 with dissolve
    mc "In my defense, though, I didn't know you were still friends!\nI would've asked you not to say anything![lol]"
    scene 04_0017 with dissolve
    vi "Friends?"
    if persistent.Incest and Millie.Has("Taste"):
        scene 04_0018 with dissolve
    else:
        pass
    vi "We're more than friends, [mc]!\nWe're like sisters!"
    scene 04_0019 with dissolve
    mil "You're here!!"
    scene 04_0020 with dis1
    scene 04_0021 with dis1
    mc "Hi, Sweetheart!"
    scene 04_0022 with dissolve
    mil "I've been excited {b}all{/b} morning waiting for you to arrive!"
    scene 04_0023 with dissolve
    vi "Coffee?"
    mc "Yeah, I'd love one! Thanks."
    scene 04_0024 with dissolve
    mil "When you promised to come back, I didn't expect it to be so soon!"
    mc "Yeah, me neither.[lol]"
    if persistent.Incest and Millie.Has("Taste"):
        scene 04_0025 with dissolve
        mil "Oh... You, umm..."
        scene 04_0026 with dissolve
        mil "... have something on your lip..."
        scene 04_0027 with dissolve
        pause 0.5
        scene 04_0028 with dis1
        pause 0.5
        scene 04_0029 with dis1
        pause 0.5
        scene 04_0030 with dis1
        pause 0.5
        scene 04_0031 with dissolve
        mil "... [whi]Oops, sorry."
        scene 04_0032 with dissolve
        mc "[whi]Mmm..."
        scene 04_0033 with dissolve
        mil "[whi]That's better, it's gone now!"
        mct "Jesus! Her fingers have the same taste as before!\nDid she do that deliberately??"
    scene 04_0034 with dissolve
    mil "Mom said you're staying for the night again?"
    mc "Yep!"
    scene 04_0035 with dissolve
    vi "Sorry Sweetie, but you'll need to let go of him so he can drink his coffee."
    scene 04_0036 with fade
    vi "Did I hear you right earlier?\nYou said you {i}drove{/i} down?"
    mc "Yeah!\nI'm test-driving a truck I'm gonna buy."
    scene 04_0037 with dissolve
    mil "So you'll be able to visit us {i}even{/i} more often??"
    mc "That's the idea!"
    scene 04_0038 with dissolve
    vi "Do you plan on visiting Lucy this time?"
    mc "Yeah. She'll kick my ass if I don't![lol]"
    scene 04_0039 with dissolve
    mil "She was {i}soooo{/i} mad at you!"
    scene 04_0040 with dissolve
    vi "Ohh, she was {b}PISSED{/b}!\nI swear I saw steam coming out of her ears at one point![lol]"
    mc "[lol]"
    scene 04_0041 with dissolve
    vi "Oh, I've booked us a table for tonight at a fancy new restaurant!"
    mil "Mommy and Daddy going on a romantic date![giggles]"
    scene 04_0042 with dissolve
    vi "[lol] It's {i}not{/i} a date!\nJust two good friends going out for a meal and catching up!"
    mil "Put a sock on your bedroom door if you don't want me walking in.[lol]"
    vi "Millie!"
    mc "[lol]"
    scene 04_0043 with dissolve
    mil "If Mom gets to have you all to herself this evening, it's only fair that I have you all to myself now!"
    mc "Okay, can't argue with that logic!"
    mc "What would you like to do?"
    scene 04_0044 with dissolve
    mil "To start with, we can go for a drive in your new car!\nWe can stop for lunch somewhere..."
    mil "We can go into town, do a little shopping, then drive to the lake and take a nice walk together!"
    scene 04_0045 with dissolve
    mc "That sounds... exhausting![lol]"
    mil "Come on, old man!"
    scene 04_0046 with dissolve
    mil "Time to spoil your daughter!"
    vi "[lol]"
    scene 04_0047 with dissolve
    vi "Have fun, guys!\nOur table's booked for eight o'clock, [mc]. Be back before then!"
    scene black with Fade(3, 3, 2)
    call CenterText ("You spend an enjoyable day with Millie...")
    scene 04_0048 with Fade(0,0,2)
    mil "MOM! We're home!"
    scene 04_0049 with dissolve
    vi "Perfect timing! The cab's on its way."
    scene 04_0050 with dissolve
    vi "I see you got your wish! Dad {b}has{/b} been spoiling you!"
    mil "That's his job![lol]"
    scene 04_0051 with dissolve
    mil "You can leave the bags there, Dad. I'll come back for them."
    mc "Okay, Sweetheart."
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e04/04_0052.webp", 1447, 398, True, "OakHill_AF05") with dissolve
        vi "I hope you're hungry!"
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 04_0052
            hide screen imgMap
            mc "Starving!"
    else:
        scene 04_0052 with dissolve
        vi "I hope you're hungry!"
        call OakHill_AF05
    mc "I don't feel under-dressed at all!"
    vi "You look fine!"
    scene 04_0055 with dissolve
    vi "But, if you'd {i}like{/i} to change, I still have some of your old clothes in my wardrobe.\nI never could throw them out."
    mc "You do?"
    vi "Yes. Be quick, though, the cab will be here any minute!"
    scene 04_0056 with dissolve
    mc "Why'd you book a cab? I could've driven us?"
    vi "I thought you might like a couple of beers while we were out."
    mc "Oh, okay."
    call OakHill_DateNight
    stop music
    scene 04_0183 with fade2
    vi "[lol]"
    scene 04_0184 with dissolve
    vi "This has been great, hasn't it?"
    mc "Yeah."
    scene 04_0185 with dissolve
    vi "Thanks for a wonderful evening, [mc]."
    mc "My pleasure, Vi."
    if Violet.Has("Kick"):
        $ Violet.Add("I0")
        scene 04_0187 with dissolve
        vi "The look on that poor waitress's face! I've never been so embarrassed!"
        scene 04_0188 with dissolve
        vi "Are you relieved she came to your rescue?"
        scene 04_0189 with dissolve
        mc "Who said I needed rescuing?"
        vi "Did you?"
        scene 04_0190 with dissolve
        mc "No."
        scene 04_0191 with dissolve
        vi "[ss]Mmmhhh.."
        scene 04_0192 with dissolve
        vi "[ss]...Mmhh..."
        scene 04_0193 with dissolve
        vi "Take me to bed, Honey."
        call VioletReplay01
    else:
        if not Violet.isActive():
            scene 04_0186 with dissolve
            vi "I should get into bed.\nThe wine's really starting to hit![lol]"
            mc "Yeah, me too. Heh."
            scene 04_0194 with dissolve
            vi "Goodnight."
            mc "Night, Vi."
        else:
            vi "It's late. I should probably get to bed."
            mc "Yeah, me too. Heh."
            scene 04_0188 with dissolve
            vi "God, I've missed you."
            $ tCh=Violet.Has("EZ")
            if not EzModeActive:
                menu:
                    "[wk_y]Kiss her":
                        $ tCh=True
                    "Don't[wk_c]":
                        $ tCh=False
            if tCh:
                $ Violet.Add("L0")
                scene 04_0190 with dissolve
                mc "As much as I've missed you?"
                scene 04_0191 with dissolve
                vi "[ss]Mmmhhh.."
                scene 04_0192 with dissolve
                vi "[ss]...Mmhh..."
                scene 04_0193 with dissolve
                vi "Let's go to bed, Honey."
                call VioletReplay01
            else:
                scene 04_0189 with dissolve
                mc "Heh, you're drunk. Go to bed."
                vi "You're right, that wine is hitting hard!"
                call CloseCharacterPath (Violet, "Violet")
                scene 04_0194 with dissolve
                vi "goodnight."
                mc "Goodnight, Vi."
    if Violet.isSexual() and persistent.Incest and Millie.isActive() and Millie.hasScore(2):
        call OakHill_WakeupWithMillie
    else:
        scene black with Fade(2, 2, 0)
    scene 04_0355 with Fade(0,2,3)
    mil "Do you {i}have{/i} to leave so early, Dad?"
    mc "Sorry, Sweetheart.\nI'll come back soon."
    scene 04_0356 with dissolve
    vi "Aunt Lucy will {b}never{/b} forgive him if he doesn't visit her this time![lol]"
    scene 04_0357 with dissolve
    vi "Now that your Dad has a truck, he's able to visit as often as he wants!"
    scene 04_0358 with dissolve
    vi "It'll almost be like we're a family again."
    if Violet.isSexual():
        scene 04_0359 with dissolve
        mc "We {b}are{/b} a family."
        scene 04_0360 with dissolve
        vi "Yes, we are."
        if Violet.Has("I0") and Millie.Has("L0") and persistent.Incest:
            vi "My heart melted this morning seeing you two."
            vi "You were so goddamn cute cuddled up together in bed!"
            scene 04_0361 with dissolve
            mil "Mom!"
            vi "I'm just sayin'![lol]"
    else:
        mc "We'll always be family, Vi."
    scene 04_0362 with dissolve
    mc "Okay, wish me luck with Satan!"
    vi "[mc]! Don't call your sister that![lol]"
    mil "[lol] Good luck, Dad!"
    jump OakHill_MeetHannahAndLucy
return

label OakHill_WakeupWithMillie:
    scene 04_0264 with Fade(0, 4, 3)
    pause
    scene 04_0265 with dis1
    scene 04_0266 with dis1
    scene 04_0267 with dis1
    call Emotion (mc, "Groan")
    scene 04_0268 with dissolve
    pause
    scene 04_0269 with dissolve
    mc "[kiss]"
    scene 04_0270 with dissolve
    mct "Oh, crap!"
    scene 04_0271 with dissolve
    mct "It's Millie!"
    mil "[whi]..Zzzz.."
    scene 04_0272 with dissolve
    mct "Violet must be up already."
    mct "I guess Millie still sneaks into her bed! Heh."
    scene 04_0273 with dissolve
    mct "Uhh.. Just remembered... I'm naked!"
    if not EzModeActive:
        menu:
            "Gently get out of bed and leave the room":
                scene 04_0274 with dissolve
                mct "Please don't wake up..."
                scene 04_0275 with dis1
                scene 04_0276 with dis1
                mct "There ya go..."
                scene 04_0277 with dissolve
                mct "Now, where did I put my pants? Heh."
                scene black with Fade(2, 2, 0)
                return
            "[wk_y]Stay in bed a while longer":
                call MillieReplay01
    elif Millie.Has("EZ"):
        call MillieReplay01
return

label OakHill_DateNight:
    $ renpy.music.set_volume(0.75)
    scene 04_0057 with Fade(3, 2, 2)
    play music "datenight.mp3" loop
    mc "Wow! Nice place."
    mc "Hope I can still afford to buy the truck after I've paid the bill! Heh."
    scene 04_0058 with fade1
    mc "It's been too long since we've done this."
    vi "We're doing it now; that's all that matters."
    scene 04_0059 with fade1
    unk "Are you ready to order?"
    mc "Yes. I'll have the, err..."
    scene 04_0060 with fade1
    mc "So, you wanted to discuss something?"
    vi "I... Uhh... I think we should eat first, and you can have another beer or two.[lol]"
    mc "Umm, okay.[lol]"
    scene 04_0061 with dissolve
    mc "Could I ask {i}you{/i} something, then?"
    vi "Of course! Anything."
    mc "Before we married, we hung out a lot with Pete and Alison..."
    scene 04_0062 with dissolve
    mc "But soon after, it became less and less, until we pretty much stopped seeing them altogether."
    mc "I always thought it was because you didn't like Alison."
    scene 04_0063 with dissolve
    vi "That's not true! I like Alison!"
    scene 04_0064 with dissolve
    mc "So why?\nWhy {i}did{/i} we stop hanging out with them?"
    vi "I don't know... We were all busy with life, I suppose."
    vi "Why bring it up now??"
    scene 04_0065 with dissolve
    mc "I've been thinking about my life a lot recently."
    mc "Things I should've seen, but seemed blind to."
    scene 04_0066 with dissolve
    vi "It was a long time ago. It doesn't matter anymore."
    scene 04_0067 with dissolve
    mc "It was Pete, wasn't it?"
    mc "What did he do?"
    scene 04_0068 with dissolve
    vi "[mc]... What difference does it make now?"
    mc "Vi, please."
    scene 04_0069 with dissolve
    mc "Whatever you tell me, I won't let it spoil our night."
    mc "I just need to hear it. I'm not looking for an argument."
    scene 04_0070 with dissolve
    vi "..."
    vi "He... He tried to..."
    scene 04_0071 with dissolve
    vi "He {i}tried it on{/i} with me... on {b}our{/b} wedding night!"
    vi "I brushed it off at first because he was drunk."
    scene 04_0072 with dissolve
    vi "But he tried again a few weeks later, and then again, and again."
    vi "I did my best to avoid him at all times!"
    vi "I'm sorry I didn't tell you. I wanted to, but..."
    scene 04_0061 with dissolve
    mc "No, don't do that.\nYou have {b}nothing{/b} to be sorry for."
    mc "I {i}know{/i} why you didn't tell me, Vi."
    mc "You knew I wouldn't have believed you, or I would've made excuses for him, because no way my best friend would do anything like that."
    scene 04_0070 with dissolve
    vi "Yeah."
    scene 04_0073 with dissolve
    vi "Every time you left the room, his demeanor would change..."
    vi "I hated him. He was a creep!"
    scene 04_0074 with dissolve
    vi "What kind of guy tries to bed his {b}best friend's{/b} wife?!"
    vi "I know all you men are horny little shits who will often cheat on your wives, but come on!"
    scene 04_0075 with dissolve
    mc "Whoa! Hold up a second!"
    mc "I {b}never{/b} cheated on you!"
    scene 04_0076 with dissolve
    vi "Yeah, if you say so![lol]"
    mc "Vi! I'm serious!"
    vi "Never??"
    mc "No!"
    scene 04_0077 with dissolve
    vi "Hmmm, okay... But I bet you came close a few times!"
    scene 04_0078 with dissolve
    mc "No!"
    scene 04_0079 with dissolve
    mc "..."
    mc "Well..."
    scene 04_0080 with dissolve
    mc "There was {i}one{/i} time..."
    scene 04_0081 with dissolve
    mc "It had been a tough tour, stuck in the desert, middle of nowhere..."
    scene 04_0082 with dissolve
    mc "I was bored outta my mind, and for some reason, horny as hell."
    scene 04_0061 with dissolve
    mc "And then, I saw her.\nIt was as if she'd appeared right out of a sandstorm..."
    mc "The most dazzling eyes you could imagine..."
    scene 04_0083 with dissolve
    mc "And, I swear, the biggest, most perfect pair of..."
    scene 04_0084 with dissolve
    mc "... humps I'd ever seen!\nShe was the prettiest {b}camel{/b} I'd ever come across!"
    scene 04_0085 with dissolve
    vi "Wait, what?! CAMEL??"
    scene 04_0086 with dissolve
    vi "[lol]"
    scene 04_0087 with dissolve
    vi "Asshole! I thought you were serious![lol]"
    scene 04_0088 with dissolve
    vi "Thank you!\nCould we get another beer, please?"
    unk "Certainly."
    scene 04_0089 with dissolve
    mc "Looks delicious!"
    vi "It does!"
    scene 04_0090 with Fade(2, 2, 1)
    mc "Damn! That was {b}good{/b}!"
    scene 04_0091 with dissolve
    vi "[whi]Okay... Let's get this over with..."
    vi "We need to talk about Millie..."
    mc "Millie? Okay... What about her?"
    scene 04_0092 with dissolve
    vi "I don't want this to turn into a fight."
    scene 04_0093 with dissolve
    mc "Why would it?"
    scene 04_0094 with dissolve
    vi "Because... over the past year, she's become -honestly- kind of obsessed with you."
    vi "And since you came back... it's only gotten more intense."
    scene 04_0095 with dissolve
    vi "Every conversation I have with her somehow circles back to you."
    vi "{i}'Dad says this,' 'Dad used to do that...'{/i}. It's constant."
    scene 04_0096 with dissolve
    vi "Please, don't get me wrong.\nIt's wonderful that she loves you {i}so{/i} much!"
    vi "But it's also why I'm worried."
    scene 04_0097 with dissolve
    mc "Worried?"
    vi "If you disappear again..."
    vi "If something pulls you away, even for a while - I... I don't know how she'd handle it."
    scene 04_0098 with dissolve
    vi "She'd be heartbroken. Maybe even {b}broken{/b}."
    vi "The more time you spend with her, the deeper she falls into that bond."
    vi "And if -God forbid- you vanish from her life again..."
    scene 04_0099 with dissolve
    mc "Vi..."
    mc "I'm not going anywhere!"
    vi "Maybe not today, or tomorrow..."
    scene 04_0100 with dissolve
    vi "But what about in a month? Six months? A year?"
    vi "You've never stayed still, [mc].\nYour life's always been somewhere else - some warzone, some assignment... some cause."
    vi "What happens when this life starts to feel... too small for you?"
    scene 04_0099 with dissolve
    mc "That's not going to happen."
    vi "You don't know that."
    scene 04_0101 with dissolve
    vi "And if it does, if she wakes up one day and realizes you're gone again..."
    vi "I don't think I'll be able to put her back together."
    scene 04_0102 with dissolve
    mc "Violet, I promise you, I'm not going anywhere."
    mc "I've had four years of silence and regret to think about it."
    scene 04_0103 with dissolve
    mc "I missed important moments of her life. Hell, I missed {b}her{/b} more than {i}words{/i} could ever explain."
    mc "And I kept telling myself, I'll make it up to her, to you both, when I'm back."
    mc "You don't know how many nights I sat in those barracks wondering if she'd even recognize me if I walked through the door."
    mc "Wondering if you'd both be better off if I just stayed away."
    scene 04_0104 with dissolve
    mc "I'm here. And I'm staying.\nNot just for a few weeks. Not until the guilt fades."
    mc "For once in my life, I'm not waiting on a call to ship out."
    mc "I want to build something. A life, roots."
    scene 04_0094 with dissolve
    vi "I {i}want{/i} to believe you, [mc], I do..."
    scene 04_0097 with dissolve
    mc "I don't need you to believe me, Vi. I need you to {i}trust{/i} me.\nGive me the chance to prove it to you."
    mc "I swear, I won't let her down. I won't let {b}you{/b} down."
    scene 04_0105 with dissolve
    vi "..."
    scene 04_0106 with dissolve
    vi "Okay."
    scene 04_0107 with dissolve
    vi "But I'm warning you, [mc]..."
    scene 04_0108 with dissolve
    vi "I'll find you, and rip off your balls with my bare hands if you fuck this up."
    scene 04_0109 with dissolve
    mc "Damn!\nYou gave me the chills![lol]"
    scene 04_0110 with dissolve
    mc "If I fuck it up, my balls are all yours.\nI'll even spread my legs for easier extraction."
    vi "[lol]"
    scene 04_0111 with fade
    unk "Would you like to see the dessert menu?"
    vi "Ooh Yes! And another beer, please."
    unk "On its way."
    scene 04_0112 with fade
    vi "Thank you."
    mc "For what?"
    vi "I wasn't sure how this would go, but..."
    scene 04_0113 with dissolve
    vi "We couldn't have had this conversation before, without yelling or one of us walking out halfway through."
    vi "You've changed."
    scene 04_0061 with dissolve
    mc "Still screw up half the time, but I'm trying."
    call OakHill_ExtendedVioletConvo
    scene 04_0147 with dissolve
    pause 0.5
    scene 04_0148 with dissolve
    vi "I'm glad we did this! It's been a fun evening!"
    scene 04_0149 with dissolve
    mc "Me, too."
    scene 04_0150 with dissolve
    vi "I need to visit the ladies' room. Too much wine!"
    mc "Heh. Okay."
    scene 04_0151 with Fade(1, 2, 1)
    pause 1.0
    scene 04_0152 with Fade(1, 2, 1)
    unk "Would you like to order dessert?"
    mc "Yeah, we'll have two slices of your finest chocolate cake, please."
    unk "Excellent choice."
    scene 04_0153 with Fade(1, 2, 1)
    pause 0.5
    if Violet.isActive() and Violet.Has("Fantasy"):
        play sound "text.mp3"
        pause 1.0
        scene 04_0154 with dissolve
        pause 1.0
        show screen CellPhone("Violet")
        msg_nvl "Can you come to the ladies' room?"
        mc_nvl "Why?"
        msg_nvl "Need your help."
        msg_nvl "{image=/thumbs/cell/emoji/tongue.png}"
        call CloseCell ()
        scene 04_0155 with dissolve
        pause 0.5
        if not EzModeActive:
            menu:
                "[wk_y]Reply: On my way!":
                    pass
                "Reply: Not a good idea.[wk_c]":
                    call CloseCharacterPath (Violet, "Violet")
        scene 04_0154 with dissolve
        pause 1.0
        scene 04_0156 with dissolve
        mc "Thanks."
        scene 04_0157 with fade1
        pause 0.5
        if Violet.isActive():
            scene 04_0158 with Fade(1, 2, 1)
            pause 1.0
            call OakHill_BathroomDate
        else:
            scene 04_0182 with Fade(2, 1, 1)
            vi "Ooh! Nice job choosing the dessert!"
    else:
        scene 04_0182 with Fade(2, 1, 1)
        vi "Ooh! Nice job choosing the dessert!"
    scene black with Fade(4, 0, 0)
return

label OakHill_ExtendedVioletConvo:
    if not persistent.Incest or not Millie.hasScore(2):
        scene 04_0119 with dissolve
        "Your beer, Sir.\nAnd the menu."
        mc "Thanks."
        scene black with Fade(1, 2, 1)
        return
    scene 04_0114 with dissolve
    vi "Don't change {i}too{/i} much!\nMillie loves you just the way you are!"
    vi "I meant what I said about her, she is OBSESSED with you!"
    scene 04_0115 with dissolve
    vi "Every time I go into her room, I'm half-expecting to see the walls covered in posters of you, like some superstar!"
    vi "She hasn't shut up about you showing up out of the blue! She tells everyone!"
    vi "You'd think it was her favorite celebrity who'd knocked on our door, not her dad!"
    scene 04_0116 with dissolve
    mc "That's alright, though, isn't it? She loves me!"
    scene 04_0118 with dissolve
    vi "Yeah, of course it is!"
    scene 04_0120 with dissolve
    vi "It's just..."
    scene 04_0117 with dissolve
    vi "I don't know how to..."
    vi "No, I shouldn't say anything. Forget it."
    scene 04_0116 with dissolve
    mc "Say {i}what{/i}? Forget {i}what{/i}? Tell me, Vi!"
    scene 04_0117 with dissolve
    vi "Well..."
    scene 04_0119 with dissolve
    "Your beer, Sir.\nAnd the menu."
    mc "Thanks."
    scene 04_0121 with fade
    vi "Okay... I guess you {i}should{/i} be aware of it.\nIn case it becomes a more serious issue at some point."
    vi "But {b}promise me{/b} you'll NEVER say anything to her!\nShe would die of embarrassment!"
    scene 04_0116 with dissolve
    mc "I give you my word."
    scene 04_0122 with dissolve
    vi "Okay..."
    vi "Nine, maybe ten, months ago, I took some clean laundry up to her room..."
    vi "I wasn't thinking and just walked in..."
    scene 04_0123 with dissolve
    vi "She was lying on her bed, staring at her phone.\nShe was concentrating on it so much, she wasn't even aware I was there!"
    vi "I could see the screen. She was scrolling through pictures of {b}you{/b}."
    scene 04_0124 with dissolve
    vi "She was... Uhh..."
    vi "Her {i}other{/i} hand was..."
    scene 04_0125 with dissolve
    vi "Fuck, this is difficult to say out loud!"
    scene 04_0126 with dissolve
    scene 04_0127 with dis1
    scene 04_0128 with dis1
    pause 0.5
    scene 04_0123 with dissolve
    vi "She was masturbating. To pictures of... you!"
    vi "I left quietly."
    vi "I walked into my bedroom and sat on the bed. Questioning what I'd just witnessed."
    scene 04_0129 with dissolve
    vi "{i}Was{/i} she doing what I thought she was doing??"
    vi "Was it really {i}you{/i} in the pictures??"
    vi "I... I was... shocked... horrified!"
    scene 04_0130 with dissolve
    vi "Why would she do that?!"
    scene 04_0131 with dissolve
    mc "I don't know."
    vi "Wow. You're handling it better than I did!\nI was expecting more of a reaction."
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Tell Violet you witnessed it, too.":
                $ tCh=True
            "Keep quiet":
                pass
    elif Violet.Has("EZ"):
        $ tCh=True
    if tCh:
        $ Violet.Score(1)
        scene 04_0061 with dissolve
        mc "I have to tell you, Vi..."
        mc "I, uh, saw it, too."
        scene 04_0062 with dissolve
        mc "When you sent me up to her room, I didn't knock.\nShe was doing the same thing."
        scene 04_0132 with dissolve
        vi "No!!"
        vi "Shit, [mc], I'm so sorry!"
        scene 04_0133 with dissolve
        vi "I should've warned you to knock on her door first!"
        vi "What did you do??"
        scene 04_0131 with dissolve
        mc "Same as you - left quietly. Then knocked."
        vi "How did it make you {i}feel{/i}?? Seeing that?"
        scene 04_0104 with dissolve
        mc "I, err.. don't know.\nI didn't really think about it."
        mc "I was just happy to see her again!"
        scene 04_0122 with dissolve
        vi "Yeah, that makes sense."
    else:
        mc "Why? Everyone does it!\nGranted, not to a picture of their parent, but still.\nTo each their own, I guess."
        vi "Yeah, I suppose."
        return
    if not Violet.isActive() or not Violet.hasScore(3):
        return
    scene 04_0124 with dissolve
    vi "I was so confused about the whole thing to begin with.\nI didn't know what to do."
    vi "But after a while, I don't know..."
    scene 04_0133 with dissolve
    vi "It's just a {i}fantasy{/i}, isn't it?"
    scene 04_0134 with dissolve
    vi "God, we all imagine crazy shit when we... do that, don't we??"
    mc "I guess so, yeah."
    $ Violet.Add("Fantasy")
    vi "I couldn't shake it... get it out of my mind..."
    vi "But, the more I thought about it... I.. I... the less angry I became."
    scene 04_0141 with dissolve
    vi "I even reached a point where I started to... like... thinking about it!"
    vi "It was as if, suddenly, it had become {i}my{/i} fantasy!"
    vi "The thought of her, with you... doing things."
    vi "So depraved and obscene. So naughty, yet so exciting!!"
    scene 04_0142 with dissolve
    vi "I made up different scenarios in my head.\nSome were pretty wild!"
    vi "I'd even masturbate while thinking about them."
    scene 04_0136 with dissolve
    mc "What the fuck, Vi?! What are you doing?"
    scene 04_0139 with dissolve
    vi "[lol]"
    scene 04_0140 with dissolve
    vi "I'm sorry. I went too far!"
    vi "It's just..."
    scene 04_0135 with dissolve
    vi "It got me thinking.\nIf {i}you{/i} knew she was thinking of you while touching herself..."
    vi "Would you ever... you know, ...repay the compliment?"
    scene 04_0136 with dissolve
    mc "WHAT?! {b}NO{/b}! Of course not!!"
    scene 04_0137 with dissolve
    vi "[mc]! Obviously only in your imagination!\nI'm not talking about {b}real life{/b}. That's completely different!!"
    vi "Just as a fantasy!\nShe's a beautiful, young woman, isn't she?"
    scene 04_0138 with dissolve
    vi "Imagine for a minute - you're alone in bed, and she walks into your room - butt-naked..."
    scene 04_0134 with dissolve
    vi "{i}Daddy, I can't sleep. Can I get into bed with you?{/i}"
    scene 04_0136 with dissolve
    mc "Are you serious right now??!"
    scene 04_0137 with dissolve
    vi "Yes!\nYou'd be shocked at the things I've imagined you doing to our daughter!"
    scene 04_0136 with dissolve
    mc "JESUS, VIOLET!!"
    scene 04_0133 with dissolve
    vi "Oh, come on [mc]!\nIt's just fantasizing!! It's not real!"
    $ tCh=Violet.Has("EZ")
    if not EzModeActive:
        menu:
            "This is ridiculous! And gross![wk_c]":
                $ tCh=False
            "[wk_y]What did you imagine us doing, exactly??":
                $ tCh=True
    if not tCh:
        scene 04_0143 with dissolve
        call CloseCharacterPath (Violet, "Violet")
        mc "I don't {b}ever{/b} want to hear about this shit again, understand??"
        scene 04_0144 with dissolve
        vi "[mc]! I was only messing!\nTrying to make light of a crazy situation! Jeez!!"
        mc "Okay. Just... don't do it again."
        vi "Fine!"
        scene 04_0138 with dissolve
        vi "It's getting late. We should go home."
        return
    mc "Damn! Now I'm interested in what you imagined us doing!"
    scene 04_0145 with dissolve
    vi "Oh, I can't tell you that!\nIt's way too embarrassing!"
    vi "It's my own personal fantasy!"
    scene 04_0146 with dissolve
    vi "I'm sure you have your own, too!\nWould {i}you{/i} share it with {b}me{/b}?"
    scene 04_0075 with dissolve
    mc "Fair point.[lol]"
return

label OakHill_BathroomDate:
    scene 04_0159 with fade2
    pause 0.5
    scene 04_0160 with dissolve
    mc "Uhh... Violet?"
    play sound "knock.mp3"
    scene 04_0161 with dissolve
    pause 1.0
    scene 04_0160 with dissolve
    pause 1.0
    scene 04_0162 with dissolve
    mc "Vi??"
    scene 04_0163 with dissolve
    vi "Get in here!"
    scene 04_0164 with dissolve
    $ renpy.music.set_volume(0.3)
    vi "Lock the door!"
    mc "You're kidding me??"
    scene 04_0165 with dissolve
    vi "Our conversation about Millie. Wow..."
    scene 04_0166 with dissolve
    vi "It's made me {i}so{/i} damn horny."
    scene 04_0167 with dissolve
    vi "And I need my husband to take care of it."
    mc "Husband?"
    scene 04_0168 with dissolve
    vi "You'll {i}always{/i} be my husband, to me."
    scene 04_0169 with dissolve
    vi "I want us to fuck, [mc]. Right here, right now."
    scene 04_0170 with dissolve
    mc "[ss]Mmhhh.."
    scene 04_0171 with dissolve
    vi "[ss]...Mmmmhhh..."
    scene 04_0172 with dissolve
    vi "[ss]..Mmhh.."
    scene 04_0173 with dissolve
    pause 0.5
    scene 04_0174 with dis1
    vi "[ss]...Mmmmhhh..."
    scene 04_0175 with dissolve
    mc "[whi]Fuck..."
    vi "What's wrong?"
    scene 04_0176 with dissolve
    mc "It's too high! {b}You're{/b} too high!!"
    scene 04_0177 with dissolve
    vi "[lol]"
    play sound "doorbang.mp3" volume 0.5
    pause 1.0
    unk "HELLO?? IS SOMEONE IN THERE?{w=1}{nw}"
    scene 04_0178 with dissolve
    vi "[whi]Shit!"
    unk "OPEN THE DOOR PLEASE!!"
    scene 04_0179 with dissolve
    vi "Damn it!"
    scene 04_0180 with Fade(1, 3, 1)
    unk "You're no longer welcome here.\nPlease don't ever return."
    vi "I'm {i}so{/i} sorry."
    mc "[whi][lol]"
    $ Violet.Add("Kick")
return

label OakHill_MeetHannahAndLucy:
    scene 04_0363 with Fade(2,3,2)
    mct "Ahh, shit. Here we go..."
    scene 04_0364 with dissolve
    mct "Hopefully, she isn't home! Heh."
    play sound "knock.mp3"
    scene 04_0365 with dissolve
    pause 2.0
    scene 04_0366 with dissolve
    pause 1.0
    scene 04_0367 with dissolve
    $ Hannah_name=""
    han "Yes? Can I help you?"
    mc "Hi, Hannah!"
    $ Hannah_name="Hannah"
    scene 04_0368 with dissolve
    han "Err... Do I know you?"
    mc "Hannah?! It's me!\nUncle [mc]!!"
    scene 04_0369 with dissolve
    han "Nah, that can't be right??"
    han "My Uncle [mc] doesn't live on this planet; otherwise he'd visit more often!"
    scene 04_0370 with dissolve
    mc "Heh. Alright, wise-ass!"
    han "[lol]"
    $ Hannah.Activate("Hannah")
    $ persistent.HannahLocked=False
    scene 04_0371 with dissolve
    han "Good to see you, Unc!"
    scene 04_0372 with dissolve
    han "Your health insurance is up-to-date, right?"
    mc "Yeah, why?"
    han "You're probably gonna need it. Mom's furious with you."
    scene 04_0373 with dissolve
    han "Mom, you have a visitor."
    scene 04_0374 with dissolve
    luc "Let me call you back..."
    luc "Bye."
    scene 04_0375 with dissolve
    luc "Look who {b}finally{/b} decided to show up."
    $ Lucy.Activate("Lucy")
    $ persistent.LucyLocked=False
    scene 04_0376 with dissolve
    han "Don't worry, Unc. You got this!"
    scene 04_0377 with dissolve
    han "Have fun![lol]"
    scene 04_0378 with dissolve
    luc "You in town to visit your {b}ex-wife{/b} again?"
    luc "Guess I should be grateful that you managed to fit me into your busy schedule {i}this time{/i}!"
    scene 04_0379 with dissolve
    mc "I came to visit {b}my daughter{/b}, not Violet!"
    scene 04_0380 with dissolve
    mc "Can I sit down, or would you prefer I leave?"
    luc "Do what you want. You always do."
    scene 04_0381 with dissolve
    mc "Jesus, Lucy!\nI already apologized, come on!"
    scene 04_0382 with dissolve
    luc "Oh, wow...Yeah...\nYou apologized for ignoring me when you were last in town..."
    scene 04_0383 with dissolve
    luc "You didn't fuckin' apologize to me for missing Mom's funeral."
    luc "Or for leaving {b}me{/b} to deal with all the shit afterward."
    scene 04_0384 with dissolve
    luc "And I don't remember you letting me know you were even home?"
    scene 04_0385 with dissolve
    luc "I don't recall our conversation where you told me you'd quit your job, either."
    scene 04_0386 with dissolve
    mc "Damn, Sis! Okay, you've made your point!\nI'm a shit brother!"
    luc "Yes, you are."
    scene 04_0387 with dissolve
    mc "And you're a shit sister!"
    scene 04_0388 with dissolve
    mc "I barely knew your husband!\nAnd it was Violet who told me that you'd divorced him!"
    mc "I don't remember us having {i}that{/i} conversation??"
    scene 04_0389 with dissolve
    mc "It works both ways, Sis!"
    scene 04_0390 with dissolve
    mc "It's always been this way with us!\nWe've never been {i}that{/i} close!"
    mc "When we were younger, you did everything you could to avoid me, for fuck sake!"
    scene 04_0391 with dissolve
    luc "It wasn't {i}you{/i} I was avoiding!\nIt was that creepy little fuckwit that was always by your side!"
    scene 04_0392 with dissolve
    mc "... Pete?"
    mc "Did he do something??"
    luc "No, I never gave him the chance!"
    scene 04_0393 with dissolve
    luc "And yes, you're right. We've {b}never{/b} been close."
    luc "But [mc], things are different now.\nSince Mom passed, you're all the family I have left!"
    scene 04_0394 with dissolve
    mc "I could've sworn you had children? Heh."
    luc "Fuck off, you know what I mean!"
    call Emotion (luc, "Sigh")
    scene 04_0395 with dissolve
    luc "Do you ever... think about our father?"
    luc "For a long time, you wanted to try to find him."
    scene 04_0386 with dissolve
    mc "Jeez! That was years ago!"
    mc "Mom refused to talk about him. Wouldn't even give me his name."
    mc "Impossible to track someone down when you have absolutely no information on them!"
    scene 04_0396 with dissolve
    luc "Richard Johnson."
    luc "Want his address?"
    scene 04_0397 with dissolve
    mc "What?"
    mc "You knew??"
    scene 04_0398 with dissolve
    luc "No.\nNot until after her death."
    scene 04_0399 with dissolve
    luc "It was left to me to clear out Mom's things before we sold the house."
    luc "I found an old box hidden away in her bedroom.\nIt contained some old letters."
    scene 04_0400 with dissolve
    luc "They were from our father."
    luc "He occasionally sent her cash and would ask about us."
    scene 04_0401 with dissolve
    luc "The letters had a return address."
    scene 04_0402 with dissolve
    mc "Not interested."
    scene 04_0403 with dissolve
    luc "What?! Why not??"
    scene 04_0397 with dissolve
    mc "He obviously {i}knew{/i} he was our father, knew where we lived.\nWhy didn't he ever come to see us?"
    mc "Clearly, he didn't want us in his life.\nFuck him."
    scene 04_0404 with dissolve
    luc "Wouldn't you like to know {i}why{/i}?"
    luc "At least give him a chance to explain!\nHe may have a valid reason?!"
    scene 04_0405 with dissolve
    mc "I couldn't give a damn what his excuse is!"
    scene 04_0406 with dissolve
    luc "Well, I do!!\n{b}I{/b} want to know!"
    scene 04_0407 with dissolve
    mc "SO GO FUCKIN' ASK HIM!"
    luc "I CAN'T GO!"
    mc "WHY??"
    scene 04_0408 with dissolve
    luc "I... I..."
    scene 04_0409 with dissolve
    luc "... I'm frightened he'll reject me."
    scene 04_0410 with dissolve
    mc "He's {b}already{/b} rejected you, Lucy!\nHe rejected both of us!"
    scene 04_0411 with dissolve
    luc "[mc], please. I just need to know {b}why{/b}."
    scene 04_0412 with dissolve
    mc "Please??\nWhat do you expect me..."
    scene 04_0413 with dissolve
    mc "Whoa! Hold on!"
    scene 04_0414 with dissolve
    mc "You want {b}me{/b} to go??"
    scene 04_0415 with dissolve
    luc "Will you?\nPlease! For me?"
    if persistent.Incest and EzModeActive:
        call EzModeAsk ("Lucy")
        if _return:
            $ Lucy.Add("EZ")
    scene 04_0416 with dissolve
    mc "You can't be fuckin' serious?"
    scene 04_0417 with dissolve
    luc "I'm begging you, [mc]."
    mc "Why??"
    scene 04_0418 with dissolve
    luc "Like it or not, he's a part of us!"
    luc "We could even have {b}more{/b} family out there, somewhere!"
    scene 04_0419 with dissolve
    mc "Damn it, Lucy!\nHow old are these letters??"
    mc "He could've moved!\nHell, he could be dead by now!"
    mc "What if I find him and he refuses even to admit he's our father?"
    mc "Or he just tells me to get lost??"
    scene 04_0418 with dissolve
    luc "Then at least I'll know we tried.\nI'll know we gave {i}him{/i} the chance."
    luc "It's the {i}not knowing{/i} that hurts."
    scene 04_0420 with dissolve
    luc "I've never asked you for anything, but, as my only brother, my only family, I'm asking you for this."
    scene 04_0421 with dissolve
    luc "[mc], please."
    call Emotion (mc, "Sigh")
    mc "Let me think about it, Sis."
    scene 04_0422 with dissolve
    luc "Okay, fair enough."
    luc "This is all new to you.\nIt's been on my mind for months, ever since I found those letters."
    luc "It's only fair I give you time to process it."
    scene 04_0423 with dissolve
    luc "But please, don't leave me hanging for too long, [mc]."
    scene 04_0422 with dissolve
    mc "Okay."
    mc "Heh. {b}This{/b} is new for me, too - seeing you down there in that position!"
    scene 04_0424 with dissolve
    luc "What position?"
    mc "On your knees, begging for my help."
    scene 04_0425 with dissolve
    luc "Yeah, I imagine you're loving this, aren't you?!"
    scene 04_0426 with dissolve
    if persistent.Incest:
        $ tCh=None
        if not EzModeActive:
            menu:
                "[wk_y]I like seeing you on your knees!":
                    $ tCh=True
                "No, it's freaking me out a little!":
                    pass
        elif Lucy.Has("EZ"):
            $ tCh=True
        if tCh:
            $ Lucy.Score(1)
            scene 04_0427 with dissolve
            mc "I could get used to it, Sis!"
            luc "You're weird. You know that, right?"
        else:
            mc "No, it's freaking me out a little!"
            luc "Good. It's the first and last time you get to see it, Bro."
    else:
        mc "No, it's freaking me out a little!"
        $ Lucy.Score(1)
        luc "Good. It's the first and last time you get to see it, Bro."
    scene 04_0428 with dissolve
    han "Whoops! Sorry!\nWould you like me to come back in ... ten minutes? [lol]"
    luc "Very funny."
    scene 04_0429 with dissolve
    luc "What are you doing??"
    scene 04_0430 with dissolve
    han "I came to clean up the blood!"
    mc "[lol]"
    scene 04_0431 with dissolve
    luc "{i}This{/i} is what I have to put up with!"
    luc "The girl {i}thinks{/i} she's hilarious!"
    scene 04_0432 with dissolve
    han "I am!\nUncle [mc] laughed!"
    mc "It {i}was{/i} kinda funny. Heh."
    scene 04_0433 with dissolve
    luc "I'll make some coffee."
    scene 04_0434 with dissolve
    han "How you doin', Unc?"
    scene 04_0435 with dissolve
    han "Haven't seen you for a while!"
    scene 04_0436 with dissolve
    mc "I know! Sorry, Sweetie.\nI should've made more of an effort to visit you guys."
    if persistent.Incest and EzModeActive:
        call EzModeAsk ("Hannah")
        if _return:
            $ Hannah.Add("EZ")
    mc "Wasn't your hair blue the last time I saw you?"
    scene 04_0437 with dissolve
    han "Yeah!\nDon't you think I look cute like this, though?"
    mc "Of course! Heh."
    scene 04_0438 with dissolve
    han "Daaaamn!\nLook at these bad boys! Are they even bigger now?"
    han "Do it, Unc!"
    if persistent.Incest:
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e04/04_0439.webp", 835, 722, True, "OakHill_AF06") with dissolve
            han "Niiiiice!!"
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 04_0439
                hide screen imgMap
                mc "[lol]"
        else:
            scene 04_0439 with dissolve
            han "Niiiiice!!"
            if not EzModeActive:
                menu:
                    "[wk_y]Place your hand on her thigh":
                        call OakHill_AF06
                    "Don't":
                        mc "[lol]"
            elif Hannah.Has("EZ"):
                call OakHill_AF06
    else:
        scene 04_0439 with dissolve
        han "Niiiiice!!"
        mc "[lol]"
    $ tt=""
    if Hannah.hasScore(1):
        $ tt="a"
    show expression "04_0440" + tt with dissolve
    han "I heard you've been havin' some fun with Millie!"
    mc "Huh?"
    scene 04_0443 with dissolve
    han "She sent me about twenty messages yesterday!"
    han "My dad bought me {i}this{/i}. My dad bought me {i}that{/i}.\nMy dad took me {i}here{/i}. My dad took me {i}there{/i}!"
    scene 04_0444 with dissolve
    han "She's my best friend, but that girl is {b}crazy{/b}!"
    show expression "04_0445" + tt with dissolve
    han "It made me a little jealous!\nI can't remember the last time {b}we{/b} spent time together!"
    mc "I know. And I'm gonna make it up to you.\nYou're gonna be seeing a lot more of me from now on!"
    scene 04_0446 with dissolve
    han "For real??"
    mc "Yeah!"
    if Hannah.hasScore(1):
        scene 04_0447 with dissolve
        han "That'll be awesome!!"
        scene 04_0448 with dis1
        pause 0.5
        scene 04_0449 with dissolve
        han "Your hand lookin' for an adventure down there, Unc?"
        mc "Heh. Just admiring your soft, delicate skin."
        han "Yeah? The higher you go, the more delicate it gets!"
        scene 04_0448 with dissolve
        mc "Is that so?"
        scene 04_0450 with dis1
        pause 0.5
        scene 04_0451 with dissolve
        han "[lol]"
        han "Damn it, you win!\nYou {b}always{/b} call my bluff!"
        han "I'm gonna beat you one day!"
        mc "Never![lol]"
        scene 04_0452 with dissolve
        luc "What are you two giggling about?"
    else:
        scene 04_0453 with dissolve
        han "That'll be awesome!"
    scene 04_0454 with dissolve
    han "Uncle [mc] said we're gonna see a lot more of him from now on!"
    luc "Hmm, we'll see."
    scene 04_0455 with dissolve
    mc "Where's your brother?"
    han "College!"
    scene 04_0456 with dissolve
    han "He searched for a college as far away as possible from Mom and left!"
    scene 04_0457 with dissolve
    luc "Don't listen to her. It was the only college that accepted him."
    han "It was the only college he applied to![lol]"
    scene 04_0458 with dissolve
    luc "At least he's trying to do something with his life.\nHave you told your uncle what it is {i}you{/i} do?"
    scene 04_0459 with dissolve
    han "I'm an online streamer!"
    if persistent.Incest and Hannah.hasScore(1):
        mc "Oh, shit!\nIs it OnlyFans? Please tell me it's OnlyFans![lol]"
    else:
        mc "What?! Jesus... Please tell me it isn't OnlyFans?!!"
    scene 04_0460 with dissolve
    han "[lol]"
    scene 04_0461 with dissolve
    if persistent.Incest and Hannah.hasScore(1):
        han "Sorry, Unc! It's not OnlyFans!"
    else:
        han "No, of course not!"
    scene 04_0462 with dissolve
    han "I stream myself playing games.\nIt's a lot of fun!"
    mc "Ohh... you're a {i}gamer girl{/i}? Heh."
    han "Yep!"
    mc "Good for you, Sweetie!"
    scene 04_0463 with dissolve
    luc "Typical!\nI should've known you'd take her side!"
    han "[lol]"
    scene black with Fade(3, 2, 0)
    call CenterText ("A couple of hours later...")
    scene 04_0464 with dissolve
    luc "I hate to admit it, but it's been nice to see you, [mc]."
    mc "Good seeing you, too, Sis.\nAnd again, sorry for last time."
    scene 04_0465 with dissolve
    luc "You can make it up to me by agreeing to my request."
    mc "Send me the address. I'm not making any promises, though."
    scene 04_0466 with dissolve
    han "You'd better come back {b}soon{/b}!"
    scene 04_0467 with dissolve
    mc "I will!"
    scene 04_0468 with fade
    han "Bye, Unc!"
    $ cedargrove_open=True
    jump OakHill_Leave
return

label OakHill_Start3:
    scene 07_0001 with Fade(0,3,3)
    pause
    play sound "knock.mp3"
    scene 07_0002 with dissolve
    pause
    scene 07_0003 with dissolve
    vi "You just can't stay away, can you? [lol]"
    mc "Heh. Guess I'm making up for lost time."
    scene 07_0004 with dissolve
    vi "You must've flown down the highway! I wasn't expecting you this soon."
    mc "Yeah, sorry. I was already on the road when I sent the text."
    scene 07_0005 with dissolve
    vi "Everything alright?\nI'll admit, I was a little surprised you wanted to visit again so soon."
    mc "Yeah. I just... need to talk to Millie.\nTo both of you, really. But her first."
    scene 07_0006 with dissolve
    vi "Why?"
    vi "You've got that serious look..."
    scene 07_0007 with dissolve
    vi "You're not leaving again, are you??"
    vi "I warned you not to do this, [mc]!"
    scene 07_0008 with dissolve
    mc "No. I'm {b}not{/b} leaving, Vi!"
    mc "I promised you, and I'm keeping it."
    scene 07_0009 with dissolve
    vi "Sorry.\nI want to believe you. I really do. It's just going to take time."
    mc "I get that. After everything, I don't blame you."
    vi "Still... it wasn't fair of me to jump to conclusions."
    scene 07_0010 with dissolve
    vi "So, what's this about?"
    mc "Is Millie here?"
    vi "No, she's not home yet."
    scene 07_0011 with dissolve
    mc "Okay... Then I'll tell you first."
    vi "Tell me what?"
    mc "Let's sit down."
    scene 07_0012 with Fade(0.5,0.5,0.5)
    vi "You're worrying me, [mc]."
    mc "It's about Cara..."
    scene 07_0013 with dissolve
    vi "Cara? Is she okay??"
    mc "She's fine."
    scene 07_0014 with dissolve
    mc "She's {b}mine{/b}, Vi."
    mc "She's {b}my{/b} daughter. Not Pete's. Mine."
    scene 07_0015 with dissolve
    vi "..."
    mc "I should've told you a long time ago. You deserved that."
    scene 07_0016 with dissolve
    vi "That's why you came all this way?"
    mc "Yeah."
    scene 07_0014 with dissolve
    mc "Cara knows now. I couldn't let you hear it from someone else."
    mc "Now {i}I'm{/i} beginning to worry... You seem awfully calm."
    scene 07_0017 with dissolve
    vi "[mc]... I already knew."
    mc "Huh?! HOW??"
    vi "You don't remember, do you?"
    scene 07_0014 with dissolve
    mc "Remember what?"
    scene 07_0018 with dissolve
    vi "It was years ago... You were home on leave and had gotten yourself steaming drunk."
    scene 07_0019 with dissolve
    vi "I found you bawling your eyes out in the corner of our room."
    vi "At first, I thought you couldn't shake some awful event from deployment.\nWouldn't be the first time."
    vi "It took a while, but I eventually calmed you down."
    scene 07_0020 with dissolve
    vi "You'd never talk about the things you had to do just to survive a mission, so I'd never ask what's upsetting you."
    vi "I'd simply comfort you, hold you close."
    vi "But this time... you started talking."
    scene 07_0021 with dissolve
    vi "It was Cara's birthday that day. Her second, I think."
    vi "Alison had asked you to stay away; they'd wanted to celebrate as a family. You were devastated."
    scene 07_0022 with dissolve
    vi "And that night... you told me everything."
    vi "Poured your heart out - only time you ever did."
    scene 07_0023 with dissolve
    mc "Damn. I... I remember that night. Just not telling you."
    mc "If you've known all this time... why didn't we talk about it again?"
    scene 07_0024 with dissolve
    vi "You're kidding, right?"
    scene 07_0025 with dissolve
    vi "When have we {b}ever{/b} talked about something {b}you{/b} didn't want to discuss?"
    scene 07_0026 with dissolve
    vi "You bottle everything up. If I pushed, it turned into a fight."
    scene 07_0027 with dissolve
    vi "So I waited.\nI thought, when you were ready, you'd bring it up."
    vi "When you didn't..."
    scene 07_0025 with dissolve
    vi "I started to think maybe you didn't even remember telling me.\nSo I kept quiet."
    scene 07_0023 with dissolve
    mc "I'm sorry, Violet."
    scene 07_0028 with dissolve
    mc "You should've been able to talk to me about {i}anything{/i}."
    mc "I really was an ass sometimes."
    scene 07_0029 with dissolve
    vi "Sometimes. But not always."
    scene 07_0023 with dissolve
    mc "I don't know how you put up with me for so long."
    scene 07_0024 with dissolve
    $ dia = "Because you were my husband, and I " + ("love you." if Violet.L==4 else "loved you.")
    vi "[dia]"
    vi "You had your good moments too.\nNone of us is perfect."
    vi "What matters is you're trying now."
    scene 07_0030 with dissolve
    mc "I just wish I'd tried sooner."
    scene 07_0031 with dissolve
    mc "You deserved better from me. You all did."
    scene 07_0032 with dissolve
    vi "Maybe we're getting it now.\nThis is the second serious conversation we've had without even a raised voice."
    vi "I'm impressed![lol]"
    scene 07_0033 with dissolve
    vi "I'll make us some coffee."
    mc "Thanks."
    scene 07_0034 with fade
    mct "All those years I spent worrying about how to tell her... and I already had!"
    mct "I remember that day... kinda blurry."
    mct "Even drunk, it seems I managed to blame everyone but myself."
    scene 07_0035 with dissolve
    mct "Alison didn't ask me to stay away that day. She even encouraged me to visit Cara that morning."
    mct "They'd already made plans to go off and celebrate that afternoon as a family, but because I wasn't invited, I was pissed."
    mct "Just wanted to forget for a bit... But the more whisky I had, the more worked up I got."
    scene 07_0036 with dissolve
    mct "I was a mess by the time Violet came in. Don't remember us talking..."
    mct "... Just remember feeling her compassion, her love."
    scene 07_0037 with dissolve
    vi "So how did Cara take the news?\nIt must've come as a shock."
    scene 07_0038 with dissolve
    mc "She seems happy about it.\nBut then, she's had time to process it."
    scene 07_0039 with dissolve
    mc "We didn't know, but she actually found out a couple of years ago."
    mc "She overheard her Mom and Grandma discussing it."
    mc "She came to me a few days ago.\nWanted to tell me, but wasn't sure if I knew already."
    scene 07_0040 with dissolve
    vi "Oh jeez. You told her the truth, right?"
    scene 07_0041 with dissolve
    mc "Yeah... Mostly."
    mc "I told her it was a joint decision to keep it a secret.\nNo point in laying all the blame on Alison."
    mc "I explained the circumstances. She understood, I think."
    mc "I got the impression she was happy."
    scene 07_0042 with dissolve
    vi "{i}The impression{/i}?\nYou haven't spoken to her about it since?"
    scene 07_0043 with dissolve
    mc "Uhh... no.\nI was waiting for her to bring it up again..."
    mc "Yeah, I know... You don't need to say it.\nI'll talk to her."
    scene 07_0044 with dissolve
    vi "I like this new version of you."
    scene 07_0045 with dissolve
    mc "All that's left to do is tell Millie."
    mc "Think she'll be alright about it?"
    scene 07_0046 with dissolve
    vi "I think so. She's always loved Cara."
    vi "They rarely see each other these days, but they're constantly texting and calling."
    scene 07_0047 with dissolve
    vi "We'll find out soon enough.\nI sent her a message while I was making coffee to let her know you're here."
    vi "No doubt she'll be home in double-time! [lol]"
    scene 07_0048 with dissolve
    if Violet.L==4:
        mc "Do you want to talk about... the last time I was here?"
        vi "I don't underst-"
        vi "Oh, you're talking about us having sex."
        scene 07_0049 with dissolve
        mc "Yeah."
        mc "We were both pretty drunk."
        vi "Are you asking me if I regret it?"
        mc "Uh, yeah... I guess I am."
        scene 07_0047 with dissolve
        vi "Of course not.\nI wasn't {i}that{/i} drunk."
        scene 07_0050 with dissolve
        vi "Why? Do {i}you{/i}?"
        scene 07_0051 with dissolve
        mc "Hell no! It was great!\nI just don't want things to get awkward between us."
        scene 07_0052 with dissolve
        vi "It {b}was{/b} great!\nAnd I wouldn't complain if it were to happen again."
    else:
        mc "The sooner I can get it over with, the better. Heh."
    mil "I'm home!"
    scene 07_0053 with dissolve
    mil "DAD!"
    scene 07_0054 with dissolve
    mc "There's my girl!"
    scene 07_0055 with dissolve
    mil "[giggles]"
    scene 07_0056 with dissolve
    mil "This is a nice surprise!"
    if Violet.Has("I0") and Millie.hasScore(2) and persistent.Incest:
        scene 07_0057 with dissolve
        mil "I didn't know you were coming!"
        scene 07_0058 with dissolve
        vi "We need to talk to you, Sweetheart. That's why he's here today."
        scene 07_0059 with dissolve
    else:
        mil "I didn't know you were coming!"
        scene 07_0059 with dissolve
        vi "We need to talk to you, Sweetheart. That's why he's here today."
    mil "Am I in trouble?"
    scene 07_0060 with dissolve
    mc "[lol]\nNo, you're not in trouble."
    mc "I need to talk to you about... Cara."
    scene 07_0061 with dissolve
    mil "Cara?? Why?\nIs she okay?!"
    mc "Yes, she's fine.\nIt's just... I'm... She's..."
    mc "She's... your sister.\nI'm her dad. Her {i}real{/i} dad."
    scene 07_0062 with dissolve
    mil "WHAT?! {b}NO!{/b}"
    vi "Millie!"
    scene 07_0063 with dissolve
    mil "He's {b}MY{/b} dad, not {i}hers{/i}!"
    vi "He's {b}still{/b} your dad, too!"
    scene 07_0064 with dissolve
    mc "Millie!"
    mil "Leave me alone!"
    scene 07_0065 with dissolve
    mc "Fuck!"
    vi "I wasn't expecting her to react like that!"
    scene 07_0066 with dissolve
    mc "Damn it... I fucked it up again."
    scene 07_0067 with dissolve
    vi "Hey. You haven't fucked it up."
    vi "You did the right thing. She needed to know."
    scene 07_0068 with dissolve
    vi "Being a parent can be rough sometimes!"
    vi "You're doing okay."
    scene 07_0069 with dissolve
    vi "The {i}old you{/i} would be driving away right now, but you're still here."
    vi "Go and talk to her."
    scene 07_0070 with dissolve
    vi "Let her scream and shout at you if that's what she needs."
    vi "Stand your ground. Let her vent."
    scene 07_0071 with dissolve
    vi "Just be there for her."
    mc "Okay."
    scene 07_0072 with dissolve
    if Violet.isActive:
        mc "I don't deserve you. You know that, right?"
        vi "Yeah.[lol]"
    else:
        mc "Thanks, Vi."
    jump OakHill_TalkToMillie
return

label OakHill_TalkToMillie:
    scene 07_0073 with Fade(1, 2, 1)
    mct "Need to make this right... Somehow."
    play sound "knock.mp3"
    scene 07_0074 with dissolve
    mc "Millie?"
    scene 07_0075 with dissolve
    mc "Sweetheart, can I come in?"
    scene 07_0076 with dissolve
    mil "I thought you'd have left by now."
    mc "I made that mistake once; I won't do it again."
    scene 07_0077 with dissolve
    mil "I'm sorry, Dad. I didn't mean to yell at you."
    scene 07_0078 with dissolve
    mc "You have nothing to apologize for, Sweetie."
    scene 07_0079 with dissolve
    mc "Honestly, I'm just glad you didn't punch me!"
    scene 07_0080 with dissolve
    mil "Don't give me ideas!"
    scene 07_0081 with dissolve
    mc "Come here."
    scene 07_0082 with dissolve
    mc "I'm sorry, Millie."
    mc "I didn't mean to upset you.\nI thought you might even have been happy about it."
    scene 07_0083 with dissolve
    mil "I {i}am{/i} happy, Dad.\nCara's always been like a sister to me."
    mil "It's just... Uhh..."
    scene 07_0084 with dissolve
    mc "It's okay, you can tell me."
    mil "I guess... I'm a little jealous."
    mc "Why?"
    scene 07_0085 with dissolve
    mil "Because you live with her, and she gets to see you every day."
    mil "It's not fair!"
    scene 07_0086 with dissolve
    mil "And now she's your daughter, too?"
    mil "I just... I don't know... I felt special.\nBecause you were {i}MY{/i} dad."
    scene 07_0087 with dissolve
    mc "Sweetheart, you {b}are{/b} special!"
    mc "You'll {i}always{/i} be special to me."
    scene 07_0088 with dissolve
    mc "And me - {i}staying{/i} with them, it's not forever."
    mc "I want to get a place of my own. Closer to here. To you."
    scene 07_0089 with dissolve
    mil "You do?"
    mc "Yeah!\nAnd until then, I plan on visiting so often that you'll be tired of seeing me!"
    scene 07_0090 with dissolve
    mil "[lol]\nThat'll {i}never{/i} happen!"
    scene 07_0091 with dissolve
    mc "Tell you what... Why don't I stay over again tonight?"
    mc "We can spend the rest of the day together, just you and me."
    scene 07_0092 with dissolve
    mil "Really?!"
    mc "Yep! We can do whatever you want!"
    scene 07_0093 with dissolve
    mil "Horse riding!"
    mc "Uh... What?"
    mil "I want us to go horse riding!\nThere's a beautiful lake close to the trail. I love going there!"
    scene 07_0094 with dissolve
    mc "Can you even ride a horse??"
    mil "Yes!\nI go with Hannah all the time!"
    mc "Okay, horse riding it is!"
    scene 07_0095 with dissolve
    mil "YAY! It's gonna be so much fun!"
    scene 07_0096 with dissolve
    mil "I need to change! Can't go like this!"
    mc "Okay."
    mc "I'll go tell your mom our plan."
    if persistent.Incest and Millie.hasScore(2):
        scene 07_0097 with dissolve
        mil "You don't need to leave!"
        mil "I'm only changing into jeans.\nYou've already seen me in my underwear!"
        if not EzModeActive:
            menu:
                "Leave":
                    scene 07_0098 with dissolve
                    mc "No, you need your privacy. Meet you downstairs."
                    mil "Okay."
                    call OakHill_TalkToMillie_alt02
                "[wk_y]Stay":
                    call OakHill_TalkToMillie_alt01
        elif Millie.Has("EZ"):
            mc "Okay."
            call OakHill_TalkToMillie_alt01
        else:
            scene 07_0098 with dissolve
            mc "No, you need your privacy. Meet you downstairs."
            mil "Okay."
            call OakHill_TalkToMillie_alt02
    else:
        scene 07_0098 with dissolve
        mc "Meet you downstairs."
        mil "Okay."
        call OakHill_TalkToMillie_alt02
    jump OakHill_HorseRiding
return

label OakHill_TalkToMillie_alt01:
    $ Millie.L=2
    scene 07_0099 with dissolve
    mil "Good. I want to keep my eye on you."
    scene 07_0100 with dissolve
    mil "Make sure you don't sneak off..."
    scene 07_0101 with dissolve
    mil "...because you're too frightened to ride a horse.[lol]"
    mc "Hah! I'll have you know - I'm a pro at riding!"
    if persistent.UseFocus and not EzModeActive:
        $ _skipping = False
        show screen imgMap("images/e07/07_0102.webp", 825, 521, True, "OakHill_AF07") with dissolve
        mil "We'll see."
        $ _skipping = True
        if renpy.get_screen("imgMap"):
            scene 07_0102
            hide screen imgMap
    else:
        scene 07_0102 with dissolve
        mil "We'll see."
        call OakHill_AF07
    scene 07_0106 with dissolve
    mil "Actually, Dad... Should we invite Hannah?\nI bet she'd love to come with us."
    mc "Uh... I thought you wanted {i}us{/i} to spend time together?"
    mil "I do!"
    scene 07_0107 with dissolve
    mil "But, she's always telling me how she'd like to spend more time with you, too."
    scene 07_0108 with dissolve
    mil "I need to stop being selfish and learn to share you a bit.[lol]"
    scene 07_0109 with dissolve
    mc "What if I want to be selfish and have {b}you{/b} all to myself?"
    scene 07_0110 with dissolve
    mil "Well... Once you live closer, you can have me whenever you want!"
    scene 07_0109 with dissolve
    mc "Sweetheart, this is your day.\nIf you'd like to invite Hannah along, then of course, I don't mind."
    scene 07_0111 with dissolve
    mil "Great. I'll call her from the car!"
    if Millie.Has("CaughtYou") and Millie.Has("Taste"):
        scene 07_0112 with dissolve
        pause
        mil "Dad..."
        mil "Can I ask you something... kinda weird?"
        mc "Sure."
        scene 07_0112_01 with dissolve
        mil "Remember when you told me you liked the taste of my fingers?..."
        mc "Uhh... Yeah."
        mil "Did you... Umm..."
        mil "... did you know... what you were tasting?"
        $ tCh=True
        if not EzModeActive:
            menu:
                "No, what was it?":
                    $ tCh=False
                "[wk_y]I knew exactly what I was tasting":
                    pass
        else:
            mc "I knew exactly what I was tasting."
        if tCh:
            $ Millie.L=3
            call MillieReplay02
        else:
            scene 07_0112_02 with dissolve
            mil "Ohh... Umm, nothing."
            scene 07_0131 with dissolve
            mct "Need her to stop doing that. Don't want to encourage her."
    scene 07_0131 with dissolve
    mct "It'll be good to spend a little time with Hannah.\nPromised her I would, after all!"
    scene 07_0132 with Fade(1, 1, 0.5)
    mil "Okay, let's go!"
    scene 07_0149 with Fade(1, 2, 1)
    vi "This is an encouraging sign!"
    mc "We're goin' horse riding, heh."
    scene 07_0134 with dissolve
    vi "That's great!"
    vi "I'm so pleased you're both friends again!"
    scene 07_0150 with dissolve
    mc "Mind if I stay here tonight?"
    vi "Not at all!\nYou're welcome to stay whenever you want."
    mc "Great. Thanks."
    scene 07_0151 with dissolve
    mc "You wanna join us?"
    mil "[lol]"
    scene 07_0152 with dissolve
    vi "Nope![lol]"
    vi "She goes riding a lot with Hannah.\nI made the mistake of tagging along once - Never again!"
    vi "Let's just say, horses and me - not compatible!"
    scene 07_0148 with dissolve
    mc "Heh. Fair enough.\nSee you later then."
    mil "Bye Mom!"
    vi "Bye. Have a wonderful time, guys!"
return

label OakHill_TalkToMillie_alt02:
    scene 07_0133 with Fade(1, 2, 1)
    vi "How'd it go?\nI didn't hear any shouting."
    mc "We're going horse riding!"
    scene 07_0134 with dissolve
    vi "[mc]! That's great!"
    vi "I'm so pleased!"
    scene 07_0135 with dissolve
    mc "Mind if I stay tonight?\nI kinda promised her I would."
    vi "Not at all!\nYou're welcome to stay here whenever you want."
    mc "Thanks."
    scene 07_0136 with dissolve
    vi "Horse riding... So, bribery, huh?"
    mc "[lol] No!"
    mc "She was okay.\nThe news came as a bit of a shock, that's all."
    scene 07_0137 with dissolve
    mc "We hugged it out, and I asked if she'd like us to spend the day together."
    mc "Horse riding wasn't {i}my{/i} idea![lol]"
    scene 07_0138 with dissolve
    vi "[lol]"
    vi "She goes riding a lot with Hannah.\nI made the mistake of tagging along once - Never again!"
    vi "Let's just say, horses and me - not compatible!"
    scene 07_0139 with dissolve
    mil "I'm ready!"
    scene 07_0140 with dissolve
    vi "Have lots of fun, guys!"
    mil "Dad - I was thinking..."
    scene 07_0141 with dissolve
    mil "Should we invite Hannah?\nI bet she'd love to come with us."
    mc "Uh... I thought you wanted {i}us{/i} to spend time together?"
    scene 07_0142 with dissolve
    mil "Yeah, I do!"
    mil "But, she's always telling me how she'd like to spend more time with you, too."
    scene 07_0143 with dissolve
    mil "I need to stop being selfish and learn to share you a bit.[lol]"
    scene 07_0144 with dissolve
    vi "That's sweet, Millie!"
    mc "But what if I want to be selfish and have {b}you{/b} all to myself?"
    scene 07_0145 with dissolve
    mil "Well... Once you live closer, I can be all yours whenever you want!"
    scene 07_0146 with dissolve
    vi "Ouch... She has you there."
    mc "Yep.[lol]"
    scene 07_0147 with dissolve
    mc "Sweetheart, this is your day.\nIf you'd like to invite Hannah along, then of course, I don't mind."
    mil "Great. I'll call her from the car!\nLet's go!"
    scene 07_0148 with dissolve
    mc "Plenty of room in the truck if you wanna come? Heh."
    vi "[lol] I'm good, thanks.\nHave a wonderful time, guys!"
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
