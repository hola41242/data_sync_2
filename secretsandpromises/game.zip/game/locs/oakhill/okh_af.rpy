label OakHill_AF01:
    scene 02_0689
    hide screen imgMap
    $ _skipping = True
    scene 02_0690 with dissolve
    mc "You look... great."
    $ Violet.Score(1)
    vi h "Thanks!"
    scene 02_0691 with dissolve
    vi "Still the same old charmer, I see!"
return

label OakHill_AF02:
    scene 02_0792
    hide screen imgMap
    $ _skipping = True
    scene 02_0793 with dissolve
    mct "Hot as hell, too! Heh."
    $ a = False
    if persistent.UseFocus and not EzModeActive:
        menu:
            "[wk_y]Lift her top higher":
                $ a = True
            "Leave":
                pass
    else:
        $ a = True
    if a:
        $ Millie.Add("Top")
        scene 02_0794 with dissolve
        call Emotion (mct, "Sigh", "I know I shouldn't...")
        scene 02_0795 with dissolve
        pause 1.0
        call Emotion (mil, "Groan", "", True)
        mct "Shit! {w=1}{nw}"
        scene 02_0796 with dissolve
        mct "Okay."
return

label OakHill_AF03:
    scene 02_0797
    hide screen imgMap
    $ _skipping = True
    scene 02_0798 with dissolve
    mct "Hmm... Think I'm about to break an unwritten rule..."
    scene 02_0799 with dissolve
    $ Millie.Add("SawPic")
    mct "Awww!\nShe has a picture of ME! Didn't expect that!"
    call Emotion (mil, "Groan", "", True)
    mct "Okay, no more snooping. Better get outta here! Heh."
return

label OakHill_AF04:
    scene 02_0724
    hide screen imgMap
    $ _skipping = True
    scene 02_0725 with dissolve
    mct "Is that the faint scent of her pussy I can smell on her fingers?"
    $ tCh=None
    if not EzModeActive:
        menu:
            "[wk_y]Taste her":
                $ tCh=True
            "Don't":
                pass
    if tCh or EzModeActive:
        scene 02_0726 with dis1
        scene 02_0727 with dis1
        pause 0.5
        scene 02_0728 with dissolve
        mil "[whi]What... are you doing?!"
        scene 02_0729 with dissolve
        mc "Shit, I'm Sorry!"
        mc "I don't know what's wrong with me lately!\nIt sometimes feels like someone else is controlling me!"
        mc "I guess... They smell nice! I wanted to see if they taste nice, too."
        mil "[whi]... Umm... okay?"
        scene 02_0730 with dissolve
        mil "[whi]......{size=*.8}do they?"
        $ tCh=None
        if not EzModeActive:
            menu:
                "No, not really":
                    pass
                "[wk_y]Yeah":
                    $ tCh=True
        if tCh or EzModeActive:
            mc "Yeah."
            $ Millie.Score(2)
            $ Millie.Add("Taste")
            scene 02_0732 with dissolve
            pause 0.5 
        else:
            $ Millie.Score(-2)
            scene 02_0731 with dissolve
            pause 0.5
return

label OakHill_AF05:
    scene 04_0052
    hide screen imgMap
    $ _skipping = True
    call ScanImage ("images/e04/04_0053.webp")
    $ Violet.Score(1)
    mc "Damn!"
    mc "You look amazing, Vi!"
    scene 04_0054 with dissolve
return

label OakHill_AF06:
    scene 04_0439
    hide screen imgMap
    $ _skipping = True
    $ Hannah.Score(1)
    scene 04_0440a with dissolve
    mc "[lol]"
    scene 04_0441 with dissolve
    pause
    scene 04_0442 with dissolve
    pause
return

label OakHill_AF07:
    $ Millie.Add("CaughtYou")
    scene 07_0102
    hide screen imgMap
    $ _skipping = True
    scene 07_0103 with dissolve
    pause
    scene 07_0104 with dissolve
    mil "Are you keeping an eye on me too, Daddy?"
    mc "Huh? No!... Err... Sorry."
    scene 07_0105 with dissolve
    mil "[giggles]"
return

label OakHill_AF08:
    $ Lucy.Score(1)
    $ Lucy.Add("Ass")
    scene 12_0363
    hide screen imgMap
    $ _skipping = True
    scene 12_0364 with dissolve
    pause
    scene 12_0365 with dissolve
    pause
    scene 12_0366 with dissolve
    luc "[mc!u]!"
    scene 12_0367 with dissolve
    luc "What the hell are you doing?!"
    mc "Shit! I'm sorry, Sis!"
    mc "I hug a beautiful woman with a sexy ass, and instinct kicks in!"
    scene 12_0368 with dissolve
    luc "I'm your {b}sister{/b}!"
    mc "I know! Sorry!"
    scene 12_0369 with dissolve
    luc "Ohh..."
    luc "... This is your fucked up way of trying to cheer me up and pay me a compliment, isn't it?"
    mc "Kinda backfired on me, huh?"
    scene 12_0370 with dissolve
    luc "Sorry. I sometimes forget that you're an idiot."
    scene 12_0363 with dissolve
    luc "I love you, [mc]."
    mc "I love you too, Sis."
return

label OakHill_AF09:
    scene 15_0139
    hide screen imgMap
    $ _skipping = True
    scene 15_0140 with dissolve
    scene 15_0141 with dis1
    mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
    luc "Yes, of course."
    scene 15_0142 with dis1
    mc "Thanks, Sis."
    if Lucy.Has("Ass"):
        $ Lucy.Add("Ass2")
        $ Lucy.Del("Ass")
        scene 15_0148 with dis1
        luc "[mc]!"
        luc "You're doing it again."
        scene 15_0149 with dis1
        mc "Sorry."
        scene 15_0150 with dissolve
        luc "I forgive you. And I kinda get it, you know.\nIt's sometimes easy to forget that you're my brother when you hold me like this."
        scene 15_0151 with dissolve
        pause
        scene 15_0152 with dissolve
        pause
    else:
        $ Lucy.Add("Ass")
        scene 15_0143 with dissolve
        luc "[mc!u]!"
        scene 15_0144 with dissolve
        luc "What the hell are you doing?!"
        mc "Shit! I'm sorry, Sis!\nI wasn't thinking!"
        mc "I hug a beautiful woman with a sexy ass, and instinct kicks in!"
        scene 15_0145 with dissolve
        luc "I'm your {b}sister{/b}!"
        mc "I know!"
        mc "Like I said, I was just enjoying the moment and wasn't thinking.\nSorry."
        scene 15_0146 with dissolve
        luc "... Okay."
        luc "Maybe I overreacted."
        luc "I {b}will{/b} take the compliment, though."
        scene 15_0147 with dissolve
        luc "I'm sorry, too.\nIt sometimes slips my mind that you're an idiot."
return

label OakHill_AF10:
    scene 15_0160
    hide screen imgMap
    $ _skipping = True
    scene 15_0161 with dissolve
    scene 15_0162 with dis1
    mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
    luc "Yes, of course."
    scene 15_0163 with dis1
    mc "Thanks, Sis."
    if Lucy.Has("Ass"):
        $ Lucy.Add("Ass2")
        $ Lucy.Del("Ass")
        scene 15_0164 with dis1
        luc "[mc]!"
        luc "You're doing it again."
        scene 15_0165 with dis1
        mc "Sorry."
        scene 15_0166 with dissolve
        luc "I forgive you. And I kinda get it, you know.\nIt's sometimes easy to forget that you're my brother when you hold me like this."
        scene 15_0167 with dissolve
        pause
        scene 15_0168 with dissolve
        pause
    else:
        $ Lucy.Add("Ass")
        scene 15_0171 with dissolve
        luc "[mc!u]!"
        scene 15_0172 with dissolve
        luc "What the hell are you doing?!"
        mc "Shit! I'm sorry, Sis!\nI wasn't thinking!"
        mc "I hug a beautiful woman with a sexy ass, and instinct kicks in!"
        scene 15_0173 with dissolve
        luc "I'm your {b}sister{/b}!"
        mc "I know!"
        mc "Like I said, I was just enjoying the moment and wasn't thinking.\nSorry."
        scene 15_0174 with dissolve
        luc "... Okay."
        luc "Maybe I overreacted."
        luc "I {b}will{/b} take the compliment, though."
        scene 15_0175 with dissolve
        luc "I'm sorry, too.\nIt sometimes slips my mind that you're an idiot."
return

label OakHill_AF11:
    scene 15_0213
    hide screen imgMap
    $ _skipping = True
    $ Lucy.L=1
    scene 15_0215 with dissolve
    luc "[mc], I can reach there myself!"
    mc "Yeah, I know... But I have the cream all over my hands..."
    scene 15_0216 with dis1
    mc "No point wasting it."
    scene 15_0217 with dissolve
    pause 0.5
    scene 15_0218 with dis1
    mct "Okay... I'm liking this more than I should."
    scene 15_0219 with dissolve
    mct "... She's not stopping me... is she enjoying it, too?..."
    call AutoA (True)
    scene 15_0220 with dis1
    $ apause()
    scene 15_0221 with dis1
    $ apause()
    scene 15_0222 with dis1
    $ apause()
    scene 15_0223 with dis1
    $ apause()
    scene 15_0224 with dis1
    $ apause()
    scene 15_0225 with dis1
    $ apause()
    scene 15_0226 with dis1
    $ apause(0.5, True)
    scene 15_0227 with dis1
    luc "Whoa... Are you forgetting I'm your sister again?"
    scene 15_0228 with dis1
    mc "Sorry, just making sure you're protected all over."
    mc "And no, I didn't forget..."
    mc "It's just... For a moment, I... didn't care."
    scene 15_0229 with dis1
    luc "[whi]Yeah, I know what you mean."
return

label OakHill_AF12:
    scene 18_0074
    hide screen imgMap
    $ _skipping = True
    $ Lucy.act=True
    scene 18_0075 with dis1
    luc "How's Vi today? She seemed nervous about seeing Alison again."
    mc "Alison was exactly the same."
    mc "As soon as they saw each other they were fine."
    luc "That's good."
    scene 18_0076 with dissolve
    mc "This has to be one of the longest hugs we've ever had."
    luc "Is that a complaint?"
    scene 18_0077 with dis1
    mc "Not at all."
    luc "I'm glad."
    scene 18_0078 with dissolve
    luc "I've come to enjoy these little moments between us."
    scene 18_0079 with dissolve
    mc "Yeah, me too."
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
