label OakHill_05_WaitingForLucy:
    scene 15_0128 with fade2
    pause 0.5
    scene 15_0129 with dis1
    pause
    scene 15_0130 with dissolve
    pause
    luc "Let me guess..."
    scene 15_0131 with dissolve
    luc "You didn't let anyone know you were coming... again!"
    mc "Hey Sis."
    scene 15_0132 with dissolve
    mc "Yeah, you'd think I'd have learned my lesson by now, huh?"
    scene 15_0133 with dissolve
    luc "If it were anyone else, I'd agree."
    scene 15_0134 with dissolve
    luc "So? You're not going to greet your sister?"
    scene 15_0135 with dis1
    scene 15_0136 with dis1
    scene 15_0137 with dis1
    mc "'Course I am!"
    scene 15_0138 with dissolve
    luc "Violet's away visiting her mother."
    luc "Had you called first, you wouldn't have wasted your time."
    scene 15_0139 with dissolve
    mc "It's not a waste of time; I still get to see you and Hannah."
    if persistent.Incest and Lucy.hasScore(2):
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e15/15_0139.webp", 888, 748, True, "OakHill_AF09")
            luc "I suppose."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 15_0139
                hide screen imgMap
                mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
                luc "Yes, of course."
        else:
            luc "I suppose."
            $ tCh=Lucy.Has("EZ")
            if not EzModeActive:
                menu:
                    "[wk_y]Move your hand down":
                        $ tCh=True
                    "Leave it where it is":
                        $ tCh=False
            if tCh:
                call OakHill_AF09
            else:
                mc "Millie said they'll be back tomorrow. I was hoping I could stay here tonight."
                luc "Yes, of course."
    else:
        call CloseCharacterPath (Lucy)
    scene 15_0153 with dissolve
    luc "I'm going to get changed."
    mc "Changed? Why?"
    scene 15_0154 with dissolve
    luc "It's a beautiful day, and I intend to make the most of what's left of it."
    jump OakHill_05_RelaxWithLucy
return

label OakHill_05_RelaxWithLucy:
    scene 15_0176 with Fade(1, 2, 2)
    luc "[whi]Mmmh."
    scene 15_0177 with dissolve
    pause
    scene 15_0178 with dissolve
    luc "Can I ask you something?"
    mc "Sure."
    luc "What did you do with your half of the money?"
    scene 15_0179 with dissolve
    mc "What money?"
    luc "From the sale of Mom's house."
    mc "Why? Do you need some?"
    luc "No, of course not. I was just curious."
    scene 15_0180 with dissolve
    luc "It was a big house, and we sold it for a reasonable price."
    luc "It's enough for you to put down a serious deposit on a place of your own... if you still have it."
    mc "I still have it."
    mc "Bought the truck, but otherwise I ain't touched it."
    scene 15_0181 with dissolve
    luc "So why are you still living in Springhaven?"
    luc "Violet told me about the promise you made to Millie."
    scene 15_0182 with dissolve
    mc "What promise?"
    luc "That you were going to move down here, or closer at least."
    luc "Was it bullshit?\nJust telling her something she wanted to hear?"
    mc "No!"
    scene 15_0183 with dissolve
    luc "Don't make the same mistakes as before, [mc]."
    luc "Just be honest with her, with {i}them{/i}.\nEven if it {b}isn't{/b} what they want to hear."
    luc "It's not only about Violet and Millie, either."
    luc "Hannah enjoys having you back in her life, and honestly, so do I."
    scene 15_0184 with dissolve
    mc "It {b}wasn't{/b} bullshit, Lucy."
    mc "I have some... unfinished business... in Springhaven."
    mc "Once that's been taken care of, I'll be keeping my promise to Millie."
    scene 15_0185 with dissolve
    luc "Okay then. I'm glad."
    luc "That's all you had to say."
    scene 15_0186 with dissolve
    luc "Why are you sunbathing in your jeans?"
    mc "I didn't bring shorts."
    luc "Jeez!"
    scene 15_0187 with dissolve
    luc "You're wearing underwear, right?"
    luc "How many times have we been to the beach together? Or swimming?"
    luc "No need to be so modest in front of me!"
    scene 15_0188 with dissolve
    mc "Actually, I was thinking more about Hannah."
    luc "Han??"
    luc "Oh, don't worry, she never joins me out here."
    luc "Anyway, she was always with us at the beach!\nNothing she hasn't seen before either."
    luc "It's too damn hot for jeans! Take them off and relax."
    scene 15_0189 with fade1
    pause
    scene 15_0190 with fade1
    pause
    scene 15_0191 with dissolve
    han "This is where you're both hiding!"
    luc "Nobody's hiding, Sweetheart.\nWe're simply enjoying the sunshine."
    luc "You're more than welcome to join us."
    scene 15_0192 with dissolve
    han "Nah, I'm good."
    scene 15_0194 with dissolve
    han "When are we gonna eat? I'm starving!"
    luc "I'll make something soon."
    scene 15_0195 with dissolve
    luc "Told you."
    mc "C'mon Sis. We were the same with Mom!\nIt's {b}never{/b} been cool to hang out with a parent!"
    scene 15_0196 with dissolve
    luc "Yeah... You're right."
    luc "I just miss her.\nWe used to do so much together when she was younger."
    scene 15_0197 with dissolve
    luc "I suppose she's reached the age where she no longer needs me."
    scene 15_0198 with dissolve
    mc "Wow! Do you hear yourself?\nI actually thought you were Mom for a second!"
    luc "God... I thought the same before the words had even finished leaving my mouth!"
    scene 15_0199 with dissolve
    luc "[lol]"
    if Lucy.isActive():
        scene 15_0200 with dissolve
        luc "I'll make you a deal..."
        luc "I'll stop being a moaning minnie... or {i}Mom{/i}..."
        scene 15_0201 with dissolve
        luc "If you cream my back."
        mc "Sis, I'd eat the damn stuff if it'll stop you moaning!"
        luc "[lol]"
        scene 15_0202 with dissolve
        luc "How are you finding civilian life?"
        scene 15_0203 with dissolve
        mc "Still adjusting."
        luc "Do you regret leaving?"
        scene 15_0204 with dissolve
        mc "I regret not leaving sooner."
        luc "I'm relieved you're out.\nI was {i}always{/i} worried about you."
        scene 15_0205 with dissolve
        luc "Never knowing where you were. If you were safe or not."
        luc "We may not have been very close, but you were still my brother."
        scene 15_0206 with dissolve
        mc "It was worth it in the end though, right?"
        mc "I'm home now, and look at us.\nWe're closer than we've ever been, and I'm practically about to give you a massage!"
        mc "Who thought that would happen?!"
        scene 15_0207 with dissolve
        luc "Very true!"
        scene 15_0208 with dissolve
        luc "So stop talking and let me enjoy it!"
        scene 15_0209 with dissolve
        mc "Yes Ma'am."
        scene 15_0210 with dis1
        scene 15_0211 with dis1
        luc "I didn't expect you to have such a delicate touch!"
        scene 15_0212 with dissolve
        mc "Okay, you got me... I never {i}really{/i} signed up for the military."
        mc "I ran away to Thailand and trained as a master masseuse."
        luc "[lol]"
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e15/15_0213.webp", 1472, 405, True, "OakHill_AF11") with dissolve
            luc "[whi]Mmhh... I could get used to this."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 15_0213
                hide screen imgMap
                scene 15_0214 with dissolve
                pause 
        else:
            scene 15_0213 with dissolve
            luc "[whi]Mmhh... I could get used to this."
            if not EzModeActive:
                menu:
                    "[wk_y]Massage her butt":
                        call OakHill_AF11
                    "Continue on her back":
                        scene 15_0214 with dissolve
                        pause
            elif Lucy.Has("EZ"):
                call OakHill_AF11
        scene 15_0230 with dissolve
        luc "Thanks.\nDon't let me fall asleep out here."
        mc "Okay."
    scene 15_0231 with fade1
    pause
    scene 15_0232 with Fade(1, 2, 1)
    pause
    scene 15_0233 with Fade(1, 2, 1)
    mc "[whi]..Zzz.."
    scene 15_0234 with dissolve
    han "[whi]Uncle [mc]?"
    scene 15_0235 with dissolve
    mc "[whi]Hey."
    han "Your supper's getting cold."
    han "Mom tried to wake you earlier."
    scene 15_0236 with dissolve
    call Emotion (mc, "Groan", "Sorry.")
    scene 15_0237 with dissolve
    han "I was thinking... Can we do movie night again?"
    han "It was fun last time; I liked that we all spent time together."
    mc "Sure we can, Sweetheart."
    scene 15_0238 with dissolve
    han "Cool! I'll go find us something good to watch."
    mc "Please, Han... No chick-flicks!"
    scene black with Fade(3, 1,0)
    jump OakHill_05_RelaxWithLucyEvening
return

label OakHill_05_RelaxWithLucyEvening:
    call CenterText ("Later that evening...")
    scene 15_0239 with fade
    mc "Hey.\nYour mom not joining us?"
    scene 15_0240 with dissolve
    han "Yeah, she is."
    han "She's putting on her PJs first."
    scene 15_0241 with dissolve
    mc "Things getting any better between you both?"
    han "Yes, actually."
    han "And I doubt it's just a coincidence.\nSo, whatever you said to her - thanks."
    scene 15_0242 with dissolve
    mc "I didn't say much."
    han "You could've chosen to say nothing, but you didn't.\nYou stood up for me."
    mc "Of course I did. I'll always have your back, Han."
    scene 15_0243 with dissolve
    han "That right there."
    han "That's why you've always been my favorite uncle!"
    scene 15_0244 with dissolve
    mc "Aww, and you're my fav--"
    mc "Wait a minute... Your dad's an only child, isn't he??"
    mc "So I'm your {b}ONLY{/b} uncle!"
    scene 15_0245 with dissolve
    han "[lol]"
    scene 15_0246 with dissolve
    han "My {b}favorite{/b} only uncle!"
    if persistent.Incest and Hannah.Has("Knows") and Millie.isSexual():
        scene 15_0247 with dissolve
        han "Hey, I'm glad you took my advice with Millie."
        mc "What advice?"
        han "To give her what she wanted!"
        mc "Ohh... right."
        mc "So... she told you?"
        scene 15_0248 with dissolve
        han "You kidding me? She hasn't shut up about it!"
        mc "She okay though?\nI ain't really had a chance to speak to her about it since."
        scene 15_0249 with dissolve
        han "You don't need to worry about her, Unc."
        han "She doesn't regret any of it.\nShe's wanted it to happen for so long."
        scene 15_0250 with dissolve
        han "Every time I see her, she has a goofy grin permanently etched on her face."
        han "She's so damn happy!\nYou did good."
    scene 15_0251 with dissolve
    luc "Sorry for keeping you."
    scene 15_0252 with dissolve
    han "We ready?"
    luc "Yes."
    scene black with Fade(2, 2, 0)
    call CenterText ("One movie later...")
    scene 15_0253 with Fade(0, 1, 2)
    mc "Okay... I could've sworn I said {i}no chick-flicks{/i}!"
    han "You did... but I know you didn't {i}mean{/i} it!"
    scene 15_0254 with dissolve
    mc "Lucy?"
    han "She still sleeping? Don't think she watched even five minutes of it!"
    luc "[whi]..Zzz.."
    scene 15_0255
    han "{b}MOM!{/b}" with hpunch
    call Emotion (luc, "GASP", "WHAT?!")
    scene 15_0256 with dissolve
    luc "Sorry... I think I dozed off for a moment."
    han "[lol]"
    scene 15_0257 with dissolve
    luc "I'm heading to bed; I can't keep my eyes open!"
    mc "Yeah, sounds like a plan. I'm pretty tired now, too."
    scene 15_0258 with fade2
    mct "Had a good time today chillin' with Lucy."
    scene 15_0259 with dissolve
    play sound "knock.mp3" volume 0.3
    mct "Wish I'd made more of an effort with her {b}years{/b} ago."
    scene 15_0260 with dissolve
    mc "Uhh... Yeah?"
    scene 15_0261 with dissolve
    han "Hey.\nJust came to say goodnight."
    scene 15_0262 with dissolve
    han "Sorry about the smell in there. I have a gross pig for a brother."
    scene 15_0263 with dissolve
    mc "Heh. I didn't even notice."
    mc "Some of the barracks I've had to stay at... The smell would make your eyes water! You'd be horrified!"
    han "[lol]"
    han "Okay, goodnight Unc."
    mc "Night Sweetheart."
    scene 15_0264 with dis1
    scene 15_0265 with dissolve
    mct "Hah... Course I noticed!"
    scene 15_0266 with dissolve
    mct "Seriously... What the hell {b}has{/b} he been doing in here??"
    if Hannah.isActive():
        call HannahReplay01_P2
    else:
        scene 15_0267 with dissolve
        pause 0.5
        scene 15_0268 with dissolve
        pause 0.5
        scene 15_0269 with fade1
        mc "[whi]...Zzz..."
    scene 15_0370 with Fade(2, 4, 2)
    mc "Mornin', Sis."
    luc "Good, you're awake."
    scene 15_0371 with dissolve
    luc "I need to get to work, but wanted to say goodbye first."
    mc "Millie messaged me. They're on their way home, but it'll be a few hours."
    scene 15_0372 with dissolve
    luc "I'm not throwing you out, [mc].\nYou're more than welcome to hang out here until they get back."
    mc "Thanks.\nAlways happy to spend more time with Hannah!"
    luc "Hannah's at college today.\nYou'll have to keep yourself company, I'm afraid."
    scene 15_0373 with dissolve
    luc "I have an incredibly busy few days ahead with work.\nWe may not see each other before you leave town again."
    luc "I just wanted to say thank you."
    mc "For what?"
    scene 15_0374 with dissolve
    luc "I know we didn't do a lot yesterday, but still, I enjoyed our time together."
    luc "I find myself starting to look forward to your visits."
    scene 15_0375 with dissolve
    luc "So don't disappoint the {i}ice queen{/i}. Come back soon."
    mc "Damn, is there anything Vi {i}doesn't{/i} tell you?!"
    scene 15_0376 with dissolve
    luc "Not when it comes to you.\nYou're our favorite topic of conversation these days."
    scene 15_0377 with dissolve
    luc "Sorry, but I really need to get going."
    scene 15_0378 with dissolve
    mc "I'll see you soon, Sis."
    scene 15_0379 with dissolve
    luc "[whi]Good."
    scene 15_0380 with fade2
    mct "Damn, Lucy!\nDidn't know you were into raunchy shit like this! Heh."
    scene 15_0381 with fade2
    mct "No! Don't take his bullshit!"
    play sound "vib.mp3"
    mct "Leave him! Get the hell out, girl!!"
    scene 15_0382 with dissolve
    stop sound
    mil cell "Hey Dad, we're home!"
    mc cell "Great! I'm on my way, Sweetie."
    jump OakHill_05_VisitMillie
return

label OakHill_05_VisitMillie:
    scene 15_0383 with fade2
    pause
    scene 15_0384 with fade
    mil "Mom's taking a shower."
    scene 15_0385 with dissolve
    mc "She's still a nervous driver, huh?"
    mil "Sweats like a pig."
    scene 15_0386 with dissolve
    mil "Sorry we weren't here yesterday."
    scene 15_0387 with dissolve
    mc "Nah, It's my own fault!\nI should've let you know I was coming, Sweetie."
    mc "No more surprise visits.\nFrom now on I'll give you a heads-up before traveling."
    scene 15_0388 with dissolve
    mil "I love when you show up unexpectedly, Dad.\nBut it's a long way to come if we're not here!"
    mil "So maybe, next time, just check with Mom first."
    scene 15_0389 with dissolve
    mc "You got it, Boss."
    scene 15_0390 with dissolve
    mil "I like the sound of that!"
    mil "Does this mean I get to order you around and tell you what to do?"
    mc "Isn't that how it's {i}always{/i} been??"
    scene 15_0391 with dissolve
    mil "Ohh, Daddy... It could be so much worse!"
    scene 15_0392 with dissolve
    mil "For starters, I'd tell you that you're not allowed to leave town today; you {b}have{/b} to stay the night!"
    mc "Well... If that's the boss's orders."
    scene 15_0393 with dissolve
    mil "Wait... Really?!"
    mc "Yup."
    scene 15_0394 with dissolve
    mil "Awesome!"
    mil "You're always so busy and usually can only stay in town for one night."
    mil "I thought you'd have to leave soon!"
    scene 15_0395 with dissolve
    mc "Screw everything else.\nSpending time with you is more important to me, Millie."
    mil "I love you."
    mc "I love you too."
    if not Millie.isSexual():
        call CloseCharacterPath (Millie)
    if persistent.Incest and Millie.isSexual():
        scene 15_0396 with dissolve
        mil "Are we okay though, Dad?"
        mc "Yeah, of course. Why?"
        mil "I've been worried you regretted doing what we did."
        scene 15_0397 with dissolve
        mc "No, Sweetheart."
        mc "I was worried that's how {i}you'd{/i} be feeling, too."
        scene 15_0398 with dissolve
        mil "Dad, there's no way I'll {b}ever{/b} regret it."
        mil "The only thing I'd regret is {i}not{/i} doing it again."
        scene 15_0399 with dissolve
        mil "I loved every second of it."
        scene 15_0400 with dissolve
        mil "We had sex, Dad."
        mil "It was the best moment of my life."
        scene 15_0401 with dissolve
        mil "[whi]Mmhh."
        scene 15_0402 with dissolve
        pause
        scene 15_0403 with dissolve
        mil "[whi]..Mmmhhhh.."
        scene 15_0404 with dissolve
        mil "Now... As your boss, I'm ordering you to fuck your daughter again before you leave town."
        mc "Yes, Ma'am."
    scene 15_0405 with dissolve
    mil "Did you have fun staying with Aunt Lucy?"
    mc "Yeah, I kinda did!"
    scene 15_0406 with dissolve
    if persistent.Incest and Hannah.Has("Knows") and Hannah.isSexual():
        mil "Good. Hannah told me she had fun, too."
        mc "Uhh... She did?"
        scene 15_0407 with dissolve
        mil "Yeah."
        mil "She said she was glad you didn't try to stick it in, though!"
        scene 15_0408 with dissolve
        mc "Sorry, Sweetheart.\nWe just got carried away with that little game we play."
        mc "I pushed it too far."
        scene 15_0409 with dissolve
        mil "Why?\nDon't you want to have sex with her?"
        mc "I know I'm supposed to say no here... But I don't want to lie to you, Millie."
        mc "It doesn't matter anyway.\nBy the sounds of it, she doesn't, so there's nothing to worry about."
        scene 15_0410 with dissolve
        mil "You're wrong."
        mil "She was glad you didn't try because she said she would've let you, and she didn't want to lose her virginity in her brother's bed."
        scene 15_0411 with dissolve
        mil "Wait... Do you think I'm mad at you?"
        mil "Because I'm not."
        scene 15_0412 with dissolve
        mil "If it was up to me, I'd want you to fuck her."
        mc "Why??"
        scene 15_0413 with dissolve
        mil "She loves you like I love you, Daddy."
        if Cara.isSexual():
            mil "Like Cara loves you."
            scene 15_0414 with dissolve
            mil "I'd like to have you all to myself, sure.\nBut Dad, it wouldn't be fair to them, would it?"
            scene 15_0415 with dissolve
            mil "I'd be devastated if you chose one of them over me!"
            mil "And I'm pretty sure they'd feel the same way if you chose me over them."
            scene 15_0416 with dissolve
            mil "So yeah, honestly, if it was up to me, you'd fuck us all."
            scene 15_0417 with dissolve
            mc "Is that why you told Cara what we did?"
            mc "She told me how you tried to encourage her to sleep with me."
            mil "C'mon, Dad, I know you're {i}already{/i} doing that."
            mil "I was trying to get her to {b}admit{/b} it."
            mc "Why?"
            scene 15_0418 with dissolve
            mil "She's my sister!"
            mil "I know we both feel the same way.\nIt'd be nice to talk to her about it."
            mil "You just said you won't lie to me.\nSo tell me, Dad, you already fucked her, didn't you?"
            scene 15_0419 with dissolve
            mc "[whi]Fuck."
            mc "Yeah, I did. But listen, you can't tell anyone else."
            mc "This is just between us."
            mc "How did you know?"
            scene 15_0420 with dissolve
            mil "She called me.\nWe were chatting for about an hour, and then, as usual, we ended up talking about you."
            mil "I wasn't going to say anything, but... I don't know... The way she was talking about you seemed different..."
            mil "Something had changed.\nThey were only little, innocuous comments... but enough for me to put two and two together."
            scene 15_0421 with dissolve
            mil "I knew you'd be mad if I told her, especially if I was wrong!"
            mil "But I couldn't stop myself... I was {b}so{/b} sure I was right."
            mil "I didn't tell her we'd actually done anything to begin with."
            scene 15_0422 with dissolve
            mil "I started by suggesting it was just something {b}I'd{/b} like to do."
            mil "She wasn't shocked or disgusted.\nThe more I talked about it... she seemed to be getting a kick out of the conversation, too."
            mil "I could tell she felt the same; she just wouldn't admit it."
            scene 15_0423 with dissolve
            mil "I was getting frustrated with her holding back..."
            mil "That's when I told her.\nThe line went quiet for a few seconds... and I started to panic."
            scene 15_0424 with dissolve
            mil "But then she started teasing me, calling me {i}Daddy's little slut{/i}."
            mil "We laughed and joked about it for a while... I knew though, she was dying to tell me she'd had sex with you, too."
            mil "She came close to spilling once or twice, but stopped herself. Probably because she was worried about your reaction."
            scene 15_0425 with dissolve
            mc "Yeah. She told me that."
            mc "She did want to tell you, but she thought it best to get the okay from me first."
            mil "Sorry, Dad. I should've done the same."
            scene 15_0426 with dissolve
            mc "No. I'm glad you were brave enough to tell her, Sweetheart."
            mc "Hate to admit it, but had either of you come to me first..."
            mc "There's no way I would've agreed to you telling each other."
            scene 15_0419 with dissolve
            mc "We {b}have{/b} to be careful though, Millie.\nWe need to keep this between us."
            mil "I won't tell anyone else, Dad. I swear."
            mc "Okay."
            scene 15_0414 with dissolve
            mil "And Hannah?"
            scene 15_0416 with dissolve
            mil "Tell me you {b}want{/b} to fuck her."
            scene 15_0408 with dissolve
            mc "Okay... Yeah, I'd like to."
            mc "But only if you're truly on board with it."
        else:
            scene 15_0414 with dissolve
            mil "I'd like to have you all to myself, sure.\nBut Dad, it wouldn't be fair, would it?"
            scene 15_0415 with dissolve
            mil "I'd be devastated if you chose her over me!"
            mil "And I'm pretty sure she'd feel the same way if you chose me over her."
            scene 15_0416 with dissolve
            mil "So yeah, honestly, if it was up to me, you'd fuck us both."
            scene 15_0417 with dissolve
            mc "C'mon, you don't really feel that way."
            mc "... Do you?"
            mil "Yeah. I do."
        scene 15_0418 with dissolve
        mil "Hannah's more like a sister to me than a cousin."
        mil "We've been close our whole lives. We talk about everything together."
        scene 15_0420 with dissolve
        mil "I know how she feels about you."
        mil "How horny she gets when you tease her playing your game."
        scene 15_0424 with dissolve
        mil "I don't think you realize how close she was to letting you eat her the first time you tried it."
        scene 15_0421 with dissolve
        mil "The only reason she stopped you that day was me."
        mil "She wanted to make sure I'd be okay with it first."
        scene 15_0427 with dissolve
        mil "When I told her we'd done it, I could tell she was a little bit jealous."
        mil "I was so excited about the whole thing, I forgot for a second how much she loved you, too."
        scene 15_0428 with dissolve
        mil "I already told her she has my blessing, and now I'm telling you."
        scene 15_0429 with dissolve
        mc "You know how fucked up all this is, don't you?"
        mil "Yeah."
        scene 15_0430 with dissolve
        mil "But be honest, that just makes it so much fuckin' hotter, right?"
        mil "You wouldn't believe how wet this conversation has made me."
        scene 15_0431 with dissolve
        mc "Yeah, I know what you mean.\nMy dick's so fuckin' hard it's about to rip right through my jeans."
        mil "[lol]"
    else:
        mil "It's great that we're all a big happy family again!"
        mc "Yeah."
        scene 15_0407 with dissolve
        mil "Why did you and Aunt Lucy fall out?"
        mc "We didn't fall out.\nWe were just never very close."
        mil "What changed?"
        scene 15_0408 with dissolve
        mc "I don't know... I suppose as you get older, you start appreciating more the things you once took for granted."
        mc "My relationship with her didn't seem {i}that{/i} important to me if I'm being honest."
        mc "But I was wrong. Very wrong.\nAnd now, I'm trying to make up for it."
        scene 15_0409 with dissolve
        mil "How could you think that, Dad?"
        mil "She's your sister.\nIt should be one of the most important relationships in your life."
        scene 15_0417 with dissolve
        mc "Yeah, you're absolutely right, Sweetheart."
        mc "I had my priorities all screwed up.\nNot just with Aunt Lucy, but with you and your mom too."
        scene 15_0418 with dissolve
        mil "At least you figured it out before it was too late!"
        mil "You're trying your best now, Dad. That's what counts."
        scene 15_0431 with dissolve
        mc "I hope so."
    scene 15_0432 with dissolve
    vi "Hey there, Mister Impulsive."
    mc "Yeah, I know. Sorry, Vi."
    scene 15_0433 with dissolve
    vi "Remember the old days when it'd take three days of planning just to get you to go visit your sister?"
    scene 15_0434 with dissolve
    mc "I remember it being more persuading than planning."
    vi "Yeah, true."
    scene 15_0435 with dissolve
    mil "My turn for a shower.\nNervous driver equals nervous passenger!"
    vi "I'm not a nervous driver!\nI'm just careful!"
    scene 15_0436 with fadehold
    mc "How's your mom?"
    vi "Good, thanks."
    vi "Don't worry, she still hates you."
    scene 15_0437 with dissolve
    mc "Heh, yeah."
    mc "I was never good enough for you in her eyes.\nTo be fair though, I can see where she was coming from."
    vi "Oh, Baby... It was never just you!\nThere's not a man on this planet good enough for her daughter!"
    scene 15_0438 with dissolve
    vi "I think old age has finally started to mellow her, though!"
    vi "She was genuinely happy for Millie when I told her you were back."
    scene 15_0439 with dissolve
    mc "But not happy for you?"
    vi "No, of course not!"
    scene 15_0440 with dissolve
    vi "She's old, but not {i}that{/i} old!"
    vi "[lol]"
    scene 15_0441 with dissolve
    vi "Oh, hey... Thanks for talking to Alison and getting her to call me!"
    vi "It was really great to hear from her!"
    vi "I didn't realize how much I've missed her until we started chatting again."
    scene 15_0442 with dissolve
    mc "She always thought you both falling out was her fault.\nOnce I explained it to her, she didn't hesitate to get in touch."
    vi "Yeah, she told me."
    vi "I couldn't believe the mess she found herself in when... {i}he{/i}... died."
    vi "I was so glad you were able to help her."
    if Violet.isActive():
        scene 15_0443 with dissolve
        vi "She was rather surprised when I said we were trying to make things work again."
        vi "You never told her?"
        mc "No."
        vi "Why not?"
        scene 15_0444 with dissolve
        mc "I don't know, Vi..."
        mc "... I'm still worried I'll fuck it all up."
        mc "I didn't wanna tell her, and then have to explain later how I'd blown it again."
        scene 15_0445 with dissolve
        vi "[mc], you're doing great!\nWhy do you think you're gonna fuck it up??"
        scene 15_0446 with dissolve
        if Alison.isActive():
            call Emotion (mc, "Sigh", "Okay...", True)
            mc "There's something I need to tell you, Vi..."
            mc "You're not going to like it, but you deserve to know the truth."
            mc "I've... been sleeping with... Alison."
            scene 15_0447 with dissolve
            vi "[whi]Ohh... umm... okay."
            scene 15_0448 with dissolve
            mc "I'm sorry, Violet. I'm not trying to hurt you here."
            vi "Then what {i}are{/i} you trying to do?"
            mc "I'm trying to be honest.\nI love you, and I don't want to lie to you."
            scene 15_0449 with dissolve
            vi "Is it just sex, or... do you love her?"
            mc "[whi]I love her."
            vi "More than you love me?"
            scene 15_0450 with dissolve
            mc "No!"
            vi "But you still decided you wanted to be with her rather than me?"
            scene 15_0451 with dissolve
            mc "No, Vi!\nI still want to be with you."
            vi "I don't understand, [mc].\nWhy are you telling me this now?"
            mc "I... I want to be with you {b}both{/b}."
            scene 15_0452 with dissolve
            vi "What?!"
            scene 15_0453 with vpunch
            vi "ARE YOU OUTTA YOUR GODDAMN MIND?!!"
            scene 15_0454 with dissolve
            vi "You want us to SHARE YOU?!!"
            vi "ARE YOU FUCKIN' CRAZY??"
            scene 15_0455 with dissolve
            vi "DO YOU THINK {b}I'M{/b} FUCKIN' CRAZY?"
            mc "No!"
            scene 15_0456 with dissolve
            mc "Vi... Please. Wait."
            vi "Let me walk away before I say something I {i}really{/i} regret, [mc]."
            scene 15_0457 with dis1
            scene 15_0458 with dis1
            scene 15_0459 with dis1
            mct "Goddamnit.\nI couldn't have fucked that up more if I'd tried."
            jump OakHill_05_MovieWithMillie
        mc "Because I always do.\nI don't {b}want{/b} to. I won't {b}try{/b} to."
        mc "But, Vi, you know me better than anyone... {i}Somehow{/i}, I will."
        scene 15_0442 with dissolve
        vi "We're going to make mistakes along the way, Baby. It's inevitable. Everyone does."
        vi "We just have to be willing to work at it.\nThat's really all we can ask of each other."
        mc "I want us to work, and I'll do everything I can to make sure we do."
        vi "And so will I."
    scene 15_0460 with dissolve
    call Emotion (vi, "Sigh")
    mc "You okay?"
    vi "[whi]Hmm?"
    scene 15_0461 with dissolve
    vi "Oh, yeah. Sorry.\nMy head's pounding."
    vi "You know how stressful I get with driving!"
    scene 15_0462 with dissolve
    mc "Honey, go lie down for a while!"
    mc "You don't need to sit here keeping me company!"
    vi "You wouldn't mind?"
    scene 15_0463 with dissolve
    mc "Get outta here!"
    vi "Okay. Just for a little while."
    scene 15_0464 with dissolve
    vi "I have no doubt Millie will be back down soon to annoy you, anyway."
    scene 15_0465 with dissolve
    vi "Tell her she can order pizza when she gets hungry."
    mc "Will do."
    scene 15_0466 with dissolve
    mct "She always hated driving long distances.\nFigured she'd have got used to it by now."
    jump OakHill_05_MovieWithMillie
return

label OakHill_05_MovieWithMillie:
    scene black with fade2
    call CenterText ("An hour or so later...")
    scene 15_0467 with fade
    pause
    scene 15_0468 with dissolve
    mil "Hey, Dad.\nSorry I took so long."
    mc "It's fine, Sweetie."
    scene 15_0469 with dissolve
    mil "Where's Mom?"
    if Violet.isActive() and Alison.isActive():
        mc "Uhh... think she went to lie down for a while."
    else:
        mc "She went to lie down for a while, bad headache."
    mil "Right. She always does after driving home from Grandma's."
    scene 15_0470 with dissolve
    mil "Probably won't see her for the rest of the night now, so guess it's just you and me."
    mc "Yeah, guess so."
    scene 15_0471 with dissolve
    mil "Wanna watch a movie with me?"
    mc "You're the boss, remember!\nWe can do whatever you want, Sweetie."
    scene 15_0472 with dissolve
    mil "Careful, Dad!\nAll this power might go to my head!"
    call laugh (mc, "Noted!")
    scene 15_0473 with dissolve
    mc "Tell you what... Why don't you find us a movie to watch, and I'll go and check on your mom."
    mc "She's been up there a while. Just wanna make sure she's alright."
    mil "Okay."
    scene 15_0474 with dissolve
    mc "No chick-flicks!"
    mil "Ugghh! As if!"
    call laugh (mc, "That's my girl!")
    call OakHill_05_CheckOnViolet (Violet.isActive() and Alison.isActive())
    scene 15_0483 with Fade(1,2,1)
    mc "Find one?"
    mil "Yep! Think you're gonna love it."
    scene 15_0484 with dissolve
    mc "You picked the scariest movie you could find, didn't ya?"
    mil "Not the {b}scariest{/b}."
    scene 15_0485 with fade1
    mil "Oh my god!"
    mil "Okay, I didn't know it was gonna be {b}this{/b} scary!"
    call laugh (mc)
    if persistent.Incest and Millie.isSexual():
        call MillieReplay07
        scene 15_0647 with fade1
        pause
    scene 15_0486 with fade1
    mc "I enjoyed that, Mils!\nHow about you?"
    mc "... Millie?"
    scene 15_0487 with dissolve
    mil "[whi]..Zzzzz.."
    mc "[whi]Heh. Every damn time!"
    mc "[whi]Okay, let's get you to bed."
    scene 15_0488 with fade1
    mc "[whi]Goodnight, Sweetheart."
    scene 15_0489 with dis1
    scene 15_0490 with dis1
    pause 0.5
    if Violet.isActive() and Alison.isActive():
        scene 15_0661 with fade1
        mct "I'm such a goddamn fool.\nShould never have asked her!"
        mct "No way in Hell I'd ever share her with another guy... What made me think {b}she'd{/b} be okay with it?!"
        play sound "vib.mp3"
        mct "Not sure I can fix this."
        scene 15_0662 with dissolve
        stop sound
        mc cell "Hey, Alison."
        ali cell "I told you it was a bad idea, [mc]."
        mc cell "Yeah. Wish I'd listened."
        scene 15_0663 with dissolve
        ali cell "Telling her you didn't want to lose me without a fight wasn't great either."
        mc cell "I was trying to be honest with her."
        mc cell "I'm sorry if I've fucked things up again between the two of you.\nYou'd only just become friends again."
        ali cell "No, you haven't.\nShe isn't blaming me for this."
        mc cell "That's something, I guess."
        scene 15_0664 with dissolve
        mc cell "I don't think there's any coming back from this, Ali.\nI pushed her too far. Blown it."
        ali cell "I wouldn't speak too soon, [mc].\nShe's calmed down a little now. I've been talking to her most of the evening."
        ali cell "She even said she was kinda happy you thought you could talk to her about it."
        ali cell "It's not something you would've ever done before."
        scene 15_0665 with dissolve
        mc cell "Lot of good it did me!"
        ali cell "I didn't think you'd actually ask her, if I'm honest.\nThought it was a crazy idea when you brought it up, and still do."
        ali cell "Did you want it so much that you were willing to risk everything?"
        mc cell "Guess so."
        ali cell "Uh.. hold on a sec."
        ali cell "..."
        scene 15_0662 with dissolve
        ali cell "She's calling again."
        ali cell "Let me talk to her.\nI'll try to smooth things out a bit."
        mc cell "Okay.\nI'll see you when I get back to Springhaven."
        ali cell "Night, [mc]."
        mc cell "Night."
        scene 15_0666 with dissolve
        mct "Hope you have better luck than me."
    scene 15_0667 with fade1
    mc "[whi]..Zzz.."
    jump OakHill_05_NextMorning
return

label OakHill_05_CheckOnViolet(Extended=False):
    scene black with fade1
    play sound "knock.mp3" volume 0.5
    scene 15_0475 with fade
    pause 0.5
    scene 15_0476 with dissolve
    mc "[whi]Violet?"
    if not Extended:
        scene 15_0478 with dissolve
        scene 15_0479 with dis1
        scene 15_0480 with dissolve
        vi "[whi]..Zzzzz.."
        scene 15_0481 with dissolve
        scene 15_0482 with dis1
        vi "[whi]Zzz."
        return
    scene 15_0477 with dissolve
    vi cell "I have to go."
    vi cell "Yeah... Me too."
    vi cell "Okay.\nSee you soon. Bye."
    scene 15_0648 with dissolve
    mc "Jesus.\nLet me guess... My sister?"
    mc "Couldn't wait to tell her how I screwed up, huh?"
    scene 15_0649 with dissolve
    vi "Wrong."
    vi "If you must know, it was Alison."
    scene 15_0650 with dissolve
    vi "I wanted to hear it from {i}her{/i}."
    vi "Why she wants to ruin everything we're trying to rebuild."
    scene 15_0651 with dissolve
    mc "Vi, she's not trying to ruin {b}anything{/b}."
    mc "Alison didn't know about us trying to work things out."
    mc "As soon as she did, she put a stop to her and me."
    scene 15_0652 with dissolve
    mc "She didn't demand I choose between you both.\nShe flat-out refused to get in the way."
    mc "It was {b}my{/b} suggestion, my greed, to want you both."
    mc "She would only agree to it if you did.\nPlease don't blame her. This is all {b}my{/b} fault, and I'm sorry."
    scene 15_0653 with dissolve
    vi "That's what she just told me."
    vi "She said she thought it was a bad idea to ask me, but you did anyway."
    mc "[whi]Yeah. Maybe I shouldn't have."
    scene 15_0654 with dissolve
    mc "I live with enough regrets already. I didn't want this to be another one."
    mc "The truth is, I {b}don't{/b} want to lose her..."
    mc "But if you say no to this idea, then I'm willing to."
    scene 15_0655 with dissolve
    vi "It's not much of a choice when she already made that decision for you, though, is it?"
    vi "If you want to be with her, [mc], then you should go and {b}be{/b} with her."
    scene 15_0656 with dissolve
    mc "Violet, you're my wife, and I love you.\nI'm {b}not{/b} leaving."
    mc "I'm sorry I've hurt you. It really wasn't my intention."
    mc "You know how terrible I am at expressing my feelings; it's just {b}not{/b} something I do."
    mc "But I wanted to try. I wanted to tell you how I feel for once."
    scene 15_0657 with dissolve
    mc "I wasn't demanding you accept the situation... I just wanted to float the idea, see how you felt about it."
    mc "If you said no, then fair enough.\nAlison and I would be done - for good."
    mc "But... She was right; it {i}was{/i} stupid to ask.\nAnd now I've fucked everything up again."
    scene 15_0658 with dissolve
    vi "I don't understand how you expect me to respond."
    vi "If I say no, you'll hold against me forever."
    mc "No, Vi. I {b}promise{/b} that'll never happen."
    scene 15_0652 with dissolve
    mc "If I didn't ask... I would've held it against myself."
    mc "I'd have regretted losing Alison without at least putting up a fight."
    mc "Now? I did what I could.\nI can live with that and move forward without the {i}not{/i} knowing."
    scene 15_0653 with dissolve
    vi "But would you be happy?"
    mc "If I'm with you? {b}Yes{/b}."
    scene 15_0659 with dissolve
    vi "Fuck. My brain is scrambled."
    mc "Vi..."
    vi "I need space, [mc].\nI need time to process."
    mc "[whi]Okay..."
    scene 15_0660 with dissolve
    mc "I'll be downstairs if you wanna talk some more."
    mc "I'm sorry, Vi."
return

label OakHill_05_NextMorning:
    scene 15_0668 with Fade(2, 4, 2)
    mc "[whi]..Zzz.."
    if Violet.isActive():
        scene 15_0669 with fade1
        vi "[whi][mc]?"
        call Emotion (mc, "Mumbles", "", True)
        scene 15_0670 with dissolve
        vi "[whi]Wake up.\nI made you a coffee."
        call Emotion (mc, "Groans", "", True)
        scene 15_0671 with dissolve
        call Emotion (mc, "Groans", "Thanks.", True)
        if not Alison.isActive():
            vi "What are you doing in here?"
            mc "I didn't want to disturb your sleep."
            scene 15_0672 with dissolve
            mc "I know how stressed you can get after driving, and the headaches that bring on."
            mc "Wanted you to get some decent rest. If I'd have got into your bed, I would've woken you."
            scene 15_0673 with dissolve
            vi "Baby, you've been trained by the mightiest military in the world."
            vi "Are you really telling me that {b}you{/b} couldn't have got into bed covertly?"
            mc "No, of course I could!"
            mc "What I'm telling you is, my wife's so hot and sexy, it would be impossible for me to climb into her bed and not want to fuck her."
            scene 15_0674 with dissolve
            vi "How incredibly sweet!"
            vi "But... Maybe that's what your wife was hoping you'd do!"
            scene 15_0675 with dissolve
            vi "You might also be interested to know, dear husband..."
            scene 15_0688 with dissolve
            vi "I've had plenty of sleep, and no longer have a headache."
            scene 15_0689 with dis1
            scene 15_0690 with dis1
            vi "So..."
        else:
            vi "Can we talk?"
            mc "Uhh... yeah."
            scene 15_0672 with fade
            mc "Listen, about yesterday... I'm so sorry, Vi."
            mc "I should never have brought it up. I was an idiot."
            scene 15_0676 with dissolve
            vi "For me, your most annoying trait has always been not sharing how you feel."
            vi "I'm not going to berate you for finally trying to do just that."
            scene 15_0677 with dissolve
            vi "You couldn't tell from my reaction, I know, but I was pleased you felt able to share your feelings with me."
            vi "So I apologize for screaming at you."
            scene 15_0678 with dissolve
            mc "You had every right, Vi."
            mc "Is there any way we can forget about the whole thing?\nPretend like it never happened?"
            mc "I can't lose you, not again."
            scene 15_0679 with dissolve
            vi "You haven't lost me, [mc]."
            scene 15_0680 with dissolve
            vi "We can't forget, though."
            vi "I did {b}a lot{/b} of thinking last night.\nTrying to figure out if we could get over this bump."
            scene 15_0681 with dissolve
            vi "I called Alison again. We had a long heart-to-heart."
            vi "Something she said stuck with me..."
            if persistent.Incest:
                vi "She told me that you and her have always been like family. Brother and sister, almost."
                vi "And she's right."
                scene 15_0682 with dissolve
                vi "Remember when we first met? I thought she {b}was{/b} your sister for the first few months."
                vi "It really took me by surprise when you eventually told me you were only friends!"
                scene 15_0683 with dissolve
                vi "Recalling thinking you were her brother made me realize something, though."
                vi "You don't love Alison in the same way you love me."
                vi "It's a different kind of love."
                scene 15_0684 with dissolve
                vi "What {b}we{/b} have is special, but so is what you have with her."
                vi "I can't take that away from you both. I won't."
                vi "It's too precious, too beautiful."
            else:
                vi "She told me that she'd always regretted marrying Pete."
                vi "She should've accepted your proposal when she had the chance."
                scene 15_0682 with dissolve
                vi "I'm glad she didn't."
                vi "We would never have met, and Millie wouldn't even exist!"
                scene 15_0683 with dissolve
                vi "The thought of us never meeting, never getting married... It made me incredibly emotional."
                vi "I can't begin to tell you how much I hate us being divorced.\nThat's {b}my{/b} biggest regret."
                scene 15_0684 with dissolve
                vi "Things have been different between us since you got back.\nThey've been better than ever."
                vi "If one of the reasons for that is Alison, then how can I object?"
            scene 15_0685 with dissolve
            mc "What are you saying, Vi?"
            vi "I'm saying... Okay."
            scene 15_0686 with dissolve
            vi "I'm saying I'll give it a chance. Let's see if it works."
            mc "Wow... Seriously??"
            mc "After yesterday, I didn't think I'd ever be able to convince you."
            scene 15_0687 with dissolve
            vi "Oh, Sweetheart, you didn't convince me {b}at all{/b}!\nYour argument was terrible!"
            vi "But Alison made a compelling case on your behalf.\nI still had doubts, but she reassured me on some things."
            vi "She even got me thinking it might be... fun."
            scene 15_0688 with dissolve
            mc "Damn. I don't believe it.\nThank you, Vi."
            mc "But, promise me one thing... At any point, if you feel like it isn't working for you, just talk to me."
            mc "I want this, but only if we're {b}all{/b} happy with it."
            vi "Deal."
            scene 15_0689 with dis1
            vi "The only question now is..."
            scene 15_0690 with dis1
            vi "How should we seal the deal?"
            scene 15_0691 with dissolve
            mc "Making love to my awesome wife sounds good to me!"
            vi "Me too."
        scene 15_0692 with dis1
        if persistent.Incest and persistent.GroupSex and Millie.isSexual():
            scene 15_0693 with dis1
            vi "Oh, wait..."
            scene 15_0694 with dissolve
            if Violet.Has("SawYou"):
                $ Violet.Del("SawYou")
                vi "I know she had her wicked way with you last night, but still, should we invite Millie?"
            else:
                vi "Should we invite Millie?"
            menu:
                "Hell yeah!":
                    scene 15_0695 with dissolve
                    vi "I'll be right back."
                    call VioletReplay04A
                "Nah, not this time":
                    vi "Okay, I get you all to myself then."
                    call VioletReplay04B
        else:
            call VioletReplay04B
        scene 15_0993 with fade1
    else:
        scene 15_0991 with fade1
        pause 0.5
        scene 15_0992 with dis1
        pause 0.5
        scene 15_0993 with dis1
    vi "Excellent timing. I was about to come get you.\nBreakfast is ready."
    mc "Great, I'm starving."
    scene 15_0994 with fade2
    mct "Beginning to hate leaving this town."
    scene 15_0995 with dis1
    scene 15_0996 with dis1
    scene 15_0997 with dis1

    jump OakHill_Leave
return

label OakHill_CaraAndAlisonVisit:
    call CenterText ("Later that day.")
    scene 18_0001 with Fade(0, 2, 3)
    call ShowLocation (oakhill_id)
    scene 18_0002 with dis1
    scene 18_0003 with dis1
    scene 18_0004 with dis1
    scene 18_0005 with dis1
    scene 18_0006 with dis1
    scene 18_0007 with dis1
    pause 0.5
    scene 18_0008 with dissolve
    mc "You coming?"
    ali "Yeah..."
    ali "God, I feel a little nervous!"
    mc "Why?"
    scene 18_0009 with dissolve
    ali "I don't know!\nWe haven't seen each other in so long..."
    ali "What if we don't get along like we used to?"
    call laugh (mc, "Come on.")
    scene 18_0010 with dissolve
    mc "Stop worrying - you'll be fine."
    scene 18_0011 with dissolve
    mc "Hey, Vi."
    vi "Hi, guys!\nI'm glad you're here at last!"
    scene 18_0012 with dissolve
    vi "Millie's been acting like a cat on a hot tin roof waiting on you all!"
    mc "Yeah, I was ready to dump Cara on the side of the road if she'd asked {i}how much further{/i} one more time!"
    scene 18_0013 with dissolve
    mc "Do I need to introduce you both again?"
    vi "Shut up, idiot."
    scene 18_0014 with dissolve
    vi "It's really good to see you, Ali!"
    scene 18_0015 with dissolve
    ali "You too."
    vi "I've missed you so much!"
    scene 18_0016 with dissolve
    vi "Come on in!"
    scene 18_0017 with dissolve
    vi "Looks like the girls went straight up to Millie's room if you want to go up and say hi, [mc]."
    scene 18_0018 with dissolve
    vi "Ali and I are about to open a bottle of wine to calm our nerves."
    ali "You too, huh?"
    scene 18_0019 with dissolve
    vi "I barely slept a wink last night!"
    ali "Same! [lol]"
    call OakHill_CaraAndAlisonVisit_SeeMillie
    scene 18_0047 with fade2
    scene 18_0048 with dis1
    mc "Time for me to start heading back."
    scene 18_0049 with dissolve
    ali "I thought you were going to take a nap first?"
    mc "Nah, just wanna get it over with."
    scene 18_0050 with dissolve
    vi "What's going on?"
    ali "He's exhausted!\nHe complained the whole way down here about how tired he was."
    scene 18_0051 with dissolve
    vi "[mc]! You shouldn't be driving if you're not up to it!"
    mc "I'm fine!"
    scene 18_0052 with dissolve
    vi "What if you fall asleep at the wheel??"
    scene 18_0053 with dissolve
    ali "That's what I said!\nAnd why he {b}agreed{/b} to have a nap before leaving!"
    scene 18_0054 with dissolve
    mc "Well, shit! That didn't take long {i}at all{/i}!"
    ali "What didn't?"
    mc "For the nagging to start!"
    scene 18_0055 with dissolve
    mc "I knew it was a bad idea to get you two back together!"
    vi "[lol]"
    scene 18_0056 with dissolve
    mc "I'll be fine, stop worrying."
    ali "Okay, but please, let us know you got home safely."
    mil "We're ready, Dad."
    scene 18_0057 with dissolve
    vi "Ready for what? He's just about to leave."
    mil "He's taking us to Hannah's."
    scene 18_0058 with dissolve
    vi "Oh, you're visiting Lucy before you leave?"
    mc "Nah, I'm just dropping them off."
    scene 18_0059 with dissolve
    vi "Oh, [mc]! You know what she's like."
    vi "She'll be annoyed if you don't at least go in and say hello!"
    scene 18_0060 with dissolve
    vi "And he wonders why they were never close!"
    ali "[lol]"
    scene 18_0061 with dissolve
    mc "Holy shit! Okay, I'll go in and say hi!\nJust {i}please{/i} stop!"
    vi "[lol]"
    scene 18_0062 with dissolve
    ali "Drive safe! See you in a few days."
    call OakHill_CaraAndAlisonVisit_VisitLucy
    scene 18_0139 with fade2
    if Lucy.isActive():
        mct "She's right, I {b}am{/b} an idiot... Shouldn't have done that."
        scene 18_0140 with dissolve
        mct "I hope I ain't fucked things up again."
    else:
        mct "Jeez. Getting old sucks ass!"
        scene 18_0140 with dissolve
        mct "Seems like only yesterday I could stay awake for days!"
    scene 18_0141 with dissolve
    mc "[whi]..Zzzz.."
    scene black with Fade(3, 2, 0)
    if Hannah.isSexual():
        call HannahReplay02
        scene 18_0266 with fade1
        han "Can I ask you something?"
        mc "Sure."
        han "Did that feel wrong to you? Like, at {i}any{/i} point?"
        scene 18_0267 with dissolve
        mc "No."
        mc "Did you feel that way?"
        han "No."
        scene 18_0268 with dissolve
        han "At {i}some{/i} point I thought I would... but I didn't."
        han "My uncle just took my virginity, and it felt nothing but right to me. \nThat's weird, right?"
        scene 18_0269 with dissolve
        mc "Who cares?\nIf it feels right to {b}us{/b}, that's all that matters."
        mc "I fucked my niece, and I loved every single second."
        scene 18_0270 with dissolve
        han "I loved every second, too."
        han "But... Was this just a one-off, Unc?\nThe game's over now. I won."
        mc "God, I hope not, Hannah."
        mc "If it were up to me, we'd fuck every day, for the rest of my life!"
        scene 18_0271 with dissolve
        han "Really?"
        han "I'd like that."
        scene 18_0272 with dissolve
        han "Well... Maybe not {i}every{/i} day.\nI'm feelin' kinda sore right now!"
        scene 18_0273 with dissolve
        call laugh (mc, "Okay, how about every {b}week{/b}?")
        han "Perfect."
        scene 18_0142 with Fade(2, 1, 2)
        mc "[whi]..Zzzz.."
        scene black with Fade(3, 2, 0)
    call OakHill_CaraAndAlisonVisit_LucyMorning
    scene 18_0295 with fade2
    luc "Are you coming in?"
    if (not Cara.isSexual(None, True) or not Millie.isSexual(None, True)) or not persistent.GroupSex:
        mc "Nah."
        mc "If I go in, they'll nag me to have breakfast before leaving, blah, blah, blah."
        scene 18_0296 with dissolve
        luc "You act like a child sometimes."
        mc "I just need to get back, Sis."
        scene 18_0297 with dis1
        scene 18_0298 with dis1
        scene 18_0299 with dis1
        scene 18_0300 with dis1
        jump Springhaven_06_ReturnFromOakhill
    mc "Yeah."
    scene 18_0301 with fade1
    luc "Hello Alison. Long time no see."
    ali "Hi Lucy. It's great to see you."
    scene 18_0302 with dissolve
    ali "Morning, [mc].\nI'm glad you saw sense and decided to stay over."
    scene 18_0303 with dissolve
    mc "That your way of saying {i}I told you so{/i}?"
    ali "[lol]"
    mc "Where's Vi?"
    ali "Upstairs getting ready."
    scene 18_0304 with dissolve
    mc "I'll go say bye."
    scene 18_0305 with dissolve
    luc "How are you and Violet getting on?\nShe was worried you both might've changed too much."
    scene 18_0306 with dissolve
    ali "So was I!\nIt's been great, though. I'm glad we came."
    scene 18_0307 with fade1
    scene 18_0308 with dis1
    vi "Oh, hi Honey."
    mc "Hey."
    scene 18_0309 with dissolve
    vi "Thanks for bringing Lucy over."
    vi "Come to say goodbye?"
    mc "Yeah."
    if Violet.isSexual():
        scene 18_0310 with dissolve
        mc "And to do this..."
        scene 18_0311 with dissolve
        vi "[whi]Mmhh."
        scene 18_0312 with dis1
        scene 18_0313 with dissolve
        vi "[whi]..Mmmhh.."
        scene 18_0314 with dissolve
        pause
        scene 18_0315 with dissolve
        vi "[whi]Aww, are you feeling horny, Baby?"
        mc "[whi]I'm {b}always{/b} horny when my sexy wife is in my arms."
        scene 18_0316 with dissolve
        vi "[whi]I'd like nothing more than for us to get into bed and make love right now, Sweetheart."
        vi "[whi]But Alison and Lucy are waiting on me!"
        scene 18_0317 with dissolve
        vi "[whi]Millie and Cara didn't want to come shopping with us, so they're still in bed."
        vi "[whi]I'm sure I can convince Cara to change her mind, though."
        scene 18_0318 with dissolve
        vi "[whi]And I'm positive Millie will be delighted to stay behind and fuck her daddy."
        scene 18_0319 with dissolve
        $ Violet.Add("KnowsAbtCara")
        mc "[whi]Nah, it wouldn't be fair on Cara."
        vi "[whi]Why?"
        mc "[whi]Millie isn't the only daughter who loves her dad."
        scene 18_0320 with dissolve
        vi "[whi]Nooo! [mc]!!\nWhat?! You're fucking Cara, too??"
        vi "[whi]{b}That's{/b} what they've been whispering and giggling about!"
        scene 18_0321 with dissolve
        vi "[whi]You're a {b}baaad{/b} man, Mister!"
        scene 18_0322 with dissolve
        vi "[whi]God, you're not the only one who's horny as fuck right now."
        scene 18_0323 with dissolve
        vi "[ss]..Mmmhh.."
        scene 18_0324 with dissolve
        vi "[ss]....Mmmhh...."
        luc "[whi]Violet?\nC'mon, we're waiting down here!"
        scene 18_0325 with dissolve
        vi "[whi]Goddamn it!"
        scene 18_0326 with dissolve
        vi "[whi]The girls slept in the guestroom if you want to see them before you leave."
        scene 18_0327 with dissolve
        vi "[whi]Sorry, Baby. I have to go."
        mc "[whi]Okay, I'll see you in a few days."
        scene 18_0328 with dissolve
        mct "Knew she'd be okay about Cara and me."
        mct "Didn't quite expect her to get so turned on by it though, heh."
        scene 18_0329 with dis1
        scene 18_0330 with dis1
    else:
        scene 18_0331 with dissolve
        mc "How are things going with you and Alison?"
        vi "Really great!"
        vi "We're all going shopping.\nYou're welcome to come along!"
        mc "I can't think of anything I'd want to do {b}less{/b}!"
        scene 18_0332 with dissolve
        vi "[lol]"
        vi "Millie and Cara felt the same way!\nThey don't want to come either."
        vi "They're asleep in the guestroom if you want to see them before you leave."
        luc "Violet?\nC'mon, we're waiting down here!"
        scene 18_0327 with dissolve
        vi "[whi]Sorry, I need to go."
        mc "[whi]Okay, I'll see you in a few days."
        scene 18_0328 with dissolve
        mct "Good to see they're both getting on again.\nDon't know why Alison was so nervous about coming here. Heh."
        scene 18_0329 with dis1
        scene 18_0330 with dis1
    scene 18_0333 with fade1
    scene 18_0334 with dis1
    scene 18_0335 with dis1
    scene 18_0336 with dis1
    menu:
        "Leave for Springhaven":
            scene 18_0337 with dis1
        "See Millie and Cara before leaving":
            scene 18_0343 with dis1
            call MillieReplay08
            scene black with Fade(0,1,2)
    scene 18_0338 with dis1
    scene 18_0339 with dis1
    scene 18_0340 with dis1
    scene 18_0341 with dis1
    scene 18_0342 with dis1
    jump Springhaven_06_ReturnFromOakhill
return

label OakHill_CaraAndAlisonVisit_SeeMillie:
    scene 18_0020 with fade1
    play sound "knock.mp3"
    scene 18_0021 with dis1
    pause 0.5
    mil "[whi]Come in."
    scene 18_0022 with dissolve
    mil "Hey, Dad!"
    scene 18_0023 with dissolve
    mc "Hi, Sweetheart.\nI don't {i}usually{/i} need to come looking to get a hug from my daughter!"
    scene 18_0024 with dissolve
    mil "Ohh, I'm sorry!\nI was so excited that Cara was here that I forgot about you!"
    scene 18_0025 with dissolve
    mil "[whi]Hi, Daddy."
    mc "[whi]Hi, Sweetie."
    scene 18_0026 with dissolve
    mil "C'mon, Sis!"
    scene 18_0027 with dissolve
    mil "Dad needs a hug from his daughters!"
    scene 18_0028 with dis1
    scene 18_0029 with dis1
    mc "Mmmmhh.\nCan't tell you how long I've wanted to hold you both in my arms like this."
    scene 18_0030 with dissolve
    mc "Can we stay like this forever?"
    mil "I'd be happy to."
    car "Me too."
    scene 18_0031 with dissolve
    mil "Cara said you're not staying?"
    mc "No, sorry Milz.\nYou know I would if I could."
    mc "I'm just so busy right now."
    scene 18_0032 with dissolve
    car "He'll be back in a few days to take us home."
    mc "Yeah, I'll stay over then."
    scene 18_0033 with dissolve
    mil "Okay."
    if Millie.isSexual(None, True) and Millie.getSex()>0 and Cara.isSexual() and Cara.getSex()>0:
        scene 18_0034 with dissolve
        mil "Guess I can wait a {i}few{/i} more days for some daddy love."
        mil "You're so lucky to be living with him!"
        mil "I bet he fucks you every day."
        scene 18_0035 with dissolve
        car "I wish!"
        car "He's probably had more sex with you than with me!"
        if Cara.getSex()==2:
            car "We've only done it twice!"
        else:
            car "We've only done it once!"
        if Millie.getSex()==3:
            scene 18_0036 with dissolve
            mil "Dad! How can you fuck me more than Cara?\nWe've done it three times!"
            mc "Things are more complicated in Springhaven, Sweetheart."
            scene 18_0037 with dissolve
        else:
            scene 18_0037 with dissolve
            if Millie.getSex()==2:
                mil "We've done it twice."
            else:
                mil "Only once!\nHe took my v-card and hasn't bothered since!"
        mil "It's fine. He can make up for it when we all live together."
        scene 18_0034 with dissolve
        mil "One of us can have mornings, and the other evenings."
        mc "When we all live together??"
        scene 18_0038 with dissolve
        car "Yeah!"
        car "We're making plans, Daddy.\nYou don't have any say, so don't worry about it."
        scene 18_0039 with dissolve
        mil "We're gonna be one big happy family!"
        mil "And it'll be {i}our{/i} job to take care of {b}you{/b}."
        mil "{b}Whenever{/b} you want us to!"
        mc "Wow, sounds great! Heh."
        scene 18_0040 with dissolve
        mil "Does he cum inside you?"
        if Cara.getCumIns()>0:
            car "Yeah."
            if Millie.getCumIns()>0:
                if Millie.getCumIns()==Millie.getSex():
                    mil "Me too! Every time!"
                else:
                    mil "Me too!"
                scene 18_0041 with dissolve
                mil "It's my favorite part!"
            else:
                mil "He hasn't with me... yet.\nCan't wait 'til he does!"
        else:
            car "No! Too risky!"
            if Millie.getCumIns()>0:
                mil "Uhh... Yeah, I guess so."
            else:
                mil "Yeah, I think so."
        scene 18_0042 with dissolve
        mil "God, all this talk has made me super horny!"
        mil "Dad..."
        mc "It's too risky with Alison here, Sweetie."
        scene 18_0043 with dissolve
        car "Yeah, my mom isn't cool like yours, Millie."
        car "If she caught us, she'd freak out {b}big time{/b}!"
        scene 18_0044 with dissolve
        mc "I need to get going anyway."
    else:
        scene 18_0044 with dissolve
        mc "I need to get going."
    mil "You're leaving right now?"
    mc "Yeah, sorry, but I have to."
    mil "Can you drop us off at Hannah's on your way?"
    scene 18_0045 with dissolve
    mil "She can't wait to meet her new cousin officially!"
    mc "Uh, yeah, sure."
    scene 18_0046 with dissolve
    mc "Are you ready to go now?"
    mil "Yeah, just give us a few minutes."
    mc "Okay, I'll go tell your moms that I'm leaving."
return

label OakHill_CaraAndAlisonVisit_VisitLucy:
    scene 18_0063 with fade2
    mil "C'mon, Dad!\nWe'll tell on you if you don't come in!"
    call Emotion (mc, "Yawn", "I'm comin'.")
    scene 18_0064 with fade1
    han "Hey, Unc!\nWhere's Millie? She said they were coming with you?"
    scene 18_0065 with dissolve
    mc "They did.\nShe thought you'd be in your bedroom. They went straight up."
    scene 18_0066 with dissolve
    han "It's awesome that you visit so often these days."
    mc "Yeah."
    if Hannah.isSexual(None, True):
        scene 18_0067 with dissolve
        han "I wasn't happy when Millie told me you couldn't stay, though."
        han "I've been {i}really{/i} looking forward to us playing our game again."
        mc "Yeah, me too."
        scene 18_0068 with dissolve
        han "Good to know."
        mc "I'll be back in a few days.\nWe'll need to try and find some alone time."
        han "'kay."
    scene 18_0069 with dissolve
    luc "Oh, [mc]. When Han said you'd be dropping the girls off, I didn't expect you'd come in."
    scene 18_0070 with dissolve
    mc "Of course I'm gonna come in! I'd never miss an opportunity to see you, now would I?"
    luc "Sarcasm? Very droll."
    scene 18_0071 with dissolve
    han "I'm going up to my room to see Millie and Cara."
    luc "Okay Sweetheart."
    scene 18_0072 with dissolve
    mc "It {i}wasn't{/i} sarcasm, Sis."
    luc "Then I apologize.\nI've just got home from a long day at work."
    scene 18_0073 with dissolve
    luc "Forgive me."
    if not persistent.Incest or not Lucy.L==1 or not Lucy.hasScore(3) or not Lucy.Has("Ass2"):
        call CloseCharacterPath (Lucy)
        mc "There's nothing to forgive."
    else:
        $ Lucy.act=False
        $ Lucy.lvr=False
        if persistent.UseFocus and not EzModeActive:
            $ _skipping = False
            show screen imgMap("images/e18/18_0074.webp", 897, 785, True, "OakHill_AF12") with dissolve
            mc "There's nothing to forgive."
            $ _skipping = True
            if renpy.get_screen("imgMap"):
                scene 18_0074
                hide screen imgMap 
        else:
            scene 18_0074 with dissolve
            mc "There's nothing to forgive."
            if not EzModeActive:
                menu:
                    "[wk_y]Move your hand down":
                        call OakHill_AF12
                    "Leave your hand where it is":
                        pass
            elif Lucy.Has("EZ"):
                call OakHill_AF12
    scene 18_0080 with dissolve
    luc "I'll make some coffee."
    mc "I don't really have the time, Lucy."
    luc "Don't be silly! It's just a coffee, [mc].\nSit down."
    scene 18_0081 with dissolve
    call Emotion (mc, "Sigh", "", True)
    scene 18_0082 with dissolve
    mct "Probably not a bad idea to get a little caffeine kick."
    scene 18_0083 with dis1
    mct "Should help me stay awake."
    scene 18_0084 with dis1
    mct "... Need all the help I can get."
    scene 18_0085 with dis1
    mct "... So... damn... tired..."
    scene 18_0086 with dis1
    mc "[whi]..Zzz..."
    scene 18_0087 with dis1
    scene 18_0088 with dis1
    scene 18_0089 with dis1
    scene black
    scene 18_0090 with Fade(0, 5, 4)
    pause 0.5
    scene 18_0091 with dis1
    call Emotion (mc, "Groan", "", True)
    scene 18_0092 with dissolve
    mc "Fuck! What time is it??"
    scene 18_0093 with dis1
    scene 18_0094 with dis1
    scene 18_0095 with dis1
    scene 18_0096 with fadehold
    mc "Damn, Sis! Why didn't you wake me up?!"
    luc "I tried!"
    scene 18_0097 with dissolve
    luc "But then Violet called and suggested I leave you to sleep."
    scene 18_0098 with dissolve
    mc "Fuck... It's {b}so{/b} late!\nI'm gonna have to drive through what's left of the night."
    scene 18_0099 with dissolve
    luc "Don't be ridiculous, [mc]. Just stay here overnight and leave first thing."
    mc "I got shit to do back in Springhaven."
    scene 18_0100 with dissolve
    luc "You can drive all night, get home and sleep all day, or you can get a decent night's sleep here and leave at dawn."
    luc "At least by staying here you'll be fit to make the journey home."
    luc "But the choice is yours."
    scene 18_0101 with dissolve
    call Emotion (mc, "Sigh", "Yeah... I guess you're right.")
    scene 18_0102 with dissolve
    mc "What's all this? Having a private party?"
    scene 18_0103 with dissolve
    luc "Just taking advantage of some peace."
    luc "Hannah's over at Vi's hanging out with Millie and Cara.\nShe'll either be back late or tomorrow."
    luc "There's more in the refrigerator if you want to join me."
    if Lucy.isActive():
        $ tCh=Lucy.Has("EZ")
        if not EzModeActive:
            menu:
                "[wk_y]Have a beer with Lucy":
                    $ tCh=True
                "Go to bed [wk_c]":
                    $ tCh=False
        if not tCh:
            call CloseCharacterPath (Lucy, "Lucy")
    scene 18_0104 with dissolve
    if not Lucy.isActive():
        mc "Nah, I'm good.\nI'm gonna get some more sleep."
        luc "Okay, goodnight [mc]."
        return
    mc "Yeah, why not. Get you another?"
    luc "Sure."
    scene black with fade2
    call CenterText ("Some time later.")
    scene 18_0105 with Fade(0,0,4)
    luc "[lol]"
    call laugh (mc, "Mom {b}never{/b} trusted me with her car again after that!")
    scene 18_0106 with dissolve
    mc "Did she {i}ever{/i} find out it was your fault?"
    luc "Hell no![lol]"
    scene 18_0107 with dissolve
    mc "Damn. How do you do it, Luc?"
    mc "You're the only woman who can drink me under the table!"
    scene 18_0108 with dissolve
    luc "You'd think it'd make me good wife material, huh?"
    luc "Just my luck I married a non-drinker!"
    mc "He was a fuckin' idiot to let you go."
    scene 18_0109 with dissolve
    luc "Why? Because I can handle my beer better than my brother?"
    mc "Because you're a beautiful, sexy woman!\nI guarantee he regrets it every single day."
    scene 18_0110 with dissolve
    luc "You're {i}so{/i} drunk!"
    mc "Doesn't mean I'm wrong."
    scene 18_0111 with dis1
    mc "[kiss]"
    scene 18_0112 with dis1
    pause 0.5
    scene 18_0113 with dis1
    luc "[whi]Mhh."
    scene 18_0114 with dis1
    luc "[whi]..Mmhh.."
    scene 18_0115 with dis1
    pause 0.5
    scene 18_0116 with dis1
    luc "I've told you before that you're weird, right?"
    luc "Brothers don't kiss their sisters like that."
    scene 18_0117 with dis1
    mc "And yet you didn't stop me."
    scene 18_0118 with dis1
    mc "Just like you didn't move my hand away from your ass when we hugged earlier."
    scene 18_0119 with dis1
    luc "I can't say I noticed."
    scene 18_0120 with dis1
    luc "I must be getting used to you doing it."
    scene 18_0121 with dis1
    mc "I {i}know{/i} you like it, Sis."
    scene 18_0122 with dis1
    mc "You like me touching you where I shouldn't."
    scene 18_0123 with dis1
    mc "Do you ever imagine us fucking?"
    luc "No."
    scene 18_0124 with dis1
    luc "[whi]..Mmhh.."
    scene 18_0125 with dissolve
    luc "[whi]Mmmhh."
    scene 18_0126 with dissolve
    luc "[whi]....Mmhhhh...."
    scene 18_0127 with dissolve
    mc "I do. All the time."
    luc "I wish you weren't my brother right now, [mc]."
    luc "We can't, and you {i}know{/i} we can't."
    scene 18_0128 with dissolve
    luc "We're behaving like a pair of drunken fools, that's all."
    scene 18_0129 with dissolve
    luc "We'd {b}both{/b} regret it tomorrow, and there's a good chance we'd permanently fuck up our relationship."
    scene 18_0130 with dissolve
    luc "And that's something I {b}don't{/b} want us to do."
    scene 18_0131 with dissolve
    luc "I'm sorry, but you know I'm right."
    mc "Yeah..."
    scene 18_0132 with dissolve
    luc "Goodnight, [mc]."
    mc "Night."
    scene 18_0133 with dis1
    mc "[whi]Damn it."
    scene 18_0134 with dis1
    scene 18_0135 with dissolve
    scene 18_0136 with dis1
    scene 18_0137 with dis1
    scene 18_0138 with dissolve
return

label OakHill_CaraAndAlisonVisit_LucyMorning:
    scene 18_0274 with Fade(0, 4, 3)
    call EmotionSml (mc, "Yawn")
    scene 18_0275 with dis1
    mc "Mornin', Sis."
    scene 18_0276 with dissolve
    if Lucy.isActive():
        luc "[mc], we need to talk."
        scene 18_0277 with dissolve
        mc "...Okay."
        luc "Sit down."
        scene 18_0278 with dissolve
        luc "Last night... We were both {b}very{/b} drunk."
        luc "Do you... remember what happened?"
        mc "Yeah, I wasn't {i}that{/i} drunk!"
        scene 18_0279 with dissolve
        luc "You were drunk enough to do something outrageous!\nWe {b}both{/b} were!"
        scene 18_0280 with dissolve
        luc "I... I should've stopped you. I don't know why I didn't!"
        scene 18_0281 with dissolve
        luc "What we did... It was disgusting, and it can {b}NEVER{/b} happen again!"
        luc "Agreed?"
        scene 18_0282 with dissolve
        mc "Lucy..."
        luc "{b}[mc!u], ARE WE AGREED?{/b}"
        mc "Yes! Of course!"
        scene 18_0283 with dissolve
        luc "I'm not blaming {i}you{/i}; we were both at fault."
        luc "I don't know what came over me.\nI'm embarrassed, and apologize if I encouraged you in any way."
        scene 18_0284 with dissolve
        mc "You don't owe me an apology, Lucy."
        mc "You didn't encourage me.\nYes, I was drunk, but I was in control of my actions."
        mc "It was {i}my{/i} decision, so {b}I'm{/b} sorry."
        scene 18_0285 with dissolve
        luc "Thank you, and accepted."
        luc "Why? Why did you kiss me like {i}that{/i}??"
        mc "I don't know, Sis."
        mc "It just felt..."
        call Emotion (mc, "Sigh", "I tried to stop myself, but I couldn't resist...")
        scene 18_0286 with dissolve
        luc "We {b}must{/b} resist, [mc]! We're brother and sister."
        luc "We can't allow it to happen again."
        scene 18_0287 with dissolve
        mc "{i}We{/i}?"
        mc "Did you feel the same way??"
        luc "No!\nI was drunk and didn't know what I was doing!"
        scene 18_0288 with dissolve
        luc "[mc], we've come so far.\nI don't want this to hurt our relationship."
        luc "Let's put it out of our minds and not mention it again."
        scene 18_0282 with dissolve
        mc "Okay... If that's what you want."
        luc "It is."
    else:
        luc "Good morning.\nSleep well?"
        scene 18_0277 with dissolve
        mc "Yeah."
        scene 18_0282 with dissolve
        luc "Will you have breakfast before you leave?"
        mc "Nah, I'll get something on the way."
    scene 18_0289 with dissolve
    luc "Are you able to drop me off at Violet's on your way out of town?"
    mc "Yeah, sure."
    luc "Good. It'll save her having to pick me up.\nWe're all going out for the day."
    luc "It's been years since I've seen Alison, and we always got on quite well together; it'll be nice to get reacquainted."
    scene 18_0290 with dissolve
    luc "Okay, let's go."
    mc "Oh... You meant right now?"
    scene 18_0291 with dissolve
    luc "Is that a problem?"
    scene 18_0292 with dissolve
    mc "Uh, nope."
    scene 18_0293 with dis1
    scene 18_0294 with dis1
    pause 0.5
return

label OakHill_Start6:
    scene 21_0432 with Fade(0, 2, 3)
    pause
    call OakHill_06_CleanUp
    scene 21_0433 with fade1
    vi "We weren't expecting you so early!"
    mc "I left Alison a message telling her I was on my way.\nDidn't she get it?"
    vi "Oh, I don't know - She's still in bed."
    scene 21_0434 with dissolve
    vi "Girls, your dad's here."
    scene 21_0435 with dissolve
    mil "Already?!"
    scene 21_0436 with dissolve
    mil "Daddy!"
    scene 21_0437 with dissolve
    mil "Did you miss us?"
    mc "You kidding?! Of course I did!\nI always miss my girls!"
    scene 21_0438 with dissolve
    mil "Your girls missed {i}you{/i}, too!"
    if Millie.isSexual(None, True) and Cara.isSexual() and Violet.Has("Z00"):
        call OakHill_06_FullHello
    else:
        scene 21_0493 with dissolve
        mc "Hi Pipsqueak."
        scene 21_0494 with dissolve
        mil "Dad, can you take us riding today?"
        mc "Horse riding?"
        mil "Yeah!\nCara's never been!"
        scene 21_0495 with dissolve
        mc "You've never ridden a horse?"
        car "No. I'd love to have a go, though!"
        scene 21_0496 with dissolve
        mc "Guess I'm takin' them horse riding!"
        vi "[lol]"
        scene 21_0458 with dissolve
        mil "C'mon, Sis. Let's get dressed!"
        scene 21_0459 with dissolve
        vi "I'm sure they'll allow you a coffee first!\nI'll make you one."
        if Violet.isSexual():
            scene 21_0460 with dissolve
            mc "Not so fast!"
            mc "{i}You{/i} ain't said hello yet."
            scene 21_0461 with dissolve
            vi "[whi]Hi."
            scene 21_0462 with dis1
            vi "[whi]Mmhh."
            scene 21_0463 with dissolve
            vi "[whi]..Mmmhh.."
            scene 21_0464 with dissolve
            mc "How about we skip the coffee and go upstairs?"
            vi "Oh, Baby. I don't want a quick rough'n'tumble!"
            scene 21_0466 with dissolve
            vi "We can have {i}our{/i} fun later tonight... If you're not too sore from the saddle."
            scene 21_0467 with dissolve
            mc "I could {i}never{/i} be too sore to make love to my wife, Sweetheart."
            vi "Good.\nI'll make that coffee."
        scene 21_0492 with dissolve
        vi "Why don't you check if Alison's awake yet? She's in the guest room."
        mc "Okay."
    call OakHill_06_AlisonHello
    call OakHill_06_BackToTheLake
    scene 21_0911 with Fade(0,0,3)
    car "That was sooo much fun!"
    scene 21_0912 with dissolve
    mil "Told ya you'd love it, Sis!"
    play sound "vib.mp3" loop
    scene 21_0913 with dissolve
    car "Everything okay, Dad?"
    mc "Yeah.\nYou go ahead; I need to take this."
    stop sound
    scene 21_0914 with dissolve
    mc cell "Hey.\nWasn't expecting to hear from you so soon."
    scene 21_0915 with dissolve
    ame cell "We need a meeting."
    mc cell "Why?"
    ame cell "It's a part of the process."
    scene 21_0916 with dissolve
    mc cell "Fine. When?"
    ame cell "The sooner the better."
    mc cell "I'll be back in Springhaven tomorrow."
    ame cell "I can't keep showing up in Springhaven. It's too risky."
    scene 21_0917 with dissolve
    mc cell "So where?"
    ame cell "Can you make it to Briar Hollow?\n... or maybe we could meet halfway?"
    ame cell "Tomorrow could prove difficult, though."
    ame cell "I guess today would be out of the question for you?"
    scene 21_0918 with dissolve
    mc cell "Is this really necessary??"
    ame cell "Yes!\nWe have to do this by the book, [mc]."
    mc cell "Goddamit."
    scene 21_0919 with dissolve
    mc cell "Fine.\nI'm not too far from Briar Hollow. I can be there in around an hour."
    ame cell "Okay. That's perfect."
    ame cell "Apologies for the inconvenience."
    scene 21_0920 with dissolve
    mct "Better not be wasting my damn time."
    scene 21_0921 with fade1
    mc "Wow. You made it out of bed!\nWell done!"
    scene 21_0922 with dissolve
    ali "[lol]\nWe heard you lost {i}another{/i} race against the girls!"
    mc "Nah, I let them win!"
    vi "You couldn't let anyone win, even if your life depended on it!"
    scene 21_0923 with dissolve
    call laugh (mc, "Fine... My stupid horse let them win!")
    vi "[lol]"
    scene 21_0924 with dissolve
    mc "I hate to do this, but something's come up."
    ali "Oh. Do we have to leave?"
    mc "No, you guys can stay.\nBut I have to disappear for a little while. It's a work thing."
    scene 21_0925 with dissolve
    vi "You have a {i}work thing{/i} in Oakhill?"
    mc "No. There's a meeting in Briar Hollow I need to attend."
    scene 21_0926 with dissolve
    ali "Lucy's planning to cook a meal for all of us later. Will you be back in time?"
    scene 21_0927 with dissolve
    vi "She'll be very upset if you're not there, [mc]."
    scene 21_0930 with dissolve
    mc "Yeah, I'll be back by then, don't worry."
    scene 21_0931 with fade1
    scene 21_0932 with dis1
    scene 21_0933 with dis1
    scene black with Fade(3, 3, 0)
    call BriarHollow_QuickMeeting
    call CenterText ("Later that afternoon...")
    scene 22_0095 with Fade(0, 0, 3)
    call ShowLocation (oakhill_id)
    pause
    scene 22_0096 with fade1
    call Emotion (unk, "Indistinct chatter")
    scene 22_0097 with dissolve
    mc "Damn. You've outdone yourself, Sis; This looks delicious!"
    luc "Thank you."
    scene 22_0098 with dissolve
    luc "These past few days have been great."
    luc "I've enjoyed getting to know Alison and Cara better."
    scene 22_0099 with dissolve
    luc "I think it's what I've been missing."
    luc "That feeling of belonging.\nBeing part of a {i}real{/i} family again."
    luc "Know what I mean?"
    scene 22_0100 with dissolve
    mc "Yeah, I know exactly what you mean."
    scene 22_0101 with dissolve
    mc "Here's to us, Sis."
    scene 22_0102 with dis1
    scene 22_0103 with dis1
    luc "To us - And to {i}family{/i}."
    scene 22_0104 with dissolve
    vi "What are you two celebrating down there?"
    scene 22_0105 with dissolve
    mc "You guys. And having an awesome family."
    vi "I'll drink to that!"
    scene 22_0106 with dissolve
    vi "To our wonderful family!"
    scene 22_0107 with dissolve
    call Emotion (unk, "Everyone", "{b}TO FAMILY!{/b}")
    scene 22_0108 with Fade(2, 4, 2)
    scene 22_0109 with dis1
    scene 22_0110 with dis1
    scene 22_0111 with dissolve
    vi "There you are!\nWe were wondering where you'd gone."
    mc "I was clearing up the kitchen."
    scene 22_0112 with dissolve
    luc "You didn't need to do that!\nI was going to leave it until morning."
    mc "It was the least I could do, Sis!"
    scene 22_0113 with dissolve
    mc "Where are the girls?"
    ali "They weren't impressed with the movie we chose, so decided to watch their own in Hannah's room."
    scene 22_0114 with dissolve
    mc "Let me guess - You picked a chick flick?"
    ali "Of course we did!"
    mc "{i}Great{/i}.\nWonder what they're watching?"
    scene 22_0115 with dissolve
    vi "[lol] Nope!\nYou're watching {b}our{/b} movie, mister!"
    mc "Was worth a try, heh."
    scene 22_0116 with dissolve
    luc "We'd better open another bottle of wine before we start the movie."
    scene 22_0117 with dissolve
    luc "Would you like a beer, [mc]?"
    mc "Nah, better not. I'm driving."
    vi "Leave the truck here!\nWe can walk home; it's not far."
    scene 22_0118 with dissolve
    ali "If you don't mind, Lucy, I'll have a beer, too.\nThis wine already knocked me on my ass once!"
    ali "[mc] wants to leave early tomorrow, and I don't fancy the long drive home with another hangover."
    luc "Of course!"
    scene 22_0119 with dissolve
    luc "I'll be right back."
    ali "I'll give you a hand."
    scene 22_0120 with dis1
    scene 22_0121 with dis1
    scene 22_0122 with dis1
    if Violet.Has("Z00"):
        vi "The girls were very happy after they returned from the lake.\nI presume they got what they wanted?"
        mc "Yeah."
        scene 22_0123 with dissolve
        vi "God, I wish I could've been there with you, Honey.\nI can't imagine how beautiful it must've been!"
        mc "Can't lie, Vi. It was great.\nI wish you'd been there too."
        scene 22_0124 with dissolve
        vi "One day, Baby.\nWe can {b}all{/b} be together. I can't wait!"
        scene 22_0125 with dissolve
        vi "You should think about staying {i}here{/i} tonight.\nAlison and Cara can come home with Millie and me."
        vi "I can invite Hannah to sleepover, too."
        mc "Ohh... I don't know, Vi...\nAlison would find it kinda strange for me to wanna stay here, wouldn't she?"
        scene 22_0126 with dissolve
        vi "Just do what you {i}always{/i} do! Fall asleep!"
        vi "We all know what you're like."
        scene 22_0127 with dissolve
        vi "Pretend to be asleep before the movie ends, and I'll suggest we leave you here."
        vi "Alison knows how difficult it is to wake you, so I'm sure she'll agree."
        vi "And Lucy isn't going to object to having her brother all to herself for a while, is she?"
        scene 22_0128 with dissolve
        mc "Damn. I love you.\nYou know that, right?"
        mc "I can't decide if you're corrupting me, or I'm corrupting you... or Millie's corrupted us both!"
        scene 22_0129 with dissolve
        vi "Baby, there is no corruption!\nJust pure, unadulterated love."
        vi "This was always how we were meant to be. It just took us a while to figure it out!"
        mc "I'm glad we did."
        vi "Yeah, me too."
        scene 22_0130 with dissolve
        vi "Oh, and sit next to her for the movie."
        mc "Why?"
        vi "Let her snuggle up to you!\nThat's why I suggested something romantic for us to watch!"
        scene 22_0131 with dissolve
    else:
        vi "I feel terrible for not warning her about the wine last night!"
        scene 22_0131 with fade1
    luc "What are you two whispering about?"
    mc "We're tryin' to figure out how you became such a great cook!"
    scene 22_0132 with dissolve
    luc "I've {i}always{/i} been a great cook, thank you very much!"
    mc "Yeah?"
    mc "Then how come I remember you burning {b}soup{/b}?!"
    scene 22_0133 with dissolve
    luc "Because you had me pinned to the floor, sat on top of me, and wouldn't let me go until I declared you Mom's favorite child!"
    mc "Ahh yeah, I {i}did{/i} do that.\nCould've just admitted it, though; not my fault it was the truth!"
    scene 22_0134 with dissolve
    vi "Really? That's not what your mom told me."
    mc "What?!"
    scene 22_0135 with dissolve
    luc "[lol]"
    scene 22_0136 with dissolve
    luc "Are we ready for the movie?"
    mc "Yeah."
    vi "[mc], You're gonna end up with a stiff neck if you watch from there."
    luc "Yes, Vi's right.\nCome on, there's plenty of room here."
    scene 22_0137 with fadehold
    luc "Everyone ready?"
    vi "Yep."
    scene 22_0138 with Fade(4, 3, 3)
    mc "[whi]..Zzz.."
    scene 22_0139 with dissolve
    ali "You gotta be kidding me."
    scene 22_0140 with dissolve
    luc "Has he ever {i}not{/i} fallen asleep during a movie?"
    vi "Aww, leave him."
    scene 22_0141 with dissolve
    ali "We're not gonna be able to wake him! You know what he's like, Vi!"
    vi "It's fine. He can stay the night here."
    vi "You don't mind, right, Lucy?"
    scene 22_0142 with dissolve
    luc "No, of course not."
    vi "I was gonna invite Hannah over for a sleepover with the girls anyway."
    scene 22_0143 with dissolve
    vi "He'd probably prefer a quiet night here."
    scene 22_0144 with dissolve
    ali "Jeez. Can't take him anywhere, can we? [lol]"
    mc "[whi]..Zzz.."
    scene black with Fade(3, 3, 0)
    if Lucy.isActive() and persistent.Incest:
        scene 22_0145 with Fade(0, 0, 3)
        luc "[mc]?"
        call EmotionSml (mc, "Mumbles")
        luc "I'm going to put on my PJs, and I'll be back to keep you company for a while."
        luc "Don't want to leave you down here alone all night."
        scene 22_0146 with dis1
        scene 22_0147 with dis1
        scene 22_0148 with dis1
        if Violet.Has("Z00"):
            call OakHill_06_LucyExtended
        else:
            mc "[whi]..Zzz.."
        scene black with Fade(1,2,0)
    scene 22_0177 with Fade(0, 0, 2)
    luc "[mc]. Wake up."
    luc "Time for bed."
    scene 22_0178 with dissolve
    call EmotionSml (mc, "Groan")
    luc "Wake up!"
    mc "[whi]Lucy?"
    scene 22_0179 with dissolve
    mc "[whi]Where'd everyone go?"
    luc "You fell asleep again. They've gone home."
    luc "It's late. Go to bed."
    scene 22_0180 with dissolve
    luc "Don't go back to sleep there!"
    mc "Yeah, I'm goin'."
    scene black with Fade(2,2,0)
    if Lucy.isActive() and persistent.Incest:
        scene 22_0181 with Fade(0,0,2)
        pause 0.5
        scene 22_0182 with dis1
        scene 22_0183 with dis1
        mc "Night, Sis."
        luc "Goodnight."
        scene 22_0184 with dis1
        scene 22_0185 with dis1
        scene 22_0186 with dis1
        luc "[mc]... Would you..."
        scene 22_0187 with dissolve
        luc "Uhh..."
        luc "Nevermind. Goodnight."
        scene 22_0188 with dissolve
        mc "Wait. Would I {i}what{/i}?"
        luc "Nothing. Forget it."
        mc "C'mon, Lucy. You can ask me anything."
        scene 22_0189 with dissolve
        call Emotion (luc, "Sigh", "I was just wondering if you'd lie down with me for a while.")
        luc "I...miss falling asleep in a warm embrace."
        scene 22_0190 with dissolve
        luc "Sorry. I'm just being stupid.\nOne glass of wine too many. Go to bed."
        scene 22_0191 with dis1
        pause 0.5
        scene 22_0192 with dis1
        scene 22_0193 with dis1
        scene 22_0194 with dissolve
        mc "If my sister wants to cuddle, then that's what I'm gonna give her."
        luc "You don't mind?"
        mc "Not at all."
        scene 22_0195 with dissolve
        luc "No shoes on my bed."
        mc "Uhh... okay."
        call LucyReplay01
        scene 22_0288 with Fade(0, 3, 3)
        pause
        scene 22_0289 with fade2
        pause
        scene 22_0290 with fade1
        pause 0.5
        scene 22_0291 with dis1
        pause 0.5
    else:
        scene 22_0292 with Fade(0, 3, 3)
        pause
        scene 22_0293 with fade2
        pause
        scene 22_0294 with fade1
        pause 0.5
        scene 22_0295 with dis1
        pause 0.5
    scene 22_0296 with fade1
    scene 22_0297 with dis1
    pause 0.5
    scene 22_0298 with dis1
    scene 22_0299 with dis1
    pause 0.5
    scene 22_0300 with dis1
    mc "Lucy?"
    scene 22_0299 with dis1
    pause 0.5
    scene 22_0301 with dis1
    scene 22_0302 with dis1
    pause 0.5
    scene 22_0301 with dis1
    scene 22_0303 with dis1
    scene 22_0304 with dis1
    scene 22_0305 with dis1
    scene 22_0306 with fade1
    pause 0.5
    scene 22_0307 with fadehold
    mc "Hey.\nReady to go?"
    ali "Yeah. We're waiting on you!"
    scene 22_0308 with dissolve
    ali "I'll get Cara. She's upstairs with Millie and Hannah."
    mc "Great."
    if Alison.isSexual() and Violet.isSexual() and persistent.GroupSex:
        scene 22_0309 with dissolve
        mc "Sorry I fell asleep last night."
        ali "Yes, that was a little irritating!"
        ali "I was looking forward to us all having some fun!"
        scene 22_0310 with dissolve
        vi "What?"
        vi "You mean the three of us?... {i}together{/i}??"
        scene 22_0311 with dissolve
        ali "Yeah. Why not?\nNeither of us are prudes, and [mc]'s hardly gonna object, is he?"
        ali "If we're sharing him, there's no point in him running from room to room!"
        scene 22_0312 with dissolve
        ali "But only if you wanted to, Vi! No pressure!"
        ali "Don't you think it'd be fun, though?"
        scene 22_0313 with dissolve
        vi "Now you've put the thought in my head... I'm thinking - yes, it could be."
        vi "I'd be up for trying it, at least."
        scene 22_0314 with dissolve
        ali "I bet we gave him an erection just talking about it! [lol]"
        scene 22_0315 with dissolve
        mc "Damn right you have!"
        vi "[lol]"
    scene 22_0316 with dissolve
    if Violet.Has("Z00") and Lucy.isSexual():
        scene 22_0316 with dissolve
        vi "[whi]How'd it go with Lucy last night?"
        mc "[whi]Well, your plan worked - we had sex."
        scene 22_0317 with dissolve
        vi "[whi]Holy shit, [mc]! That's great!"
        vi "[whi]I didn't expect you to get {i}that{/i} far so soon!"
        vi "[whi]How was it??"
        scene 22_0318 with dissolve
        mc "[whi]Honestly, Vi... I dunno."
        mc "[whi]I mean, it was great - {b}really{/b} great!"
        scene 22_0319 with dissolve
        mc "[whi]But she regretted it pretty much straight after."
        mc "[whi]I think I went too far, too fast."
        mc "[whi]Couldn't even talk to her about it this morning."
        mc "[whi]She'd already left before I woke up. Probably to get away from me."
        scene 22_0320 with dissolve
        vi "[whi]Oh, Sweetheart, don't worry about it.\nIt's a confusing time for her."
        vi "[whi]Give her space to process everything."
        vi "[whi]She'll be okay, [mc]. She just needs to wrap her head around it first."
        mc "[whi]I hope you're right."
        scene 22_0321 with dissolve
        vi "[whi]When have I {i}ever{/i} been wrong?"
        vi "[whi]Trust me! You'll have her again."
        scene 22_0322 with dissolve
        vi "[whi]And she didn't leave to {i}get away{/i} from you!"
        vi "[whi]She mentioned yesterday that she had an early work meeting this morning."
        mc "[whi]Oh, okay. That makes me feel a {i}little{/i} better."
    else:
        mc "Can you say bye to Lucy for me? Didn't see her this morning; guess she was still in bed."
        vi "Sure.\nShe mentioned yesterday that she had an early work meeting this morning."
        mc "Ah, okay."
    scene 22_0323 with fade1
    han "See you soon, Unc!"
    scene 22_0324 with fade1
    mil "Bye, everyone!"
    scene black with Fade(3,1,0)
    jump OakHill_Leave
return

label OakHill_06_CleanUp:
    if Violet.Has("Told"):
        $ Violet.Add("A00")
        $ Violet.Del("Told")
    if Violet.Has("AteM"):
        $ Violet.Add("A01")
        $ Violet.Del("AteM")
    if Violet.Has("Kick"):
        $ Violet.Add("A02")
        $ Violet.Del("Kick")
    if Violet.Has("Fantasy"):
        $ Violet.Add("A03")
        $ Violet.Del("Fantasy")
    if Violet.Has("Saw"):
        $ Violet.Add("A04")
        $ Violet.Del("Saw")
    if Violet.Has("R3"):
        $ Violet.Add("A05")
        $ Violet.Del("R3")
    if Violet.Has("R1"):
        $ Violet.Add("A06")
        $ Violet.Del("R1")
    if Violet.Has("Anal"):
        $ Violet.Add("A07")
        $ Violet.Del("Anal")
    if Violet.Has("knowsabtcara"):
        $ Violet.Add("A08")
        $ Violet.Del("knowsabtcara")
    $ Violet.Del("i0")
    $ Violet.Del("i1")
    if Violet.isSexual() and (Violet.Has("A05") or Violet.Has("A06")) and Violet.Has("A08"):
        $ Violet.Add("Z00")
    if Millie.Has("AteV"):
        $ Millie.Add("A03")
        $ Millie.Del("AteV")
    if Lucy.Has("DadNews"):
        $ Lucy.Add("A00")
    $ Lucy.Del("DadNews")
    $ Lucy.Del("Ass2")
    if Hannah.Has("Toe"):
        $ Hannah.Add("A00")
        $ Hannah.Del("Toe")
    $ Hannah.Del("Knows")
return

label OakHill_06_FullHello:
    scene 21_0439 with dissolve
    mil "[whi]Mmhh."
    scene 21_0440 with dissolve
    vi "It's okay, Sweetheart. I know Millie's told you that I'm good with it."
    car "I, uhh, didn't know she'd told you that {i}I{/i} knew about it."
    scene 21_0441 with dissolve
    vi "Ohh, Sweetie!"
    scene 21_0442 with dissolve
    vi "I know everything!\nYour dad told me about you both."
    vi "What you and Millie have with him is amazing, and I think it's beautiful!"
    scene 21_0443 with dissolve
    car "God, you're so cool, Aunt Vi!\nI wish Mom were like you."
    vi "Try not to worry about it, Cara.\nLeave it to your dad and me to figure out."
    car "... You think she'd come around?"
    vi "Who knows? Maybe one day, with a bit of convincing!"
    scene 21_0444 with dissolve
    mil "Sis? Wanna say hello to Dad?"
    car "Yeah, I do."
    vi "Then go ahead, Sweetheart. Your mom's still fast asleep."
    scene 21_0445 with dis1
    scene 21_0446 with dis1
    scene 21_0447 with dis1
    scene 21_0448 with dissolve
    car "[whi]Mmhh."
    scene 21_0449 with dissolve
    car "[whi]..Mmmhh.."
    scene 21_0450 with dissolve
    mil "Think I'll be able to have {i}daddy time{/i} again before he leaves?"
    vi "Oh, Milz, I don't know, Sweetie.\nIt'll be tough with Alison here."
    mil "Can't you take her out somewhere again?"
    scene 21_0451 with dissolve
    vi "She had a little too much to drink last night.\nShe's got a hangover; I don't think she'll want to go anywhere today."
    vi "Why don't you take your dad out somewhere? Back to the lake, maybe?"
    scene 21_0452 with dissolve
    mil "Yeah! Cara said she wanted to try horse riding!"
    if Hannah.isSexual():
        scene 21_0453 with dissolve
        mil "Hannah might like to come too!"
        vi "It's sweet that you want to invite her, but won't she... get in the way?"
        mil "Mom..."
        vi "..."
        scene 21_0454 with dissolve
        vi "Hannah?!"
        scene 21_0455 with dissolve
        vi "What have we done, Milz? Your dad's out of control!"
    else:
        $ Violet.Del("Z00")
    scene 21_0456 with dissolve
    mil "C'mon, Sis. We need to get dressed!\nDad's taking us riding!"
    scene 21_0457 with dissolve
    mc "I am?"
    mil "Yep!"
    scene 21_0458 with dissolve
    mc "Guess I'm goin' horse riding."
    vi "[lol]"
    scene 21_0459 with dissolve
    vi "I'm sure they'll allow you a coffee first!\nI'll make you one."
    scene 21_0460 with dissolve
    mc "Not so fast!"
    mc "{i}You{/i} ain't said hello yet."
    scene 21_0461 with dissolve
    vi "[whi]Hi."
    scene 21_0462 with dis1
    vi "[whi]Mmhh."
    scene 21_0463 with dissolve
    vi "[whi]..Mmmhh.."
    scene 21_0464 with dissolve
    mc "How about we skip the coffee and go upstairs?"
    vi "Oh, Baby, we can't do that!\nYou're gonna need all the energy you have!"
    scene 21_0465 with dissolve
    vi "Why do you think the girls want to go horse riding?"
    vi "They want some {i}alone time{/i} with you!"
    scene 21_0466 with dissolve
    vi "But try to keep a little in reserve for later tonight."
    vi "Your wife needs you, too."
    scene 21_0467 with dissolve
    mc "I {b}always{/b} have a little in reserve for you, Sweetheart."
    if Hannah.isSexual():
        scene 21_0468 with dissolve
        vi "So, Hannah, huh?"
        mc "Yeah... I was gonna tell you."
        vi "I know, Baby."
        vi "God, I love you {i}so{/i} much!"
    scene 21_0469 with dis1
    vi "[whi]Mmhh."
    if Hannah.isSexual() and Lucy.isActive():
        scene 21_0470 with dis1
        vi "Be careful, though... Not sure how Lucy will react if she finds out."
        mc "Maybe I can get her on-side too."
        scene 21_0471 with dissolve
        vi "{i}On-side{/i}?\nWhat do you mean?"
        mc "Things are... changing... between us."
        mc "I think... I'm sexually attracted to her.\n... I'm sure she feels the same way about me."
        vi "You want to have sex... with your sister??"
        mc "... I've thought about it."
        scene 21_0472 with dissolve
        mc "I can't help it; it just kinda pops into my head sometimes."
        mc "And when it does... I get so damn horny."
        mc "My dick gets so hard it fuckin' hurts."
        scene 21_0473 with dissolve
        vi "Damn!"
        scene 21_0474 with dissolve
        vi "God, I bet she'd fuckin' love it, Baby."
        scene 21_0475 with vpunch
        vi "[whi]..Mmmhh.."
        scene 21_0476 with dissolve
        call Moan (vi)
        scene 21_0477 with dissolve
        vi "[ss]Mmmhhh."
        scene 21_0478 with dissolve
        vi "If you want your sister, you should make it happen, [mc]."
        mc "I'm tryin', Vi."
        scene 21_0479 with dissolve
        call Moan (vi)
        mc "I know she wants it, but she's fighting it."
        mc "I grab her ass the same as I do yours, and she likes it."
        scene 21_0480 with dissolve
        image MiscA_01 = Movie(play="images/e21/21_0481.webm")
        show MiscA_01
        call Moan (vi)
        scene 21_0482 with dissolve
        mc "We've kissed - passionately."
        vi "[ss]...Ohhh, Baby..."
        mc "My tongue was deep inside her mouth... I wanted it to be in her pussy so bad."
        scene 21_0483 with dissolve
        call Moan (vi)
        mc "I wanted to devour every drop of my sister's juice."
        scene 21_0484 with dissolve
        mc "I wanted to open her legs wide, climb on top of her, and thrust my rock-hard dick as deep as it could go, inside her."
        call CharCum ("e21/21_0484.webp", "e21/21_0485.webp", vi, "...Ohhhhhhhhh...")
        scene 21_0486 with dissolve
        vi "[ss]Mmhh."
        vi "[whi]Was {i}any{/i} of that true? Or was it just for me? "
        scene 21_0487 with dissolve
        mc "It was {b}all{/b} true."
        scene 21_0488 with dissolve
        vi "Lucy deserves a little happiness.\nShe's been so lonely for so long."
        vi "She needs you, [mc]. She needs her brother's love."
        vi "Don't give up on her."
        scene 21_0489 with dissolve
        vi "[whi]Mmmhh."
        scene 21_0490 with dissolve
        vi "[whi]..Mmmhh.."
        scene 21_0491 with dissolve
    else:
        scene 21_0472 with dis1
        $ Violet.Del("Z00")
    vi "I'd better make that coffee."
    scene 21_0492 with dissolve
    vi "Why don't you check if Alison's awake yet? She's in the guest room."
    mc "Okay."
return

label OakHill_06_AlisonHello:
    scene 21_0497 with fade1
    mc "[whi]Alison?"
    scene 21_0498 with dissolve
    ali "[whi]..Zzzz.."
    scene 21_0499 with dissolve
    mct "Heh. Lightweight."
    scene 21_0500 with dissolve
    call EmotionSml (ali, "Groan")
    scene 21_0501 with dissolve
    ali "[whi][mc]?"
    ali "[whi]Jesus. What time is it??\nHave I been asleep all morning??"
    scene 21_0502 with dissolve
    mc "Nah. I got here early."
    call Emotion (ali, "Sigh", "Ughh... My head.")
    scene 21_0503 with dissolve
    ali "What the heck do they put in the wine down here?! I didn't think I had that many!"
    call laugh (mc, "Let me guess... You spent the evening at Lucy's?")
    ali "Uh-huh."
    mc "Yeah, my sister likes her wine strong!\nGuess Violet's used to it now, and forgot to give you the heads-up."
    scene 21_0504 with dissolve
    ali "I'm sorry.\nYou didn't make plans for us today, did you?"
    ali "Not sure I'll even be able to get out of bed for a while."
    mc "Nah, stay where you are.\nI'm taking Cara and Millie horse riding."
    scene 21_0505 with dissolve
    ali "Cara on a horse?! That'll be a sight!"
    ali "She's been so happy down here with her sister. They've been inseparable."
    ali "Constantly laughing and giggling. It's been nice to see.\nShe's been getting on great with Hannah, too."
    scene 21_0506 with dissolve
    ali "I feel guilty for having to take her home."
    mc "Don't worry about it.\nI'll bring her back here whenever she wants, and Millie can visit us sometime, too!"
    scene 21_0507 with dissolve
    ali "You're a great dad, [mc]."
    ali "I wish I could come with you today, but I don't feel so good."
    scene 21_0508 with dissolve
    mc "Bullshit! You hate horse riding as much as I do!\nYou're lovin' this!"
    ali "[lol]"
    scene 21_0509 with dissolve
    ali "Ouch... Don't make me laugh; it hurts my head!"
    call laugh (mc)
    scene black with Fade(4, 2, 0)
return

label OakHill_06_BackToTheLake:
    call CenterText ("A little while later.")
    scene 21_0510 with Fade(1, 1, 3)
    mil "YAH!"
    scene 21_0511 with fade1
    car "She's sooo beautiful!"
    mc "You're doin' great, Pipsqueak!"
    scene 21_0512 with dissolve
    mc "You're a natural!\nI thought you'd be more nervous."
    scene 21_0513 with dissolve
    car "I love it, Dad!\nJust don't let go![lol]"
    mc "Don't worry, I got you."
    scene 21_0514 with dissolve
    mc "Millie and Hannah were fine with your pace; you didn't need to tell them to ride on ahead."
    car "Yeah, I know.\nI didn't want to spoil their fun. Millie told me how they love racing each other."
    scene 21_0515 with dissolve
    mc "That's true! They even {i}almost{/i} beat me! Heh."
    car "Really? That's not what I heard!"
    mc "I took a wrong turn! I would've {b}definitely{/b} beaten them!"
    car "[lol]"
    scene 21_0516 with dissolve
    car "I've had such a blast being down here, Dad. Thanks for bringing us!"
    mc "My pleasure, Sweetheart."
    scene 21_0517 with dissolve
    car "Millie said she'd like to come and stay with us sometime. Can she?"
    mc "Yeah, of course!"
    $ p=0
    if not persistent.GroupSex and Millie.isSexual(None, True):
        $ p=1
    elif persistent.GroupSex and Millie.isSexual(None, True) and Cara.isSexual() and Hannah.isSexual():
        $ p=2
    if p==1:
        scene 21_0518 with dissolve
        car "When we're at the lake, Hannah and I are gonna go for a walk, okay?"
        mc "Uh... Why?"
        car "Millie wants to have sex with you.\nWe'll give you some alone time with her."
        scene 21_0519 with dissolve
        if not Cara.isSexual():
            mc "She told you?"
            car "Of course she did!"
        else:
            mc "What about you?"
            car "We can have sex when we're back home!\nMillie doesn't know when you'll be down here again."
    elif p==2:
        scene 21_0519 with dissolve
        car "How much further to the lake?"
        mc "It's not far."
        car "Cool. Can't wait to get there!"
    scene 21_0520 with fade2
    car "Oh, wow! It's so pretty!"
    scene 21_0521 with dissolve
    mil "Sorry guys! We didn't mean to get so far ahead!"
    mc "Who won?"
    scene 21_0522 with dissolve
    mil "It was too close to call."
    scene 21_0523 with dissolve
    han "You're so full of shit!"
    mil "[lol]"
    scene 21_0524 with dissolve
    mil "I {b}would've{/b} won... but I took a wrong turn!"
    scene 21_0525 with dissolve
    han "[lol]"
    scene 21_0526 with dissolve
    mil "How was your first horse ride, Sis?"
    car "So great!"
    scene 21_0527 with dissolve
    han "You did really well!\nIt took me about three lessons before I'd even leave the paddock!"
    car "Dad held on to the reins most of the way!"
    scene 21_0528 with dissolve
    han "He only did that to stop {i}you{/i} beating him here, too!"
    car "[lol]"
    scene 21_0529 with dissolve
    mc "Damn, such a nice day!"
    scene 21_0530 with dissolve
    scene 21_0531 with dis1
    mc "Who's up for a spot of sunbathing?!"
    if p==1:
        scene 21_0790 with dissolve
        han "Later.\nThere's an awesome cave a little further down the trail; Cara wants to check it out."
        scene 21_0791 with dissolve
        mil "I'll stay and sunbathe with you, Dad!"
        mc "Okay."
        scene 21_0792 with dissolve
        han "C'mon, Cuz!"
        car "Have fun!"
        call MillieReplay09
    elif p==2:
        call CaraReplay07
    scene black with Fade(3, 2, 0)
    call CenterText ("You spend some time relaxing at the lake.")
return

label OakHill_06_LucyExtended:
    scene 22_0149 with dis1
    mct "Heh."
    scene 22_0150 with dissolve
    mct "This is silly.\nWhy did I let Vi talk me into it?"
    mct "Oh well... might as well let it play out now."
    scene 22_0151 with fade2
    luc "Still asleep?"
    scene 22_0152 with dis1
    luc "Mind if I have another drink, Bro?"
    scene 22_0153 with dis1
    luc "I know I'm a little drunk, but what's one more, right?"
    scene 22_0154 with dis1
    luc "[mc]?"
    scene 22_0155 with dissolve
    mc "[whi]Zzz."
    scene 22_0156 with dissolve
    luc "Are you awake?"
    scene 22_0157 with dis1
    luc "Okay, just checking."
    scene 22_0158 with dis1
    pause 0.5
    scene 22_0159 with dis1
    pause 0.5
    scene 22_0160 with dis1
    luc "You didn't grope me today."
    luc "I know I act indifferently to it... But I like it when you gently squeeze my ass."
    mct "Believe me - I wanted to!"
    scene 22_0161 with dissolve
    mc "[whi]..Zzz.."
    scene 22_0162 with dis1
    pause 0.5
    scene 22_0163 with dis1
    luc "I have a confession to make."
    scene 22_0164 with dissolve
    luc "I wasn't honest with you."
    luc "When you asked if I'd ever thought about us having sex - I lied when I said no."
    scene 22_0165 with dissolve
    luc "The first time it happened, I was disgusted with myself."
    luc "Convinced myself that I was just lonely and horny."
    luc "I pushed those thoughts out as fast as I could!"
    scene 22_0166 with dissolve
    luc "They kept coming back, though."
    luc "The closer we were getting, the more intense my imagination got."
    luc "At some point I just stopped fighting it."
    scene 22_0167 with dissolve
    luc "I let my head fill with thoughts of us."
    luc "God, it was amazing."
    scene 22_0168 with dissolve
    luc "So, yeah... I {b}do{/b} think about us fucking. All the time."
    scene 22_0169 with dis1
    scene 22_0170 with dis1
    scene 22_0171 with dis1
    luc "That's me done."
    scene 22_0172 with dissolve
    luc "I'd better prepare your bed, on the off chance I can wake you."
    scene 22_0173 with dissolve
    scene 22_0174 with dis1
    scene 22_0175 with dis1
    pause 0.5
    scene 22_0176 with dis1
    mct "Damn, Violet. This was a great idea! Heh."
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
