default persistent.chestnut_active = False
default chestnut_id = "CNC"
default chestnut_ch = 1
default chestnut_open = False
default chestnut_info = [""]

label UpdateChestnutData:

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
