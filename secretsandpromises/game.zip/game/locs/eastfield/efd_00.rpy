default persistent.eastfield_active = False
default eastfield_id = "EF"
default eastfield_ch = 1
default eastfield_open = False
default eastfield_info = [""]

label UpdateEastFieldData:

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
