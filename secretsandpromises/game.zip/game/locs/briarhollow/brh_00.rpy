default persistent.briarhollow_active = False
default briarhollow_id = "BH"
default briarhollow_ch = 1
default briarhollow_open = False
default briarhollow_info = [""]

default persistent.AmeliaLocked = True
default Amelia_name = ""
define ame = Character("[Amelia_name]", what_color=Wht, what_outlines=PrpO,who_color=Pnk, who_outlines=[(3, Blk)], image="amelia")
image side amelia cell = side+"amelia_c.png"
image side amelia h = side+"amelia_hp.png"
image side amelia s = side+"amelia_sd.png"
image side amelia a = side+"amelia_an.png"
image side amelia sh = side+"amelia_sh.png"
image side amelia su = side+"amelia_su.png"
default Amelia = Stats()

label UpdateBriarHollowData:

return

screen BriarHollow_Replays():
    $ next_x=0
    $ next_y=0
    frame:
        style "gallery_replays"
        use ReplayItemBtn(next_x, next_y, "brh", "amelia", Amelia_Replay, persistent.AmeliaLocked, "Barmaid at Hanks bar in Cedar Grove.")
        python:
            next_x, next_y=IncreaseXY(next_x,next_y)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
