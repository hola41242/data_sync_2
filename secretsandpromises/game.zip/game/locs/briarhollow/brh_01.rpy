label BriarHollow_Start1:
    $ persistent.briarhollow_active=True
    $ curLOC=briarhollow_id
    centered "{font=Vanilla.ttf}{color=#ffff}Two hours later..." with Fade(0, 2, 1)
    scene 16_0001 with Fade(2,1,3)
    $ aPs(0, True)
    scene 16_0002 with dis1
    $ aPs()
    scene 16_0003 with dis1
    $ aPs()
    scene 16_0004 with dis1
    $ aPs()
    scene 16_0005 with dis1
    $ aPs()
    scene 16_0006 with dis1
    $ aPs()
    scene 16_0007 with dis1
    $ aPs()
    scene 16_0008 with dis1
    $ aPs()
    scene 16_0009 with dis1
    $ aPs()
    scene 16_0010 with dis1
    $ aPs(0, False, True)
    scene 16_0011 with dissolve
    mct "Where the hell's she going?"
    scene 16_0012 with fade1
    $ aPs(0, True)
    scene 16_0013 with dis1
    $ aPs()
    scene 16_0014 with dis1
    $ aPs()
    scene 16_0015 with dis1
    $ aPs()
    scene 16_0016 with dis1
    $ aPs(0, False, True)
    scene 16_0017 with dissolve
    mct "Briar Hollow?\nLong way from Cedar Grove."
    scene 16_0018 with fade1
    $ aPs(0, True)
    scene 16_0019 with dis1
    $ aPs()
    scene 16_0020 with dis1
    $ aPs()
    scene 16_0021 with dis1
    $ aPs()
    scene 16_0022 with dis1
    $ aPs(0, False, True)
    scene 16_0023 with dissolve
    mct "She's finally stopping..."
    scene 16_0024 with dis1
    $ aPs(0, True)
    scene 16_0025 with dis1
    $ aPs(0, False, True)
    scene 16_0026 with dissolve
    mct "Straight from the bar to here... Didn't even go home first..."
    scene 16_0027 with dissolve
    mct "...What {b}is{/b} she up to??"
    scene 16_0028 with dis1
    $ aPs(0, True)
    scene 16_0029 with dis1
    scene 16_0030 with dis1
    $ aPs()
    scene 16_0031 with fade1
    $ aPs()
    scene 16_0032 with dis1
    $ aPs()
    scene 16_0033 with dis1
    $ aPs(1)
    scene 16_0034 with dissolve
    $ aPs()
    scene 16_0035 with dis1
    $ aPs(0, False, True)
    scene 16_0036 with dis1
    mct "Does she live here??"
    scene 16_0037 with dissolve
    mct "Me showing up at her door is gonna scare the shit out of her...\nNot what I wanna do..."
    mct "But I tried being friendly, and she still lied to me..."
    scene 16_0038 with dissolve
    mct "She's given me no choice... I {b}need{/b} to know the real reason she was following me."
    scene 16_0039 with dis1
    play sound "knock.mp3"
    pause 0.5
    scene 16_0040 with dis1
    pause
    scene 16_0041 with dissolve
    mct "Gave her plenty of opportunity to be straight with me."
    scene 16_0042 with dissolve
    call Emotion (ame, "GASP", "WHAT THE FUCK?!")
    mc "Hi."
    scene 16_0043 with dissolve
    ame "WHY?! {w=0.5}{nw}"
    play sound "doorslam.mp3"
    scene 16_0044 with hpunch
    mc "Amelia!"
    ame "[whi]Go away!"
    mc "Not until you talk to me."
    scene 16_0045 with dissolve
    play sound "knock.mp3"
    mc "Amelia, please.\nI just wanna--"
    scene 16_0046 with hpunch
    ame "HANDS ON YOUR HEAD!"
    scene 16_0047 with dissolve
    mc "WHOA!"
    ame "I SAID ON YOUR FUCKIN' HEAD! {b}NOW!{/b}"
    scene 16_0048 with dissolve
    mc "Okay! Jesus!\nTake it easy with that thing."
    scene 16_0049 with dissolve
    ame "Inside! And keep your hands where they are!"
    scene 16_0050 with dissolve
    ame "Slowly."
    scene 16_0051 with dissolve
    ame "Keep moving."
    scene 16_0052 with dissolve
    ame "That's far enough."
    scene 16_0053 with dissolve
    ame "Get down on your knees."
    scene 16_0054 with dissolve
    scene 16_0055 with dissolve
    pause 0.5
    scene 16_0056 with dissolve
    pause
    scene 16_0057 with fade1
    mc "Handcuffs?? Seriously?!"
    scene 16_0058 with dissolve
    mc "Are you a cop??"
    ame "No."
    scene 16_0059 with dissolve
    ame "Okay, slowly... get up, walk over to the couch, and sit."
    scene 16_0060 with dis1
    scene 16_0061 with dis1
    scene 16_0062 with dissolve
    ame "What the fuck are you doing here?"
    mc "I followed you."
    scene 16_0063 with dissolve
    ame "Yeah, no shit! {i}Why{/i}??"
    mc "If you want the truth..."
    scene 16_0064 with dissolve
    mc "It's slightly embarrassing, but... I think you're kinda cute.\nI wanted to learn more about you."
    scene 16_0065 with dissolve
    ame "You think you're funny. You're not."
    mc "You gonna shoot me? Do it."
    scene 16_0066 with dissolve
    mc "If you're lucky, your neighbors won't report the gunshot."
    mc "You'll struggle to get my dead, bloody body out of here all by yourself, but I'm sure you'll manage."
    mc "I {i}did{/i} notice a security camera at the building's entrance, though, so you'll probably want to deactivate it first."
    scene 16_0067 with dissolve
    ame "Or maybe {b}I'll{/b} call the cops..."
    ame "Tell them I shot an intruder in self-defense because he threatened to rape me."
    scene 16_0068 with dissolve
    mc "Yeah, that might work... but I've tightened the cuffs."
    mc "Enough to leave marks on my wrists that'll be difficult for you to explain away."
    scene 16_0069 with dissolve
    ame "I'll take my chances."
    ame "Tell me why you're here."
    mc "You {b}know{/b} why I'm here."
    scene 16_0070 with dissolve
    ame "Damn you, [mc]!\nI {b}wasn't{/b} there for you! I told you that!"
    ame "Why couldn't you just let it be?!"
    scene 16_0071
    ame "FUUUCK!{w=1}{nw}" with hpunch
    scene 16_0072 with dissolve
    call Emotion (ame, "Sigh", "Okay...")
    scene 16_0073 with dissolve
    ame "Don't you fuckin' move. Understand?"
    mc "Yeah."
    ame "I mean it, [mc]! I {b}will{/b} shoot you if I have to!"
    mc "I believe you."
    scene 16_0074 with dissolve
    call Emotion (ame, "Muttering", "", True)
    scene 16_0075 with dissolve
    mct "Well, whatever it is she's up to, she just confirmed it's not for Hank."
    scene 16_0076 with dissolve
    mct "That was genuine panic."
    scene 16_0077 with dissolve
    mct "I can understand the gun, but why does she have handcuffs in her home?"
    mct "...Not the kinky kind either! They're the real deal..."
    mct "Said she wasn't a cop ... think that's the first thing she's told me that I actually believe."
    scene 16_0078 with dissolve
    call Emotion (ame, "Muffled talking", "", True)
    mct "Is there somebody else here??"
    scene 16_0079 with dissolve
    ame cell "[whi]Mh-mhh... Yeah..."
    scene 16_0080 with dissolve
    ame cell "[whi]...But.........No........Okay..."
    mct "Wonder who she's talking to?"
    scene 16_0081 with dissolve
    call Emotion (ame, "Muffled talking", "", True)
    mct "She's not working alone... Interesting."
    call CenterText ("A few more minutes pass...")
    scene 16_0082 with fade1
    scene 16_0083 with dissolve
    ame "You've left me with two bad choices - Kill you, or trust you."
    scene 16_0084 with dissolve
    ame "If you want to walk out of here, you need to convince me that I {b}can{/b} trust you."
    menu:
        "Convince her with a lie":
            $ Amelia.Score(-1)
        "[wk_y]Convince her with a truth":
            $ Amelia.Score(1)
            $ Amelia.Add("A00")
    scene 16_0085 with dissolve
    if Amelia.hasScore(1):
        mc "I helped Sue kidnap her daughter from Anton."
        mc "I was worried you could be working for him.\nI needed to find out, one way or the other."
        scene 16_0086 with dissolve
        ame "I'm not."
        mc "Okay. That's all I needed to know."
        scene 16_0087 with dissolve
        ame "Shooting you is a waste of a bullet."
        ame "When Anton finds out what you've done - and he will - you're going to wish I {b}had{/b} pulled the trigger."
        scene 16_0088 with dissolve
        mc "When that time comes, I'll have to deal with it."
        mc "Let's just say Sue was {i}economical{/i} with the truth.\nI didn't find out about Anton until later."
        scene 16_0089 with dissolve
        ame "She played you?"
        scene 16_0090 with dis1
        call Emotion (ame, "Sigh", "Yeah, I heard she's good at that.")
    else:
        mc "I think Hank - or one of his guys - killed my friend.\nI'm looking for answers."
        mc "When I saw you following me, I thought they were on to me... Needed to know for sure, one way or the other."
        scene 16_0086 with dissolve
        ame "Keep talking."
        mc "His name was Pete. He was murdered about six months ago."
        mc "I know he was mixed up with Hank. I need to know what happened."
        ame "You're looking for revenge?"
        mc "Justice."
        scene 16_0087 with dissolve
        ame "You won't find it. Not here."
        ame "I can't help you. It's before my time.\nNever heard anyone talk about him, either."
        scene 16_0088 with dissolve
        mc "I wasn't asking for your help."
        mc "Just need you to keep quiet."
        scene 16_0089 with dissolve
        ame "I can do that..."
        scene 16_0090 with dis1
        ame "But I need something in return."
    scene 16_0091 with dis1
    scene 16_0092 with dis1
    ame "Tell me about the doctor."
    mc "Doctor?"
    ame "The one you and Hank talked about earlier."
    scene 16_0093 with dissolve
    mc "Not much to tell. First time I'd met him."
    ame "So he's male. What else?"
    mc "Asian, old.\nSmall guy, seemed quite frail. Likes a drink."
    ame "Get his name?"
    mc "No.\nHe's got family. Hank was using them against him, threatening to hurt them."
    scene 16_0094 with dissolve
    ame "Doctor Lee."
    ame "You've confirmed he's still alive. His family wasn't sure."
    ame "Where's he being held?"
    scene 16_0095 with dissolve
    mc "No idea."
    mc "Hank took me to a warehouse.\nIt was just a few minutes' drive from the bar."
    scene 16_0096 with dissolve
    mc "They had a prisoner there. Wanted me to... question him.\nThe doc was there to keep him alive."
    ame "That's helpful.\nThey only have one warehouse that close to the bar."
    mc "What's your interest in the doctor?"
    scene 16_0097 with dissolve
    ame "Doctor Lee's been missing for five months."
    ame "His family contacted the police and filed a report, but have heard nothing since."
    ame "Four months ago, the Lee family hired me to find him."
    mc "{i}Hired{/i} you?"
    scene 16_0098 with dissolve
    ame "I'm a private investigator."
    ame "I followed a thread that eventually led me to Hank's organization."
    scene 16_0099 with dissolve
    ame "I walked into that bar wearing the sluttiest dress I could find, and asked if they were hiring."
    ame "Hank immediately offered me a job behind the bar, and I took it."
    ame "Been there ever since."
    scene 16_0100 with dissolve
    mc "Still doesn't explain why you were in Springhaven."
    ame "It wasn't the first time I'd been there.\nI had no idea where Doctor Lee was being held."
    ame "So, occasionally, I'd stake out other persons of interest."
    ame "Springhaven, Eastfield, Brookvale, Lakeshore... I've been to them all."
    scene 16_0101 with dissolve
    ame "You're the new guy, and I didn't have any information about you."
    ame "I didn't go to Springhaven looking for {i}you{/i} in particular, but when I saw you leaving Sue's house... I decided to follow you."
    scene 16_0102 with dissolve
    mc "Yeah... About that day..."
    mc "I'm sorry if I scared you.\nI had no idea it was you in the car."
    mc "Sorry about {i}this{/i}, too.\nI didn't want to come here. I didn't want to knock on your door."
    scene 16_0103 with dissolve
    ame "You {b}did{/b} frighten me, but, believe it or not, I was grateful.\nYou taught me a valuable lesson."
    ame "You're not the first person I've followed, but you {i}were{/i} the first to catch me in the act."
    ame "You showed me I need to be even more discreet.\n... And {i}never{/i} follow the target down a blind alley!"
    scene 16_0104 with dissolve
    ame "Okay..."
    scene 16_0105 with dissolve
    ame "Let's get those cuffs off."
    scene 16_0106 with fade1
    mc "Thanks."
    ame "They hadn't been tightened."
    scene 16_0107 with dissolve
    mc "Nah. Sorry."
    scene 16_0108 with fade
    ame "If you do happen to see Doctor Lee again, tell him not to worry about his family. They're safe."
    mc "Sure."
    if Amelia.Has("A00"):
        ame "And I'll give you a heads-up if I hear anything about Anton."
    else:
        ame "And if I hear anything about your friend, I'll let you know."
    mc "Thanks. Appreciate it."
    ame "Guess I'll see you around then."
    scene 16_0109 with dissolve
    mc "I have a {i}really{/i} long drive ahead of me..."
    mc "Would it be too much to ask if I could use your bathroom quickly?"
    ame "Uhh, sure. It's straight down the hall."
    scene 16_0110 with dissolve
    mc "You're a star! Thanks."
    scene 16_0111 with fade1
    mc "And again, I'm sorry for showing up here."
    ame "And I apologize for threatening to shoot you."
    scene 16_0112 with dissolve
    mc "See ya, Amelia."
    ame "Bye."
    scene 16_0113 with dis1
    scene 16_0114 with dis1
    scene 16_0115 with dis1
    scene 16_0116 with fade2
    mct "Need to get this to Alysha as soon as I can."
    scene 16_0117 with dis1
    scene 16_0118 with dis1
    scene 16_0119 with dis1
    jump BriarHollow_Leave
return

label BriarHollow_Leave:
    scene black with Fade(3, 2, 1)
    $ briarhollow_open=False
    $ briarhollow_ch+=1
    call CheckShOpen
    jump ShowMap
return

label BriarHollow_QuickMeeting:
    call CenterText ("A little while later.")
    scene 22_0001 with Fade(0, 0, 3)
    call ShowLocation (briarhollow_id)
    pause
    scene black with Fade(1,1,0)
    play sound "knock.mp3"
    scene 22_0002 with Fade(0, 0, 2)
    pause 0.5
    scene 22_0003 with dissolve
    ame "Thanks for coming."
    scene 22_0004 with dis1
    scene 22_0005 with dis1
    scene 22_0006 with dissolve
    ame "Can I get you a drink before we begin?"
    mc "No thanks. Let's just get this over with."
    scene 22_0007 with dissolve
    ame "Okay. Take a seat."
    scene 22_0008 with dissolve
    mc "What the hell's this?\nYou recording me?"
    scene 22_0009 with dissolve
    ame "I {i}will{/i} be recording this conversation, yes."
    ame "Everything you say here will be on the record."
    scene 22_0010 with dissolve
    ame "It's in your own best interest to be completely honest with me, [mc]."
    ame "We need to know what you know, including any crimes you've committed whilst working for Sue."
    scene 22_0011 with dissolve
    mc "You're fuckin' kidding, right?"
    mc "{b}IF{/b} I'd broken the law, why would I implicate myself to the FBI?!"
    scene 22_0012 with dissolve
    ame "Because it's the only way we can protect you from any consequences."
    ame "We understand you can't work for these people {i}without{/i} breaking a few laws."
    scene 22_0013 with dissolve
    ame "As long as you had a legitimate reason, we can protect you from anything you've done."
    ame "But we can only do that if we know about it.\nIf something comes up afterward that you didn't tell us about, you'll be on your own."
    scene 22_0014 with dissolve
    ame "I know we got off on the wrong foot, but I'm on your side."
    ame "You're the best asset we have, and I don't want anything to jepordize that."
    ame "Please trust me."
    scene 22_0015 with dissolve
    mc "I'm trying to trust you, Amelia. {b}You{/b}."
    mc "But what about those around you? Your team."
    scene 22_0016 with dissolve
    ame "They were hand-picked by my boss - Someone I trust with my life."
    ame "Every team member was thoroughly vetted before bringing them on-board."
    ame "Our circle is small - and air-tight."
    scene 22_0017 with dissolve
    ame "If we had a leak, I'd be dead already."
    ame "I trust every single one of them."
    scene 22_0018 with dissolve
    ame "Whatever you tell us on this recording, it's {i}not{/i} to implicate you."
    scene 22_0019 with dissolve
    mc "And if I refuse?"
    scene 22_0020 with dissolve
    ame "I'm being honest and upfront with you.\nI could've hidden the recorder before you came in."
    ame "The choice is yours, but you need to choose now."
    mc "..."
    call Emotion (mc, "Sigh", "...Fine.")
    mc "What do you want to know?"
    scene 22_0021 with dissolve
    ame "Everything."
    scene 22_0022 with dissolve
    ame "Start at the beginning. How you first got involved with Sue."
    scene 22_0023 with dissolve
    mc "I went to Springhaven to deliver a letter..."
    scene black with Fade(4, 4, 4)
    call CenterText ("You tell Amelia your story.")
    if Nettie.isActive():
        call CenterText ("... But you decide to NOT to reveal anything about Hayley just yet.")
    scene 22_0024 with fade1
    mc "That's it."
    ame "Jesus."
    scene 22_0025 with dissolve
    ame "We had no idea Sue was looking for a way out.\nThat's valuable intel!"
    ame "Do you think she can be flipped?"
    scene 22_0026 with dissolve
    mc "No chance!"
    mc "She'd manipulate you into taking out the rest of them and end up running everything herself!"
    mc "The only reason she wants to run is for her daughter's sake.\nTake away that threat and she'd stay."
    if JamesD:
        scene 22_0027 with dissolve
        if SimonD:
            ame "Why did you help cover up James and Simon's murder?"
        else:
            ame "Why did you help cover up James' murder?"
        ame "You'd already met Alysha by then - a cop who you trusted - why not report it?"
        ame "Wasn't {i}that{/i} your way out of the mess you found yourself in?"
        scene 22_0028 with dissolve
        mc "Taking Sue out of the game wouldn't have changed anything."
        mc "She said it herself - she'd have been replaced within hours.\nI'd be back to square one, and my family would've been in even {b}more{/b} danger."
        mc "If I helped her though, I'd gain her trust and buy myself more time."
        if SimonD:
            scene 22_0029 with dissolve
            ame "I met Simon and Douglas once or twice at the bar."
            ame "I can see why you named them Asshole1 and Asshole2, but for the sake of the recording, let's keep to real names."
            ame "You let Douglas leave. Any idea where he went?"
            scene 22_0030 with dissolve
            mc "Nope."
            mc "I gave him the keys to James' van and told him to get as far away as he could."
            mc "He was frightened.\nIf he has any sense he'll still be in hiding."
            scene 22_0031 with dissolve
            ame "I'll put out an {i}All Agencies Alert{/i}.\nWe need to find him."
            mc "Why?"
            ame "He can corroborate your version of events for a start!"
            ame "Two eye witnesses to a double-murder is better than one."
    scene 22_0032 with dissolve
    ame "Tell me more about Melissa."
    ame "You're right about her being a potential high-value witness, but would she be willing?"
    scene 22_0033 with dissolve
    mc "Can't say for sure.\nDawn seems to think so."
    mc "Melissa just wants a normal life.\nIf you can offer her that, then maybe."
    ame "Anton's still looking for her.\nI caught part of a conversation he had with Hank at the bar."
    ame "He no longer believes she simply ran away with a boyfriend."
    scene 22_0034 with dissolve
    ame "He thinks she's still in Lakeshore, hiding out somewhere, and he's ordered his men to do everything it takes to track her down."
    ame "They're systematically searching abandoned buildings on the outskirts of town."
    ame "He has a lot of guys like you - ex-military. Professionals."
    ame "It's only a matter of time before they find your safehouse."
    scene 22_0035 with dissolve
    mc "Yeah. It's time to get her out of there."
    ame "I can help."
    ame "We have a secure location that you can use."
    mc "Nah, I'm not putting her in an FBI safehouse."
    scene 22_0036 with dissolve
    ame "It's off-the-book.\nOnly two people knows it exists - me, and my boss."
    ame "It's my fallback for if anything goes wrong."
    scene 22_0037 with dissolve
    ame "We... {i}accuired{/i} it during a previous investigation."
    ame "We knew we'd need somewhere safe for this operation, so we deliberately kept it out of our reports."
    scene 22_0038 with dissolve
    mc "Isn't that illegal? Doesn't that make {i}you{/i} corrupt?"
    ame "Like I said - we can't do what we're doing {i}without{/i} breaking a few laws."
    scene 22_0039 with dissolve
    ame "When this is all over, my boss will come clean to the director."
    scene 22_0040 with dissolve
    ame "We {b}all{/b} have a recording."
    scene 22_0041 with dissolve
    mc "So where is it? This non-existant safehouse."
    scene 22_0042 with dissolve
    scene 22_0043 with dissolve
    scene 22_0044 with dissolve
    ame "Eastfield."
    scene 22_0045 with dissolve
    ame "I can send you the location."
    ame "We can meet-up there so you can check the place out for yourself."
    scene 22_0046 with dissolve
    mc "Why are you doing this, Amelia?"
    ame "It's my job."
    mc "Yeah... but there's more to it.\nYou said you volunteered. Why?"
    ame "..."
    ame "This meeting is officially over. You've given me what I needed."
    scene 22_0047 with dissolve
    ame "Now, it's just you and me; Two people talking."
    ame "So how about that coffee?"
    mc "Okay."
    scene 22_0048 with fade1
    ame "I'm third generation law enforcement."
    ame "My grandfather was a sheriff in this very town."
    scene 22_0049 with dissolve
    ame "My father followed in his footsteps and progressed to the FBI - where he met my mother."
    ame "Back then they didn't recruit many female agents so my dad was immediately intrigued."
    scene 22_0050 with dissolve
    ame "They fell in love, got married and had me."
    ame "As far back as I can remember, I always wanted to be a cop - I guess it was in my blood."
    scene 22_0051 with dissolve
    ame "My parents weren't so keen.\nThey wanted me to choose a different career."
    ame "They didn't care what, just not law enforcement."
    ame "Obviously, I didn't listen.\nNothing would stop me from continuing the family legacy."
    ame "I never really understood why they'd even object."
    scene 22_0052 with dissolve
    ame "... Not until the day I was called out of class in college."
    ame "It was my birthday."
    scene 22_0053 with dissolve
    ame "And the day they found my father's severed head in the trunk of an abandoned vehicle."
    scene 22_0054 with dissolve
    mc "Jesus. That's awful! I'm sorry."
    ame "The report said the weapon used was a sharp, bladed instrument. Possibly a sword."
    scene 22_0055 with dissolve
    mc "... Or an axe?"
    ame "He was undercover at the time; working as one of Anton's foot-soldiers."
    scene 22_0056 with dissolve
    ame "He had no idea that his FBI handler {i}also{/i} worked for Anton."
    mc "Damn."
    scene 22_0057 with dissolve
    ame "They never found the rest of his body.\nAll we had to bury was his head."
    scene 22_0058 with dissolve
    ame "I know what you're thinking, but you're wrong."
    scene 22_0059 with dissolve
    ame "I'm not after revenge.\nIt's about finishing what my father started."
    ame "He was well aware of the risk when he accepted the assignment."
    scene 22_0060 with dissolve
    ame "He'd seen first-hand the pain and misery Anton and the rest of them were causing."
    ame "He wasn't the type of man to turn his back and ignore it. Not when he had the power to do something."
    scene 22_0061 with dissolve
    mc "Sounds like he was quite the guy."
    mc "And if this {i}isn't{/i} about revenge for you, then it sounds like he raised a helluva daughter, too."
    scene 22_0062 with dissolve
    ame "My mom would have something to say about that.\nShe'd claim {i}that{/i} credit."
    scene 22_0063 with dissolve
    ame "My father was never around. Always away, working.\nThey divorced when I was seven years old."
    mc "Ah, sorry. I have a bad habit of putting my foot in my mouth."
    scene 22_0064 with dissolve
    ame "No, it's fine."
    ame "They remained friends - for my sake mostly, but they made it work."
    scene 22_0065 with dissolve
    mc "So is your mom, uhh... still around?"
    mc "Can't imagine she'd be too happy knowing you've picked up your father's mantle?"
    scene 22_0066 with dissolve
    ame "Yeah, we had some {i}loud{/i} conversations about it, and it took some convincing!"
    ame "But I eventually won her approval."
    scene 22_0067 with dissolve
    ame "And her approval was needed since it's {i}her{/i} operation."
    ame "She's my boss."
    scene 22_0068 with dissolve
    mc "{b}Your own mother{/b} sent you undercover to Hank's bar?? Jesus!"
    ame "This is personal to us both - not for revenge - but for closure."
    ame "My father sacrificed his life trying to put these assholes away and we intend for that to mean something."
    scene 22_0069 with dissolve
    mc "I appreciate the honesty."
    mc "Not gonna lie... it's a little fucked up, but at the same time it's reasurring knowing it's your mother who's in charge."
    mc "'Cause I know if it was {b}my{/b} daughter, I'd damn well make sure I could rely on every single person on my team."
    scene 22_0070 with dissolve
    mc "Okay... Send me your safehouse location.\nI'll move Melissa there and that'll give you the chance to talk to her yourself."
    mc "Let's take these bastards down, together."
    ame "It's going to take more than Melissa."
    scene 22_0071 with dissolve
    ame "We need hard evidence. Reliable witnesses.\nWe have to build the strongest case possible."
    ame "The more you can find, the better our chance of success."
    scene 22_0072 with dissolve
    ame "And remember, I'm here for you - anytime.\nIf you think I can help in any way, call me."
    ame "I won't let you down, and I'll always have your back."
    scene 22_0073 with dissolve
    mc "Right back at ya."
    mc "Except maybe for any drunk idiots at the bar... They're all yours."
    scene 22_0074 with dissolve
    ame "[lol]"
    ame "Sorry I gave you a hard time for that. I truly did appreciate the gesture."
    scene 22_0075 with dissolve
    ame "It was nice to have someone stand up for me, I just couldn't show it."
    ame "I think you're the first guy to walk into the bar who {i}hasn't{/i} tried to get into my pants."
    scene 22_0076 with dissolve
    $ tCh= Amelia.Has("EZ")
    if not EzModeActive:
        menu:
            "[wk_y]I haven't tried... Yet!":
                $ tCh=True
            "And I never will [wk_c]":
                $ tCh=False
    if tCh:
        mc "I'm just biding my time.\nLetting you get to know me better before I make my move."
        scene 22_0077 with dissolve
        ame "Oh, wow! You have {i}moves{/i}?"
        ame "Okay, I look forward to watching you embarrass yourself, {i}old timer{/i}."
        scene 22_0078 with dissolve
        mc "You have a whole lot more than {i}that{/i} to look forward to, Sweetheart."
        ame "Oh my god. Have you started?\nI feel like you've started, 'cause that was embarrasing!"
        call laugh (mc, "I'm just warming up.")
        ame "Thank heavens! [lol]"
    else:
        call CloseCharacterPath (Amelia, "Amelia")
        mc "I just wanna get the job done, go home and live a peaceful life."
        ame "Can't argue with that."
    scene 22_0079 with dissolve
    mc "I'd better head back.\nThanks for the coffee."
    ame "I'm glad you came, [mc].\nI feel we've made great progress today."
    mc "Yeah, me too."
    scene 22_0080 with dissolve
    ame "I'll forward you the safehouse location later."
    mc "Great."
    scene 22_0081 with dissolve
    ame "Keep in touch.\nAnd remember, if you {i}have{/i} to break the law to maintain your cover - we'll need to make a record of it."
    mc "Understood."
    scene 22_0082 with dissolve
    mc "Ohh... wait..."
    scene 22_0083 with dissolve
    mc "There might be {i}something{/i} you can help with."
    mc "I need a dog."
    scene 22_0084 with dissolve
    ame "A dog??"
    mc "Yeah.\nBlaze came up with the idea of swapping Bruno for a look-a-like."
    scene 22_0085 with dissolve
    ame "Hmm, okay... Interesting..."
    scene 22_0086 with dissolve
    ame "Can you get a photo?"
    mc "I already have a couple. I'll send you them."
    ame "Okay, I'll see what we can do."
    mc "Thanks."
    scene 22_0087 with dissolve
    ame "I have a question."
    ame "What gave me away?\nI was sure I'd convinced you that I was a private investigator!"
    mc "You did... right up until the end."
    scene 22_0088 with dissolve
    mc "When I gave you the location of the doctor, that information didn't seem important to you."
    mc "If rescuing him really was your only objective, I'd have expected to see more urgency."
    mc "That put a doubt in my mind. I couldn't shake it."
    scene 22_0089 with dissolve
    ame "Shit. Good to know."
    ame "It's the little things that get you, huh?"
    mc "Always."
    ame "I'm glad you're on our side."
    scene 22_0090 with dissolve
    ame "Be safe out there, [mc]."
    mc "Yeah. You too."
    scene 22_0091 with dissolve
    mc "See you soon, Amelia."
    ame "Bye."
    scene 22_0092 with dis1
    scene 22_0093 with dis1
    scene 22_0094 with dis1
    scene black with Fade(3, 3, 0)
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
