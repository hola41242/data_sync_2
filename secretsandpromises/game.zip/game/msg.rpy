label Msg_Chloe01(ClsCell=True):
    show screen CellPhone("Chloe")
    msg_nvl "Hi [mc]!"
    msg_nvl "Sorry for randomly messaging but I've been dying to know..."
    msg_nvl "Did you use them? {image=/thumbs/cell/emoji/smile shy.png}"
    mc_nvl "Hi Chloe."
    mc_nvl "Use what??"
    msg_nvl "OMG!"
    msg_nvl "My photos!"
    mc_nvl "{image=/thumbs/cell/emoji/tongue.png} Of course I did!"
    mc_nvl "Multiple times! {image=/thumbs/cell/emoji/wink.png}"
    msg_nvl "{image=/thumbs/cell/emoji/smile shy.png}"
    if ClsCell:
        msg_nvl "Ok. Bye x"
        call CloseCell ()
return

label Msg_Chloe02(cont=False):
    if not cont:
        show screen CellPhone("Chloe")
        msg_nvl "Ok, since you've used them multiple times already..."
        msg_nvl "I took a new one for you. {image=/thumbs/cell/emoji/smile shy.png}"
    else:
        msg_nvl "multiple times?? {image=/thumbs/cell/emoji/smile shy.png}"
        msg_nvl "Maybe you'd like this new one I took for you then!"
    call SendPhoto ("chlo_07")
    mc_nvl "Wow!"
    mc_nvl "That one's gonna be used mutliple mutliple times!"
    msg_nvl "{image=/thumbs/cell/emoji/crylaugh.png}"
    mc_nvl "Damn, your pussy looks delicious!{image=/thumbs/cell/emoji/drool.png}"
    msg_nvl "[mc!u]!! OMG! {image=/thumbs/cell/emoji/flushed.png}"
    mc_nvl "Haha, sorry! I was just sayin!"
    msg_nvl "{image=/thumbs/cell/emoji/crylaugh.png}"
    msg_nvl "Bye x {image=/thumbs/cell/emoji/smile shy.png}"
    call CloseCell ()
return

label Msg_Chloe03(rep=True):
    show screen CellPhone("Chloe")
    msg_nvl "Hi [mc]!"
    msg_nvl "Thanks again for the day out, still buzzing!"
    msg_nvl "Here's your reward, as promised!"
    call SendPhoto ("chlo_08")
    msg_nvl "Hope you like it! {image=/thumbs/cell/emoji/smile shy.png}"
    if rep:
        mc_nvl "Wow! How could I NOT like it??"
        mc_nvl "So damn beautiful!"
        msg_nvl "{image=/thumbs/cell/emoji/smile hearts.png}"
        msg_nvl "Looking forward to your next visit!"
        msg_nvl "Bye x"
    call CloseCell ()
return

label Msg_Nicole01:
    show screen CellPhone("Nicole")
    msg_nvl "You won't show it to anyone else will you?"
    mc_nvl "no, of course not."
    msg_nvl "K"
    call SendPhoto ("nic_01")
    mc_nvl "Like I said - STUNNING!"
    msg_nvl "{image=/thumbs/cell/emoji/blush smile.png}"
    msg_nvl "I took another one..."
    call SendPhoto ("nic_02")
    mc_nvl "Wow, so beautiful! I'm speechless."
    msg_nvl "{image=/thumbs/cell/emoji/monkey hiding.png}"
    msg_nvl "Bye xx"
    call CloseCell ()
return

label Msg_Hannah01:
    show screen CellPhone("Hannah")
    msg_nvl "Yo! How's my favorite pervy uncle doin? {image=/thumbs/cell/emoji/kiss.png}"
    mc_nvl "Hey Han, I'm good. You?"
    msg_nvl "Yeah. Just sitting here, thinking about your last visit."
    call SendPhoto ("han_06")
    mc_nvl "Beautiful."
    mc_nvl "Why you thinking about my last visit?"
    msg_nvl "Ok, not so much thinking about your last visit..."
    msg_nvl "more like looking forward to the next one.{image=/thumbs/cell/emoji/wink.png}"
    call SendPhoto ("han_07")
    mc_nvl "Damn! Me too.{image=/thumbs/cell/emoji/tongue out.png}"
    msg_nvl "Love you, your favorite pervy niece xx {image=/thumbs/cell/emoji/kiss.png}{image=/thumbs/cell/emoji/kiss.png}"
    call CloseCell ()
return

label Msg_Nicole02(full=True):
    show screen CellPhone("Nicole")
    if full:
        msg_nvl "I'm really sorry about earlier. I hope you're not angry with me."
        mc_nvl "No, of course not!"
        mc_nvl "I get it, you were embarrassed.\nYou didn't do anything wrong.\nDon't worry, we're good!"
        msg_nvl "Yeah, I was embarrassed!{image=/thumbs/cell/emoji/flushed.png}"
        msg_nvl "It's the first time I -you know- in front of anyone!"
        mc_nvl "Orgasmed?"
        msg_nvl "{image=/thumbs/cell/emoji/monkey hiding.png} Yeah."
        msg_nvl "I panicked... I wasn't sure if you expected me to do something to you in return."
        mc_nvl "No, Nic!"
        mc_nvl "I'd never try to make you do something you didn't want!\nI promise."
        msg_nvl "Okay. I'm sorry."
        msg_nvl "I hope we're still friends."
        mc_nvl "Of course!\nIt'll take more than that to get rid of me!"
        msg_nvl "I don't want to get rid of you!{image=/thumbs/cell/emoji/heart.png}"
    msg_nvl "Thanks for talking to my mom."
    msg_nvl "She actually apologized and admitted that she was in the wrong!"
    msg_nvl "Don't know what you said to her, but thank you!"
    mc_nvl "No problem.\nGlad I was able to help."
    msg_nvl "Bye [mc] X"
    call CloseCell ()
return

label Msg_Alysha01:
    show screen CellPhone("Alysha")
    mc_nvl "Hey, tried calling again, guess you're still busy at work."
    mc_nvl "Any news on the prints yet?"
    mc_nvl "Call me when you get the chance."
    call CloseCell ()
return

label Msg_Chloe04:
    show screen CellPhone("Chloe")
    msg_nvl "Hi [mc]!"
    msg_nvl "Still practicing those moves you taught me!"
    msg_nvl "I was working so hard, look at the state of me!{image=/thumbs/cell/emoji/smile shy.png}"
    call SendPhoto ("chlo_15")
    mc_nvl "Holy shit! Wow!"
    mc_nvl "Did you mean to send me THAT one??"
    msg_nvl "{image=/thumbs/cell/emoji/monkey hiding.png} Oops!"
    mc_nvl "Okay, I'll delete it."
    msg_nvl "It's ok, you can keep it."
    msg_nvl "{image=/thumbs/cell/emoji/tongue out.png} I kinda like what you said you do with my photos."
    msg_nvl "I won't send any more if you don't want me to."
    menu(nvl=True):
        "Hell no! Keep 'em coming!":
            mc_nvl "Hell no! Keep 'em coming!"
            msg_nvl "{image=/thumbs/cell/emoji/smile shy.png}OK."
            $ Pix_Chloe = True
        "Yeah, better not.":
            mc_nvl "Yeah, better not."
            msg_nvl "Ok."
            $ Pix_Chloe = False
    msg_nvl "Gotta go. Bye x"
    call CloseCell ()
return

label Msg_Chloe05:
    show screen CellPhone("Chloe")
    msg_nvl "Hi [mc]!"
    msg_nvl "Still practicing those moves you taught me!"
    msg_nvl "Thought you deserved a little reward for all your help!{image=/thumbs/cell/emoji/smile shy.png}"
    call SendPhoto ("chlo_15")
    msg_nvl "{image=/thumbs/cell/emoji/kiss.png}"
    mc_nvl "Wow! Thanks."
    mc_nvl "Although, I'm starting to think you LIKE sending me these."
    msg_nvl "{image=/thumbs/cell/emoji/tongue out.png} Maybe I do."
    msg_nvl "Bye x"
    call CloseCell ()
return

label Msg_Alysha02:
    show screen CellPhone("Alysha")
    mc_nvl "You're still not picking up!"
    mc_nvl "You working the graveyard shift?\nYeah, you're probably asleep now."
    mc_nvl "Talk later. Call me when you have a minute."
    call CloseCell ()
return

label Msg_Sarah01:
    show screen CellPhone("Sarah")
    mc_nvl "Hi.\nI'm going to Lakeshore tomorrow, you want to come along?"
    msg_nvl "Hi, [mc]."
    msg_nvl "As much as I'd like to join you, it's impossible for me right now."
    msg_nvl "If I even request any additional time off, I'm sure I'd be dismissed on the spot!"
    if Plr.Has("MaryPath") and Sarah.isSexual():
        msg_nvl "Maybe you can come over when you're back?\nI'd like to hear how Dawn's getting on."
        mc_nvl "Yeah, I can do that."
        msg_nvl "Okay, it's a date! See you then."
    else:
        msg_nvl "Maybe next time?"
        mc_nvl "Yeah, I thought it was too short notice, but figured I'd ask to be certain."
        msg_nvl "And it's appreciated. Thank you."
        if Sarah.isSexual():
            msg_nvl "Sorry I haven't been in touch. I've been so busy with work!"
            mc_nvl "Yeah, same here."
        msg_nvl "Sorry, I have to go - my break's about to end."
        msg_nvl "See you soon."
    call CloseCell ()
return

label Msg_Alysha03(p=True):
    show screen CellPhone("Alysha")
    if p:
        mc_nvl "Why didn't you call? Is everything ok??"
        mc_nvl "I'm getting worried about you."
        mc_nvl "Are you there??"
        mc_nvl "Call me!"
        mc_nvl "I have to leave town early.\nIf I ain't heard from you before I leave I'm coming looking."
        call CloseCell (False)
    else:
        msg_nvl "I'm busy. Don't worry."
        mc_nvl "Where are you?"
        msg_nvl "Got to go. Call soon."
        mc_nvl "Go?? Go where??"
        mc_nvl "Alysha?!"
        call CloseCell ()
return

label Msg_Alysha04:
    show screen CellPhone("Alysha")
    mc_nvl "If you're seeing my messages you need to answer!"
    mc_nvl "I'm gonna kick down the door to your apartment if I don't hear from you."
    mc_nvl "Please Alysha, just let me know you're ok."
    call CloseCell ()
return

label Msg_Sarah02:
    show screen CellPhone("Sarah")
    mc_nvl "Hey.\nBack from Lakeshore. Dawn's doing fine."
    msg_nvl "Hi!"
    msg_nvl "Relieved she's ok!"
    msg_nvl "But didn't you promise to come over when you got back?"
    msg_nvl "I have an open bottle of wine and an empty bed if you'd like to come now {image=/thumbs/cell/emoji/wink.png}"
    mc_nvl "Is the bottle empty too? {image=/thumbs/cell/emoji/crylaugh.png}"
    msg_nvl "LOL. Is that your polite way of asking if I'm drunk?"
    msg_nvl "I'm not."
    msg_nvl "Just a little buzzed... and a little {image=/thumbs/cell/emoji/devil.png}"
    mc_nvl "Ummm.... Devily??"
    msg_nvl "OMG {image=/thumbs/cell/emoji/crylaugh.png}"
    msg_nvl "HORNY!"
    mc_nvl "On my way! {image=/thumbs/cell/emoji/wink.png}"
    msg_nvl "{image=/thumbs/cell/emoji/crylaugh.png}{image=/thumbs/cell/emoji/crylaugh.png}{image=/thumbs/cell/emoji/kiss.png}"
    call CloseCell ()
return

label Msg_Mary01:
    show screen CellPhone("Mary")
    msg_nvl "I'm so scared!! {image=/thumbs/cell/emoji/pleading.png}"
    mc_nvl "Why? What's wrong??"
    msg_nvl "Can't you hear it??"
    mc_nvl "Ohh... the thunderstorm. Right. You don't like them."
    mc_nvl "Don't worry, it'll soon pass!"
    msg_nvl "I'm under my blanket, shaking."
    msg_nvl "I'm all alone again, but now there's thunder.\nI don't like it."
    msg_nvl "Can you come visit?"
    mc_nvl "Where's Bill?"
    msg_nvl "He was on his way home, but the truck broke down!"
    msg_nvl "Won't be fixed until morning.\nDon't think I can survive that long! {image=/thumbs/cell/emoji/sweat.png}"
    msg_nvl "Pleeeeeeeassssseee [mc]! {image=/thumbs/cell/emoji/pray.png}"
    mc_nvl "Okay, guess I can keep you company a while."
    mc_nvl "I'll be there as soon as I can."
    msg_nvl "OMG REALLY?! {image=/thumbs/cell/emoji/shock.png}"
    msg_nvl "{image=/thumbs/cell/emoji/heart sparkling.png}{image=/thumbs/cell/emoji/heart sparkling.png}{image=/thumbs/cell/emoji/heart sparkling.png}"
    call CloseCell ()
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
