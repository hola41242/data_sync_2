init offset = -1

style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")

style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5

style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")

style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"

style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)





screen say(who, what):
    style_prefix "say"

    window:
        id "window"
        background None
        if who is not None:

            window:
                id "namebox"
                style "namebox"
                if who==persistent.McName and persistent.EditableName:
                    button:
                        text who id "who"
                        action Call("UpdateName", True)
                else:
                    text who id "who"

        text what id "what"



    if not renpy.variant("small"):
        if persistent.UseSideImage:
            add SideImage() xalign 0.05 yalign 1.0


init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", gui.namebox_borders, tile=gui.namebox_tile, xalign=gui.name_xalign)
    padding gui.namebox_borders.padding

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos

    adjust_spacing False


screen input(prompt):
    style_prefix "input"

    window:

        has vbox
        xanchor gui.dialogue_text_xalign
        xpos gui.dialogue_xpos
        xsize gui.dialogue_width
        ypos gui.dialogue_ypos

        text prompt style "input_prompt"
        input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width



screen choice(items):
    style_prefix "choice"

    vbox:
        for i in items:
            if "friend" in i.kwargs:
                textbutton "{} ({}{})".format( i.caption, "{"+"color={}".format( i.kwargs["color"] ) + "}" if "color" in i.kwargs else "{color=#FFF}", i.kwargs["friend"] + "{/color}") action i.action
            else:
                textbutton i.caption action i.action



style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 405
    yanchor 0.5

    spacing gui.choice_spacing

style choice_button is default:
    properties gui.button_properties("choice_button")

style choice_button_text is default:
    properties gui.text_properties("choice_button")



screen quick_menu():


    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("History") action ShowMenu('history')
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Save") action ShowMenu('save')
            textbutton _("Q.Save") action QuickSave()
            textbutton _("Q.Load") action QuickLoad()
            textbutton _("Prefs") action ShowMenu('preferences')
            if GalleryUnlocked:
                textbutton _("Gallery") action ToggleScreen('phonegallery')
            if not _in_replay:
                textbutton _("Editor") action ToggleScreen('Editor'), Hide("GameConfig"), Hide("ShowPlrInfo")



init python:
    config.overlay_screens.append("quick_menu")

default quick_menu = True

style quick_button is default
style quick_button_text is button_text

style quick_button:
    properties gui.button_properties("quick_button")

style quick_button_text:
    properties gui.text_properties("quick_button")






screen navigation():

    vbox:
        style_prefix "navigation"

        xpos gui.navigation_xpos
        yalign 0.5

        spacing gui.navigation_spacing

        if main_menu:

            textbutton _("Start") action Start()

        else:

            textbutton _("History") action ShowMenu("history")

            textbutton _("Save") action ShowMenu("save")

        textbutton _("Load") action ShowMenu("load")
        if not _in_replay:
            textbutton _("Replay Scenes") action ShowMenu("replaychars")

        textbutton _("Preferences") action ShowMenu("preferences")

        if _in_replay:

            textbutton _("End Replay") action EndReplay(confirm=True)

        elif not main_menu:

            textbutton _("Main Menu") action MainMenu()

        textbutton _("Changelog") action ShowMenu("changelog")
        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):


            textbutton _("Help") action ShowMenu("help")

        if renpy.variant("pc"):



            textbutton _("Quit") action Quit(confirm=not main_menu)


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    size_group "navigation"
    properties gui.button_properties("navigation_button")

style navigation_button_text:
    properties gui.text_properties("navigation_button")



default persistent.MenuOptSel = -1
default persistent.MenuSSactive = True
define MenuSSimg = ["mnu/mn_car.webp", "mnu/mn_ali.webp", "mnu/mn_luc.webp", "mnu/mn_gab.webp", "mnu/mn_net.webp", "mnu/mn_sar.webp", "mnu/mn_blz.webp", 
"mnu/mn_alx.webp", "mnu/mn_jem.webp", "mnu/mn_aly.webp", "mnu/mn_han.webp", "mnu/mn_dwn.webp", "mnu/mn_nic.webp", "mnu/mn_vi.webp", "mnu/mn_mar.webp",
"mnu/mn_sue.webp", "mnu/mn_liz.webp", "mnu/mn_kiy.webp", "mnu/mn_mil.webp", "mnu/mn_mel.webp", "mnu/mn_clo.webp", "mnu/mn_cri.webp", "mnu/mn_rth.webp",
"mnu/mn_miy.webp", "mnu/mn_mls.webp", "mnu/mn_ame.webp", "mnu/mn_pri.webp", "mnu/mn_mit.webp", "mnu/mn_hay.webp"]
init python:
    def SetMenuOpt(i):
        renpy.store.persistent.MenuOptSel=i


image mainmenuImages:
    "mnu/mn_b.webp" with Dissolve(3)
    pause 1.0
    "[MenuSSimg[0]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[1]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[2]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[3]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[4]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[5]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[6]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[7]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[8]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[9]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[10]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[11]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[12]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[13]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[14]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[15]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[16]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[17]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[18]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[19]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[20]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[21]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[22]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[23]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[24]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[25]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[26]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[27]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    "[MenuSSimg[28]]" with Dissolve(3)
    pause 6.0
    "mnu/mn_b.webp" with Dissolve(3)
    pause 5.0
    repeat

screen mnu_addSel(p, i):
    imagebutton:
        if persistent.MenuOptSel==i:
            idle "gallery/"+p+"_h.jpg"
        else:
            idle "gallery/"+p+"_i.jpg"
        action Function(SetMenuOpt, i)

screen MnuCnf():
    modal True
    frame:
        align (0.5, 0.5)
        xysize (700, 850)
        background Frame("gui/pref_box.png", 10,10,10,10)
        frame:
            background None
            xalign 0.5
            text "{size=*.6}{b}{u}CUSTOMIZE MENU SCREEN"
        frame:
            background None
            xalign 0.5
            ypos -15
            xsize 200
            ysize 100
            textbutton "On":
                text_size 22
                xalign 0.1
                ypos 40
                action ToggleField(persistent, "MenuSSactive")
            imagebutton:
                ypos 47
                xalign 0.5
                if not persistent.MenuSSactive:
                    idle "gui/pref_off.png"
                    action ToggleField(persistent, "MenuSSactive")
                else:
                    idle "gui/pref_on.png"
                    action ToggleField(persistent, "MenuSSactive")
            textbutton "Off":
                text_size 22
                xalign 0.95
                ypos 40
                action ToggleField(persistent, "MenuSSactive")
        if persistent.MenuSSactive:
            frame:
                background None
                xalign 0.5
                ypos 70
                has grid 6 10
                spacing 10
                imagebutton:
                    if persistent.MenuOptSel==-1:
                        idle "mnu/ss_h.jpg"
                    else:
                        idle "mnu/ss_i.jpg"
                    action Function(SetMenuOpt, -1)
                use mnu_addSel("sph/cara", 0)
                use mnu_addSel("sph/alison", 1)
                use mnu_addSel("okh/lucy", 2)
                use mnu_addSel("sph/gabrielle", 3)
                use mnu_addSel("cdg/nettie", 4)
                use mnu_addSel("sph/sarah", 5)
                use mnu_addSel("lks/blaze", 6)
                use mnu_addSel("sph/alex", 7)
                use mnu_addSel("brv/jemma", 8)
                use mnu_addSel("sph/alysha", 9)
                use mnu_addSel("okh/hannah", 10)
                use mnu_addSel("lks/dawn", 11)
                use mnu_addSel("sph/nicole", 12)
                use mnu_addSel("okh/violet", 13)
                use mnu_addSel("sph/mary", 14)
                use mnu_addSel("sph/sue", 15)
                use mnu_addSel("cdg/elizabeth", 16)
                use mnu_addSel("sph/kiyomi", 17)
                use mnu_addSel("okh/millie", 18)
                use mnu_addSel("sph/melanie", 19)
                use mnu_addSel("cdg/chloe", 20)
                use mnu_addSel("sph/christina", 21)
                use mnu_addSel("lks/ruth", 22)
                use mnu_addSel("ntc/miyuka", 23)
                use mnu_addSel("lks/melissa", 24)
                use mnu_addSel("brh/amelia", 25)
                use mnu_addSel("mlf/priya", 26)
                use mnu_addSel("ntc/mitsui", 27)
                use mnu_addSel("cdg/hayley", 28)

        frame:
            xalign 0.5
            yalign 0.99
            style "minibg"
            has vbox
            textbutton "{size=*.6}CLOSE":
                text_color "#FFFFFF"
                action Hide("MnuCnf")

screen main_menu():
    tag menu


    add gui.main_menu_background

    frame:
        style "main_menu_frame"
        if persistent.MenuSSactive:
            if persistent.MenuOptSel==-1:
                add "mainmenuImages"
            else:
                add "[MenuSSimg[persistent.MenuOptSel]]"
    add "mnu/spl.webp" align (1.0, 1.0)
    frame:
        background None
        align (1.0, 1.0)
        imagebutton:
            idle "thumbs/cell/s_icon_i.png"
            hover "thumbs/cell/s_icon_h.png"
            action ToggleScreen("MnuCnf")


    use navigation

    if gui.show_name:

        vbox:
            style "main_menu_vbox"

            text "[config.name!t]":
                style "main_menu_title"

            text "[config.version]":
                style "main_menu_version"

style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_frame:
    xsize 420
    yfill True

style main_menu_vbox:
    xalign 0.96
    xmaximum 1200
    yalign 0.85

style main_menu_text:
    properties gui.text_properties("main_menu", accent=True)

style main_menu_title:
    properties gui.text_properties("title")

style main_menu_version:
    properties gui.text_properties("version")



screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"
    add gui.game_menu_background

    frame:
        style "game_menu_outer_frame"

        has hbox


        frame:
            style "game_menu_navigation_frame"

        frame:
            style "game_menu_content_frame"

            if scroll == "viewport":

                viewport:
                    yinitial yinitial
                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    has vbox
                    spacing spacing

                    transclude

            elif scroll == "vpgrid":

                vpgrid:
                    cols 1
                    yinitial yinitial

                    scrollbars "vertical"
                    mousewheel True
                    draggable True
                    pagekeys True

                    side_yfill True

                    spacing spacing

                    transclude

            else:

                transclude

    use navigation

    textbutton _("Return"):
        style "return_button"

        action Return()

    label title

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_outer_frame:
    bottom_padding 45
    top_padding 180

style game_menu_navigation_frame:
    xsize 420
    yfill True

style game_menu_content_frame:
    left_margin 60
    right_margin 30
    top_margin 15

style game_menu_viewport:
    xsize 1380

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label:
    xpos 75
    ysize 180

style game_menu_label_text:
    size gui.title_text_size
    color gui.accent_color
    yalign 0.5

style return_button:
    xpos gui.navigation_xpos
    yalign 1.0
    yoffset -45



screen about():
    tag menu





    use game_menu(_("About"), scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("Version [config.version!t]\n")


            if gui.about:
                text "[gui.about!t]\n"

            text _("Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]")


style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size



screen save():
    tag menu


    use file_slots(_("Save"))


screen load():
    tag menu


    use file_slots(_("Load"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("Page {}"), auto=_("Automatic saves"), quick=_("Quick saves"))

    use game_menu(title):

        fixed:



            order_reverse True


            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value


            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.5

                spacing gui.slot_spacing

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1

                    button:
                        if persistent.UseSaveNames:
                            action If(renpy.get_screen("save"), true=Show("savegameName", accept=FileSave(slot)), false=FileLoad(slot))
                        else:
                            action FileAction(slot)

                        vbox:

                            add FileScreenshot(slot) xalign 0.5

                            text FileTime(slot, format=_("{#file_time}%A, %B %d %Y, %H:%M"), empty=_("empty slot")):
                                style "slot_time_text"

                            if FileLoadable(slot):
                                imagebutton:
                                    auto "images/thumbs/del_%s.png"
                                    action FileDelete(slot)
                                    xalign 1.0
                                    xoffset 15
                                    yoffset -250

                            if FileSaveName(slot):
                                $ fn = FileSaveName(slot)
                                if fn and ("-" in fn):
                                    $ y = fn.split("-")
                                text fn:
                                    style "slot_name_text"
                                    yoffset -300

                            key "save_delete" action FileDelete(slot)




            vbox:
                style_prefix "page"

                xalign 0.5
                yalign 1.0

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}A") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}Q") action FilePage("quick")


                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                if config.has_sync:
                    if CurrentScreenName() == "save":
                        textbutton _("Upload Sync"):
                            action UploadSync()
                            xalign 0.5
                    else:
                        textbutton _("Download Sync"):
                            action DownloadSync()
                            xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text

style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 75
    ypadding 5

style page_label_text:
    textalign 0.5
    layout "subtitle"
    hover_color gui.hover_color

style page_button:
    properties gui.button_properties("page_button")

style page_button_text:
    properties gui.text_properties("page_button")

style slot_button:
    properties gui.button_properties("slot_button")

style slot_button_text:
    properties gui.text_properties("slot_button")



screen savegameName(accept=NullAction()):
    modal True
    add Solid("#000000") alpha 0.8
    style_prefix "savegameName"

    frame:
        has vbox
        xalign 0.5
        spacing 20

        label _("Save Name"):
            text_color gui.text_color
            xalign 0.5

        null height 10

        input size 40 color gui.hover_color default store.save_name changed Namer length 22 allow allowedChars:
            yalign 1.0
            xalign 0.5
            xysize (550, 40)

        textbutton _("{u}Save Game{/u}"):
            xalign 0.5
            keysym ['K_RETURN', 'K_KP_ENTER']
            action [accept, (Hide("savegameName"))]

init python:
    import string
    def Namer(name):
        store.save_name = name


define allowedChars = string.ascii_letters + string.digits + " -"
style savegameName_frame:
    padding gui.confirm_frame_borders.padding
    xsize 650
    xalign 0.5
    yalign 0.5

style savegameName_frame:
    variant "touch"
    padding gui.confirm_frame_borders.padding
    xsize 650
    xalign 0.5
    yalign 0
    ypos 50


screen preferences():
    tag menu

    use prefs_menu()

style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    yalign 1.0

style pref_vbox:
    xsize 338

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")

style slider_slider:
    xsize 525

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 675

screen history():
    tag menu



    predict False

    use game_menu(_("History"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:


                has fixed
                yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False



                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("The dialogue history is empty.")




define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5



screen help():
    tag menu


    default device = "keyboard"

    use game_menu(_("Help"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 23

            hbox:

                textbutton _("Keyboard") action SetScreenVariable("device", "keyboard")
                textbutton _("Mouse") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("Gamepad") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("Enter")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Space")
        text _("Advances dialogue without selecting choices.")

    hbox:
        label _("Arrow Keys")
        text _("Navigate the interface.")

    hbox:
        label _("Escape")
        text _("Accesses the game menu.")

    hbox:
        label _("Ctrl")
        text _("Skips dialogue while held down.")

    hbox:
        label _("Tab")
        text _("Toggles dialogue skipping.")

    hbox:
        label _("Page Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Page Down")
        text _("Rolls forward to later dialogue.")

    hbox:
        label "H"
        text _("Hides the user interface.")

    hbox:
        label "S"
        text _("Takes a screenshot.")

    hbox:
        label "V"
        text _("Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}.")

    hbox:
        label "Shift+A"
        text _("Opens the accessibility menu.")


screen mouse_help():

    hbox:
        label _("Left Click")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Middle Click")
        text _("Hides the user interface.")

    hbox:
        label _("Right Click")
        text _("Accesses the game menu.")

    hbox:
        label _("Mouse Wheel Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Mouse Wheel Down")
        text _("Rolls forward to later dialogue.")


screen gamepad_help():

    hbox:
        label _("Right Trigger\nA/Bottom Button")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Left Trigger\nLeft Shoulder")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Right Shoulder")
        text _("Rolls forward to later dialogue.")

    hbox:
        label _("D-Pad, Sticks")
        text _("Navigate the interface.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("Accesses the game menu.")

    hbox:
        label _("Y/Top Button")
        text _("Hides the user interface.")

    textbutton _("Calibrate") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0







screen confirm(message, yes_action, no_action):


    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        has vbox
        xalign .5
        yalign .5
        spacing 45

        label _(message):
            style "confirm_prompt"
            xalign 0.5

        hbox:
            xalign 0.5
            spacing 150

            textbutton _("Yes") action yes_action
            textbutton _("No") action no_action


    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background Frame([ "gui/confirm_frame.png", "gui/frame.png"], gui.confirm_frame_borders, tile=gui.frame_tile)
    padding gui.confirm_frame_borders.padding
    xalign .5
    yalign .5

style confirm_prompt_text:
    textalign 0.5
    layout "subtitle"

style confirm_button:
    properties gui.button_properties("confirm_button")

style confirm_button_text:
    properties gui.text_properties("confirm_button")



screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        has hbox
        spacing 9

        text _("Skipping")

        text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
        text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"



transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    ypos gui.skip_ypos
    background Frame("gui/skip.png", gui.skip_frame_borders, tile=gui.frame_tile)
    padding gui.skip_frame_borders.padding

style skip_text:
    size gui.notify_text_size

style skip_triangle:


    font "DejaVuSans.ttf"



screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    ypos gui.notify_ypos

    background Frame("gui/notify.png", gui.notify_frame_borders, tile=gui.frame_tile)
    padding gui.notify_frame_borders.padding

style notify_text:
    properties gui.text_properties("notify")



screen nvl(dialogue, items=None):

    if nvl_mode == "phone":
        use PhoneDialogue(dialogue, items)
    else:


        window:
            style "nvl_window"

            has vbox
            spacing gui.nvl_spacing


            if gui.nvl_height:

                vpgrid:
                    cols 1
                    yinitial 1.0

                    use nvl_dialogue(dialogue)

            else:

                use nvl_dialogue(dialogue)



            for i in items:

                textbutton i.caption:
                    action i.action
                    style "nvl_button"

        add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            has fixed
            yfit gui.nvl_height is None

            if d.who is not None:

                text d.who:
                    id d.who_id

            text d.what:
                id d.what_id




define config.nvl_list_length = 12

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    text_align gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    text_align gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    text_align gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.button_text_properties("nvl_button")

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}







style pref_vbox:
    variant "medium"
    xsize 675



screen quick_menu():
    variant "touch"

    zorder 100

    if quick_menu:

        hbox:
            style_prefix "quick"

            xalign 0.5
            yalign 1.0

            textbutton _("Back") action Rollback()
            textbutton _("Skip") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("Auto") action Preference("auto-forward", "toggle")
            textbutton _("Menu") action ShowMenu()


style window:
    variant "small"
    background "gui/phone/textbox.png"

style radio_button:
    variant "small"
    foreground "gui/phone/button/radio_[prefix_]foreground.png"

style check_button:
    variant "small"
    foreground "gui/phone/button/check_[prefix_]foreground.png"

style nvl_window:
    variant "small"
    background "gui/phone/nvl.png"

style main_menu_frame:
    variant "small"
    background "gui/phone/overlay/main_menu.jpg"

style game_menu_outer_frame:
    variant "small"

style game_menu_navigation_frame:
    variant "small"
    xsize 510

style game_menu_content_frame:
    variant "small"
    top_margin 0

style pref_vbox:
    variant "small"
    xsize 600

style bar:
    variant "small"
    ysize gui.bar_size
    left_bar Frame("gui/phone/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/phone/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    variant "small"
    xsize gui.bar_size
    top_bar Frame("gui/phone/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/phone/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    variant "small"
    ysize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    variant "small"
    xsize gui.scrollbar_size
    base_bar Frame("gui/phone/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/phone/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    variant "small"
    ysize gui.slider_size
    base_bar Frame("gui/phone/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/horizontal_[prefix_]thumb.png"

style vslider:
    variant "small"
    xsize gui.slider_size
    base_bar Frame("gui/phone/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/phone/slider/vertical_[prefix_]thumb.png"

style slider_vbox:
    variant "small"
    xsize None

style slider_slider:
    variant "small"
    xsize 900
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
