default infobox = None
default infobox_ch = ""
default curlocation = "My current location."
label ShowMap:
    scene black with fade
    window hide
    show screen MapView with Fade(0,0,2)
    pause
    window auto
return
default wkdata = ""
default shi = False
screen MapView():
    modal True
    $ map_path="images/thumbs/map/"
    add map_path+"Map.jpg"
    if persistent.WGuide:
        if brookvale_ch==1 and brookridge_open:
            $ wkdata=wkg004
        if wkdata!="":
            frame:
                xysize (300,300)
                yalign 0.95
                xpos 1030
                padding (10,10)
                background Frame("gui/pref_box.png", 10,10,10,10)
                text "{size=*.6}{b}Walkthrough Guide" align (0.5, 0.0)
                text "\n{size=*.5}[wkdata]"


    if curLOC==springhaven_id:
        imagebutton:
            idle map_path+"sh_c.jpg"
            pos (396, 106)
            hovered SetScreenVariable("infobox", map_path+"sh_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if springhaven_open:
            imagebutton:
                pos (396, 106)
                idle map_path+"sh_i.jpg"
                hover map_path+"sh_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"sh_ib.jpg"), SetScreenVariable("infobox_ch", springhaven_info[springhaven_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", springhaven_id), Jump("springhavenHub")

    if curLOC==lakeshore_id:
        imagebutton:
            idle map_path+"lks_c.jpg"
            pos (597, 265)
            hovered SetScreenVariable("infobox", map_path+"lks_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if lakeshore_open:
            imagebutton:
                pos (597, 265)
                idle map_path+"lks_i.jpg"
                hover map_path+"lks_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"lks_ib.jpg"), SetScreenVariable("infobox_ch",lakeshore_info[lakeshore_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", lakeshore_id), Jump("lakeshoreHub")

    if curLOC==northcrest_id:
        imagebutton:
            idle map_path+"nc_c.jpg"
            pos (751, 64)
            hovered SetScreenVariable("infobox", map_path+"nc_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if northcrest_open:
            imagebutton:
                pos (751, 64)
                idle map_path+"nc_i.jpg"
                hover map_path+"nc_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"nc_ib.jpg"), SetScreenVariable("infobox_ch", northcrest_info[northcrest_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", northcrest_id), Jump("northcrestHub")

    if curLOC==milfork_id:
        imagebutton:
            idle map_path+"mf_c.jpg"
            pos (859, 101)
            hovered SetScreenVariable("infobox", map_path+"mf_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if milfork_open:
            imagebutton:
                pos (859, 101)
                idle map_path+"mf_i.jpg"
                hover map_path+"mf_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"mf_ib.jpg"), SetScreenVariable("infobox_ch", milfork_info[milfork_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", milfork_id), Jump("milforkHub")

    if curLOC==eastfield_id:
        imagebutton:
            idle map_path+"ef_c.jpg"
            pos (1042, 301)
            hovered SetScreenVariable("infobox", map_path+"ef_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if eastfield_open:
            imagebutton:
                pos (1042, 301)
                idle map_path+"ef_i.jpg"
                hover map_path+"ef_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"ef_ib.jpg"), SetScreenVariable("infobox_ch", eastfield_info[eastfield_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", eastfield_id), Jump("eastfieldHub")

    if curLOC==brookridge_id:
        imagebutton:
            idle map_path+"br_c.jpg"
            pos (300, 536)
            hovered SetScreenVariable("infobox", map_path+"br_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if brookridge_open:
            imagebutton:
                pos (300, 536)
                idle map_path+"br_i.jpg"
                hover map_path+"br_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"br_ib.jpg"), SetScreenVariable("infobox_ch", brookridge_info[brookridge_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", brookridge_id), Jump("brookridgeHub")

    if curLOC==brookvale_id:
        imagebutton:
            idle map_path+"bv_c.jpg"
            pos (430, 567)
            hovered SetScreenVariable("infobox", map_path+"bv_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if brookvale_open:
            imagebutton:
                pos (430, 567)
                idle map_path+"bv_i.jpg"
                hover map_path+"bv_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"bv_ib.jpg"), SetScreenVariable("infobox_ch", brookvale_info[brookvale_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", brookvale_id), Jump("brookvaleHub")

    if curLOC==oakhill_id:
        imagebutton:
            idle map_path+"oh_c.jpg"
            pos (594, 626)
            hovered SetScreenVariable("infobox", map_path+"oh_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if oakhill_open:
            imagebutton:
                pos (594, 626)
                idle map_path+"oh_i.jpg"
                hover map_path+"oh_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"oh_ib.jpg"), SetScreenVariable("infobox_ch", oakhill_info[oakhill_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", oakhill_id), Jump("oakhillHub")

    if curLOC==chestnut_id:
        imagebutton:
            idle map_path+"cc_c.jpg"
            pos (870, 699)
            hovered SetScreenVariable("infobox", map_path+"cc_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if chestnut_open:
            imagebutton:
                pos (870, 699)
                idle map_path+"cc_i.jpg"
                hover map_path+"cc_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"cc_ib.jpg"), SetScreenVariable("infobox_ch", chestnut_info[chestnut_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", chestnut_id), Jump("chestnutHub")

    if curLOC==briarhollow_id:
        imagebutton:
            idle map_path+"bh_c.jpg"
            pos (580, 791)
            hovered SetScreenVariable("infobox", map_path+"bh_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if briarhollow_open:
            imagebutton:
                pos (580, 791)
                idle map_path+"bh_i.jpg"
                hover map_path+"bh_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"bh_ib.jpg"), SetScreenVariable("infobox_ch", briarhollow_info[briarhollow_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", briarhollow_id), Jump("briarhollowHub")

    if curLOC==cedargrove_id:
        imagebutton:
            idle map_path+"cg_c.jpg"
            pos (347, 905)
            hovered SetScreenVariable("infobox", map_path+"cg_ib.jpg"), SetScreenVariable("infobox_ch", curlocation)
            unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
            action NullAction()
    else:
        if cedargrove_open:
            imagebutton:
                pos (347, 905)
                idle map_path+"cg_i.jpg"
                hover map_path+"cg_h.jpg"
                hovered SetScreenVariable("infobox", map_path+"cg_ib.jpg"), SetScreenVariable("infobox_ch", cedargrove_info[cedargrove_ch])
                unhovered SetScreenVariable("infobox", None), SetScreenVariable("infobox_ch", "")
                action Hide("MapView"),SetVariable("curLOC", cedargrove_id) , Jump("cedargroveHub")

    if infobox!=None:
        add infobox:
            xpos 1335
            ypos 0
        frame:
            xpos 1350
            ypos 120
            xsize 560
            ysize 600
            background Solid("#ffffff00")
            text "{font=RobConLt.ttf}{size=*0.7}[infobox_ch]"
return

label springhavenHub:
    jump expression "".join(["Springhaven_Start", str(springhaven_ch)])
return
label cedargroveHub:
    jump expression "".join(["CedarGrove_Start", str(cedargrove_ch)])
return
label briarhollowHub:

return
label chestnutHub:

return
label oakhillHub:
    jump expression "".join(["OakHill_Start", str(oakhill_ch)])
return
label brookvaleHub:
    jump expression "".join(["Brookvale_Start", str(brookvale_ch)])
return
label brookridgeHub:
    jump expression "".join(["BrookRidge_Start", str(brookridge_ch)])
return
label eastfieldHub:

return
label milforkHub:
    jump expression "".join(["Milfork_Start", str(milfork_ch)])
return
label northcrestHub:

return
label lakeshoreHub:
    jump expression "".join(["Lakeshore_Start", str(lakeshore_ch)])
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
