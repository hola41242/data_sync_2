define wkg001 = """Accepting the lift will put you on her path.
Declining will put you on someone elses path, but you will meet her again later in the story."""
define wkg002 = """Aceepting Bill's offer will put you on the alternate path.
You can decline and stay off both paths. You will still meet both later in the game."""
define wkg003 = """If you decide to help Melanie, it helps seal the fate of Asshole1 and Asshole2."""
define wkg004 = """Choosing to visit Brook Ridge is optional. You don't have to ever visit the town, or you can visit later.
Should you decide to visit the town now, the order you choose between there and Brookvale alters your path.
Visiting Brook Ridge AFTER Brookvale will have consequences for both you and James."""
define wkg005 = """There isn't a right or wrong choice here, and there could be consequences later with either decision.
Choosing to kill will allow you to progress a little faster with a character you've yet to meet."""
define wkg006 = """Taking the stealth option will reveal a piece of information you otherwise won't have. Information that could be of help to someone later.
Attacking will give you a different piece of information (which is revealed later in the story). It can also speed things along with Kiyomi."""
define wkg007 = """Either decision could lead to concequences later.
Neither is right or wrong, so choose the one you're most comfortable with."""
define wkg008 = """Telling Sue about the blackmail will result in Ruth being permanently silenced.
Whilst this will have no direct consequence to you in-game, YOU will have to forever live with the knowledge that her blood is on your hands."""
define autotxt = """Auto advance is sometimes used to save the player from having to click forward on every screen.
You can now modify/disable this feature.
When enabled and in-use, the icon will show in the bottom-right corner."""
define errorsave = """Save and reload your game to continue."""
default cl11 = """Retconned the Brook Ridge scene where you meet your fathers wife. The planned DLC will be made for Boxed In instead.
You can visit the {a=https://f95zone.to/threads/secrets-and-promises-v0-10-badbod.259286/}F95Zone thread{/a} for more details. You can view the scene in isolation {a=BrookRidge_Retcon}by clicking here.{/a}

New option added: EZMode.
When this mode is enabled, you don't need to worry about making (or missing) the right choices with LI's, because the game makes them automatically. You will have one single decision to make: pursue that character or not.
{i}When EZMode is enabled, you still decide the story-driven choices{/i}.
{b}*You need to start a new game to enable this option.*{/b}
"""
default cl10 = """Added brief descriptions to some of the preference menu items.
"""
default cl09 = """Added a name check on load - if the MC's name is blank it'll reset back to default.
Added character thumbnails to the editor for easier identification.
Added the ability to disable the screen flash and/or screen shake that occurs during climax scenes.
Minor bug-fixes."""
default cl08a = """Bug-fix update."""
default cl08 = """Temporarily removed Brookridge from the Replay Gallery. This town was added specifically for future DLC, so for now it's redundant.
Added a Walkthrough Guide which gives you a brief overview to the consequences of some choices.
I've tried to word the overviews as spoiler-free as I can, but inevitably they will still reveal certain events, so I've separated it from the current walkthrough.
You'll need to activate the current walkthrough first, and then choose to enable the full guide. (Default is off)

Added a built-in Editor for anyone who wishes to track/edit character and game variables. (Enabled from the in-game quick menu)
It's what I use for making quick changes when running test playthroughs. *Warning* - Use at your own risk!

Fixed a bug that caused unlocked replays to get locked when using the unlocker.

Added options to the Gallery Unlocker - You can now soft or hard unlock clips. You also have the option to reset all clips to their original locked state.

Added brief descriptions of the characters to the Replay Gallery."""
default cl07 = """Modified the replay gallery slightly. Separated the Millie/Violet scenes into their own slots.

Added a built-in gallery unlocker that you can toggle on/off.
When unlocked, all replays can be watched. When locked, it will re-lock only those that you have not yet unlocked in-game (watching from replay will not change its game state).
*NOTE: Some replays are dependent on in-game choices, so can play out differently. Replays you watch from unlocking the gallery that have yet to be played in-game will use default variables.*

There's been one or two reports of the MC's name being lost, or changing, after loading a save.
I've implemented a quick-fix solution (for now) - You can now change the MC's name at any point during the game by simply clicking on his name (when he talks on-screen). Click on his name and a prompt to enter a new name will be shown.
This action can be disabled from the preferences menu, should you wish to do so. *This is only active for the MC Name*"""

default cl06 = """Added the ability to modify the auto-advance I sometimes use in this VN (see Preferences menu).
You can now disable it completely or have an icon appear in the bottom corner when the VN is auto-advancing (the icon can be resized and its transparency adjusted).
This feature only works for the new content in this update. I haven't implemented it for the older content yet, as it's still in testing and could change."""

default cl05 = """Added the option to change the colors of the cellphone backgrounds and text. When cellphone is on-screen click the gear icon at bottom left corner.
Made some changes to the Interactive Focus element. Icons have changed to make them easier to spot.
Also included the option to deactivate it.(Gives you regular menu choices instead)"""

default cl04 = """Customised the Preferences menu.

Added the option to enable/disable lesbian content in group scenes.

Added pregnancy to the Optional Fetishes menu. (Doesn't affect the game in any way for now. Added it for later)

Updated the replay gallery GUI a little.

Added an Image Gallery (in-game only). During the game some characters may send you a picture or two and they'll be added to your gallery. 
You can open the gallery at any time from the QuickMenu at the bottom of the screen.
*NOTE: Some characters may offer to occasionally send you more photos. Your answer will not affect that character's relationship status in any way.
If you don't want these bonus images, it's safe to say no, and it won't affect the characters' storyline."""

default cl03 = """Added a slider bar in preferences, which enables players to adjust the opacity of the interactive-focus icons.

Added GroupSex to the Optional Fetishes menu (Default is on. When off, you no longer need to manually avoid it in-game)
*NOTE: When GroupSex is Enabled, group sex won't be forced in every situation; it'll still be your choice.

Updated edits to story/dialog from previous version(s):
Sarah Route (Conversation with Dawn)
If GroupSex is disabled, there is no longer a discussion about what happened between Sarah and Dawn at college.

Minor dialogue change - 
When Alex asks if you're into girls with tattoos, the optional answer has been changed from 'Sexy as hell' to "Depends on the girl'"""

default cl02 = """Added a built-in Walkthrough (Default is off)

Added the optional ability to name your Saves (Default is off)

Added the option to disable Character Portraits in Dialogue box (Default is off)

Added Incest to the Optional Fetishes menu (Default is on. When off, you no longer need to manually avoid it in-game)
*NOTE: If you disable incest, while not absolutely necessary, it's advisable to start a new game.
Family characters are hidden in the replay gallery when incest is disabled.

Added a notification when a character's path closes.

Updated edits to story/dialog from previous version(s):
Man-cave scene: 
The kiss with Cara is no longer forced; you now have the option to decline it.
If you closed the path for Alex (saying you weren't into tattooed women), this scene is now longer and plays out a little differently.
The scene in Millie's bedroom hasn't changed but has been altered slightly. 
Her hand is now an Interactive Focus option instead of forcing the dialog (It only appears if you didn't knock on the door first beforehand).
MovieNight scene:
If you previously showed no incestuous interest in Millie, the dialogue has been altered to reflect this, and you no longer have lewd thoughts when sitting beside her."""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
