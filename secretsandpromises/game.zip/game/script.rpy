label start:
    python:
        toggle_walkthrough()   
    show screen Tutorial
    pause
    hide screen Tutorial
    scene wlkthru
    pause
    scene black
    call screen EZModeOnOff()
    $ EzModeActive=_return
    $ SaveVers=1
    jump Springhaven_Start1
return

label after_load:
    $ renpy.random.seed()
    if persistent.McName=="":
        $ persistent.McName="John"
    python:
        toggle_walkthrough()
    if SaveVers==0:
        $ renpy.rollback(True, 5, False, True, "UpdateSaveVersion", True)

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
