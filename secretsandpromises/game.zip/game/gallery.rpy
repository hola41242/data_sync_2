default Gallery_items = []
define gpath = "thumbs/gal/"

init python:
    g_maxthumbx = config.screen_width / (4 + 1)
    g_maxthumby = config.screen_height / (4 + 1)
    gallery_page = 0
    SelectedImage="gui/gal_def.jpg"
    class GalleryItem:
        def __init__(self, thumb,hthumb, img):
            self.thumb = thumb
            self.hthumb = hthumb
            self.img = img

label AddGaleryItem(imgid, ntf=True):
    $ Gallery_items.append(GalleryItem(gpath+imgid+"_t.jpg",gpath+imgid+"_h.jpg", gpath+imgid+"_f.jpg"))
    if ntf:
        $ renpy.notify("A picture was added to your gallery.")
return

screen phonegallery():
    modal True
    frame:
        background SelectedImage
        xpos 110
        ypos 0
        xsize 478
        ysize 1056
    frame:
        background "gui/gal_bg.png"
        foreground "gui/gal_fg.png"

        has frame
        background None
        xpos 679
        ypos 50
        xsize 1145
        ysize 931
        if len(Gallery_items)>0:
            $ start = gallery_page * 32
            $ end = min(start + 32 - 1, len(Gallery_items) - 1)
            grid 8 4:
                xfill True
                yfill True

                for i in range(start, end + 1):
                    imagebutton:
                        idle Gallery_items[i].thumb
                        hover Gallery_items[i].hthumb
                        action SetScreenVariable("SelectedImage", Gallery_items[i].img)

                for i in range(end - start + 1, 32):
                    null

    if gallery_page > 0:
        imagebutton:
            idle "gui/gal_p.png"
            hover "gui/gal_ph.png"
            action SetVariable("gallery_page", gallery_page - 1)
            xpos 689
            ypos 990

    if (gallery_page + 1) * 32 < len(Gallery_items):
        imagebutton:
            idle "gui/gal_n.png"
            hover "gui/gal_nh.png"
            action SetVariable("gallery_page", gallery_page + 1)
            xpos 1630
            ypos 990
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
